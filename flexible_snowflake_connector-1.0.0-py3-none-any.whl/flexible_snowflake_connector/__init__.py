"""
Flexible Snowflake Connector

A flexible, enterprise-grade Snowflake connection utility supporting multiple
connector types with integrated AWS Vault authentication and RSA key management.

🔒 SECURITY FEATURES:
- RSA credential management through Vault
- AWS IAM-based authentication  
- Protected internal functions
- Comprehensive parameter validation
- Production-ready error handling

🚀 SUPPORTED CONNECTORS:
1. Snowpark - DataFrame-based operations, ML workflows
2. Snowflake Connector - Traditional SQL operations, JDBC-like interface
3. PySpark - Big data processing, Spark pipelines (EMR/EKS/Kubeflow)

📦 QUICK START:

    from flexible_snowflake_connector import get_snowflake_connection
    
    # Snowpark (default)
    session = get_snowflake_connection(
        service_id="your-service-id",
        vault_role_name="your-vault-role",
        vault_namespace="your-namespace", 
        vault_path="your/vault/path",
        vault_url="https://vault.company.com:8200",
        verify_ssl=True,
        snowflake_warehouse="YOUR_WH",
        snowflake_schema="YOUR_SCHEMA",
        sf_database="YOUR_DB",
        sf_account="company.snowflakecomputing.com"
    )
    
    # Python Connector
    conn = get_snowflake_connection(
        connector_type="connector",
        # ... same parameters
    )
    
    # PySpark
    sf_options = get_snowflake_connection(
        connector_type="pyspark",
        # ... same parameters
    )

Version: 3.0.0
Author: Internal Security Team
License: Internal Use Only
"""

from .connection import get_snowflake_connection
from .connectors import get_spark_snowflake_config

# Package metadata
__version__ = "3.0.0"
__author__ = "Internal Security Team"
__license__ = "Internal Use Only"
__title__ = "Flexible Snowflake Connector"

# Public API
__all__ = [
    "get_snowflake_connection",
    "get_spark_snowflake_config"
]


def get_version():
    """Get the current package version."""
    return __version__


def get_supported_connectors():
    """Get list of supported connector types."""
    return ["snowpark", "connector", "pyspark"]


def usage_help():
    """Display basic usage information."""
    help_text = f"""
    {__title__} v{__version__}
    
    SUPPORTED CONNECTOR TYPES:
    - snowpark   : Snowflake Snowpark (DataFrame API, ML workflows)
    - connector  : Snowflake Python Connector (SQL operations, JDBC-like)
    - pyspark    : PySpark integration (EMR, EKS, Kubeflow)
    
    MAIN FUNCTION:
    get_snowflake_connection(connector_type="snowpark", ...)
    
    HELPER FUNCTIONS:
    get_spark_snowflake_config() - Get PySpark configuration
    get_supported_connectors()   - List supported connector types
    get_version()                - Get package version
    
    DOCUMENTATION:
    - See README.md for complete usage guide
    - Check examples/ for connector-specific examples
    - Review SECURITY_GUIDE.md for security best practices
    
    SUPPORT:
    - Internal documentation available
    - Contact security team for questions
    """
    print(help_text)
    return help_text
