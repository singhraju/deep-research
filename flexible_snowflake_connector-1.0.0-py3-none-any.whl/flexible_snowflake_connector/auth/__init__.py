"""
Authentication Module

Provides AWS IAM and Vault authentication with RSA key management.
"""

from .vault_auth import (
    verify_aws_credentials,
    authenticate_with_vault,
    fetch_vault_secret
)
from .rsa_handler import extract_rsa_key, convert_pem_to_der

__all__ = [
    'verify_aws_credentials',
    'authenticate_with_vault',
    'fetch_vault_secret',
    'extract_rsa_key',
    'convert_pem_to_der'
]
