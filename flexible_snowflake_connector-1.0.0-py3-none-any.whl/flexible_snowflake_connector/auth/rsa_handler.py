"""
RSA Key Handler Module

Handles RSA private key processing for Snowflake authentication.
"""

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend


def extract_rsa_key(vault_response):
    """
    Extract RSA private key from Vault response.
    
    Handles different Vault response structures:
    - KV v1 API or static-creds: {"data": {"rsa_private_key": "..."}}
    - KV v2 API: {"data": {"data": {"rsa_private_key": "..."}}}
    
    Args:
        vault_response (dict): Response from Vault
        
    Returns:
        str: RSA private key in PEM format
        
    Raises:
        Exception: If RSA key not found in response
    """
    if 'data' in vault_response:
        # Check for nested structure (KV v2)
        if isinstance(vault_response['data'], dict) and 'data' in vault_response['data']:
            creds = vault_response['data']['data']
        else:
            # Flat structure (KV v1 or static-creds)
            creds = vault_response['data']
        
        if 'rsa_private_key' not in creds:
            raise Exception(
                f"RSA private key not found in credentials. "
                f"Available keys: {list(creds.keys())}"
            )
            
        return creds['rsa_private_key']
    else:
        raise Exception("Unexpected response structure from Vault")


def convert_pem_to_der(rsa_private_key_pem):
    """
    Convert RSA private key from PEM to DER format.
    
    Args:
        rsa_private_key_pem (str or bytes): RSA private key in PEM format
        
    Returns:
        bytes: RSA private key in DER format (PKCS8)
        
    Raises:
        Exception: If key conversion fails
    """
    try:
        # Convert to bytes if string
        if isinstance(rsa_private_key_pem, str):
            private_key_bytes = rsa_private_key_pem.encode('utf-8')
        else:
            private_key_bytes = rsa_private_key_pem
            
        # Load the private key
        p_key = serialization.load_pem_private_key(
            private_key_bytes,
            password=None,
            backend=default_backend()
        )
        
        # Convert to DER format
        pkb = p_key.private_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        return pkb
        
    except Exception as e:
        raise Exception(f"Failed to convert RSA key: {e}")
