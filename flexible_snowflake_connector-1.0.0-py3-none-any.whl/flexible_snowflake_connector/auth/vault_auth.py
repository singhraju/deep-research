"""
Vault Authentication Module

Handles AWS IAM-based authentication with HashiCorp Vault.
"""

import os
import base64
import requests
from datetime import datetime
import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest


def generate_vault_request(role_name=""):
    """
    Generate a signed AWS request for Vault authentication.
    
    Args:
        role_name (str): Vault role name for AWS IAM authentication
        
    Returns:
        dict: Signed request payload for Vault
    """
    sts_region = "us-east-1"
    aws_region = os.getenv("AWS_REGION", "us-east-1")
    
    session = boto3.session.Session(region_name=aws_region)
    credentials = session.get_credentials().get_frozen_credentials()

    request_url = "https://sts.amazonaws.com/"
    request_body = "Action=GetCallerIdentity&Version=2011-06-15"
    headers = {
        "Host": "sts.amazonaws.com",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Amz-Date": datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"),
    }
    
    if credentials.token:
        headers["X-Amz-Security-Token"] = credentials.token

    aws_request = AWSRequest(
        method="POST",
        url=request_url,
        data=request_body,
        headers=headers
    )
    SigV4Auth(credentials, "sts", sts_region).add_auth(aws_request)

    required_headers = ["Host", "Authorization", "Content-Type", "X-Amz-Date"]  
    if credentials.token:
        required_headers.append("X-Amz-Security-Token")
    
    filtered_headers = {k: v for k, v in aws_request.headers.items() 
                       if k in required_headers}

    return {
        'iam_http_request_method': aws_request.method,
        'iam_request_url': base64.b64encode(request_url.encode('utf-8')).decode('utf-8'),
        'iam_request_body': base64.b64encode(request_body.encode('utf-8')).decode('utf-8'),
        'iam_request_headers': filtered_headers,
        'role': role_name,
    }


def verify_aws_credentials():
    """
    Verify that AWS credentials are valid.
    
    Returns:
        tuple: (is_valid: bool, info: dict or str)
    """
    aws_region = os.getenv("AWS_REGION", "us-east-2")
    session = boto3.session.Session(region_name=aws_region)

    try:
        client = session.client("sts")
        response = client.get_caller_identity()
        return True, {
            'Account': response['Account'],
            'ARN': response['Arn'], 
            'UserId': response['UserId']
        }
    except Exception as e:
        return False, str(e)


def authenticate_with_vault(vault_url, role_name, verify_ssl=False, cert_path=None):
    """
    Authenticate with Vault using AWS IAM method.
    
    Args:
        vault_url (str): Vault server URL
        role_name (str): Vault role name for AWS IAM authentication
        verify_ssl (bool): Enable SSL certificate verification
        cert_path (str, optional): Path to custom CA certificate file
        
    Returns:
        str: Vault authentication token
        
    Raises:
        Exception: If authentication fails
    """
    signed_request = generate_vault_request(role_name)

    payload = {
        "role": signed_request['role'],
        "iam_http_request_method": signed_request['iam_http_request_method'],
        "iam_request_url": signed_request['iam_request_url'],
        "iam_request_body": signed_request['iam_request_body'],
        "iam_request_headers": signed_request['iam_request_headers'],
    }

    verify = cert_path if cert_path else verify_ssl
    auth_url = f"{vault_url}/v1/auth/aws/login"

    try:
        response = requests.post(auth_url, json=payload, verify=verify)
        if response.status_code == 200:
            auth_data = response.json()
            return auth_data.get('auth', {}).get('client_token')
        else:
            error_msg = f"Vault authentication failed: {response.status_code}"
            if response.text:
                error_msg += f"\nResponse: {response.text}"
            raise Exception(error_msg)
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error during Vault authentication: {e}")


def fetch_vault_secret(vault_url, vault_token, namespace, path, verify_ssl=False, cert_path=None):
    """
    Fetch secret from Vault using authenticated token.
    
    Args:
        vault_url (str): Vault server URL
        vault_token (str): Vault authentication token
        namespace (str): Vault namespace
        path (str): Secret path in Vault
        verify_ssl (bool): Enable SSL verification
        cert_path (str, optional): Path to CA certificate
        
    Returns:
        dict: Secret data from Vault
        
    Raises:
        Exception: If secret fetch fails
    """
    url = f"{vault_url}/v1/{path}"
    headers = {
        "X-Vault-Token": vault_token,
        "X-Vault-Namespace": namespace
    }

    verify = cert_path if cert_path else verify_ssl

    try:
        response = requests.get(url, headers=headers, verify=verify)
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(
                f"Failed to fetch secret. Status: {response.status_code}, "
                f"Response: {response.text}"
            )
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error during secret fetch: {e}")
