"""
Main Connection Module

Provides unified interface for all Snowflake connector types.
"""

from .auth import (
    verify_aws_credentials,
    authenticate_with_vault,
    fetch_vault_secret,
    extract_rsa_key
)
from .connectors import (
    create_snowpark_session,
    create_python_connection,
    create_pyspark_session
)
from .utils import (
    validate_required_params,
    validate_connector_type,
    validate_boolean_param
)


def get_snowflake_connection(
    service_id,
    vault_role_name,
    vault_namespace,
    vault_path,
    vault_url,
    verify_ssl,
    snowflake_warehouse,
    snowflake_schema,
    sf_database,
    sf_account,
    connector_type="snowpark",
    cert_path=None,
    verbose=True,
    **kwargs
):
    """
    Create Snowflake connection with secure Vault-based RSA authentication.
    
    Supports three connector types:
    1. "snowpark" - Snowflake Snowpark Session (default)
    2. "connector" - Snowflake Python Connector
    3. "pyspark" - PySpark Snowflake integration
    
    Args:
        service_id (str): Snowflake service account identifier (REQUIRED)
        vault_role_name (str): Vault role name for AWS IAM auth (REQUIRED)
        vault_namespace (str): Vault namespace (REQUIRED)
        vault_path (str): Vault path for RSA credentials (REQUIRED)
        vault_url (str): Vault URL including port (REQUIRED)
        verify_ssl (bool): Enable SSL verification (REQUIRED)
        snowflake_warehouse (str): Snowflake warehouse name (REQUIRED)
        snowflake_schema (str): Snowflake schema name (REQUIRED)
        sf_database (str): Snowflake database name (REQUIRED)
        sf_account (str): Snowflake account identifier (REQUIRED)
        connector_type (str): Type of connector - "snowpark", "connector", or "pyspark" (default: "snowpark")
        cert_path (str, optional): Path to CA certificate bundle
        verbose (bool): Enable verbose logging (default: True)
        **kwargs: Additional connector-specific parameters
    
    Returns:
        - snowflake.snowpark.Session (if connector_type="snowpark")
        - snowflake.connector.SnowflakeConnection (if connector_type="connector")
        - dict (if connector_type="pyspark") - Snowflake options for PySpark
        
    Raises:
        Exception: If any step fails or required parameters are missing
        
    Examples:
        # Snowpark (default)
        >>> session = get_snowflake_connection(
        ...     service_id="my-service",
        ...     vault_role_name="snowdb-role",
        ...     vault_namespace="eda-snowflakedb",
        ...     vault_path="edaprod/static-creds/service",
        ...     vault_url="https://vault.company.com:8200",
        ...     verify_ssl=True,
        ...     snowflake_warehouse="COMPUTE_WH",
        ...     snowflake_schema="PUBLIC",
        ...     sf_database="PROD_DB",
        ...     sf_account="company.snowflakecomputing.com"
        ... )
        >>> results = session.sql("SELECT * FROM table").collect()
        >>> session.close()
        
        # Python Connector
        >>> conn = get_snowflake_connection(
        ...     connector_type="connector",
        ...     # ... same parameters as above
        ... )
        >>> cursor = conn.cursor()
        >>> cursor.execute("SELECT * FROM table")
        >>> results = cursor.fetchall()
        >>> cursor.close()
        >>> conn.close()
        
        # PySpark
        >>> sf_options = get_snowflake_connection(
        ...     connector_type="pyspark",
        ...     # ... same parameters as above
        ... )
        >>> df = spark.read.format("snowflake").options(**sf_options).option("dbtable", "table").load()
    """
    
    # Validate connector type
    connector_type = validate_connector_type(connector_type)
    
    # Validate all required parameters
    required_params = {
        'service_id': service_id,
        'vault_role_name': vault_role_name,
        'vault_namespace': vault_namespace,
        'vault_path': vault_path,
        'vault_url': vault_url,
        'snowflake_warehouse': snowflake_warehouse,
        'snowflake_schema': snowflake_schema,
        'sf_database': sf_database,
        'sf_account': sf_account
    }
    
    validate_required_params(required_params)
    validate_boolean_param('verify_ssl', verify_ssl)
    
    if verbose:
        print("=" * 70)
        print(f"🔄 Starting Snowflake connection ({connector_type.upper()})...")
        print("=" * 70)
    
    try:
        # Step 1: Verify AWS credentials
        if verbose:
            print("🔐 Step 1/4: Verifying AWS credentials...")
        
        aws_valid, aws_info = verify_aws_credentials()
        if not aws_valid:
            raise Exception(f"AWS credential verification failed: {aws_info}")
        
        if verbose:
            print(f"   ✅ AWS Account: {aws_info['Account']}")

        # Step 2: Authenticate with Vault
        if verbose:
            print(f"🏛️  Step 2/4: Authenticating with Vault (role: {vault_role_name})...")
            
        vault_token = authenticate_with_vault(
            vault_url,
            vault_role_name,
            verify_ssl=verify_ssl,
            cert_path=cert_path
        )

        if not vault_token:
            raise Exception("Failed to obtain Vault token")

        if verbose:
            print(f"   ✅ Vault authentication successful")

        # Step 3: Fetch RSA credentials
        if verbose:
            print(f"🔑 Step 3/4: Retrieving RSA credentials from: {vault_path}")
            
        vault_response = fetch_vault_secret(
            vault_url,
            vault_token,
            vault_namespace,
            vault_path,
            verify_ssl=verify_ssl,
            cert_path=cert_path
        )

        if not vault_response:
            raise Exception("Failed to fetch RSA credentials")

        # Extract RSA private key
        rsa_private_key = extract_rsa_key(vault_response)
        
        if verbose:
            print("   ✅ RSA credentials retrieved successfully")

        # Step 4: Create connection based on connector type
        if verbose:
            print(f"❄️  Step 4/4: Creating {connector_type.upper()} connection...")
        
        if connector_type == "snowpark":
            connection = create_snowpark_session(
                rsa_private_key,
                service_id,
                sf_account=sf_account,
                sf_database=sf_database,
                snowflake_schema=snowflake_schema,
                snowflake_warehouse=snowflake_warehouse,
                **kwargs
            )
            
            if verbose:
                print("   🎉 Snowpark session created successfully!")
                try:
                    results = connection.sql("SELECT CURRENT_ACCOUNT(), CURRENT_ROLE(), CURRENT_USER()").collect()
                    for row in results:
                        print(f"      📊 Account: {row['CURRENT_ACCOUNT()']}")
                        print(f"      👤 Role: {row['CURRENT_ROLE()']}")  
                        print(f"      🆔 User: {row['CURRENT_USER()']}")
                except:
                    pass
        
        elif connector_type == "connector":
            connection = create_python_connection(
                rsa_private_key,
                service_id,
                sf_account=sf_account,
                sf_database=sf_database,
                snowflake_schema=snowflake_schema,
                snowflake_warehouse=snowflake_warehouse,
                **kwargs
            )
            
            if verbose:
                print("   🎉 Snowflake connection created successfully!")
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT CURRENT_ACCOUNT(), CURRENT_ROLE(), CURRENT_USER()")
                    row = cursor.fetchone()
                    print(f"      📊 Account: {row[0]}")
                    print(f"      👤 Role: {row[1]}")
                    print(f"      🆔 User: {row[2]}")
                    cursor.close()
                except:
                    pass
        
        elif connector_type == "pyspark":
            connection = create_pyspark_session(
                rsa_private_key,
                service_id,
                sf_account=sf_account,
                sf_database=sf_database,
                snowflake_schema=snowflake_schema,
                snowflake_warehouse=snowflake_warehouse,
                **kwargs
            )
            
            if verbose:
                print("   🎉 PySpark Snowflake options created successfully!")
                print(f"      📊 Account: {sf_account}")
                print(f"      🗄️  Database: {sf_database}")
                print(f"      📁 Schema: {snowflake_schema}")
                print(f"      ⚙️  Warehouse: {snowflake_warehouse}")
        
        if verbose:
            print("=" * 70)
            
        return connection
        
    except Exception as e:
        if verbose:
            print(f"\n❌ Error: {e}")
            print("=" * 70)
        raise e
