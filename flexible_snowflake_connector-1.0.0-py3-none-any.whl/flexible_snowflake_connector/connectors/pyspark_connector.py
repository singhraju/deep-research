"""
PySpark Connector Module

Provides PySpark integration with Snowflake using RSA authentication.
Optimized for AWS environments (EMR, EKS, Kubeflow).
"""

from ..utils import validate_required_params


def create_pyspark_session(
    rsa_private_key_pem,
    service_id,
    sf_account,
    sf_database,
    snowflake_schema,
    snowflake_warehouse,
    spark_session=None,
    **kwargs
):
    """
    Create or configure PySpark session for Snowflake connectivity.
    
    This function returns Snowflake connection options that can be used with
    PySpark's DataFrame reader/writer. It does NOT create a SparkSession
    (as that's typically managed by EMR/EKS/Kubeflow environments).
    
    Args:
        rsa_private_key_pem (str): RSA private key in PEM format
        service_id (str): Snowflake service/user identifier
        sf_account (str): Snowflake account identifier 
        sf_database (str): Target database name
        snowflake_schema (str): Target schema name
        snowflake_warehouse (str): Compute warehouse name
        spark_session: Optional existing SparkSession to configure
        **kwargs: Additional Snowflake options
        
    Returns:
        dict: Snowflake connection options for PySpark
        
    Raises:
        Exception: If parameter validation fails
        
    Example (EMR/EKS/Kubeflow):
        >>> from pyspark.sql import SparkSession
        >>> 
        >>> # Get Snowflake options
        >>> sf_options = create_pyspark_session(
        ...     rsa_key_pem,
        ...     "my-service-id",
        ...     "company.snowflakecomputing.com",
        ...     "PROD_DB",
        ...     "PUBLIC",
        ...     "COMPUTE_WH"
        ... )
        >>> 
        >>> # Use with existing Spark session
        >>> spark = SparkSession.builder.getOrCreate()
        >>> 
        >>> # Read from Snowflake
        >>> df = spark.read \\
        ...     .format("snowflake") \\
        ...     .options(**sf_options) \\
        ...     .option("dbtable", "my_table") \\
        ...     .load()
        >>> 
        >>> # Write to Snowflake
        >>> df.write \\
        ...     .format("snowflake") \\
        ...     .options(**sf_options) \\
        ...     .option("dbtable", "output_table") \\
        ...     .mode("overwrite") \\
        ...     .save()
    """
    
    # Validate required parameters
    required_params = {
        'rsa_private_key_pem': rsa_private_key_pem,
        'service_id': service_id,
        'sf_account': sf_account,
        'sf_database': sf_database,
        'snowflake_schema': snowflake_schema,
        'snowflake_warehouse': snowflake_warehouse
    }
    
    validate_required_params(required_params)
    
    try:
        # Build Snowflake options for PySpark
        # Note: PySpark Snowflake connector uses PEM key directly (not DER)
        snowflake_options = {
            "sfURL": f"{sf_account}.snowflakecomputing.com",
            "sfUser": service_id,
            "pem_private_key": rsa_private_key_pem,
            "sfDatabase": sf_database,
            "sfSchema": snowflake_schema,
            "sfWarehouse": snowflake_warehouse,
            "sfRole": f"{service_id}_PRIVS"
        }
        
        # Add any additional options
        snowflake_options.update(kwargs)
        
        # If SparkSession provided, configure it with Snowflake connector
        if spark_session:
            # Ensure Snowflake Spark connector is available
            # This is typically pre-configured in EMR/EKS/Kubeflow
            pass
        
        return snowflake_options
        
    except Exception as e:
        raise Exception(f"Failed to create PySpark Snowflake options: {e}")


def get_spark_snowflake_config():
    """
    Get recommended Spark configuration for Snowflake connector.
    
    Returns:
        dict: Spark configuration options
        
    Example:
        >>> from pyspark.sql import SparkSession
        >>> 
        >>> config = get_spark_snowflake_config()
        >>> spark = SparkSession.builder \\
        ...     .appName("SnowflakeApp") \\
        ...     .config("spark.jars.packages", config["packages"]) \\
        ...     .getOrCreate()
    """
    return {
        "packages": "net.snowflake:spark-snowflake_2.12:2.11.0-spark_3.3",
        "driver_memory": "4g",
        "executor_memory": "4g",
        "recommended_configs": {
            "spark.sql.shuffle.partitions": "200",
            "spark.sql.adaptive.enabled": "true",
            "spark.sql.adaptive.coalescePartitions.enabled": "true"
        }
    }
