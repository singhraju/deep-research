"""
Snowpark Connector Module

Provides Snowflake Snowpark session creation with RSA authentication.
"""

from snowflake.snowpark import Session
from ..auth import convert_pem_to_der
from ..utils import validate_required_params


def create_snowpark_session(
    rsa_private_key_pem,
    service_id,
    sf_account,
    sf_database,
    snowflake_schema,
    snowflake_warehouse,
    **kwargs
):
    """
    Create Snowflake Snowpark session using RSA private key.
    
    Args:
        rsa_private_key_pem (str): RSA private key in PEM format
        service_id (str): Snowflake service/user identifier
        sf_account (str): Snowflake account identifier 
        sf_database (str): Target database name
        snowflake_schema (str): Target schema name
        snowflake_warehouse (str): Compute warehouse name
        **kwargs: Additional Snowpark session parameters
        
    Returns:
        snowflake.snowpark.Session: Active Snowflake Snowpark session
        
    Raises:
        Exception: If session creation fails
        
    Example:
        >>> session = create_snowpark_session(
        ...     rsa_key_pem,
        ...     "my-service-id", 
        ...     "company.snowflakecomputing.com",
        ...     "PROD_DB",
        ...     "PUBLIC",
        ...     "COMPUTE_WH"
        ... )
        >>> results = session.sql("SELECT CURRENT_USER()").collect()
        >>> session.close()
    """
    
    # Validate required parameters
    required_params = {
        'rsa_private_key_pem': rsa_private_key_pem,
        'service_id': service_id,
        'sf_account': sf_account,
        'sf_database': sf_database,
        'snowflake_schema': snowflake_schema,
        'snowflake_warehouse': snowflake_warehouse
    }
    
    validate_required_params(required_params)
    
    try:
        # Convert PEM key to DER format
        pkb = convert_pem_to_der(rsa_private_key_pem)

        # Build connection parameters
        connection_parameters = {
            "account": sf_account,
            "user": service_id, 
            "private_key": pkb,
            "database": sf_database,
            "schema": snowflake_schema,
            "warehouse": snowflake_warehouse,
            "role": f"{service_id}_PRIVS"
        }
        
        # Add any additional parameters
        connection_parameters.update(kwargs)

        # Create Snowpark session
        session = Session.builder.configs(connection_parameters).create()
        return session
        
    except Exception as e:
        raise Exception(f"Failed to create Snowpark session: {e}")
