"""
Parameter Validation Module

Validates connection parameters for all connector types.
"""


def validate_required_params(params_dict):
    """
    Validate that all required parameters are provided and not empty.
    
    Args:
        params_dict (dict): Dictionary of parameter names and values
        
    Raises:
        Exception: If any required parameter is missing or empty
    """
    missing_params = []
    
    for param_name, param_value in params_dict.items():
        if param_value is None or (isinstance(param_value, str) and param_value.strip() == ''):
            missing_params.append(param_name)
    
    if missing_params:
        raise Exception(
            f"Missing required parameters: {', '.join(missing_params)}. "
            f"All parameters must be provided."
        )


def validate_connector_type(connector_type):
    """
    Validate that connector type is supported.
    
    Args:
        connector_type (str): Type of connector
        
    Returns:
        str: Validated connector type (lowercase)
        
    Raises:
        ValueError: If connector type is not supported
    """
    valid_types = ['snowpark', 'connector', 'pyspark']
    connector_type_lower = connector_type.lower()
    
    if connector_type_lower not in valid_types:
        raise ValueError(
            f"Invalid connector_type '{connector_type}'. "
            f"Must be one of: {', '.join(valid_types)}"
        )
    
    return connector_type_lower


def validate_boolean_param(param_name, param_value):
    """
    Validate that a parameter is a boolean.
    
    Args:
        param_name (str): Name of the parameter
        param_value: Value to validate
        
    Raises:
        Exception: If parameter is not a boolean
    """
    if not isinstance(param_value, bool):
        raise Exception(
            f"{param_name} must be a boolean value, "
            f"got: {type(param_value).__name__}"
        )
