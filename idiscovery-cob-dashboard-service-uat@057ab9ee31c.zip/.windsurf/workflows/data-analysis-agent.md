---
description: COB Data Analysis Agent (autonomous, minimal questions)
auto_execution_mode: 3
---
 
# COB Data Analysis Agent (Autonomous)
 
This workflow runs Snowflake analysis via `/snowflake/query` with default assumptions. Ask only if a missing detail would materially change the query.
 
## Defaults (use unless the user specifies)
- **Date range:** last 30 days (start = today - 30, end = today)
- **Granularity:** aggregate
- **LOB:** all
- **Output:** table + 2-3 bullet insights
- **Schema:** `NON_CRTFD_AIFS.DL_DV_TMBR` (do not use `VW_SLVR_COB_AI`)
- **Dedup for work item counts:**
  ```sql
  ROW_NUMBER() OVER (
      PARTITION BY PYID
      ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC
  )
  ```
- **Date filtering:** inclusive start, exclusive end (end + 1 day)
- **Column hints:** use `PYSTATUSWORK` (not `PYSTATUS`), avoid `PYWORKTYPE` in `COB_AI_INVNTRY_PROFILE`.
 
## 1) Interpret (minimal questions)
1. Restate the request and list inferred defaults.
2. Map the metric to table(s) and key columns.
3. Ask **one targeted question only if required** (e.g., user vs manager scope). Otherwise proceed.
 
## 2) Plan SQL
1. Select minimal columns with fully qualified table names.
2. Apply explicit filters (date range, user_id, manager_id, lob, status).
3. Add dedup CTE if counting work items.
4. Set LIMIT (default 500) for exploration.
5. List expected output columns and meanings.
 
## 3) Run (Snowflake query API)
```bash
BASE_URL="localhost"
curl -sS --cacert C:/codebase/idiscovery-cob-dashboard-service/cacert.pem \
  -X POST "$BASE_URL/snowflake/query" \
  -H "Content-Type: application/json" \
  -d @/tmp/snowflake_query.json
```
 
## 4) Validate
1. Check `record_count`, unexpected nulls, and outliers.
2. Confirm date filter behavior (inclusive start, exclusive end).
3. Note any assumptions or defaults used.
 
## 5) Summarize + next steps
1. Provide concise findings (table + bullets).
2. Offer **numbered** next-step options (deeper cut, trend, breakdown) without asking extra questions.
 
## Example: Quick Analysis Flow
**Request:** “Show work items completed by user AD44140 in March 2026.”
 
**SQL plan:** Dedup by PYID, then count by intake source system.
 
**Run:**
```bash
BASE_URL="localhost"
curl -sS --cacert C:/codebase/idiscovery-cob-dashboard-service/cacert.pem \
  -X POST "$BASE_URL/snowflake/query" \
  -H "Content-Type: application/json" \
  -d @/tmp/work_items_by_source_query.json
```
 
**Validate + summarize** (top sources, total completed, anomalies).
 