# Performance IQ Auditor Manager API - SQL Documentation

**Generated:** 2026-08-03 14:32:05

**Total APIs:** 18
**Total SQL Queries:** 65

## Table of Contents

1. [ata_rebuttal_drilldown](#ata-rebuttal-drilldown) (4 queries)
2. [ata_score_drilldown](#ata-score-drilldown) (4 queries)
3. [ata_score_gauge](#ata-score-gauge) (4 queries)
4. [audit_cycle_time_gauge](#audit-cycle-time-gauge) (4 queries)
5. [audit_sample_pct_drilldown](#audit-sample-pct-drilldown) (2 queries)
6. [auditor_list](#auditor-list) (1 queries)
7. [auditor_manager_lob](#auditor-manager-lob) (1 queries)
8. [completed_audit_count_drilldown](#completed-audit-count-drilldown) (4 queries)
9. [fuse_time_drilldown](#fuse-time-drilldown) (2 queries)
10. [header_kpis](#header-kpis) (14 queries)
11. [manager_list](#manager-list) (1 queries)
12. [quality_outcomes](#quality-outcomes) (5 queries)
13. [rebuttal_drilldown](#rebuttal-drilldown) (4 queries)
14. [rebuttals](#rebuttals) (8 queries)
15. [time_utilization](#time-utilization) (1 queries)
16. [user_activity](#user-activity) (4 queries)
17. [work_items_drilldown](#work-items-drilldown) (2 queries)

---

## ata_rebuttal_drilldown

**Number of Queries:** 4

### 1. ATA_REBUTTALS_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS ATA_REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_ata_cases_with_rebuttals
FROM ata_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 2. ATA_REBUTTAL_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH ata_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        REBUTTALFLAG,
        ISATACASE,
        INTAKESOURCESYSTEM,
        PLATFORM,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXUPDATEDATETIME,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'ATA%'
      AND ISATACASE = 'Y'
),
latest_rebuttal_cases AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        REBUTTALFLAG,
        ISATACASE,
        INTAKESOURCESYSTEM,
        PLATFORM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXUPDATEDATETIME,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM ata_base
),
rebuttal_population AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        INTAKESOURCESYSTEM,
        PLATFORM,
        LOB,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM latest_rebuttal_cases
    WHERE rn = 1
      AND REBUTTALFLAG = 'Y'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
completion_candidates AS (
    SELECT
        rp.PYID,
        rp.CASE_TO_AUDIT,
        rp.AUDIT_SUBJECT_ID,
        rp.AUDIT_SUBJECT_NAME,
        rp.AUDIT_SUBJECT_MGR_ID,
        rp.INTAKESOURCESYSTEM,
        rp.PLATFORM,
        rp.LOB,
        rp.INVNTRY_TYPE,
        rp.AUDIT_MONTH,
        rp.AUDIT_YEAR,
        a.PYSTATUSWORK AS completion_status,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY rp.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM rebuttal_population rp
    INNER JOIN ata_base a
        ON rp.PYID = a.PYID
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        INTAKESOURCESYSTEM,
        PLATFORM,
        LOB,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    ce.PYID AS WORK_ITEM_ID,
    COALESCE(ce.INTAKESOURCESYSTEM, 'N/A') AS WORKTYPE_CATEGORY,
    CASE
        WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(ce.completion_status, 'N/A')
    END AS OUTCOME_STATUS,
    COALESCE(ce.LOB, 'N/A') AS LOB,
    ce.completion_ts AS RESOLVED_DATE,
    COALESCE(ce.AUDIT_SUBJECT_ID, 'N/A') AS DOMAIN_ID,
    COALESCE(ce.AUDIT_SUBJECT_NAME, 'N/A') AS ASSOCIATE_NAME,
    COALESCE(ce.PLATFORM, 'N/A') AS PLATFORM_SOURCE_SYSTEM,
    COALESCE(ce.INVNTRY_TYPE, 'N/A') AS INVENTORY_TYPE,
    COALESCE(aa.ERRORCATEGORYTYPE, 'N/A') AS ERROR_TYPE,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS ERROR_CATEGORY,
    COALESCE(aa.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME,
    COALESCE(ce.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ce.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM completion_event ce
INNER JOIN deduped_audit_activity aa
    ON ce.PYID = aa.CASEID
    AND aa.rn = 1
ORDER BY ce.completion_ts DESC
LIMIT 20 OFFSET 0
```

---

### 3. ATA_REBUTTALS_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS ATA_REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_ata_cases_with_rebuttals
FROM ata_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 4. ATA_REBUTTAL_PAGINATED_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH ata_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        REBUTTALFLAG,
        ISATACASE,
        INTAKESOURCESYSTEM,
        PLATFORM,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXUPDATEDATETIME,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'ATA%'
      AND ISATACASE = 'Y'
),
latest_rebuttal_cases AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        REBUTTALFLAG,
        ISATACASE,
        INTAKESOURCESYSTEM,
        PLATFORM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXUPDATEDATETIME,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM ata_base
),
rebuttal_population AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        INTAKESOURCESYSTEM,
        PLATFORM,
        LOB,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM latest_rebuttal_cases
    WHERE rn = 1
      AND REBUTTALFLAG = 'Y'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
completion_candidates AS (
    SELECT
        rp.PYID,
        rp.CASE_TO_AUDIT,
        rp.AUDIT_SUBJECT_ID,
        rp.AUDIT_SUBJECT_NAME,
        rp.AUDIT_SUBJECT_MGR_ID,
        rp.INTAKESOURCESYSTEM,
        rp.PLATFORM,
        rp.LOB,
        rp.INVNTRY_TYPE,
        rp.AUDIT_MONTH,
        rp.AUDIT_YEAR,
        a.PYSTATUSWORK AS completion_status,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY rp.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM rebuttal_population rp
    INNER JOIN ata_base a
        ON rp.PYID = a.PYID
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        INTAKESOURCESYSTEM,
        PLATFORM,
        LOB,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    ce.PYID AS WORK_ITEM_ID,
    COALESCE(ce.INTAKESOURCESYSTEM, 'N/A') AS WORKTYPE_CATEGORY,
    CASE
        WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(ce.completion_status, 'N/A')
    END AS OUTCOME_STATUS,
    COALESCE(ce.LOB, 'N/A') AS LOB,
    ce.completion_ts AS RESOLVED_DATE,
    COALESCE(ce.AUDIT_SUBJECT_ID, 'N/A') AS DOMAIN_ID,
    COALESCE(ce.AUDIT_SUBJECT_NAME, 'N/A') AS ASSOCIATE_NAME,
    COALESCE(ce.PLATFORM, 'N/A') AS PLATFORM_SOURCE_SYSTEM,
    COALESCE(ce.INVNTRY_TYPE, 'N/A') AS INVENTORY_TYPE,
    COALESCE(aa.ERRORCATEGORYTYPE, 'N/A') AS ERROR_TYPE,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS ERROR_CATEGORY,
    COALESCE(aa.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME,
    COALESCE(ce.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ce.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM completion_event ce
INNER JOIN deduped_audit_activity aa
    ON ce.PYID = aa.CASEID
    AND aa.rn = 1
ORDER BY ce.completion_ts DESC
LIMIT 20 OFFSET 0
```

---

## ata_score_drilldown

**Number of Queries:** 4

### 1. ATA_AUDIT_SCORE_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "audit_resolved",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB,
        INTAKESOURCESYSTEM,
        PLATFORM,
        AUDITCYCLETIME,
        INVNTRY_TYPE
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PLATFORM,
        a.AUDITCYCLETIME,
        a.INVNTRY_TYPE,
        a.LOB,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SUBJECT_NAME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        INTAKESOURCESYSTEM,
        PLATFORM,
        AUDITCYCLETIME,
        INVNTRY_TYPE,
        LOB,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)
SELECT
    PYID,
    INTAKESOURCESYSTEM,
    completion_type AS PYSTATUSWORK,
    LOB,
    DATE(completion_timestamp) AS AUDIT_DATE,
    AUDIT_SUBJECT_ID AS AUDITOR_ID,
    COALESCE(AUDIT_SUBJECT_NAME, 'N/A') AS AUDIT_SUBJECT_NAME,
    AUDIT_SCORE,
    PLATFORM,
    TARGET_AUDIT,
    AUDITCYCLETIME,
    INVNTRY_TYPE,
    COALESCE(AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM ata_final_records
ORDER BY AUDIT_DATE DESC, PYID ASC
LIMIT 20 OFFSET 0
```

---

### 2. ATA_AUDIT_SCORE_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "audit_resolved",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)

SELECT
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
```

---

### 3. ATA_AUDIT_SCORE_PAGINATED_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "audit_resolved",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB,
        INTAKESOURCESYSTEM,
        PLATFORM,
        AUDITCYCLETIME,
        INVNTRY_TYPE
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PLATFORM,
        a.AUDITCYCLETIME,
        a.INVNTRY_TYPE,
        a.LOB,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SUBJECT_NAME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        INTAKESOURCESYSTEM,
        PLATFORM,
        AUDITCYCLETIME,
        INVNTRY_TYPE,
        LOB,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)
SELECT
    PYID,
    INTAKESOURCESYSTEM,
    completion_type AS PYSTATUSWORK,
    LOB,
    DATE(completion_timestamp) AS AUDIT_DATE,
    AUDIT_SUBJECT_ID AS AUDITOR_ID,
    COALESCE(AUDIT_SUBJECT_NAME, 'N/A') AS AUDIT_SUBJECT_NAME,
    AUDIT_SCORE,
    PLATFORM,
    TARGET_AUDIT,
    AUDITCYCLETIME,
    INVNTRY_TYPE,
    COALESCE(AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM ata_final_records
ORDER BY AUDIT_DATE DESC, PYID ASC
LIMIT 20 OFFSET 0
```

---

### 4. ATA_AUDIT_SCORE_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "audit_resolved",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)

SELECT
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
```

---

## ata_score_gauge

**Number of Queries:** 4

### 1. ATA_AUDIT_SCORE_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)

SELECT
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
```

---

### 2. ATA_SCORE_TREND_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH grouping_logic AS (
    SELECT
        'monthly' AS grouping_type,
        'false' AS use_audit_period_grouping
),
ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),
first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),
completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),
ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.AUDIT_YEAR,
        a.AUDIT_MONTH,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),
ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
),
ata_scores_with_audit_period AS (
    SELECT
        PYID,
        TO_NUMBER(TRIM(AUDIT_SCORE)) AS AUDIT_SCORE,
        completion_timestamp,
        DATE(completion_timestamp) AS completion_date,
        AUDIT_YEAR,
        AUDIT_MONTH,
        CASE UPPER(TRIM(AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM ata_final_records
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(a.completion_timestamp)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(a.completion_timestamp))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(a.AUDIT_YEAR), a.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(a.completion_timestamp))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(a.AUDIT_YEAR),
                CASE
                    WHEN a.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN a.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN a.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(a.completion_timestamp))

            ELSE DATE_TRUNC('year', DATE(a.completion_timestamp))
        END AS group_key,
        a.completion_date,
        a.AUDIT_SCORE,
        a.PYID
    FROM ata_scores_with_audit_period a
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    ROUND(AVG(AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE,
    COUNT(DISTINCT PYID) AS TOTAL_AUDITS,
    MIN(completion_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
```

---

### 3. ATA_AUDIT_SCORE_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)

SELECT
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
```

---

### 4. ATA_SCORE_TREND_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH grouping_logic AS (
    SELECT
        'monthly' AS grouping_type,
        'true' AS use_audit_period_grouping
),
ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),
first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),
completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),
ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.AUDIT_YEAR,
        a.AUDIT_MONTH,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),
ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
),
ata_scores_with_audit_period AS (
    SELECT
        PYID,
        TO_NUMBER(TRIM(AUDIT_SCORE)) AS AUDIT_SCORE,
        completion_timestamp,
        DATE(completion_timestamp) AS completion_date,
        AUDIT_YEAR,
        AUDIT_MONTH,
        CASE UPPER(TRIM(AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM ata_final_records
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(a.completion_timestamp)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(a.completion_timestamp))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(a.AUDIT_YEAR), a.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(a.completion_timestamp))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(a.AUDIT_YEAR),
                CASE
                    WHEN a.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN a.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN a.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(a.completion_timestamp))

            ELSE DATE_TRUNC('year', DATE(a.completion_timestamp))
        END AS group_key,
        a.completion_date,
        a.AUDIT_SCORE,
        a.PYID
    FROM ata_scores_with_audit_period a
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    ROUND(AVG(AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE,
    COUNT(DISTINCT PYID) AS TOTAL_AUDITS,
    MIN(completion_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
```

---

## audit_cycle_time_gauge

**Number of Queries:** 4

### 1. AUDIT_CYCLE_TIME_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME,
        a.AUDITCYCLETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      AND completion_ts >= '2026-07-01' AND completion_ts < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
        ON a.PYID = f.PYID
       AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts
)
SELECT
    COUNT(*) AS TOTAL_RESOLVED_AUDITS,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM cycle_time_at_first_positive_ts
```

---

### 2. AUDIT_CYCLE_TIME_TREND_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH grouping_logic AS (
    SELECT
        'monthly' AS grouping_type,
        'false' AS use_audit_period_grouping
),
audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME,
        a.AUDITCYCLETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      AND completion_ts >= '2026-07-01' AND completion_ts < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.completion_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
      ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.completion_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        f.AUDIT_MONTH,
        f.AUDIT_YEAR,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
      ON a.PYID = f.PYID
     AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        f.AUDIT_MONTH,
        f.AUDIT_YEAR
),
cycle_time_with_audit_period AS (
    SELECT
        c.PYID,
        c.completion_ts,
        c.cycle_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.AUDITCYCLETIME,
        CASE UPPER(TRIM(c.AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM cycle_time_at_first_positive_ts c
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(c.completion_ts)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(c.completion_ts))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(c.AUDIT_YEAR), c.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(c.completion_ts))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(c.AUDIT_YEAR),
                CASE
                    WHEN c.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN c.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN c.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(c.completion_ts))

            ELSE DATE_TRUNC('year', DATE(c.completion_ts))
        END AS group_key,
        DATE(c.completion_ts) AS completion_date,
        c.AUDITCYCLETIME,
        c.PYID
    FROM cycle_time_with_audit_period c
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES,
    COUNT(DISTINCT PYID) AS TOTAL_AUDITS,
    MIN(completion_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
```

---

### 3. AUDIT_CYCLE_TIME_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME,
        a.AUDITCYCLETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
        ON a.PYID = f.PYID
       AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts
)
SELECT
    COUNT(*) AS TOTAL_RESOLVED_AUDITS,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM cycle_time_at_first_positive_ts
```

---

### 4. AUDIT_CYCLE_TIME_TREND_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH grouping_logic AS (
    SELECT
        'monthly' AS grouping_type,
        'true' AS use_audit_period_grouping
),
audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME,
        a.AUDITCYCLETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.completion_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
      ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.completion_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        f.AUDIT_MONTH,
        f.AUDIT_YEAR,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
      ON a.PYID = f.PYID
     AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        f.AUDIT_MONTH,
        f.AUDIT_YEAR
),
cycle_time_with_audit_period AS (
    SELECT
        c.PYID,
        c.completion_ts,
        c.cycle_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.AUDITCYCLETIME,
        CASE UPPER(TRIM(c.AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM cycle_time_at_first_positive_ts c
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(c.completion_ts)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(c.completion_ts))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(c.AUDIT_YEAR), c.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(c.completion_ts))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(c.AUDIT_YEAR),
                CASE
                    WHEN c.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN c.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN c.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(c.completion_ts))

            ELSE DATE_TRUNC('year', DATE(c.completion_ts))
        END AS group_key,
        DATE(c.completion_ts) AS completion_date,
        c.AUDITCYCLETIME,
        c.PYID
    FROM cycle_time_with_audit_period c
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES,
    COUNT(DISTINCT PYID) AS TOTAL_AUDITS,
    MIN(completion_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
```

---

## audit_sample_pct_drilldown

**Number of Queries:** 2

### 1. AUDIT_SAMPLE_PCT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH invntry_base AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        PYSTATUSWORK,
        LOB,
        INTAKESOURCESYSTEM
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
deduped_invntry AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID
    FROM invntry_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND INTAKESOURCESYSTEM NOT IN ('ASPEN', 'eCOB Intake')
      AND INTAKESOURCESYSTEM NOT LIKE '%-DUP'
      AND INTAKESOURCESYSTEM NOT LIKE '%Adhoc%'
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        DATE(PXCREATEDATETIME) AS audit_date
    FROM audit_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
audited_cases AS (
    SELECT
        i.PYID AS inventory_case,
        a.PYID AS audit_case,
        a.AUDITOR_ID,
        a.PYSTATUSWORK AS audit_status
    FROM deduped_invntry i
    LEFT JOIN deduped_audit a
        ON i.PYID = a.CASE_TO_AUDIT
),
audit_summary AS (
    SELECT
        COUNT(DISTINCT inventory_case) AS total_cases_resolved,
        COUNT(DISTINCT CASE WHEN audit_case IS NOT NULL THEN inventory_case END) AS total_audited,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN inventory_case END) AS open_audits,
        COUNT(DISTINCT CASE WHEN audit_status = 'Resolved-Completed' THEN inventory_case END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN inventory_case END) AS pending_audits
    FROM audited_cases
)
SELECT
    total_cases_resolved AS TOTAL_CASES_RESOLVED,
    open_audits AS OPEN_AUDITS,
    closed_audits AS CLOSED_AUDITS,
    pending_audits AS PENDING_AUDITS,
    total_audited AS TOTAL_AUDITS,
    total_cases_resolved AS TOTAL_WORK_ITEMS_COMPLETED,
    total_audited AS TOTAL_ITEMS_AUDITED,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS AUDIT_SAMPLE_PCT,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS OVERALL_AUDIT_SAMPLE_PCT
FROM audit_summary
```

---

### 2. AUDIT_SAMPLE_PCT_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH invntry_base AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        PYSTATUSWORK,
        LOB,
        INTAKESOURCESYSTEM
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
deduped_invntry AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID
    FROM invntry_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND INTAKESOURCESYSTEM NOT IN ('ASPEN', 'eCOB Intake')
      AND INTAKESOURCESYSTEM NOT LIKE '%-DUP'
      AND INTAKESOURCESYSTEM NOT LIKE '%Adhoc%'
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        DATE(PXCREATEDATETIME) AS audit_date
    FROM audit_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
audited_cases AS (
    SELECT
        i.PYID AS inventory_case,
        a.PYID AS audit_case,
        a.AUDITOR_ID,
        a.PYSTATUSWORK AS audit_status
    FROM deduped_invntry i
    LEFT JOIN deduped_audit a
        ON i.PYID = a.CASE_TO_AUDIT
),
audit_summary AS (
    SELECT
        COUNT(DISTINCT inventory_case) AS total_cases_resolved,
        COUNT(DISTINCT CASE WHEN audit_case IS NOT NULL THEN inventory_case END) AS total_audited,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN inventory_case END) AS open_audits,
        COUNT(DISTINCT CASE WHEN audit_status = 'Resolved-Completed' THEN inventory_case END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN inventory_case END) AS pending_audits
    FROM audited_cases
)
SELECT
    total_cases_resolved AS TOTAL_CASES_RESOLVED,
    open_audits AS OPEN_AUDITS,
    closed_audits AS CLOSED_AUDITS,
    pending_audits AS PENDING_AUDITS,
    total_audited AS TOTAL_AUDITS,
    total_cases_resolved AS TOTAL_WORK_ITEMS_COMPLETED,
    total_audited AS TOTAL_ITEMS_AUDITED,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS AUDIT_SAMPLE_PCT,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS OVERALL_AUDIT_SAMPLE_PCT
FROM audit_summary
```

---

## auditor_list

**Number of Queries:** 1

### 1. AUDITOR_LIST_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH auditor AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE USERID IS NOT NULL 
        AND PYACCESSGROUP IN ('COB:FrontLineAuditor', 'CLMSCCU:Auditor')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
)
SELECT DISTINCT
    auditor.USERID AS ASSOCIATE_ID,
    auditor.USERNAME AS ASSOCIATE_NAME
FROM auditor
WHERE 1=1
AND auditor.PYREPORTTO IN ('AC95624')
ORDER BY auditor.USERNAME
```

---

## auditor_manager_lob

**Number of Queries:** 1

### 1. AUDITOR_MANAGER_LOB_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    AND REPORTTOMANAGERID IN ('AC95624')
    AND PYRESOLVEDUSERID IN ('AG50550')
UNION
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    AND AUDITOR_MGR_ID IN ('AC95624')
    AND AUDITOR_ID IN ('AG50550')
```

---

## completed_audit_count_drilldown

**Number of Queries:** 4

### 1. COMPLETED_AUDIT_COUNT_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "audit_resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.INTAKESOURCESYSTEM,
        a.INVNTRY_TYPE,
        a.LOB,
        a.PLATFORM,
        a.AUDITOR_ID,
        a.AUDITOR_NAME,
        a.AUDITOR_MGR_ID,
        a.AUDITCYCLETIME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.INTAKESOURCESYSTEM,
        a.INVNTRY_TYPE,
        a.LOB,
        a.PLATFORM,
        a.AUDITOR_ID,
        a.AUDITOR_NAME,
        a.AUDITOR_MGR_ID,
        a.AUDITCYCLETIME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS completion_status,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN UPPER(TRIM(a.PYSTATUSWORK)) = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN UPPER(TRIM(a.PYSTATUSWORK)) = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE UPPER(TRIM(a.PYSTATUSWORK)) IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      AND completion_ts >= '2026-07-01' AND completion_ts < DATEADD(day, 1, '2026-07-29'::DATE)
      AND a.LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
)
SELECT
    PYID AS work_item,
    COALESCE(INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(AUDITCYCLETIME::VARCHAR, '0') AS audit_cycle_time,
    CASE
        WHEN completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(completion_status, 'N/A')
    END AS audit_resolved_status,
    COALESCE(INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(completion_ts, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(AUDITOR_ID, 'N/A') AS auditor_id,
    COALESCE(AUDITOR_NAME, 'N/A') AS auditor_name,
    COALESCE(PLATFORM, 'N/A') AS platform_source_system,
    COALESCE(AUDIT_MONTH, 'N/A') AS audit_month,
    COALESCE(AUDIT_YEAR, 'N/A') AS audit_year
FROM filtered_completion
ORDER BY DATE(completion_ts) DESC, PYID ASC
LIMIT 20 OFFSET 0
```

---

### 2. COMPLETED_AUDIT_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "audit_resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
    AND completion_ts >= '2026-07-01' AND completion_ts < DATEADD(day, 1, '2026-07-29'::DATE)
    AND a.LOB IN ('Commercial', 'Medicaid', 'Medicare')
    AND AUDITOR_ID IN ('AG50550')
    AND AUDITOR_MGR_ID IN ('AC95624')
)
SELECT
    COUNT(DISTINCT PYID) AS COMPLETED_AUDIT_COUNT
FROM filtered_completion
```

---

### 3. COMPLETED_AUDIT_COUNT_PAGINATED_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "audit_resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.INTAKESOURCESYSTEM,
        a.INVNTRY_TYPE,
        a.LOB,
        a.PLATFORM,
        a.AUDITOR_ID,
        a.AUDITOR_NAME,
        a.AUDITOR_MGR_ID,
        a.AUDITCYCLETIME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.INTAKESOURCESYSTEM,
        a.INVNTRY_TYPE,
        a.LOB,
        a.PLATFORM,
        a.AUDITOR_ID,
        a.AUDITOR_NAME,
        a.AUDITOR_MGR_ID,
        a.AUDITCYCLETIME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS completion_status,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN UPPER(TRIM(a.PYSTATUSWORK)) = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN UPPER(TRIM(a.PYSTATUSWORK)) = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE UPPER(TRIM(a.PYSTATUSWORK)) IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND a.LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
)
SELECT
    PYID AS work_item,
    COALESCE(INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(AUDITCYCLETIME::VARCHAR, '0') AS audit_cycle_time,
    CASE
        WHEN completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(completion_status, 'N/A')
    END AS audit_resolved_status,
    COALESCE(INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(completion_ts, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(AUDITOR_ID, 'N/A') AS auditor_id,
    COALESCE(AUDITOR_NAME, 'N/A') AS auditor_name,
    COALESCE(PLATFORM, 'N/A') AS platform_source_system,
    COALESCE(AUDIT_MONTH, 'N/A') AS audit_month,
    COALESCE(AUDIT_YEAR, 'N/A') AS audit_year
FROM filtered_completion
ORDER BY DATE(completion_ts) DESC, PYID ASC
LIMIT 20 OFFSET 0
```

---

### 4. COMPLETED_AUDIT_COUNT_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "audit_resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
    AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
    AND a.LOB IN ('Commercial', 'Medicaid', 'Medicare')
    AND AUDITOR_ID IN ('AG50550')
    AND AUDITOR_MGR_ID IN ('AC95624')
)
SELECT
    COUNT(DISTINCT PYID) AS COMPLETED_AUDIT_COUNT
FROM filtered_completion
```

---

## fuse_time_drilldown

**Number of Queries:** 2

### 1. FUSE_TIME_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH associate_hierarchy AS (
    -- Get list of associates who reported to specified manager during the period
    SELECT DISTINCT
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS work_date
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '2026-07-01' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND PYRESOLVEDUSERID IN ('AG50550')
      AND REPORTTOMANAGERID IN ('AC95624')
)
SELECT COUNT(*) as TOTAL_COUNT
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u 
INNER JOIN associate_hierarchy ah
    ON u.USERID = ah.PYRESOLVEDUSERID
    AND u.LOGINDATE = ah.work_date
```

---

### 2. FUSE_TIME_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH associate_hierarchy AS (
    -- Get list of associates who reported to specified manager during the period
    SELECT DISTINCT
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS work_date
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '2026-07-01' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND PYRESOLVEDUSERID IN ('AG50550')
      AND REPORTTOMANAGERID IN ('AC95624')
)
SELECT 
    u.USERNAME,
    u.USERID,
    u.LOGINDATE,
    u.FIRSTLOGINTIME,
    u.LASTLOGOUTTIME,
    u.TOTALSYSTEMTIME,
    u.FUSE_NON_PRODUCTIVE_TIME,
    u.PRODUCTIVETIME,
    -- Calculate Other Time: Total - (Productive + Non-Productive)
    COALESCE(u.TOTALSYSTEMTIME, 0) - 
    (COALESCE(
        CASE 
            WHEN u.PRODUCTIVETIME IS NOT NULL AND u.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END, 0
    ) + 
    COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0)) AS OTHER_TIME
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u 
INNER JOIN associate_hierarchy ah
    ON u.USERID = ah.PYRESOLVEDUSERID
    AND u.LOGINDATE = ah.work_date
ORDER BY u.LOGINDATE DESC, u.USERNAME ASC, u.USERID ASC
LIMIT 20 OFFSET 0
```

---

## header_kpis

**Number of Queries:** 14

### 1. ATA_AUDIT_SCORE_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)

SELECT
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
```

---

### 2. ATA_REBUTTALS_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
        AND LOB IN ('Commercial')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS ATA_REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_ata_cases_with_rebuttals
FROM ata_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 3. ATA_REBUTTAL_PCT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
        AND LOB IN ('Commercial')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
ata_audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS total_rebuttals,

    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS rebuttals_overturned,

    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS rebuttals_upheld,

    COALESCE(
        ROUND(
            (COUNT(DISTINCT CASE
                WHEN act.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
            END) * 100.0)
            / NULLIF(COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY), 0),
            2
        ),
        0
    ) AS rebuttal_overturn_pct
FROM ata_filtered af
INNER JOIN ata_audit_activity_deduped act
    ON af.PYID = act.CASEID
    AND act.rn = 1
```

---

### 4. AUDIT_CYCLE_TIME_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME,
        a.AUDITCYCLETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      AND completion_ts >= '2026-07-01' AND completion_ts < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
        ON a.PYID = f.PYID
       AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts
)
SELECT
    COUNT(*) AS TOTAL_RESOLVED_AUDITS,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM cycle_time_at_first_positive_ts
```

---

### 5. AUDIT_SAMPLE_PCT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH invntry_base AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        PYSTATUSWORK,
        LOB,
        INTAKESOURCESYSTEM
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
deduped_invntry AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID
    FROM invntry_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND INTAKESOURCESYSTEM NOT IN ('ASPEN', 'eCOB Intake')
      AND INTAKESOURCESYSTEM NOT LIKE '%-DUP'
      AND INTAKESOURCESYSTEM NOT LIKE '%Adhoc%'
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        DATE(PXCREATEDATETIME) AS audit_date
    FROM audit_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
audited_cases AS (
    SELECT
        i.PYID AS inventory_case,
        a.PYID AS audit_case,
        a.AUDITOR_ID,
        a.PYSTATUSWORK AS audit_status
    FROM deduped_invntry i
    LEFT JOIN deduped_audit a
        ON i.PYID = a.CASE_TO_AUDIT
),
audit_summary AS (
    SELECT
        COUNT(DISTINCT inventory_case) AS total_cases_resolved,
        COUNT(DISTINCT CASE WHEN audit_case IS NOT NULL THEN inventory_case END) AS total_audited,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN inventory_case END) AS open_audits,
        COUNT(DISTINCT CASE WHEN audit_status = 'Resolved-Completed' THEN inventory_case END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN inventory_case END) AS pending_audits
    FROM audited_cases
)
SELECT
    total_cases_resolved AS TOTAL_CASES_RESOLVED,
    open_audits AS OPEN_AUDITS,
    closed_audits AS CLOSED_AUDITS,
    pending_audits AS PENDING_AUDITS,
    total_audited AS TOTAL_AUDITS,
    total_cases_resolved AS TOTAL_WORK_ITEMS_COMPLETED,
    total_audited AS TOTAL_ITEMS_AUDITED,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS AUDIT_SAMPLE_PCT,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS OVERALL_AUDIT_SAMPLE_PCT
FROM audit_summary
```

---

### 6. COMPLETED_AUDIT_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
    AND completion_ts >= '2026-07-01' AND completion_ts < DATEADD(day, 1, '2026-07-29'::DATE)
    AND LOB IN ('Commercial')
    AND AUDITOR_ID IN ('AG50550')
    AND AUDITOR_MGR_ID IN ('AC95624')
)
SELECT
    COUNT(DISTINCT PYID) AS COMPLETED_AUDIT_COUNT
FROM filtered_completion
```

---

### 7. WORK_ITEMS_COMPLETED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        REPORTTOMANAGERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        REPORTTOMANAGERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG50550')
      AND REPORTTOMANAGERID IN ('AC95624')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM filtered_inventory
```

---

### 8. ATA_AUDIT_SCORE_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)

SELECT
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
```

---

### 9. ATA_REBUTTALS_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
        AND LOB IN ('Commercial')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS ATA_REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_ata_cases_with_rebuttals
FROM ata_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 10. ATA_REBUTTAL_PCT_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
        AND LOB IN ('Commercial')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
ata_audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS total_rebuttals,

    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS rebuttals_overturned,

    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS rebuttals_upheld,

    COALESCE(
        ROUND(
            (COUNT(DISTINCT CASE
                WHEN act.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
            END) * 100.0)
            / NULLIF(COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY), 0),
            2
        ),
        0
    ) AS rebuttal_overturn_pct
FROM ata_filtered af
INNER JOIN ata_audit_activity_deduped act
    ON af.PYID = act.CASEID
    AND act.rn = 1
```

---

### 11. AUDIT_CYCLE_TIME_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME,
        a.AUDITCYCLETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
        ON a.PYID = f.PYID
       AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts
)
SELECT
    COUNT(*) AS TOTAL_RESOLVED_AUDITS,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM cycle_time_at_first_positive_ts
```

---

### 12. AUDIT_SAMPLE_PCT_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH invntry_base AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        PYSTATUSWORK,
        LOB,
        INTAKESOURCESYSTEM
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
deduped_invntry AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID
    FROM invntry_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND INTAKESOURCESYSTEM NOT IN ('ASPEN', 'eCOB Intake')
      AND INTAKESOURCESYSTEM NOT LIKE '%-DUP'
      AND INTAKESOURCESYSTEM NOT LIKE '%Adhoc%'
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        DATE(PXCREATEDATETIME) AS audit_date
    FROM audit_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
audited_cases AS (
    SELECT
        i.PYID AS inventory_case,
        a.PYID AS audit_case,
        a.AUDITOR_ID,
        a.PYSTATUSWORK AS audit_status
    FROM deduped_invntry i
    LEFT JOIN deduped_audit a
        ON i.PYID = a.CASE_TO_AUDIT
),
audit_summary AS (
    SELECT
        COUNT(DISTINCT inventory_case) AS total_cases_resolved,
        COUNT(DISTINCT CASE WHEN audit_case IS NOT NULL THEN inventory_case END) AS total_audited,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN inventory_case END) AS open_audits,
        COUNT(DISTINCT CASE WHEN audit_status = 'Resolved-Completed' THEN inventory_case END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN inventory_case END) AS pending_audits
    FROM audited_cases
)
SELECT
    total_cases_resolved AS TOTAL_CASES_RESOLVED,
    open_audits AS OPEN_AUDITS,
    closed_audits AS CLOSED_AUDITS,
    pending_audits AS PENDING_AUDITS,
    total_audited AS TOTAL_AUDITS,
    total_cases_resolved AS TOTAL_WORK_ITEMS_COMPLETED,
    total_audited AS TOTAL_ITEMS_AUDITED,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS AUDIT_SAMPLE_PCT,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS OVERALL_AUDIT_SAMPLE_PCT
FROM audit_summary
```

---

### 13. COMPLETED_AUDIT_COUNT_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
    AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
    AND LOB IN ('Commercial')
    AND AUDITOR_ID IN ('AG50550')
    AND AUDITOR_MGR_ID IN ('AC95624')
)
SELECT
    COUNT(DISTINCT PYID) AS COMPLETED_AUDIT_COUNT
FROM filtered_completion
```

---

### 14. WORK_ITEMS_COMPLETED_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        REPORTTOMANAGERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        REPORTTOMANAGERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG50550')
      AND REPORTTOMANAGERID IN ('AC95624')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM filtered_inventory
```

---

## manager_list

**Number of Queries:** 1

### 1. MANAGERS_LIST_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH auditor AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE PYACCESSGROUP IN ('COB:FrontLineAuditor', 'CLMSCCU:Auditor')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
),
manager AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYACCESSGROUP
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
)
SELECT DISTINCT  
    manager.USERID AS MANAGER_ID, 
    manager.USERNAME AS MANAGER_NAME 
FROM auditor 
INNER JOIN manager 
    ON auditor.PYREPORTTO = manager.USERID
WHERE manager.USERID IS NOT NULL
  AND manager.USERNAME IS NOT NULL
  
ORDER BY manager.USERNAME
```

---

## quality_outcomes

**Number of Queries:** 5

### 1. ATA_AUDIT_SCORE_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG50550')
      AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)

SELECT
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
```

---

### 2. ATA_REBUTTALS_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        
        AND LOB IN ('Commercial')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS ATA_REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_ata_cases_with_rebuttals
FROM ata_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 3. ATA_SCORE_TREND_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH date_range AS (
    SELECT
        DATEDIFF(day, '2026-07-01'::DATE, '2026-07-29'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
audit_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        AUDITOR_ID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial')
      AND PYID LIKE 'AUD%'
      AND AUDITOR_ID IN ('AG50550')
),
auditor_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-07-01' AND LOGINDATE < DATEADD(day, 1, '2026-07-29'::DATE)
        AND USERID IN ('AG50550')
        AND PYREPORTTO IN ('AC95624')
),
audit_with_manager AS (
    SELECT
        aud.PYID,
        aud.AUDITOR_ID,
        aud.resolved_date
    FROM audit_deduped aud
    INNER JOIN auditor_manager_mapping am
        ON aud.AUDITOR_ID = am.USERID
        AND aud.resolved_date = am.LOGINDATE
    WHERE aud.rn = 1
),
ata_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDITOR_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
),
ata_with_date AS (
    SELECT
        aud.resolved_date AS case_completion_date,
        ata.AUDIT_SCORE,
        ata.PYID AS ata_id
    FROM audit_with_manager aud
    INNER JOIN ata_deduped ata
        ON aud.PYID = ata.CASE_TO_AUDIT
        AND ata.rn = 1
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN a.case_completion_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.case_completion_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.case_completion_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.case_completion_date)
            ELSE DATE_TRUNC('year', a.case_completion_date)
        END AS group_key,
        a.case_completion_date,
        a.AUDIT_SCORE,
        a.ata_id
    FROM ata_with_date a
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_ata_score,
    COUNT(DISTINCT ata_id) AS total_ata_cases,
    MIN(case_completion_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

### 4. AUDIT_CYCLE_TIME_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXUPDATEDATETIME,
        a.AUDITCYCLETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      
      AND LOB IN ('Commercial')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
        ON a.PYID = f.PYID
       AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts
)
SELECT
    COUNT(*) AS TOTAL_RESOLVED_AUDITS,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM cycle_time_at_first_positive_ts
```

---

### 5. AUDIT_CYCLE_TIME_TREND_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH date_range AS (
    SELECT
        DATEDIFF(day, '2026-07-01'::DATE, '2026-07-29'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
audit_deduped AS (
    SELECT
        a.PYID,
        a.AUDITCYCLETIME,
        a.AUDITOR_ID,
        DATE(a.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY a.PYID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND a.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
        AND LOB IN ('Commercial')
        AND a.AUDITCYCLETIME IS NOT NULL
        AND AUDITOR_ID IN ('AG50550')
),
auditor_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-07-01' AND LOGINDATE < DATEADD(day, 1, '2026-07-29'::DATE)
        AND USERID IN ('AG50550')
        AND PYREPORTTO IN ('AC95624')
),
audit_with_manager AS (
    SELECT
        a.PYID,
        a.AUDITCYCLETIME,
        a.resolved_date
    FROM audit_deduped a
    INNER JOIN auditor_manager_mapping am
        ON a.AUDITOR_ID = am.USERID
        AND a.resolved_date = am.LOGINDATE
    WHERE a.rn = 1
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN a.resolved_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.resolved_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.resolved_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.resolved_date)
            ELSE DATE_TRUNC('year', a.resolved_date)
        END AS group_key,
        a.resolved_date,
        a.AUDITCYCLETIME,
        a.PYID
    FROM audit_with_manager a
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    AVG(AUDITCYCLETIME / 60.0) AS avg_audit_cycle_time_minutes,
    COUNT(DISTINCT PYID) AS total_audits,
    MIN(resolved_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

## rebuttal_drilldown

**Number of Queries:** 4

### 1. REBUTTALS_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        AUDITOR_ID
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND AUDITOR_ID IN ('AG50550')
        AND AUDITOR_MGR_ID IN ('AC95624')
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS
FROM audit_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 2. REBUTTAL_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        INTAKESOURCESYSTEM,
        PLATFORM,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
),
latest_rebuttal_cases AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        INTAKESOURCESYSTEM,
        PLATFORM,
        PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM audit_base
),
rebuttal_population AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        INTAKESOURCESYSTEM,
        PLATFORM
    FROM latest_rebuttal_cases
    WHERE rn = 1
      AND REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
completion_candidates AS (
    SELECT
        rp.PYID,
        rp.AUDITOR_ID,
        rp.AUDITOR_NAME,
        rp.LOB,
        rp.AUDIT_MONTH,
        rp.AUDIT_YEAR,
        rp.INTAKESOURCESYSTEM,
        rp.PLATFORM,
        a.PYSTATUSWORK AS completion_status,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY rp.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM rebuttal_population rp
    INNER JOIN audit_base a
        ON rp.PYID = a.PYID
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_NAME,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        INTAKESOURCESYSTEM,
        PLATFORM,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    ce.PYID AS WORK_ITEM_ID,
    COALESCE(ce.INTAKESOURCESYSTEM, 'N/A') AS WORKTYPE_CATEGORY,
    CASE
        WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(ce.completion_status, 'N/A')
    END AS OUTCOME_STATUS,
    COALESCE(ce.LOB, 'N/A') AS LOB,
    ce.completion_ts AS RESOLVED_DATE,
    COALESCE(ce.AUDITOR_ID, 'N/A') AS DOMAIN_ID,
    COALESCE(ce.AUDITOR_NAME, 'N/A') AS ASSOCIATE_NAME,
    COALESCE(ce.PLATFORM, 'N/A') AS PLATFORM_SOURCE_SYSTEM,
    COALESCE(aa.ERRORCATEGORYTYPE, 'N/A') AS ERROR_TYPE,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS ERROR_CATEGORY,
    COALESCE(aa.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME,
    COALESCE(ce.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ce.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM completion_event ce
INNER JOIN deduped_audit_activity aa
    ON ce.PYID = aa.CASEID
   AND aa.rn = 1
ORDER BY DATE(ce.completion_ts) DESC, ce.PYID ASC
LIMIT 20 OFFSET 0
```

---

### 3. REBUTTALS_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        AUDITOR_ID
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND AUDITOR_ID IN ('AG50550')
        AND AUDITOR_MGR_ID IN ('AC95624')
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS
FROM audit_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 4. REBUTTAL_PAGINATED_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        INTAKESOURCESYSTEM,
        PLATFORM,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
),
latest_rebuttal_cases AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        INTAKESOURCESYSTEM,
        PLATFORM,
        PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM audit_base
),
rebuttal_population AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        INTAKESOURCESYSTEM,
        PLATFORM
    FROM latest_rebuttal_cases
    WHERE rn = 1
      AND REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID IN ('AG50550')
      AND AUDITOR_MGR_ID IN ('AC95624')
),
completion_candidates AS (
    SELECT
        rp.PYID,
        rp.AUDITOR_ID,
        rp.AUDITOR_NAME,
        rp.LOB,
        rp.AUDIT_MONTH,
        rp.AUDIT_YEAR,
        rp.INTAKESOURCESYSTEM,
        rp.PLATFORM,
        a.PYSTATUSWORK AS completion_status,
        a.PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY rp.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXUPDATEDATETIME ASC
        ) AS rn
    FROM rebuttal_population rp
    INNER JOIN audit_base a
        ON rp.PYID = a.PYID
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_NAME,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        INTAKESOURCESYSTEM,
        PLATFORM,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    ce.PYID AS WORK_ITEM_ID,
    COALESCE(ce.INTAKESOURCESYSTEM, 'N/A') AS WORKTYPE_CATEGORY,
    CASE
        WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(ce.completion_status, 'N/A')
    END AS OUTCOME_STATUS,
    COALESCE(ce.LOB, 'N/A') AS LOB,
    ce.completion_ts AS RESOLVED_DATE,
    COALESCE(ce.AUDITOR_ID, 'N/A') AS DOMAIN_ID,
    COALESCE(ce.AUDITOR_NAME, 'N/A') AS ASSOCIATE_NAME,
    COALESCE(ce.PLATFORM, 'N/A') AS PLATFORM_SOURCE_SYSTEM,
    COALESCE(aa.ERRORCATEGORYTYPE, 'N/A') AS ERROR_TYPE,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS ERROR_CATEGORY,
    COALESCE(aa.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME,
    COALESCE(ce.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ce.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM completion_event ce
INNER JOIN deduped_audit_activity aa
    ON ce.PYID = aa.CASEID
   AND aa.rn = 1
ORDER BY DATE(ce.completion_ts) DESC, ce.PYID ASC
LIMIT 20 OFFSET 0
```

---

## rebuttals

**Number of Queries:** 8

### 1. ATA_REBUTTALS_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        
        AND LOB IN ('Commercial')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS ATA_REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_ata_cases_with_rebuttals
FROM ata_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 2. REBUTTALS_OVERTURN_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK,
        REBUTTALFLAG
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        PXCREATEDATETIME
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
        AND LOB IN ('Commercial')
        AND AUDITOR_ID IN ('AG50550')
        AND AUDITOR_MGR_ID IN ('AC95624')
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
),
rebuttal_outcome_deduped AS (
    SELECT
        CASEID,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND REBUTTALOUTCOME IS NOT NULL
)
SELECT
    COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS TOTAL_REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN ro.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS REBUTTALS_OVERTURNED,
    COUNT(DISTINCT CASE
        WHEN ro.REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS REBUTTALS_UPHELD,
    COALESCE(
        ROUND(
            (
                COUNT(DISTINCT CASE
                    WHEN ro.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                    THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
                END) * 100.0
            ) / NULLIF(
                COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY),
                0
            ),
            2
        ),
        0
    ) AS REBUTTAL_OVERTURN_PCT
FROM audit_filtered af
INNER JOIN audit_activity_deduped act
    ON af.PYID = act.CASEID
    AND act.rn = 1
LEFT JOIN rebuttal_outcome_deduped ro
    ON af.PYID = ro.CASEID
    AND ro.rn = 1
```

---

### 3. REBUTTALS_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        AUDITOR_ID
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
        AND LOB IN ('Commercial')
        AND AUDITOR_ID IN ('AG50550')
        AND AUDITOR_MGR_ID IN ('AC95624')
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS
FROM audit_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 4. REBUTTALS_TREND_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH grouping_logic AS (
    SELECT
        'monthly' AS grouping_type,
        'false' AS use_audit_period_grouping
),
audit_base AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK,
        REBUTTALFLAG
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        CASE UPPER(TRIM(AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        AND PXCREATEDATETIME >= '2026-07-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-07-29'::DATE)
        AND LOB IN ('Commercial')
        AND AUDITOR_ID IN ('AG50550')
        AND AUDITOR_MGR_ID IN ('AC95624')
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
),
rebuttal_outcome_deduped AS (
    SELECT
        CASEID,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND REBUTTALOUTCOME IS NOT NULL
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(af.PXCREATEDATETIME)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(af.PXCREATEDATETIME))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(af.AUDIT_YEAR), af.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(af.PXCREATEDATETIME))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(af.AUDIT_YEAR),
                CASE
                    WHEN af.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN af.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN af.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(af.PXCREATEDATETIME))

            ELSE DATE_TRUNC('year', DATE(af.PXCREATEDATETIME))
        END AS group_key,
        DATE(af.PXCREATEDATETIME) AS created_date,
        af.PYID,
        act.ERRORCATEGORYTYPE,
        act.ERRORCATEGORY,
        ro.REBUTTALOUTCOME
    FROM audit_filtered af
    CROSS JOIN grouping_logic g
    INNER JOIN audit_activity_deduped act
        ON af.PYID = act.CASEID
        AND act.rn = 1
    LEFT JOIN rebuttal_outcome_deduped ro
        ON af.PYID = ro.CASEID
        AND ro.rn = 1
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    COUNT(DISTINCT PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS OVERTURNED,
    COUNT(DISTINCT CASE
        WHEN REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS UPHELD,
    COALESCE(
        ROUND(
            (
                COUNT(DISTINCT CASE
                    WHEN REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                    THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
                END) * 100.0
            ) / NULLIF(
                COUNT(DISTINCT PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY),
                0
            ),
            2
        ),
        0
    ) AS REBUTTAL_OVERTURN_PCT,
    MIN(created_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
```

---

### 5. ATA_REBUTTALS_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        
        AND LOB IN ('Commercial')
        AND AUDIT_SUBJECT_ID IN ('AG50550')
        AND AUDIT_SUBJECT_MGR_ID IN ('AC95624')
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS ATA_REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_ata_cases_with_rebuttals
FROM ata_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 6. REBUTTALS_OVERTURN_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK,
        REBUTTALFLAG
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        PXCREATEDATETIME
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
        AND LOB IN ('Commercial')
        AND AUDITOR_ID IN ('AG50550')
        AND AUDITOR_MGR_ID IN ('AC95624')
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
),
rebuttal_outcome_deduped AS (
    SELECT
        CASEID,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND REBUTTALOUTCOME IS NOT NULL
)
SELECT
    COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS TOTAL_REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN ro.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS REBUTTALS_OVERTURNED,
    COUNT(DISTINCT CASE
        WHEN ro.REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS REBUTTALS_UPHELD,
    COALESCE(
        ROUND(
            (
                COUNT(DISTINCT CASE
                    WHEN ro.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                    THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
                END) * 100.0
            ) / NULLIF(
                COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY),
                0
            ),
            2
        ),
        0
    ) AS REBUTTAL_OVERTURN_PCT
FROM audit_filtered af
INNER JOIN audit_activity_deduped act
    ON af.PYID = act.CASEID
    AND act.rn = 1
LEFT JOIN rebuttal_outcome_deduped ro
    ON af.PYID = ro.CASEID
    AND ro.rn = 1
```

---

### 7. REBUTTALS_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        AUDITOR_ID
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
        AND LOB IN ('Commercial')
        AND AUDITOR_ID IN ('AG50550')
        AND AUDITOR_MGR_ID IN ('AC95624')
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS
FROM audit_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 8. REBUTTALS_TREND_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH grouping_logic AS (
    SELECT
        'monthly' AS grouping_type,
        'true' AS use_audit_period_grouping
),
audit_base AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK,
        REBUTTALFLAG
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        CASE UPPER(TRIM(AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
        AND LOB IN ('Commercial')
        AND AUDITOR_ID IN ('AG50550')
        AND AUDITOR_MGR_ID IN ('AC95624')
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
),
rebuttal_outcome_deduped AS (
    SELECT
        CASEID,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND REBUTTALOUTCOME IS NOT NULL
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(af.PXCREATEDATETIME)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(af.PXCREATEDATETIME))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(af.AUDIT_YEAR), af.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(af.PXCREATEDATETIME))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(af.AUDIT_YEAR),
                CASE
                    WHEN af.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN af.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN af.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(af.PXCREATEDATETIME))

            ELSE DATE_TRUNC('year', DATE(af.PXCREATEDATETIME))
        END AS group_key,
        DATE(af.PXCREATEDATETIME) AS created_date,
        af.PYID,
        act.ERRORCATEGORYTYPE,
        act.ERRORCATEGORY,
        ro.REBUTTALOUTCOME
    FROM audit_filtered af
    CROSS JOIN grouping_logic g
    INNER JOIN audit_activity_deduped act
        ON af.PYID = act.CASEID
        AND act.rn = 1
    LEFT JOIN rebuttal_outcome_deduped ro
        ON af.PYID = ro.CASEID
        AND ro.rn = 1
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    COUNT(DISTINCT PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS OVERTURNED,
    COUNT(DISTINCT CASE
        WHEN REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS UPHELD,
    COALESCE(
        ROUND(
            (
                COUNT(DISTINCT CASE
                    WHEN REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                    THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
                END) * 100.0
            ) / NULLIF(
                COUNT(DISTINCT PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY),
                0
            ),
            2
        ),
        0
    ) AS REBUTTAL_OVERTURN_PCT,
    MIN(created_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
```

---

## time_utilization

**Number of Queries:** 1

### 1. FUSE_TIME_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH associate_hierarchy AS (
    -- Get list of associates who reported to specified manager during the period
    SELECT DISTINCT
        PYRESOLVEDUSERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '2026-07-01' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND PYRESOLVEDUSERID IN ('AG50550')
      AND REPORTTOMANAGERID IN ('AC95624')
)
SELECT 
    -- Total Fuse Time Hours = Available Hours (Total System Time - Non Productive Time)
    ROUND((SUM(up.TOTALSYSTEMTIME) / 3600.0) - (SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0), 2) AS TOTAL_FUSE_TIME_HOURS,
    
    -- OHI Productive Time (from PRODUCTIVETIME column)
   
    ROUND(SUM(
        CASE 
            WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END
    ) / 3600.0, 2) AS OHI_PRODUCTIVE_TIME_HOURS,
    
    -- Non-Productive Time (using FUSE_NON_PRODUCTIVE_TIME)
    ROUND(SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0, 2) AS TOTAL_NON_PRODUCTIVE_HOURS,
    
    
    ROUND(
        (SUM(up.TOTALSYSTEMTIME) / 3600.0) - 
        ((SUM(
            CASE 
                WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                    (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
                ELSE 0
            END
        ) / 3600.0) + 
        (SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0)), 
    2) AS OTHER_TIME_HOURS,
    
    -- Percentages (for UI chart display)
    -- Productive %
    ROUND(
        SUM(CASE WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
            (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
             SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
             SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
        ELSE 0 END) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 2
    ) AS PRODUCTIVE_PCT,
    
    -- Non-Productive %
    ROUND(
        SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 2
    ) AS NON_PRODUCTIVE_PCT,
    
    -- Other time%
    ROUND(
        100.0 - 
        COALESCE(
            SUM(CASE WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0 END) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 0
        ) -
        COALESCE(
            SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 0
        ), 2
    ) AS OTHER_PCT
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE up  
INNER JOIN associate_hierarchy ah
    ON up.USERID = ah.PYRESOLVEDUSERID  
WHERE up.TOTALSYSTEMTIME IS NOT NULL
  AND LOGINDATE >= '2026-07-01' AND LOGINDATE < DATEADD(day, 1, '2026-07-29'::DATE)
```

---

## user_activity

**Number of Queries:** 4

### 1. AUDIT_TEAM_RANK_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH auditors AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        COALESCE(PYREPORTTO, 'NONE') AS manager_id,
        PYACCESSGROUP
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE UPPER(PYACCESSGROUP) IN ('COB:FRONTLINEAUDITOR', 'CLMSCCU:AUDITOR')
),
audit_base_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        AUDITCYCLETIME,
        ISATACASE
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND COALESCE(ISATACASE, 'N') = 'N'
),
completion_candidates_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY
                CASE
                    WHEN PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base_efficiency
    WHERE PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_candidates_efficiency
    WHERE rn = 1
),
filtered_completion_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        completion_ts,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM completion_event_efficiency
    WHERE 1 = 1
      AND completion_ts >= '2026-07-01' AND completion_ts < DATEADD(day, 1, '2026-07-29'::DATE)
),
first_positive_cycle_ts_efficiency AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.completion_ts,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion_efficiency c
    JOIN audit_base_efficiency a
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY c.PYID, c.AUDITOR_ID, c.completion_ts
),
cycle_time_at_first_positive AS (
    SELECT
        f.PYID,
        f.AUDITOR_ID,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts_efficiency f
    JOIN audit_base_efficiency a
        ON a.PYID = f.PYID
       AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY f.PYID, f.AUDITOR_ID
),
audit_cycle_time AS (
    SELECT
        AUDITOR_ID AS userid,
        AVG(AUDITCYCLETIME) AS avg_cycle_time_seconds,
        COUNT(PYID) AS total_audits
    FROM cycle_time_at_first_positive
    GROUP BY AUDITOR_ID
),
ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDITGOAL,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND AUDITGOAL > 0
),
first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),
first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),
completion_points_ata AS (
    SELECT
        PYID,
        completion_timestamp
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),
filtered_completion_ata AS (
    SELECT DISTINCT
        a.PYID,
        a.AUDIT_SUBJECT_ID,
        c.completion_timestamp,
        a.AUDIT_YEAR,
        a.AUDIT_MONTH
    FROM ata_filtered_records a
    JOIN completion_points_ata c
        ON a.PYID = c.PYID
    WHERE 1 = 1
      AND completion_timestamp >= '2026-07-01' AND completion_timestamp < DATEADD(day, 1, '2026-07-29'::DATE)
),
ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SUBJECT_ID,
        TRY_TO_DECIMAL(TRIM(a.AUDIT_SCORE)) AS AUDIT_SCORE,
        a.AUDITGOAL,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN filtered_completion_ata fc
        ON a.PYID = fc.PYID
    WHERE a.PXUPDATEDATETIME >= fc.completion_timestamp
),
ata_scores AS (
    SELECT
        AUDIT_SUBJECT_ID AS userid,
        AVG((AUDIT_SCORE / NULLIF(AUDITGOAL, 0)) * 100) AS avg_ata_score_pct,
        COUNT(PYID) AS ata_count
    FROM ata_scores_at_completion
    WHERE rn = 1
    GROUP BY AUDIT_SUBJECT_ID
),
auditor_scores AS (
    SELECT
        a.USERID,
        a.USERNAME,
        a.FIRSTNAME,
        a.LASTNAME,
        a.manager_id,
        a.PYACCESSGROUP,
        COALESCE(act.avg_cycle_time_seconds, 0) AS avg_cycle_time_seconds,
        COALESCE(act.total_audits, 0) AS total_audits,
        COALESCE(ata.avg_ata_score_pct, 0) AS avg_ata_score_pct,
        COALESCE(ata.ata_count, 0) AS ata_count,
        CASE
            WHEN act.avg_cycle_time_seconds > 0
            THEN (20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100
            ELSE 0
        END AS efficiency_score,
        CASE
            WHEN ata.avg_ata_score_pct > 0 AND act.avg_cycle_time_seconds > 0
            THEN ((20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100 + ata.avg_ata_score_pct) / 2
            WHEN act.avg_cycle_time_seconds > 0
            THEN (20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100
            ELSE 0
        END AS final_score
    FROM auditors a
    LEFT JOIN audit_cycle_time act
        ON a.USERID = act.userid
    LEFT JOIN ata_scores ata
        ON a.USERID = ata.userid
),
auditor_rankings AS (
    SELECT
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        manager_id,
        PYACCESSGROUP,
        final_score,
        RANK() OVER (PARTITION BY manager_id ORDER BY final_score DESC, USERID) AS team_rank,
        RANK() OVER (ORDER BY final_score DESC, USERID) AS dept_rank,
        avg_cycle_time_seconds,
        ROUND(avg_cycle_time_seconds / 60.0, 2) AS avg_cycle_time_minutes,
        total_audits,
        avg_ata_score_pct,
        ata_count,
        efficiency_score
    FROM auditor_scores
    WHERE final_score > 0
)
SELECT
    team_rank AS TEAMRANK
FROM auditor_rankings
WHERE USERID = 'AM62084'
```

---

### 2. USER_ACTIVITY_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
SELECT 
    DATE(LOGINTIME) as LOGINDATE,
    TO_CHAR(LOGINTIME, 'HH12:MI AM') || ' ET' as login_time,
    TO_CHAR(LOGOUTTIME, 'HH12:MI AM') || ' ET' as logout_time
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_ACTIVITY
WHERE DOMAINID = 'AM62084'
AND DATE(LOGINTIME) = CURRENT_DATE()
ORDER BY LOGINTIME ASC
```

---

### 3. AUDIT_TEAM_RANK_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
WITH auditors AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        COALESCE(PYREPORTTO, 'NONE') AS manager_id,
        PYACCESSGROUP
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE UPPER(PYACCESSGROUP) IN ('COB:FRONTLINEAUDITOR', 'CLMSCCU:AUDITOR')
),
audit_base_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        AUDITCYCLETIME,
        ISATACASE
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND COALESCE(ISATACASE, 'N') = 'N'
),
completion_candidates_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY
                CASE
                    WHEN PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base_efficiency
    WHERE PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_candidates_efficiency
    WHERE rn = 1
),
filtered_completion_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        completion_ts,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM completion_event_efficiency
    WHERE 1 = 1
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
),
first_positive_cycle_ts_efficiency AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.completion_ts,
        MIN(a.PXUPDATEDATETIME) AS cycle_ts
    FROM filtered_completion_efficiency c
    JOIN audit_base_efficiency a
        ON a.PYID = c.PYID
    WHERE a.PXUPDATEDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY c.PYID, c.AUDITOR_ID, c.completion_ts
),
cycle_time_at_first_positive AS (
    SELECT
        f.PYID,
        f.AUDITOR_ID,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts_efficiency f
    JOIN audit_base_efficiency a
        ON a.PYID = f.PYID
       AND a.PXUPDATEDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY f.PYID, f.AUDITOR_ID
),
audit_cycle_time AS (
    SELECT
        AUDITOR_ID AS userid,
        AVG(AUDITCYCLETIME) AS avg_cycle_time_seconds,
        COUNT(PYID) AS total_audits
    FROM cycle_time_at_first_positive
    GROUP BY AUDITOR_ID
),
ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDITGOAL,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND AUDITGOAL > 0
),
first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),
first_resolved AS (
    SELECT
        PYID,
        MIN(PXUPDATEDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),
completion_points_ata AS (
    SELECT
        PYID,
        completion_timestamp
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),
filtered_completion_ata AS (
    SELECT DISTINCT
        a.PYID,
        a.AUDIT_SUBJECT_ID,
        c.completion_timestamp,
        a.AUDIT_YEAR,
        a.AUDIT_MONTH
    FROM ata_filtered_records a
    JOIN completion_points_ata c
        ON a.PYID = c.PYID
    WHERE 1 = 1
      AND ((UPPER(TRIM(AUDIT_MONTH)) = UPPER('May') AND TRIM(AUDIT_YEAR) = '2026') OR (UPPER(TRIM(AUDIT_MONTH)) = UPPER('June') AND TRIM(AUDIT_YEAR) = '2026'))
),
ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SUBJECT_ID,
        TRY_TO_DECIMAL(TRIM(a.AUDIT_SCORE)) AS AUDIT_SCORE,
        a.AUDITGOAL,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN filtered_completion_ata fc
        ON a.PYID = fc.PYID
    WHERE a.PXUPDATEDATETIME >= fc.completion_timestamp
),
ata_scores AS (
    SELECT
        AUDIT_SUBJECT_ID AS userid,
        AVG((AUDIT_SCORE / NULLIF(AUDITGOAL, 0)) * 100) AS avg_ata_score_pct,
        COUNT(PYID) AS ata_count
    FROM ata_scores_at_completion
    WHERE rn = 1
    GROUP BY AUDIT_SUBJECT_ID
),
auditor_scores AS (
    SELECT
        a.USERID,
        a.USERNAME,
        a.FIRSTNAME,
        a.LASTNAME,
        a.manager_id,
        a.PYACCESSGROUP,
        COALESCE(act.avg_cycle_time_seconds, 0) AS avg_cycle_time_seconds,
        COALESCE(act.total_audits, 0) AS total_audits,
        COALESCE(ata.avg_ata_score_pct, 0) AS avg_ata_score_pct,
        COALESCE(ata.ata_count, 0) AS ata_count,
        CASE
            WHEN act.avg_cycle_time_seconds > 0
            THEN (20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100
            ELSE 0
        END AS efficiency_score,
        CASE
            WHEN ata.avg_ata_score_pct > 0 AND act.avg_cycle_time_seconds > 0
            THEN ((20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100 + ata.avg_ata_score_pct) / 2
            WHEN act.avg_cycle_time_seconds > 0
            THEN (20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100
            ELSE 0
        END AS final_score
    FROM auditors a
    LEFT JOIN audit_cycle_time act
        ON a.USERID = act.userid
    LEFT JOIN ata_scores ata
        ON a.USERID = ata.userid
),
auditor_rankings AS (
    SELECT
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        manager_id,
        PYACCESSGROUP,
        final_score,
        RANK() OVER (PARTITION BY manager_id ORDER BY final_score DESC, USERID) AS team_rank,
        RANK() OVER (ORDER BY final_score DESC, USERID) AS dept_rank,
        avg_cycle_time_seconds,
        ROUND(avg_cycle_time_seconds / 60.0, 2) AS avg_cycle_time_minutes,
        total_audits,
        avg_ata_score_pct,
        ata_count,
        efficiency_score
    FROM auditor_scores
    WHERE final_score > 0
)
SELECT
    team_rank AS TEAMRANK
FROM auditor_rankings
WHERE USERID = 'AM62084'
```

---

### 4. USER_ACTIVITY_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi"
}
```

**SQL Query:**

```sql
SELECT 
    DATE(LOGINTIME) as LOGINDATE,
    TO_CHAR(LOGINTIME, 'HH12:MI AM') || ' ET' as login_time,
    TO_CHAR(LOGOUTTIME, 'HH12:MI AM') || ' ET' as logout_time
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_ACTIVITY
WHERE DOMAINID = 'AM62084'
AND DATE(LOGINTIME) = CURRENT_DATE()
ORDER BY LOGINTIME ASC
```

---

## work_items_drilldown

**Number of Queries:** 2

### 1. WORK_ITEMS_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        REPORTTOMANAGERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        REPORTTOMANAGERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND PYRESOLVEDUSERID IN ('AG50550')
      AND REPORTTOMANAGERID IN ('AC95624')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM filtered_inventory
```

---

### 2. WORK_ITEMS_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AM62084",
  "start_date": "2026-07-01",
  "end_date": "2026-07-29",
  "audit_periods": [],
  "lob": [
    "Commercial",
    "Medicaid",
    "Medicare"
  ],
  "manager_ids": [
    "AC95624"
  ],
  "auditor_ids": [
    "AG50550"
  ],
  "session_id": "session_1785331397538_6yx5jrghi",
  "sort_by": "resolved_date",
  "sort_direction": "desc",
  "page": 1,
  "page_size": 20
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        CYCLE_TIME,
        PYSTATUSWORK,
        LOB,
        INVNTRY_TYPE,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PLATFORM,
        REPORTTOMANAGERID,
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        CYCLE_TIME,
        PYSTATUSWORK,
        LOB,
        INVNTRY_TYPE,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PLATFORM,
        REPORTTOMANAGERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-07-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-29'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND PYRESOLVEDUSERID IN ('AG50550')
      AND REPORTTOMANAGERID IN ('AC95624')
),
user_profile_deduped AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYID,
    i.INTAKESOURCESYSTEM,
    i.CYCLE_TIME,
    i.PYSTATUSWORK,
    i.LOB,
    i.PYRESOLVEDTIMESTAMP,
    i.PYRESOLVEDUSERID,
    u.USERNAME AS ASSOCIATE_NAME,
    i.PLATFORM,
    i.INVNTRY_TYPE
FROM filtered_inventory i
LEFT JOIN user_profile_deduped u ON i.PYRESOLVEDUSERID = u.USERID AND u.rn = 1
ORDER BY DATE(i.PYRESOLVEDTIMESTAMP) DESC, i.PYID ASC
LIMIT 20 OFFSET 0
```

---

