# Performance IQ FL Auditor API - SQL Documentation

**Generated:** 2026-06-19 14:52:10

**Total APIs:** 13
**Total SQL Queries:** 25

## Table of Contents

1. [ata_score_drilldown](#ata-score-drilldown) (2 queries)
2. [ata_score_gauge](#ata-score-gauge) (2 queries)
3. [audit_cycle_time_gauge](#audit-cycle-time-gauge) (2 queries)
4. [complete_audit_count_drilldown](#complete-audit-count-drilldown) (2 queries)
5. [fuse_time_drilldown](#fuse-time-drilldown) (2 queries)
6. [header_kpis](#header-kpis) (5 queries)
7. [lob_list](#lob-list) (1 queries)
8. [rebuttal_count_drilldown](#rebuttal-count-drilldown) (2 queries)
9. [rebuttals](#rebuttals) (2 queries)
10. [time_utilization](#time-utilization) (1 queries)
11. [user_activity](#user-activity) (2 queries)
12. [work_items_drilldown](#work-items-drilldown) (2 queries)

---

## ata_score_drilldown

**Number of Queries:** 2

### 1. AUDIT_SCORE_COUNT_QUERY

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT 
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND PXCREATEDATETIME >= '2026-03-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-31'::DATE)
      AND AUDIT_SUBJECT_ID = 'AI06493'
)
SELECT 
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS TOTAL_COUNT,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS TARGET_AUDIT_COUNT
FROM ata_deduped
WHERE rn = 1
```

---

### 2. AUDIT_SCORE_PAGINATED_QUERY

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        AUDIT_SUBJECT_ID,
        LOB,
        PLATFORM,
        AUDITCYCLETIME,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        PXCREATEDATETIME::DATE as audit_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND PXCREATEDATETIME >= '2026-03-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-31'::DATE)
      AND AUDIT_SUBJECT_ID = 'AI06493'
),
deduped_user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
),
rebuttal_outcome_deduped AS (
    SELECT
        CASEID,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE REBUTTALOUTCOME IS NOT NULL
)
SELECT 
    ata.PYID,
    COALESCE(ata.INTAKESOURCESYSTEM, 'N/A') AS INTAKESOURCESYSTEM,
    ata.PYSTATUSWORK,
    ata.LOB,
    ata.audit_date,
    ata.AUDIT_SUBJECT_ID AS AUDITOR_ID,
    TO_NUMBER(TRIM(ata.AUDIT_SCORE)) AS AUDIT_SCORE,
    ata.PLATFORM,
    ata.TARGET_AUDIT,
    ata.AUDITCYCLETIME,
    ata.INVNTRY_TYPE,
    COALESCE(u.USERNAME, 'N/A') AS AUDITOR_NAME,
    COALESCE(ro.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME
FROM ata_deduped ata
INNER JOIN deduped_user_profile u
    ON ata.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
LEFT JOIN rebuttal_outcome_deduped ro
    ON ata.PYID = ro.CASEID
    AND ro.rn = 1
WHERE ata.rn = 1
ORDER BY ata.audit_date DESC
LIMIT 20 OFFSET 0
```

---

## ata_score_gauge

**Number of Queries:** 2

### 1. ATA_SCORE_QUERY

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT 
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND PXCREATEDATETIME >= '2026-03-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-31'::DATE)
      AND AUDIT_SUBJECT_ID = 'AI06493'
)
SELECT 
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_deduped
WHERE rn = 1
```

---

### 2. ATA_SCORE_TREND_QUERY

**SQL Query:**

```sql
WITH date_range AS (
    SELECT
        DATEDIFF(day, '2026-03-01'::DATE, '2026-03-31'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
ata_deduped AS (
    SELECT 
        PYID,
        AUDIT_SCORE,
        PXCREATEDATETIME::DATE AS created_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND PXCREATEDATETIME >= '2026-03-01'
      AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-31'::DATE)
      AND AUDIT_SUBJECT_ID = 'AI06493'
),
audit_data AS (
    SELECT 
        created_date,
        TO_NUMBER(TRIM(AUDIT_SCORE)) AS AUDIT_SCORE
    FROM ata_deduped
    WHERE rn = 1
),
grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE 
            WHEN g.grouping_type = 'daily' THEN a.created_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.created_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.created_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.created_date)
            ELSE DATE_TRUNC('year', a.created_date)
        END AS group_key,
        a.created_date,
        a.AUDIT_SCORE
    FROM audit_data a
    CROSS JOIN grouping_logic g
)
SELECT 
    CASE 
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(group_key, 'MM/DD') || ' - ' || 
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(*) AS total_audits,
    MIN(created_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

## audit_cycle_time_gauge

**Number of Queries:** 2

### 1. AUDIT_CYCLE_TIME_QUERY

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        a.PYID,
        a.AUDITCYCLETIME,
        a.PYRESOLVEDTIMESTAMP,
        a.AUDITOR_ID,
        DATE(a.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY a.PYID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND a.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND PYRESOLVEDTIMESTAMP >= '2026-03-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND a.AUDITCYCLETIME IS NOT NULL
        AND AUDITOR_ID = 'AI06493'
)
SELECT
    COUNT(DISTINCT a.PYID) AS total_resolved_audits,
    AVG(a.AUDITCYCLETIME / 60.0) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM audit_deduped a
WHERE a.rn = 1
```

---

### 2. AUDIT_CYCLE_TIME_TREND_QUERY

**SQL Query:**

```sql
WITH date_range AS (
    SELECT
        DATEDIFF(day, '2026-03-01'::DATE, '2026-03-31'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
audit_deduped AS (
    SELECT
        a.PYID,
        a.AUDITCYCLETIME,
        DATE(a.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY a.PYID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND a.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND a.PYRESOLVEDTIMESTAMP >= '2026-03-01'
        AND a.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND a.AUDITCYCLETIME IS NOT NULL
        AND a.AUDITOR_ID = 'AI06493'
),
audit_filtered AS (
    SELECT
        PYID,
        AUDITCYCLETIME,
        resolved_date
    FROM audit_deduped
    WHERE rn = 1
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN a.resolved_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.resolved_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.resolved_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.resolved_date)
            ELSE DATE_TRUNC('year', a.resolved_date)
        END AS group_key,
        a.resolved_date,
        a.AUDITCYCLETIME,
        a.PYID
    FROM audit_filtered a
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    AVG(AUDITCYCLETIME / 60.0) AS avg_cycle_time_minutes,
    COUNT(DISTINCT PYID) AS total_audits,
    MIN(resolved_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

## complete_audit_count_drilldown

**Number of Queries:** 2

### 1. COMPLETED_AUDIT_COUNT_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-AutoCloseLink', 'Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID = 'AI06493'
),
deduped_user_profile AS (
    SELECT
        USERID,
        PYREPORTTO,
        USERID_ROLE,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM deduped_audit a
INNER JOIN deduped_user_profile u
    ON a.AUDITOR_ID = u.USERID
WHERE a.rn = 1
  AND u.rn = 1
```

---

### 2. COMPLETED_AUDIT_COUNT_PAGINATED_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        PYRESOLVEDTIMESTAMP,
        AUDITOR_ID,
        AUDITCYCLETIME,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-AutoCloseLink', 'Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID = 'AI06493'
),
deduped_user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT 
    a.PYID AS work_item,
    COALESCE(a.INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(a.AUDITCYCLETIME::VARCHAR, '0') AS audit_cycle_time,
    COALESCE(a.PYSTATUSWORK, 'N/A') AS audit_resolved_status,
    COALESCE(a.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(a.LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(a.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(u.USERNAME, 'N/A') AS auditor_name,
    COALESCE(a.PLATFORM, 'N/A') AS platform_source_system
FROM deduped_audit a
INNER JOIN deduped_user_profile u
    ON a.AUDITOR_ID = u.USERID
WHERE a.rn = 1
  AND u.rn = 1
ORDER BY a.PYRESOLVEDTIMESTAMP DESC
LIMIT 20 OFFSET 0
```

---

## fuse_time_drilldown

**Number of Queries:** 2

### 1. FUSE_TIME_COUNT_QUERY

**SQL Query:**

```sql
SELECT COUNT(*) as TOTAL_COUNT
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u
WHERE 1=1
    AND u.LOGINDATE >= '2026-03-01' AND u.LOGINDATE < DATEADD(day, 1, '2026-03-31'::DATE)
    AND u.USERID = 'AI06493'
```

---

### 2. FUSE_TIME_PAGINATED_QUERY

**SQL Query:**

```sql
SELECT 
    u.USERNAME,
    u.USERID,
    u.LOGINDATE,
    u.FIRSTLOGINTIME,
    u.LASTLOGOUTTIME,
    u.TOTALSYSTEMTIME,
    u.FUSE_NON_PRODUCTIVE_TIME,
    u.PRODUCTIVETIME,
    -- Calculate Other Time: Total - Productive - Non-Productive
    (COALESCE(u.TOTALSYSTEMTIME, 0) - 
    (COALESCE(
        CASE 
            WHEN u.PRODUCTIVETIME IS NOT NULL AND u.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END, 0
    ) + 
    COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0))) AS OTHER_TIME
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u
WHERE 1=1
    AND u.LOGINDATE >= '2026-03-01' AND u.LOGINDATE < DATEADD(day, 1, '2026-03-31'::DATE)
    AND u.USERID = 'AI06493'
ORDER BY u.LOGINDATE DESC
LIMIT 20 OFFSET 0
```

---

## header_kpis

**Number of Queries:** 5

### 1. ATA_AUDIT_SCORE_QUERY

**SQL Query:**

```sql
WITH ata_deduped AS (
    SELECT 
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\.[0-9]+)?$')
      AND PXCREATEDATETIME >= '2026-03-01' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-31'::DATE)
      AND AUDIT_SUBJECT_ID = 'AI06493'
)
SELECT 
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_deduped
WHERE rn = 1
```

---

### 2. AUDIT_CYCLE_TIME_QUERY

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        a.PYID,
        a.AUDITCYCLETIME,
        a.AUDITOR_ID,
        DATE(a.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY a.PYID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND a.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND PYRESOLVEDTIMESTAMP >= '2026-03-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND a.AUDITCYCLETIME IS NOT NULL
        AND AUDITOR_ID = 'AI06493'
)
SELECT
    COUNT(DISTINCT a.PYID) AS total_resolved_audits,
    ROUND(AVG(a.AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM audit_deduped a
WHERE a.rn = 1
```

---

### 3. COMPLETED_AUDIT_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-AutoCloseLink', 'Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID = 'AI06493'
),
deduped_user_profile AS (
    SELECT
        USERID,
        PYREPORTTO,
        USERID_ROLE,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM deduped_audit a
INNER JOIN deduped_user_profile u
    ON a.AUDITOR_ID = u.USERID
WHERE a.rn = 1
  AND u.rn = 1
```

---

### 4. REBUTTALS_QUERY

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND pxcreatedatetime IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID = 'AI06493'
),
audit_filtered AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID
    FROM audit_deduped a
    WHERE a.rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT
FROM audit_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 5. WORK_ITEMS_COMPLETED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        a.PYID,
        a.PYRESOLVEDUSERID,
        DATE(a.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY a.PYID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE a
    WHERE a.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND a.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND PYRESOLVEDTIMESTAMP >= '2026-03-01' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND a.PYRESOLVEDUSERID = 'AI06493'
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped
WHERE rn = 1
```

---

## lob_list

**Number of Queries:** 1

### 1. FL_AUDITOR_LOB_QUERY

**SQL Query:**

```sql
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    AND PYRESOLVEDUSERID = 'AI06493'
UNION
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    AND PYRESOLVEDUSERID = 'AI06493'
ORDER BY LOB
```

---

## rebuttal_count_drilldown

**Number of Queries:** 2

### 1. REBUTTAL_COUNT_QUERY

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND pxcreatedatetime IS NOT NULL
      AND pxcreatedatetime >= '2026-03-01' AND pxcreatedatetime < DATEADD(day, 1, '2026-03-31'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID = 'AI06493'
),
audit_filtered AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID
    FROM audit_deduped a
    WHERE a.rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT
FROM audit_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 2. REBUTTAL_PAGINATED_QUERY

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDITOR_ID,
        INTAKESOURCESYSTEM,
        PLATFORM,
        PYSTATUSWORK,
        pxcreatedatetime,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND pxcreatedatetime IS NOT NULL
      AND pxcreatedatetime >= '2026-03-01' AND pxcreatedatetime < DATEADD(day, 1, '2026-03-31'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID = 'AI06493'
),
audit_filtered AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.INTAKESOURCESYSTEM,
        a.PLATFORM,
        a.PYSTATUSWORK,
        a.LOB,
        a.PYRESOLVEDTIMESTAMP,
        a.pxcreatedatetime
    FROM audit_deduped a
    WHERE a.rn = 1
),
rebuttal_details AS (
    SELECT
        act.CASEID,
        act.ERRORCATEGORY,
        act.ERRORCATEGORYTYPE,
        act.REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY act.CASEID, act.ERRORCATEGORYTYPE, act.ERRORCATEGORY
            ORDER BY act.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY act
    WHERE act.CASEID LIKE 'AUD%'
      AND act.ERRORCATEGORYTYPE IS NOT NULL
      AND act.ERRORCATEGORY IS NOT NULL
),
user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    af.PYID AS WORK_ITEM_ID,
    COALESCE(af.INTAKESOURCESYSTEM, 'N/A') AS WORKTYPE_CATEGORY,
    COALESCE(af.PYSTATUSWORK, 'N/A') AS OUTCOME_STATUS,
    COALESCE(af.LOB, 'N/A') AS LOB,
    af.PYRESOLVEDTIMESTAMP AS RESOLVED_DATE,
    COALESCE(af.AUDITOR_ID, 'N/A') AS DOMAIN_ID,
    COALESCE(u.USERNAME, 'N/A') AS ASSOCIATE_NAME,
    COALESCE(af.PLATFORM, 'N/A') AS PLATFORM_SOURCE_SYSTEM,
    COALESCE(rd.ERRORCATEGORY, 'N/A') AS ERROR_CATEGORY,
    COALESCE(rd.ERRORCATEGORYTYPE, 'N/A') AS ERROR_TYPE,
    COALESCE(rd.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME
FROM audit_filtered af
INNER JOIN rebuttal_details rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
LEFT JOIN user_profile u
    ON af.AUDITOR_ID = u.USERID
    AND u.rn = 1
ORDER BY af.pxcreatedatetime DESC
LIMIT 20 OFFSET 0
```

---

## rebuttals

**Number of Queries:** 2

### 1. REBUTTALS_QUERY

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND pxcreatedatetime IS NOT NULL
      AND pxcreatedatetime >= '2026-03-01' AND pxcreatedatetime < DATEADD(day, 1, '2026-03-31'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
      AND AUDITOR_ID = 'AI06493'
),
audit_filtered AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID
    FROM audit_deduped a
    WHERE a.rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT
FROM audit_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 2. REBUTTALS_TREND_QUERY

**SQL Query:**

```sql
WITH date_range AS (
    SELECT
        DATEDIFF(day, '2026-03-01'::DATE, '2026-03-31'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
audit_deduped AS (
    SELECT 
        PYID,
        pxcreatedatetime,
        AUDITOR_ID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND AUDITOR_ID = 'AI06493'
      AND pxcreatedatetime >= '2026-03-01'
      AND pxcreatedatetime < DATEADD(day, 1, '2026-03-31'::DATE)
      AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
),
audit_filtered AS (
    SELECT
        a.PYID,
        a.pxcreatedatetime
    FROM audit_deduped a
    WHERE a.rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
rebuttal_outcome_deduped AS (
    SELECT
        CASEID,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE REBUTTALOUTCOME IS NOT NULL
),
grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE 
            WHEN g.grouping_type = 'daily' THEN af.pxcreatedatetime::DATE
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', af.pxcreatedatetime)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', af.pxcreatedatetime)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', af.pxcreatedatetime)
            ELSE DATE_TRUNC('year', af.pxcreatedatetime)
        END AS group_key,
        COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS rebuttals,
        COUNT(DISTINCT CASE 
            WHEN ro.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
            THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
        END) AS overturned,
        COUNT(DISTINCT CASE 
            WHEN ro.REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
            THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
        END) AS upheld
    FROM audit_filtered af
    CROSS JOIN grouping_logic g
    INNER JOIN audit_activity_deduped act
        ON af.PYID = act.CASEID
        AND act.rn = 1
    LEFT JOIN rebuttal_outcome_deduped ro
        ON af.PYID = ro.CASEID
        AND ro.rn = 1
    GROUP BY g.grouping_type, 
        CASE 
            WHEN g.grouping_type = 'daily' THEN af.pxcreatedatetime::DATE
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', af.pxcreatedatetime)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', af.pxcreatedatetime)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', af.pxcreatedatetime)
            ELSE DATE_TRUNC('year', af.pxcreatedatetime)
        END
)
SELECT 
    CASE 
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(group_key, 'MM/DD') || ' - ' || 
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    rebuttals,
    overturned,
    upheld,
    COALESCE(
        ROUND(
            (overturned * 100.0) / NULLIF(rebuttals, 0),
            2
        ),
        0
    ) AS rebuttal_overturn_pct,
    group_key AS sort_date
FROM grouped_data
ORDER BY sort_date
```

---

## time_utilization

**Number of Queries:** 1

### 1. FUSE_TIME_QUERY

**SQL Query:**

```sql
SELECT 
    -- Total Fuse Time
    ROUND(SUM(TOTALSYSTEMTIME) / 3600.0, 2) AS TOTAL_FUSE_TIME_HOURS,
    
    -- OHI Productive Time (from PRODUCTIVETIME column)
    -- Convert HH:MM:SS string format to hours
    ROUND(SUM(
        CASE 
            WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END
    ) / 3600.0, 2) AS OHI_PRODUCTIVE_TIME_HOURS,
    
    -- Non-Productive Time (using FUSE_NON_PRODUCTIVE_TIME)
    ROUND(SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0, 2) AS TOTAL_NON_PRODUCTIVE_HOURS,
    
    -- Other Time (calculated as Total - (Productive + Non-Productive))
    ROUND(
        (SUM(TOTALSYSTEMTIME) / 3600.0) - 
        ((SUM(
            CASE 
                WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                    (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                     SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                     SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
                ELSE 0
            END
        ) / 3600.0) + 
        (SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0)), 
    2) AS OTHER_TIME_HOURS,
    
    -- Percentages (for UI chart display)
    ROUND(
        SUM(CASE WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
            (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
             SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
             SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
        ELSE 0 END) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 2
    ) AS PRODUCTIVE_PCT,
    
    ROUND(
        SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 2
    ) AS NON_PRODUCTIVE_PCT,
    
    ROUND(
        100.0 - 
        COALESCE(
            SUM(CASE WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0 END) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 0
        ) -
        COALESCE(
            SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 0
        ), 2
    ) AS OTHER_PCT

FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE TOTALSYSTEMTIME IS NOT NULL
AND LOGINDATE >= '2026-03-01' AND LOGINDATE < DATEADD(day, 1, '2026-03-31'::DATE)
AND USERID = 'AI06493'
```

---

## user_activity

**Number of Queries:** 2

### 1. AUDIT_TEAM_RANK_QUERY

**SQL Query:**

```sql
WITH 

config AS (
    SELECT 
        CURRENT_DATE() AS calculation_date,
        '2026-03-01'::DATE AS from_date,
        '2026-03-31'::DATE AS to_date,
        20.0 AS productivity_goal_minutes  -- Fixed RE Time goal for auditors
),
-- =====================================================
-- Get All Auditors
-- =====================================================
auditors AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        COALESCE(PYREPORTTO, 'NONE') AS manager_id,
        PYACCESSGROUP
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE UPPER(PYACCESSGROUP) IN ('COB:FRONTLINEAUDITOR', 'CLMSCCU:AUDITOR')


),
-- =====================================================
-- Efficiency Component: Audit Cycle Time
-- =====================================================
audit_cycle_time AS (
    SELECT 
        AUDITOR_ID AS userid,
        AVG(AUDITCYCLETIME) AS avg_cycle_time_minutes,
        COUNT(PYID) AS total_audits
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    CROSS JOIN config
    WHERE DATE(PYRESOLVEDTIMESTAMP) BETWEEN from_date AND to_date
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND AUDITCYCLETIME IS NOT NULL
      AND AUDITCYCLETIME > 0
      -- Exclude ATA cases from efficiency calculation
      AND COALESCE(ISATACASE, 'N') = 'N'
    GROUP BY AUDITOR_ID
),
-- =====================================================
-- Quality Component: ATA Score (Audit-the-Auditor)
-- =====================================================
ata_scores AS (
    SELECT 
        AUDIT_SUBJECT_ID AS userid,
        AVG((AUDIT_SCORE / NULLIF(AUDITGOAL, 0)) * 100) AS avg_ata_score_pct,
        COUNT(PYID) AS ata_count
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    CROSS JOIN config
    WHERE DATE(PYRESOLVEDTIMESTAMP) BETWEEN from_date AND to_date
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND ISATACASE = 'Y'
      AND AUDIT_SCORE IS NOT NULL
      AND AUDITGOAL > 0
    GROUP BY AUDIT_SUBJECT_ID
),
-- =====================================================
-- Calculate Final Scores
-- =====================================================
auditor_scores AS (
    SELECT 
        a.USERID,
        a.USERNAME,
        a.FIRSTNAME,
        a.LASTNAME,
        a.manager_id,
        a.PYACCESSGROUP,


        -- Efficiency metrics
        COALESCE(act.avg_cycle_time_minutes, 0) AS avg_cycle_time_minutes,
        COALESCE(act.total_audits, 0) AS total_audits,


        -- Quality metrics
        COALESCE(ata.avg_ata_score_pct, 0) AS avg_ata_score_pct,
        COALESCE(ata.ata_count, 0) AS ata_count,


        -- Efficiency Score: (20 minutes / Actual Cycle Time) × 100
        CASE 
            WHEN act.avg_cycle_time_minutes > 0
            THEN (productivity_goal_minutes / act.avg_cycle_time_minutes) * 100
            ELSE 0
        END AS efficiency_score,


        -- Final Score Calculation
        CASE 
            -- If ATA Score available: (Efficiency + ATA) / 2
            WHEN ata.avg_ata_score_pct > 0 AND act.avg_cycle_time_minutes > 0
            THEN (((productivity_goal_minutes / act.avg_cycle_time_minutes) * 100) + ata.avg_ata_score_pct) / 2


            -- If no ATA Score: Efficiency only
            WHEN act.avg_cycle_time_minutes > 0
            THEN (productivity_goal_minutes / act.avg_cycle_time_minutes) * 100


            -- No audit activity
            ELSE 0
        END AS final_score


    FROM auditors a
    LEFT JOIN audit_cycle_time act ON a.USERID = act.userid
    LEFT JOIN ata_scores ata ON a.USERID = ata.userid
    CROSS JOIN config
),
-- =====================================================
-- Calculate Rankings
-- =====================================================
auditor_rankings AS (
    SELECT 
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        manager_id,
        PYACCESSGROUP,
        final_score,


        -- Team Rank: Rank within manager's team
        RANK() OVER (PARTITION BY manager_id ORDER BY final_score DESC, USERID) AS team_rank,


        -- Department Rank: Rank across all auditors
        RANK() OVER (ORDER BY final_score DESC, USERID) AS dept_rank,


        -- Supporting metrics
        avg_cycle_time_minutes,
        total_audits,
        avg_ata_score_pct,
        ata_count,
        efficiency_score,


        -- Date context
        (SELECT from_date FROM config) AS rank_from_date,
        (SELECT to_date FROM config) AS rank_to_date,
        (SELECT calculation_date FROM config) AS calculation_date


    FROM auditor_scores
    WHERE final_score > 0  -- Only include auditors with activity
)
-- =====================================================
-- Final Output
-- =====================================================
SELECT 
    TEAM_RANK AS TEAMRANK
FROM auditor_rankings
WHERE USERID = 'AI06493'
```

---

### 2. USER_ACTIVITY_QUERY

**SQL Query:**

```sql
SELECT 
    DATE(LOGINTIME) as LOGINDATE,
    TO_CHAR(LOGINTIME, 'HH12:MI AM') || ' ET' as login_time,
    TO_CHAR(LOGOUTTIME, 'HH12:MI AM') || ' ET' as logout_time
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_ACTIVITY
WHERE DOMAINID = 'AI06493'
AND DATE(LOGINTIME) = CURRENT_DATE()
ORDER BY LOGINTIME ASC
```

---

## work_items_drilldown

**Number of Queries:** 2

### 1. WORK_ITEMS_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        i.PYID,
        i.PYRESOLVEDUSERID,
        DATE(i.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY i.PYID ORDER BY i.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE i.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND i.PYRESOLVEDTIMESTAMP >= '2026-03-01' AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND i.PYRESOLVEDUSERID = 'AI06493'
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped
WHERE rn = 1
```

---

### 2. WORK_ITEMS_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        i.PYID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.PYSTATUSWORK,
        i.LOB,
        i.INVNTRY_TYPE,
        i.PYRESOLVEDTIMESTAMP,
        i.PYRESOLVEDUSERID,
        i.PLATFORM,
        i.RETIME,
        ROW_NUMBER() OVER (PARTITION BY i.PYID ORDER BY i.RETIME DESC NULLS LAST, i.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE i.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND i.PYRESOLVEDTIMESTAMP >= '2026-03-01' AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-31'::DATE)
        AND LOB IN ('Commercial', 'Medicaid', 'Medicare')
        AND i.PYRESOLVEDUSERID = 'AI06493'
),
user_profile_deduped AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYID,
    i.INTAKESOURCESYSTEM,
    i.CYCLE_TIME,
    i.PYSTATUSWORK,
    i.LOB,
    i.PYRESOLVEDTIMESTAMP,
    i.PYRESOLVEDUSERID,
    u.USERNAME AS ASSOCIATE_NAME,
    i.PLATFORM,
    i.INVNTRY_TYPE
FROM invntry_deduped i
LEFT JOIN user_profile_deduped u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT 20 OFFSET 0
```

---

