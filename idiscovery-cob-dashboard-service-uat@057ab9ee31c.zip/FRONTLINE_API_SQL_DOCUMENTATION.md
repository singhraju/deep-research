# Performance IQ Frontline API - SQL Documentation

**Generated:** 2026-07-31 16:54:46

**Total APIs:** 11
**Total SQL Queries:** 31

## Table of Contents

1. [audit_error_drilldown](#audit-error-drilldown) (4 queries)
2. [audit_score_gauge](#audit-score-gauge) (4 queries)
3. [auditscore_drilldown](#auditscore-drilldown) (4 queries)
4. [fusetime_drilldown](#fusetime-drilldown) (2 queries)
5. [production_pct_drilldown](#production-pct-drilldown) (3 queries)
6. [production_percentage_gauge](#production-percentage-gauge) (2 queries)
7. [user_activity](#user-activity) (3 queries)
8. [user_metrics](#user-metrics) (6 queries)
9. [workitems_drilldown](#workitems-drilldown) (3 queries)

---

## audit_error_drilldown

**Number of Queries:** 4

### 1. AUDIT_ERROR_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "audit_error",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "date_assessed",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY i.PYID
        ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        PYRESOLVEDTIMESTAMP
    FROM latest_inventory
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND UPPER(TRIM(PYRESOLVEDUSERID)) = 'AG01440'
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
final_base AS (
    SELECT
        i.ASSOCIATE_ID,
        i.ORIGINAL_OHI_CASE_ID,
        i.PYRESOLVEDTIMESTAMP,
        ap.AUDIT_CASE_ID,
        ap.AUDIT_CREATE_TIMESTAMP,
        ap.AUDIT_UPDATE_TIMESTAMP,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        aa.RESULTTYPE,
        aa.DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.ACTIVITY_UPDATE_TIMESTAMP
    FROM filtered_inventory i
    JOIN audit_profile_deduped ap
      ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
     AND ap.rn = 1
    JOIN audit_activity_deduped aa
      ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
     AND aa.rn = 1
)
SELECT
    COUNT(DISTINCT AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS AUDIT_ERROR_COUNT
FROM final_base
```

---

### 2. AUDIT_ERROR_DRILLDOWN_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "audit_error",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "date_assessed",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.INTAKESOURCESYSTEM,
        i.INVNTRY_TYPE,
        i.LOB,
        i.PLATFORM
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY i.PYID
        ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(i.PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        i.PYRESOLVEDTIMESTAMP,
        i.INTAKESOURCESYSTEM,
        i.INVNTRY_TYPE,
        i.LOB,
        i.PLATFORM
    FROM latest_inventory i
    WHERE UPPER(TRIM(i.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND i.PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND UPPER(TRIM(i.PYRESOLVEDUSERID)) = 'AG01440'
      AND i.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.LOB,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(ap.PYSTATUSWORK)) AS AUDIT_STATUS,
        ap.AUDIT_MONTH,
        ap.AUDIT_YEAR,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        DATE(ap.PXCREATEDATETIME) AS RESOLVED_DATE,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.createtimestamp AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    ap.AUDIT_CASE_ID AS work_item_id,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS error_category,
    COALESCE(up.USERNAME, 'N/A') AS associate_name,
    aa.DATE_ASSESSED AS date_assessed,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(i.LOB, 'N/A') AS lob,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(aa.SPECIALISTERRORCORRECTED, 'N/A') AS specialist_error_corrected,
    COALESCE(ap.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ap.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM filtered_inventory i
JOIN audit_profile_deduped ap
  ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
 AND ap.rn = 1
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
LEFT JOIN deduped_user_profile up
  ON up.USERID = i.ASSOCIATE_ID
 AND up.rn = 1
ORDER BY
    DATE(aa.DATE_ASSESSED) DESC, ap.AUDIT_CASE_ID ASC, aa.ERRORCATEGORY ASC
```

---

### 3. AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "screen_id": "audit_error",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [
      {
        "year": "2026",
        "month": "May"
      },
      {
        "year": "2026",
        "month": "June"
      }
    ],
    "sort_by": "date_assessed",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        ap.AUDIT_MONTH,
        ap.AUDIT_YEAR,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) = UPPER('AG01440')
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND ap.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
)
SELECT
    COUNT(DISTINCT ap.AUDIT_CASE_ID || '|' || aa.ERRORCATEGORYTYPE || '|' || aa.ERRORCATEGORY) AS AUDIT_ERROR_COUNT
FROM audit_profile_deduped ap
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
WHERE ap.rn = 1
  AND ((UPPER(TRIM(ap.AUDIT_MONTH)) = UPPER('May') AND TRIM(ap.AUDIT_YEAR) = '2026') OR (UPPER(TRIM(ap.AUDIT_MONTH)) = UPPER('June') AND TRIM(ap.AUDIT_YEAR) = '2026'))
```

---

### 4. AUDIT_ERROR_DRILLDOWN_AUDIT_PERIOD_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "screen_id": "audit_error",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [
      {
        "year": "2026",
        "month": "May"
      },
      {
        "year": "2026",
        "month": "June"
      }
    ],
    "sort_by": "date_assessed",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(ap.PYSTATUSWORK)) AS AUDIT_STATUS,
        ap.AUDIT_MONTH,
        ap.AUDIT_YEAR,
        ap.LOB,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        DATE(ap.PXCREATEDATETIME) AS RESOLVED_DATE,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) = UPPER('AG01440')
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND ap.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.createtimestamp AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
latest_inventory AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(i.PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        i.INTAKESOURCESYSTEM,
        i.INVNTRY_TYPE,
        i.LOB,
        i.PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    ap.AUDIT_CASE_ID AS work_item_id,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS error_category,
    COALESCE(up.USERNAME, 'N/A') AS associate_name,
    aa.DATE_ASSESSED AS date_assessed,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(i.LOB, ap.LOB, 'N/A') AS lob,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(aa.SPECIALISTERRORCORRECTED, 'N/A') AS specialist_error_corrected,
    COALESCE(ap.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ap.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM audit_profile_deduped ap
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
LEFT JOIN latest_inventory i
  ON i.ORIGINAL_OHI_CASE_ID = ap.ORIGINAL_OHI_CASE_ID
 AND i.rn = 1
LEFT JOIN deduped_user_profile up
  ON up.USERID = ap.AUDIT_SUBJECT_ID
 AND up.rn = 1
WHERE ap.rn = 1
  AND ((UPPER(TRIM(ap.AUDIT_MONTH)) = UPPER('May') AND TRIM(ap.AUDIT_YEAR) = '2026') OR (UPPER(TRIM(ap.AUDIT_MONTH)) = UPPER('June') AND TRIM(ap.AUDIT_YEAR) = '2026'))
ORDER BY
    DATE(aa.DATE_ASSESSED) DESC, ap.AUDIT_CASE_ID ASC, aa.ERRORCATEGORY ASC
```

---

## audit_score_gauge

**Number of Queries:** 4

### 1. AUDIT_SCORE_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-06-17'
      AND LOB IN ('Medicaid')
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-25'::DATE)
),
audit_deduped AS (
    SELECT 
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = 'AH40730'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      AND LOB IN ('Medicaid')
)
SELECT 
    a.AUDIT_SUBJECT_ID,
    ROUND(AVG(a.AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT i.PYID) AS total_cases_audited
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
GROUP BY a.AUDIT_SUBJECT_ID
```

---

### 2. AUDIT_SCORE_TREND_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH date_range AS (
    SELECT
        DATEDIFF(day, '2026-06-17'::DATE, '2026-07-25'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-06-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-25'::DATE)
      AND LOB IN ('Medicaid')
),
audit_deduped AS (
    SELECT 
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        ROW_NUMBER() OVER (
            PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID 
            ORDER BY a.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = 'AH40730'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      AND LOB IN ('Medicaid')
),
audit_with_completion_date AS (
    SELECT 
        i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        i.PYID AS case_id
    FROM filtered_inventory i
    INNER JOIN audit_deduped a
        ON i.PYID = a.CASE_TO_AUDIT
        AND a.rn = 1
),
grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE 
            WHEN g.grouping_type = 'daily' THEN a.case_completion_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.case_completion_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.case_completion_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.case_completion_date)
            ELSE DATE_TRUNC('year', a.case_completion_date)
        END AS group_key,
        a.case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        a.case_id
    FROM audit_with_completion_date a
    CROSS JOIN grouping_logic g
)
SELECT 
    CASE 
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(GREATEST(group_key, '2026-06-17'::DATE), 'MM/DD') || ' - ' ||
            TO_CHAR(LEAST(DATEADD(day, 6, group_key), '2026-07-25'::DATE), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT audit_id) AS total_audits,
    COUNT(DISTINCT case_id) AS total_cases_audited,
    MIN(case_completion_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

### 3. AUDIT_SCORE_AUDIT_PERIOD_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.LOB,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('AH40730')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      AND LOB IN ('Medicaid')
)
SELECT
    a.AUDIT_SUBJECT_ID,
    ROUND(AVG(a.AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT a.CASE_TO_AUDIT) AS total_cases_audited
FROM audit_deduped a
WHERE a.rn = 1
  AND ((UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('May') AND TRIM(a.AUDIT_YEAR) = '2026') OR (UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('June') AND TRIM(a.AUDIT_YEAR) = '2026'))
GROUP BY a.AUDIT_SUBJECT_ID
```

---

### 4. AUDIT_SCORE_TREND_AUDIT_PERIOD_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT AS case_id,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        CASE
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JAN', 'JANUARY') THEN 1
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('FEB', 'FEBRUARY') THEN 2
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('MAR', 'MARCH') THEN 3
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('APR', 'APRIL') THEN 4
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('MAY') THEN 5
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JUN', 'JUNE') THEN 6
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JUL', 'JULY') THEN 7
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('AUG', 'AUGUST') THEN 8
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('SEP', 'SEPT', 'SEPTEMBER') THEN 9
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('OCT', 'OCTOBER') THEN 10
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('NOV', 'NOVEMBER') THEN 11
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('DEC', 'DECEMBER') THEN 12
            ELSE NULL
        END AS audit_month_number,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('AH40730')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      AND LOB IN ('Medicaid')
),
grouped_data AS (
    SELECT
        CASE
            WHEN 'monthly' = 'monthly'
                THEN TRIM(a.AUDIT_YEAR) || '-' || LPAD(TO_VARCHAR(a.audit_month_number), 2, '0')
            WHEN 'monthly' = 'quarterly'
                THEN TRIM(a.AUDIT_YEAR) || '-Q' || TO_VARCHAR(FLOOR((a.audit_month_number - 1) / 3) + 1)
            ELSE TRIM(a.AUDIT_YEAR)
        END AS period,
        CASE
            WHEN 'monthly' = 'monthly'
                THEN TO_DATE(TRIM(a.AUDIT_YEAR) || '-' || LPAD(TO_VARCHAR(a.audit_month_number), 2, '0') || '-01')
            WHEN 'monthly' = 'quarterly'
                THEN DATE_FROM_PARTS(
                    TRY_TO_NUMBER(TRIM(a.AUDIT_YEAR)),
                    (FLOOR((a.audit_month_number - 1) / 3) * 3) + 1,
                    1
                )
            ELSE DATE_FROM_PARTS(TRY_TO_NUMBER(TRIM(a.AUDIT_YEAR)), 1, 1)
        END AS sort_date,
        a.AUDIT_SCORE,
        a.audit_id,
        a.case_id
    FROM audit_deduped a
    WHERE a.rn = 1
      AND ((UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('May') AND TRIM(a.AUDIT_YEAR) = '2026') OR (UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('June') AND TRIM(a.AUDIT_YEAR) = '2026'))
      AND a.audit_month_number IS NOT NULL
)
SELECT
    period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT audit_id) AS total_audits,
    COUNT(DISTINCT case_id) AS total_cases_audited,
    MIN(sort_date) AS sort_date
FROM grouped_data
GROUP BY period
ORDER BY sort_date
```

---

## auditscore_drilldown

**Number of Queries:** 4

### 1. AUDIT_SCORE_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "audit_score",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "audit_resolved",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYSTATUSWORK,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
),
audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        ROW_NUMBER() OVER (
            PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID
            ORDER BY a.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = 'AG01440'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
)
SELECT
    COUNT(DISTINCT a.audit_id) AS TOTAL_COUNT,
    COUNT(DISTINCT CASE WHEN UPPER(TRIM(a.TARGET_AUDIT)) = 'YES' THEN a.audit_id END) AS TARGET_AUDIT_COUNT
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
```

---

### 2. AUDIT_SCORE_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "audit_score",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "audit_resolved",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYSTATUSWORK,
        PYRESOLVEDUSERID,
        INVNTRY_TYPE,
        CYCLE_TIME,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        INVNTRY_TYPE,
        CYCLE_TIME
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
audit_deduped AS (
    SELECT 
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PYSTATUSWORK,
        a.LOB,
        a.PXUPDATEDATETIME::DATE AS audit_date,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.PLATFORM,
        a.TARGET_AUDIT,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID 
            ORDER BY a.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = 'AG01440'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
)
SELECT 
    a.audit_id AS audit_work_item,
    i.PYID AS case_work_item,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK AS audit_status,
    a.LOB,
    i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    i.INVNTRY_TYPE,
    i.CYCLE_TIME,
    COALESCE(a.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(a.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP::DATE DESC, a.audit_id ASC
LIMIT 20 OFFSET 0
```

---

### 3. AUDIT_SCORE_COUNT_AUDIT_PERIOD_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "screen_id": "audit_score",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [
      {
        "year": "2026",
        "month": "May"
      },
      {
        "year": "2026",
        "month": "June"
      }
    ],
    "sort_by": "audit_resolved",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.LOB,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('AG01440')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
)
SELECT
    COUNT(DISTINCT a.audit_id) AS TOTAL_COUNT,
    COUNT(DISTINCT CASE WHEN UPPER(TRIM(a.TARGET_AUDIT)) = 'YES' THEN a.audit_id END) AS TARGET_AUDIT_COUNT
FROM audit_deduped a
WHERE a.rn = 1
  AND ((UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('May') AND TRIM(a.AUDIT_YEAR) = '2026') OR (UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('June') AND TRIM(a.AUDIT_YEAR) = '2026'))
```

---

### 4. AUDIT_SCORE_PAGINATED_AUDIT_PERIOD_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "screen_id": "audit_score",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [
      {
        "year": "2026",
        "month": "May"
      },
      {
        "year": "2026",
        "month": "June"
      }
    ],
    "sort_by": "audit_resolved",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PYSTATUSWORK,
        a.LOB,
        a.PXUPDATEDATETIME::DATE AS audit_date,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.PLATFORM,
        a.TARGET_AUDIT,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('AG01440')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        INVNTRY_TYPE,
        CYCLE_TIME,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
)
SELECT
    a.audit_id AS audit_work_item,
    a.CASE_TO_AUDIT AS case_work_item,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK AS audit_status,
    COALESCE(a.LOB, 'N/A') AS LOB,
    i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    i.INVNTRY_TYPE,
    i.CYCLE_TIME,
    COALESCE(a.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(a.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM audit_deduped a
LEFT JOIN latest_inventory i
  ON i.PYID = a.CASE_TO_AUDIT
 AND i.rn = 1
WHERE a.rn = 1
  AND ((UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('May') AND TRIM(a.AUDIT_YEAR) = '2026') OR (UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('June') AND TRIM(a.AUDIT_YEAR) = '2026'))
ORDER BY i.PYRESOLVEDTIMESTAMP::DATE DESC, a.audit_id ASC
LIMIT 20 OFFSET 0
```

---

## fusetime_drilldown

**Number of Queries:** 2

### 1. FUSE_TIME_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "fuse_time",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "date",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
SELECT COUNT(*) as TOTAL_COUNT
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = 'AG01440'
AND LOGINDATE BETWEEN '2026-03-17' AND '2026-03-23'
```

---

### 2. FUSE_TIME_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "fuse_time",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "date",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
SELECT 
    USERNAME,
    USERID,
    LOGINDATE,
    FIRSTLOGINTIME,
    LASTLOGOUTTIME,
    TOTALSYSTEMTIME,
    FUSE_NON_PRODUCTIVE_TIME,
    PRODUCTIVETIME,
    COALESCE(TOTALSYSTEMTIME, 0) - 
    (COALESCE(
        CASE 
            WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END, 0
    ) + 
    COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) AS OTHER_TIME
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = 'AG01440'
AND LOGINDATE BETWEEN '2026-03-17' AND '2026-03-23'
ORDER BY LOGINDATE DESC, USERNAME ASC, USERID ASC
LIMIT 20 OFFSET 0
```

---

## production_pct_drilldown

**Number of Queries:** 3

### 1. PRODUCTION_PCT_ACHIEVED_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "production_pct_achieved",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "resolved_date",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDUSERID = 'AG01440'
    AND PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
    AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
    AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
    AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
)
SELECT 
    PYRESOLVEDUSERID,
    COUNT(DISTINCT PYID) AS completed_tasks
FROM invntry_deduped
WHERE rn = 1
GROUP BY PYRESOLVEDUSERID
```

---

### 2. PRODUCTION_PCT_ACHIEVED_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "production_pct_achieved",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "resolved_date",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH
invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        CYCLE_TIME,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        MARKET,
        PLATFORM,
        ACTIVITYCODE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDUSERID = 'AG01440'
      AND PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
invntry_daily AS (
    SELECT
        PYRESOLVEDUSERID AS userid,
        resolved_date,
        COUNT(DISTINCT PYID) AS work_items_completed,
        SUM(RETIME) AS total_retime_min
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID, resolved_date
),
user_daily AS (
    SELECT
        USERID,
        USERNAME,
        LOGINDATE,
        TOTALSYSTEMTIME,
        non_prdctv_duration AS non_productive_sec,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INT * 60) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 2)::INT) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 3)::INT / 60.0) AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY USERID, LOGINDATE ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE USERID = 'AG01440'
      AND LOGINDATE >= '2026-03-17'
      AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
      AND TOTALSYSTEMTIME IS NOT NULL
),
daily_metrics AS (
    SELECT
        i.userid,
        u.USERNAME,
        i.resolved_date,
        i.work_items_completed,
        i.total_retime_min,
        u.actual_production_min
    FROM invntry_daily i
    INNER JOIN user_daily u
        ON i.userid = u.USERID
        AND i.resolved_date = u.LOGINDATE
    WHERE u.rn = 1
      AND u.actual_production_min > 0
),
aggregated_totals AS (
    SELECT
        userid,
        MAX(USERNAME) AS USERNAME,
        SUM(work_items_completed) AS total_work_items,
        SUM(total_retime_min) AS total_retime_min,
        SUM(actual_production_min) AS total_actual_production_min,
        COUNT(DISTINCT resolved_date) AS work_days,
        ROUND(
            (SUM(total_retime_min) / NULLIF(SUM(actual_production_min), 0)) * 100,
            2
        ) AS production_pct_achieved,
        ROUND(
            SUM(actual_production_min) / NULLIF(SUM(total_retime_min) / NULLIF(SUM(work_items_completed), 0), 0),
            0
        ) AS total_expected_tasks
    FROM daily_metrics
    GROUP BY userid
),
user_profile_deduped AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYRESOLVEDUSERID AS associate,
    COALESCE(u.USERNAME, p.USERNAME) AS associate_name,
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS worktype,
    i.RETIME AS standard_time,
    i.CYCLE_TIME AS case_cycle_time,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.MARKET,
    i.PLATFORM,
    TO_CHAR(i.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY') AS resolved_date,
    i.ACTIVITYCODE AS activity_code,
    'View Details' AS action,
    p.total_work_items,
    p.total_retime_min AS total_expected_min,
    ROUND(p.total_actual_production_min, 0) AS total_actual_production_min,
    p.total_expected_tasks,
    p.production_pct_achieved
FROM invntry_deduped i
INNER JOIN aggregated_totals p
    ON i.PYRESOLVEDUSERID = p.userid
LEFT JOIN user_profile_deduped u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC, i.PYRESOLVEDTIMESTAMP DESC, i.PYID
LIMIT 20 OFFSET 0
```

---

### 3. USER_NAME_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "production_pct_achieved",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "resolved_date",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
SELECT TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) as full_name
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = 'AG01440'
```

---

## production_percentage_gauge

**Number of Queries:** 2

### 1. PRODUCTION_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH 
invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-06-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-25'::DATE)
      AND PYRESOLVEDUSERID = 'AH40730'
      AND LOB IN ('Medicaid')
),
associate_work AS (
    SELECT 
        PYRESOLVEDUSERID AS userid,
        COUNT(DISTINCT PYID) AS work_items_completed,
        SUM(RETIME) AS total_retime_min
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID
),
user_daily AS (
    SELECT 
        USERID,
        USERNAME,
        LOGINDATE,
        TOTALSYSTEMTIME,
        non_prdctv_duration AS non_productive_sec,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INT * 60) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 2)::INT) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 3)::INT / 60.0) AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY USERID, LOGINDATE ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE USERID = 'AH40730'
      AND LOGINDATE >= '2026-06-17'
      AND LOGINDATE < DATEADD(day, 1, '2026-07-25'::DATE)
      AND TOTALSYSTEMTIME IS NOT NULL
),
associate_prod AS (
    SELECT 
        USERID AS userid,
        MAX(USERNAME) AS username,
        SUM(actual_production_min) AS total_prod_min
    FROM user_daily
    WHERE rn = 1
      AND actual_production_min > 0
    GROUP BY USERID
)
SELECT 
    ROUND(
        (SUM(w.total_retime_min) / NULLIF(SUM(p.total_prod_min), 0)) * 100,
        2
    ) AS AVG_PRODUCTION_PCT
FROM associate_work w
LEFT JOIN associate_prod p ON w.userid = p.userid
```

---

### 2. PRODUCTION_TREND_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH date_range AS (
    SELECT DATEDIFF(day, '2026-06-17'::DATE, '2026-07-25'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),

invntry_deduped AS (
    SELECT 
        PYID, 
        PYRESOLVEDUSERID, 
        RETIME, 
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDUSERID = 'AH40730'
      AND PYRESOLVEDTIMESTAMP::DATE BETWEEN '2026-06-17' AND '2026-07-25'
      AND LOB IN ('Medicaid')
),
invntry_daily AS (
    SELECT 
        PYRESOLVEDUSERID AS userid,
        resolved_date,
        COUNT(DISTINCT PYID) AS work_items_completed,
        SUM(RETIME) AS total_retime_min
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID, resolved_date
),

user_daily AS (
    SELECT 
        USERID, 
        LOGINDATE,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INT * 60) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 2)::INT) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 3)::INT / 60.0) AS actual_production_min,
        ROW_NUMBER() OVER (
            PARTITION BY USERID, LOGINDATE 
            ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND USERID = 'AH40730'
        AND LOGINDATE BETWEEN '2026-06-17' AND '2026-07-25'
        AND TOTALSYSTEMTIME IS NOT NULL
),
user_prod_daily AS (
    SELECT 
        USERID, 
        LOGINDATE, 
        actual_production_min
    FROM user_daily
    WHERE rn = 1 
      AND actual_production_min > 0
),

combined_daily AS (
    SELECT
        COALESCE(i.resolved_date, u.LOGINDATE) AS activity_date,  
        COALESCE(i.userid, u.USERID) AS userid,                 
        COALESCE(i.work_items_completed, 0) AS work_items_completed, 
        COALESCE(i.total_retime_min, 0) AS total_retime_min,        
        COALESCE(u.actual_production_min, 0) AS actual_production_min 
    FROM invntry_daily i
    FULL OUTER JOIN user_prod_daily u 
        ON i.userid = u.USERID
        AND i.resolved_date = u.LOGINDATE
),

grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN d.activity_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', d.activity_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', d.activity_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', d.activity_date)
            ELSE DATE_TRUNC('year', d.activity_date)
        END AS group_key,
        d.activity_date, 
        d.work_items_completed,
        d.total_retime_min,
        d.actual_production_min
    FROM combined_daily d  
    CROSS JOIN grouping_logic g
)

SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(group_key, 'MM/DD') || ' - ' || TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(
        (SUM(total_retime_min) / NULLIF(SUM(actual_production_min), 0)) * 100,
        2
    ) AS production_percentage,
    SUM(work_items_completed) AS total_tasks,
    MIN(activity_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

## user_activity

**Number of Queries:** 3

### 1. LOGIN_LOGOUT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
SELECT 
    DATE(LOGINTIME) as LOGINDATE,
    TO_CHAR(LOGINTIME, 'HH12:MI AM') || ' ET' as login_time,
    TO_CHAR(LOGOUTTIME, 'HH12:MI AM') || ' ET' as logout_time
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_ACTIVITY
WHERE DOMAINID = 'AH40730'
AND DATE(LOGINTIME) = CURRENT_DATE()
ORDER BY LOGINTIME ASC
```

---

### 2. RANK_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
SELECT 
    ROUND(AVG(TEAMRANK))::INT AS TEAMRANK,
    ROUND(AVG(DEPTRANK))::INT AS DEPTRANK
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = 'AH40730'
AND LOGINDATE >= '2026-06-17'
AND LOGINDATE < DATEADD(day, 1, '2026-07-25'::DATE)
AND TEAMRANK IS NOT NULL
AND DEPTRANK IS NOT NULL
```

---

### 3. SKILLED_SOURCES_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
SELECT DISTINCT SKILLDESCRIPTION
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_SKILLS
WHERE USERID = 'AH40730'
AND DATE(PXCOMMITDATETIME) = (
    SELECT MAX(DATE(PXCOMMITDATETIME))
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_SKILLS
    WHERE USERID = 'AH40730'
)
```

---

## user_metrics

**Number of Queries:** 6

### 1. AUDIT_ERROR_COUNT_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY i.PYID
        ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        PYRESOLVEDTIMESTAMP
    FROM latest_inventory
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-06-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-25'::DATE)
      AND UPPER(TRIM(PYRESOLVEDUSERID)) = 'AH40730'
      AND LOB IN ('Medicaid')
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
final_base AS (
    SELECT
        i.ASSOCIATE_ID,
        i.ORIGINAL_OHI_CASE_ID,
        i.PYRESOLVEDTIMESTAMP,
        ap.AUDIT_CASE_ID,
        ap.AUDIT_CREATE_TIMESTAMP,
        ap.AUDIT_UPDATE_TIMESTAMP,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        aa.RESULTTYPE,
        aa.DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.ACTIVITY_UPDATE_TIMESTAMP
    FROM filtered_inventory i
    JOIN audit_profile_deduped ap
      ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
     AND ap.rn = 1
    JOIN audit_activity_deduped aa
      ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
     AND aa.rn = 1
)
SELECT
    COUNT(DISTINCT AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS AUDIT_ERROR_COUNT
FROM final_base
```

---

### 2. AUDIT_SCORE_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-06-17'
      AND LOB IN ('Medicaid')
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-25'::DATE)
),
audit_deduped AS (
    SELECT 
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = 'AH40730'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      AND LOB IN ('Medicaid')
)
SELECT 
    a.AUDIT_SUBJECT_ID,
    ROUND(AVG(a.AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT i.PYID) AS total_cases_audited
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
GROUP BY a.AUDIT_SUBJECT_ID
```

---

### 3. WORK_ITEMS_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    PYRESOLVEDUSERID,
    COUNT(DISTINCT PYID) AS completed_tasks
FROM latest_inventory
WHERE UPPER(TRIM(PYRESOLVEDUSERID)) = 'AH40730'
  AND PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP >= '2026-06-17'
  AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-25'::DATE)
  AND LOB IN ('Medicaid')
GROUP BY PYRESOLVEDUSERID
```

---

### 4. AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        ap.AUDIT_MONTH,
        ap.AUDIT_YEAR,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) = UPPER('AH40730')
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND LOB IN ('Medicaid')
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
)
SELECT
    COUNT(DISTINCT ap.AUDIT_CASE_ID || '|' || aa.ERRORCATEGORYTYPE || '|' || aa.ERRORCATEGORY) AS AUDIT_ERROR_COUNT
FROM audit_profile_deduped ap
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
WHERE ap.rn = 1
  AND ((UPPER(TRIM(ap.AUDIT_MONTH)) = UPPER('May') AND TRIM(ap.AUDIT_YEAR) = '2026') OR (UPPER(TRIM(ap.AUDIT_MONTH)) = UPPER('June') AND TRIM(ap.AUDIT_YEAR) = '2026'))
```

---

### 5. AUDIT_SCORE_AUDIT_PERIOD_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.LOB,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('AH40730')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      AND LOB IN ('Medicaid')
)
SELECT
    a.AUDIT_SUBJECT_ID,
    ROUND(AVG(a.AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT a.CASE_TO_AUDIT) AS total_cases_audited
FROM audit_deduped a
WHERE a.rn = 1
  AND ((UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('May') AND TRIM(a.AUDIT_YEAR) = '2026') OR (UPPER(TRIM(a.AUDIT_MONTH)) = UPPER('June') AND TRIM(a.AUDIT_YEAR) = '2026'))
GROUP BY a.AUDIT_SUBJECT_ID
```

---

### 6. WORK_ITEMS_QUERY

**Mode:** `audit_period`

**Payload Used:**

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "lob": [
    "Medicaid"
  ],
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "warm_ai_coach_context": true
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    PYRESOLVEDUSERID,
    COUNT(DISTINCT PYID) AS completed_tasks
FROM latest_inventory
WHERE UPPER(TRIM(PYRESOLVEDUSERID)) = 'AH40730'
  AND PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP >= '2026-06-17'
  AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-07-25'::DATE)
  AND LOB IN ('Medicaid')
GROUP BY PYRESOLVEDUSERID
```

---

## workitems_drilldown

**Number of Queries:** 3

### 1. USER_NAME_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "work_items",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "resolved_date",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
SELECT TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) as full_name
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = 'AG01440'
```

---

### 2. WORK_ITEMS_PAGINATED_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "work_items",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "resolved_date",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        CYCLE_TIME,
        PYSTATUSWORK,
        LOB,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PLATFORM,
        INVNTRY_TYPE
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    PYID,
    INTAKESOURCESYSTEM,
    CYCLE_TIME,
    PYSTATUSWORK,
    LOB,
    PYRESOLVEDTIMESTAMP,
    PYRESOLVEDUSERID,
    PLATFORM,
    INVNTRY_TYPE
FROM latest_inventory
WHERE UPPER(TRIM(PYRESOLVEDUSERID)) = 'AG01440'
  AND PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
  AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
  AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
ORDER BY DATE(PYRESOLVEDTIMESTAMP) DESC, PYID ASC
LIMIT 20 OFFSET 0
```

---

### 3. WORK_ITEMS_QUERY

**Mode:** `date_range`

**Payload Used:**

```json
{
  "screen_id": "work_items",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": "resolved_date",
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

**SQL Query:**

```sql
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    PYRESOLVEDUSERID,
    COUNT(DISTINCT PYID) AS completed_tasks
FROM latest_inventory
WHERE UPPER(TRIM(PYRESOLVEDUSERID)) = 'AG01440'
  AND PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
  AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
  AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
GROUP BY PYRESOLVEDUSERID
```

---

## Summary

### Queries per Module

| Module | Query Count |
|--------|-------------|
| audit_error_drilldown | 4 |
| audit_score_gauge | 4 |
| auditscore_drilldown | 4 |
| fusetime_drilldown | 2 |
| production_pct_drilldown | 3 |
| production_percentage_gauge | 2 |
| user_activity | 3 |
| user_metrics | 6 |
| workitems_drilldown | 3 |

### Test Payload Used (Non-Drilldown APIs)

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "audit_periods": [],
  "lob": [
    "Medicaid"
  ]
}
```

### Audit Period Payload Used (Non-Drilldown APIs)

```json
{
  "user_id": "AH40730",
  "start_date": "2026-06-17",
  "end_date": "2026-07-25",
  "audit_periods": [
    {
      "year": "2026",
      "month": "May"
    },
    {
      "year": "2026",
      "month": "June"
    }
  ],
  "lob": [
    "Medicaid"
  ]
}
```

### Pagination Payload Used (Drilldown APIs)

```json
{
  "screen_id": "work_items",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [],
    "sort_by": null,
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```

### Audit Period Pagination Payload Used (Drilldown APIs)

```json
{
  "screen_id": "work_items",
  "query": {
    "user_id": "AG01440",
    "date_range": {
      "from": "2026-03-17",
      "to": "2026-03-23"
    },
    "lob": [
      "CSBD",
      "Commercial",
      "CrossOver",
      "EGR",
      "GRS",
      "Group Retiree Solutions",
      "INT",
      "KCP",
      "MDR",
      "MMP",
      "MedSupp",
      "Medicaid",
      "Medicare",
      "PDP",
      "SUP",
      "Supplemental"
    ],
    "audit_periods": [
      {
        "year": "2026",
        "month": "May"
      },
      {
        "year": "2026",
        "month": "June"
      }
    ],
    "sort_by": null,
    "sort_direction": "desc"
  },
  "page": {
    "page_limit": 20,
    "page": 1
  }
}
```
