# Performance IQ Manager API - SQL Documentation

**Generated:** 2026-06-18 14:37:14

**Total APIs:** 19
**Total SQL Queries:** 48

## Table of Contents

1. [associate_utilization](#associate-utilization) (5 queries)
2. [associates_list](#associates-list) (1 queries)
3. [audit_errors_drilldown](#audit-errors-drilldown) (2 queries)
4. [audit_score_drilldown](#audit-score-drilldown) (2 queries)
5. [complete_audit_count_drilldown](#complete-audit-count-drilldown) (2 queries)
6. [fuse_time_drilldown](#fuse-time-drilldown) (2 queries)
7. [header_kpis](#header-kpis) (7 queries)
8. [manager_capacity_insight_drilldown](#manager-capacity-insight-drilldown) (1 queries)
9. [manager_list](#manager-list) (1 queries)
10. [manager_lob](#manager-lob) (2 queries)
11. [pended_items_counts_drilldown](#pended-items-counts-drilldown) (2 queries)
12. [production_pct_achieved_drilldown](#production-pct-achieved-drilldown) (2 queries)
13. [quality_outcomes](#quality-outcomes) (7 queries)
14. [rebuttal_drilldown](#rebuttal-drilldown) (2 queries)
15. [rework_drilldown](#rework-drilldown) (2 queries)
16. [user_activity](#user-activity) (4 queries)
17. [watchlist_manager_drilldown](#watchlist-manager-drilldown) (2 queries)
18. [work_items_drilldown](#work-items-drilldown) (2 queries)

---

## associate_utilization

**Number of Queries:** 5

### 1. AUDIT_SCORE_TREND_QUERY

**SQL Query:**

```sql
WITH date_range AS (
    -- Calculate total days in the selected date range
    SELECT
        DATEDIFF(day, '2026-03-17'::DATE, '2026-03-23'::DATE) + 1 AS total_days
),
grouping_logic AS (
    -- Determine grouping type based on date range length
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID, 
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
      
),
audit_deduped AS (
    -- Deduplicate audit records by (CASE_TO_AUDIT, AUDIT_SUBJECT_ID)
    SELECT 
        PYID AS audit_id,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        ROW_NUMBER() OVER (
            PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
audit_with_completion_date AS (
    -- SIMPLIFIED: Direct join between inventory and audit, no intermediate CTE needed
    -- Links audits to work item completion dates
    SELECT 
        i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        i.PYID AS case_id,
        a.AUDIT_SUBJECT_ID
    FROM invntry_deduped i
    INNER JOIN audit_deduped a
        ON i.PYID = a.CASE_TO_AUDIT
        AND a.rn = 1
    WHERE i.rn = 1  
),
grouped_data AS (
    -- Group audit data by the appropriate time period
    SELECT 
        g.grouping_type,
        CASE 
            WHEN g.grouping_type = 'daily' THEN a.case_completion_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.case_completion_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.case_completion_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.case_completion_date)
            ELSE DATE_TRUNC('year', a.case_completion_date)
        END AS group_key,
        a.case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        a.case_id,
        a.AUDIT_SUBJECT_ID
    FROM audit_with_completion_date a
    CROSS JOIN grouping_logic g
)
-- Final aggregation and formatting for trend line display
SELECT 
    -- Format period label based on grouping type
    CASE 
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(group_key, 'MM/DD') || ' - ' || 
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT audit_id) AS total_audits,
    COUNT(DISTINCT case_id) AS total_cases_audited,
    COUNT(DISTINCT AUDIT_SUBJECT_ID) AS total_frontline_audited,
    MIN(case_completion_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

### 2. CAPACITY_INSIGHT_QUERY

**SQL Query:**

```sql
WITH
date_range_config AS (
    SELECT
        '2026-03-17'::DATE AS period_start,
        '2026-03-23'::DATE AS period_end
),
grouping_logic AS (
    SELECT
        DATEDIFF(day, period_start, period_end) + 1 AS total_days,
        CASE
            WHEN DATEDIFF(day, period_start, period_end) + 1 <= 7 THEN 'daily'
            WHEN DATEDIFF(day, period_start, period_end) + 1 <= 30 THEN 'weekly'
            WHEN DATEDIFF(day, period_start, period_end) + 1 <= 365 THEN 'monthly'
            WHEN DATEDIFF(day, period_start, period_end) + 1 <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range_config
),
date_spine AS (
    SELECT DATEADD(DAY, SEQ4(), drc.period_start) AS spine_date
    FROM TABLE(GENERATOR(ROWCOUNT => 500))
    CROSS JOIN date_range_config drc
    WHERE DATEADD(DAY, SEQ4(), drc.period_start) <= drc.period_end
),
date_periods AS (
    SELECT DISTINCT
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN spine_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', spine_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', spine_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', spine_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', spine_date)
        END AS period_date,
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN spine_date
            WHEN 'weekly' THEN DATEADD(DAY, 6, DATE_TRUNC('WEEK', spine_date))
            WHEN 'monthly' THEN LAST_DAY(DATE_TRUNC('MONTH', spine_date))
            WHEN 'quarterly' THEN LAST_DAY(DATE_TRUNC('QUARTER', spine_date))
            WHEN 'yearly' THEN LAST_DAY(DATE_TRUNC('YEAR', spine_date))
        END AS period_end_date,
        EXTRACT(YEAR FROM spine_date) AS period_year,
        EXTRACT(MONTH FROM spine_date) AS period_month
    FROM date_spine
),
date_spine_for_business_days AS (
    SELECT
        dp.period_date,
        dp.period_end_date,
        DATEADD(DAY, gs.SEQ, dp.period_date) AS business_date
    FROM date_periods dp
    CROSS JOIN (
        SELECT SEQ4() AS SEQ
        FROM TABLE(GENERATOR(ROWCOUNT => 400))
    ) gs
    LEFT JOIN NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_HOLIDAY_DATA holidays
        ON DATEADD(DAY, gs.SEQ, dp.period_date) = holidays.DATE
    WHERE DATEADD(DAY, gs.SEQ, dp.period_date) <= dp.period_end_date
      AND DATEADD(DAY, gs.SEQ, dp.period_date) <= (SELECT period_end FROM date_range_config)  -- Only count days within requested range
      AND DATEADD(DAY, gs.SEQ, dp.period_date) >= (SELECT period_start FROM date_range_config)  -- Only count days within requested range
      AND DAYNAME(DATEADD(DAY, gs.SEQ, dp.period_date)) NOT IN ('Sat', 'Sun')
      AND holidays.DATE IS NULL  -- Exclude holidays
),
business_days_per_period AS (
    SELECT
        dp.period_date,
        dp.period_end_date,
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN 1
            ELSE COALESCE(bd_count.business_days, 0)
        END AS business_days
    FROM date_periods dp
    LEFT JOIN (
        SELECT
            period_date,
            COUNT(*) AS business_days
        FROM date_spine_for_business_days
        GROUP BY period_date
    ) bd_count ON dp.period_date = bd_count.period_date
),
productive_hrs AS (
    -- Total Fuse Time Hours per day - Dynamic based on past 90 days from end date
    -- Using logic: (Total System Time - Non Productive Time) / 3600.0 to convert seconds to hours
    SELECT
        ROUND(AVG(
            SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT
            + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0
            + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
        ), 2) AS avg_hrs_per_day
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
      AND u.TOTALSYSTEMTIME IS NOT NULL
      AND u.LOGINDATE BETWEEN DATEADD(day, -90, (SELECT period_end FROM date_range_config)) AND (SELECT period_end FROM date_range_config)
),
avail_fte_by_period AS (
    SELECT
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN TRY_CAST(w.ASOFTODAY AS DATE)
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', TRY_CAST(w.ASOFTODAY AS DATE))
        END AS period_date,
        COUNT(DISTINCT w.EMPLOYEE_DOMAIN_ID) AS available_fte
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT period_start FROM date_range_config) AND (SELECT period_end FROM date_range_config)
    GROUP BY
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN TRY_CAST(w.ASOFTODAY AS DATE)
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', TRY_CAST(w.ASOFTODAY AS DATE))
        END
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.CYCLE_TIME,
        DATE(inv.pxcreatedatetime) AS resolve_date,
        DATE_TRUNC('WEEK', inv.pxcreatedatetime) AS week_start,
        DATE_TRUNC('MONTH', inv.pxcreatedatetime) AS month_start,
        DATE_TRUNC('QUARTER', inv.pxcreatedatetime) AS quarter_start,
        DATE_TRUNC('YEAR', inv.pxcreatedatetime) AS year_start,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS intakesourcesystem,
        ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY inv.pxupdatedatetime DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE inv
    WHERE pxcreatedatetime >= '2026-03-17' AND pxcreatedatetime < DATEADD(day, 1, '2026-03-23'::DATE)
      AND (LOB IN ('Commercial', 'EGR', 'GRS', 'MMP', 'MedSupp', 'Medicaid', 'Medicare') OR LOB IS NULL)
),
avg_cycle_time AS (
    SELECT
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS intakesourcesystem,
        ROUND(AVG(inv.CYCLE_TIME) / 3600.0, 2) AS avg_cycle_time_hrs
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE inv
        WHERE inv.CYCLE_TIME IS NOT NULL
          AND inv.PXCREATEDATETIME BETWEEN DATEADD(DAY, -90, (SELECT period_end FROM date_range_config)) AND DATEADD(DAY, 1, (SELECT period_end FROM date_range_config))
    GROUP BY COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown')
),
actual_receipts_by_period AS (
    -- Completed Items = No of work items resolved in the period (Distinct PYID) by intake source system
    SELECT
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN resolve_date
            WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start
            WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start
        END AS period_date,
        intakesourcesystem,
        COUNT(DISTINCT PYID) AS actual_receipts
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN resolve_date
            WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start
            WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start
        END,
        intakesourcesystem
),
fte_calculation AS (
    -- Total Fuse Time Hours/day = Dynamic based on past 90 days (Total System Time - Non Productive Time)
    -- For Daily: Total Available Hours per FTE = Total Fuse Time Hours/day * 1 day
    -- For Weekly/Monthly/Quarterly: Total Available Hours per FTE = Total Fuse Time Hours/day * business days in period
    -- Completed Items = No of work items resolved in the period (Distinct PYID)
    -- Total Work Hours Required = Completed Items * Cycle Time (90 days average in hours)
    -- Required FTE = Total Work Hours Required / Total Available Hours per FTE
    SELECT
        ar.period_date,
        ar.intakesourcesystem,
        ar.actual_receipts AS actual_receipts,
        COALESCE(ct.avg_cycle_time_hrs, 0) AS cycle_time_hrs,
        COALESCE((SELECT avg_hrs_per_day FROM productive_hrs), 6.5) AS productive_hrs_per_day,
        bd.business_days,
        af.available_fte,
        -- Total Available Hours per FTE = Total Fuse Time Hours/day * Number of business days
        ROUND(COALESCE((SELECT avg_hrs_per_day FROM productive_hrs), 6.5) * bd.business_days , 2) AS total_available_hrs_per_fte,
        -- Total Work Hours Required = Recieved Items * Cycle Time (hours)
        ROUND(ar.actual_receipts * COALESCE(ct.avg_cycle_time_hrs, 0), 2) AS total_work_hours_required
    FROM actual_receipts_by_period ar
    LEFT JOIN avg_cycle_time ct ON ar.intakesourcesystem = ct.intakesourcesystem
    LEFT JOIN business_days_per_period bd ON ar.period_date = bd.period_date
    LEFT JOIN avail_fte_by_period af ON ar.period_date = af.period_date
),
fte_summary AS (
    SELECT
        fc.period_date,
        -- Aggregate across all intake source systems
        SUM(fc.actual_receipts) AS actual_receipts,
        ROUND(SUM(fc.total_work_hours_required), 2) AS total_work_hours_required,
        MAX(fc.total_available_hrs_per_fte) AS total_available_hrs_per_fte,
        MAX(fc.productive_hrs_per_day) AS productive_hrs_per_day,
        -- Weighted average cycle time
        ROUND(SUM(fc.total_work_hours_required) / NULLIF(SUM(fc.actual_receipts), 0), 2) AS weighted_cycle_time_hrs,
        -- Required FTE = Total Work Hours Required / Total Available Hours per FTE
        CEIL(
            SUM(fc.total_work_hours_required) / NULLIF(MAX(fc.total_available_hrs_per_fte), 0)
        ) AS required_fte
    FROM fte_calculation fc
    GROUP BY fc.period_date
)
SELECT
    CASE (SELECT grouping_type FROM grouping_logic)
        WHEN 'daily' THEN TO_VARCHAR(dp.period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_VARCHAR(dp.period_date, 'MM/DD/YY') || '-' || TO_VARCHAR(dp.period_end_date, 'MM/DD/YY')
        WHEN 'monthly' THEN TO_VARCHAR(dp.period_date, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_VARCHAR(dp.period_date, 'YYYY') || '-Q' || QUARTER(dp.period_date)
        WHEN 'yearly' THEN TO_VARCHAR(dp.period_date, 'YYYY')
    END AS period_label,
    COALESCE(fs.required_fte, 0) AS required_fte,
    -- Available FTE count from Workday (eCOB Specialists in the period)
    COALESCE(af.available_fte, 0) AS available_fte,
    fs.actual_receipts,
    fs.total_work_hours_required,
    fs.productive_hrs_per_day as hours_per_day,
    fs.total_available_hrs_per_fte
FROM date_periods dp
LEFT JOIN fte_summary fs ON dp.period_date = fs.period_date
INNER JOIN avail_fte_by_period af ON dp.period_date = af.period_date
LEFT JOIN business_days_per_period bd ON dp.period_date = bd.period_date
WHERE
    CASE
        WHEN (SELECT grouping_type FROM grouping_logic) = 'daily' THEN
            DAYNAME(dp.period_date) NOT IN ('Sat', 'Sun')
        ELSE TRUE
    END
ORDER BY dp.period_date
```

---

### 3. EXPERIENCE_LEVEL_QUERY

**SQL Query:**

```sql
SELECT 
    EXPERIENCELEVEL AS LEVEL,
    COUNT(DISTINCT USERID) AS COUNT,
    ROUND(COUNT(DISTINCT USERID) * 100.0 / SUM(COUNT(DISTINCT USERID)) OVER (), 2) AS PERCENTAGE
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE EXPERIENCELEVEL IS NOT NULL

AND USERID IN ('AG01440')
AND PYREPORTTO IN ('A', 'D', '5', '0', '3', '9', '8')
GROUP BY EXPERIENCELEVEL
ORDER BY COUNT DESC
```

---

### 4. FUSE_TIME_SUMMARY_QUERY

**SQL Query:**

```sql
WITH associate_hierarchy AS (
    -- Get list of associates who reported to specified manager during the period
    SELECT DISTINCT
        PYRESOLVEDUSERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '2026-03-17' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND PYRESOLVEDUSERID IN ('AG01440')
      
)
SELECT 
    -- Total Fuse Time Hours = Available Hours (Total System Time - Non Productive Time)
    ROUND((SUM(up.TOTALSYSTEMTIME) / 3600.0) - (SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0), 2) AS TOTAL_FUSE_TIME_HOURS,
    
    -- OHI Productive Time (from PRODUCTIVETIME column)
   
    ROUND(SUM(
        CASE 
            WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END
    ) / 3600.0, 2) AS OHI_PRODUCTIVE_TIME_HOURS,
    
    -- Non-Productive Time (using FUSE_NON_PRODUCTIVE_TIME)
    ROUND(SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0, 2) AS TOTAL_NON_PRODUCTIVE_HOURS,
    
    
    ROUND(
        (SUM(up.TOTALSYSTEMTIME) / 3600.0) - 
        ((SUM(
            CASE 
                WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                    (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
                ELSE 0
            END
        ) / 3600.0) + 
        (SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0)), 
    2) AS OTHER_TIME_HOURS,
    
    -- Percentages (for UI chart display)
    -- Productive %
    ROUND(
        SUM(CASE WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
            (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
             SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
             SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
        ELSE 0 END) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 2
    ) AS PRODUCTIVE_PCT,
    
    -- Non-Productive %
    ROUND(
        SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 2
    ) AS NON_PRODUCTIVE_PCT,
    
    -- Other time%
    ROUND(
        100.0 - 
        COALESCE(
            SUM(CASE WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0 END) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 0
        ) -
        COALESCE(
            SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 0
        ), 2
    ) AS OTHER_PCT
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE up  
INNER JOIN associate_hierarchy ah
    ON up.USERID = ah.PYRESOLVEDUSERID  
WHERE up.TOTALSYSTEMTIME IS NOT NULL
```

---

### 5. PRODUCTION_TREND_QUERY

**SQL Query:**

```sql
WITH date_range AS (
    SELECT DATEDIFF(day, '2026-03-17'::DATE, '2026-03-23'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),

invntry_deduped AS (
    SELECT 
        PYID, 
        PYRESOLVEDUSERID, 
        RETIME, 
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
invntry_daily AS (
    SELECT 
        PYRESOLVEDUSERID AS userid,
        resolved_date,
        COUNT(DISTINCT PYID) AS work_items_completed,
        SUM(RETIME) AS total_retime_min
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID, resolved_date
),

users_with_work AS (
    SELECT DISTINCT userid 
    FROM invntry_daily
),
user_daily AS (
    SELECT 
        USERID, 
        LOGINDATE,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INT * 60) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 2)::INT) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 3)::INT / 60.0) AS actual_production_min,
        ROW_NUMBER() OVER (
            PARTITION BY USERID, LOGINDATE 
            ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= '2026-03-17'
      AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
      AND PYREPORTTO IN ('A', 'D', '5', '0', '3', '9', '8')
      AND USERID IN (SELECT userid FROM users_with_work) 
      AND TOTALSYSTEMTIME IS NOT NULL
),
user_prod_daily AS (
    SELECT 
        USERID, 
        LOGINDATE, 
        actual_production_min
    FROM user_daily
    WHERE rn = 1 
      AND actual_production_min > 0
),

combined_daily AS (
    SELECT
        COALESCE(i.resolved_date, u.LOGINDATE) AS activity_date,  
        COALESCE(i.userid, u.USERID) AS userid,                 
        COALESCE(i.work_items_completed, 0) AS work_items_completed, 
        COALESCE(i.total_retime_min, 0) AS total_retime_min,        
        COALESCE(u.actual_production_min, 0) AS actual_production_min 
    FROM invntry_daily i
    FULL OUTER JOIN user_prod_daily u 
        ON i.userid = u.USERID
        AND i.resolved_date = u.LOGINDATE
),

grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN d.activity_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', d.activity_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', d.activity_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', d.activity_date)
            ELSE DATE_TRUNC('year', d.activity_date)
        END AS group_key,
        d.activity_date, 
        d.work_items_completed,
        d.total_retime_min,
        d.actual_production_min,
        d.userid
    FROM combined_daily d  
    CROSS JOIN grouping_logic g
)

SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(group_key, 'MM/DD') || ' - ' || TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(
        (SUM(total_retime_min) / NULLIF(SUM(actual_production_min), 0)) * 100,
        2
    ) AS avg_production_pct,
    SUM(work_items_completed) AS total_work_items,
    ROUND(SUM(total_retime_min), 0) AS total_expected_min,
    ROUND(SUM(actual_production_min), 0) AS total_actual_production_min,
    ROUND(
        SUM(actual_production_min) / 
        NULLIF(SUM(total_retime_min) / NULLIF(SUM(work_items_completed), 0), 0),
        0
    ) AS total_expected_tasks,
    COUNT(DISTINCT userid) AS associate_count,
    MIN(activity_date) AS sort_date  
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

## associates_list

**Number of Queries:** 1

### 1. ASSOCIATES_LIST_QUERY

**SQL Query:**

```sql
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE USERID IS NOT NULL 
        AND PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
)
SELECT DISTINCT
    frontline.USERID AS ASSOCIATE_ID,
    frontline.USERNAME AS ASSOCIATE_NAME
FROM frontline
WHERE 1=1

ORDER BY frontline.USERNAME
```

---

## audit_errors_drilldown

**Number of Queries:** 2

### 1. AUDIT_ERROR_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE UPPER(TRIM(i.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      
      AND UPPER(TRIM(PYRESOLVEDUSERID)) IN ('AG01440')
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped i
JOIN audit_profile_deduped ap
  ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
 AND ap.rn = 1
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
WHERE i.rn = 1
```

---

### 2. AUDIT_ERROR_DRILLDOWN_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(i.PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        UPPER(TRIM(i.REPORTTOMANAGERID)) AS MANAGER_ID,
        i.PYRESOLVEDTIMESTAMP,
        i.INTAKESOURCESYSTEM,
        i.INVNTRY_TYPE,
        i.LOB,
        i.PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE UPPER(TRIM(i.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      
      AND UPPER(TRIM(PYRESOLVEDUSERID)) IN ('AG01440')
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(ap.PYSTATUSWORK)) AS AUDIT_STATUS,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        DATE(ap.PXCREATEDATETIME) AS RESOLVED_DATE,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.createtimestamp AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
deduped_user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    ap.AUDIT_CASE_ID AS work_item,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS error_category,
    COALESCE(up.USERNAME, 'N/A') AS associate_name,
    aa.DATE_ASSESSED AS date_assessed,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(i.LOB, 'N/A') AS lob,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(aa.SPECIALISTERRORCORRECTED, 'N/A') AS specialist_error_corrected
FROM invntry_deduped i
JOIN audit_profile_deduped ap
  ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
 AND ap.rn = 1
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
LEFT JOIN deduped_user_profile up
  ON up.USERID = i.ASSOCIATE_ID
 AND up.rn = 1
WHERE i.rn = 1
ORDER BY 
    ap.RESOLVED_DATE DESC,
    ap.AUDIT_CASE_ID,
    aa.ERRORCATEGORY
```

---

## audit_score_drilldown

**Number of Queries:** 2

### 1. AUDIT_SCORE_MANAGER_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,  -- ADDED: Need this for hierarchy validation
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PYRESOLVEDUSERID IN ('AG01440')
      
),
audit_deduped AS (
    -- Deduplicate audit records by (CASE_TO_AUDIT, AUDIT_SUBJECT_ID)
    -- Includes TARGET_AUDIT flag for counting targeted audits
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        PXUPDATEDATETIME::DATE as audit_date,
        TARGET_AUDIT,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Open-FeedbackReview', 'Open-RebuttalReview', 'Open-UpdateAuditCase', 'Resolved-Completed')
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
)
SELECT 
    COUNT(DISTINCT a.PYID) as TOTAL_COUNT,
    SUM(CASE WHEN UPPER(a.TARGET_AUDIT) = 'YES' THEN 1 ELSE 0 END) as TARGET_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT  -- Join inventory work item to audit case
    AND a.rn = 1
WHERE i.rn = 1
```

---

### 2. AUDIT_SCORE_MANAGER_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        INVNTRY_TYPE,
        CYCLE_TIME,  -- ADDED: Get CYCLE_TIME directly from inventory
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PYRESOLVEDUSERID IN ('AG01440')
      
),
audit_deduped AS (
    -- Deduplicate audit records with all display columns
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PXUPDATEDATETIME::DATE as audit_date,
        PLATFORM,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
)
SELECT 
    a.PYID,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK,
    a.LOB,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    i.CYCLE_TIME,  -- MODIFIED: Get CYCLE_TIME directly from inventory (per work item)
    i.INVNTRY_TYPE
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT  -- Join inventory work item to audit case
    AND a.rn = 1
WHERE i.rn = 1
ORDER BY a.audit_date DESC
LIMIT 20 OFFSET 0
```

---

## complete_audit_count_drilldown

**Number of Queries:** 2

### 1. COMPLETED_AUDIT_COUNT_MANAGER_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND a.PYRESOLVEDTIMESTAMP >= '2026-03-17' AND a.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND a.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
```

---

### 2. COMPLETED_AUDIT_COUNT_MANAGER_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND a.PYRESOLVEDTIMESTAMP >= '2026-03-17' AND a.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        AUDIT_SUBJECT_ID,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND a.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
deduped_user_profile AS (
    SELECT
        USERID,
        PYREPORTTO,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
),
audit_cycle_time AS (
    SELECT
        PYRESOLVEDUSERID,
        MAX(CYCLE_TIME) AS CYCLE_TIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE CYCLE_TIME IS NOT NULL
    GROUP BY PYRESOLVEDUSERID
)
SELECT 
    a.PYID AS work_item,
    COALESCE(a.INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(c.CYCLE_TIME::VARCHAR, '0') AS audit_cycle_time,
    COALESCE(a.PYSTATUSWORK, 'N/A') AS audit_resolved_status,
    COALESCE(a.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(a.LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(a.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(a.AUDITOR_ID, 'N/A') AS auditor_id,
    COALESCE(auditor.USERNAME, 'N/A') AS auditor_name,
    COALESCE(a.PLATFORM, 'N/A') AS platform_source_system
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
LEFT JOIN deduped_user_profile auditor
    ON a.AUDITOR_ID = auditor.USERID
    AND auditor.rn = 1
LEFT JOIN audit_cycle_time c
    ON a.AUDIT_SUBJECT_ID = c.PYRESOLVEDUSERID
WHERE i.rn = 1
ORDER BY a.PYRESOLVEDTIMESTAMP DESC
LIMIT 20 OFFSET 0
```

---

## fuse_time_drilldown

**Number of Queries:** 2

### 1. FUSE_TIME_MANAGER_COUNT_QUERY

**SQL Query:**

```sql
WITH associate_hierarchy AS (
    -- Validate hierarchy using inventory table
    -- Get list of associates who reported to specified manager during the period
    -- AND actually completed work (have inventory records)
    SELECT DISTINCT
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS work_date
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '2026-03-17' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND PYRESOLVEDUSERID IN ('AG01440')
      AND REPORTTOMANAGERID IN ('A', 'D', '5', '0', '3', '9', '8')
)
SELECT COUNT(*) as TOTAL_COUNT
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u 
INNER JOIN associate_hierarchy ah
    ON u.USERID = ah.PYRESOLVEDUSERID
    AND u.LOGINDATE = ah.work_date
```

---

### 2. FUSE_TIME_MANAGER_PAGINATED_QUERY

**SQL Query:**

```sql
WITH associate_hierarchy AS (
    -- Validate hierarchy using inventory table
    -- Get list of associates who reported to specified manager during the period
    -- AND actually completed work (have inventory records)
    SELECT DISTINCT
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS work_date
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '2026-03-17' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND PYRESOLVEDUSERID IN ('AG01440')
      AND REPORTTOMANAGERID IN ('A', 'D', '5', '0', '3', '9', '8')
)
SELECT 
    u.USERNAME,
    u.USERID,
    u.LOGINDATE,
    u.FIRSTLOGINTIME,
    u.LASTLOGOUTTIME,
    u.TOTALSYSTEMTIME,
    u.FUSE_NON_PRODUCTIVE_TIME,
    u.PRODUCTIVETIME,
    -- Calculate Other Time: Total - (Productive + Non-Productive)
    COALESCE(u.TOTALSYSTEMTIME, 0) - 
    (COALESCE(
        CASE 
            WHEN u.PRODUCTIVETIME IS NOT NULL AND u.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END, 0
    ) + 
    COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0)) AS OTHER_TIME
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u 
INNER JOIN associate_hierarchy ah
    ON u.USERID = ah.PYRESOLVEDUSERID
    AND u.LOGINDATE = ah.work_date
ORDER BY u.LOGINDATE DESC
LIMIT 20 OFFSET 0
```

---

## header_kpis

**Number of Queries:** 7

### 1. ACTIVE_USERS_COUNT_QUERY

**SQL Query:**

```sql
SELECT COUNT(DISTINCT USERID) AS ACTIVE_USERS
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE LOGINDATE >= DATEADD('day', -7, CURRENT_DATE())
AND PYREPORTTO IN ('A', 'D', '5', '0', '3', '9', '8')
```

---

### 2. AUDIT_SCORE_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
      
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
)
SELECT 
    ROUND(AVG(a.AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT i.PYID) AS total_cases_audited
FROM invntry_deduped i  
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
```

---

### 3. CYCLE_TIME_AVG_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        CYCLE_TIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      
      AND PYRESOLVEDUSERID IN ('AG01440')
      AND CYCLE_TIME IS NOT NULL
)
SELECT 
    COUNT(DISTINCT PYID) AS total_resolved_items,
    ROUND(AVG(CYCLE_TIME), 2) AS avg_cycle_time_seconds,
    ROUND(AVG(CYCLE_TIME) / 60, 2) AS avg_cycle_time_minutes
FROM invntry_deduped
WHERE rn = 1
```

---

### 4. NON_VALUE_ADD_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        ACTIONDECISION,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      
      AND PYRESOLVEDUSERID IN ('AG01440')
)
SELECT 
    COUNT(DISTINCT CASE 
        WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
        THEN PYID 
    END) AS non_value_add_count,
    COUNT(DISTINCT PYID) AS total_closed,
    ROUND(
        COUNT(DISTINCT CASE 
            WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
            THEN PYID 
        END) * 100.0 / NULLIF(COUNT(DISTINCT PYID), 0), 
    2) AS non_value_add_pct
FROM invntry_deduped
WHERE rn = 1
```

---

### 5. PENDED_ITEMS_QUERY

**SQL Query:**

```sql
WITH deduped_invntry AS (
    SELECT DISTINCT
        PYID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1 = 1
      AND LOB IN ('Commercial')
      AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
latest_status AS (
    SELECT
        t.PYID,
        t.PYSTATUSWORK,
        t.PYRESOLVEDTIMESTAMP,
        t.REASSIGNED_TO,
        t.FIRST_ASSIGNED_TO,
        ROW_NUMBER() OVER (
            PARTITION BY t.PYID
            ORDER BY t.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE t
    INNER JOIN deduped_invntry a
        ON t.PYID = a.PYID
)
SELECT
    COUNT(DISTINCT PYID) AS PENDED_ITEMS_COUNT
FROM latest_status
WHERE rn = 1
  AND PYSTATUSWORK LIKE 'Pend%'
  AND PYRESOLVEDTIMESTAMP IS NULL
```

---

### 6. PRODUCTION_PCT_QUERY

**SQL Query:**

```sql
WITH 
invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
       --REPORTTOMANAGERID in ()
      AND PYRESOLVEDUSERID IN ('AG01440') --PYRESOLVEDUSERID in ()
),
associate_work AS (
    SELECT 
        PYRESOLVEDUSERID AS userid,
        COUNT(DISTINCT PYID) AS work_items_completed,
        SUM(RETIME) AS total_retime_min
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID
),
user_daily AS (
    SELECT 
        USERID,
        USERNAME,
        LOGINDATE,
        TOTALSYSTEMTIME,
        non_prdctv_duration AS non_productive_sec,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INT * 60) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 2)::INT) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 3)::INT / 60.0) AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY USERID, LOGINDATE ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
      AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
      AND PYREPORTTO IN ('A', 'D', '5', '0', '3', '9', '8')
      AND USERID IN ('AG01440')
      AND TOTALSYSTEMTIME IS NOT NULL
),
associate_prod AS (
    SELECT 
        USERID AS userid,
        MAX(USERNAME) AS username,
        SUM(actual_production_min) AS total_prod_min
    FROM user_daily
    WHERE rn = 1
      AND actual_production_min > 0
    GROUP BY USERID
)
SELECT 
    ROUND(
        (SUM(w.total_retime_min) / NULLIF(SUM(p.total_prod_min), 0)) * 100,
        2
    ) AS AVG_PRODUCTION_PCT
FROM associate_work w
LEFT JOIN associate_prod p ON w.userid = p.userid
```

---

### 7. WORK_ITEMS_COMPLETED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
        AND LOB IN ('Commercial')
        
        AND PYRESOLVEDUSERID IN ('AG01440')
)
SELECT COUNT(*) AS COMPLETED_TASKS
FROM invntry_deduped
WHERE rn = 1
```

---

## manager_capacity_insight_drilldown

**Number of Queries:** 1

### 1. CAPACITY_INSIGHT_DRILLDOWN_QUERY

**SQL Query:**

```sql
WITH
date_range_config AS (
    SELECT
        '2026-03-17'::DATE AS period_start,
        '2026-03-23'::DATE AS period_end
),
grouping_logic AS (
    SELECT
        DATEDIFF(day, period_start, period_end) + 1 AS total_days,
        'monthly' AS grouping_type  -- Always use monthly grouping for capacity insights
    FROM date_range_config
),
date_spine AS (
    SELECT DATEADD(DAY, SEQ4(), drc.period_start) AS spine_date
    FROM TABLE(GENERATOR(ROWCOUNT => 500))
    CROSS JOIN date_range_config drc
    WHERE DATEADD(DAY, SEQ4(), drc.period_start) <= drc.period_end
),
date_periods AS (
    SELECT DISTINCT
        DATE_TRUNC('MONTH', spine_date) AS period_date,  -- Always monthly for drilldown
        LAST_DAY(DATE_TRUNC('MONTH', spine_date)) AS period_end_date,
        EXTRACT(YEAR FROM spine_date) AS period_year,
        EXTRACT(MONTH FROM spine_date) AS period_month
    FROM date_spine
),
date_spine_for_business_days AS (
    SELECT
        dp.period_date,
        dp.period_end_date,
        DATEADD(DAY, gs.SEQ, dp.period_date) AS business_date
    FROM date_periods dp
    CROSS JOIN (
        SELECT SEQ4() AS SEQ 
        FROM TABLE(GENERATOR(ROWCOUNT => 400))
    ) gs
    LEFT JOIN NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_HOLIDAY_DATA holidays
        ON DATEADD(DAY, gs.SEQ, dp.period_date) = holidays.DATE
    WHERE DATEADD(DAY, gs.SEQ, dp.period_date) <= dp.period_end_date
      AND DATEADD(DAY, gs.SEQ, dp.period_date) <= (SELECT period_end FROM date_range_config)  -- Only count days within requested range
      AND DATEADD(DAY, gs.SEQ, dp.period_date) >= (SELECT period_start FROM date_range_config)  -- Only count days within requested range
      AND DAYNAME(DATEADD(DAY, gs.SEQ, dp.period_date)) NOT IN ('Sat', 'Sun')
      AND holidays.DATE IS NULL  -- Exclude holidays
),
business_days_per_period AS (
    SELECT
        dp.period_date,
        dp.period_end_date,
        COALESCE(bd_count.business_days, 0) AS business_days
    FROM date_periods dp
    LEFT JOIN (
        SELECT 
            period_date,
            COUNT(*) AS business_days
        FROM date_spine_for_business_days
        GROUP BY period_date
    ) bd_count ON dp.period_date = bd_count.period_date
),
productive_hrs AS (
    -- Total Fuse Time Hours per day - Dynamic based on past 90 days from end date
    -- Using logic: (Total System Time - Non Productive Time) / 3600.0 to convert seconds to hours
    SELECT
        ROUND(AVG(
            SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT
            + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0
            + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
        ), 2) AS avg_hrs_per_day
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
      AND u.TOTALSYSTEMTIME IS NOT NULL
      AND u.LOGINDATE BETWEEN DATEADD(day, -90, (SELECT period_end FROM date_range_config)) AND (SELECT period_end FROM date_range_config)
),
avail_fte_by_period AS (
    SELECT
        DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE)) AS period_date,  -- Always monthly
        COUNT(DISTINCT w.EMPLOYEE_DOMAIN_ID) AS available_fte
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT period_start FROM date_range_config) AND (SELECT period_end FROM date_range_config)
    GROUP BY DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE))
),
active_associates AS (
    SELECT DISTINCT
        w.EMPLOYEE_DOMAIN_ID AS USERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT period_start FROM date_range_config) AND (SELECT period_end FROM date_range_config)
),
pto_latest_records AS (
    SELECT
        w.EMPLOYEE_DOMAIN_ID,
        TRY_CAST(w.TIME_OFF_DATE AS DATE) AS TIME_OFF_DATE,
        w.HOURS,
        w.TIME_OFF_TYPE,
        w.TIME_OFF_ENTRY_UNIQUE_KEY,
        ROW_NUMBER() OVER (
            PARTITION BY w.EMPLOYEE_DOMAIN_ID, w.TIME_OFF_DATE, w.TIME_OFF_ENTRY_UNIQUE_KEY
            ORDER BY TRY_CAST(w.ASOFTODAY AS DATE) DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_WORKDAY_HIST w
    INNER JOIN active_associates a ON w.EMPLOYEE_DOMAIN_ID = a.USERID
    WHERE TRY_CAST(w.TIME_OFF_DATE AS DATE) IS NOT NULL
      AND TRY_CAST(w.TIME_OFF_DATE AS DATE) BETWEEN (SELECT period_start FROM date_range_config) AND (SELECT period_end FROM date_range_config)
      AND w.STATUS = 'Approved'
      AND w.HOURS IS NOT NULL
      AND (w.TIME_OFF_TYPE ILIKE '%Paid Time Off%' 
           OR w.TIME_OFF_TYPE ILIKE '%Non Paid Time%'
           OR w.TIME_OFF_TYPE ILIKE '%Sick Time%'
           OR w.TIME_OFF_TYPE ILIKE '%Other Paid Time%'
           OR w.TIME_OFF_TYPE ILIKE '%Paid Parental Leave%'
           OR w.TIME_OFF_TYPE ILIKE '%Wellness Days%'
           OR w.TIME_OFF_TYPE ILIKE '%On Leave%'
           OR w.TIME_OFF_TYPE ILIKE '%Critical Care Leave%')
),
pto_by_employee_by_day AS (
    SELECT
        EMPLOYEE_DOMAIN_ID,
        TIME_OFF_DATE,
        TIME_OFF_TYPE,
        SUM(HOURS) AS net_hours_per_day
    FROM pto_latest_records
    WHERE rn = 1
    GROUP BY EMPLOYEE_DOMAIN_ID, TIME_OFF_DATE, TIME_OFF_TYPE
),
-- Separate PTO calculation (all except "Non Paid Time")
pto_by_employee_by_period AS (
    SELECT
        DATE_TRUNC('MONTH', pto.TIME_OFF_DATE) AS period_date,  -- Always monthly
        pto.EMPLOYEE_DOMAIN_ID,
        SUM(pto.net_hours_per_day) AS total_pto_hours_per_employee
    FROM pto_by_employee_by_day pto
    WHERE pto.net_hours_per_day > 0
      AND pto.TIME_OFF_TYPE NOT ILIKE '%Non Paid Time%'
    GROUP BY DATE_TRUNC('MONTH', pto.TIME_OFF_DATE), pto.EMPLOYEE_DOMAIN_ID
),
pto_total_by_period AS (
    SELECT
        period_date,
        SUM(total_pto_hours_per_employee) AS total_pto_hours
    FROM pto_by_employee_by_period
    GROUP BY period_date
),
-- Separate UTO calculation (only "Non Paid Time")
uto_by_employee_by_period AS (
    SELECT
        DATE_TRUNC('MONTH', uto.TIME_OFF_DATE) AS period_date,  -- Always monthly
        uto.EMPLOYEE_DOMAIN_ID,
        SUM(uto.net_hours_per_day) AS total_uto_hours_per_employee
    FROM pto_by_employee_by_day uto
    WHERE uto.net_hours_per_day > 0
      AND uto.TIME_OFF_TYPE ILIKE '%Non Paid Time%'
    GROUP BY DATE_TRUNC('MONTH', uto.TIME_OFF_DATE), uto.EMPLOYEE_DOMAIN_ID
),
uto_total_by_period AS (
    SELECT
        period_date,
        SUM(total_uto_hours_per_employee) AS total_uto_hours
    FROM uto_by_employee_by_period
    GROUP BY period_date
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.CYCLE_TIME,
        DATE(inv.pxcreatedatetime) AS resolve_date,
        DATE_TRUNC('WEEK', inv.pxcreatedatetime) AS week_start,
        DATE_TRUNC('MONTH', inv.pxcreatedatetime) AS month_start,
        DATE_TRUNC('QUARTER', inv.pxcreatedatetime) AS quarter_start,
        DATE_TRUNC('YEAR', inv.pxcreatedatetime) AS year_start,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS intakesourcesystem,
        ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY inv.pxupdatedatetime DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE inv
    WHERE pxcreatedatetime >= '2026-03-17' AND pxcreatedatetime < DATEADD(day, 1, '2026-03-23'::DATE)
      AND (LOB IN ('Commercial', 'EGR', 'GRS', 'MMP', 'MedSupp', 'Medicaid', 'Medicare') OR LOB IS NULL)
),
avg_cycle_time AS (
    SELECT
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS intakesourcesystem,
        ROUND(AVG(inv.CYCLE_TIME) / 3600.0, 2) AS avg_cycle_time_hrs
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.CYCLE_TIME IS NOT NULL
      AND inv.PXCREATEDATETIME BETWEEN DATEADD(DAY, -90, (SELECT period_end FROM date_range_config)) AND DATEADD(DAY, 1, (SELECT period_end FROM date_range_config))
    GROUP BY COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown')
),
actual_receipts_by_period AS (
    -- Completed Items = No of work items resolved in the period (Distinct PYID) by intake source system
    SELECT
        month_start AS period_date,  -- Always use monthly for drilldown
        intakesourcesystem,
        COUNT(DISTINCT PYID) AS actual_receipts
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY month_start, intakesourcesystem
),
fte_calculation AS (
    -- Total Fuse Time Hours/day = Dynamic based on past 90 days (Total System Time - Non Productive Time)
    -- For Daily: Total Available Hours per FTE = Total Fuse Time Hours/day * 1 day
    -- For Weekly/Monthly/Quarterly: Total Available Hours per FTE = Total Fuse Time Hours/day * business days in period
    -- Completed Items = No of work items resolved in the period (Distinct PYID)
    -- Total Work Hours Required = Completed Items * Cycle Time (90 days average in hours)
    -- Required FTE = Total Work Hours Required / Total Available Hours per FTE
    SELECT
        ar.period_date,
        ar.intakesourcesystem,
        ar.actual_receipts AS actual_receipts,
        COALESCE(ct.avg_cycle_time_hrs, 0) AS cycle_time_hrs,
        COALESCE((SELECT avg_hrs_per_day FROM productive_hrs), 6.5) AS productive_hrs_per_day,
        bd.business_days,
        af.available_fte,
        -- Total Available Hours per FTE = Total Fuse Time Hours/day * Number of business days
        ROUND(COALESCE((SELECT avg_hrs_per_day FROM productive_hrs), 6.5) * bd.business_days, 2) AS total_available_hrs_per_fte,
        -- Total Work Hours Required = Recieved Items * Cycle Time (hours)
        ROUND(ar.actual_receipts * COALESCE(ct.avg_cycle_time_hrs, 0), 2) AS total_work_hours_required
    FROM actual_receipts_by_period ar
    LEFT JOIN avg_cycle_time ct ON ar.intakesourcesystem = ct.intakesourcesystem
    LEFT JOIN business_days_per_period bd ON ar.period_date = bd.period_date
    LEFT JOIN avail_fte_by_period af ON ar.period_date = af.period_date
),
fte_summary AS (
    SELECT
        fc.period_date,
        -- Aggregate across all intake source systems
        SUM(fc.actual_receipts) AS actual_receipts,
        ROUND(SUM(fc.total_work_hours_required), 2) AS total_work_hours_required,
        MAX(fc.total_available_hrs_per_fte) AS total_available_hrs_per_fte,
        MAX(fc.productive_hrs_per_day) AS productive_hrs_per_day,
        -- Weighted average cycle time
        ROUND(SUM(fc.total_work_hours_required) / NULLIF(SUM(fc.actual_receipts), 0), 2) AS weighted_cycle_time_hrs,
        -- Required FTE = Total Work Hours Required / Total Available Hours per FTE
        CEIL(
            SUM(fc.total_work_hours_required) / NULLIF(MAX(fc.total_available_hrs_per_fte), 0)
        ) AS required_fte
    FROM fte_calculation fc
    GROUP BY fc.period_date
)
SELECT
    TO_VARCHAR(dp.period_date, 'Mon') AS period_label,  -- Always show month name
    EXTRACT(YEAR FROM dp.period_date) AS period_year,
    EXTRACT(MONTH FROM dp.period_date) AS period_month,
    COALESCE(fs.required_fte, 0) AS required_fte,
    COALESCE(fs.total_work_hours_required, 0) AS total_required_hours,
    COALESCE(fs.productive_hrs_per_day, 6.5) AS productive_hrs_per_day,
    COALESCE(bd.business_days, 1) AS business_days,
    COALESCE(pto.total_pto_hours, 0) AS total_pto_hours,
    COALESCE(uto.total_uto_hours, 0) AS total_uto_hours,
    COALESCE(af.available_fte, 0) AS available_fte,
    ROUND(
        (COALESCE(af.available_fte, 0) * COALESCE(bd.business_days, 1) * 8) - 
        COALESCE(pto.total_pto_hours, 0) - COALESCE(uto.total_uto_hours, 0),
        2
    ) AS total_available_hours
FROM date_periods dp
LEFT JOIN fte_summary fs ON dp.period_date = fs.period_date
INNER JOIN avail_fte_by_period af ON dp.period_date = af.period_date  -- Only show months with ASOFTODAY data
LEFT JOIN business_days_per_period bd ON dp.period_date = bd.period_date
LEFT JOIN pto_total_by_period pto ON dp.period_date = pto.period_date
LEFT JOIN uto_total_by_period uto ON dp.period_date = uto.period_date
ORDER BY EXTRACT(YEAR FROM dp.period_date), EXTRACT(MONTH FROM dp.period_date)
```

---

## manager_list

**Number of Queries:** 1

### 1. MANAGERS_LIST_QUERY

**SQL Query:**

```sql
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO,
        REPORTTOUSERNAME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
),
manager AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYACCESSGROUP
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
)
SELECT DISTINCT
    manager.USERID AS MANAGER_ID,
    manager.USERNAME AS MANAGER_NAME
FROM frontline
INNER JOIN manager
    ON frontline.PYREPORTTO = manager.USERID
WHERE manager.USERID IS NOT NULL
  AND manager.USERNAME IS NOT NULL
  
ORDER BY manager.USERNAME
```

---

## manager_lob

**Number of Queries:** 2

### 1. MANAGER_LOB_AUDIT_QUERY

**SQL Query:**

```sql
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    AND PYRESOLVEDUSERID IN ('AG01440')
```

---

### 2. MANAGER_LOB_INVENTORY_QUERY

**SQL Query:**

```sql
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    
    AND PYRESOLVEDUSERID IN ('AG01440')
```

---

## pended_items_counts_drilldown

**Number of Queries:** 2

### 1. PENDED_ITEMS_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_invntry AS (
    SELECT DISTINCT
        PYID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1 = 1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('AG01440')
),
latest_status AS (
    SELECT
        t.PYID,
        t.PYSTATUSWORK,
        t.PYRESOLVEDTIMESTAMP,
        t.REASSIGNED_TO,
        t.FIRST_ASSIGNED_TO,
        ROW_NUMBER() OVER (
            PARTITION BY t.PYID
            ORDER BY t.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE t
    INNER JOIN deduped_invntry a
        ON t.PYID = a.PYID
)
SELECT
    COUNT(DISTINCT PYID) AS TOTAL_COUNT
FROM latest_status
WHERE rn = 1
  AND PYSTATUSWORK LIKE 'Pend%'
  AND PYRESOLVEDTIMESTAMP IS NULL
```

---

### 2. PENDED_ITEMS_PAGINATED_QUERY

**SQL Query:**

```sql
WITH deduped_invntry AS (
    SELECT DISTINCT
        PYID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1 = 1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('AG01440')
),
latest_status AS (
    SELECT
        t.PYID,
        t.INTAKESOURCESYSTEM,
        t.PYSTATUSWORK,
        t.LOB,
        t.PXCREATEDATETIME,
        t.PXUPDATEDATETIME,
        t.PEND_CREATE_DT,
        t.PEND_RESOLVED_DT,
        t.INTERNALDUEDATE,
        COALESCE(t.REASSIGNED_TO, t.FIRST_ASSIGNED_TO) AS assigned_user,
        t.PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY t.PYID
            ORDER BY t.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE t
    INNER JOIN deduped_invntry a
        ON t.PYID = a.PYID
),
user_profile_deduped AS (
    SELECT
        USERID,
        PYREPORTTO,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS worktype_category,
    i.PYSTATUSWORK AS status,
    i.LOB,
    DATEDIFF('day', i.PEND_CREATE_DT, COALESCE(i.PEND_RESOLVED_DT, CURRENT_DATE)) AS days_pended,
    i.PEND_CREATE_DT AS pend_date,
    i.INTERNALDUEDATE AS due_date,
    i.PEND_RESOLVED_DT AS resolved_date,
    u.USERNAME AS associate_name
FROM latest_status i
INNER JOIN user_profile_deduped u
    ON i.assigned_user = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
  AND i.PYSTATUSWORK LIKE 'Pend%'
  AND i.PYRESOLVEDTIMESTAMP IS NULL
ORDER BY i.PXCREATEDATETIME DESC
LIMIT 20 OFFSET 0
```

---

## production_pct_achieved_drilldown

**Number of Queries:** 2

### 1. PRODUCTION_PCT_ACHIEVED_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      
      AND PYRESOLVEDUSERID IN ('AG01440')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped
WHERE rn = 1
```

---

### 2. PRODUCTION_PCT_ACHIEVED_QUERY

**SQL Query:**

```sql
WITH
invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        CYCLE_TIME,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        MARKET,
        PLATFORM,
        ACTIVITYCODE,
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PYRESOLVEDUSERID IN ('AG01440')
      
),
invntry_daily AS (
    SELECT
        PYRESOLVEDUSERID AS userid,
        resolved_date,
        COUNT(DISTINCT PYID) AS work_items_completed,
        SUM(RETIME) AS total_retime_min
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID, resolved_date
),
user_daily AS (
    SELECT
        USERID,
        USERNAME,
        LOGINDATE,
        TOTALSYSTEMTIME,
        non_prdctv_duration AS non_productive_sec,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INT * 60) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 2)::INT) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 3)::INT / 60.0) AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY USERID, LOGINDATE ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
      AND USERID IN ('AG01440')
      AND TOTALSYSTEMTIME IS NOT NULL
),
daily_metrics AS (
    SELECT
        i.userid,
        u.USERNAME,
        i.resolved_date,
        i.work_items_completed,
        i.total_retime_min,
        u.actual_production_min
    FROM invntry_daily i
    INNER JOIN user_daily u
        ON i.userid = u.USERID
        AND i.resolved_date = u.LOGINDATE
    WHERE u.rn = 1
      AND u.actual_production_min > 0
),
aggregated_totals AS (
    SELECT
        userid,
        MAX(USERNAME) AS USERNAME,
        SUM(work_items_completed) AS total_work_items,
        SUM(total_retime_min) AS total_retime_min,
        SUM(actual_production_min) AS total_actual_production_min,
        COUNT(DISTINCT resolved_date) AS work_days,
        ROUND(
            (SUM(total_retime_min) / NULLIF(SUM(actual_production_min), 0)) * 100,
            2
        ) AS production_pct_achieved,
        ROUND(
            SUM(actual_production_min) / NULLIF(SUM(total_retime_min) / NULLIF(SUM(work_items_completed), 0), 0),
            0
        ) AS total_expected_tasks
    FROM daily_metrics
    GROUP BY userid
),
user_profile_deduped AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYRESOLVEDUSERID AS associate,
    COALESCE(u.USERNAME, p.USERNAME) AS associate_name,
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS worktype,
    i.RETIME AS standard_time,
    i.CYCLE_TIME AS case_cycle_time,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.MARKET,
    i.PLATFORM,
    TO_CHAR(i.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY') AS resolved_date,
    i.ACTIVITYCODE AS activity_code,
    'View Details' AS action,
    p.total_work_items,
    p.total_retime_min AS total_expected_min,
    ROUND(p.total_actual_production_min, 0) AS total_actual_production_min,
    p.total_expected_tasks,
    p.production_pct_achieved
FROM invntry_deduped i
INNER JOIN aggregated_totals p
    ON i.PYRESOLVEDUSERID = p.userid
LEFT JOIN user_profile_deduped u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT 20 OFFSET 0
```

---

## quality_outcomes

**Number of Queries:** 7

### 1. AUDIT_ERROR_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(i.PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        UPPER(TRIM(i.REPORTTOMANAGERID)) AS MANAGER_ID,
        i.PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE UPPER(TRIM(i.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(ap.PYSTATUSWORK)) AS AUDIT_STATUS,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
final_base AS (
    SELECT
        i.MANAGER_ID,
        i.ASSOCIATE_ID,
        i.ORIGINAL_OHI_CASE_ID,
        i.PYRESOLVEDTIMESTAMP,
        ap.AUDIT_CASE_ID,
        ap.AUDIT_STATUS,
        ap.AUDIT_CREATE_TIMESTAMP,
        ap.AUDIT_UPDATE_TIMESTAMP,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        aa.RESULTTYPE,
        aa.DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.ACTIVITY_UPDATE_TIMESTAMP
    FROM invntry_deduped i
    JOIN audit_profile_deduped ap
      ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
     AND ap.rn = 1
    JOIN audit_activity_deduped aa
      ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
     AND aa.rn = 1
    WHERE i.rn = 1
)
SELECT
    COUNT(DISTINCT ORIGINAL_OHI_CASE_ID) AS COMPLETED_INVENTORY_CASES_AUDITED,
    COUNT(DISTINCT AUDIT_CASE_ID) AS COMPLETED_AUDIT_CASES,
    COUNT(DISTINCT AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS AUDIT_ERROR_COUNT,
    COUNT(DISTINCT CASE
        WHEN UPPER(TRIM(NVL(SPECIALISTERRORCORRECTED, 'NO'))) IN ('Y', 'YES')
        THEN AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS CORRECTED_ERROR_COUNT,
    COUNT(DISTINCT CASE
        WHEN UPPER(TRIM(NVL(SPECIALISTERRORCORRECTED, 'NO'))) IN ('N', 'NO')
        THEN AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS NOT_CORRECTED_ERROR_COUNT
FROM final_base
```

---

### 2. COMPLETED_AUDIT_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        AUDIT_SUBJECT_ID,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND LOB IN ('Commercial')
      
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
```

---

### 3. FUSE_TIME_QUERY

**SQL Query:**

```sql
SELECT 
    SUM(COALESCE(u.TOTALSYSTEMTIME, 0)) AS TOTAL_FUSE_TIME_SECONDS
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
```

---

### 4. REBUTTAL_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PYRESOLVEDTIMESTAMP DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        PYRESOLVEDTIMESTAMP AS audit_resolved_timestamp,
        DATE(PYRESOLVEDTIMESTAMP) AS audit_resolved_date,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(TRIM(REBUTTALFLAG)) = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      AND LOB IN ('Commercial')
      
),
audit_activity_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT a.PYID) AS unique_audit_cases_with_rebuttals,
    COUNT(*) AS total_rebuttal_records
FROM invntry_deduped i
INNER JOIN audit_deduped a 
    ON i.PYID = a.CASE_TO_AUDIT 
    AND a.rn = 1
LEFT JOIN audit_activity_deduped act 
    ON a.PYID = act.CASEID 
    AND act.rn = 1
WHERE i.rn = 1
  AND act.ERRORCATEGORYTYPE IS NOT NULL
  AND act.ERRORCATEGORY IS NOT NULL
```

---

### 5. REBUTTAL_OVERTURN_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PYRESOLVEDTIMESTAMP DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        PYRESOLVEDTIMESTAMP AS audit_resolved_timestamp,
        DATE(PYRESOLVEDTIMESTAMP) AS audit_resolved_date,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(TRIM(REBUTTALFLAG)) = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      AND LOB IN ('Commercial')
      
),
audit_activity_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
rebuttal_outcome_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        UPPER(TRIM(REBUTTALOUTCOME)) AS REBUTTALOUTCOME,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE REBUTTALOUTCOME IS NOT NULL
)
SELECT
    COUNT(DISTINCT a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS total_rebuttals,
    COUNT(DISTINCT CASE 
        WHEN ro.REBUTTALOUTCOME IN ('ERROR RETRACTED', 'FYI RETRACTED', 'CHANGED TO FYI')
        THEN a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS overturned_count
FROM invntry_deduped i
INNER JOIN audit_deduped a 
    ON i.PYID = a.CASE_TO_AUDIT 
    AND a.rn = 1
LEFT JOIN audit_activity_deduped act 
    ON a.PYID = act.CASEID 
    AND act.rn = 1
LEFT JOIN rebuttal_outcome_deduped ro 
    ON a.PYID = ro.CASEID 
    AND act.ERRORCATEGORYTYPE = ro.ERRORCATEGORYTYPE
    AND act.ERRORCATEGORY = ro.ERRORCATEGORY
    AND ro.rn = 1
WHERE i.rn = 1
  --AND act.ERRORCATEGORYTYPE IS NOT NULL
  --AND act.ERRORCATEGORY IS NOT NULL
```

---

### 6. REWORK_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PXCREATEDATETIME >= '2026-03-17' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        
        AND PYRESOLVEDUSERID IN ('AG01440')
)
SELECT
    COUNT(DISTINCT a.PYID) AS REWORK_COUNT
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
WHERE a.rn = 1
```

---

### 7. WATCHLIST_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('Commercial')
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      
      
)
SELECT
    COUNT(DISTINCT PYID) AS WATCHLIST_COUNT
FROM invntry_deduped 
WHERE rn = 1
```

---

## rebuttal_drilldown

**Number of Queries:** 2

### 1. REBUTTAL_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PYRESOLVEDTIMESTAMP DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        PYRESOLVEDTIMESTAMP AS audit_resolved_timestamp,
        DATE(PYRESOLVEDTIMESTAMP) AS audit_resolved_date,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(TRIM(REBUTTALFLAG)) = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
audit_activity_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT a.PYID) AS unique_audit_cases_with_rebuttals,
    COUNT(*) AS total_rebuttal_records
FROM invntry_deduped i
INNER JOIN audit_deduped a 
    ON i.PYID = a.CASE_TO_AUDIT 
    AND a.rn = 1
LEFT JOIN audit_activity_deduped act 
    ON a.PYID = act.CASEID 
    AND act.rn = 1
WHERE i.rn = 1
  AND act.ERRORCATEGORYTYPE IS NOT NULL
  AND act.ERRORCATEGORY IS NOT NULL
```

---

### 2. REBUTTAL_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PYRESOLVEDTIMESTAMP DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PYRESOLVEDTIMESTAMP AS audit_resolved_timestamp,
        DATE(PYRESOLVEDTIMESTAMP) AS audit_resolved_date,
        PLATFORM,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE UPPER(TRIM(REBUTTALFLAG)) = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
deduped_user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
),
audit_activity_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
rebuttal_outcome_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        UPPER(TRIM(REBUTTALOUTCOME)) AS REBUTTALOUTCOME,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
    WHERE REBUTTALOUTCOME IS NOT NULL
)
SELECT
    a.PYID as work_item_id,
    a.INTAKESOURCESYSTEM as worktype_category,
    a.PYSTATUSWORK as outcome_status,
    a.LOB,
    i.resolved_date as resolved_date,
    a.AUDIT_SUBJECT_ID as audit_subject_id,
    u.USERNAME as auditor_name,
    a.PLATFORM as platform_source_system,
    COALESCE(act.ERRORCATEGORY, 'N/A') as error_category,
    COALESCE(act.ERRORCATEGORYTYPE, 'N/A') as error_type,
    COALESCE(ro.REBUTTALOUTCOME, 'N/A') as rebuttal_outcome
FROM invntry_deduped i
INNER JOIN audit_deduped a 
    ON i.PYID = a.CASE_TO_AUDIT 
    AND a.rn = 1
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
LEFT JOIN audit_activity_deduped act 
    ON a.PYID = act.CASEID 
    AND act.rn = 1
LEFT JOIN rebuttal_outcome_deduped ro 
    ON a.PYID = ro.CASEID 
    AND act.ERRORCATEGORYTYPE = ro.ERRORCATEGORYTYPE
    AND act.ERRORCATEGORY = ro.ERRORCATEGORY
    AND ro.rn = 1
WHERE i.rn = 1
  AND act.ERRORCATEGORYTYPE IS NOT NULL
  AND act.ERRORCATEGORY IS NOT NULL
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT 20 OFFSET 0
```

---

## rework_drilldown

**Number of Queries:** 2

### 1. REWORK_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PXCREATEDATETIME >= '2026-03-17' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        
        AND PYRESOLVEDUSERID IN ('AG01440')
)
SELECT
    COUNT(DISTINCT a.PYID) AS TOTAL_COUNT
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
WHERE a.rn = 1
```

---

### 2. REWORK_PAGINATED_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        AUDITOR_ID,
        AUDIT_SCORE,
        CASE_TO_AUDIT,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PXCREATEDATETIME >= '2026-03-17' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        
        AND PYRESOLVEDUSERID IN ('AG01440')
),
deduped_user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
),
invntry_deduped AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
)
SELECT
    a.PYID AS work_item,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(i.PYSTATUSWORK, 'N/A') AS resolved_status,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    a.LOB,
    a.resolved_date,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(CAST(a.AUDIT_SCORE AS VARCHAR), 'N/A') AS audit_score,
    COALESCE(auditor.USERNAME, u.USERNAME, 'N/A') AS auditor_name
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
LEFT JOIN deduped_user_profile auditor
    ON a.AUDITOR_ID = auditor.USERID
    AND auditor.rn = 1
LEFT JOIN invntry_deduped i
    ON a.CASE_TO_AUDIT = i.PYID
    AND i.rn = 1
WHERE a.rn = 1
ORDER BY a.resolved_date DESC, a.PYID
LIMIT 20 OFFSET 0
```

---

## user_activity

**Number of Queries:** 4

### 1. LOGIN_LOGOUT_QUERY

**SQL Query:**

```sql
SELECT 
    DATE(LOGINTIME) as LOGINDATE,
    TO_CHAR(LOGINTIME, 'HH12:MI AM') || ' ET' as login_time,
    TO_CHAR(LOGOUTTIME, 'HH12:MI AM') || ' ET' as logout_time
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_ACTIVITY
WHERE DOMAINID = ''
AND DATE(LOGINTIME) = CURRENT_DATE()
ORDER BY LOGINTIME ASC
```

---

### 2. RAMP_QUERY

**SQL Query:**

```sql
SELECT EXPERIENCELEVEL
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = ''
AND LOGINDATE >= '2026-03-17'
AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
ORDER BY LOGINDATE DESC
LIMIT 1
```

---

### 3. RANK_QUERY

**SQL Query:**

```sql
SELECT 
    ROUND(AVG(TEAMRANK))::INT AS TEAMRANK,
    ROUND(AVG(DEPTRANK))::INT AS DEPTRANK
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = ''
AND LOGINDATE >= '2026-03-17'
AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
AND TEAMRANK IS NOT NULL
AND DEPTRANK IS NOT NULL
```

---

### 4. SKILLED_SOURCES_QUERY

**SQL Query:**

```sql
SELECT DISTINCT SKILLDESCRIPTION
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_SKILLS
WHERE USERID = ''
AND DATE(PXCOMMITDATETIME) = (
    SELECT MAX(DATE(PXCOMMITDATETIME))
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_SKILLS
    WHERE USERID = ''
)
```

---

## watchlist_manager_drilldown

**Number of Queries:** 2

### 1. WATCHLIST_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PXCREATEDATETIME >= '2026-03-17' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      
      AND PYRESOLVEDUSERID IN ('AG01440')
)
SELECT
    COUNT(DISTINCT PYID) AS WATCHLIST_COUNT
FROM invntry_deduped 
WHERE rn = 1
```

---

### 2. WATCHLIST_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PLATFORM,
        INVNTRY_TYPE,
        ISADDTOWATCHLIST,
        PYRESOLVEDUSERID,
        PXCREATEDATETIME,
        EXTERNALDUEDATE,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PXCREATEDATETIME >= '2026-03-17' AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      
      AND PYRESOLVEDUSERID IN ('AG01440')
),
deduped_user_profile AS (
    SELECT 
        USERID,
        PYREPORTTO,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYID AS work_item,
    i.INTAKESOURCESYSTEM AS work_type,
    u.USERNAME AS associate,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.PLATFORM,
    i.EXTERNALDUEDATE AS elv_due_date
FROM invntry_deduped i
INNER JOIN deduped_user_profile u
    ON i.PYRESOLVEDUSERID = u.USERID
WHERE i.rn = 1
  AND u.rn = 1
ORDER BY i.PXCREATEDATETIME DESC
LIMIT 20 OFFSET 0
```

---

## work_items_drilldown

**Number of Queries:** 2

### 1. WORK_ITEMS_MANAGER_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        i.PYID,
        ROW_NUMBER() OVER (PARTITION BY i.PYID ORDER BY i.RETIME DESC NULLS LAST, i.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE i.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND i.PYRESOLVEDTIMESTAMP >= '2026-03-17' AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
        AND i.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
        
        AND i.PYRESOLVEDUSERID IN ('AG01440')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped
WHERE rn = 1
```

---

### 2. WORK_ITEMS_MANAGER_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        i.PYID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.PYSTATUSWORK,
        i.LOB,
        i.INVNTRY_TYPE,
        i.PYRESOLVEDTIMESTAMP,
        i.PYRESOLVEDUSERID,
        i.PLATFORM,
        i.RETIME,
        ROW_NUMBER() OVER (PARTITION BY i.PYID ORDER BY i.RETIME DESC NULLS LAST, i.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE i.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND i.PYRESOLVEDTIMESTAMP >= '2026-03-17' AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
        AND i.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
        
        AND i.PYRESOLVEDUSERID IN ('AG01440')
),
user_profile_deduped AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYID,
    i.INTAKESOURCESYSTEM,
    i.CYCLE_TIME,
    i.PYSTATUSWORK,
    i.LOB,
    i.PYRESOLVEDTIMESTAMP,
    i.PYRESOLVEDUSERID,
    u.USERNAME AS ASSOCIATE_NAME,
    i.PLATFORM,
    i.INVNTRY_TYPE
FROM invntry_deduped i
LEFT JOIN user_profile_deduped u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT 20 OFFSET 0
```

---

## Summary

### Queries per Module

| Module | Query Count |
|--------|-------------|
| associate_utilization | 5 |
| associates_list | 1 |
| audit_errors_drilldown | 2 |
| audit_score_drilldown | 2 |
| complete_audit_count_drilldown | 2 |
| fuse_time_drilldown | 2 |
| header_kpis | 7 |
| manager_capacity_insight_drilldown | 1 |
| manager_list | 1 |
| manager_lob | 2 |
| pended_items_counts_drilldown | 2 |
| production_pct_achieved_drilldown | 2 |
| quality_outcomes | 7 |
| rebuttal_drilldown | 2 |
| rework_drilldown | 2 |
| user_activity | 4 |
| watchlist_manager_drilldown | 2 |
| work_items_drilldown | 2 |

### Test Payload Used

```json
{
  "user_id": "AD50398",
  "start_date": "2026-03-17",
  "end_date": "2026-03-23",
  "lob": [
    "Commercial"
  ],
  "frontline_associate_ids": [
    "AG01440"
  ]
}
```

### Pagination Payload Used

```json
{
  "user_id": "AD50398",
  "start_date": "2026-03-17",
  "end_date": "2026-03-23",
  "lob": [
    "CSBD",
    "Commercial",
    "CrossOver",
    "EGR",
    "GRS",
    "Group Retiree Solutions",
    "INT",
    "KCP",
    "MDR",
    "MMP",
    "MedSupp",
    "Medicaid",
    "Medicare",
    "PDP",
    "SUP",
    "Supplemental"
  ],
  "frontline_associate_ids": [
    "AG01440"
  ],
  "page": 1,
  "page_size": 20
}
```
