# idiscovery-cob-dashboard-service

COB Dashboard Service for iDiscovery - Direct Snowflake API

## Purpose

This service provides direct REST API access to Snowflake database for performance comparison with MCP-based access.

## Capabilities:

1. Basic healthcheck endpoint
2. Direct Snowflake database query endpoint
3. Data processing endpoint

```bash
# Install
poetry install

# Run
poetry run python src/idiscovery-cob-dashboard-service.py
```

## Running Tests

The project includes comprehensive test suites for API functionality and data handling:

```bash

# Run specific test file
poetry run pytest tests/test_director_apis.py
poetry run pytest tests/test_director_list_handling.py

```

### Test Files

- **`test_director_apis.py`** - Tests for API endpoints and functionality
- **`test_director_list_handling.py`** - Tests for data processing and list handling

## Credential Configuration

Snowflake credentials are managed via a **SecretHandler** pattern supporting two modes:

### Local Development (OS Environment Variables)
```bash
export SECRET_HANDLER_TYPE=os  # default
export SNOWFLAKE_USER=your_user
export SNOWFLAKE_PASSWORD=your_password
export SNOWFLAKE_ACCOUNT=your_account
export SNOWFLAKE_ROLE=your_role
export SNOWFLAKE_WAREHOUSE=your_warehouse
export SNOWFLAKE_DATABASE=your_database
export SNOWFLAKE_SCHEMA=your_schema
```

### Production (Vault)
```bash
export SECRET_HANDLER_TYPE=vault
```
Vault credentials are read from `/vault/secrets/creds` file with keys:
- `SNOWFLAKE_USER`
- `SNOWFLAKE_PASSWORD`

Non-sensitive config (ACCOUNT, ROLE, WAREHOUSE, DATABASE, SCHEMA) remains in environment variables.

## API Endpoints

```json
{
  "query": "SELECT * FROM table LIMIT 10",
  "limit": 10
}
```

**GET** `/health` - Health check

## API Documentation

Visit `http://localhost:8001/docs` for interactive Swagger UI. 
