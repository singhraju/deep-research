# Release Notes

## [0.7.0] - 21-August-2026

### Added
- Updated Frontline, Manager, FL Auditor and Auditor Manager Dashboards in Performance IQ

## [0.6.0] - 12-June-2026

### Added
- Added Performance Improvements in Performace IQ

## [0.5.0] - 22-May-2026

### Added
- Fixed Role Base Acess to pick latest pyaccessgroup 


## [0.4.0] - 15-May-2026

### Added
- Enabled Director, Manager and Auditor Manager views for Performance IQ
- Minor Fixes for Frontline and FL Auditor views in Performance IQ

## [0.1.0] - 13-March-2026

### Added
- Performance IQ Dashboard Changes



## [0.1.0] - 02-FEB-2026

### Added

- Initial release of COB Dashboard healthcheck service
- Basic healthcheck endpoints: `/`, `/health`, `/healthcheck`
- FastAPI-based service with CORS middleware
- Certificate management for AWS/SSL connections 
