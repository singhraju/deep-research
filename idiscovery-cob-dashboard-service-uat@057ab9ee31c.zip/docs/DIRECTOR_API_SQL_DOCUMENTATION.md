# Performance IQ Director API - SQL Documentation

**Generated:** 2026-04-09 16:27:21

**Total APIs:** 28
**Total SQL Queries:** 52

## Table of Contents

1. [associate_utilization](#associate-utilization) (4 queries)
2. [associates_list](#associates-list) (1 queries)
3. [audit_sample_pct_drilldown](#audit-sample-pct-drilldown) (1 queries)
4. [audit_score_director_drilldown](#audit-score-director-drilldown) (2 queries)
5. [completed_audit_count_drilldown](#completed-audit-count-drilldown) (2 queries)
6. [demand_inventory](#demand-inventory) (6 queries)
7. [director_list](#director-list) (1 queries)
8. [director_lob](#director-lob) (1 queries)
9. [director_user_activity](#director-user-activity) (3 queries)
10. [escalation_count_drilldown](#escalation-count-drilldown) (2 queries)
11. [fuse_time_director_drilldown](#fuse-time-director-drilldown) (2 queries)
12. [header_kpis](#header-kpis) (4 queries)
13. [managers_list](#managers-list) (1 queries)
14. [operational_flow](#operational-flow) (4 queries)
15. [pended_items_counts_drilldown](#pended-items-counts-drilldown) (2 queries)
16. [production_pct_achieved_drilldown](#production-pct-achieved-drilldown) (2 queries)
17. [quality_outcomes](#quality-outcomes) (6 queries)
18. [rebuttal_drilldown](#rebuttal-drilldown) (2 queries)
19. [rework_pct_drilldown](#rework-pct-drilldown) (2 queries)
20. [watchlist_drilldown](#watchlist-drilldown) (2 queries)
21. [work_items_director_drilldown](#work-items-director-drilldown) (2 queries)

---

## associate_utilization

**Number of Queries:** 4

### 1. AUDIT_SCORE_TREND_QUERY

**SQL Query:**

```sql
WITH date_range AS (
    SELECT
        DATEDIFF(day, '2026-03-17'::DATE, '2026-03-23'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoClosedLinked')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= '2026-03-17'
      AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
      AND USERID IN ('AG01440')
      AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
invntry_with_manager AS (
    SELECT 
        i.PYID,
        i.PYRESOLVEDTIMESTAMP,
        i.PYRESOLVEDUSERID
    FROM invntry_deduped i
    INNER JOIN associate_manager_mapping am
        ON i.PYRESOLVEDUSERID = am.USERID
        AND i.resolved_date = am.LOGINDATE
    WHERE i.rn = 1
),
audit_deduped AS (
    SELECT 
        PYID AS audit_id,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        ROW_NUMBER() OVER (
            PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
audit_with_completion_date AS (
    SELECT 
        i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        i.PYID AS case_id,
        a.AUDIT_SUBJECT_ID
    FROM invntry_with_manager i
    INNER JOIN audit_deduped a
        ON i.PYID = a.CASE_TO_AUDIT
        AND a.rn = 1
),
grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE 
            WHEN g.grouping_type = 'daily' THEN a.case_completion_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.case_completion_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.case_completion_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.case_completion_date)
            ELSE DATE_TRUNC('year', a.case_completion_date)
        END AS group_key,
        a.case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        a.case_id,
        a.AUDIT_SUBJECT_ID
    FROM audit_with_completion_date a
    CROSS JOIN grouping_logic g
)
SELECT 
    CASE 
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(group_key, 'MM/DD') || ' - ' || 
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT audit_id) AS total_audits,
    COUNT(DISTINCT case_id) AS total_cases_audited,
    COUNT(DISTINCT AUDIT_SUBJECT_ID) AS total_frontline_audited,
    MIN(case_completion_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

### 2. EXPERIENCE_LEVEL_QUERY

**SQL Query:**

```sql
SELECT 
    EXPERIENCELEVEL AS LEVEL,
    COUNT(DISTINCT USERID) AS COUNT,
    ROUND(COUNT(DISTINCT USERID) * 100.0 / SUM(COUNT(DISTINCT USERID)) OVER (), 2) AS PERCENTAGE
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE EXPERIENCELEVEL IS NOT NULL
AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
AND USERID IN ('AG01440')
AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
GROUP BY EXPERIENCELEVEL
ORDER BY COUNT DESC
```

---

### 3. FUSE_TIME_SUMMARY_QUERY

**SQL Query:**

```sql
SELECT 
    -- Total Fuse Time Hours = Available Hours (Total System Time - Non Productive Time)
    ROUND((SUM(TOTALSYSTEMTIME) / 3600.0) - (SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0), 2) AS TOTAL_FUSE_TIME_HOURS,
    -- OHI Productive Time (NEW - from PRODUCTIVETIME column)
    -- Convert HH:MM:SS string format to hours
    ROUND(SUM(
        CASE 
            WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END
    ) / 3600.0, 2) AS OHI_PRODUCTIVE_TIME_HOURS,
    
    -- Non-Productive Time (FIXED - now using FUSE_NON_PRODUCTIVE_TIME)
    ROUND(SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0, 2) AS TOTAL_NON_PRODUCTIVE_HOURS,
    
    -- Other Time (NEW - calculated as remainder)
    ROUND(
        (SUM(TOTALSYSTEMTIME) / 3600.0) - 
        (SUM(
            CASE 
                WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                    (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                     SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                     SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
                ELSE 0
            END
        ) / 3600.0) - 
        (SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0), 
    2) AS OTHER_TIME_HOURS,
    
    -- Percentages (NEW - for UI chart display)
    ROUND(
        SUM(CASE WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
            (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
             SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
             SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
        ELSE 0 END) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 2
    ) AS PRODUCTIVE_PCT,
    
    ROUND(
        SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 2
    ) AS NON_PRODUCTIVE_PCT,
    
    ROUND(
        100.0 - 
        COALESCE(
            SUM(CASE WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0 END) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 0
        ) -
        COALESCE(
            SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 0
        ), 2
    ) AS OTHER_PCT

FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE TOTALSYSTEMTIME IS NOT NULL
AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
AND USERID IN ('AG01440')
AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
```

---

### 4. PRODUCTION_TREND_QUERY

**SQL Query:**

```sql
WITH date_range AS (
    SELECT
        DATEDIFF(day, '2026-03-17'::DATE, '2026-03-23'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= '2026-03-17'
      AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
      AND USERID IN ('AG01440')
      AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
invntry_daily AS (
    SELECT 
        i.PYRESOLVEDUSERID AS userid,
        i.resolved_date,
        COUNT(DISTINCT i.PYID) AS work_items_completed,
        SUM(i.RETIME) AS total_retime_min
    FROM invntry_deduped i
    INNER JOIN associate_manager_mapping am
        ON i.PYRESOLVEDUSERID = am.USERID
        AND i.resolved_date = am.LOGINDATE
    WHERE i.rn = 1
    GROUP BY i.PYRESOLVEDUSERID, i.resolved_date
),
user_daily AS (
    SELECT 
        USERID,
        LOGINDATE,
        (TOTALSYSTEMTIME - (
            COALESCE(LUNCH_DURATION, 0) + 
            COALESCE(BREAK_DURATION, 0) + 
            COALESCE(NON_PRDCTV_DURATION, 0) + 
            COALESCE(MEETING_DURATION, 0) + 
            COALESCE(OTHER_DURATION, 0)
        )) / 60.0 AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY USERID, LOGINDATE ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
      AND LOGINDATE >= '2026-03-17'
      AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
      AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
      AND USERID IN ('AG01440')
      AND TOTALSYSTEMTIME IS NOT NULL
),
daily_metrics AS (
    SELECT 
        i.userid,
        i.resolved_date,
        i.work_items_completed,
        i.total_retime_min,
        u.actual_production_min,
        i.total_retime_min / NULLIF(i.work_items_completed, 0) AS avg_retime_per_task,
        u.actual_production_min / NULLIF(i.total_retime_min / NULLIF(i.work_items_completed, 0), 0) AS expected_tasks,
        ROUND(
            i.work_items_completed / 
            NULLIF(u.actual_production_min / NULLIF(i.total_retime_min / NULLIF(i.work_items_completed, 0), 0), 0) 
            * 100, 
        2) AS daily_production_pct
    FROM invntry_daily i
    INNER JOIN user_daily u 
        ON i.userid = u.USERID 
        AND i.resolved_date = u.LOGINDATE
    WHERE u.rn = 1
      AND u.actual_production_min > 0
),
grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE 
            WHEN g.grouping_type = 'daily' THEN d.resolved_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', d.resolved_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', d.resolved_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', d.resolved_date)
            ELSE DATE_TRUNC('year', d.resolved_date)
        END AS group_key,
        d.resolved_date,
        d.work_items_completed,
        d.total_retime_min,
        d.actual_production_min,
        d.expected_tasks,
        d.daily_production_pct,
        d.userid
    FROM daily_metrics d
    CROSS JOIN grouping_logic g
)
SELECT 
    CASE 
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(group_key, 'MM/DD') || ' - ' || 
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(daily_production_pct), 2) AS avg_production_pct,
    SUM(work_items_completed) AS total_work_items,
    ROUND(SUM(total_retime_min), 0) AS total_expected_min,
    ROUND(SUM(actual_production_min), 0) AS total_actual_production_min,
    ROUND(SUM(expected_tasks), 0) AS total_expected_tasks,
    COUNT(DISTINCT userid) AS associate_count,
    MIN(resolved_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
```

---

## associates_list

**Number of Queries:** 1

### 1. ASSOCIATES_LIST_QUERY

**SQL Query:**

```sql
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE USERID IS NOT NULL 
        AND PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
)
SELECT DISTINCT
    frontline.USERID AS ASSOCIATE_ID,
    frontline.USERNAME AS ASSOCIATE_NAME
FROM frontline
WHERE 1=1
AND frontline.PYREPORTTO IN ('SANTICH', 'ROSETSC')
ORDER BY frontline.USERNAME
```

---

## audit_sample_pct_drilldown

**Number of Queries:** 1

### 1. AUDIT_SAMPLE_PCT_QUERY

**SQL Query:**

```sql
WITH deduped_invntry AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
work_items AS (
    SELECT 
        i.PYRESOLVEDUSERID AS USERID,
        COUNT(DISTINCT i.PYID) AS cases_resolved
    FROM deduped_invntry i
    INNER JOIN associate_manager_mapping am
        ON i.PYRESOLVEDUSERID = am.USERID
        AND i.resolved_date = am.LOGINDATE
    WHERE i.rn = 1
    GROUP BY i.PYRESOLVEDUSERID
),
deduped_audit AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        DATE(PXUPDATEDATETIME) AS audit_date,
        ROW_NUMBER() OVER (
            PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PXUPDATEDATETIME >= '2026-03-17'
      AND PXUPDATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
audit_summary AS (
    SELECT 
        a.AUDIT_SUBJECT_ID AS USERID,
        COUNT(DISTINCT CASE WHEN a.PYSTATUSWORK IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN a.CASE_TO_AUDIT END) AS open_audits,
        COUNT(DISTINCT CASE WHEN a.PYSTATUSWORK = 'Resolved-Completed' THEN a.CASE_TO_AUDIT END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN a.PYSTATUSWORK IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN a.CASE_TO_AUDIT END) AS pending_audits,
        COUNT(DISTINCT a.CASE_TO_AUDIT) AS total_audits
    FROM deduped_audit a
    INNER JOIN associate_manager_mapping am
        ON a.AUDIT_SUBJECT_ID = am.USERID
        AND a.audit_date = am.LOGINDATE
    WHERE a.rn = 1
    GROUP BY a.AUDIT_SUBJECT_ID
),
user_profile AS (
    SELECT 
        USERID,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
      AND USERID IN ('AG01440')
)
SELECT 
    u.USERID,
    u.USERNAME AS associate_name,
    COALESCE(a.open_audits, 0) AS open_audits,
    COALESCE(a.closed_audits, 0) AS closed_audits,
    COALESCE(a.pending_audits, 0) AS pending_audits,
    COALESCE(w.cases_resolved, 0) AS total_cases_resolved,
    COALESCE(a.total_audits, 0) AS total_audits,
    ROUND((COALESCE(a.total_audits, 0) * 100.0 / NULLIF(w.cases_resolved, 0)), 2) AS audit_sample_pct
FROM user_profile u
LEFT JOIN work_items w ON u.USERID = w.USERID
LEFT JOIN audit_summary a ON u.USERID = a.USERID
WHERE u.rn = 1
```

---

## audit_score_director_drilldown

**Number of Queries:** 2

### 1. AUDIT_SCORE_DIRECTOR_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoClosedLinked')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
audit_deduped AS (
    SELECT 
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.PXUPDATEDATETIME::DATE as audit_date,
        a.TARGET_AUDIT,
        ROW_NUMBER() OVER (PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SCORE IS NOT NULL
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN ('Open-FeedbackReview', 'Open-RebuttalReview', 'Open-UpdateAuditCase', 'Resolved-Completed')
      AND a.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT 
    COUNT(DISTINCT a.PYID) as TOTAL_COUNT,
    SUM(CASE WHEN UPPER(a.TARGET_AUDIT) = 'YES' THEN 1 ELSE 0 END) as TARGET_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.audit_date = am.LOGINDATE
WHERE i.rn = 1
```

---

### 2. AUDIT_SCORE_DIRECTOR_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        INVNTRY_TYPE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoClosedLinked')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
audit_deduped AS (
    SELECT 
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PYSTATUSWORK,
        a.LOB,
        a.PXUPDATEDATETIME::DATE as audit_date,
        a.PLATFORM,
        ROW_NUMBER() OVER (PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SCORE IS NOT NULL
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      AND a.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
cycle_time_data AS (
    SELECT PYRESOLVEDUSERID,
           MAX(CYCLE_TIME) as CYCLE_TIME  
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    GROUP BY PYRESOLVEDUSERID
)
SELECT 
    a.PYID,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK,
    a.LOB,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    c.CYCLE_TIME,
    i.INVNTRY_TYPE
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.audit_date = am.LOGINDATE
LEFT JOIN cycle_time_data c
    ON a.AUDIT_SUBJECT_ID = c.PYRESOLVEDUSERID
WHERE i.rn = 1
ORDER BY a.audit_date DESC
LIMIT 20 OFFSET 0
```

---

## completed_audit_count_drilldown

**Number of Queries:** 2

### 1. COMPLETED_AUDIT_COUNT_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND a.PYRESOLVEDTIMESTAMP >= '2026-03-17' AND a.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND a.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
WHERE a.rn = 1
```

---

### 2. COMPLETED_AUDIT_COUNT_PAGINATED_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND a.PYRESOLVEDTIMESTAMP >= '2026-03-17' AND a.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND a.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
deduped_user_profile AS (
    SELECT
        USERID,
        PYREPORTTO,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
),
audit_cycle_time AS (
    SELECT
        PYRESOLVEDUSERID,
        MAX(CYCLE_TIME) AS CYCLE_TIME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE CYCLE_TIME IS NOT NULL
    GROUP BY PYRESOLVEDUSERID
)
SELECT 
    a.PYID AS work_item,
    COALESCE(a.INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(c.CYCLE_TIME::VARCHAR, '0') AS audit_cycle_time,
    COALESCE(a.PYSTATUSWORK, 'N/A') AS audit_resolved_status,
    COALESCE(a.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(a.LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(a.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(a.AUDIT_SUBJECT_ID, 'N/A') AS auditor_id,
    COALESCE(u.USERNAME, 'N/A') AS auditor_name,
    COALESCE(a.PLATFORM, 'N/A') AS platform_source_system
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
LEFT JOIN audit_cycle_time c
    ON a.AUDIT_SUBJECT_ID = c.PYRESOLVEDUSERID
WHERE a.rn = 1
  AND u.rn = 1
ORDER BY a.PYRESOLVEDTIMESTAMP DESC
LIMIT  OFFSET 0
```

---

## demand_inventory

**Number of Queries:** 6

### 1. BACKLOG_VOLUME_QUERY

**SQL Query:**

```sql
WITH deduped_inventory AS (
    SELECT 
        PYID,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        ASSIGNEDTO,
        LOB,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('Commercial')
      -- Item existed before end date
      AND PXCREATEDATETIME < '2026-03-23'
      -- Item was still open at end date (not resolved, or resolved after)
      AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= '2026-03-23')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
  i.PYSTATUSWORK,
  COUNT(DISTINCT i.PYID) AS BACKLOG_COUNT
FROM deduped_inventory i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
WHERE i.rn = 1  -- Latest version only
  AND i.PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake',
                         'Open-ReviewIntake', 'Pend', 'Pend-Decision')
GROUP BY i.PYSTATUSWORK
ORDER BY BACKLOG_COUNT DESC
```

---

### 2. ESCALATION_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_inventory AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        PRIORITY,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        ASSIGNEDTO,
        LOB,
        PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('Commercial')
      AND PRIORITY IN ('Instant', 'Immediate')
      -- Item existed before end date
      AND PXCREATEDATETIME < '2026-03-23'
      -- Open or Pending status (these items don't have resolved dates)
      AND (PYSTATUSWORK ILIKE 'Open%' OR PYSTATUSWORK ILIKE 'Pend%')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
    COUNT(DISTINCT i.PYID) AS ESCALATION_COUNT
FROM deduped_inventory i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
WHERE i.rn = 1  -- Latest inventory version only
```

---

### 3. NON_VALUE_ADD_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ACTIONDECISION,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-AutoCloseLink', 'Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND ASSIGNEDTO IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT 
    COUNT(DISTINCT CASE 
        WHEN i.ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
        THEN i.PYID 
    END) AS non_value_add_count,
    COUNT(DISTINCT i.PYID) AS total_closed,
    ROUND(
        COUNT(DISTINCT CASE 
            WHEN i.ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
            THEN i.PYID 
        END) * 100.0 / NULLIF(COUNT(DISTINCT i.PYID), 0), 
    2) AS non_value_add_pct
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
WHERE i.rn = 1
```

---

### 4. PENDED_ITEMS_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXUPDATEDATETIME,
        PEND_CREATE_DT,
        PEND_RESOLVED_DT,
        ASSIGNEDTO,
        PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('Commercial')
      -- Item existed before end date
      AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      -- Pending status (these items don't have resolved dates)
      AND (PYSTATUSWORK ILIKE 'Pend%' OR PYSTATUSWORK ILIKE 'Pending%')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
        AND USERID IN ('AG01440')
)
SELECT
    COUNT(DISTINCT i.PYID) AS PENDED_ITEMS_COUNT
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
WHERE i.rn = 1  -- Latest inventory version only
```

---

### 5. WATCHLIST_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        ISADDTOWATCHLIST,
        PYSTATUSWORK,
        LOB,
        ASSIGNEDTO,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('Commercial')
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
    COUNT(DISTINCT i.PYID) AS WATCHLIST_COUNT
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
WHERE i.rn = 1  -- Latest inventory version only
```

---

### 6. WORK_ITEMS_COMPLETED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
        AND LOB IN ('Commercial')
        AND ASSIGNEDTO IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT COUNT(*) AS COMPLETED_TASKS
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
WHERE i.rn = 1
```

---

## director_list

**Number of Queries:** 1

### 1. DIRECTORS_LIST_QUERY

**SQL Query:**

```sql
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
),
manager AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO,
        REPORTTOUSERNAME
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT DISTINCT  
    manager.PYREPORTTO AS DIRECTOR_ID, 
    manager.REPORTTOUSERNAME AS DIRECTOR_NAME 
FROM frontline 
INNER JOIN manager 
    ON frontline.PYREPORTTO = manager.USERID
WHERE 1=1
ORDER BY manager.REPORTTOUSERNAME
```

---

## director_lob

**Number of Queries:** 1

### 1. DIRECTOR_LOB_QUERY

**SQL Query:**

```sql
SELECT DISTINCT LOB 
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
WHERE LOB IS NOT NULL
    AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
    AND PYRESOLVEDUSERID IN (SELECT USERID FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE WHERE PYREPORTTO IN ('SANTICH', 'ROSETSC'))
    AND PYRESOLVEDUSERID IN ('AG01440')
ORDER BY LOB
```

---

## director_user_activity

**Number of Queries:** 3

### 1. RAMP_QUERY

**SQL Query:**

```sql
SELECT EXPERIENCELEVEL
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = ''
AND LOGINDATE >= '2026-03-17'
AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
ORDER BY LOGINDATE DESC
LIMIT 1
```

---

### 2. RANK_QUERY

**SQL Query:**

```sql
SELECT 
    ROUND(AVG(TEAMRANK))::INT AS TEAMRANK,
    ROUND(AVG(DEPTRANK))::INT AS DEPTRANK
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE USERID = '{{associate_id}}'
AND LOGINDATE >= '{{start_date}}'
AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
AND TEAMRANK IS NOT NULL
AND DEPTRANK IS NOT NULL
```

---

### 3. SKILLED_SOURCES_QUERY

**SQL Query:**

```sql
SELECT DISTINCT SKILLDESCRIPTION
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_SKILLS
WHERE USERID = ''
AND DATE(PXCOMMITDATETIME) = (
    SELECT MAX(DATE(PXCOMMITDATETIME))
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_SKILLS
    WHERE USERID = ''
)
```

---

## escalation_count_drilldown

**Number of Queries:** 2

### 1. ESCALATION_COUNT_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_inventory AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        PRIORITY,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        ASSIGNEDTO,
        LOB,
        PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PRIORITY IN ('Instant', 'Immediate')
      -- Item existed before end date
      AND PXCREATEDATETIME < '2026-03-23'
      -- Open or Pending status (these items don't have resolved dates)
      AND (PYSTATUSWORK ILIKE 'Open%' OR PYSTATUSWORK ILIKE 'Pend%')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
        AND USERID IN ('AG01440')
)
SELECT
    COUNT(DISTINCT i.PYID) AS ESCALATION_COUNT
FROM deduped_inventory i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
WHERE i.rn = 1  -- Latest inventory version only
```

---

### 2. ESCALATION_COUNT_PAGINATED_QUERY

**SQL Query:**

```sql
WITH deduped_inventory AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PRIORITY,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        ASSIGNEDTO,
        LOB,
        PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND PRIORITY IN ('Instant', 'Immediate')
      -- Item existed before end date
      AND PXCREATEDATETIME < '2026-03-23'
      -- Open or Pending status (these items don't have resolved dates)
      AND (PYSTATUSWORK ILIKE 'Open%' OR PYSTATUSWORK ILIKE 'Pend%')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
        AND USERID IN ('AG01440')
),
deduped_user_profile AS (
    SELECT 
        USERID,
        PYREPORTTO,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS workitem_type,
    i.PRIORITY,
    i.PYSTATUSWORK AS status,
    i.LOB,
    i.PLATFORM,
    i.ASSIGNEDTO AS associate_id,
    u.USERNAME AS associate_name
FROM deduped_inventory i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
INNER JOIN deduped_user_profile u
    ON i.ASSIGNEDTO = u.USERID
WHERE i.rn = 1  -- Latest inventory version only
  AND u.rn = 1  -- Latest user profile version only
ORDER BY i.PRIORITY, i.PYID
LIMIT 20 OFFSET 0
```

---

## fuse_time_director_drilldown

**Number of Queries:** 2

### 1. FUSE_TIME_DIRECTOR_COUNT_QUERY

**SQL Query:**

```sql
WITH associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT COUNT(*) as TOTAL_COUNT
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u
INNER JOIN associate_manager_mapping am
    ON u.USERID = am.USERID
    AND u.LOGINDATE = am.LOGINDATE
```

---

### 2. FUSE_TIME_DIRECTOR_PAGINATED_QUERY

**SQL Query:**

```sql
WITH associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT 
    u.USERID,
    u.LOGINDATE,
    u.FIRSTLOGINTIME,
    u.LASTLOGOUTTIME,
    u.TOTALSYSTEMTIME,
    u.FUSE_NON_PRODUCTIVE_TIME,
    u.PRODUCTIVETIME,
    -- Calculate Other Time: Total - Productive - Non-Productive
    COALESCE(u.TOTALSYSTEMTIME, 0) - 
    COALESCE(
        CASE 
            WHEN u.PRODUCTIVETIME IS NOT NULL AND u.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END, 0
    ) - 
    COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0) AS OTHER_TIME
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE u
INNER JOIN associate_manager_mapping am
    ON u.USERID = am.USERID
    AND u.LOGINDATE = am.LOGINDATE
ORDER BY u.LOGINDATE DESC
LIMIT 20 OFFSET 0
```

---

## header_kpis

**Number of Queries:** 4

### 1. AUDIT_SCORE_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoClosedLinked')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
invntry_with_manager AS (
    SELECT 
        i.PYID,
        i.PYRESOLVEDUSERID
    FROM invntry_deduped i
    INNER JOIN associate_manager_mapping am
        ON i.PYRESOLVEDUSERID = am.USERID
        AND i.resolved_date = am.LOGINDATE
    WHERE i.rn = 1
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
)
SELECT 
    ROUND(AVG(a.AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT i.PYID) AS total_cases_audited
FROM invntry_with_manager i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
```

---

### 2. CYCLE_TIME_AVG_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        CYCLE_TIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoClosedLinked')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
      AND CYCLE_TIME IS NOT NULL
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT 
    COUNT(DISTINCT i.PYID) AS total_resolved_items,
    ROUND(AVG(i.CYCLE_TIME), 2) AS avg_cycle_time_seconds,
    ROUND(AVG(i.CYCLE_TIME) / 60, 2) AS avg_cycle_time_minutes
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
WHERE i.rn = 1
  AND USERID IN ('AG01440')
```

---

### 3. PRODUCTION_PCT_QUERY

**SQL Query:**

```sql
WITH 
invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
invntry_daily AS (
    SELECT 
        i.PYRESOLVEDUSERID AS userid,
        i.resolved_date,
        COUNT(DISTINCT i.PYID) AS work_items_completed,
        SUM(i.RETIME) AS total_retime_min
    FROM invntry_deduped i
    INNER JOIN associate_manager_mapping am
        ON i.PYRESOLVEDUSERID = am.USERID
        AND i.resolved_date = am.LOGINDATE
    WHERE i.rn = 1
      AND USERID IN ('AG01440')
    GROUP BY i.PYRESOLVEDUSERID, i.resolved_date
),
user_daily AS (
    SELECT 
        USERID,
        USERNAME,
        LOGINDATE,
        TOTALSYSTEMTIME,
        COALESCE(LUNCH_DURATION, 0) + 
        COALESCE(BREAK_DURATION, 0) + 
        COALESCE(NON_PRDCTV_DURATION, 0) + 
        COALESCE(MEETING_DURATION, 0) + 
        COALESCE(OTHER_DURATION, 0) AS non_productive_sec,
        (TOTALSYSTEMTIME - (
            COALESCE(LUNCH_DURATION, 0) + 
            COALESCE(BREAK_DURATION, 0) + 
            COALESCE(NON_PRDCTV_DURATION, 0) + 
            COALESCE(MEETING_DURATION, 0) + 
            COALESCE(OTHER_DURATION, 0)
        )) / 60.0 AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY USERID, LOGINDATE ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
      AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
      AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
      AND USERID IN ('AG01440')
      AND TOTALSYSTEMTIME IS NOT NULL
),
daily_metrics AS (
    SELECT 
        i.userid,
        u.USERNAME,
        i.resolved_date,
        i.work_items_completed,
        i.total_retime_min,
        u.actual_production_min,
        i.total_retime_min / NULLIF(i.work_items_completed, 0) AS avg_retime_per_task,
        u.actual_production_min / NULLIF(i.total_retime_min / NULLIF(i.work_items_completed, 0), 0) AS expected_tasks,
        ROUND(
            i.work_items_completed / 
            NULLIF(u.actual_production_min / NULLIF(i.total_retime_min / NULLIF(i.work_items_completed, 0), 0), 0) 
            * 100, 
        2) AS daily_production_pct
    FROM invntry_daily i
    INNER JOIN user_daily u 
        ON i.userid = u.USERID 
        AND i.resolved_date = u.LOGINDATE
    WHERE u.rn = 1
      AND u.actual_production_min > 0
),
aggregated_totals AS (
    SELECT 
        userid,
        MAX(USERNAME) AS USERNAME,
        SUM(work_items_completed) AS total_work_items,
        SUM(total_retime_min) AS total_retime_min,
        SUM(actual_production_min) AS total_actual_production_min,
        SUM(expected_tasks) AS total_expected_tasks,
        AVG(daily_production_pct) AS avg_daily_production_pct,
        COUNT(DISTINCT resolved_date) AS work_days
    FROM daily_metrics
    GROUP BY userid
)
SELECT 
    ROUND(AVG(avg_daily_production_pct), 2) AS AVG_PRODUCTION_PCT
FROM aggregated_totals
```

---

### 4. WORK_ITEMS_COMPLETED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
        AND LOB IN ('Commercial')
        AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT COUNT(*) AS COMPLETED_TASKS
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
WHERE i.rn = 1
```

---

## managers_list

**Number of Queries:** 1

### 1. MANAGERS_LIST_QUERY

**SQL Query:**

```sql
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
),
manager AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT DISTINCT
    manager.USERID AS MANAGER_ID,
    manager.USERNAME AS MANAGER_NAME
FROM frontline
INNER JOIN manager
    ON frontline.PYREPORTTO = manager.USERID
WHERE 1=1
AND manager.PYREPORTTO IN ('SANTICH', 'ROSETSC')
ORDER BY manager.USERNAME
```

---

## operational_flow

**Number of Queries:** 4

### 1. ACTIVE_USERS_COUNT_QUERY

**SQL Query:**

```sql
SELECT COUNT(DISTINCT USERID) AS ACTIVE_USERS
FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
WHERE LOGINDATE >= DATEADD('day', -7, CURRENT_DATE())
AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
```

---

### 2. ASSIGNMENT_TYPE_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        ASSIGNED_BY,
        FIRST_ASSIGNED_TO,
        REASSIGNED_BY,
        REASSIGNED_FROM,
        REASSIGNED_TO,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE ASSIGNED_BY IS NOT NULL
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
frontline_users AS (
    SELECT DISTINCT USERID
    FROM (
        SELECT 
            USERID,
            USERID_PROFILE,
            ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
        FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
        WHERE USERID_PROFILE = 'Frontline'
    ) sub
    WHERE rn = 1
)
SELECT 
    CASE WHEN ASSIGNED_BY LIKE 'GNW%' THEN 'GNW Assigned' ELSE 'Manually Assigned' END AS ASSIGNMENT_TYPE,
    COUNT(PYID) AS TOTAL_CNT,
    COUNT(CASE 
        WHEN REASSIGNED_BY IS NOT NULL 
        AND FIRST_ASSIGNED_TO != PYRESOLVEDUSERID 
        -- NEW: For manual assignments, validate REASSIGNED_FROM is frontline
        AND (
            ASSIGNED_BY LIKE 'GNW%'  -- GNW assignments don't need validation
            OR EXISTS (
                SELECT 1 
                FROM frontline_users f 
                WHERE f.USERID = i.REASSIGNED_FROM  -- Changed from FIRST_ASSIGNED_TO
            )
        )
        THEN PYID 
    END) AS REASSIGNED_CNT,
    ROUND(COUNT(PYID) * 100.0 / SUM(COUNT(PYID)) OVER (), 2) AS ASSIGNMENT_PCT,
    ROUND(COUNT(CASE 
        WHEN REASSIGNED_BY IS NOT NULL 
        AND FIRST_ASSIGNED_TO != PYRESOLVEDUSERID 
        -- NEW: For manual assignments, validate REASSIGNED_FROM is frontline
        AND (
            ASSIGNED_BY LIKE 'GNW%'  -- GNW assignments don't need validation
            OR EXISTS (
                SELECT 1 
                FROM frontline_users f 
                WHERE f.USERID = i.REASSIGNED_FROM  -- Changed from FIRST_ASSIGNED_TO
            )
        )
        THEN PYID 
    END) * 100.0 / NULLIF(COUNT(PYID), 0), 2) AS REASSIGNED_PCT
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
WHERE i.rn = 1
GROUP BY CASE WHEN ASSIGNED_BY LIKE 'GNW%' THEN 'GNW Assigned' ELSE 'Manually Assigned' END
```

---

### 3. LEAD_TIME_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        COMPANYRECEIVEDDATE,
        PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-AutoCloseLink', 'Resolved-Completed')
      AND COMPANYRECEIVEDDATE IS NOT NULL
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT 
    AVG(DATEDIFF('minute', i.COMPANYRECEIVEDDATE, i.PYRESOLVEDTIMESTAMP)) AS LEAD_TIME_AVG_MINUTES
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
WHERE i.rn = 1
```

---

### 4. TAKT_TIME_BY_SLA_QUERY

**SQL Query:**

```sql
WITH sla_buckets AS (
    SELECT 
        PYID,
        ASSIGNEDTO,
        CASE 
            WHEN DATEDIFF('hour', COMPANYRECEIVEDDATE, CURRENT_TIMESTAMP()) <= 4 THEN '4 hours'
            WHEN DATEDIFF('day', COMPANYRECEIVEDDATE, CURRENT_TIMESTAMP()) <= 2 THEN '2 days'
            WHEN DATEDIFF('day', COMPANYRECEIVEDDATE, CURRENT_TIMESTAMP()) <= 10 THEN '10 days'
            ELSE '30 days'
        END AS COB_SLA_BUCKET
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 'Open-ReviewIntake', 'Pend', 'Pend-Decision')
    AND COMPANYRECEIVEDDATE IS NOT NULL
    AND LOB IN ('Commercial')
    AND ASSIGNEDTO IN ('AG01440')
)
SELECT 
    COB_SLA_BUCKET,
    COUNT(DISTINCT PYID) AS BACKLOG_COUNT
FROM sla_buckets
GROUP BY COB_SLA_BUCKET
ORDER BY 
    CASE COB_SLA_BUCKET 
        WHEN '4 hours' THEN 1 
        WHEN '2 days' THEN 2 
        WHEN '10 days' THEN 3 
        ELSE 4 
    END
```

---

## pended_items_counts_drilldown

**Number of Queries:** 2

### 1. PENDED_ITEMS_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXUPDATEDATETIME,
        PEND_CREATE_DT,
        PEND_RESOLVED_DT,
        ASSIGNEDTO,
        PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      -- Item existed before end date
      AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      -- Pending status (these items don't have resolved dates)
      AND (PYSTATUSWORK ILIKE 'Pend%' OR PYSTATUSWORK ILIKE 'Pending%')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
        AND USERID IN ('AG01440')
)
-- Final SELECT with deduplication applied
SELECT
    COUNT(DISTINCT i.PYID) AS TOTAL_COUNT
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
WHERE i.rn = 1  -- Latest inventory version only
```

---

### 2. PENDED_ITEMS_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXUPDATEDATETIME,
        PEND_CREATE_DT,
        PEND_RESOLVED_DT,
        ASSIGNEDTO,
        PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      -- Item existed before end date
      AND PXCREATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      -- Pending status (these items don't have resolved dates)
      AND (PYSTATUSWORK ILIKE 'Pend%' OR PYSTATUSWORK ILIKE 'Pending%')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
        AND USERID IN ('AG01440')
),
-- Deduplicate user profile table
user_profile_deduped AS (
    SELECT 
        USERID,
        PYREPORTTO,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
-- Final SELECT with deduplication applied
SELECT
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS worktype_category,
    i.PYSTATUSWORK AS status,
    i.LOB,
    DATEDIFF('day', i.PEND_CREATE_DT, COALESCE(i.PEND_RESOLVED_DT, CURRENT_DATE)) AS days_pended,
    i.PEND_CREATE_DT AS pend_date,
    i.PEND_RESOLVED_DT AS resolved_date,
    u.USERNAME AS associate_name
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
INNER JOIN user_profile_deduped u
    ON i.ASSIGNEDTO = u.USERID
    AND u.rn = 1  -- Latest user profile version only
WHERE i.rn = 1  -- Latest inventory version only
ORDER BY i.PXCREATEDATETIME DESC
LIMIT 20 OFFSET 0
```

---

## production_pct_achieved_drilldown

**Number of Queries:** 2

### 1. PRODUCTION_PCT_ACHIEVED_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        DATE(i.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY i.PYID ORDER BY i.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE i.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
        AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
WHERE i.rn = 1
```

---

### 2. PRODUCTION_PCT_ACHIEVED_QUERY

**SQL Query:**

```sql
WITH
-- Step 1: Deduplicate inventory to get unique work items
invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        CYCLE_TIME,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        MARKET,
        PLATFORM,
        ACTIVITYCODE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
-- Step 1a: Associate-Manager mapping with date-based relationship
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
-- Step 2: Aggregate by user and date (daily metrics) - only for associates with manager mapping
invntry_daily AS (
    SELECT
        i.PYRESOLVEDUSERID AS userid,
        i.resolved_date,
        COUNT(DISTINCT i.PYID) AS work_items_completed,
        SUM(i.RETIME) AS total_retime_min
    FROM invntry_deduped i
    INNER JOIN associate_manager_mapping am
        ON i.PYRESOLVEDUSERID = am.USERID
        AND i.resolved_date = am.LOGINDATE
    WHERE i.rn = 1
    GROUP BY i.PYRESOLVEDUSERID, i.resolved_date
),
-- Step 3: Get user daily productive time - only for associates in mapping
user_daily AS (
    SELECT
        up.USERID,
        up.USERNAME,
        up.LOGINDATE,
        up.TOTALSYSTEMTIME,
        COALESCE(up.LUNCH_DURATION, 0) +
        COALESCE(up.BREAK_DURATION, 0) +
        COALESCE(up.NON_PRDCTV_DURATION, 0) +
        COALESCE(up.MEETING_DURATION, 0) +
        COALESCE(up.OTHER_DURATION, 0) AS non_productive_sec,
        (up.TOTALSYSTEMTIME - (
            COALESCE(up.LUNCH_DURATION, 0) +
            COALESCE(up.BREAK_DURATION, 0) +
            COALESCE(up.NON_PRDCTV_DURATION, 0) +
            COALESCE(up.MEETING_DURATION, 0) +
            COALESCE(up.OTHER_DURATION, 0)
        )) / 60.0 AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY up.USERID, up.LOGINDATE ORDER BY up.PXUPDATEDATETIME DESC, up.TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE up
    INNER JOIN associate_manager_mapping am
        ON up.USERID = am.USERID
        AND up.LOGINDATE = am.LOGINDATE
    WHERE up.TOTALSYSTEMTIME IS NOT NULL
),
-- Step 4: Calculate daily production metrics
daily_metrics AS (
    SELECT
        i.userid,
        u.USERNAME,
        i.resolved_date,
        i.work_items_completed,
        i.total_retime_min,
        u.actual_production_min,
        i.total_retime_min / NULLIF(i.work_items_completed, 0) AS avg_retime_per_task,
        u.actual_production_min / NULLIF(i.total_retime_min / NULLIF(i.work_items_completed, 0), 0) AS expected_tasks,
        ROUND(
            i.work_items_completed /
            NULLIF(u.actual_production_min / NULLIF(i.total_retime_min / NULLIF(i.work_items_completed, 0), 0), 0)
            * 100,
        2) AS daily_production_pct
    FROM invntry_daily i
    INNER JOIN user_daily u
        ON i.userid = u.USERID
        AND i.resolved_date = u.LOGINDATE
    WHERE u.rn = 1
      AND u.actual_production_min > 0
),
-- Step 5: Aggregate to period totals per user
user_period_totals AS (
    SELECT
        userid,
        MAX(USERNAME) AS USERNAME,
        SUM(work_items_completed) AS total_work_items,
        SUM(total_retime_min) AS total_retime_min,
        SUM(actual_production_min) AS total_actual_production_min,
        SUM(expected_tasks) AS total_expected_tasks,
        AVG(daily_production_pct) AS avg_daily_production_pct,
        COUNT(DISTINCT resolved_date) AS work_days,
        ROUND(
            SUM(work_items_completed) / NULLIF(SUM(expected_tasks), 0) * 100,
        2) AS production_pct_achieved
    FROM daily_metrics
    GROUP BY userid
),
-- Step 6: Deduplicate user profile for username lookup
user_profile_deduped AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
-- Final output: Detailed work items with user production metrics
SELECT
    i.PYRESOLVEDUSERID AS associate,
    u.USERNAME AS associate_name,
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS worktype,
    i.RETIME AS standard_time,
    i.CYCLE_TIME AS case_cycle_time,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.MARKET,
    i.PLATFORM,
    TO_CHAR(i.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY') AS resolved_date,
    i.ACTIVITYCODE AS activity_code,
    'View Details' AS action,
    -- Aggregated production metrics per user
    p.total_work_items,
    p.total_retime_min AS total_expected_min,
    ROUND(p.total_actual_production_min, 0) AS total_actual_production_min,
    ROUND(p.total_expected_tasks, 0) AS total_expected_tasks,
    p.production_pct_achieved
FROM invntry_deduped i
INNER JOIN user_period_totals p
    ON i.PYRESOLVEDUSERID = p.userid
LEFT JOIN user_profile_deduped u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT 20 OFFSET 0
```

---

## quality_outcomes

**Number of Queries:** 6

### 1. AUDIT_CYCLE_TIME_AVG_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        AUDITCYCLETIME,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDITCYCLETIME IS NOT NULL
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
    ROUND(AVG(a.AUDITCYCLETIME), 2) AS AVG_AUDIT_CYCLE_TIME
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
WHERE a.rn = 1
```

---

### 2. AUDIT_SAMPLE_PCT_QUERY

**SQL Query:**

```sql
WITH deduped_invntry AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND PYRESOLVEDUSERID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
work_items AS (
    SELECT 
        i.PYRESOLVEDUSERID AS USERID,
        COUNT(DISTINCT i.PYID) AS work_items_completed
    FROM deduped_invntry i
    INNER JOIN associate_manager_mapping am
        ON i.PYRESOLVEDUSERID = am.USERID
        AND i.resolved_date = am.LOGINDATE
    WHERE i.rn = 1
    GROUP BY i.PYRESOLVEDUSERID
),
deduped_audit AS (
    SELECT 
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        PXUPDATEDATETIME,
        DATE(PXUPDATEDATETIME) AS audit_date,
        ROW_NUMBER() OVER (
            PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PXUPDATEDATETIME >= '2026-03-17'
      AND PXUPDATEDATETIME < DATEADD(day, 1, '2026-03-23'::DATE)
      AND PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND LOB IN ('Commercial')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
audited_items AS (
    SELECT 
        a.AUDIT_SUBJECT_ID AS USERID,
        COUNT(DISTINCT a.CASE_TO_AUDIT) AS items_audited
    FROM deduped_audit a
    INNER JOIN associate_manager_mapping am
        ON a.AUDIT_SUBJECT_ID = am.USERID
        AND a.audit_date = am.LOGINDATE
    WHERE a.rn = 1
    GROUP BY a.AUDIT_SUBJECT_ID
)
SELECT 
    w.USERID,
    w.work_items_completed,
    COALESCE(a.items_audited, 0) AS items_audited,
    ROUND((COALESCE(a.items_audited, 0) * 100.0 / NULLIF(w.work_items_completed, 0)), 2) AS audit_sample_pct
FROM work_items w
LEFT JOIN audited_items a ON w.USERID = a.USERID
WHERE w.work_items_completed > 0
```

---

### 3. AUDIT_SCORE_AVG_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT 
    ROUND(AVG(a.AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
WHERE a.rn = 1
```

---

### 4. COMPLETED_AUDIT_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
WHERE a.rn = 1
```

---

### 5. REBUTTAL_COUNT_QUERY

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDITOR_ID,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
auditor_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
audit_with_manager AS (
    SELECT
        a.PYID,
        a.AUDIT_SUBJECT_ID
    FROM audit_deduped a
    INNER JOIN auditor_manager_mapping am
        ON a.AUDIT_SUBJECT_ID = am.USERID
        AND a.resolved_date = am.LOGINDATE
    WHERE a.rn = 1
),
rebuttal_details AS (
    SELECT
        act.CASEID,
        act.ERRORCATEGORYTYPE,
        act.ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY act.CASEID, act.ERRORCATEGORYTYPE, act.ERRORCATEGORY
            ORDER BY act.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY act
    WHERE act.CASEID LIKE 'AUD%'
      AND act.ERRORCATEGORYTYPE IS NOT NULL
      AND act.ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_audit_cases_with_rebuttals,
    COUNT(*) AS total_rebuttal_records
FROM audit_with_manager awm
INNER JOIN rebuttal_details rd
    ON awm.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 6. REWORK_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('Commercial')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
    COUNT(DISTINCT a.PYID) AS REWORK_COUNT
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
WHERE a.rn = 1
```

---

## rebuttal_drilldown

**Number of Queries:** 2

### 1. REBUTTAL_COUNT_QUERY

**SQL Query:**

```sql
WITH audit_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
auditor_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
audit_with_manager AS (
    SELECT
        a.PYID,
        a.AUDIT_SUBJECT_ID
    FROM audit_deduped a
    INNER JOIN auditor_manager_mapping am
        ON a.AUDIT_SUBJECT_ID = am.USERID
        AND a.resolved_date = am.LOGINDATE
    WHERE a.rn = 1
),
rebuttal_details AS (
    SELECT
        act.CASEID,
        act.ERRORCATEGORYTYPE,
        act.ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY act.CASEID, act.ERRORCATEGORYTYPE, act.ERRORCATEGORY
            ORDER BY act.PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY act
    WHERE act.CASEID LIKE 'AUD%'
      AND act.ERRORCATEGORYTYPE IS NOT NULL
      AND act.ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT
FROM audit_with_manager awm
INNER JOIN rebuttal_details rd
    ON awm.PYID = rd.CASEID
    AND rd.rn = 1
```

---

### 2. REBUTTAL_PAGINATED_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PLATFORM,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND AUDIT_SUBJECT_ID IN ('AG01440')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
deduped_user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORY,
        ERRORCATEGORYTYPE,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_ACTIVITY
)
SELECT
    a.PYID as work_item_id,
    a.INTAKESOURCESYSTEM as worktype_category,
    a.PYSTATUSWORK as outcome_status,
    a.LOB,
    a.PXCREATEDATETIME as resolved_date,
    a.AUDIT_SUBJECT_ID as audit_subject_id,
    u.USERNAME as associate_name,
    a.PLATFORM as platform_source_system,
    COALESCE(aa.ERRORCATEGORY, 'N/A') as error_category,
    COALESCE(aa.ERRORCATEGORYTYPE, 'N/A') as error_type,
    COALESCE(aa.REBUTTALOUTCOME, 'N/A') as rebuttal_outcome
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
LEFT JOIN deduped_audit_activity aa
    ON a.PYID = aa.CASEID
    AND aa.rn = 1
WHERE a.rn = 1
  AND u.rn = 1
ORDER BY a.PXCREATEDATETIME DESC
LIMIT 20 OFFSET 0
```

---

## rework_pct_drilldown

**Number of Queries:** 2

### 1. REWORK_COUNT_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
    COUNT(DISTINCT a.PYID) AS TOTAL_COUNT
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
WHERE a.rn = 1
```

---

### 2. REWORK_PAGINATED_QUERY

**SQL Query:**

```sql
WITH deduped_audit AS (
    SELECT
        PYID,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        CASE_TO_AUDIT,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '2026-03-17' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
deduped_user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
),
invntry_deduped AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
)
SELECT
    a.PYID AS work_item,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(i.PYSTATUSWORK, 'N/A') AS resolved_status,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    a.LOB,
    a.resolved_date,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(CAST(a.AUDIT_SCORE AS VARCHAR), 'N/A') AS audit_score,
    COALESCE(u.USERNAME, 'N/A') AS auditor_name
FROM deduped_audit a
INNER JOIN associate_manager_mapping am
    ON a.AUDIT_SUBJECT_ID = am.USERID
    AND a.resolved_date = am.LOGINDATE
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
LEFT JOIN invntry_deduped i
    ON a.CASE_TO_AUDIT = i.PYID
    AND i.rn = 1
WHERE a.rn = 1
  AND u.rn = 1
ORDER BY a.resolved_date DESC, a.PYID
LIMIT 20 OFFSET 0
```

---

## watchlist_drilldown

**Number of Queries:** 2

### 1. WATCHLIST_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        ISADDTOWATCHLIST,
        PYSTATUSWORK,
        LOB,
        ASSIGNEDTO,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT
    COUNT(DISTINCT i.PYID) AS WATCHLIST_COUNT
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
WHERE i.rn = 1
```

---

### 2. WATCHLIST_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PLATFORM,
        INVNTRY_TYPE,
        ISADDTOWATCHLIST,
        ASSIGNEDTO,
        PXCREATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      AND LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
deduped_user_profile AS (
    SELECT 
        USERID,
        PYREPORTTO,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYID AS work_item,
    i.INTAKESOURCESYSTEM AS work_type,
    u.USERNAME AS associate,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.PLATFORM,
    'N/A' AS elv_due_date
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.ASSIGNEDTO = am.USERID
INNER JOIN deduped_user_profile u
    ON i.ASSIGNEDTO = u.USERID
WHERE i.rn = 1
  AND u.rn = 1
ORDER BY i.PXCREATEDATETIME DESC
LIMIT 20 OFFSET 0
```

---

## work_items_director_drilldown

**Number of Queries:** 2

### 1. WORK_ITEMS_DIRECTOR_COUNT_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT 
        i.PYID,
        i.PYRESOLVEDUSERID,
        DATE(i.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY i.PYID ORDER BY i.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE i.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND i.PYRESOLVEDTIMESTAMP >= '2026-03-17' AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
        AND i.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
WHERE i.rn = 1
```

---

### 2. WORK_ITEMS_DIRECTOR_PAGINATED_QUERY

**SQL Query:**

```sql
WITH invntry_deduped AS (
    SELECT
        i.PYID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.PYSTATUSWORK,
        i.LOB,
        i.INVNTRY_TYPE,
        i.PYRESOLVEDTIMESTAMP,
        DATE(i.PYRESOLVEDTIMESTAMP) AS resolved_date,
        i.PYRESOLVEDUSERID,
        i.PLATFORM,
        i.RETIME,
        ROW_NUMBER() OVER (PARTITION BY i.PYID ORDER BY i.RETIME DESC NULLS LAST, i.PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_INVNTRY_PROFILE i
    WHERE i.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND i.PYRESOLVEDTIMESTAMP >= '2026-03-17' AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '2026-03-23'::DATE)
        AND i.LOB IN ('CSBD', 'Commercial', 'CrossOver', 'EGR', 'GRS', 'Group Retiree Solutions', 'INT', 'KCP', 'MDR', 'MMP', 'MedSupp', 'Medicaid', 'Medicare', 'PDP', 'SUP', 'Supplemental')
),
associate_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
    WHERE 1=1
        AND LOGINDATE >= '2026-03-17' AND LOGINDATE < DATEADD(day, 1, '2026-03-23'::DATE)
        AND USERID IN ('AG01440')
        AND PYREPORTTO IN ('SANTICH', 'ROSETSC')
),
user_profile_deduped AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM NON_CRTFD_AIFS.DL_DV_TMBR.COB_AI_USER_PROFILE
)
SELECT
    i.PYID,
    i.INTAKESOURCESYSTEM,
    i.CYCLE_TIME,
    i.PYSTATUSWORK,
    i.LOB,
    i.PYRESOLVEDTIMESTAMP,
    i.PYRESOLVEDUSERID,
    u.USERNAME AS ASSOCIATE_NAME,
    i.PLATFORM,
    i.INVNTRY_TYPE
FROM invntry_deduped i
INNER JOIN associate_manager_mapping am
    ON i.PYRESOLVEDUSERID = am.USERID
    AND i.resolved_date = am.LOGINDATE
LEFT JOIN user_profile_deduped u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT 20 OFFSET 0
```

---

## Summary

### Queries per Module

| Module | Query Count |
|--------|-------------|
| associate_utilization | 4 |
| associates_list | 1 |
| audit_sample_pct_drilldown | 1 |
| audit_score_director_drilldown | 2 |
| completed_audit_count_drilldown | 2 |
| demand_inventory | 6 |
| director_list | 1 |
| director_lob | 1 |
| director_user_activity | 3 |
| escalation_count_drilldown | 2 |
| fuse_time_director_drilldown | 2 |
| header_kpis | 4 |
| managers_list | 1 |
| operational_flow | 4 |
| pended_items_counts_drilldown | 2 |
| production_pct_achieved_drilldown | 2 |
| quality_outcomes | 6 |
| rebuttal_drilldown | 2 |
| rework_pct_drilldown | 2 |
| watchlist_drilldown | 2 |
| work_items_director_drilldown | 2 |

### Test Payload Used

```json
{
  "end_date": "2026-03-23",
  "frontline_associate_ids": [
    "AG01440"
  ],
  "lob": [
    "Commercial"
  ],
  "manager_ids": [
    "SANTICH",
    "ROSETSC"
  ],
  "start_date": "2026-03-17",
  "user_id": "AB77504"
}
```

### Pagination Payload Used

```json
{
  "end_date": "2026-03-23",
  "frontline_associate_ids": [
    "AG01440"
  ],
  "lob": [
    "CSBD",
    "Commercial",
    "CrossOver",
    "EGR",
    "GRS",
    "Group Retiree Solutions",
    "INT",
    "KCP",
    "MDR",
    "MMP",
    "MedSupp",
    "Medicaid",
    "Medicare",
    "PDP",
    "SUP",
    "Supplemental"
  ],
  "manager_ids": [
    "SANTICH",
    "ROSETSC"
  ],
  "start_date": "2026-03-17",
  "user_id": "AB77504",
  "page": 1,
  "page_size": 20
}
```
