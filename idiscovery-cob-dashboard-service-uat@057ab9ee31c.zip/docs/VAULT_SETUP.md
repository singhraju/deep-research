# Vault and Certificate Setup for OpenAI Integration

## Overview
This document describes the vault integration and SSL certificate setup required for OpenAI/Horizon OAuth authentication in the COB Dashboard Service.

## Files Added

### 1. `root.pem` - WellPoint Internal Root CA Certificate
**Location**: `/Users/AH64226/Downloads/idiscovery-cob-dashboard-service/root.pem`

**Purpose**: SSL/TLS certificate for secure communication with internal Elevance Health/WellPoint services.

**Description**: This is the WellPoint Internal Root CA certificate used to verify SSL connections to:
- Horizon OAuth endpoint (`api.horizon.elevancehealth.com`)
- OpenAI API endpoint (via Horizon)
- Other internal APIs

**Usage**: Automatically used by Python's requests library when making HTTPS calls to internal services.

---

## Vault Integration

### Configuration Pattern
The application follows the orchestrator-cob pattern for secure credential management:

```python
# 1. Read from vault first
vault_config.read('/vault/secrets/creds')

# 2. Get credential with fallback to environment variable
HORIZON_CLIENT_ID = vault_config.get('default', 'HORIZON_CLIENT_ID', 
                                       fallback=os.environ.get("HORIZON_CLIENT_ID"))
```

### Vault File Location
**Production**: `/vault/secrets/creds`

### Vault File Format (INI)
```ini
[default]
HORIZON_CLIENT_ID=your_actual_client_id_here
HORIZON_CLIENT_SECRET=your_actual_client_secret_here
```

---

## Environment-Specific Setup

### Local Development (No Vault)
When vault is not available (local laptop, dev environment), use `.env` file:

```bash
# .env
HORIZON_CLIENT_ID=your_dev_client_id
HORIZON_CLIENT_SECRET=your_dev_client_secret
```

### DEV/QA/PROD (With Vault)
Credentials are automatically read from `/vault/secrets/creds`. No `.env` changes needed.

**Vault Setup Steps:**
1. Create vault file: `/vault/secrets/creds`
2. Add credentials in INI format (see above)
3. Set proper file permissions: `chmod 600 /vault/secrets/creds`
4. Ensure application user has read access

---

## Required Credentials

### 1. HORIZON_CLIENT_ID
- **Purpose**: OAuth client identifier for Horizon API
- **Format**: String (e.g., `idiscovery-cob-dashboard-dev`)
- **Source**: Obtain from Elevance Health API team or vault

### 2. HORIZON_CLIENT_SECRET
- **Purpose**: OAuth client secret for Horizon API
- **Format**: String (secret key)
- **Source**: Obtain from Elevance Health API team or vault
- **Security**: **NEVER commit to git** or log this value

### 3. HORIZON_PROJECT (Optional)
- **Purpose**: Project identifier for Horizon
- **Default**: `IDISCOVERY`
- **Source**: `.env` or environment variable

### 4. HORIZON_AUTH_URL (Optional)
- **Purpose**: Horizon OAuth token endpoint
- **Default**: `https://api.horizon.elevancehealth.com/v2/oauth2/token`
- **Source**: `.env` or environment variable

---

## Configuration Priority

The application reads credentials in this order:
1. **Vault** (`/vault/secrets/creds`) - **Highest priority**
2. **Environment Variables** - Fallback
3. **Default Values** (only for non-sensitive configs like URLs)

---

## Testing the Setup

### 1. Verify Vault File Exists
```bash
cat /vault/secrets/creds
```

Expected output:
```ini
[default]
HORIZON_CLIENT_ID=...
HORIZON_CLIENT_SECRET=...
```

### 2. Test OpenAI Service Initialization
```python
from src.services.openai_service import get_openai_service

try:
    service = get_openai_service()
    print("✅ OpenAI service initialized successfully")
except Exception as e:
    print(f"❌ Failed to initialize: {e}")
```

### 3. Test API Request
```bash
curl -X POST http://localhost:8000/cobdashboard/v1/ai-coach \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AD44140",
    "start_date": "2025-01-01",
    "end_date": "2025-01-31"
  }'
```

Expected: AI-generated summary (not "Feature disabled" error)

---

## Troubleshooting

### Error: "Failed to initialize OpenAI service"

**Possible Causes:**
1. Vault file doesn't exist or is empty
2. Missing credentials in vault file
3. Incorrect vault file format
4. No environment variables set (local dev)

**Solution:**
```bash
# Check if vault file exists
ls -la /vault/secrets/creds

# Verify vault file format
cat /vault/secrets/creds

# Check environment variables (local dev)
echo $HORIZON_CLIENT_ID
echo $HORIZON_CLIENT_SECRET
```

### Error: SSL Certificate Verification Failed

**Possible Causes:**
1. `root.pem` file missing
2. Incorrect certificate path

**Solution:**
```bash
# Verify root.pem exists
ls -la /Users/AH64226/Downloads/idiscovery-cob-dashboard-service/root.pem

# Verify it's the correct certificate (should show WellPoint CA)
openssl x509 -in root.pem -text -noout | grep "Issuer"
```

### Error: "HORIZON_CLIENT_ID and HORIZON_CLIENT_SECRET must be set"

**Possible Causes:**
1. Vault file has wrong section name (should be `[default]`)
2. Key names don't match exactly
3. Both vault and environment variables are empty

**Solution:**
```bash
# For local dev, set in .env
echo "HORIZON_CLIENT_ID=your_id_here" >> .env
echo "HORIZON_CLIENT_SECRET=your_secret_here" >> .env

# For production, fix vault file format:
cat > /vault/secrets/creds << EOF
[default]
HORIZON_CLIENT_ID=your_id_here
HORIZON_CLIENT_SECRET=your_secret_here
EOF
```

---

## Security Best Practices

### DO ✅
- Store credentials in vault in production
- Use `.env` for local development only
- Add `.env` to `.gitignore`
- Set restrictive file permissions: `chmod 600 /vault/secrets/creds`
- Rotate credentials regularly
- Use different credentials per environment (dev/qa/prod)

### DON'T ❌
- Commit credentials to git
- Log credential values
- Share credentials in plain text
- Use production credentials in dev/qa
- Store credentials in code or config files

---

## Deployment Checklist

### Pre-Deployment
- [ ] Obtain HORIZON_CLIENT_ID and HORIZON_CLIENT_SECRET from API team
- [ ] Create `/vault/secrets/creds` file in target environment
- [ ] Add credentials to vault file in INI format
- [ ] Set file permissions: `chmod 600 /vault/secrets/creds`
- [ ] Verify `root.pem` exists in application directory
- [ ] Test OpenAI service initialization

### Post-Deployment
- [ ] Test AI Coach endpoint with real request
- [ ] Monitor logs for OpenAI initialization success
- [ ] Verify no credential-related errors
- [ ] Check token usage and costs

---

## File Locations Summary

| File | Location | Purpose | Source |
|------|----------|---------|--------|
| `root.pem` | Project root | SSL certificate for Horizon API | Copied from orchestrator-cob |
| `/vault/secrets/creds` | System vault | Production credentials (CLIENT_ID, SECRET) | Created by DevOps/SRE |
| `.env` | Project root | Local dev credentials (fallback) | Developer creates locally |
| `src/config.py` | Source code | Configuration loader with vault integration | Updated to match orchestrator-cob |

---

## References

- **Orchestrator-COB Config**: `/Users/AH64226/Downloads/KL/mongo/idiscovery-orchestrator-cob/idiscovery_orchestrator_cob/config.py` (lines 6-7, 38-39)
- **Certificate Source**: `/Users/AH64226/Downloads/KL/mongo/idiscovery-orchestrator-cob/root.pem`
- **Horizon API Documentation**: Contact Elevance Health API team

---

## Support

For credential access or vault setup issues, contact:
- **DevOps Team**: For vault file creation/permissions
- **API Team**: For Horizon OAuth credentials
- **Security Team**: For certificate or security policy questions
