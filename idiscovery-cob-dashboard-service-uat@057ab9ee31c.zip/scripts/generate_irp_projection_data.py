"""
Script to generate IRP Projection data from Snowflake queries.
This script runs the ETL queries for a date range and exports the results to an Excel file.

Usage:
    python generate_irp_projection_data.py --start-date 2026-07-01 --end-date 2026-07-20
    poetry run python .\scripts\generate_irp_projection_data.py --start-date 2026-07-01 --end-date 2026-07-02
"""

import os
import sys
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List
import argparse

# Add parent directory to path to import from src
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'src'))

from src.db import SnowflakeConnectionManager
from src.config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import pandas as pd

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# =============================================================================
# SQL Query Templates
# =============================================================================

BACKLOG_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PXCREATEDATETIME,
        inv.PYRESOLVEDTIMESTAMP,
        COALESCE(inv.LOB, 'Unknown') as lob,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS work_type,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.pxupdatedatetime < DATEADD(day, 1, :target_date::DATE)
)
SELECT
    inv.lob,
    inv.work_type,
    COUNT(DISTINCT inv.PYID) AS backlog_count
FROM invntry_deduped inv
WHERE inv.rn = 1
    AND (work_type NOT LIKE '%-Dup%' OR work_type = 'Solution Central-Dup')
    AND inv.PXCREATEDATETIME < :target_date::DATE  
    AND (
        inv.PYRESOLVEDTIMESTAMP IS NULL 
        OR inv.PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, :target_date::DATE)
    )
GROUP BY inv.lob, inv.work_type
"""

NEW_ITEMS_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PXCREATEDATETIME,
        COALESCE(inv.LOB, 'Unknown') as lob,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS work_type,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.pxupdatedatetime < DATEADD(day, 1, :target_date::DATE)
)
SELECT
    inv.lob,
    inv.work_type,
    COUNT(DISTINCT inv.PYID) AS new_items
FROM invntry_deduped inv
WHERE inv.rn = 1
    AND inv.PXCREATEDATETIME >= :target_date::DATE
    AND inv.PXCREATEDATETIME < DATEADD(day, 1, :target_date::DATE)
GROUP BY inv.lob, inv.work_type
"""

CYCLE_TIME_QUERY = f"""
SELECT
    COALESCE(inv.LOB, 'Unknown') AS lob,
    COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS work_type,
    ROUND(AVG(inv.CYCLE_TIME) / 3600.0, 2) AS avg_cycle_time_hrs
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
WHERE inv.CYCLE_TIME IS NOT NULL
    AND inv.PYRESOLVEDTIMESTAMP IS NOT NULL
    AND inv.PYRESOLVEDTIMESTAMP BETWEEN 
        DATEADD(DAY, -90, :target_date::DATE) 
        AND :target_date::DATE
GROUP BY inv.INTAKESOURCESYSTEM, inv.lob
"""

AVG_RESOLVED_PER_DAY_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE pxupdatedatetime < DATEADD(day, 1, :target_date::DATE)
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC
    ) = 1
    
),
filtered_inventory AS (
    SELECT
        PYID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP BETWEEN DATEADD(DAY, -90, :target_date::DATE) AND :target_date::DATE
),
total_resolved AS (
    SELECT COUNT(DISTINCT PYID) AS total_resolved_cases
    FROM filtered_inventory
),
date_range AS (
    SELECT
        DATEADD(day, SEQ4(), DATEADD(DAY, -90, :target_date::DATE)) AS calendar_date
    FROM TABLE(GENERATOR(ROWCOUNT => 91))
    WHERE DATEADD(day, SEQ4(), DATEADD(DAY, -90, :target_date::DATE)) <= :target_date::DATE
),
holidays AS (
    SELECT DISTINCT DATE
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA
    WHERE DATE BETWEEN DATEADD(DAY, -90, :target_date::DATE) AND :target_date::DATE
),
working_days AS (
    SELECT COUNT(*) AS total_working_days
    FROM date_range dr
    LEFT JOIN holidays h ON dr.calendar_date = h.DATE
    WHERE DAYOFWEEK(dr.calendar_date) NOT IN (0, 6)
      AND h.DATE IS NULL
)
SELECT
    ROUND(tr.total_resolved_cases::FLOAT / NULLIF(wd.total_working_days, 0), 2) AS avg_daily_resolved
FROM total_resolved tr
CROSS JOIN working_days wd
"""

PRODUCTIVE_HOURS_QUERY = f"""
SELECT
    ROUND(AVG(
        SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT
        + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0
        + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
    ), 2) AS avg_hrs_per_day
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
    AND u.TOTALSYSTEMTIME IS NOT NULL
    AND u.LOGINDATE BETWEEN DATEADD(day, -90, :target_date::DATE) 
        AND :target_date::DATE
"""

AVAILABLE_FTE_QUERY = f"""
SELECT
    COUNT(DISTINCT w.EMPLOYEE_DOMAIN_ID) AS available_fte
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
WHERE w.JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
    AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
    AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN :target_date::DATE AND DATEADD(day, 1, :target_date::DATE)
"""

SLA_DUE_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.EXTERNALDUEDATE,
        inv.INTERNALDUEDATE,
        COALESCE(inv.LOB, 'Unknown') as lob,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS work_type,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.pxupdatedatetime < DATEADD(day, 1, :target_date::DATE)
)
SELECT
    inv.lob,
    inv.work_type,
    COUNT(DISTINCT inv.PYID) AS sla_due_count
FROM invntry_deduped inv
WHERE inv.rn = 1 
    AND inv.EXTERNALDUEDATE IS NOT NULL
    AND inv.EXTERNALDUEDATE >= :target_date::DATE
    AND inv.EXTERNALDUEDATE < DATEADD(day, 1, :target_date::DATE)
    
GROUP BY inv.lob, inv.work_type
"""

TOTAL_PRODUCTION_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.PYRESOLVEDTIMESTAMP,
        COALESCE(inv.LOB, 'Unknown') as lob,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS work_type,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.pxupdatedatetime < DATEADD(day, 1, :target_date::DATE)
)
SELECT
    inv.lob,
    inv.work_type,
    COUNT(DISTINCT inv.PYID) AS production_count
FROM invntry_deduped inv
WHERE inv.rn = 1
    AND inv.PYRESOLVEDTIMESTAMP IS NOT NULL
    AND inv.PYSTATUSWORK IN ('Resolved-Completed')
    AND inv.PYRESOLVEDTIMESTAMP >= :target_date::DATE
    AND inv.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, :target_date::DATE)
GROUP BY inv.lob, inv.work_type
"""

PROD_APPLIED_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.PYRESOLVEDTIMESTAMP,
        inv.EXTERNALDUEDATE,
        inv.INTERNALDUEDATE,
        COALESCE(inv.LOB, 'Unknown') as lob,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS work_type,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.pxupdatedatetime < DATEADD(day, 1, :target_date::DATE)
)
SELECT
    inv.lob,
    inv.work_type,
    COUNT(DISTINCT inv.PYID) AS prod_applied_sla_count
FROM invntry_deduped inv
WHERE inv.rn = 1
    AND inv.PYSTATUSWORK IN ('Resolved-Completed')
    AND inv.EXTERNALDUEDATE IS NOT NULL
    AND inv.EXTERNALDUEDATE >= :target_date::DATE
    AND inv.EXTERNALDUEDATE < DATEADD(day, 1, :target_date::DATE)
    AND inv.PYRESOLVEDTIMESTAMP >= :target_date::DATE
    AND inv.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, :target_date::DATE)
GROUP BY inv.lob, inv.work_type
"""

OUT_OF_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.PXCREATEDATETIME,
        inv.PYRESOLVEDTIMESTAMP,
        inv.EXTERNALDUEDATE,
        inv.INTERNALDUEDATE,
        COALESCE(inv.LOB, 'Unknown') as lob,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS work_type,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.pxupdatedatetime < DATEADD(day, 1, :target_date::DATE)
)
SELECT
    inv.lob,
    inv.work_type,
    COUNT(DISTINCT inv.PYID) AS out_of_sla_count
FROM invntry_deduped inv
WHERE inv.rn = 1
    AND inv.EXTERNALDUEDATE IS NOT NULL
    AND inv.EXTERNALDUEDATE >= :target_date::DATE
    AND inv.EXTERNALDUEDATE < DATEADD(day, 1, :target_date::DATE)
    AND (inv.PYRESOLVEDTIMESTAMP IS NULL OR inv.PYRESOLVEDTIMESTAMP > inv.EXTERNALDUEDATE)
GROUP BY inv.lob, inv.work_type
"""


# =============================================================================
# Data Extraction Functions
# =============================================================================

def execute_query_single(engine, query_template: str, target_date: str) -> Any:
    """Execute a query and return the first column value of the first row (for aggregate queries)."""
    try:
        query = query_template.replace(":target_date", f"'{target_date}'")
        session = engine.connect()
        result = session.sql(query).collect()
        
        if result and len(result) > 0:
            first_row = result[0]
            first_value = first_row[0]
            return first_value if first_value is not None else 0
        return 0
    except Exception as e:
        logger.error(f"Error executing single query for date {target_date}: {str(e)}")
        return 0


def execute_query_multi(engine, query_template: str, target_date: str) -> List[Dict[str, Any]]:
    """Execute a query and return all rows as list of dictionaries (for grouped queries)."""
    try:
        query = query_template.replace(":target_date", f"'{target_date}'")
        session = engine.connect()
        result = session.sql(query).collect()
        
        # Convert to list of dictionaries
        return [row.as_dict() for row in result]
    except Exception as e:
        logger.error(f"Error executing multi query for date {target_date}: {str(e)}")
        return []


def extract_metrics_for_date(engine, target_date: str) -> List[Dict[str, Any]]:
    """Extract all metrics for a specific date, grouped by LOB and work_type."""
    logger.info(f"Extracting metrics for {target_date}")
    
    # Execute grouped queries (return multiple rows)
    backlog_data = execute_query_multi(engine, BACKLOG_COUNT_QUERY, target_date)
    new_items_data = execute_query_multi(engine, NEW_ITEMS_QUERY, target_date)
    sla_due_data = execute_query_multi(engine, SLA_DUE_QUERY, target_date)
    production_data = execute_query_multi(engine, TOTAL_PRODUCTION_QUERY, target_date)
    prod_sla_data = execute_query_multi(engine, PROD_APPLIED_SLA_QUERY, target_date)
    out_sla_data = execute_query_multi(engine, OUT_OF_SLA_QUERY, target_date)
    cycle_time_data = execute_query_multi(engine, CYCLE_TIME_QUERY, target_date)
    
    # Execute aggregate queries (return single values)
    avg_daily_resolved = execute_query_single(engine, AVG_RESOLVED_PER_DAY_QUERY, target_date)
    avg_hrs_per_day = execute_query_single(engine, PRODUCTIVE_HOURS_QUERY, target_date)
    available_fte = execute_query_single(engine, AVAILABLE_FTE_QUERY, target_date)
    
    # Convert aggregate values
    avg_daily_resolved = float(avg_daily_resolved) if avg_daily_resolved else 1.0
    avg_hrs_per_day = float(avg_hrs_per_day) if avg_hrs_per_day else 8.0
    available_fte = int(available_fte) if available_fte else 0
    
    # Create lookup dictionaries for easy access
    backlog_lookup = {(row['LOB'], row['WORK_TYPE']): int(row['BACKLOG_COUNT']) for row in backlog_data}
    new_items_lookup = {(row['LOB'], row['WORK_TYPE']): int(row['NEW_ITEMS']) for row in new_items_data}
    sla_due_lookup = {(row['LOB'], row['WORK_TYPE']): int(row['SLA_DUE_COUNT']) for row in sla_due_data}
    production_lookup = {(row['LOB'], row['WORK_TYPE']): int(row['PRODUCTION_COUNT']) for row in production_data}
    prod_sla_lookup = {(row['LOB'], row['WORK_TYPE']): int(row['PROD_APPLIED_SLA_COUNT']) for row in prod_sla_data}
    out_sla_lookup = {(row['LOB'], row['WORK_TYPE']): int(row['OUT_OF_SLA_COUNT']) for row in out_sla_data}
    cycle_time_lookup = {(row['LOB'], row['WORK_TYPE']): float(row['AVG_CYCLE_TIME_HRS']) for row in cycle_time_data}
    
    # Get all unique LOB/work_type combinations
    all_keys = set()
    all_keys.update(backlog_lookup.keys())
    all_keys.update(new_items_lookup.keys())
    all_keys.update(sla_due_lookup.keys())
    all_keys.update(production_lookup.keys())
    all_keys.update(prod_sla_lookup.keys())
    all_keys.update(out_sla_lookup.keys())
    
    # Build result records - one per LOB/work_type combination
    results = []
    for lob, work_type in all_keys:
        backlog_count = backlog_lookup.get((lob, work_type), 0)
        new_items = new_items_lookup.get((lob, work_type), 0)
        sla_due_count = sla_due_lookup.get((lob, work_type), 0)
        production_count = production_lookup.get((lob, work_type), 0)
        prod_applied_sla_count = prod_sla_lookup.get((lob, work_type), 0)
        out_of_sla_count = out_sla_lookup.get((lob, work_type), 0)
        
        # Get work_type-specific cycle time (default to 0 if not found)
        avg_cycle_time_hrs = cycle_time_lookup.get((lob, work_type), 0.0)
        
        # Calculate total work for this LOB/work_type
        total_work = backlog_count + new_items
        
        # Calculate Required FTE for this LOB/work_type
        required_fte = 0.0
        required_fte_sla = 0.0
        if avg_hrs_per_day > 0 and avg_cycle_time_hrs > 0:
            required_fte = round((sla_due_count * avg_cycle_time_hrs) / avg_hrs_per_day, 2)
        
        # Calculate FTE Gap = Required FTE - Available FTE
        fte_gap = round(required_fte - available_fte, 2)
        
        # Calculate Overtime Estimate
        overtime_estimate = 0.0
        if fte_gap > 0:
            overtime_estimate = round(fte_gap * avg_hrs_per_day, 2)
        
        # Calculate DWOH
        dwoh = 0.0
        if avg_daily_resolved > 0:
            dwoh = round(total_work / avg_daily_resolved, 2)
        
        results.append({
            'date': target_date,
            'lob': lob,
            'work_type': work_type,
            'total_work': total_work,
            'backlog_count': backlog_count,
            'new_items': new_items,
            'sla_due': sla_due_count,
            'req_fte': required_fte,
            'avail_fte': available_fte,
            'total_production': production_count,
            'prod_applied_to_sla': prod_applied_sla_count,
            'out_of_sla': out_of_sla_count,
            'fte_gap': fte_gap,
            'overtime_estimate': overtime_estimate,
            'dwoh': dwoh,
            'avg_cycle_time_hrs': avg_cycle_time_hrs,
            'avg_daily_resolved': avg_daily_resolved,
            'avg_productive_hrs_per_day': avg_hrs_per_day
        })
    
    logger.info(f"Extracted {len(results)} LOB/work_type combinations for {target_date}")
    return results


def generate_date_range(start_date: str, end_date: str) -> List[str]:
    """Generate a list of dates between start_date and end_date (inclusive)."""
    start = datetime.strptime(start_date, '%Y-%m-%d')
    end = datetime.strptime(end_date, '%Y-%m-%d')
    
    date_list = []
    current_date = start
    while current_date <= end:
        date_list.append(current_date.strftime('%Y-%m-%d'))
        current_date += timedelta(days=1)
    
    return date_list


def export_to_excel(data: List[Dict[str, Any]], output_file: str):
    """Export data to Excel file."""
    logger.info(f"Exporting data to {output_file}")
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Reorder columns for better readability
    column_order = [
        'date',
        'lob',
        'work_type',
        'total_work',
        'backlog_count',
        'new_items',
        'sla_due',
        'req_fte',
        'avail_fte',
        'total_production',
        'prod_applied_to_sla',
        'out_of_sla',
        'fte_gap',
        'overtime_estimate',
        'dwoh',
        'avg_cycle_time_hrs',
        'avg_daily_resolved',
        'avg_productive_hrs_per_day'
    ]
    
    df = df[column_order]
    
    # Export to Excel
    try:
        df.to_excel(output_file, index=False, sheet_name='IRP Projection Data')
        logger.info(f"Successfully exported {len(data)} records to {output_file}")
    except PermissionError:
        logger.error(f"Cannot write to {output_file} - file is open in another application.")
        logger.error("Please close the Excel file and try again.")
        raise


# =============================================================================
# Main Function
# =============================================================================

def main():
    """Main function to run the data extraction."""
    parser = argparse.ArgumentParser(description='Generate IRP Projection data from Snowflake')
    parser.add_argument('--start-date', required=True, help='Start date in YYYY-MM-DD format')
    parser.add_argument('--end-date', required=True, help='End date in YYYY-MM-DD format')
    parser.add_argument('--output', default='irp_projection_data.xlsx', help='Output Excel file name')
    
    args = parser.parse_args()
    
    start_date = args.start_date
    end_date = args.end_date
    output_file = args.output
    
    logger.info(f"Starting data extraction from {start_date} to {end_date}")
    
    # Validate date format
    try:
        datetime.strptime(start_date, '%Y-%m-%d')
        datetime.strptime(end_date, '%Y-%m-%d')
    except ValueError:
        logger.error("Invalid date format. Please use YYYY-MM-DD format.")
        sys.exit(1)
    
    # Initialize connection manager
    connection_manager = SnowflakeConnectionManager()
    
    if not connection_manager.validate_config():
        logger.error("Snowflake credentials not configured.")
        sys.exit(1)
    
    # Get database engine
    engine = connection_manager.get_engine()
    
    # Generate date range
    date_list = generate_date_range(start_date, end_date)
    logger.info(f"Processing {len(date_list)} dates")
    
    # Extract data for each date
    all_data = []
    for date in date_list:
        try:
            metrics_list = extract_metrics_for_date(engine, date)
            # Extend instead of append since extract_metrics_for_date returns a list
            all_data.extend(metrics_list)
        except Exception as e:
            logger.error(f"Error processing date {date}: {str(e)}")
            continue
    
    # Export to Excel
    if all_data:
        export_to_excel(all_data, output_file)
        logger.info("Data extraction completed successfully!")
    else:
        logger.error("No data extracted. Please check the logs.")
        sys.exit(1)


if __name__ == "__main__":
    main()
