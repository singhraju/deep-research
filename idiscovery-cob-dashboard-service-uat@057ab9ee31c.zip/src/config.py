from dotenv import load_dotenv
import os
import configparser
import logging

logger = logging.getLogger(__name__)


def _get_bool_env(name: str, default: str = "false") -> bool:
    return os.environ.get(name, default).lower() == "true"

# Initialize vault configuration reader with error handling
vault_config = configparser.ConfigParser()
try:
    vault_config.read('/vault/secrets/creds')
except Exception as e:
    # Vault not available in local development, use environment variables only
    pass


load_dotenv()

SERVICE_HOST = os.environ.get("SERVICE_HOST") or "0.0.0.0"
SERVICE_PORT = os.environ.get("SERVICE_PORT") or "8000"
SERVICE_VERSION = os.environ.get("SERVICE_VERSION") or "v1"
SERVICE_PREFIX = os.environ.get("SERVICE_PREFIX") or "cobdashboard"
RELOAD = os.environ.get("RELOAD", "true").lower() == "true"
NUM_WORKERS = os.environ.get("NUM_WORKERS", "8")  # Production: 4 workers for better performance
INCLUDE_ERROR_STACK = True

# Non-sensitive Snowflake configuration (loaded from environment)
# Sensitive credentials (SNOWFLAKE_USER, SNOWFLAKE_PASSWORD) are handled by SecretHandler
SNOWFLAKE_ACCOUNT = os.environ.get("SNOWFLAKE_ACCOUNT") or "carelon-edaprod1.privatelink"
SNOWFLAKE_ROLE = os.environ.get("SNOWFLAKE_ROLE")
SNOWFLAKE_WAREHOUSE = os.environ.get("SNOWFLAKE_WAREHOUSE")
SNOWFLAKE_SCHEMA = os.environ.get("SNOWFLAKE_SCHEMA")
SNOWFLAKE_DATABASE = os.environ.get("SNOWFLAKE_DATABASE")

# Redis configuration
REDIS_ENABLED = os.environ.get("REDIS_ENABLED", "True").lower() == "true" 
REDIS_HOST = os.environ.get("REDIS_HOST", "localhost")
REDIS_PORT = int(os.environ.get("REDIS_PORT", "6379"))
REDIS_SOCKET_CONNECT_TIMEOUT = int(os.environ.get("REDIS_SOCKET_CONNECT_TIMEOUT", "10"))
REDIS_SOCKET_KEEPALIVE = os.environ.get("REDIS_SOCKET_KEEPALIVE", "False").lower() == "true"
REDIS_MAX_CONNECTIONS = int(os.environ.get("REDIS_MAX_CONNECTIONS", "100"))
REDIS_RETRY_ON_TIMEOUT = os.environ.get("REDIS_RETRY_ON_TIMEOUT", "True").lower() == "true"
REDIS_HEALTH_CHECK_INTERVAL = int(os.environ.get("REDIS_HEALTH_CHECK_INTERVAL", "30"))
REDIS_DECODE_RESPONSES = os.environ.get("REDIS_DECODE_RESPONSES", "True").lower() == "true"
REDIS_CONNECTION_POOL_KWARGS = {
    "max_connections": int(os.environ.get("REDIS_MAX_CONNECTIONS", "100")),
    "retry_on_timeout": os.environ.get("REDIS_RETRY_ON_TIMEOUT", "True").lower() == "true",
    "socket_keepalive": os.environ.get("REDIS_SOCKET_KEEPALIVE", "True").lower() == "true",
    "socket_connect_timeout": int(os.environ.get("REDIS_SOCKET_CONNECT_TIMEOUT", "10")),
    "health_check_interval": int(os.environ.get("REDIS_HEALTH_CHECK_INTERVAL", "30")),
}

# Session Cache Configuration (used for session-based metric caching)
SESSION_CACHE_ENABLED = os.environ.get("SESSION_CACHE_ENABLED", "true").lower() == "true"
SESSION_CACHE_TTL = int(os.environ.get("SESSION_CACHE_TTL", "28800"))  # 8 hours
SESSION_CACHE_LOCK_TTL = int(os.environ.get("SESSION_CACHE_LOCK_TTL", "120"))  # 2 minutes
SESSION_CACHE_WAIT_TIMEOUT = int(os.environ.get("SESSION_CACHE_WAIT_TIMEOUT", "60"))  # 60 seconds
SESSION_CACHE_PARALLEL_WORKERS = int(os.environ.get("SESSION_CACHE_PARALLEL_WORKERS", "100"))  # Concurrent API calls (matches API count)
SESSION_CACHE_CHUNK_SIZE = int(os.environ.get("SESSION_CACHE_CHUNK_SIZE", "1000"))  # Records per chunk

# Metric-Level Cache Configuration (for 6 core Director APIs)
METRIC_CACHE_TTL = int(os.environ.get("METRIC_CACHE_TTL", "60"))  # 1 minutes default


# Cache Full Dataset Limit (used for cache warming and Excel downloads)
CACHE_FULL_DATASET_LIMIT = int(os.environ.get("CACHE_FULL_DATASET_LIMIT", "999999"))  # Full dataset limit

# OpenAI Configuration (for AI Coach)
OPENAI_BASE_URL = os.environ.get("OPENAI_BASE_URL", "https://api.horizon.elevancehealth.com/openai/v1/")
OPENAI_DEFAULT_MODEL = os.environ.get("OPENAI_DEFAULT_MODEL", "gpt-5.4-mini")
OPENAI_REASONING_MODEL = os.environ.get("OPENAI_REASONING_MODEL", "gpt-5.4-mini")
OPENAI_REASONING_EFFORT = os.environ.get("OPENAI_REASONING_EFFORT", "low")

# Model fallback list (comma-separated, tried in order if primary fails)
OPENAI_MODEL_FALLBACK = [
    m.strip() for m in os.environ.get(
        "OPENAI_MODEL_FALLBACK",
        "gpt-5.4-nano,gpt-5.2,gpt-5-mini,gpt-5-nano"
    ).split(",") if m.strip()
]

# Horizon OAuth credentials (from vault first, then environment variables)
try:
    HORIZON_CLIENT_ID = vault_config.get('default', 'HORIZON_CLIENT_ID', fallback=os.environ.get("HORIZON_CLIENT_ID"))
    HORIZON_CLIENT_SECRET = vault_config.get('default', 'HORIZON_CLIENT_SECRET', fallback=os.environ.get("HORIZON_CLIENT_SECRET"))
except Exception:
    # Fallback to environment variables only if vault access fails
    HORIZON_CLIENT_ID = os.environ.get("HORIZON_CLIENT_ID")
    HORIZON_CLIENT_SECRET = os.environ.get("HORIZON_CLIENT_SECRET")
HORIZON_PROJECT = os.environ.get("HORIZON_PROJECT", "IDISCOVERY")
HORIZON_AUTH_URL = os.environ.get("HORIZON_AUTH_URL", "https://api.horizon.elevancehealth.com/v2/oauth2/token")
HORIZON_REQUEST_TIMEOUT = int(os.environ.get("HORIZON_REQUEST_TIMEOUT", "60"))
API_AUTH_ENABLED = _get_bool_env("API_AUTH_ENABLED", "false")
API_AUTH_JWKS_URL = os.environ.get(
    "API_AUTH_JWKS_URL",
    "https://idiscovery-auth.api.dev.carelon.com/v1/auth/jwks-keys",
)

# AI Coach Configuration

AI_COACH_ENABLED = _get_bool_env("AI_COACH_ENABLED", "true")
AI_COACH_FRONTLINE_ENABLED = _get_bool_env("AI_COACH_FRONTLINE_ENABLED", "true")
AI_COACH_MANAGER_ENABLED = _get_bool_env("AI_COACH_MANAGER_ENABLED", "true")
AI_COACH_DIRECTOR_ENABLED = _get_bool_env("AI_COACH_DIRECTOR_ENABLED", "true")
AI_COACH_FL_AUDITOR_ENABLED = _get_bool_env("AI_COACH_FL_AUDITOR_ENABLED", "true")
AI_COACH_AUDITOR_MANAGER_ENABLED = _get_bool_env("AI_COACH_AUDITOR_MANAGER_ENABLED", "true")
AI_COACH_WORKFORCE_ENABLED = _get_bool_env("AI_COACH_WORKFORCE_ENABLED", "true")
AI_COACH_PERSONA_FLAGS = {
    "frontline": AI_COACH_FRONTLINE_ENABLED,
    "manager": AI_COACH_MANAGER_ENABLED,
    "director": AI_COACH_DIRECTOR_ENABLED,
    "fl_auditor": AI_COACH_FL_AUDITOR_ENABLED,
    "auditor_manager": AI_COACH_AUDITOR_MANAGER_ENABLED,
    "workforce": AI_COACH_WORKFORCE_ENABLED,
}

AI_COACH_MAX_TOKENS = int(os.environ.get("AI_COACH_MAX_TOKENS", "10000"))
AI_COACH_TIMEOUT = int(os.environ.get("AI_COACH_TIMEOUT", "60"))  # seconds
AI_COACH_CACHE_TTL = int(os.environ.get("AI_COACH_CACHE_TTL", "3600"))  # 1 hour cache for AI summaries

def is_ai_coach_enabled(persona: str) -> bool:
    normalized_persona = persona.strip().lower()
    persona_enabled = AI_COACH_PERSONA_FLAGS.get(normalized_persona)

    if persona_enabled is None:
        logger.warning("Unknown AI Coach persona '%s' requested; feature will remain disabled", persona)
        return False

    return AI_COACH_ENABLED and persona_enabled

# OpenAI Token Strategy
# Set to "false" to skip Framework's Horizon token call and use direct fallback token generation
USE_FRAMEWORK_HORIZON_TOKEN = os.environ.get("USE_FRAMEWORK_HORIZON_TOKEN", "true").lower() == "true"

# Change Tracking KPIs Configuration
CHANGE_TRACKING_KPIS = os.environ.get("CHANGE_TRACKING_KPIS", "Cycle Time,Audit Score %,Flip Rate Manual,Flip Rate Touchless,Non-Value Add %,Lead Accuracy").split(",")

# Change Tracking Savings Types Configuration
CHANGE_TRACKING_SAVINGS_TYPES = os.environ.get("CHANGE_TRACKING_SAVINGS_TYPES", "CoC,SVRO,PIAI,Self-Funded").split(",")


# Workforce IQ - LOB mapping from payload values to COB_AI_MEMBERSHIP_DATA LOB values
MEMBERSHIP_LOB_MAP = {
    "Medicare": "GB CARE",
    "EGR": "GB CARE",
    "GRS": "GB CARE",
    "MMP": "GB CARE",
    "CrossOver": "GB CAID",
    "KCP": "GB CAID",
    "MedSupp": "GB CAID",
    "SUP": "GB CAID",
    "INT": "GB CAID",
    "Medicaid": "GB CAID",
    "Commercial": "CSBD",
}

# Workforce IQ - LOB mapping from payload values to COB_AI_STAFFING_CATEGORY_XWALK LOB values
STAFFING_CATEGORY_LOB_MAP = {
    "Medicare": "Medicare",
    "EGR": "Medicare",
    "GRS": "Medicare",
    "MMP": "Medicare",
    "CrossOver": "Medicaid",
    "KCP": "Medicaid",
    "MedSupp": "Medicaid",
    "SUP": "Medicaid",
    "INT": "Medicaid",
    "Medicaid": "Medicaid",
    "Commercial": "Commercial",
}

# Workforce IQ - LOB mapping from payload values to COB_AI_OPEN_POSITIONS LOB values
OPEN_POSITIONS_LOB_MAP = {
    "Medicare": "GB Medicare",
    "EGR": "GB Medicare",
    "GRS": "GB Medicare",
    "MMP": "GB Medicare",
    "CrossOver": "GB Medicaid",
    "KCP": "GB Medicaid",
    "MedSupp": "GB Medicaid",
    "SUP": "GB Medicaid",
    "INT": "GB Medicaid",
    "Medicaid": "GB Medicaid",
    "Commercial": "Commercial",
}
