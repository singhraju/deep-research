from .user_time import router as user_time_router
from .user_metrics import router as user_metrics_router
from .user_activity import router as user_activity_router
from .audit_score_gauge import router as audit_score_gauge_router
from .workitems_drilldown import router as workitems_drilldown_router
from .auditscore_drilldown import router as auditscore_drilldown_router
from .production_percentage_gauge import router as production_percentage_gauge_router
from .fusetime_drilldown import router as fusetime_drilldown_router
from .production_pct_drilldown import router as production_pct_drilldown_router
from .ai_coach import router as ai_coach_router
from .audit_error_drilldown import router as audit_error_drilldown_router


__all__ = [
    "user_time_router",
    "user_metrics_router",
    "user_activity_router",
    "audit_score_gauge_router",
    "workitems_drilldown_router",
    "auditscore_drilldown_router",
    "production_percentage_gauge_router",
    "fusetime_drilldown_router",
    "production_pct_drilldown_router",
    "ai_coach_router",
    "audit_error_drilldown_router",
]
