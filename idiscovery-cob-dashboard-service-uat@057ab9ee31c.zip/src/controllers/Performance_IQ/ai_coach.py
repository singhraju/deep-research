import logging
import time
from datetime import datetime, timezone
from fastapi import APIRouter, Response, status
import config
from schema import AICoachRequest, AICoachResponse
from services.openai_service import generate_performance_summary, normalize_ai_summary
from services.metrics_aggregator import fetch_frontline_metrics

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Performance_IQ"])

@router.post(
    "/ai-coach",
    response_model=AICoachResponse,
    summary="Get AI Coach Performance Summary",
    description="""
Retrieve AI-generated performance summary based on user's KPIs and metrics.

**Input Parameters:**
- **user_id** (required): The unique identifier of the user
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values

**Response Fields:**
- **performance_summary**: AI-generated summary analyzing work items, audit scores, production percentage, and other KPIs

**Status:** AI-powered performance coaching using OpenAI GPT models
""",
)
async def get_ai_coach(request: AICoachRequest, response: Response) -> AICoachResponse:
    if not config.is_ai_coach_enabled("frontline"):
        return AICoachResponse(
            status="disabled",
            user_id=request.user_id,
            performance_summary="AI Coach feature is currently disabled",
            message="Feature disabled by configuration"
        )
    
    try:
        logger.info(f"AI Coach request for user {request.user_id} ({request.start_date} to {request.end_date})")
        
        # Fetch ENHANCED metrics with team averages and goals
        metrics_data = await fetch_frontline_metrics(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date,
            lob=request.lob,
            session_id=request.session_id
        )
        
        if "error" in metrics_data:
            logger.error(f"AI Coach metrics fetch failed for {request.user_id}: {metrics_data.get('error')}")
            response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            return AICoachResponse(
                status="error",
                user_id=request.user_id,
                performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
                message=f"Failed to fetch AI Coach metrics: {metrics_data.get('error')}",
                data_gaps=metrics_data.get("data_gaps", [])
            )
        
        # Generate ENHANCED summary with structured output
        start_time = time.time()
        summary = await generate_performance_summary(
            user_id=request.user_id,
            metrics_data=metrics_data,
            role="frontline",
            start_date=request.start_date,
            end_date=request.end_date,
            lob=request.lob
        )
        latency_ms = int((time.time() - start_time) * 1000)

        normalized_summary = normalize_ai_summary(summary, include_legacy_key=True)
        enhanced_data = normalized_summary["parsed_payload"]
        summary_text = normalized_summary["performance_summary"]
        
        # Return ENHANCED response with optional fields populated
        return AICoachResponse(
            status="success",
            user_id=request.user_id,
            performance_summary=summary_text,
            message="AI Coach analysis completed successfully",
            # NEW enhanced fields
            confidence=enhanced_data.get("confidence"),
            primary_issue=enhanced_data.get("primary_issue"),
            primary_metric=enhanced_data.get("primary_metric"),
            secondary_issues=enhanced_data.get("secondary_issues"),
            data_gaps=enhanced_data.get("data_gaps") or metrics_data.get("data_gaps", []),
            recommended_action=enhanced_data.get("recommended_action"),
            severity=enhanced_data.get("severity"),
            metadata={
                "role": "frontline",
                "metrics_analyzed": list(metrics_data.get("metrics", {}).keys()),
                "benchmarks_used": ["goal", "team_avg"],
                "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "latency_ms": latency_ms
            }
        )
        
    except Exception as e:
        logger.error(f"AI Coach error for user {request.user_id}: {str(e)}")

        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return AICoachResponse(
            status="error",
            user_id=request.user_id,
            performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
            message=f"Error: {str(e)}"
        )