import logging
import asyncio
import math
from typing import Optional, List
from datetime import datetime
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import (
    AuditErrorDrilldownPaginatedRequest,
    AuditErrorDrilldownPaginatedResponse,
    AuditErrorDrilldownDownloadRequest,
    AuditErrorRecord,
    PageResponse,
    AuditPeriod
)
import config
from controllers.Performance_IQ.user_metrics import AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY, AUDIT_ERROR_COUNT_QUERY

logger = logging.getLogger(__name__)

router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()


def format_date_mmddyyyy(date_str: str) -> str:
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str)[:10], "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def build_lob_filter(lob: Optional[List[str]] = None, column: str = "i.LOB") -> str:
    if not lob or len(lob) == 0:
        return ""
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND ({column} IN ('{lob_values}') OR {column} IS NULL)"
    elif null_requested:
        return f"AND {column} IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND {column} IN ('{lob_values}')"

def build_audit_month_year_filter(
    audit_periods: Optional[List[AuditPeriod]] = None,
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append((month_value, year_value))

    if not valid_periods:
        return ""

    conditions = [
        f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
        for month, year in valid_periods
    ]

    return "AND (" + " OR ".join(conditions) + ")"


AUDIT_ERROR_DRILLDOWN_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.INTAKESOURCESYSTEM,
        i.INVNTRY_TYPE,
        i.LOB,
        i.PLATFORM
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY i.PYID
        ORDER BY i.PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(i.PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        i.PYRESOLVEDTIMESTAMP,
        i.INTAKESOURCESYSTEM,
        i.INVNTRY_TYPE,
        i.LOB,
        i.PLATFORM
    FROM latest_inventory i
    WHERE UPPER(TRIM(i.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND i.PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND UPPER(TRIM(i.PYRESOLVEDUSERID)) = '{{user_id}}'
      {{lob_filter}}
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.LOB,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(ap.PYSTATUSWORK)) AS AUDIT_STATUS,
        ap.AUDIT_MONTH,
        ap.AUDIT_YEAR,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        DATE(ap.PXCREATEDATETIME) AS RESOLVED_DATE,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.createtimestamp AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    ap.AUDIT_CASE_ID AS work_item_id,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS error_category,
    COALESCE(up.USERNAME, 'N/A') AS associate_name,
    aa.DATE_ASSESSED AS date_assessed,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(i.LOB, 'N/A') AS lob,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(aa.SPECIALISTERRORCORRECTED, 'N/A') AS specialist_error_corrected,
    COALESCE(ap.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ap.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM filtered_inventory i
JOIN audit_profile_deduped ap
  ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
 AND ap.rn = 1
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
LEFT JOIN deduped_user_profile up
  ON up.USERID = i.ASSOCIATE_ID
 AND up.rn = 1
ORDER BY
    ap.RESOLVED_DATE DESC,
    ap.AUDIT_CASE_ID,
    aa.ERRORCATEGORY
"""

AUDIT_ERROR_DRILLDOWN_AUDIT_PERIOD_QUERY = f"""
WITH audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(ap.PYSTATUSWORK)) AS AUDIT_STATUS,
        ap.AUDIT_MONTH,
        ap.AUDIT_YEAR,
        ap.LOB,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        DATE(ap.PXCREATEDATETIME) AS RESOLVED_DATE,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) = UPPER('{{user_id}}')
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      {{lob_filter}}
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.createtimestamp AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
latest_inventory AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(i.PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        i.INTAKESOURCESYSTEM,
        i.INVNTRY_TYPE,
        i.LOB,
        i.PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    ap.AUDIT_CASE_ID AS work_item_id,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS error_category,
    COALESCE(up.USERNAME, 'N/A') AS associate_name,
    aa.DATE_ASSESSED AS date_assessed,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(i.LOB, ap.LOB, 'N/A') AS lob,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(aa.SPECIALISTERRORCORRECTED, 'N/A') AS specialist_error_corrected,
    COALESCE(ap.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ap.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM audit_profile_deduped ap
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
LEFT JOIN latest_inventory i
  ON i.ORIGINAL_OHI_CASE_ID = ap.ORIGINAL_OHI_CASE_ID
 AND i.rn = 1
LEFT JOIN deduped_user_profile up
  ON up.USERID = ap.AUDIT_SUBJECT_ID
 AND up.rn = 1
WHERE ap.rn = 1
  {{audit_period_filter}}
ORDER BY
    ap.RESOLVED_DATE DESC,
    ap.AUDIT_CASE_ID,
    aa.ERRORCATEGORY
"""

DEFAULT_AUDIT_ERROR_ORDER_BY = "ap.RESOLVED_DATE DESC,\n    ap.AUDIT_CASE_ID,\n    aa.ERRORCATEGORY"

DISPLAY_AUDIT_ERROR_DATE_ASSESSED_SQL = "DATE(aa.DATE_ASSESSED)"

SORTABLE_AUDIT_ERROR_COLUMNS = {
    "work_item_id": "ap.AUDIT_CASE_ID",
    "work_type": "COALESCE(i.INTAKESOURCESYSTEM, 'N/A')",
    "error_category": "COALESCE(aa.ERRORCATEGORY, 'N/A')",
    "associate_name": "COALESCE(up.USERNAME, 'N/A')",
    "date_assessed": DISPLAY_AUDIT_ERROR_DATE_ASSESSED_SQL,
    "inventory_type": "COALESCE(i.INVNTRY_TYPE, 'N/A')",
    "lob": "COALESCE(i.LOB, 'N/A')",
    "platform": "COALESCE(i.PLATFORM, 'N/A')",
    "error_corrected": "COALESCE(aa.SPECIALISTERRORCORRECTED, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_AUDIT_ERROR_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_AUDIT_ERROR_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid audit error sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_AUDIT_ERROR_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid audit error sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_AUDIT_ERROR_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "date_assessed":
        tie_breakers.append("ap.RESOLVED_DATE DESC")
    if normalized_sort_by != "work_item_id":
        tie_breakers.append("ap.AUDIT_CASE_ID ASC")
    if normalized_sort_by != "error_category":
        tie_breakers.append("aa.ERRORCATEGORY ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_audit_error_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY\n    {DEFAULT_AUDIT_ERROR_ORDER_BY}",
        f"ORDER BY\n    {order_by_clause}",
        1,
    )


@router.post(
    "/audit-error-drilldown",
    response_model=AuditErrorDrilldownPaginatedResponse,
    summary="Get Audit Error Drilldown",
    description="""
Retrieve paginated list of audit errors for detailed table display.

**Input Parameters:**
- **screen_id** (optional): Screen identifier, defaults to 'audit_error'
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user (e.g., 'AF05867')
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
  - **lob** (optional): List of Line of Business values (e.g., ['Commercial'])
- **page** (optional): Pagination parameters:
  - **page_limit**: Records per page (default: 50, max: 500)
  - **page**: Page number (1-indexed, default: 1)

**Response Fields (per record):**
- **work_item_id**: Unique audit case identifier
- **work_type**: Type of work item (intake source system)
- **error_category**: Category of the audit error
- **associate_name**: Name of the associate
- **date_assessed**: Date when the audit was assessed
- **inventory_type**: Inventory type classification
- **lob**: Line of Business
- **platform**: Processing platform
- **error_corrected**: Whether the specialist error was corrected (Y/N)

**Data Source:** COB_AI_INVNTRY_PROFILE, COB_AI_AUDIT_PROFILE, COB_AI_AUDIT_ACTIVITY, COB_AI_USER_PROFILE
""",
)
async def get_audit_error_drilldown(
    request: AuditErrorDrilldownPaginatedRequest
) -> AuditErrorDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        lob = request.query.lob

        page_limit = request.page.page_limit
        page = request.page.page or 1
        offset = (page - 1) * page_limit

        count_inventory_lob_filter = build_lob_filter(lob, column="LOB")
        drilldown_inventory_lob_filter = build_lob_filter(lob, column="i.LOB")
        audit_lob_filter = build_lob_filter(lob, column="ap.LOB")
        engine = connection_manager.get_engine()

        valid_audit_periods = [
            period
            for period in (request.query.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)

        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="ap.AUDIT_MONTH",
                audit_year_column="ap.AUDIT_YEAR",
            )

            count_query = AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY.format(
                user_id=user_id,
                lob_filter=audit_lob_filter,
                audit_period_filter=audit_period_filter,
            )

            drilldown_query = AUDIT_ERROR_DRILLDOWN_AUDIT_PERIOD_QUERY.format(
                user_id=user_id,
                lob_filter=audit_lob_filter,
                audit_period_filter=audit_period_filter,
            )
        else:
            count_query = AUDIT_ERROR_COUNT_QUERY.format(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob_filter=count_inventory_lob_filter
            )

            drilldown_query = AUDIT_ERROR_DRILLDOWN_QUERY.format(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob_filter=drilldown_inventory_lob_filter
            )

        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = int(count_result[0].get("AUDIT_ERROR_COUNT", 0)) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0

        drilldown_query = apply_custom_sort_to_audit_error_query(
            drilldown_query,
            request.query.sort_by,
            request.query.sort_direction,
        )
        drilldown_query += f"\nLIMIT {page_limit} OFFSET {offset}"

        records = await engine.execute_query_async(drilldown_query, limit=page_limit)

        audit_errors = [
            AuditErrorRecord(
                work_item_id=str(record.get("WORK_ITEM_ID") or "N/A"),
                work_type=str(record.get("WORK_TYPE") or "N/A"),
                error_category=str(record.get("ERROR_CATEGORY") or "N/A"),
                associate_name=str(record.get("ASSOCIATE_NAME") or "N/A"),
                date_assessed=format_date_mmddyyyy(str(record.get("DATE_ASSESSED") or "")),
                inventory_type=str(record.get("INVENTORY_TYPE") or "N/A"),
                lob=str(record.get("LOB") or "N/A"),
                platform=str(record.get("PLATFORM") or "N/A"),
                error_corrected=str(record.get("SPECIALIST_ERROR_CORRECTED") or "N/A"),
                audit_month=str(record.get("AUDIT_MONTH") or "N/A"),
                audit_year=str(record.get("AUDIT_YEAR") or "N/A")
            )
            for record in records
        ] if records else []

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item_id": "Unique identifier for the audit work item/case",
            "work_type": "Type of work item (intake source system)",
            "error_category": "Category of the audit error identified",
            "associate_name": "Name of the associate who worked on the item",
            "date_assessed": "Date when the audit was assessed",
            "inventory_type": "Type of inventory classification for the work item",
            "lob": "Line of Business associated with the work item",
            "platform": "Platform where the work item was processed",
            "error_corrected": "Indicates whether the specialist error was corrected (Y/N)",
            "audit_month": "Audit month associated with the audited case",
            "audit_year": "Audit year associated with the audited case"
        }

        return AuditErrorDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            user_id=user_id,
            page=page_response,
            records=audit_errors,
            message="Audit error records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated audit error drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page.page_limit,
            page=request.page.page or 1,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return AuditErrorDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            user_id=request.query.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve audit error records: {str(e)}"
        )


@router.post(
    "/audit-error-drilldown/download-excel",
    summary="Download Audit Error Drilldown as Excel",
    description="""
Download complete audit error drilldown data as an Excel file.

**Input Parameters:**
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
  - **lob** (optional): List of Line of Business values

**Returns:** Excel file (.xlsx) with all audit error records
""",
)
async def download_audit_error_drilldown_excel(
    request: AuditErrorDrilldownDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        lob = request.query.lob

        inventory_lob_filter = build_lob_filter(lob, column="i.LOB")
        audit_lob_filter = build_lob_filter(lob, column="ap.LOB")
        engine = connection_manager.get_engine()

        valid_audit_periods = [
            period
            for period in (request.query.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)

        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="ap.AUDIT_MONTH",
                audit_year_column="ap.AUDIT_YEAR",
            )

            drilldown_query = AUDIT_ERROR_DRILLDOWN_AUDIT_PERIOD_QUERY.format(
                user_id=user_id,
                lob_filter=audit_lob_filter,
                audit_period_filter=audit_period_filter,
            )
        else:
            drilldown_query = AUDIT_ERROR_DRILLDOWN_QUERY.format(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob_filter=inventory_lob_filter
            )

        records = await engine.execute_query_async(drilldown_query, limit=config.CACHE_FULL_DATASET_LIMIT)

        wb = Workbook()
        ws = wb.active
        ws.title = "Audit Error Drilldown"

        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")

        headers = [
            "Work Item ID",
            "Work Type",
            "Error Category",
            "Associate Name",
            "Date Assessed",
            "Audit Month",
            "Audit Year",
            "Inventory Type",
            "LOB",
            "Platform",
            "Error Corrected",
        ]

        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment

        for row_num, record in enumerate(records, start=2):
            ws.cell(row=row_num, column=1, value=str(record.get("WORK_ITEM_ID") or "N/A"))
            ws.cell(row=row_num, column=2, value=str(record.get("WORK_TYPE") or "N/A"))
            ws.cell(row=row_num, column=3, value=str(record.get("ERROR_CATEGORY") or "N/A"))
            ws.cell(row=row_num, column=4, value=str(record.get("ASSOCIATE_NAME") or "N/A"))
            ws.cell(row=row_num, column=5, value=format_date_mmddyyyy(str(record.get("DATE_ASSESSED") or "")))
            ws.cell(row=row_num, column=6, value=str(record.get("AUDIT_MONTH") or "N/A"))
            ws.cell(row=row_num, column=7, value=str(record.get("AUDIT_YEAR") or "N/A"))
            ws.cell(row=row_num, column=8, value=str(record.get("INVENTORY_TYPE") or "N/A"))
            ws.cell(row=row_num, column=9, value=str(record.get("LOB") or "N/A"))
            ws.cell(row=row_num, column=10, value=str(record.get("PLATFORM") or "N/A"))
            ws.cell(row=row_num, column=11, value=str(record.get("SPECIALIST_ERROR_CORRECTED") or "N/A"))

        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

        output = BytesIO()
        wb.save(output)
        output.seek(0)

        filename = f"audit_error_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for audit error drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")