import logging
from typing import Optional, List
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import AuditScoreGaugeRequest, AuditScoreGaugeResponse, AuditScoreTrend, AuditPeriod
from controllers.Performance_IQ.user_metrics import (
    AUDIT_SCORE_AUDIT_PERIOD_QUERY,
    build_audit_month_year_filter,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

AUDIT_SCORE_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      {{lob_filter}}
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
),
audit_deduped AS (
    SELECT 
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID ORDER BY a.PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = '{{user_id}}'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      {{lob_filter}}
)
SELECT 
    a.AUDIT_SUBJECT_ID,
    ROUND(AVG(a.AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT i.PYID) AS total_cases_audited
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
GROUP BY a.AUDIT_SUBJECT_ID
"""

AUDIT_SCORE_TREND_QUERY = f"""
WITH date_range AS (
    SELECT
        DATEDIFF(day, '{{start_date}}'::DATE, '{{end_date}}'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{lob_filter}}
),
audit_deduped AS (
    SELECT 
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        ROW_NUMBER() OVER (
            PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID 
            ORDER BY a.PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = '{{user_id}}'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      {{lob_filter}}
),
audit_with_completion_date AS (
    SELECT 
        i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        i.PYID AS case_id
    FROM filtered_inventory i
    INNER JOIN audit_deduped a
        ON i.PYID = a.CASE_TO_AUDIT
        AND a.rn = 1
),
grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE 
            WHEN g.grouping_type = 'daily' THEN a.case_completion_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.case_completion_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.case_completion_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.case_completion_date)
            ELSE DATE_TRUNC('year', a.case_completion_date)
        END AS group_key,
        a.case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        a.case_id
    FROM audit_with_completion_date a
    CROSS JOIN grouping_logic g
)
SELECT 
    CASE 
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(GREATEST(group_key, '{{start_date}}'::DATE), 'MM/DD') || ' - ' ||
            TO_CHAR(LEAST(DATEADD(day, 6, group_key), '{{end_date}}'::DATE), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT audit_id) AS total_audits,
    COUNT(DISTINCT case_id) AS total_cases_audited,
    MIN(case_completion_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
"""

AUDIT_SCORE_TREND_AUDIT_PERIOD_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT AS case_id,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        CASE
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JAN', 'JANUARY') THEN 1
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('FEB', 'FEBRUARY') THEN 2
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('MAR', 'MARCH') THEN 3
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('APR', 'APRIL') THEN 4
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('MAY') THEN 5
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JUN', 'JUNE') THEN 6
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JUL', 'JULY') THEN 7
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('AUG', 'AUGUST') THEN 8
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('SEP', 'SEPT', 'SEPTEMBER') THEN 9
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('OCT', 'OCTOBER') THEN 10
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('NOV', 'NOVEMBER') THEN 11
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('DEC', 'DECEMBER') THEN 12
            ELSE NULL
        END AS audit_month_number,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME  DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('{{user_id}}')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      {{lob_filter}}
),
grouped_data AS (
    SELECT
        CASE
            WHEN '{{grouping_type}}' = 'monthly'
                THEN TRIM(a.AUDIT_YEAR) || '-' || LPAD(TO_VARCHAR(a.audit_month_number), 2, '0')
            WHEN '{{grouping_type}}' = 'quarterly'
                THEN TRIM(a.AUDIT_YEAR) || '-Q' || TO_VARCHAR(FLOOR((a.audit_month_number - 1) / 3) + 1)
            ELSE TRIM(a.AUDIT_YEAR)
        END AS period,
        CASE
            WHEN '{{grouping_type}}' = 'monthly'
                THEN TO_DATE(TRIM(a.AUDIT_YEAR) || '-' || LPAD(TO_VARCHAR(a.audit_month_number), 2, '0') || '-01')
            WHEN '{{grouping_type}}' = 'quarterly'
                THEN DATE_FROM_PARTS(
                    TRY_TO_NUMBER(TRIM(a.AUDIT_YEAR)),
                    (FLOOR((a.audit_month_number - 1) / 3) * 3) + 1,
                    1
                )
            ELSE DATE_FROM_PARTS(TRY_TO_NUMBER(TRIM(a.AUDIT_YEAR)), 1, 1)
        END AS sort_date,
        a.AUDIT_SCORE,
        a.audit_id,
        a.case_id
    FROM audit_deduped a
    WHERE a.rn = 1
      {{audit_period_filter}}
      AND a.audit_month_number IS NOT NULL
)
SELECT
    period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT audit_id) AS total_audits,
    COUNT(DISTINCT case_id) AS total_cases_audited,
    MIN(sort_date) AS sort_date
FROM grouped_data
GROUP BY period
ORDER BY sort_date
"""

AUDIT_MONTH_TO_NUMBER = {
    "JAN": 1,
    "JANUARY": 1,
    "FEB": 2,
    "FEBRUARY": 2,
    "MAR": 3,
    "MARCH": 3,
    "APR": 4,
    "APRIL": 4,
    "MAY": 5,
    "JUN": 6,
    "JUNE": 6,
    "JUL": 7,
    "JULY": 7,
    "AUG": 8,
    "AUGUST": 8,
    "SEP": 9,
    "SEPT": 9,
    "SEPTEMBER": 9,
    "OCT": 10,
    "OCTOBER": 10,
    "NOV": 11,
    "NOVEMBER": 11,
    "DEC": 12,
    "DECEMBER": 12,
}

def get_valid_audit_periods(audit_periods: Optional[List[AuditPeriod]] = None):
    valid_periods = []
    seen = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""
        month_number = AUDIT_MONTH_TO_NUMBER.get(month_value.upper())

        if not month_value or not year_value or month_number is None:
            continue

        try:
            year_number = int(year_value)
        except (TypeError, ValueError):
            continue

        key = (year_number, month_number)
        if key in seen:
            continue

        seen.add(key)
        valid_periods.append({
            "period": period,
            "year_number": year_number,
            "month_number": month_number,
        })

    valid_periods.sort(key=lambda item: (item["year_number"], item["month_number"]))
    return valid_periods

def determine_audit_period_grouping(valid_audit_periods) -> str:
    unique_months = {
        (period["year_number"], period["month_number"])
        for period in valid_audit_periods
    }
    if len(unique_months) <= 6:
        return "monthly"

    unique_quarters = {
        (period["year_number"], ((period["month_number"] - 1) // 3) + 1)
        for period in valid_audit_periods
    }
    if len(unique_quarters) <= 6:
        return "quarterly"

    return "yearly"


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def execute_gauge_query(engine, query: str):
    records = engine.execute_query(query, limit=1)
    return records[0].get("AVG_AUDIT_SCORE") if records else None

def execute_trend_query(engine, query: str):
    return engine.execute_query(query)

@router.post(
    "/audit-score-gauge",
    response_model=AuditScoreGaugeResponse,
    summary="Get Audit Score for Gauge",
    description="""
Retrieve audit score as an integer for gauge visualization along with monthly trend data.

**Input Parameters:**
- **user_id** (required): The unique identifier of the user (e.g., 'AA99826')
- **start_date** (required): Start date in YYYY-MM-DD format (e.g., '2026-02-01')
- **end_date** (required): End date in YYYY-MM-DD format (e.g., '2026-02-07')
- **lob** (optional): List of Line of Business values to filter (e.g., ['Commercial'])

**Response Fields:**
- **audit_score**: Average audit score as integer (0-100) for gauge display
- **score_trend**: Monthly breakdown array containing:
  - month: Month in YYYY-MM format
  - avg_audit_score: Average score for that month
  - total_cases: Number of audited cases in that month

**Use Case:** Dashboard gauge widget showing overall audit quality performance

**Data Source:** COB_AI_AUDIT_PROFILE table
""",
)
async def get_audit_score_gauge(request: AuditScoreGaugeRequest) -> AuditScoreGaugeResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        lob_filter = build_lob_filter(request.lob)
        engine = connection_manager.get_engine()

        valid_audit_periods = get_valid_audit_periods(request.audit_periods)
        has_audit_periods = bool(valid_audit_periods)

        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=[period["period"] for period in valid_audit_periods],
                audit_month_column="a.AUDIT_MONTH",
                audit_year_column="a.AUDIT_YEAR",
            )
            grouping_type = determine_audit_period_grouping(valid_audit_periods)

            gauge_query = AUDIT_SCORE_AUDIT_PERIOD_QUERY.format(
                user_id=request.user_id,
                lob_filter=lob_filter,
                audit_period_filter=audit_period_filter,
            )

            trend_query = AUDIT_SCORE_TREND_AUDIT_PERIOD_QUERY.format(
                user_id=request.user_id,
                lob_filter=lob_filter,
                audit_period_filter=audit_period_filter,
                grouping_type=grouping_type,
            )
        else:
            gauge_query = AUDIT_SCORE_QUERY.format(
                user_id=request.user_id,
                start_date=request.start_date,
                end_date=request.end_date,
                lob_filter=lob_filter
            )

            trend_query = AUDIT_SCORE_TREND_QUERY.format(
                user_id=request.user_id,
                start_date=request.start_date,
                end_date=request.end_date,
                lob_filter=lob_filter
            )
        
        # Execute queries in parallel
        with ThreadPoolExecutor(max_workers=2) as executor:
            gauge_future = executor.submit(execute_gauge_query, engine, gauge_query)
            trend_future = executor.submit(execute_trend_query, engine, trend_query)
            
            audit_score_value = gauge_future.result()
            trend_records = trend_future.result()
        
        trend_data = [
            AuditScoreTrend(
                period=r["PERIOD"],
                avg_audit_score=float(r["AVG_AUDIT_SCORE"]) if r["AVG_AUDIT_SCORE"] else 0.0,
                total_cases=int(r["TOTAL_AUDITS"]) if r["TOTAL_AUDITS"] else 0
            )
            for r in trend_records
        ]

        if trend_data:
            def sort_key(item):
                period = item.period
                # Handle different period formats for sorting
                if '-Q' in period:  # Quarterly: 2024-Q1
                    year, quarter = period.split('-Q')
                    return (int(year), int(quarter))
                elif len(period) == 7 and '-' in period:  # Monthly: 2024-01
                    year, month = period.split('-')
                    return (int(year), int(month))
                elif '/' in period and ' - ' in period:  # Weekly: 01/01 - 01/07
                    start_date = period.split(' - ')[0]
                    month, day = start_date.split('/')
                    return (int(month), int(day))
                elif '/' in period:  # Daily: 01/01
                    month, day = period.split('/')
                    return (int(month), int(day))
                else:  # Yearly: 2024
                    return (int(period), 0)
            
            trend_data.sort(key=sort_key)
        
        tooltips = {
            "audit_score": "Average audit quality score as an integer percentage, representing overall quality performance",
            "score_trend": "Monthly breakdown showing audit score trends over time with case counts"
        }
        
        return AuditScoreGaugeResponse(
            status="success",
            user_id=request.user_id,
            audit_score=round(float(audit_score_value), 2) if audit_score_value else 0.00,
            score_trend=trend_data,
            message="Audit score retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Audit score gauge query error: {type(e).__name__}: {str(e)}")
        return AuditScoreGaugeResponse(
            status="error",
            user_id=request.user_id,
            audit_score=0,
            score_trend=[],
            message=f"Failed to retrieve audit score: {str(e)}"
        )
