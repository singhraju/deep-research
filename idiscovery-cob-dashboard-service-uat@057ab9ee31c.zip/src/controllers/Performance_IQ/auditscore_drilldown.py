import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import (
    AuditScoreDrilldownPaginatedRequest,
    AuditScoreDrilldownPaginatedResponse,
    AuditScoreDrilldownDownloadRequest,
    AuditScoreRecord,
    PageResponse,
    AuditPeriod,
)
import math
import config

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return "N/A"
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return "N/A"

def clean_resolved_status(status: str) -> str:
    """Convert 'Resolved-Completed' to 'Resolved'"""
    if not status:
        return "N/A"
    return "Resolved" if status.startswith("Resolved") else status

logger = logging.getLogger(__name__)

router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

AUDIT_SCORE_PAGINATED_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYSTATUSWORK,
        PYRESOLVEDUSERID,
        INVNTRY_TYPE,
        CYCLE_TIME,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        INVNTRY_TYPE,
        CYCLE_TIME
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{lob_filter}}
),
audit_deduped AS (
    SELECT 
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PYSTATUSWORK,
        a.LOB,
        a.PXUPDATEDATETIME::DATE AS audit_date,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.PLATFORM,
        a.TARGET_AUDIT,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID 
            ORDER BY a.PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = '{{user_id}}'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      {{lob_filter}}
)
SELECT 
    a.audit_id AS audit_work_item,
    i.PYID AS case_work_item,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK AS audit_status,
    a.LOB,
    i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    i.INVNTRY_TYPE,
    i.CYCLE_TIME,
    COALESCE(a.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(a.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

AUDIT_SCORE_PAGINATED_AUDIT_PERIOD_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PYSTATUSWORK,
        a.LOB,
        a.PXUPDATEDATETIME::DATE AS audit_date,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.PLATFORM,
        a.TARGET_AUDIT,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('{{user_id}}')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      {{lob_filter}}
),
latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        INVNTRY_TYPE,
        CYCLE_TIME,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
)
SELECT
    a.audit_id AS audit_work_item,
    a.CASE_TO_AUDIT AS case_work_item,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK AS audit_status,
    COALESCE(a.LOB, 'N/A') AS LOB,
    i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    i.INVNTRY_TYPE,
    i.CYCLE_TIME,
    COALESCE(a.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(a.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM audit_deduped a
LEFT JOIN latest_inventory i
  ON i.PYID = a.CASE_TO_AUDIT
 AND i.rn = 1
WHERE a.rn = 1
  {{audit_period_filter}}
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_AUDIT_SCORE_ORDER_BY = "i.PYRESOLVEDTIMESTAMP DESC"

DISPLAY_AUDIT_SCORE_RESOLVED_STATUS_SQL = "CASE WHEN a.PYSTATUSWORK LIKE 'Resolved%' THEN 'Resolved' ELSE COALESCE(a.PYSTATUSWORK, 'N/A') END"
DISPLAY_AUDIT_SCORE_RESOLVED_DATE_SQL = "i.PYRESOLVEDTIMESTAMP::DATE"

SORTABLE_AUDIT_SCORE_COLUMNS = {
    "pyid": "a.audit_id",
    "work_type": "COALESCE(a.INTAKESOURCESYSTEM, 'N/A')",
    "audit_cycle_time": "COALESCE(i.CYCLE_TIME, 0)",
    "resolved_status": DISPLAY_AUDIT_SCORE_RESOLVED_STATUS_SQL,
    "lob": "COALESCE(a.LOB, 'N/A')",
    "audit_resolved": DISPLAY_AUDIT_SCORE_RESOLVED_DATE_SQL,
    "platform": "COALESCE(a.PLATFORM, 'N/A')",
    "audit_score": "COALESCE(TRY_TO_DECIMAL(TRIM(a.AUDIT_SCORE)), 0)",
    "targeted_audit_type": "COALESCE(a.TARGET_AUDIT, 'N/A')",
    "inventory_type": "COALESCE(i.INVNTRY_TYPE, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_AUDIT_SCORE_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_AUDIT_SCORE_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid audit score sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_AUDIT_SCORE_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid audit score sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_AUDIT_SCORE_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "audit_resolved":
        tie_breakers.append("i.PYRESOLVEDTIMESTAMP DESC")
    if normalized_sort_by != "pyid":
        tie_breakers.append("a.audit_id ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_audit_score_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_AUDIT_SCORE_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )

AUDIT_SCORE_COUNT_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYSTATUSWORK,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      {{lob_filter}}
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
),
audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        ROW_NUMBER() OVER (
            PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID
            ORDER BY a.PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = '{{user_id}}'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      {{lob_filter}}
)
SELECT
    COUNT(DISTINCT a.audit_id) AS TOTAL_COUNT,
    COUNT(DISTINCT CASE WHEN UPPER(TRIM(a.TARGET_AUDIT)) = 'YES' THEN a.audit_id END) AS TARGET_AUDIT_COUNT
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
"""

AUDIT_SCORE_COUNT_AUDIT_PERIOD_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.LOB,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('{{user_id}}')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      {{lob_filter}}
)
SELECT
    COUNT(DISTINCT a.audit_id) AS TOTAL_COUNT,
    COUNT(DISTINCT CASE WHEN UPPER(TRIM(a.TARGET_AUDIT)) = 'YES' THEN a.audit_id END) AS TARGET_AUDIT_COUNT
FROM audit_deduped a
WHERE a.rn = 1
  {{audit_period_filter}}
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def format_cycle_time(cycle_time) -> str:
    if not cycle_time:
        return "N/A"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "N/A"

def build_audit_month_year_filter(
    audit_periods: Optional[List[AuditPeriod]] = None,
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append((month_value, year_value))

    if not valid_periods:
        return ""

    conditions = [
        f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
        for month, year in valid_periods
    ]

    return "AND (" + " OR ".join(conditions) + ")"

def excel_cell_value(value):
    if value is None:
        return ""
    if isinstance(value, (int, float)):
        return value
    return value


@router.post(
    "/auditscore-drilldown",
    response_model=AuditScoreDrilldownPaginatedResponse,
    summary="Get Audit Score Drilldown",
    description="""
Retrieve paginated list of audit scores for detailed table display.

**Input Parameters:**
- **screen_id** (optional): Screen identifier, defaults to 'audit_score'
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user (e.g., 'AA99826')
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
  - **lob** (optional): List of Line of Business values (e.g., ['Commercial'])
- **page** (optional): Pagination parameters:
  - **page_limit**: Records per page (default: 50, max: 500)
  - **page**: Page number (1-indexed, default: 1)

**Response Fields (per record):**
- **pyid**: Unique audited case identifier
- **work_type**: Source system type
- **audit_cycle_time**: Days from creation to audit
- **resolved_status**: Case status
- **lob**: Line of Business
- **audit_resolved**: Audit completion date (MM/DD/YYYY format)
- **platform**: Processing platform
- **audit_score**: Quality score as percentage (e.g., '95%')
- **targeted_audit_type**: Type of audit (targeted vs random)
- **inventory_type**: "Type of inventory associated with the audited case",
- **rebuttal_status**: Status of rebuttal (hardcoded as 'N/A' for now)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (audit data)
- COB_AI_INVNTRY_PROFILE (cycle time)
""",
)
async def get_auditscore_drilldown(
    request: AuditScoreDrilldownPaginatedRequest
) -> AuditScoreDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        lob = request.query.lob
        
        page_limit = request.page.page_limit
        page = request.page.page or 1
        offset = (page - 1) * page_limit
        
        lob_filter = build_lob_filter(lob)
        engine = connection_manager.get_engine()

        valid_audit_periods = [
            period
            for period in (request.query.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)

        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="a.AUDIT_MONTH",
                audit_year_column="a.AUDIT_YEAR",
            )

            count_query = AUDIT_SCORE_COUNT_AUDIT_PERIOD_QUERY.format(
                user_id=user_id,
                lob_filter=lob_filter,
                audit_period_filter=audit_period_filter,
            )

            data_query = AUDIT_SCORE_PAGINATED_AUDIT_PERIOD_QUERY.format(
                user_id=user_id,
                lob_filter=lob_filter,
                audit_period_filter=audit_period_filter,
                limit=page_limit,
                offset=offset,
            )
        else:
            count_query = AUDIT_SCORE_COUNT_QUERY.format(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob_filter=lob_filter
            )

            data_query = AUDIT_SCORE_PAGINATED_QUERY.format(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob_filter=lob_filter,
                limit=page_limit,
                offset=offset
            )

        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        target_audit_count = count_result[0].get("TARGET_AUDIT_COUNT", 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0

        data_query = apply_custom_sort_to_audit_score_query(
            data_query,
            request.query.sort_by,
            request.query.sort_direction,
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        audit_scores = [
            AuditScoreRecord(
                pyid=record.get("AUDIT_WORK_ITEM") or "N/A",
                work_type=record.get("INTAKESOURCESYSTEM") or "N/A",
                audit_cycle_time=format_cycle_time(record.get("CYCLE_TIME")),
                resolved_status=clean_resolved_status(record.get("AUDIT_STATUS")),
                lob=record.get("LOB") or "N/A",
                audit_resolved=format_date_mmddyyyy(record.get("CASE_COMPLETION_DATE")),
                platform=record.get("PLATFORM") or "N/A",
                audit_score=f"{int(record.get('AUDIT_SCORE'))}%" if record.get("AUDIT_SCORE") else "N/A",
                targeted_audit_type=record.get("TARGET_AUDIT") or "N/A",
                inventory_type=record.get("INVNTRY_TYPE") or "N/A",
                rebuttal_status="N/A",
                audit_month=str(record.get("AUDIT_MONTH") or "N/A"),
                audit_year=str(record.get("AUDIT_YEAR") or "N/A")
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "pyid": "Unique identifier for the audited case",
            "work_type": "Source system or type of work item that was audited",
            "audit_cycle_time": "Number of days from case creation to audit completion",
            "resolved_status": "Current status of the audited work item",
            "lob": "Line of Business associated with the audited case",
            "audit_resolved": "Date when the audit was completed",
            "platform": "Platform where the case was processed",
            "audit_score": "Quality score achieved for this audit as a percentage",
            "targeted_audit_type": "Type of audit performed (targeted vs random)",
            "rebuttal_status": "Status of any rebuttal submitted for this audit",
            "inventory_type": "Type of inventory associated with the audited case",
            "audit_month": "Audit month associated with the audited case",
            "audit_year": "Audit year associated with the audited case",
            "target_audit_count": "Number of audits flagged as targeted for this user in the selected date range"
        }

        return AuditScoreDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            user_id=user_id,
            page=page_response,
            records=audit_scores,
            target_audit_count=target_audit_count,
            message="Audit scores retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated audit score drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page.page_limit,
            page=request.page.page or 1,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return AuditScoreDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            user_id=request.query.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve audit scores: {str(e)}"
        )

@router.post(
    "/auditscore-drilldown/download-excel",
    summary="Download Audit Score Drilldown as Excel",
    description="""
Download complete audit score drilldown data as an Excel file.

**Input Parameters:**
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
  - **lob** (optional): List of Line of Business values

**Returns:** Excel file (.xlsx) with all audit score records
""",
)
async def download_auditscore_drilldown_excel(
    request: AuditScoreDrilldownDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        lob = request.query.lob
        
        lob_filter = build_lob_filter(lob)
        engine = connection_manager.get_engine()

        valid_audit_periods = [
            period
            for period in (request.query.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)

        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="a.AUDIT_MONTH",
                audit_year_column="a.AUDIT_YEAR",
            )

            data_query = AUDIT_SCORE_PAGINATED_AUDIT_PERIOD_QUERY.replace(
                "LIMIT {{limit}} OFFSET {{offset}}", ""
            ).format(
                user_id=user_id,
                lob_filter=lob_filter,
                audit_period_filter=audit_period_filter,
                limit=config.CACHE_FULL_DATASET_LIMIT,
                offset=0
            )
        else:
            data_query = AUDIT_SCORE_PAGINATED_QUERY.replace(
                "LIMIT {{limit}} OFFSET {{offset}}", ""
            ).format(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob_filter=lob_filter,
                limit=config.CACHE_FULL_DATASET_LIMIT,
                offset=0
            )

        records = await engine.execute_query_async(data_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Audit Score Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Audit Cycle Time",
            "Audit Status",
            "Inventory Type",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Platform",
            "Audit Score",
            "Targeted Audit Type",
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        for row_num, record in enumerate(records, 2):
            ws.cell(row=row_num, column=1, value=record.get("AUDIT_WORK_ITEM") or "N/A")
            ws.cell(row=row_num, column=2, value=record.get("INTAKESOURCESYSTEM") or "N/A")
            ws.cell(row=row_num, column=3, value=format_cycle_time(record.get("CYCLE_TIME")))
            ws.cell(row=row_num, column=4, value=clean_resolved_status(record.get("AUDIT_STATUS")))
            ws.cell(row=row_num, column=5, value=record.get("INVNTRY_TYPE") or "N/A")
            ws.cell(row=row_num, column=6, value=record.get("LOB") or "N/A")
            ws.cell(row=row_num, column=7, value=format_date_mmddyyyy(record.get("CASE_COMPLETION_DATE")))
            ws.cell(row=row_num, column=8, value=record.get("AUDIT_MONTH") or "N/A")
            ws.cell(row=row_num, column=9, value=excel_cell_value(
                int(record["AUDIT_YEAR"]) if record.get("AUDIT_YEAR") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=10, value=record.get("PLATFORM") or "N/A")
            ws.cell(row=row_num, column=11, value=excel_cell_value(
                float(record["AUDIT_SCORE"]) if record.get("AUDIT_SCORE") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=12, value=record.get("TARGET_AUDIT") or "N/A")
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"audit_score_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for audit score drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
