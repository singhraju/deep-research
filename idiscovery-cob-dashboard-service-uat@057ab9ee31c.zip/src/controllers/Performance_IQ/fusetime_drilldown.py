import logging
import asyncio
from typing import Optional, List
from datetime import datetime
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from io import BytesIO
from openpyxl import Workbook
import config
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import (
    FuseTimeDrilldownPaginatedRequest,
    FuseTimeDrilldownPaginatedResponse,
    FuseTimeDrilldownDownloadRequest,
    FuseTimeRecord,
    PageResponse,
)
import math
import config

logger = logging.getLogger(__name__)

router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

FUSE_TIME_PAGINATED_QUERY = f"""
SELECT 
    USERNAME,
    USERID,
    LOGINDATE,
    FIRSTLOGINTIME,
    LASTLOGOUTTIME,
    TOTALSYSTEMTIME,
    FUSE_NON_PRODUCTIVE_TIME,
    PRODUCTIVETIME,
    COALESCE(TOTALSYSTEMTIME, 0) - 
    (COALESCE(
        CASE 
            WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END, 0
    ) + 
    COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) AS OTHER_TIME
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{user_id}}'
AND LOGINDATE BETWEEN '{{start_date}}' AND '{{end_date}}'
ORDER BY LOGINDATE DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_FUSE_TIME_ORDER_BY = "LOGINDATE DESC"

PRODUCTIVE_TIME_SECONDS_SQL = "CASE WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER) ELSE 0 END"

OTHER_TIME_SQL = f"COALESCE(TOTALSYSTEMTIME, 0) - (COALESCE({PRODUCTIVE_TIME_SECONDS_SQL}, 0) + COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0))"

SORTABLE_FUSE_TIME_COLUMNS = {
    "user_id": "COALESCE(USERNAME, 'N/A')",
    "date": "LOGINDATE",
    "log_in": "FIRSTLOGINTIME",
    "log_out": "LASTLOGOUTTIME",
    "total_fuse_time": "COALESCE(TOTALSYSTEMTIME, 0)",
    "productive_time": PRODUCTIVE_TIME_SECONDS_SQL,
    "non_productive_time": "COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)",
    "other_time": OTHER_TIME_SQL,
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_FUSE_TIME_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_FUSE_TIME_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid fuse time sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_FUSE_TIME_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid fuse time sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_FUSE_TIME_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "date":
        tie_breakers.append("LOGINDATE DESC")
    if normalized_sort_by != "user_id":
        tie_breakers.append("USERNAME ASC")
    tie_breakers.append("USERID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_fuse_time_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_FUSE_TIME_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )

FUSE_TIME_COUNT_QUERY = f"""
SELECT COUNT(*) as TOTAL_COUNT
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{user_id}}'
AND LOGINDATE BETWEEN '{{start_date}}' AND '{{end_date}}'
"""

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return "N/A"
    try:
        date_obj = datetime.strptime(str(date_str)[:10], "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return "N/A"

def format_time_hhmm(time_str: str) -> str:
    """Format timestamp to HH:MM AM/PM ET format"""
    if not time_str:
        return "N/A"
    try:
        # Parse the full timestamp
        time_obj = datetime.strptime(str(time_str)[:19], "%Y-%m-%d %H:%M:%S")
        # Format to 12-hour time with AM/PM and add ET
        return time_obj.strftime("%I:%M %p ET")
    except:
        return "N/A"


def format_duration(duration_str: str) -> str:
    """Format duration to HH:MM:SS format"""
    if not duration_str:
        return "00:00:00"
    try:
        if ':' in str(duration_str):
            parts = str(duration_str).split(':')
            hours = int(parts[0])
            minutes = int(parts[1])
            seconds = int(float(parts[2])) if len(parts) > 2 else 0
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        total_seconds = int(float(duration_str))
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    except:
        return "N/A"

@router.post(
    "/fusetime-drilldown",
    response_model=FuseTimeDrilldownPaginatedResponse,
    summary="Get Fuse Time Drilldown",
    description="""
Retrieve paginated list of fuse time records for detailed table display.

**Input Parameters:**
- **screen_id** (optional): Screen identifier, defaults to 'fuse_time'
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user (e.g., '1694MU')
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
- **page** (optional): Pagination parameters:
  - **page_limit**: Records per page (default: 50, max: 500)
  - **page**: Page number (1-indexed, default: 1)

**Response Fields (per record):**
- **user_id**: User ID
- **date**: Login date (MM/DD/YYYY format)
- **log_in**: First login time
- **log_out**: Last logout time
- **total_fuse_time**: Total system time formatted as 'X hrs Y mins'
- **non_productive_time**: Fuse non-productive time formatted as 'X hrs Y mins'

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Source:** COB_AI_USER_PROFILE table
""",
)
async def get_fusetime_drilldown(
    request: FuseTimeDrilldownPaginatedRequest
) -> FuseTimeDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date

        page_limit = request.page.page_limit
        page = request.page.page or 1
        offset = (page - 1) * page_limit
        
        engine = connection_manager.get_engine()
        
        count_query = FUSE_TIME_COUNT_QUERY.format(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date
        )
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = FUSE_TIME_PAGINATED_QUERY.format(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            limit=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_fuse_time_query(
            data_query,
            request.query.sort_by,
            request.query.sort_direction,
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        fuse_time_records = [
            FuseTimeRecord(
                user_id=record.get("USERNAME") or "N/A",
                date=format_date_mmddyyyy(record.get("LOGINDATE")),
                log_in=format_time_hhmm(record.get("FIRSTLOGINTIME")),
                log_out=format_time_hhmm(record.get("LASTLOGOUTTIME")),
                total_fuse_time=format_duration(record.get("TOTALSYSTEMTIME")),
                productive_time=format_duration(record.get("PRODUCTIVETIME")),
                non_productive_time=format_duration(record.get("FUSE_NON_PRODUCTIVE_TIME")),
                other_time=format_duration(record.get("OTHER_TIME"))
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "user_id": "Unique identifier for the user",
            "date": "Date when the user logged in",
            "log_in": "Time of first login for the day",
            "log_out": "Time of last logout for the day",
            "total_fuse_time": "Total time spent in the Fuse system",
            "productive_time": "Time spent on productive activities",
            "non_productive_time": "Time spent on non-productive activities in Fuse",
            "other_time": "Other time calculated as Total Fuse Time - (OHI Productive Time + Non-Productive Time)"
        }

        return FuseTimeDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            user_id=user_id,
            page=page_response,
            records=fuse_time_records,
            message="Fuse time records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated fuse time drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page.page_limit,
            page=request.page.page or 1,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return FuseTimeDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            user_id=request.query.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve fuse time records: {str(e)}"
        )

@router.post(
    "/fusetime-drilldown/download-excel",
    summary="Download Fuse Time Drilldown as Excel",
    description="""
Download complete fuse time drilldown data as an Excel file.

**Input Parameters:**
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format

**Returns:** Excel file (.xlsx) with all fuse time records
""",
)
async def download_fusetime_drilldown_excel(
    request: FuseTimeDrilldownDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        
        engine = connection_manager.get_engine()
        
        data_query = FUSE_TIME_PAGINATED_QUERY.replace(
            "LIMIT {{limit}} OFFSET {{offset}}", ""
        ).format(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        records = await engine.execute_query_async(data_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Fuse Time Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Associate Name",
            "Date",
            "Log In",
            "Log Out",
            "Total Fuse Time",
            "Productive Time",
            "Non-Productive Time",
            "Unclassified"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        for row_num, record in enumerate(records, 2):
            ws.cell(row=row_num, column=1, value=record.get("USERNAME") or "N/A")
            ws.cell(row=row_num, column=2, value=format_date_mmddyyyy(record.get("LOGINDATE")))
            ws.cell(row=row_num, column=3, value=format_time_hhmm(record.get("FIRSTLOGINTIME")))
            ws.cell(row=row_num, column=4, value=format_time_hhmm(record.get("LASTLOGOUTTIME")))
            ws.cell(row=row_num, column=5, value=format_duration(record.get("TOTALSYSTEMTIME")))
            ws.cell(row=row_num, column=6, value=format_duration(record.get("PRODUCTIVETIME")))
            ws.cell(row=row_num, column=7, value=format_duration(record.get("FUSE_NON_PRODUCTIVE_TIME")))
            ws.cell(row=row_num, column=8, value=format_duration(record.get("OTHER_TIME")))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"fusetime_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for fuse time drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
