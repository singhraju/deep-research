import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import ( 
    FrontlineProductionPctDrilldownRequest,
    ProductionPctDrilldownDownloadRequest,
    ProductionPctAchievedDrilldownPaginatedResponse,
    ProductionPctAchievedRecord,
    PageResponse,
)
import math
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id
from utils.cache_key_builder import build_filters_hash
import config
from .user_metrics import WORK_ITEMS_QUERY

def format_retime(retime) -> str:
    if not retime:
        return "N/A"
    try:
        total_seconds = int(float(retime) * 60)
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02}:{m:02}:{s:02}"
    except:
        return "N/A"

def format_cycle_time(cycle_time) -> str:
    if not cycle_time:
        return "N/A"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02}:{m:02}:{s:02}"
    except:
        return "N/A"

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

PRODUCTION_PCT_ACHIEVED_PAGINATED_QUERY = f"""
WITH 
-- =====================================================
-- STEP 1: Deduplicate Inventory Records (Get Latest State)
-- =====================================================
inventory_deduped AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.RETIME,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PXUPDATEDATETIME,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.INVNTRY_TYPE,
        i.LOB,
        i.MARKET,
        i.PLATFORM,
        i.ACTIVITYCODE,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXCOMMITDATETIME DESC, i.INSRT_DT_TIME DESC, i.RETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
),

-- =====================================================
-- STEP 2: Apply Business Filters and Calculate Metrics
-- =====================================================
case_level AS (
    SELECT
        i.PYRESOLVEDUSERID AS user_id,
        i.INTAKESOURCESYSTEM AS work_type,
        i.PYID AS case_id,
        i.CYCLE_TIME / 60.0 AS cycle_time_min,
        i.RETIME AS retime_min,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PYRESOLVEDTIMESTAMP,
        DATE(i.PYRESOLVEDTIMESTAMP) AS resolved_date,
        i.PYSTATUSWORK,
        i.INVNTRY_TYPE,
        i.LOB,
        i.MARKET,
        i.PLATFORM,
        i.ACTIVITYCODE,
        i.PXUPDATEDATETIME,
        CASE
            WHEN i.CYCLE_TIME > 0 THEN (i.RETIME / (i.CYCLE_TIME / 60.0)) * 100
            ELSE 0
        END AS efficiency_pct,
        CASE
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 75 THEN 75
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 75
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 90 THEN 90
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 90
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 98 THEN 97
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 98
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 100 THEN 100
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 100
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 150 THEN 115
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS mapped_efficiency
    FROM inventory_deduped i
    WHERE i.rn = 1
      AND i.PYSTATUSWORK = 'Resolved-Completed'
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND i.PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND i.PYRESOLVEDUSERID = '{{user_id}}'
      {{lob_filter}}
      AND i.CYCLE_TIME IS NOT NULL
      AND i.CYCLE_TIME > 0
      AND i.RETIME IS NOT NULL
      AND i.RETIME > 0
),

-- =====================================================
-- STEP 3: Work Type Level Aggregation
-- =====================================================
work_type_level AS (
    SELECT
        user_id,
        work_type,
        COUNT(DISTINCT case_id) AS items_completed,
        SUM(cycle_time_min) AS total_cycle_time_min,
        SUM(retime_min) AS total_retime_min,
        CASE
            WHEN SUM(cycle_time_min) > 0
            THEN (SUM(retime_min) / SUM(cycle_time_min)) * 100
            ELSE 0
        END AS work_type_efficiency_pct,
        CASE
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 75 THEN 75
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 75
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 90 THEN 90
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 90
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 98 THEN 97
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 98
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 100 THEN 100
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 100
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 150 THEN 115
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS avg_mapped_efficiency
    FROM case_level
    GROUP BY user_id, work_type
),

-- =====================================================
-- STEP 4: User Daily Time Tracking (Available Time)
-- =====================================================
user_daily AS (
    SELECT
        USERID AS user_id,
        USERNAME,
        LOGINDATE,
        TOTALSYSTEMTIME,
        FUSE_NON_PRODUCTIVE_TIME AS non_productive_sec,
        TOTALSYSTEMTIME - COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0) AS available_time_sec,
        ROW_NUMBER() OVER (
            PARTITION BY USERID, LOGINDATE
            ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID = '{{user_id}}'
      AND LOGINDATE >= '{{start_date}}'
      AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND TOTALSYSTEMTIME IS NOT NULL
),
user_available_time AS (
    SELECT
        user_id,
        SUM(available_time_sec) / 60.0 AS total_available_time_min
    FROM user_daily
    WHERE rn = 1
      AND available_time_sec > 0
    GROUP BY user_id
),
user_aggregate AS (
    SELECT
        w.user_id,
        SUM(w.items_completed) AS total_items_completed,
        SUM(w.total_cycle_time_min) AS total_cycle_time_min,
        SUM(w.total_retime_min) AS total_retime_min,
        CASE
            WHEN SUM(w.total_cycle_time_min) > 0
            THEN (SUM(w.total_retime_min) / SUM(w.total_cycle_time_min)) * 100
            ELSE 0
        END AS overall_efficiency_pct,
        CASE
            WHEN SUM(w.items_completed) > 0
            THEN SUM(w.items_completed * w.avg_mapped_efficiency) / SUM(w.items_completed)
            ELSE 0
        END AS weighted_mapped_efficiency,
        MAX(a.total_available_time_min) AS total_available_time_min
    FROM work_type_level w
    LEFT JOIN user_available_time a
        ON w.user_id = a.user_id
    GROUP BY w.user_id
),
final_calculation AS (
    SELECT
        user_id,
        total_items_completed,
        total_cycle_time_min,
        total_retime_min,
        total_available_time_min,
        overall_efficiency_pct,
        weighted_mapped_efficiency,
        CASE
            WHEN total_available_time_min > 0
            THEN (total_cycle_time_min / total_available_time_min) * 100
            ELSE 0
        END AS utilization_pct,
        CASE
            WHEN total_available_time_min > 0
            THEN (weighted_mapped_efficiency * 0.5) +
                 ((total_cycle_time_min / total_available_time_min) * 100 * 0.5)
            ELSE 0
        END AS final_production_pct
    FROM user_aggregate
),

-- =====================================================
-- STEP 8: Get User Name
-- =====================================================
user_profile_deduped AS (
    SELECT
        USERID,
        USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)

-- =====================================================
-- FINAL SELECT: Drilldown Output Format
-- =====================================================
SELECT
    c.user_id AS associate,
    COALESCE(u.USERNAME, p.USERNAME) AS associate_name,
    c.case_id AS work_item_id,
    c.work_type AS worktype,
    c.retime_min AS standard_time,
    c.cycle_time_min * 60 AS case_cycle_time,
    c.PYSTATUSWORK AS resolved_status,
    c.INVNTRY_TYPE AS inventory_type,
    c.LOB,
    c.MARKET,
    c.PLATFORM,
    TO_CHAR(c.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY') AS resolved_date,
    c.ACTIVITYCODE AS activity_code,
    'View Details' AS action,
    f.total_items_completed AS total_work_items,
    f.total_retime_min AS total_expected_min,
    ROUND(f.total_cycle_time_min, 0) AS total_actual_production_min,
    ROUND(
        f.total_available_time_min / NULLIF(f.total_retime_min / NULLIF(f.total_items_completed, 0), 0),
        0
    ) AS total_expected_tasks,
    ROUND(f.final_production_pct, 2) AS production_pct_achieved
FROM case_level c
INNER JOIN final_calculation f
    ON c.user_id = f.user_id
LEFT JOIN user_daily u
    ON c.user_id = u.user_id
   AND c.resolved_date = u.LOGINDATE
   AND u.rn = 1
LEFT JOIN user_profile_deduped p
    ON c.user_id = p.USERID
   AND p.rn = 1
ORDER BY c.PYRESOLVEDTIMESTAMP DESC, c.case_id
LIMIT {{limit}} OFFSET {{offset}}
"""

PRODUCTION_PCT_FRONTLINE_DEFAULT_ORDER_BY = "ORDER BY c.PYRESOLVEDTIMESTAMP DESC, c.case_id"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item_id": "c.case_id",
        "worktype": "c.work_type",
        "standard_time": "c.retime_min",
        "case_cycle_time": "(c.cycle_time_min * 60)",
        "resolved_status": "c.PYSTATUSWORK",
        "inventory_type": "c.INVNTRY_TYPE",
        "lob": "c.LOB",
        "resolved_date": "c.PYRESOLVEDTIMESTAMP",
        "associate": "COALESCE(u.USERNAME, p.USERNAME)",
        "associate_name": "COALESCE(u.USERNAME, p.USERNAME)",
        "activity_code": "c.ACTIVITYCODE",
        "platform": "c.PLATFORM",
        "action": "'View Details'",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return PRODUCTION_PCT_FRONTLINE_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, c.PYRESOLVEDTIMESTAMP DESC, c.case_id"

USER_NAME_QUERY = f"""
SELECT TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) as full_name
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{user_id}}'
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

@router.post(
    "/production-pct-achieved-drilldown",
    response_model=ProductionPctAchievedDrilldownPaginatedResponse,
    summary="Get Production Percentage Achieved Drilldown (Frontline User)",
    description="""
Retrieve paginated list of production percentage achieved work items for the logged-in frontline user.

**Input Parameters:**
- **screen_id** (optional): Screen identifier, defaults to 'production_pct_achieved'
- **query** (required): Query parameters object containing:
  - **user_id** (required): ...
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
  - **lob** (optional): ...
- **page** (optional): Pagination parameters:
  - **page_limit**: Records per page (default: 50, max: 500)
  - **page**: Page number (1-indexed, default: 1)

**Response Fields (per record):**
- **work_item_id**: Unique work item identifier (PYID)
- **worktype**: Work type (INTAKESOURCESYSTEM)
- **standard_time**: Standard time in minutes (RETIME)
- **case_cycle_time**: Case cycle time in days (CYCLE_TIME)
- **resolved_status**: Resolved status (PYSTATUSWORK)
- **inventory_type**: Inventory type (INVNTRY_TYPE)
- **lob**: Line of Business
- **resolved_date**: Resolved date (MM/DD/YYYY format)
- **associate_name**: associate name
- **activity_code**: "Activity code associated with the work item"

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (production data filtered by user_id)
""",
)
async def get_production_pct_achieved_drilldown(
    request: FrontlineProductionPctDrilldownRequest
) -> ProductionPctAchievedDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        lob = request.query.lob

        page_limit = request.page.page_limit
        page = request.page.page or 1
        offset = (page - 1) * page_limit
        
        # Auto-generate session_id if missing and caching enabled
        session_id = request.session_id
        if config.REDIS_ENABLED and not session_id:
            session_id = generate_session_id()
            request.session_id = session_id
            logger.info(f"Auto-generated session_id: {session_id}")
        
        lob_filter = build_lob_filter(lob)
        date_filter = build_date_filter(start_date, end_date)
        engine = connection_manager.get_engine()
        
        # Try to reuse cached work_items_completed count from user_metrics API
        total_records = 0
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict and hash for cache key
                filters = {
                    'user_id': user_id,
                    'start_date': start_date,
                    'end_date': end_date,
                    'lob': lob,
                }
                filters_hash = build_filters_hash(**filters)
                
                # Get cached work items count from user_metrics API
                cache_key = f"session:{session_id}:{filters_hash}:work_items_completed"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract COMPLETED_TASKS from cached query result
                    total_records = int(cached_metric[0].get("COMPLETED_TASKS", 0))
                    logger.info(f"✅ Reused cached work items count: {total_records} (from user_metrics)")
                else:
                    logger.info(f"Cache miss for work_items_completed, running COUNT query")
                    # Fall back to COUNT query
                    count_query = WORK_ITEMS_QUERY.format(
                        user_id=user_id,
                        start_date=start_date,
                        end_date=end_date,
                        lob_filter=lob_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("COMPLETED_TASKS", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached work items count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = WORK_ITEMS_QUERY.format(
                    user_id=user_id,
                    start_date=start_date,
                    end_date=end_date,
                    lob_filter=lob_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("COMPLETED_TASKS", 0) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = WORK_ITEMS_QUERY.format(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob_filter=lob_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("COMPLETED_TASKS", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = PRODUCTION_PCT_ACHIEVED_PAGINATED_QUERY.format(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            lob_filter=lob_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            PRODUCTION_PCT_FRONTLINE_DEFAULT_ORDER_BY,
            build_sort_clause(request.query.sort_by, request.query.sort_direction),
            1
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)

        name_result = await engine.execute_query_async(USER_NAME_QUERY.format(user_id=user_id), limit=1)
        associate_name = (name_result[0].get("FULL_NAME") or "N/A") if name_result else "N/A"

        production_records = [
            ProductionPctAchievedRecord(
                work_item_id=record.get("WORK_ITEM_ID") or "N/A",
                worktype=record.get("WORKTYPE") or "N/A",
                standard_time=format_retime(record.get("STANDARD_TIME")),
                case_cycle_time=format_cycle_time(record.get("CASE_CYCLE_TIME")),
                resolved_status=record.get("RESOLVED_STATUS") or "N/A",
                inventory_type=record.get("INVENTORY_TYPE") or "N/A",
                lob=record.get("LOB") or "N/A",
                resolved_date=record.get("RESOLVED_DATE") or "N/A",
                associate=associate_name or "N/A",
                activity_code=record.get("ACTIVITY_CODE") or "N/A",
                platform=record.get("PLATFORM") or "N/A",
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item_id": "Unique identifier for the work item (PYID)",
            "worktype": "Type of work item or source system",
            "standard_time": "Standard time allocated for this work type (hh:mm:ss)",
            "case_cycle_time": "Actual time taken to complete the work item (hh:mm:ss)",
            "resolved_status": "Status when the work item was resolved",
            "inventory_type": "Type of inventory or work category",
            "lob": "Line of Business associated with the work item",
            "resolved_date": "Date when the work item was resolved",
            "associate_name": "Associate who resolved the work item",
            "action": "Available actions for this work item",
            "platform": "Platform where the case was processed",
        }

        return ProductionPctAchievedDrilldownPaginatedResponse(
            status="success",
            screen_id="production_pct_achieved",
            page=page_response,
            records=production_records,
            message="Production percentage achieved records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Frontline production pct achieved drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page.page_limit,
            page=request.page.page or 1,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return ProductionPctAchievedDrilldownPaginatedResponse(
            status="error",
            screen_id="production_pct_achieved",
            page=page_response,
            records=[],
            message=f"Failed to retrieve production percentage achieved records: {str(e)}"
        )

@router.post(
    "/production-pct-achieved-drilldown/download-excel",
    summary="Download Production Percentage Achieved Drilldown as Excel",
    description="""
Download complete production percentage achieved drilldown data as an Excel file.

**Input Parameters:**
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
  - **lob** (optional): List of Line of Business values

**Returns:** Excel file (.xlsx) with all production percentage records
""",
)
async def download_production_pct_achieved_drilldown_excel(
    request: ProductionPctDrilldownDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        lob = request.query.lob

        lob_filter = build_lob_filter(lob)
        engine = connection_manager.get_engine()
        
        data_query = PRODUCTION_PCT_ACHIEVED_PAGINATED_QUERY.replace(
            "LIMIT {{limit}} OFFSET {{offset}}", ""
        ).format(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            lob_filter=lob_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        records = await engine.execute_query_async(data_query, limit=config.CACHE_FULL_DATASET_LIMIT)

        name_result = await engine.execute_query_async(USER_NAME_QUERY.format(user_id=user_id), limit=1)
        associate_name = (name_result[0].get("FULL_NAME") or "N/A") if name_result else "N/A"

        wb = Workbook()
        ws = wb.active
        ws.title = "Production Pct Achieved"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Standard Time",
            "Case Cycle Time",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Resolved Date",
            "Associate Name",
            "Activity Code",
            "Platform"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        for row_num, record in enumerate(records, 2):
            ws.cell(row=row_num, column=1, value=record.get("WORK_ITEM_ID") or "N/A")
            ws.cell(row=row_num, column=2, value=record.get("WORKTYPE") or "N/A")
            ws.cell(row=row_num, column=3, value=format_retime(record.get("STANDARD_TIME")))
            ws.cell(row=row_num, column=4, value=format_cycle_time(record.get("CASE_CYCLE_TIME")))
            ws.cell(row=row_num, column=5, value=record.get("RESOLVED_STATUS") or "N/A")
            ws.cell(row=row_num, column=6, value=record.get("INVENTORY_TYPE") or "N/A")
            ws.cell(row=row_num, column=7, value=record.get("LOB") or "N/A")
            ws.cell(row=row_num, column=8, value=record.get("RESOLVED_DATE") or "N/A")
            ws.cell(row=row_num, column=9, value=associate_name or "N/A")
            ws.cell(row=row_num, column=10, value=record.get("ACTIVITY_CODE") or "N/A")
            ws.cell(row=row_num, column=11, value=record.get("PLATFORM") or "N/A")        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"production_pct_achieved_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for production pct achieved: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
