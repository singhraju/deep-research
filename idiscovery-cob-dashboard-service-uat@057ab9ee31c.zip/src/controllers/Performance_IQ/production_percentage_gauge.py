import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from concurrent.futures import ThreadPoolExecutor

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import ProductionPercentageGaugeRequest, ProductionPercentageGaugeResponse, ProductionPercentageTrend
from services.frontline_ai_coach_cache_service import frontline_ai_coach_cache_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

PRODUCTION_QUERY = f"""
WITH 
-- =====================================================
-- STEP 1: Deduplicate Inventory Records (Get Latest State)
-- =====================================================
inventory_deduped AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.RETIME,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PXUPDATEDATETIME,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.LOB,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXCOMMITDATETIME DESC, i.INSRT_DT_TIME DESC, i.RETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
),

-- =====================================================
-- STEP 2: Apply Business Filters and Calculate Metrics
-- =====================================================
case_level AS (
    SELECT
        i.PYRESOLVEDUSERID AS user_id,
        i.INTAKESOURCESYSTEM AS work_type,
        i.PYID AS case_id,
        i.CYCLE_TIME / 60.0 AS cycle_time_min,
        i.RETIME AS retime_min,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PXUPDATEDATETIME,
        CASE
            WHEN i.CYCLE_TIME > 0 THEN (i.RETIME / (i.CYCLE_TIME / 60.0)) * 100
            ELSE 0
        END AS efficiency_pct,
        CASE
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 75 THEN 75
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 75
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 90 THEN 90
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 90
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 98 THEN 97
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 98
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 100 THEN 100
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 100
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 150 THEN 115
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS mapped_efficiency
    FROM inventory_deduped i
    WHERE i.rn = 1
      AND i.PYSTATUSWORK = 'Resolved-Completed'
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND i.PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND i.PYRESOLVEDUSERID = '{{user_id}}'
      {{lob_filter}}
      AND i.CYCLE_TIME IS NOT NULL
      AND i.CYCLE_TIME > 0
      AND i.RETIME IS NOT NULL
      AND i.RETIME > 0
),

-- =====================================================
-- STEP 3: Work Type Level Aggregation
-- =====================================================
work_type_level AS (
    SELECT
        user_id,
        work_type,
        COUNT(DISTINCT case_id) AS items_completed,
        SUM(cycle_time_min) AS total_cycle_time_min,
        SUM(retime_min) AS total_retime_min,
        CASE
            WHEN SUM(cycle_time_min) > 0
            THEN (SUM(retime_min) / SUM(cycle_time_min)) * 100
            ELSE 0
        END AS work_type_efficiency_pct,
        CASE
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 75 THEN 75
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 75
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 90 THEN 90
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 90
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 98 THEN 97
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 98
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 100 THEN 100
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 100
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 150 THEN 115
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS avg_mapped_efficiency
    FROM case_level
    GROUP BY user_id, work_type
),
user_daily AS (
    SELECT
        USERID AS user_id,
        LOGINDATE,
        TOTALSYSTEMTIME,
        FUSE_NON_PRODUCTIVE_TIME AS non_productive_sec,
        TOTALSYSTEMTIME - COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0) AS available_time_sec,
        ROW_NUMBER() OVER (
            PARTITION BY USERID, LOGINDATE
            ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID = '{{user_id}}'
      AND LOGINDATE >= '{{start_date}}'
      AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND TOTALSYSTEMTIME IS NOT NULL
),
user_available_time AS (
    SELECT
        user_id,
        SUM(available_time_sec) / 60.0 AS total_available_time_min
    FROM user_daily
    WHERE rn = 1
      AND available_time_sec > 0
    GROUP BY user_id
),
user_aggregate AS (
    SELECT
        w.user_id,
        SUM(w.items_completed) AS total_items_completed,
        SUM(w.total_cycle_time_min) AS total_cycle_time_min,
        SUM(w.total_retime_min) AS total_retime_min,
        CASE
            WHEN SUM(w.total_cycle_time_min) > 0
            THEN (SUM(w.total_retime_min) / SUM(w.total_cycle_time_min)) * 100
            ELSE 0
        END AS overall_efficiency_pct,
        CASE
            WHEN SUM(w.items_completed) > 0
            THEN SUM(w.items_completed * w.avg_mapped_efficiency) / SUM(w.items_completed)
            ELSE 0
        END AS weighted_mapped_efficiency,
        MAX(a.total_available_time_min) AS total_available_time_min
    FROM work_type_level w
    LEFT JOIN user_available_time a
        ON w.user_id = a.user_id
    GROUP BY w.user_id
),
final_calculation AS (
    SELECT
        user_id,
        total_items_completed,
        total_cycle_time_min,
        total_retime_min,
        total_available_time_min,
        overall_efficiency_pct,
        weighted_mapped_efficiency,
        CASE
            WHEN total_available_time_min > 0
            THEN (total_cycle_time_min / total_available_time_min) * 100
            ELSE 0
        END AS utilization_pct,
        CASE
            WHEN total_available_time_min > 0
            THEN (weighted_mapped_efficiency * 0.5) +
                 ((total_cycle_time_min / total_available_time_min) * 100 * 0.5)
            ELSE 0
        END AS final_production_pct
    FROM user_aggregate
)
SELECT
    user_id,
    total_items_completed,
    ROUND(total_cycle_time_min, 2) AS actual_cycle_time_min,
    ROUND(total_available_time_min, 2) AS available_time_min,
    ROUND(total_retime_min, 2) AS total_retime_min,
    ROUND(overall_efficiency_pct, 2) AS efficiency_pct,
    ROUND(weighted_mapped_efficiency, 2) AS mapped_efficiency_pct,
    ROUND(utilization_pct, 2) AS utilization_pct,
    ROUND(final_production_pct, 2) AS FINAL_PRODUCTION_PCT,
    CASE
        WHEN final_production_pct < 95 THEN 'Does Not Meet'
        WHEN final_production_pct >= 95 AND final_production_pct < 100 THEN 'Partial Meets'
        WHEN final_production_pct >= 100 AND final_production_pct < 115 THEN 'Meets'
        WHEN final_production_pct >= 115 AND final_production_pct < 120 THEN 'Exceeds'
        WHEN final_production_pct >= 120 THEN 'Significantly Exceeds'
        ELSE 'Does Not Meet'
    END AS OVERALL_DESCRIPTION
FROM final_calculation
"""

PRODUCTION_TREND_QUERY = f"""
WITH
-- =====================================================
-- Date Range and Grouping Logic
-- =====================================================
date_range AS (
    SELECT DATEDIFF(day, '{{start_date}}'::DATE, '{{end_date}}'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),

-- =====================================================
-- STEP 1: Deduplicate Inventory Records (Get Latest State)
-- =====================================================
inventory_deduped AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.RETIME,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PXUPDATEDATETIME,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.LOB,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXCOMMITDATETIME DESC, i.INSRT_DT_TIME DESC, i.RETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
),

-- =====================================================
-- STEP 2: Apply Business Filters and Calculate Metrics
-- =====================================================
case_level AS (
    SELECT
        i.PYRESOLVEDUSERID AS user_id,
        i.INTAKESOURCESYSTEM AS work_type,
        i.PYID AS case_id,
        i.CYCLE_TIME / 60.0 AS cycle_time_min,
        i.RETIME AS retime_min,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PYRESOLVEDTIMESTAMP,
        DATE(i.PYRESOLVEDTIMESTAMP) AS resolved_date,
        i.PXUPDATEDATETIME,
        CASE
            WHEN i.CYCLE_TIME > 0 THEN (i.RETIME / (i.CYCLE_TIME / 60.0)) * 100
            ELSE 0
        END AS efficiency_pct,
        CASE
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 75 THEN 75
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 75
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 90 THEN 90
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 90
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 98 THEN 97
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 98
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 100 THEN 100
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 100
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 150 THEN 115
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS mapped_efficiency
    FROM inventory_deduped i
    WHERE i.rn = 1
      AND i.PYSTATUSWORK = 'Resolved-Completed'
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND i.PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND i.PYRESOLVEDUSERID = '{{user_id}}'
      {{lob_filter}}
      AND i.CYCLE_TIME IS NOT NULL
      AND i.CYCLE_TIME > 0
      AND i.RETIME IS NOT NULL
      AND i.RETIME > 0
),

-- =====================================================
-- STEP 3: Work Type Level Aggregation by Date
-- =====================================================
work_type_daily AS (
    SELECT
        user_id,
        resolved_date,
        work_type,
        COUNT(DISTINCT case_id) AS items_completed,
        SUM(cycle_time_min) AS total_cycle_time_min,
        SUM(retime_min) AS total_retime_min,
        CASE
            WHEN SUM(cycle_time_min) > 0
            THEN (SUM(retime_min) / SUM(cycle_time_min)) * 100
            ELSE 0
        END AS work_type_efficiency_pct,
        CASE
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 75 THEN 75
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 75
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 90 THEN 90
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 90
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 98 THEN 97
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 98
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 100 THEN 100
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 100
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 150 THEN 115
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS avg_mapped_efficiency
    FROM case_level
    GROUP BY user_id, resolved_date, work_type
),
user_daily AS (
    SELECT
        USERID AS user_id,
        LOGINDATE,
        TOTALSYSTEMTIME,
        FUSE_NON_PRODUCTIVE_TIME AS non_productive_sec,
        TOTALSYSTEMTIME - COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0) AS available_time_sec,
        ROW_NUMBER() OVER (
            PARTITION BY USERID, LOGINDATE
            ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID = '{{user_id}}'
      AND LOGINDATE >= '{{start_date}}'
      AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND TOTALSYSTEMTIME IS NOT NULL
),
user_available_time_daily AS (
    SELECT
        user_id,
        LOGINDATE AS activity_date,
        SUM(available_time_sec) / 60.0 AS available_time_min
    FROM user_daily
    WHERE rn = 1
      AND available_time_sec > 0
    GROUP BY user_id, LOGINDATE
),
daily_aggregate AS (
    SELECT
        w.user_id,
        w.resolved_date AS activity_date,
        SUM(w.items_completed) AS total_items_completed,
        SUM(w.total_cycle_time_min) AS total_cycle_time_min,
        SUM(w.total_retime_min) AS total_retime_min,
        CASE
            WHEN SUM(w.total_cycle_time_min) > 0
            THEN (SUM(w.total_retime_min) / SUM(w.total_cycle_time_min)) * 100
            ELSE 0
        END AS overall_efficiency_pct,
        CASE
            WHEN SUM(w.items_completed) > 0
            THEN SUM(w.items_completed * w.avg_mapped_efficiency) / SUM(w.items_completed)
            ELSE 0
        END AS weighted_mapped_efficiency,
        MAX(a.available_time_min) AS available_time_min
    FROM work_type_daily w
    LEFT JOIN user_available_time_daily a
        ON w.user_id = a.user_id
       AND w.resolved_date = a.activity_date
    GROUP BY w.user_id, w.resolved_date
),
daily_production AS (
    SELECT
        user_id,
        activity_date,
        total_items_completed,
        total_cycle_time_min,
        total_retime_min,
        available_time_min,
        overall_efficiency_pct,
        weighted_mapped_efficiency,
        CASE
            WHEN available_time_min > 0
            THEN (total_cycle_time_min / available_time_min) * 100
            ELSE 0
        END AS utilization_pct,
        CASE
            WHEN available_time_min > 0
            THEN (weighted_mapped_efficiency * 0.5) +
                 ((total_cycle_time_min / available_time_min) * 100 * 0.5)
            ELSE 0
        END AS final_production_pct
    FROM daily_aggregate
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN d.activity_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', d.activity_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', d.activity_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', d.activity_date)
            ELSE DATE_TRUNC('year', d.activity_date)
        END AS group_key,
        d.activity_date,
        d.total_items_completed,
        d.total_cycle_time_min,
        d.total_retime_min,
        d.available_time_min,
        d.weighted_mapped_efficiency,
        d.utilization_pct,
        d.final_production_pct
    FROM daily_production d
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' || TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    ROUND(AVG(final_production_pct), 2) AS PRODUCTION_PERCENTAGE,
    SUM(total_items_completed) AS TOTAL_TASKS,
    MIN(activity_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def execute_gauge_query(engine, query: str):
    records = engine.execute_query(query, limit=1)
    return records[0].get("FINAL_PRODUCTION_PCT") if records else None

def execute_trend_query(engine, query: str):
    return engine.execute_query(query)

@router.post(
    "/production-percentage-gauge",
    response_model=ProductionPercentageGaugeResponse,
    summary="Get Production Percentage Gauge",
    description="""
Retrieve production percentage achieved for gauge visualization along with monthly trend data.

**Input Parameters:**
- **user_id** (required): The unique identifier of the user (e.g., 'AL48579')
- **start_date** (required): Start date in YYYY-MM-DD format (e.g., '2025-01-24')
- **end_date** (required): End date in YYYY-MM-DD format (e.g., '2025-01-24')
- **lob** (optional): List of Line of Business values to filter (e.g., ['Commercial'])

**Response Fields:**
- **production_percentage_achieved**: Integer percentage (0-100+) representing production target achievement
- **score_trend**: Monthly breakdown array containing:
  - month: Month in YYYY-MM format
  - production_percentage: Production percentage for that month
  - total_tasks: Number of tasks completed in that month

**Calculation Logic:**
Production % = (Total Expected Minutes for Work Items / Total Work Minutes) × 100

**Use Case:** Dashboard gauge widget showing productivity against targets

**Data Sources:**
- COB_AI_INVNTRY_PROFILE (work items, RETIME)
- COB_AI_USER_PROFILE (total system time)
""",
)
async def get_production_percentage_gauge(request: ProductionPercentageGaugeRequest) -> ProductionPercentageGaugeResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        if request.session_id:
            cached_response = await frontline_ai_coach_cache_service.get_cached_production_gauge_response(
                session_id=request.session_id,
                user_id=request.user_id,
                start_date=request.start_date,
                end_date=request.end_date,
                lob=request.lob,
            )
            if cached_response and cached_response.get("status") == "success":
                cached_response["score_trend"] = [
                    ProductionPercentageTrend(**trend) if isinstance(trend, dict) else trend
                    for trend in cached_response.get("score_trend", [])
                ]
                return ProductionPercentageGaugeResponse(**cached_response)

        lob_filter = build_lob_filter(request.lob)
        engine = connection_manager.get_engine()
        
        gauge_query = PRODUCTION_QUERY.format(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter
        )

        trend_query = PRODUCTION_TREND_QUERY.format(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter
        )

        # Execute queries in parallel
        with ThreadPoolExecutor(max_workers=2) as executor:
            gauge_future = executor.submit(execute_gauge_query, engine, gauge_query)
            trend_future = executor.submit(execute_trend_query, engine, trend_query)
            
            production_pct = gauge_future.result()
            trend_records = trend_future.result()

        trend_data = [
            ProductionPercentageTrend(
                period=r["PERIOD"],
                production_percentage=float(r["PRODUCTION_PERCENTAGE"]) if r["PRODUCTION_PERCENTAGE"] else 0.0,
                total_tasks=int(r["TOTAL_TASKS"]) if r["TOTAL_TASKS"] else 0
            )
            for r in trend_records
        ]

        if trend_data:
            def sort_key(item):
                period = item.period
                # Handle different period formats for sorting
                if '-Q' in period:  # Quarterly: 2024-Q1
                    year, quarter = period.split('-Q')
                    return (int(year), int(quarter))
                elif len(period) == 7 and '-' in period:  # Monthly: 2024-01
                    year, month = period.split('-')
                    return (int(year), int(month))
                elif '/' in period and ' - ' in period:  # Weekly: 01/01 - 01/07
                    start_date = period.split(' - ')[0]
                    month, day = start_date.split('/')
                    return (int(month), int(day))
                elif '/' in period:  # Daily: 01/01
                    month, day = period.split('/')
                    return (int(month), int(day))
                else:  # Yearly: 2024
                    return (int(period), 0)
            
            trend_data.sort(key=sort_key)

        tooltips = {
            "production_percentage_achieved": "Percentage of production target achieved, calculated as (total expected minutes for work items / total work minutes) × 100",
            "score_trend": "Monthly breakdown showing production percentage trends over time with task counts"
        }

        response = ProductionPercentageGaugeResponse(
            status="success",
            user_id=request.user_id,
            production_percentage_achieved=round(float(production_pct), 2) if production_pct else 0.00,
            score_trend=trend_data,
            message="Production percentage retrieved successfully",
            tooltips=tooltips
        )

        if request.session_id:
            await frontline_ai_coach_cache_service.cache_production_gauge_response(
                session_id=request.session_id,
                user_id=request.user_id,
                start_date=request.start_date,
                end_date=request.end_date,
                lob=request.lob,
                response=response,
            )
            await frontline_ai_coach_cache_service.upsert_frontline_ai_coach_context(
                session_id=request.session_id,
                user_id=request.user_id,
                start_date=request.start_date,
                end_date=request.end_date,
                lob=request.lob,
                production_gauge_response=response,
            )

        return response

    except Exception as e:
        logger.error(f"Production percentage query error: {type(e).__name__}: {str(e)}")
        return ProductionPercentageGaugeResponse(
            status="error",
            user_id=request.user_id,
            production_percentage_achieved=0,
            score_trend=[],
            message=f"Failed to retrieve production percentage: {str(e)}"
        )
