import logging
import asyncio
import uuid
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter
from collections import defaultdict

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import UserActivityRequest, UserActivityResponse, UserActivityData, LoginLogoutRecord, SessionRecord

logger = logging.getLogger(__name__)


router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

LOGIN_LOGOUT_QUERY = f"""
SELECT 
    DATE(LOGINTIME) as LOGINDATE,
    LOGINTIME as LOGIN_SORT_TS,
    TO_CHAR(LOGINTIME, 'HH12:MI AM') || ' ET' as login_time,
    TO_CHAR(LOGOUTTIME, 'HH12:MI AM') || ' ET' as logout_time
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_ACTIVITY
WHERE DOMAINID = '{{user_id}}'
AND DATE(LOGINTIME) = CURRENT_DATE()
ORDER BY LOGINTIME ASC
"""

SKILLED_SOURCES_QUERY = f"""
SELECT DISTINCT SKILLDESCRIPTION
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_SKILLS
WHERE USERID = '{{user_id}}'
AND DATE(PXCOMMITDATETIME) = (
    SELECT MAX(DATE(PXCOMMITDATETIME))
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_SKILLS
    WHERE USERID = '{{user_id}}'
)
"""

RANK_QUERY = f"""
SELECT 
    ROUND(AVG(TEAMRANK))::INT AS TEAMRANK,
    ROUND(AVG(DEPTRANK))::INT AS DEPTRANK
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{user_id}}'
AND LOGINDATE >= '{{start_date}}'
AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
AND TEAMRANK IS NOT NULL
AND DEPTRANK IS NOT NULL
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"



@router.post(
    "/user-activity",
    response_model=UserActivityResponse,
    summary="Get User Activity",
    description="""
Retrieve daily login/logout times and skilled sources for a user within a specified date range.

**Input Parameters:**
- **user_id** (required): The unique identifier of the user (e.g., 'AL48579')
- **start_date** (required): Start date in YYYY-MM-DD format (e.g., '2025-01-01')
- **end_date** (required): End date in YYYY-MM-DD format (e.g., '2025-01-31')
- **lob** (optional): List of Line of Business values to filter (e.g., ['Commercial'])

**Response Fields:**
- **login_logout_records**: Array of daily records with:
  - date: Login date
  - first_login: First login time (HH:MI AM/PM format)
  - last_logout: Last logout time (HH:MI AM/PM format)
- **skilled_sources**: List of intake source systems the user has worked with
- **team_rank**: User's ranking within their team (NA if not available)
- **department_rank**: User's ranking within department (NA if not available)

**Data Sources:**
- COB_AI_USER_PROFILE (login/logout times)
- COB_AI_INVNTRY_PROFILE (skilled sources)
""",
)
async def get_user_activity(request: UserActivityRequest) -> UserActivityResponse:
    request_id = f"req_{uuid.uuid4().hex[:14].upper()}"
    generated_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    
    meta = {
        "request_id": request_id,
        "screen_id": "user_activity",
        "generated_at": generated_at
    }

    if not connection_manager.validate_config():
        return UserActivityResponse(
            meta=meta,
            data=None,
            errors=[{
                "code": "INTERNAL_ERROR",
                "message": "Snowflake credentials not configured"
            }]
        )

    try:
        engine = connection_manager.get_engine()
        
        login_query = LOGIN_LOGOUT_QUERY.format(
            user_id=request.user_id
        )
        
        #lob_filter = build_lob_filter(request.lob)
        sources_query = SKILLED_SOURCES_QUERY.format(
            user_id=request.user_id
        )

        rank_query = RANK_QUERY.format(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        
        # Execute queries in parallel using asyncio.gather
        login_records, sources_records, rank_records = await asyncio.gather(
            engine.execute_query_async(login_query, limit=100),
            engine.execute_query_async(sources_query, limit=100),
            engine.execute_query_async(rank_query, limit=10)
        )
                
        sessions_by_date = defaultdict(list)
        for record in login_records:
            date_key = str(record.get("LOGINDATE")) if record.get("LOGINDATE") else ""
            sessions_by_date[date_key].append({
                "login_sort_ts": record.get("LOGIN_SORT_TS"),
                "login": record.get("LOGIN_TIME"),
                "logout": record.get("LOGOUT_TIME")
            })

        login_logout_list = [
            LoginLogoutRecord(
                date=date,
                sessions=[
                    SessionRecord(
                        login=session.get("login"),
                        logout=session.get("logout")
                    )
                    for session in sorted(
                        sessions,
                        key=lambda session: (
                            session.get("login_sort_ts") is None,
                            session.get("login_sort_ts")
                        )
                    )
                ]
            )
            for date, sessions in sorted(sessions_by_date.items())
        ] if sessions_by_date else []
        
        skilled_sources = [
            record.get("SKILLDESCRIPTION")
            for record in sources_records
            if record.get("SKILLDESCRIPTION")
        ] if sources_records else []

        team_rank = "N/A"
        department_rank = "N/A"
        if rank_records and len(rank_records) > 0:
            team_rank_value = rank_records[0].get("TEAMRANK")
            dept_rank_value = rank_records[0].get("DEPTRANK")
            if team_rank_value is not None:
                team_rank = str(team_rank_value)
            if dept_rank_value is not None:
                department_rank = str(dept_rank_value)

        tooltips = {
            "login_logout_records": "Login and logout times for today",
            "skilled_sources": "List of work source systems the user has processed work items from",
            "team_rank": "User's performance ranking within their immediate team",
            "department_rank": "User's performance ranking within their department"
        }

        if not login_logout_list and not skilled_sources:
            return UserActivityResponse(
                meta=meta,
                data=UserActivityData(
                    user_id=request.user_id,
                    login_logout_records=[],
                    skilled_sources=[],
                    team_rank=team_rank,
                    department_rank=department_rank
                ),
                errors=None,
                tooltips=tooltips
            )

        return UserActivityResponse(
            meta=meta,
            data=UserActivityData(
                user_id=request.user_id,
                login_logout_records=login_logout_list,
                skilled_sources=skilled_sources,
                team_rank=team_rank,
                department_rank=department_rank
            ),
            errors=None,
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"User activity query error: {type(e).__name__}: {str(e)}")
        return UserActivityResponse(
            meta=meta,
            data=None,
            errors=[{
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred"
            }]
        )
