import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import UserMetricsRequest, UserMetricsResponse, AuditPeriod
from services.frontline_ai_coach_cache_service import frontline_ai_coach_cache_service
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id
import config

logger = logging.getLogger(__name__)


router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

WORK_ITEMS_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    PYRESOLVEDUSERID,
    COUNT(DISTINCT PYID) AS completed_tasks
FROM latest_inventory
WHERE UPPER(TRIM(PYRESOLVEDUSERID)) = '{{user_id}}'
  AND PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
  AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
  {{lob_filter}}
GROUP BY PYRESOLVEDUSERID
"""

AUDIT_SCORE_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      {{lob_filter}}
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
),
audit_deduped AS (
    SELECT 
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID ORDER BY a.PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.AUDIT_SUBJECT_ID = '{{user_id}}'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND a.PYID LIKE 'AUD%'
      AND a.PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed',
            'Resolved-AutoClose'
      )
      {{lob_filter}}
)
SELECT 
    a.AUDIT_SUBJECT_ID,
    ROUND(AVG(a.AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT i.PYID) AS total_cases_audited
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
GROUP BY a.AUDIT_SUBJECT_ID
"""

AUDIT_SCORE_AUDIT_PERIOD_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.LOB,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND UPPER(TRIM(a.AUDIT_SUBJECT_ID)) = UPPER('{{user_id}}')
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      {{lob_filter}}
)
SELECT
    a.AUDIT_SUBJECT_ID,
    ROUND(AVG(a.AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT a.CASE_TO_AUDIT) AS total_cases_audited
FROM audit_deduped a
WHERE a.rn = 1
  {{audit_period_filter}}
GROUP BY a.AUDIT_SUBJECT_ID
"""

CYCLE_TIME_AVG = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        CYCLE_TIME,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    COUNT(DISTINCT PYID) AS total_resolved_items,
    ROUND(AVG(CYCLE_TIME), 2) AS avg_cycle_time_seconds,
    ROUND(AVG(CYCLE_TIME) / 60, 2) AS avg_cycle_time_minutes
FROM latest_inventory
WHERE UPPER(TRIM(PYRESOLVEDUSERID)) = '{{user_id}}'
  AND PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
  AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
  AND CYCLE_TIME IS NOT NULL
  {{lob_filter}}
"""


AUDIT_ERROR_COUNT_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY i.PYID
        ORDER BY i.PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        PYRESOLVEDTIMESTAMP
    FROM latest_inventory
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND UPPER(TRIM(PYRESOLVEDUSERID)) = '{{user_id}}'
      {{lob_filter}}
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
final_base AS (
    SELECT
        i.ASSOCIATE_ID,
        i.ORIGINAL_OHI_CASE_ID,
        i.PYRESOLVEDTIMESTAMP,
        ap.AUDIT_CASE_ID,
        ap.AUDIT_CREATE_TIMESTAMP,
        ap.AUDIT_UPDATE_TIMESTAMP,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        aa.RESULTTYPE,
        aa.DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.ACTIVITY_UPDATE_TIMESTAMP
    FROM filtered_inventory i
    JOIN audit_profile_deduped ap
      ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
     AND ap.rn = 1
    JOIN audit_activity_deduped aa
      ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
     AND aa.rn = 1
)
SELECT
    COUNT(DISTINCT AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS AUDIT_ERROR_COUNT
FROM final_base
"""

AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY = f"""
WITH audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        ap.AUDIT_MONTH,
        ap.AUDIT_YEAR,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) = UPPER('{{user_id}}')
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      {{lob_filter}}
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
)
SELECT
    COUNT(DISTINCT ap.AUDIT_CASE_ID || '|' || aa.ERRORCATEGORYTYPE || '|' || aa.ERRORCATEGORY) AS AUDIT_ERROR_COUNT
FROM audit_profile_deduped ap
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
WHERE ap.rn = 1
  {{audit_period_filter}}
"""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def get_audit_score_bubble(audit_score_value: float) -> str:
    """Determine audit score status bubble based on value.
    
    Rating Scale:
    - Exceptional: 100%
    - Exceeds: 99% - 99.99%
    - Meets: 98% - 98.99%
    - Approaching: 95.99% - 97.99%
    - Poor: Below 95.99%
    """
    if not audit_score_value or audit_score_value == 0.0:
        return "N/A"
    
    if audit_score_value >= 100:
        return "Exceptional"
    elif audit_score_value >= 99:
        return "Exceeds"
    elif audit_score_value >= 98:
        return "Meets"
    elif audit_score_value >= 95:
        return "Approaching"
    else:
        return "Poor"

def build_audit_month_year_filter(
    audit_periods: Optional[List[AuditPeriod]] = None,
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append((month_value, year_value))

    if not valid_periods:
        return ""

    conditions = [
        f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
        for month, year in valid_periods
    ]

    return "AND (" + " OR ".join(conditions) + ")"

def format_cycle_time(minutes: float) -> str:
    """Format cycle time from decimal minutes to 'X min Y sec' format."""
    total_minutes = int(minutes)
    seconds = int((minutes - total_minutes) * 60)
    return f"{total_minutes} mins. {seconds} secs."

def execute_work_query(engine, query: str):
    """Execute work items query and return raw records for caching."""
    records = engine.execute_query(query, limit=1)
    return records  # Return full records for caching

def execute_audit_query(engine, query: str):
    """Execute audit score query and return raw records for caching."""
    records = engine.execute_query(query, limit=1)
    return records  # Return full records for caching

def execute_cycle_time_query(engine, query: str):
    """Execute cycle time query and return raw records for caching."""
    records = engine.execute_query(query, limit=1)
    return records  # Return full records for caching

def execute_audit_error_query(engine, query: str):
    records = engine.execute_query(query, limit=1)
    return records


@router.post(
    "/user-metrics",
    response_model=UserMetricsResponse,
    summary="Get User Metrics",
    description="""
Retrieve work items completed and audit score metrics for a user within a specified date range.

**Input Parameters:**
- **user_id** (required): The unique identifier of the user (e.g., 'AA99826')
- **start_date** (required): Start date in YYYY-MM-DD format (e.g., '2026-02-01')
- **end_date** (required): End date in YYYY-MM-DD format (e.g., '2026-02-07')
- **lob** (optional): List of Line of Business values to filter (e.g., ['Commercial', 'Government'])
- **session_id** (optional): Session ID for caching support (auto-generated if not provided)

**Response Fields:**
- **work_items_completed**: Total resolved work items count
- **audit_score_percentage**: Average audit quality score as percentage
- **cycle_time_avg**: Average case resolution time (N/A if not available)
- **audit_error_count**: Total audit errors (N/A if not available)

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (work items)
- COB_AI_AUDIT_PROFILE (audit scores)
""",
)
async def get_user_metrics(request: UserMetricsRequest) -> UserMetricsResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Auto-generate session_id if missing and caching is enabled
        session_id = request.session_id
        if config.REDIS_ENABLED and not session_id:
            session_id = generate_session_id()
            request.session_id = session_id
            logger.info(f"Auto-generated session_id: {session_id}")
        
        lob_filter = build_lob_filter(request.lob)
        engine = connection_manager.get_engine()
        
        work_query = WORK_ITEMS_QUERY.format(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter
        )
        
        valid_audit_periods = [
            period
            for period in (request.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]

        has_audit_periods = bool(valid_audit_periods)

        normalized_audit_periods = sorted({
            f"{(period.month or '').strip().upper()}-{str(period.year).strip()}"
            for period in valid_audit_periods
        })

        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="a.AUDIT_MONTH",
                audit_year_column="a.AUDIT_YEAR",
            )
        
            audit_error_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="ap.AUDIT_MONTH",
                audit_year_column="ap.AUDIT_YEAR",
            )
        
            audit_query = AUDIT_SCORE_AUDIT_PERIOD_QUERY.format(
                user_id=request.user_id,
                lob_filter=lob_filter,
                audit_period_filter=audit_period_filter,
            )
        
            audit_error_query = AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY.format(
                user_id=request.user_id,
                lob_filter=lob_filter,
                audit_period_filter=audit_error_period_filter,
            )
        else:
            audit_query = AUDIT_SCORE_QUERY.format(
                user_id=request.user_id,
                start_date=request.start_date,
                end_date=request.end_date,
                lob_filter=lob_filter,
            )
        
            audit_error_query = AUDIT_ERROR_COUNT_QUERY.format(
                user_id=request.user_id,
                start_date=request.start_date,
                end_date=request.end_date,
                lob_filter=lob_filter
            )
        
        cycle_time_query = CYCLE_TIME_AVG.format(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter
        )
        
        # Build filters dict for cache isolation
        base_filters = {
            'user_id': request.user_id,
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
        }

        audit_filters = {
            **base_filters,
            'audit_mode': 'audit_period' if has_audit_periods else 'date_range',
            'audit_periods': normalized_audit_periods if has_audit_periods else None,
        }
        
        # Define fetch functions for each metric
        def fetch_work_items():
            return execute_work_query(engine, work_query)
        
        def fetch_audit_score():
            return execute_audit_query(engine, audit_query)
        
        def fetch_cycle_time():
            return execute_cycle_time_query(engine, cycle_time_query)
        
        def fetch_audit_error():
            return execute_audit_error_query(engine, audit_error_query)
        
        # Get or fetch cached metrics (only cache if session_id provided)
        if session_id:
            completed_tasks_value = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_work_items,
                session_id=session_id,
                metric_name="work_items_completed",
                filters=base_filters
            )
            
            audit_score_value = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_score,
                session_id=session_id,
                metric_name="audit_score",
                filters=audit_filters
            )
            
            cycle_time_value = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_cycle_time,
                session_id=session_id,
                metric_name="cycle_time",
                filters=base_filters
            )

            audit_error_value = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_error,
                session_id=session_id,
                metric_name="audit_error_count",
                filters=audit_filters
            )

        else:
            # No session_id - execute directly without caching in parallel
            completed_tasks_value, audit_score_value, cycle_time_value, audit_error_value = await asyncio.gather(
                engine.execute_query_async(work_query, limit=1),
                engine.execute_query_async(audit_query, limit=1),
                engine.execute_query_async(cycle_time_query, limit=1),
                engine.execute_query_async(audit_error_query, limit=1)
            )
        
        # Extract values from cached records
        work_items_count = completed_tasks_value[0].get("COMPLETED_TASKS") if completed_tasks_value else 0
        audit_score_raw = audit_score_value[0].get("AVG_AUDIT_SCORE") if audit_score_value else None
        cycle_time_raw = cycle_time_value[0].get("AVG_CYCLE_TIME_MINUTES") if cycle_time_value else None
        audit_error_raw = audit_error_value[0].get("AUDIT_ERROR_COUNT") if audit_error_value else None
        audit_error_count = str(audit_error_raw) if audit_error_raw is not None else "0"
        
        completed_tasks = str(work_items_count) if work_items_count is not None else "0"
        audit_score = f"{audit_score_raw:.2f}%" if audit_score_raw else "0.00%"
        audit_score_bubble = get_audit_score_bubble(audit_score_raw) if audit_score_raw is not None else "N/A"
        cycle_time_avg = format_cycle_time(cycle_time_raw) if cycle_time_raw is not None else "N/A"

        tooltips = {
            "work_items_completed": "Total number of work items resolved by the user during the selected date range",
            "audit_score_percentage": "Average audit quality score as a percentage, calculated from all audited cases",
            "audit_score_bubble": "Quality indicator: Exceptional (100%), Exceeds (99-99.99%), Meets (98-98.99%), Approaching (95.99-97.99%), Poor (<95.99%)",
            "cycle_time_avg": "Average time taken to complete a work item from assignment to resolution (in minutes)",
            "cycle_time_bubble": "Cycle time performance indicator based on average resolution time",
            "audit_error_count": "Total number of errors identified during quality audits"
        }

        response = UserMetricsResponse(
            status="success",
            user_id=request.user_id,
            work_items_completed=completed_tasks,
            audit_score_percentage=audit_score,
            audit_score_bubble=audit_score_bubble,
            cycle_time_avg=cycle_time_avg,
            cycle_time_bubble="N/A",
            audit_error_count=audit_error_count,
            message="User metrics retrieved successfully",
            tooltips=tooltips
        )

        if request.session_id and request.warm_ai_coach_context:
            await frontline_ai_coach_cache_service.warm_user_metrics_dependencies(
                session_id=request.session_id,
                user_id=request.user_id,
                start_date=request.start_date,
                end_date=request.end_date,
                lob=request.lob,
                user_metrics_response=response,
            )

        return response

    except Exception as e:
        logger.error(f"User metrics query error: {type(e).__name__}: {str(e)}")
        return UserMetricsResponse(
            status="error",
            user_id=request.user_id,
            work_items_completed="N/A",
            audit_score_percentage="N/A",
            audit_score_bubble="N/A",
            cycle_time_avg="N/A",
            cycle_time_bubble="N/A",
            audit_error_count="N/A",
            message=f"Failed to retrieve user metrics: {str(e)}"
        )
