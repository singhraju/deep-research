import logging
import asyncio
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import UserTimeRequest, UserTimeResponse

logger = logging.getLogger(__name__)


router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

USER_TIME_QUERY_TEMPLATE = f"""
SELECT 
    USERID,
    FLOOR(SUM(TOTALSYSTEMTIME) / 3600) || ' hrs. ' ||
    CEIL((SUM(TOTALSYSTEMTIME) % 3600) / 60.0) || ' mins.' AS fuse_time,
    FLOOR(SUM(FUSE_NON_PRODUCTIVE_TIME) / 3600) || ' hrs. ' ||
    CEIL((SUM(FUSE_NON_PRODUCTIVE_TIME) % 3600) / 60.0) || ' mins.' AS non_productive_time
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{user_id}}'
AND LOGINDATE BETWEEN '{{start_date}}' AND '{{end_date}}'
AND TOTALSYSTEMTIME IS NOT NULL
GROUP BY USERID
"""

OHI_PRODUCTIVE_TIME_QUERY_TEMPLATE = f"""
WITH time_in_seconds AS (
SELECT DISTINCT
        USERID,
        LOGINDATE,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
         SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
         SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER) AS seconds
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID = '{{user_id}}'
    AND LOGINDATE BETWEEN '{{start_date}}' AND '{{end_date}}'
    AND PRODUCTIVETIME IS NOT NULL
)
SELECT 
    USERID,
    FLOOR(SUM(seconds) / 3600) || ' hrs. ' ||
    CEIL((SUM(seconds) % 3600) / 60.0) || ' mins.' AS PRODUCTIVE_TIME
FROM time_in_seconds
GROUP BY USERID
"""

def build_user_time_query(user_id: str, start_date: str, end_date: str) -> str:
    return USER_TIME_QUERY_TEMPLATE.format(
        user_id=user_id,
        start_date=start_date,
        end_date=end_date
    )


def build_ohi_productive_time_query(user_id: str, start_date: str, end_date: str) -> str:
    return OHI_PRODUCTIVE_TIME_QUERY_TEMPLATE.format(
        user_id=user_id,
        start_date=start_date,
        end_date=end_date
    )


@router.post(
    "/time-utilization",
    response_model=UserTimeResponse,
    summary="Get Time Utilization Metrics",
    description="""
Retrieve FUSE time and non-productive time metrics for a user within a specified date range.

**Input Parameters:**
- **user_id** (required): The unique identifier of the user (e.g., '1694MU')
- **start_date** (required): Start date in YYYY-MM-DD format (e.g., '2025-04-03')
- **end_date** (required): End date in YYYY-MM-DD format (e.g., '2025-04-05')

**Response Fields:**
- **fuse_time**: Total time logged into FUSE system (formatted as 'X hrs. Y mins.')
- **fuse_non_productive_time**: Non-productive time within FUSE (breaks, idle time)
- **ohi_non_productive_time**: Non-productive time in OHI system

**Data Source:** COB_AI_USER_PROFILE table
""",
)
async def get_time_utilization(request: UserTimeRequest) -> UserTimeResponse:
    if not connection_manager.validate_config():
        raise HTTPException(
            status_code=500,
            detail="Snowflake credentials not configured."
        )

    try:
        query = build_user_time_query(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        ohi_query = build_ohi_productive_time_query(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        engine = connection_manager.get_engine()
        
        # Execute queries in parallel using asyncio.gather
        records, ohi_records = await asyncio.gather(
            engine.execute_query_async(query, limit=1),
            engine.execute_query_async(ohi_query, limit=1)
        )

        tooltips = {
            "fuse_time": "Total time the user was logged into the FUSE system during the selected date range",
            "fuse_non_productive_time": "Time spent on non-productive activities within FUSE (e.g., breaks, idle time)",
            "ohi_non_productive_time": "Average productive time in OHI system during the selected date range"
        }
        # Get OHI productive time
        ohi_productive_time = "0 hrs. 0 mins."
        if ohi_records:
            ohi_productive_time = ohi_records[0].get("PRODUCTIVE_TIME") or "0 hrs. 0 mins."
        
        if records:
            record = records[0]
            return UserTimeResponse(
                status="success",
                fuse_time=record.get("FUSE_TIME") or "0 hrs. 0 mins.",
                fuse_non_productive_time=record.get("NON_PRODUCTIVE_TIME") or "0 hrs. 0 mins.",
                ohi_non_productive_time=ohi_productive_time,  # Added
                message="User time metrics retrieved successfully",
                tooltips=tooltips
            )

        return UserTimeResponse(
            status="success",
            fuse_time="0 hrs. 0 mins.",
            fuse_non_productive_time="0 hrs. 0 mins.",
            ohi_non_productive_time=ohi_productive_time,
            message="No records found",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"User time query error: {type(e).__name__}: {str(e)}")
        return UserTimeResponse(
            status="error",
            fuse_time="N/A",
            fuse_non_productive_time="N/A",
            ohi_non_productive_time="N/A",  # Added
            message=f"Failed to retrieve user time metrics: {str(e)}"
        )

