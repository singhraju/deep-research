import logging
import asyncio
from typing import Optional, List
from datetime import datetime
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import (
    WorkItemsDrilldownPaginatedRequest,
    WorkItemsDrilldownPaginatedResponse,
    WorkItemsDrilldownDownloadRequest,
    WorkItemRecord,
    PageResponse,
)
import math
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id
from utils.cache_key_builder import build_filters_hash
import config

logger = logging.getLogger(__name__)

router = APIRouter(prefix="", tags=["Performance_IQ"])

connection_manager = SnowflakeConnectionManager()

WORK_ITEMS_PAGINATED_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        CYCLE_TIME,
        PYSTATUSWORK,
        LOB,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        PLATFORM,
        INVNTRY_TYPE
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    PYID,
    INTAKESOURCESYSTEM,
    CYCLE_TIME,
    PYSTATUSWORK,
    LOB,
    PYRESOLVEDTIMESTAMP,
    PYRESOLVEDUSERID,
    PLATFORM,
    INVNTRY_TYPE
FROM latest_inventory
WHERE UPPER(TRIM(PYRESOLVEDUSERID)) = '{{user_id}}'
  AND PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
  AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
  {{lob_filter}}
ORDER BY PYRESOLVEDTIMESTAMP DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_WORK_ITEMS_ORDER_BY = "PYRESOLVEDTIMESTAMP DESC"

DISPLAY_WORK_ITEMS_RESOLVED_STATUS_SQL = "CASE WHEN PYSTATUSWORK LIKE 'Resolved%' THEN 'Resolved' ELSE COALESCE(PYSTATUSWORK, 'N/A') END"
DISPLAY_WORK_ITEMS_RESOLVED_DATE_SQL = "DATE(PYRESOLVEDTIMESTAMP)"

SORTABLE_WORK_ITEMS_COLUMNS = {
    "pyid": "PYID",
    "work_type": "COALESCE(INTAKESOURCESYSTEM, 'N/A')",
    "case_cycle_time": "COALESCE(CYCLE_TIME, 0)",
    "resolved_status": DISPLAY_WORK_ITEMS_RESOLVED_STATUS_SQL,
    "lob": "COALESCE(LOB, 'N/A')",
    "resolved_date": DISPLAY_WORK_ITEMS_RESOLVED_DATE_SQL,
    "domain_id": "COALESCE(PYRESOLVEDUSERID, 'N/A')",
    "platform": "COALESCE(PLATFORM, 'N/A')",
    "inventory_type": "COALESCE(INVNTRY_TYPE, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_WORK_ITEMS_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_WORK_ITEMS_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid work items sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_WORK_ITEMS_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid work items sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_WORK_ITEMS_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "resolved_date":
        tie_breakers.append("PYRESOLVEDTIMESTAMP DESC")
    if normalized_sort_by != "pyid":
        tie_breakers.append("PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_work_items_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_WORK_ITEMS_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )

WORK_ITEMS_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    PYRESOLVEDUSERID,
    COUNT(DISTINCT PYID) AS completed_tasks
FROM latest_inventory
WHERE UPPER(TRIM(PYRESOLVEDUSERID)) = '{{user_id}}'
  AND PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
  AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
  {{lob_filter}}
GROUP BY PYRESOLVEDUSERID
"""

USER_NAME_QUERY = f"""
SELECT TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) as full_name
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{user_id}}'
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def format_cycle_time(cycle_time) -> str:
    if not cycle_time:
        return "N/A"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02}:{m:02}:{s:02}"
    except:
        return "N/A"

def format_date_mmddyyyy(date_str: str) -> str:
    if not date_str:
        return "N/A"
    try:
        date_obj = datetime.strptime(str(date_str)[:10], "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return "N/A"

def clean_resolved_status(status: str) -> str:
    if not status:
        return "N/A"
    return "Resolved" if status.startswith("Resolved") else status

@router.post(
    "/workitems-drilldown",
    response_model=WorkItemsDrilldownPaginatedResponse,
    summary="Get Work Items Drilldown",
    description="""
Retrieve paginated list of resolved work items for detailed table display.

**Input Parameters:**
- **screen_id** (optional): Screen identifier, defaults to 'work_items'
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user (e.g., 'AF05867')
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
  - **lob** (optional): List of Line of Business values (e.g., ['Commercial'])
- **page** (optional): Pagination parameters:
  - **page_limit**: Records per page (default: 50, max: 500)
  - **page**: Page number (1-indexed, default: 1)

**Response Fields (per record):**
- **pyid**: Unique case/work item identifier
- **work_type**: Source system (INTAKESOURCESYSTEM)
- **case_cycle_time**: Days from creation to resolution
- **resolved_status**: Status (e.g., 'Resolved')
- **lob**: Line of Business
- **resolved_date**: Resolution date (MM/DD/YYYY format)
- **domain_id**: User who resolved it
- **platform**: Processing platform
- **inventory_type**: Inventory type classification

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Source:** COB_AI_INVNTRY_PROFILE table
""",
)
async def get_workitems_drilldown(
    request: WorkItemsDrilldownPaginatedRequest
) -> WorkItemsDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        lob = request.query.lob
        
        page_limit = request.page.page_limit
        page = request.page.page or 1
        offset = (page - 1) * page_limit
        
        # Auto-generate session_id if missing and caching enabled
        session_id = request.session_id
        if config.REDIS_ENABLED and not session_id:
            session_id = generate_session_id()
            request.session_id = session_id
            logger.info(f"Auto-generated session_id: {session_id}")
        
        lob_filter = build_lob_filter(lob)
        engine = connection_manager.get_engine()
        
        # Try to reuse cached work_items_completed count from user_metrics API
        total_records = 0
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict and hash for cache key
                filters = {
                    'user_id': user_id,
                    'start_date': start_date,
                    'end_date': end_date,
                    'lob': lob,
                }
                filters_hash = build_filters_hash(**filters)
                
                # Get cached work items count from user_metrics API
                cache_key = f"session:{session_id}:{filters_hash}:work_items_completed"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract COMPLETED_TASKS from cached query result
                    total_records = int(cached_metric[0].get("COMPLETED_TASKS", 0))
                    logger.info(f" Reused cached work items count: {total_records} (from user_metrics)")
                else:
                    logger.info(f"Cache miss for work_items_completed, running COUNT query")
                    # Fall back to COUNT query
                    count_query = WORK_ITEMS_QUERY.format(
                        user_id=user_id,
                        start_date=start_date,
                        end_date=end_date,
                        lob_filter=lob_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("COMPLETED_TASKS", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached work items count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = WORK_ITEMS_QUERY.format(
                    user_id=user_id,
                    start_date=start_date,
                    end_date=end_date,
                    lob_filter=lob_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("COMPLETED_TASKS", 0) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = WORK_ITEMS_QUERY.format(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob_filter=lob_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("COMPLETED_TASKS", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = WORK_ITEMS_PAGINATED_QUERY.format(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            lob_filter=lob_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_work_items_query(
            data_query,
            request.query.sort_by,
            request.query.sort_direction,
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)

        name_result = await engine.execute_query_async(USER_NAME_QUERY.format(user_id=user_id), limit=1)
        associate_name = (name_result[0].get("FULL_NAME") or "N/A") if name_result else "N/A"

        work_items = [
            WorkItemRecord(
                pyid=record.get("PYID") or "N/A",
                work_type=record.get("INTAKESOURCESYSTEM") or "N/A",
                case_cycle_time=format_cycle_time(record.get("CYCLE_TIME")),
                resolved_status=clean_resolved_status(record.get("PYSTATUSWORK")) or "N/A",
                lob=record.get("LOB") or "N/A",
                resolved_date=format_date_mmddyyyy(record.get("PYRESOLVEDTIMESTAMP")),
                domain_id=associate_name or "N/A",
                platform=record.get("PLATFORM") or "N/A",
                inventory_type=record.get("INVNTRY_TYPE") or "N/A"
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "pyid": "Unique identifier for the work item/case",
            "work_type": "Source system or type of work item (e.g., intake source)",
            "case_cycle_time": "Time taken to complete the work item (hh:mm:ss)",
            "resolved_status": "Current status of the work item (e.g., Resolved)",
            "lob": "Line of Business associated with the work item",
            "resolved_date": "Date when the work item was resolved",
            "domain_id": "User ID of the person who resolved the work item",
            "platform": "Platform where the work item was processed",
            "inventory_type": "Type of inventory classification for the work item"
        }

        return WorkItemsDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            user_id=user_id,
            page=page_response,
            records=work_items,
            message="Work items retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated work items drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page.page_limit,
            page=request.page.page or 1,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return WorkItemsDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            user_id=request.query.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve work items: {str(e)}"
        )

@router.post(
    "/workitems-drilldown/download-excel",
    summary="Download Work Items Drilldown as Excel",
    description="""
Download complete work items drilldown data as an Excel file.

**Input Parameters:**
- **query** (required): Query parameters object containing:
  - **user_id** (required): The unique identifier of the user
  - **date_range** (required): Object with 'from' and 'to' dates in YYYY-MM-DD format
  - **lob** (optional): List of Line of Business values

**Returns:** Excel file (.xlsx) with all work item records
""",
)
async def download_workitems_drilldown_excel(
    request: WorkItemsDrilldownDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.query.user_id
        start_date = request.query.date_range.from_date
        end_date = request.query.date_range.to_date
        lob = request.query.lob
        
        lob_filter = build_lob_filter(lob)
        engine = connection_manager.get_engine()
        
        data_query = WORK_ITEMS_PAGINATED_QUERY.replace(
            "LIMIT {{limit}} OFFSET {{offset}}", ""
        ).format(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            lob_filter=lob_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        records = await engine.execute_query_async(data_query, limit=config.CACHE_FULL_DATASET_LIMIT)

        name_result = await engine.execute_query_async(USER_NAME_QUERY.format(user_id=user_id), limit=1)
        associate_name = (name_result[0].get("FULL_NAME") or "N/A") if name_result else "N/A"

        wb = Workbook()
        ws = wb.active
        ws.title = "Work Items Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Case Cycle Time",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Resolved Date",
            "Associate Name",
            "Platform",
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        for row_num, record in enumerate(records, 2):
            ws.cell(row=row_num, column=1, value=record.get("PYID") or "N/A")
            ws.cell(row=row_num, column=2, value=record.get("INTAKESOURCESYSTEM") or "N/A")
            ws.cell(row=row_num, column=3, value=format_cycle_time(record.get("CYCLE_TIME")))
            ws.cell(row=row_num, column=4, value=clean_resolved_status(record.get("PYSTATUSWORK")) or "N/A")
            ws.cell(row=row_num, column=5, value=record.get("INVNTRY_TYPE") or "N/A")
            ws.cell(row=row_num, column=6, value=record.get("LOB") or "N/A")
            ws.cell(row=row_num, column=7, value=format_date_mmddyyyy(record.get("PYRESOLVEDTIMESTAMP")))
            ws.cell(row=row_num, column=8, value=associate_name or "N/A")
            ws.cell(row=row_num, column=9, value=record.get("PLATFORM") or "N/A")
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"workitems_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for work items drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
