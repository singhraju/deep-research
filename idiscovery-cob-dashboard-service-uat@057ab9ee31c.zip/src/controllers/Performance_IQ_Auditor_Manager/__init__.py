"""Performance IQ Auditor Manager Dashboard Controllers"""

from .header_kpis import router as header_kpis_router
from .time_utilization import router as time_utilization_router
from .ata_score_gauge import router as ata_score_gauge_router
from .audit_cycle_time_gauge import router as audit_cycle_time_gauge_router
from .rebuttals import router as rebuttals_router
from .auditor_list import router as auditor_list_router
from .manager_list import router as manager_list_router
from .completed_audit_count_drilldown import router as completed_audit_count_drilldown_router
from .audit_sample_pct_drilldown import router as audit_sample_pct_drilldown_router
from .ata_score_drilldown import router as ata_score_drilldown_router
from .rebuttal_drilldown import router as rebuttal_drilldown_router
from .work_items_drilldown import router as work_items_drilldown_router
from .fuse_time_drilldown import router as fuse_time_drilldown_router
from .staff_utilization_drilldown import router as staff_utilization_drilldown_router
from .auditor_manager_lob import router as auditor_manager_lob_router
from .ai_coach_auditor_manager import router as ai_coach_router_auditor_manager
from .quality_outcomes import router as quality_outcomes_router
from .ata_rebuttal_drilldown import router as ata_rebuttal_drilldown_router
from .user_activity import router as user_activity_router

__all__ = [
    "header_kpis_router",
    "time_utilization_router",
    "ata_score_gauge_router",
    "audit_cycle_time_gauge_router",
    "rebuttals_router",
    "auditor_list_router",
    "manager_list_router",
    "completed_audit_count_drilldown_router",
    "audit_sample_pct_drilldown_router",
    "ata_score_drilldown_router",
    "rebuttal_drilldown_router",
    "work_items_drilldown_router",
    "fuse_time_drilldown_router",
    "staff_utilization_drilldown_router",
    "auditor_manager_lob_router",
    "ai_coach_router_auditor_manager",
    "quality_outcomes_router",
    "ata_rebuttal_drilldown_router",
    "user_activity_router",
]
