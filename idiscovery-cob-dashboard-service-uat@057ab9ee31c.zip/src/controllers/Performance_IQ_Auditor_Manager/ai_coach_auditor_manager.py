import logging
from fastapi import APIRouter, Response, status
import config
from schema import AuditorManagerBaseRequest, AuditorManagerAICoachResponse
from services.openai_service import generate_performance_summary, normalize_ai_summary
from services.metrics_aggregator import fetch_auditor_manager_metrics

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])


@router.post(
    "/ai-coach",
    response_model=AuditorManagerAICoachResponse,
    summary="Get AI Coach Performance Summary for Auditor Manager",
    description="""
Retrieve AI-generated performance summary for auditor manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **auditor_ids** (optional): List of auditor IDs to filter

**Response Fields:**
- **status**: Status of the request (success/error)
- **user_id**: User ID
- **performance_summary**: AI-generated summary for auditor team performance and quality assurance
- **message**: Response message
- **service**: Service name

**Status:** AI-powered quality assurance leadership coaching using OpenAI GPT models
""",
)
async def get_ai_coach_auditor_manager(request: AuditorManagerBaseRequest, response: Response) -> AuditorManagerAICoachResponse:
    if not config.is_ai_coach_enabled("auditor_manager"):
        return AuditorManagerAICoachResponse(
            status="disabled",
            user_id=request.user_id,
            performance_summary="AI Coach feature is currently disabled",
            message="Feature disabled by configuration"
        )
    
    try:
        logger.info(f"Auditor Manager AI Coach request for user {request.user_id}")
        
        metrics_data = await fetch_auditor_manager_metrics(
            user_id=request.user_id,
            start_date=getattr(request, 'start_date', None) or "",
            end_date=getattr(request, 'end_date', None) or "",
            lob=getattr(request, 'lob', None),
            session_id=getattr(request, 'session_id', None),
            manager_ids=getattr(request, 'manager_ids', None),
            auditor_ids=getattr(request, 'auditor_ids', None)
        )
        
        logger.info(f"Auditor Manager AI Coach - Metrics sent to LLM: {metrics_data}")

        if "error" in metrics_data:
            logger.error(f"Auditor Manager AI Coach metrics fetch failed for {request.user_id}: {metrics_data.get('error')}")
            response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            return AuditorManagerAICoachResponse(
                status="error",
                user_id=request.user_id,
                performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
                message=f"Failed to fetch AI Coach metrics: {metrics_data.get('error')}"
            )

        summary = await generate_performance_summary(
            user_id=request.user_id,
            metrics_data=metrics_data,
            role="auditor_manager",
            start_date=getattr(request, 'start_date', None) or "",
            end_date=getattr(request, 'end_date', None) or "",
            lob=getattr(request, 'lob', None)
        )

        summary_text = normalize_ai_summary(summary)["performance_summary"]
        
        return AuditorManagerAICoachResponse(
            status="success",
            user_id=request.user_id,
            performance_summary=summary_text,
            message="Auditor Manager AI Coach analysis completed successfully"
        )

    except Exception as e:
        logger.error(f"Auditor Manager AI Coach error: {type(e).__name__}: {str(e)}")

        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return AuditorManagerAICoachResponse(
            status="error",
            user_id=request.user_id,
            performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
            message=f"Error: {str(e)}"
        )
