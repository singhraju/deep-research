import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, CACHE_FULL_DATASET_LIMIT
from schema import (
    AuditorManagerRebuttalDrilldownRequest,
    ATARebuttalDrilldownPaginatedResponse,
    ATARebuttalRecord,
    PageResponse,
)
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    ATA_REBUTTALS_QUERY,
    build_lob_filter,
    build_associate_filter,
    build_audit_period_filter,
    build_audit_subject_manager_filter,
)
import math

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

ATA_REBUTTAL_PAGINATED_QUERY = f"""
WITH ata_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        REBUTTALFLAG,
        ISATACASE,
        INTAKESOURCESYSTEM,
        PLATFORM,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXCOMMITDATETIME,
        PXUPDATEDATETIME,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'ATA%'
      AND ISATACASE = 'Y'
),
latest_rebuttal_cases AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        REBUTTALFLAG,
        ISATACASE,
        INTAKESOURCESYSTEM,
        PLATFORM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PXUPDATEDATETIME,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM ata_base
),
rebuttal_population AS(
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        INTAKESOURCESYSTEM,
        PLATFORM,
        LOB,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM latest_rebuttal_cases
    WHERE rn = 1
      AND REBUTTALFLAG = 'Y'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{audit_subject_filter}}
      {{audit_subject_manager_filter}}
),
completion_candidates AS (
    SELECT
        rp.PYID,
        rp.CASE_TO_AUDIT,
        rp.AUDIT_SUBJECT_ID,
        rp.AUDIT_SUBJECT_NAME,
        rp.AUDIT_SUBJECT_MGR_ID,
        rp.INTAKESOURCESYSTEM,
        rp.PLATFORM,
        rp.LOB,
        rp.INVNTRY_TYPE,
        rp.AUDIT_MONTH,
        rp.AUDIT_YEAR,
        a.PYSTATUSWORK AS completion_status,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY rp.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM rebuttal_population rp
    INNER JOIN ata_base a
        ON rp.PYID = a.PYID
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        INTAKESOURCESYSTEM,
        PLATFORM,
        LOB,
        INVNTRY_TYPE,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    ce.PYID AS WORK_ITEM_ID,
    COALESCE(ce.INTAKESOURCESYSTEM, 'N/A') AS WORKTYPE_CATEGORY,
    CASE
        WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(ce.completion_status, 'N/A')
    END AS OUTCOME_STATUS,
    COALESCE(ce.LOB, 'N/A') AS LOB,
    ce.completion_ts AS RESOLVED_DATE,
    COALESCE(ce.AUDIT_SUBJECT_ID, 'N/A') AS DOMAIN_ID,
    COALESCE(ce.AUDIT_SUBJECT_NAME, 'N/A') AS ASSOCIATE_NAME,
    COALESCE(ce.PLATFORM, 'N/A') AS PLATFORM_SOURCE_SYSTEM,
    COALESCE(ce.INVNTRY_TYPE, 'N/A') AS INVENTORY_TYPE,
    COALESCE(aa.ERRORCATEGORYTYPE, 'N/A') AS ERROR_TYPE,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS ERROR_CATEGORY,
    COALESCE(aa.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME,
    COALESCE(ce.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ce.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM completion_event ce
INNER JOIN deduped_audit_activity aa
    ON ce.PYID = aa.CASEID
    AND aa.rn = 1
ORDER BY ce.completion_ts DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_ATA_REBUTTAL_ORDER_BY = "ce.completion_ts DESC"
DISPLAY_ATA_REBUTTAL_RESOLVED_DATE_SQL = "DATE(ce.completion_ts)"

DISPLAY_ATA_REBUTTAL_OUTCOME_STATUS_SQL = """
CASE
    WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
    WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
    ELSE COALESCE(ce.completion_status, 'N/A')
END
"""

SORTABLE_ATA_REBUTTAL_COLUMNS = {
    "work_item_id": "ce.PYID",
    "worktype_category": "COALESCE(ce.INTAKESOURCESYSTEM, 'N/A')",
    "outcome_status": DISPLAY_ATA_REBUTTAL_OUTCOME_STATUS_SQL,
    "lob": "COALESCE(ce.LOB, 'N/A')",
    "resolved_date": DISPLAY_ATA_REBUTTAL_RESOLVED_DATE_SQL,
    "domain_id": "COALESCE(ce.AUDIT_SUBJECT_ID, 'N/A')",
    "associate_name": "COALESCE(ce.AUDIT_SUBJECT_NAME, 'N/A')",
    "platform_source_system": "COALESCE(ce.PLATFORM, 'N/A')",
    "inventory_type": "COALESCE(ce.INVNTRY_TYPE, 'N/A')",
    "error_type": "COALESCE(aa.ERRORCATEGORYTYPE, 'N/A')",
    "error_category": "COALESCE(aa.ERRORCATEGORY, 'N/A')",
    "rebuttal_outcome": "COALESCE(aa.REBUTTALOUTCOME, 'N/A')",
    "audit_month": "COALESCE(ce.AUDIT_MONTH, 'N/A')",
    "audit_year": "COALESCE(ce.AUDIT_YEAR, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_ATA_REBUTTAL_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_ATA_REBUTTAL_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid ATA rebuttal sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_ATA_REBUTTAL_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid ATA rebuttal sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_ATA_REBUTTAL_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "resolved_date":
        tie_breakers.append("ce.completion_ts DESC")
    if normalized_sort_by != "work_item_id":
        tie_breakers.append("ce.PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_ata_rebuttal_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_ATA_REBUTTAL_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )


def format_date_mmddyyyy(date_str: str) -> str:
    if not date_str:
        return ""
    try:
        cleaned = str(date_str)
        if "T" in cleaned:
            cleaned = cleaned.split("T")[0]
        elif " " in cleaned:
            cleaned = cleaned.split(" ")[0]
        return datetime.strptime(cleaned, "%Y-%m-%d").strftime("%m/%d/%Y")
    except:
        return str(date_str)


@router.post(
    "/ata-rebuttal-drilldown",
    response_model=ATARebuttalDrilldownPaginatedResponse,
    summary="Get ATA Rebuttal Drilldown (Auditor Manager)",
    description="Retrieve paginated list of ATA rebuttal cases with ATA rebuttal count.",
)
async def get_ata_rebuttal_drilldown(
    request: AuditorManagerRebuttalDrilldownRequest
) -> ATARebuttalDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit

        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        audit_subject_filter = build_associate_filter(request.auditor_ids)
        audit_subject_manager_filter = build_audit_subject_manager_filter(request.manager_ids)

        engine = connection_manager.get_engine()

        count_query = ATA_REBUTTALS_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter
        )
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = count_result[0].get("ATA_REBUTTAL_COUNT", 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = ATA_REBUTTAL_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_ata_rebuttal_query(data_query, request.sort_by, request.sort_direction)
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        rebuttal_records = [
            ATARebuttalRecord(
                work_item_id=r.get("WORK_ITEM_ID") or "N/A",
                worktype_category=r.get("WORKTYPE_CATEGORY") or "N/A",
                outcome_status=r.get("OUTCOME_STATUS") or "N/A",
                lob=r.get("LOB") or "N/A",
                resolved_date=format_date_mmddyyyy(r.get("RESOLVED_DATE")) if r.get("RESOLVED_DATE") else "N/A",
                domain_id=r.get("DOMAIN_ID") or "N/A",
                associate_name=r.get("ASSOCIATE_NAME") or "N/A",
                platform_source_system=r.get("PLATFORM_SOURCE_SYSTEM") or "N/A",
                error_category=r.get("ERROR_CATEGORY") or "N/A",
                error_type=r.get("ERROR_TYPE") or "N/A",
                rebuttal_outcome=r.get("REBUTTAL_OUTCOME") or "N/A",
                inventory_type=r.get("INVENTORY_TYPE") or "N/A",
                audit_month=r.get("AUDIT_MONTH") or "N/A",
                audit_year=r.get("AUDIT_YEAR") or "N/A",
            )
            for r in records
        ] if records else []

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        return ATARebuttalDrilldownPaginatedResponse(
            status="success",
            screen_id="ata_rebuttal_auditor_manager",
            user_id=request.user_id,
            page=page_response,
            records=rebuttal_records,
            message="ATA rebuttal records retrieved successfully",
            tooltips={
                "work_item_id": "Unique identifier for the ATA work item (PYID starting with 'ATA')",
                "worktype_category": "Work type category (INTAKESOURCESYSTEM)",
                "outcome_status": "Outcome status of the ATA rebuttal case",
                "lob": "Line of Business associated with the work item",
                "resolved_date": "Date when the case was resolved",
                "domain_id": "Auditor ID who completed the audit",
                "associate_name": "Name of the auditor",
                "platform_source_system": "Platform or source system where the case was processed",
                "inventory_type": "Inventory type of the work item",
                "error_type": "Error type classification",
                "error_category": "Error category classification",
                "rebuttal_outcome": "Outcome of the rebuttal",
            }
        )

    except Exception as e:
        logger.error(f"ATA rebuttal drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return ATARebuttalDrilldownPaginatedResponse(
            status="error",
            screen_id="ata_rebuttal_auditor_manager",
            user_id=request.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve ATA rebuttal records: {str(e)}"
        )


@router.post(
    "/ata-rebuttal-drilldown/download-excel",
    summary="Download ATA Rebuttal Drilldown as Excel (Auditor Manager)",
)
async def download_ata_rebuttal_drilldown_excel(
    request: AuditorManagerRebuttalDrilldownRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"

        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        audit_subject_filter = build_associate_filter(request.auditor_ids)
        audit_subject_manager_filter = build_audit_subject_manager_filter(request.manager_ids)

        engine = connection_manager.get_engine()

        download_query = ATA_REBUTTAL_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter,
            limit=CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        data_result = await engine.execute_query_async(download_query, limit=CACHE_FULL_DATASET_LIMIT)

        wb = Workbook()
        ws = wb.active
        ws.title = "ATA Rebuttal Drilldown"

        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")

        headers = [
            "Work Item",
            "Worktype Category",
            "Error Type",
            "Error Category",
            "Rebuttal Outcome",
            "Status",
            "Inventory Type",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Platform - Source System",
            "Auditor Name",
        ]

        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment

        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM_ID", "") or "N/A"))
            ws.cell(row=row_num, column=2, value=str(row.get("WORKTYPE_CATEGORY", "") or "N/A"))
            ws.cell(row=row_num, column=3, value=str(row.get("ERROR_TYPE", "") or "N/A"))
            ws.cell(row=row_num, column=4, value=str(row.get("ERROR_CATEGORY", "") or "N/A"))
            ws.cell(row=row_num, column=5, value=str(row.get("REBUTTAL_OUTCOME", "") or "N/A"))
            ws.cell(row=row_num, column=6, value=str(row.get("OUTCOME_STATUS", "") or "N/A"))
            ws.cell(row=row_num, column=7, value=str(row.get("INVENTORY_TYPE", "") or "N/A"))
            ws.cell(row=row_num, column=8, value=str(row.get("LOB", "") or "N/A"))
            ws.cell(row=row_num, column=9, value=format_date_mmddyyyy(str(row.get("RESOLVED_DATE", ""))) if row.get("RESOLVED_DATE") else "N/A")
            ws.cell(row=row_num, column=10, value=str(row.get("AUDIT_MONTH", "") or "N/A"))
            ws.cell(row=row_num, column=11, value=(
                int(row["AUDIT_YEAR"]) if row.get("AUDIT_YEAR") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=12, value=str(row.get("PLATFORM_SOURCE_SYSTEM", "") or "N/A"))
            ws.cell(row=row_num, column=13, value=str(row.get("ASSOCIATE_NAME", "") or "N/A"))

        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

        output = BytesIO()
        wb.save(output)
        output.seek(0)
        

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename=ata_rebuttal_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"}
        )

    except Exception as e:
        logger.error(f"Excel download error for ATA rebuttal drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")