import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, CACHE_FULL_DATASET_LIMIT
from schema import (
    AuditorManagerAtaAuditScoreDrilldownRecord,
    AuditorManagerAtaAuditScoreDrilldownRequest,
    AuditorManagerAtaAuditScoreDrilldownResponse,
    PageResponse,
)
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    build_associate_filter,
    build_audit_period_filter,
    build_audit_subject_manager_filter,
    build_lob_filter as build_lob_filter_header,
    ATA_AUDIT_SCORE_QUERY,
)
import math

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def clean_resolved_status(status: str) -> str:
    if not status:
        return ""
    normalized_status = str(status).strip().upper()
    if normalized_status == "OPEN-FEEDBACKREVIEW":
        return "Open-FeedbackReview"
    if normalized_status == "RESOLVED-COMPLETED":
        return "Resolved-Completed"
    return str(status)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

# Paginated query for ATA audit score drilldown
ATA_AUDIT_SCORE_PAGINATED_QUERY = f"""
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB,
        INTAKESOURCESYSTEM,
        PLATFORM,
        AUDITCYCLETIME,
        INVNTRY_TYPE
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{audit_subject_filter}}
      {{audit_subject_manager_filter}}
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PLATFORM,
        a.AUDITCYCLETIME,
        a.INVNTRY_TYPE,
        a.LOB,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SUBJECT_NAME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        INTAKESOURCESYSTEM,
        PLATFORM,
        AUDITCYCLETIME,
        INVNTRY_TYPE,
        LOB,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)
SELECT
    PYID,
    INTAKESOURCESYSTEM,
    completion_type AS PYSTATUSWORK,
    LOB,
    DATE(completion_timestamp) AS AUDIT_DATE,
    AUDIT_SUBJECT_ID AS AUDITOR_ID,
    COALESCE(AUDIT_SUBJECT_NAME, 'N/A') AS AUDIT_SUBJECT_NAME,
    AUDIT_SCORE,
    PLATFORM,
    TARGET_AUDIT,
    AUDITCYCLETIME,
    INVNTRY_TYPE,
    COALESCE(AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM ata_final_records
ORDER BY AUDIT_DATE DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_ATA_AUDIT_SCORE_ORDER_BY = "AUDIT_DATE DESC"
DISPLAY_ATA_AUDIT_SCORE_RESOLVED_STATUS_SQL = """
CASE
    WHEN PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
    WHEN PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
    ELSE COALESCE(PYSTATUSWORK, '')
END
"""

SORTABLE_ATA_AUDIT_SCORE_COLUMNS = {
    "pyid": "PYID",
    "work_type": "COALESCE(INTAKESOURCESYSTEM, '')",
    "audit_cycle_time": "COALESCE(AUDITCYCLETIME, 0)",
    "resolved_status": DISPLAY_ATA_AUDIT_SCORE_RESOLVED_STATUS_SQL,
    "lob": "COALESCE(LOB, '')",
    "audit_resolved": "AUDIT_DATE",
    "auditor_domain_id": "COALESCE(AUDIT_SUBJECT_NAME, 'N/A')",
    "platform": "COALESCE(PLATFORM, 'N/A')",
    "audit_score": "COALESCE(TRY_TO_DECIMAL(TRIM(AUDIT_SCORE)), 0)",
    "targeted_audit_type": "COALESCE(TARGET_AUDIT, 'N/A')",
    "inventory_type": "COALESCE(INVNTRY_TYPE, 'N/A')",
    "audit_month": "COALESCE(AUDIT_MONTH, 'N/A')",
    "audit_year": "COALESCE(AUDIT_YEAR, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_ATA_AUDIT_SCORE_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_ATA_AUDIT_SCORE_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid ATA audit score sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_ATA_AUDIT_SCORE_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid ATA audit score sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_ATA_AUDIT_SCORE_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "audit_resolved":
        tie_breakers.append("AUDIT_DATE DESC")
    if normalized_sort_by != "pyid":
        tie_breakers.append("PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_ata_audit_score_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_ATA_AUDIT_SCORE_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )

@router.post(
    "/ata-score-drilldown",
    response_model=AuditorManagerAtaAuditScoreDrilldownResponse,
    summary="Get ATA Audit Score Drilldown (Auditor Manager)",
    description="""
Retrieve paginated list of audit scores for auditor manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **auditor_ids** (optional): List of auditor IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **pyid**: Unique ATA audit case identifier
- **work_type**: Source system type
- **audit_cycle_time**: Time from creation to audit in hh:mm:ss format
- **resolved_status**: Case status
- **lob**: Line of Business
- **audit_resolved**: Audit completion date (MM/DD/YYYY format)
- **auditor_domain_id**: Auditor's user ID
- **platform**: Processing platform
- **audit_score**: Quality score as percentage (e.g., '95%')
- **targeted_audit_type**: Type of audit (targeted vs random)
- **inventory_type**: Type of inventory or work category

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (ATA audit data with ISATACASE='Y')
- COB_AI_INVNTRY_PROFILE (cycle time and inventory type)
- COB_AI_USER_PROFILE (manager-auditor relationships)
""",
)
async def get_ata_score_drilldown(
    request: AuditorManagerAtaAuditScoreDrilldownRequest
) -> AuditorManagerAtaAuditScoreDrilldownResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter_header(request.lob)
        audit_subject_filter = build_associate_filter(request.auditor_ids)
        audit_subject_manager_filter = build_audit_subject_manager_filter(request.manager_ids)

        
        engine = connection_manager.get_engine()
        
        count_query = ATA_AUDIT_SCORE_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter
        )
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = int(count_result[0].get("TOTAL_ATA_CASES") or 0) if count_result else 0
        target_audit_count = int(count_result[0].get("TARGET_AUDIT_COUNT") or 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = ATA_AUDIT_SCORE_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_ata_audit_score_query(data_query, request.sort_by, request.sort_direction)
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        audit_scores = [
            AuditorManagerAtaAuditScoreDrilldownRecord(
                pyid=str(r.get("PYID") or "N/A"),
                work_type=str(r.get("INTAKESOURCESYSTEM") or "N/A"),
                audit_cycle_time=format_cycle_time(r.get("AUDITCYCLETIME")),
                resolved_status=clean_resolved_status(str(r.get("PYSTATUSWORK") or "N/A")),
                lob=str(r.get("LOB") or "N/A"),
                audit_resolved=format_date_mmddyyyy(str(r.get("AUDIT_DATE") or "")),
                auditor_domain_id=str(r.get("AUDIT_SUBJECT_NAME") or "N/A"),
                platform=str(r.get("PLATFORM") or "N/A"),
                audit_score=f"{r.get('AUDIT_SCORE')}%" if r.get("AUDIT_SCORE") is not None else "N/A",
                targeted_audit_type=str(r.get("TARGET_AUDIT") or "N/A"),
                inventory_type=str(r.get("INVNTRY_TYPE") or "N/A"),
                audit_month=str(r.get("AUDIT_MONTH") or "N/A"),
                audit_year=str(r.get("AUDIT_YEAR") or "N/A"),
            )
            for r in records
        ] if records else []

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "pyid": "Unique identifier for the ATA audit case",
            "work_type": "Source system or type of work item that was audited",
            "audit_cycle_time": "Time from case creation to audit completion in hh:mm:ss format",
            "resolved_status": "Current status of the audited work item",
            "inventory_type": "Type of inventory or work category",
            "lob": "Line of Business associated with the audited case",
            "audit_resolved": "Date when the audit was completed",
            "platform": "Platform where the case was processed",
            "audit_score": "Quality score achieved for this audit as a percentage",
            "targeted_audit_type": "Type of audit performed (targeted vs random)",
            "auditor_domain_id": "Name of the auditor who performed the audit"
        }

        return AuditorManagerAtaAuditScoreDrilldownResponse(
            status="success",
            screen_id=request.screen_id,
            user_id=request.user_id,
            page=page_response,
            records=audit_scores,
            completed_audit_work_items=total_records,
            target_audit_count=target_audit_count,
            message="ATA audit score records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated ATA audit score drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return AuditorManagerAtaAuditScoreDrilldownResponse(
            status="error",
            screen_id=request.screen_id,
            user_id=request.user_id,
            page=page_response,
            records=[],
            completed_audit_work_items=0,
            target_audit_count=0,
            message=f"Failed to retrieve ATA audit score records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )

def excel_cell_value(value):
    if value is None:
        return ""
    if isinstance(value, (int, float)):
        return value
    return value

@router.post(
    "/ata-score-drilldown/download-excel",
    summary="Download ATA Audit Score Drilldown as Excel (Auditor Manager)",
    description="""
Download complete ATA audit score drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **auditor_ids** (optional): List of auditor IDs to filter

**Returns:** Excel file (.xlsx) with all audit score records
""",
)
async def download_ata_score_drilldown_excel(
    request: AuditorManagerAtaAuditScoreDrilldownRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:

        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"

        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter_header(request.lob)
        audit_subject_filter = build_associate_filter(request.auditor_ids)
        audit_subject_manager_filter = build_audit_subject_manager_filter(request.manager_ids)

        engine = connection_manager.get_engine()

        download_query = ATA_AUDIT_SCORE_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter,
            limit=CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "ATA Audit Score"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Audit Status",
            "Inventory Type",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Platform",
            "Audit Score",
            "Targeted Audit Type",
            "Auditor Name",
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("PYID", "N/A")))
            ws.cell(row=row_num, column=2, value=str(row.get("INTAKESOURCESYSTEM", "N/A")))
            ws.cell(row=row_num, column=3, value=clean_resolved_status(str(row.get("PYSTATUSWORK", "N/A"))))
            ws.cell(row=row_num, column=4, value=str(row.get("INVNTRY_TYPE", "N/A")))
            ws.cell(row=row_num, column=5, value=str(row.get("LOB", "N/A")))
            ws.cell(row=row_num, column=6, value=format_date_mmddyyyy(str(row.get("AUDIT_DATE", "N/A"))) if row.get("AUDIT_DATE") else "N/A")
            ws.cell(row=row_num, column=7, value=excel_cell_value(row.get("AUDIT_MONTH", "N/A")))
            ws.cell(row=row_num, column=8, value=excel_cell_value(
                int(row["AUDIT_YEAR"]) if row.get("AUDIT_YEAR") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=9, value=str(row.get("PLATFORM", "N/A")))
            ws.cell(row=row_num, column=10, value=excel_cell_value(
                float(row["AUDIT_SCORE"]) if row.get("AUDIT_SCORE") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=11, value=str(row.get("TARGET_AUDIT", "N/A")))
            ws.cell(row=row_num, column=12, value=str(row.get("AUDIT_SUBJECT_NAME", "N/A")))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"ata_audit_score_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for ATA audit score drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
