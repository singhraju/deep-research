import logging
import asyncio
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import (
    AuditorManagerBaseRequest,
    AuditorManagerAtaScoreGaugeResponse,
    AuditScoreTrend,
    AuditPeriod,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    ATA_AUDIT_SCORE_QUERY,
    build_lob_filter,
    build_audit_subject_manager_filter,
    build_associate_filter,
    build_audit_period_filter,
)

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

ATA_SCORE_TREND_QUERY = f"""
WITH grouping_logic AS (
    SELECT
        '{{grouping_type}}' AS grouping_type,
        '{{use_audit_period_grouping}}' AS use_audit_period_grouping
),
ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{audit_subject_filter}}
      {{audit_subject_manager_filter}}
),
first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),
first_resolved AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),
completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),
ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.AUDIT_YEAR,
        a.AUDIT_MONTH,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_timestamp
),
ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
),
ata_scores_with_audit_period AS (
    SELECT
        PYID,
        TO_NUMBER(TRIM(AUDIT_SCORE)) AS AUDIT_SCORE,
        completion_timestamp,
        DATE(completion_timestamp) AS completion_date,
        AUDIT_YEAR,
        AUDIT_MONTH,
        CASE UPPER(TRIM(AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM ata_final_records
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(a.completion_timestamp)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(a.completion_timestamp))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(a.AUDIT_YEAR), a.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(a.completion_timestamp))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(a.AUDIT_YEAR),
                CASE
                    WHEN a.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN a.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN a.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(a.completion_timestamp))

            ELSE DATE_TRUNC('year', DATE(a.completion_timestamp))
        END AS group_key,
        a.completion_date,
        a.AUDIT_SCORE,
        a.PYID
    FROM ata_scores_with_audit_period a
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    ROUND(AVG(AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE,
    COUNT(DISTINCT PYID) AS TOTAL_AUDITS,
    MIN(completion_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
"""


def execute_query(engine, query: str, limit: int = 1):
    return engine.execute_query(query, limit=limit)


def has_valid_audit_periods(audit_periods: Optional[List[AuditPeriod]] = None) -> bool:
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = (period.year or "").strip()

        if not month_value or not year_value:
            continue

        seen_periods.add((month_value.upper(), year_value))

    return bool(seen_periods)


def get_trend_grouping_type(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    audit_periods: Optional[List[AuditPeriod]] = None,
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = (period.year or "").strip()

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append(key)

    if valid_periods:
        month_count = len(valid_periods)

        if month_count == 1:
            return "weekly"
        if month_count <= 6:
            return "monthly"
        return "quarterly"

    range_start = start_date or "1900-01-01"
    range_end = end_date or "2099-12-31"

    total_days = (
        datetime.strptime(range_end, "%Y-%m-%d") -
        datetime.strptime(range_start, "%Y-%m-%d")
    ).days + 1

    if total_days <= 7:
        return "daily"
    if total_days <= 28:
        return "weekly"
    if total_days <= 365:
        return "monthly"
    if total_days <= 1095:
        return "quarterly"
    return "yearly"


@router.post(
    "/ata-score-gauge",
    response_model=AuditorManagerAtaScoreGaugeResponse,
    summary="Get Auditor Manager ATA Score Gauge",
    description="""
Retrieve ATA score gauge metric for auditor manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter
- **auditor_ids** (optional): List of auditor IDs to filter

**Response Fields:**
- **ata_score**: Average ATA audit score (2 decimal places)
- **trend**: ATA score trend over time

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (audit scores with direct manager filtering)
""",
)
async def get_auditor_manager_ata_score_gauge(request: AuditorManagerBaseRequest) -> AuditorManagerAtaScoreGaugeResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        lob_filter = build_lob_filter(request.lob)
        audit_subject_filter = build_associate_filter(request.auditor_ids)
        audit_subject_manager_filter = build_audit_subject_manager_filter(request.manager_ids)
        ata_audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        grouping_type = get_trend_grouping_type(
            request.start_date,
            request.end_date,
            request.audit_periods,
        )
        use_audit_period_grouping = "true" if has_valid_audit_periods(request.audit_periods) else "false"

        engine = connection_manager.get_engine()

        ata_score_query = ATA_AUDIT_SCORE_QUERY.format(
            audit_period_filter=ata_audit_period_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter
        )

        trend_query = ATA_SCORE_TREND_QUERY.format(
            audit_period_filter=ata_audit_period_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter,
            grouping_type=grouping_type,
            use_audit_period_grouping=use_audit_period_grouping
        )
        
        # Execute queries in parallel using asyncio.gather
        score_records, trend_records = await asyncio.gather(
            engine.execute_query_async(ata_score_query, limit=1),
            engine.execute_query_async(trend_query, limit=10000)
        )

        ata_score = round(float(score_records[0].get("AVG_ATA_SCORE", 0.0)), 2) if score_records and score_records[0].get("AVG_ATA_SCORE") else 0.0

        # Sort trend records by sort_date in chronological order
        if trend_records:
            trend_records = sorted(trend_records, key=lambda x: x.get("SORT_DATE") or "")

        trend_data = [
            AuditScoreTrend(
                period=r["PERIOD"],
                avg_audit_score=round(float(r["AVG_AUDIT_SCORE"]), 2) if r["AVG_AUDIT_SCORE"] else 0.0,
                total_cases=int(r["TOTAL_AUDITS"]) if r["TOTAL_AUDITS"] else 0
            )
            for r in trend_records
        ] if trend_records else []

        tooltips = {
            "ata_score": "Average ATA audit score across all audited cases",
            "trend": "ATA score trend over time"
        }

        return AuditorManagerAtaScoreGaugeResponse(
            status="success",
            ata_score=ata_score,
            trend=trend_data,
            message="Auditor Manager ATA score gauge retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Auditor Manager ATA score gauge query error: {type(e).__name__}: {str(e)}")
        return AuditorManagerAtaScoreGaugeResponse(
            status="error",
            ata_score=0.0,
            trend=[],
            message=f"Failed to retrieve Auditor Manager ATA score gauge: {str(e)}"
        )
