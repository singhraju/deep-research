import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import (
    AuditorManagerAuditSamplePctDrilldownRecord,
    AuditorManagerAuditSamplePctDrilldownRequest,
    AuditorManagerAuditSamplePctDrilldownResponse,
    PageResponse,
)
from controllers.Performance_IQ_Auditor_Manager.header_kpis import build_audit_period_filter
import math

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

# Comprehensive query to get audit sample percentage data (Auditor Manager)
AUDIT_SAMPLE_PCT_QUERY = f"""
WITH invntry_base AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        PYSTATUSWORK,
        LOB,
        INTAKESOURCESYSTEM
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
deduped_invntry AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID
    FROM invntry_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      AND INTAKESOURCESYSTEM NOT IN ('ASPEN', 'eCOB Intake')
      AND INTAKESOURCESYSTEM NOT LIKE '%-DUP'
      AND INTAKESOURCESYSTEM NOT LIKE '%Adhoc%'
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        DATE(PXCREATEDATETIME) AS audit_date
    FROM audit_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      {{audit_period_filter}}
      {{lob_filter}}
      {{auditor_filter}}
      {{manager_filter}}
),
audited_cases AS (
    SELECT
        i.PYID AS inventory_case,
        a.PYID AS audit_case,
        a.AUDITOR_ID,
        a.PYSTATUSWORK AS audit_status
    FROM deduped_invntry i
    LEFT JOIN deduped_audit a
        ON i.PYID = a.CASE_TO_AUDIT
),
audit_summary AS (
    SELECT
        COUNT(DISTINCT inventory_case) AS total_cases_resolved,
        COUNT(DISTINCT CASE WHEN audit_case IS NOT NULL THEN inventory_case END) AS total_audited,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN inventory_case END) AS open_audits,
        COUNT(DISTINCT CASE WHEN audit_status = 'Resolved-Completed' THEN inventory_case END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN inventory_case END) AS pending_audits
    FROM audited_cases
)
SELECT
    total_cases_resolved AS TOTAL_CASES_RESOLVED,
    open_audits AS OPEN_AUDITS,
    closed_audits AS CLOSED_AUDITS,
    pending_audits AS PENDING_AUDITS,
    total_audited AS TOTAL_AUDITS,
    total_cases_resolved AS TOTAL_WORK_ITEMS_COMPLETED,
    total_audited AS TOTAL_ITEMS_AUDITED,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS AUDIT_SAMPLE_PCT,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS OVERALL_AUDIT_SAMPLE_PCT
FROM audit_summary
"""

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)


def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_user_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    if start_date and end_date:
        return f"AND LOGINDATE >= '{start_date}' AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND LOGINDATE >= '{start_date}'"
    elif end_date:
        return f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_auditor_filter(auditor_ids: Optional[List[str]] = None) -> str:
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND AUDITOR_ID IN ('{auditor_ids_str}')"
    return ""

def build_auditor_ids_list(auditor_ids: Optional[List[str]] = None) -> str:
    if auditor_ids and len(auditor_ids) > 0:
        return "', '".join(auditor_ids)
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table (uses AUDITOR_MGR_ID field)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND AUDITOR_MGR_ID IN ('{manager_ids_str}')"
    return ""

def build_audit_subject_filter(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE ATA table (uses AUDIT_SUBJECT_ID field)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{auditor_ids_str}')"
    return ""

def build_audit_subject_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE ATA table (uses AUDIT_SUBJECT_MGR_ID field)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND AUDIT_SUBJECT_MGR_ID IN ('{manager_ids_str}')"
    return ""

def build_date_filter_ata(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for PXCREATEDATETIME (audit section)"""
    if start_date and end_date:
        return f"AND PXCREATEDATETIME >= '{start_date}' AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND PXCREATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

@router.post(
    "/audit-sample-pct-drilldown",
    response_model=AuditorManagerAuditSamplePctDrilldownResponse,
    summary="Get Audit Sample Percentage Drilldown (Auditor Manager)",
    description="""
Retrieve audit sample percentage summary data showing key metrics (Auditor Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **auditor_ids** (optional): List of auditor IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields:**
- **date_range**: Date range for the audit period (e.g., "1/1/2026 — 1/7/2026")
- **open_audits**: Number of open audits (e.g., 35)
- **closed_audits**: Number of closed audits (e.g., 23)
- **pending_audits**: Number of pending audits (e.g., 3)
- **total_cases_resolved**: Total cases resolved by auditor during previous week (e.g., 320)

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (resolved cases data)
- COB_AI_AUDIT_PROFILE (audit status data)
""",
)
async def get_audit_sample_pct_drilldown(
    request: AuditorManagerAuditSamplePctDrilldownRequest
) -> AuditorManagerAuditSamplePctDrilldownResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        
        # Build filters
        date_filter = build_date_filter(request.start_date, request.end_date)
        audit_period_create_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        auditor_filter = build_auditor_filter(request.auditor_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        
        engine = connection_manager.get_engine()
        
        # Format query with filters
        query = AUDIT_SAMPLE_PCT_QUERY.format(
            date_filter=date_filter,
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter
        )
        
        # Execute query
        records = await engine.execute_query_async(query, limit=1)
        
        # Aggregate results across all auditors
        open_audits = 0
        closed_audits = 0
        pending_audits = 0
        total_cases_resolved = 0
        
        if records:
            total_cases_resolved = int(records[0].get("TOTAL_CASES_RESOLVED", 0))
            open_audits = int(records[0].get("OPEN_AUDITS", 0))
            closed_audits = int(records[0].get("CLOSED_AUDITS", 0))
            pending_audits = int(records[0].get("PENDING_AUDITS", 0))
        else:
            total_cases_resolved = 0
            open_audits = 0
            closed_audits = 0
            pending_audits = 0

        
        # Format date range
        date_range = ""
        if request.start_date and request.end_date:
            start_formatted = format_date_mmddyyyy(request.start_date)
            end_formatted = format_date_mmddyyyy(request.end_date)
            date_range = f"{start_formatted} — {end_formatted}"
        elif request.start_date:
            date_range = f"{format_date_mmddyyyy(request.start_date)} — Present"
        elif request.end_date:
            date_range = f"Up to {format_date_mmddyyyy(request.end_date)}"
        else:
            date_range = "All Time"
        
        # Create summary record with real data
        summary_record = AuditorManagerAuditSamplePctDrilldownRecord(
            date_range=date_range,
            open_audits=open_audits,
            closed_audits=closed_audits,
            pending_audits=pending_audits,
            total_cases_resolved=total_cases_resolved
        )
        
        # Return single summary record (not paginated in traditional sense)
        audit_sample_records = [summary_record]
        total_records = 1
        total_pages = 1
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=False,
            has_previous=False
        )

        tooltips = {
            "date_range": "Date range for the audit period",
            "open_audits": "Number of open audits (feedback/rebuttal review)",
            "closed_audits": "Number of closed/completed audits",
            "pending_audits": "Number of pending audits (audit review/unassigned)",
            "total_cases_resolved": "Total cases resolved by auditors"
        }

        return AuditorManagerAuditSamplePctDrilldownResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=audit_sample_records,
            message="Audit sample percentage records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Audit sample percentage drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return AuditorManagerAuditSamplePctDrilldownResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve audit sample percentage records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/audit-sample-pct-drilldown/download-excel",
    summary="Download Audit Sample Percentage Drilldown as Excel (Auditor Manager)",
    description="""
Download complete audit sample percentage drilldown data as an Excel file (Auditor Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **auditor_ids** (optional): List of auditor IDs to filter

**Returns:** Excel file (.xlsx) with all audit sample percentage records
""",
)

async def download_audit_sample_pct_drilldown_excel(
    request: AuditorManagerAuditSamplePctDrilldownRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"

        date_filter = build_date_filter(request.start_date, request.end_date)
        audit_period_create_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        auditor_filter = build_auditor_filter(request.auditor_ids)
        manager_filter = build_manager_filter(request.manager_ids)

        engine = connection_manager.get_engine()

        query = AUDIT_SAMPLE_PCT_QUERY.format(
            date_filter=date_filter,
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter
        )

        records = await engine.execute_query_async(query, limit=1)

        if records:
            total_cases_resolved = int(records[0].get("TOTAL_CASES_RESOLVED") or 0)
            open_audits = int(records[0].get("OPEN_AUDITS") or 0)
            closed_audits = int(records[0].get("CLOSED_AUDITS") or 0)
            pending_audits = int(records[0].get("PENDING_AUDITS") or 0)
        else:
            open_audits = closed_audits = pending_audits = total_cases_resolved = 0


        date_range = f"{format_date_mmddyyyy(request.start_date) if request.start_date else 'N/A'} to {format_date_mmddyyyy(request.end_date) if request.end_date else 'N/A'}"

        wb = Workbook()
        ws = wb.active
        ws.title = "Audit Sample Pct"

        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")

        headers = [
            "Date Range",
            "Open Audits",
            "Closed Audits",
            "Pending Audits",
            "Total Cases Resolved"
        ]

        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment

        ws.cell(row=2, column=1, value=date_range)
        ws.cell(row=2, column=2, value=open_audits)
        ws.cell(row=2, column=3, value=closed_audits)
        ws.cell(row=2, column=4, value=pending_audits)
        ws.cell(row=2, column=5, value=total_cases_resolved)

        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

        output = BytesIO()
        wb.save(output)
        output.seek(0)

        filename = f"audit_sample_pct_drilldown_auditor_manager_{user_id}_{start_date}_to_{end_date}.xlsx"

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for audit sample pct drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
