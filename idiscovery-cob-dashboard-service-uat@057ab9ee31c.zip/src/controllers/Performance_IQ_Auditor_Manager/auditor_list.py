import logging
from fastapi import APIRouter, HTTPException
from typing import Optional, List

from db import SnowflakeConnectionManager
from schema import AuditorListRequest, AssociateListResponse, AssociateItem
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
from utils import cache_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

AUDITOR_LIST_QUERY = f"""
WITH auditor AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYREPORTTO,
        PYACCESSGROUP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID IS NOT NULL 
        AND PYACCESSGROUP IN (
            'COB:FrontLineAuditor', 
            'CLMSCCU:Auditor',
            'CLMSCCU:ManagerAuditor',
            'COB:FrontLineManagerAuditor',
            'COB:OffFrontLineManagerAuditor'
        )
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
),
users_with_reportees AS (
    SELECT DISTINCT
        a1.USERID
    FROM auditor a1
    WHERE EXISTS (
        SELECT 1
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE a2
        WHERE a2.PYREPORTTO = a1.USERID
    )
)
SELECT DISTINCT
    auditor.USERID AS ASSOCIATE_ID,
    auditor.USERNAME AS ASSOCIATE_NAME
FROM auditor
WHERE 1=1
    AND auditor.USERID NOT IN (SELECT USERID FROM users_with_reportees)
{{manager_filter}}
ORDER BY auditor.USERNAME
"""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    if manager_ids and len(manager_ids) > 0:
        manager_list = "', '".join(manager_ids)
        return f"AND auditor.PYREPORTTO IN ('{manager_list}')"
    return ""


@router.post(
    "/auditor-list",
    response_model=AssociateListResponse,
    summary="Get List of Auditors",
    description="""
Retrieve list of auditors for filter dropdown with search capability.
Shows all auditors who logged in within the last 1 year.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **manager_ids** (optional): Filter auditors by manager's ID
- **search** (optional): Search term to filter auditors by ID or name
- **limit** (optional): Maximum number of results (default: 1000, max: 5000)

**Response Fields:**
- **associates**: List of auditors with ID, name, manager, and experience level
- **total_count**: Total number of auditors returned

**Data Source:** COB_AI_USER_PROFILE table (filtered to last 1 year of login activity)
**Caching:** Results cached for 6 hours (21,600s)
""",
)
async def get_auditor_list(request: AuditorListRequest) -> AssociateListResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    # Build cache key
    cache_key = cache_manager.build_key(
        "auditors:list",
        manager_ids=",".join(request.manager_ids or []),
        search=request.search or "",
        limit=request.limit
    )
    
    async def fetch_from_db():
        """Fetch auditors list from Snowflake."""
        try:
            engine = connection_manager.get_engine()
            manager_filter = build_manager_filter(request.manager_ids)
            
            query = AUDITOR_LIST_QUERY.format(
                manager_filter=manager_filter
            )
            records = await engine.execute_query_async(query, limit=request.limit)

            auditors = [
                {
                    "associate_id": r.get("ASSOCIATE_ID", ""),
                    "associate_name": r.get("ASSOCIATE_NAME"),
                    "manager_name": "",
                    "experience_level": ""
                }
                for r in records
                if r.get("ASSOCIATE_ID")
            ] if records else []

            return {
                "status": "success",
                "associates": auditors,
                "total_count": len(auditors),
                "message": "Auditors list retrieved successfully"
            }

        except Exception as e:
            logger.error(f"Auditors list query error: {type(e).__name__}: {str(e)}")
            return {
                "status": "error",
                "associates": [],
                "total_count": 0,
                "message": f"Failed to retrieve auditors list: {str(e)}"
            }
    
    # Get from cache or fetch from DB (6 hour TTL)
    result = await cache_manager.get_or_fetch(cache_key, fetch_from_db, ttl=METRIC_CACHE_TTL)
    
    # Convert dict to response model
    auditors = [AssociateItem(**a) for a in result["associates"]]
    return AssociateListResponse(
        status=result["status"],
        associates=auditors,
        total_count=result["total_count"],
        message=result["message"]
    )