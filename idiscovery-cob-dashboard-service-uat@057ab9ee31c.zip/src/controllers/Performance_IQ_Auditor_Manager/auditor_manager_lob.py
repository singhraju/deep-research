from fastapi import APIRouter, HTTPException
from typing import Optional, List
from schema.models import AuditorManagerLOBRequest, AuditorManagerLOBResponse
from utils import cache_manager
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

# Query to get LOBs based on manager-auditor relationships
AUDITOR_MANAGER_LOB_QUERY = f"""
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    {{manager_filter_invntry}}
    {{auditor_filter_invntry}}
UNION
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    {{manager_filter_audit}}
    {{auditor_filter_audit}}
"""


def build_date_filter_invntry(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for inventory table."""
    if start_date and end_date:
        return (
            f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' "
            f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_date_filter_audit(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for audit table."""
    if start_date and end_date:
        return (
            f"AND PXUPDATEDATETIME >= '{start_date}' "
            f"AND PXUPDATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PXUPDATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXUPDATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter_invntry(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table using REPORTTOMANAGERID."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_manager_filter_audit(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for audit table using AUDITOR_MGR_ID."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND AUDITOR_MGR_ID IN ('{manager_ids_str}')"
    return ""


def build_auditor_filter_invntry(auditor_ids: Optional[List[str]] = None) -> str:
    """Build auditor filter for inventory table."""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND PYRESOLVEDUSERID IN ('{auditor_ids_str}')"
    return ""


def build_auditor_filter_audit(auditor_ids: Optional[List[str]] = None) -> str:
    """Build auditor filter for audit table."""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND AUDITOR_ID IN ('{auditor_ids_str}')"
    return ""


@router.post(
    "/lobs",
    response_model=AuditorManagerLOBResponse,
    summary="Get List of LOBs for Auditor Manager View",
    description="""
Returns LOBs filtered by manager-auditor relationships for auditor manager-level view.

**Input Parameters:**
- **start_date** (optional): Start date in YYYY-MM-DD format to filter LOBs by date range
- **end_date** (optional): End date in YYYY-MM-DD format to filter LOBs by date range
- **manager_ids** (optional): List of manager IDs to filter LOBs for auditors under these managers
- **auditor_ids** (optional): List of auditor IDs to filter LOBs for specific auditors

**Response:**
- **lobs**: List of distinct LOBs available based on the filters applied

**Data Sources:**
- COB_AI_INVNTRY_PROFILE (work items)
- COB_AI_AUDIT_PROFILE (audit records)
- COB_AI_USER_PROFILE (manager-auditor relationships)

**Caching:** Results are cached for 24 hours based on the filter combination.
""",
)
async def get_auditor_manager_lobs(request: AuditorManagerLOBRequest) -> AuditorManagerLOBResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    # Build cache key based on all filter parameters
    cache_key = cache_manager.build_key(
        "auditor_manager_lobs",
        manager_ids=",".join(request.manager_ids) if request.manager_ids else "all",
        auditor_ids=",".join(request.auditor_ids) if request.auditor_ids else "all"
    )

    async def fetch_lobs():
        try:
            # Build filters for inventory table
            # date_filter_invntry = build_date_filter_invntry(request.start_date, request.end_date)
            manager_filter_invntry = build_manager_filter_invntry(request.manager_ids)
            auditor_filter_invntry = build_auditor_filter_invntry(request.auditor_ids)
            
            # Build filters for audit table
            # date_filter_audit = build_date_filter_audit(request.start_date, request.end_date)
            manager_filter_audit = build_manager_filter_audit(request.manager_ids)
            auditor_filter_audit = build_auditor_filter_audit(request.auditor_ids)

            # Format query with filters
            query = AUDITOR_MANAGER_LOB_QUERY.format(
                manager_filter_invntry=manager_filter_invntry,
                auditor_filter_invntry=auditor_filter_invntry,
                manager_filter_audit=manager_filter_audit,
                auditor_filter_audit=auditor_filter_audit
            )

            engine = connection_manager.get_engine()
            records = await engine.execute_query_async(query)
            
            # Collect LOBs and deduplicate
            lobs_set = set()
            for r in records:
                lob_value = r.get("LOB")
                if lob_value is not None:  # Include 'None' string but exclude actual None
                    lobs_set.add(lob_value)
            
            # Sort LOBs with 'None' at the end
            lobs = sorted([lob for lob in lobs_set if lob != "None"])
            if "None" in lobs_set:
                lobs.append("None")

            return {
                "status": "success",
                "lobs": lobs,
                "message": "Auditor Manager LOBs retrieved successfully",
                "service": "idiscovery-cob-dashboard-service"
            }
        except Exception as e:
            logger.error(f"Failed to retrieve auditor manager LOBs: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to retrieve auditor manager LOBs: {str(e)}")

    result = await cache_manager.get_or_fetch(cache_key, fetch_lobs, ttl=METRIC_CACHE_TTL)
    return AuditorManagerLOBResponse(**result)
