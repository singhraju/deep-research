import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from schema import (
    AuditorManagerCompletedAuditCountDrilldownRequest,
    CompletedAuditCountDrilldownPaginatedResponse,
    CompletedAuditCountRecord,
    PageResponse,
)
import math
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    build_audit_period_filter,
    COMPLETED_AUDIT_COUNT_QUERY,
)

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])
connection_manager = SnowflakeConnectionManager()

COMPLETED_AUDIT_COUNT_PAGINATED_QUERY = f"""
WITH audit_base AS (
    SELECT
        a.PYID,
        a.INTAKESOURCESYSTEM,
        a.INVNTRY_TYPE,
        a.LOB,
        a.PLATFORM,
        a.AUDITOR_ID,
        a.AUDITOR_NAME,
        a.AUDITOR_MGR_ID,
        a.AUDITCYCLETIME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXCOMMITDATETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.INTAKESOURCESYSTEM,
        a.INVNTRY_TYPE,
        a.LOB,
        a.PLATFORM,
        a.AUDITOR_ID,
        a.AUDITOR_NAME,
        a.AUDITOR_MGR_ID,
        a.AUDITCYCLETIME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS completion_status,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN UPPER(TRIM(a.PYSTATUSWORK)) = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN UPPER(TRIM(a.PYSTATUSWORK)) = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE UPPER(TRIM(a.PYSTATUSWORK)) IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      {{audit_period_filter}}
      {{lob_filter}}
      {{auditor_filter}}
      {{manager_filter}}
)
SELECT
    PYID AS work_item,
    COALESCE(INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(AUDITCYCLETIME::VARCHAR, '0') AS audit_cycle_time,
    CASE
        WHEN completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(completion_status, 'N/A')
    END AS audit_resolved_status,
    COALESCE(INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(completion_ts, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(AUDITOR_ID, 'N/A') AS auditor_id,
    COALESCE(AUDITOR_NAME, 'N/A') AS auditor_name,
    COALESCE(PLATFORM, 'N/A') AS platform_source_system,
    COALESCE(AUDIT_MONTH, 'N/A') AS audit_month,
    COALESCE(AUDIT_YEAR, 'N/A') AS audit_year
FROM filtered_completion
ORDER BY completion_ts DESC
LIMIT {{page_size}} OFFSET {{offset}}
"""

DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY = "completion_ts DESC"
DISPLAY_COMPLETED_AUDIT_RESOLVED_DATE_SQL = "DATE(completion_ts)"

DISPLAY_COMPLETED_AUDIT_RESOLVED_STATUS_SQL = """
CASE
    WHEN completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
    WHEN completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
    ELSE COALESCE(completion_status, 'N/A')
END
"""

SORTABLE_COMPLETED_AUDIT_COUNT_COLUMNS = {
    "work_item": "PYID",
    "worktype_category": "COALESCE(INTAKESOURCESYSTEM, 'N/A')",
    "audit_cycle_time": "COALESCE(AUDITCYCLETIME, 0)",
    "audit_resolved_status": DISPLAY_COMPLETED_AUDIT_RESOLVED_STATUS_SQL,
    "inventory_type": "COALESCE(INVNTRY_TYPE, 'N/A')",
    "lob": "COALESCE(LOB, 'N/A')",
    "audit_resolved_date": DISPLAY_COMPLETED_AUDIT_RESOLVED_DATE_SQL,
    "auditor_id": "COALESCE(AUDITOR_ID, 'N/A')",
    "auditor_name": "COALESCE(AUDITOR_NAME, 'N/A')",
    "platform_source_system": "COALESCE(PLATFORM, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_COMPLETED_AUDIT_COUNT_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid completed audit count sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid completed audit count sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "audit_resolved_date":
        tie_breakers.append("completion_ts DESC")
    if normalized_sort_by != "work_item":
        tie_breakers.append("PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_completed_audit_count_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )


def build_lob_filter(lob: Optional[List[str]] = None, column_name: str = "a.LOB") -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND ({column_name} IN ('{lob_values}') OR {column_name} IS NULL)"
    elif null_requested:
        return f"AND {column_name} IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND {column_name} IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "a.PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_auditor_filter(auditor_ids: Optional[List[str]] = None) -> str:
    """Build auditor filter for COB_AI_AUDIT_PROFILE table (uses AUDITOR_ID)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND AUDITOR_ID IN ('{auditor_ids_str}')"
    return ""
    
def build_auditor_filter_user(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses USERID field)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND USERID IN ('{auditor_ids_str}')"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses PYREPORTTO field)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""

def build_manager_filter_audit(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table (uses AUDITOR_MGR_ID field)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND AUDITOR_MGR_ID IN ('{manager_ids_str}')"
    return ""

@router.post(
    "/completed-audit-count-drilldown",
    response_model=CompletedAuditCountDrilldownPaginatedResponse,
    summary="Get Completed Audit Count Drilldown (Auditor Manager)",
    description="""
Retrieve paginated list of completed audit counts for detailed table display (Auditor Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **auditor_ids** (optional): List of auditor IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item**: Work Item ID
- **worktype_category**: Worktype Category (e.g., Newborn, Compass, Claims Request, HEW)
- **audit_cycle_time**: Audit Cycle Time (e.g., 00:20:00)
- **audit_resolved_status**: Audit Resolved Status (e.g., Resolved)
- **inventory_type**: Inventory Type (e.g., GB, CB)
- **lob**: Line of Business (e.g., Medicaid, Medicare, Commercial)
- **audit_resolved_date**: Audit Resolved Date (MM/DD/YYYY format)
- **auditor_id**: Auditor ID (unique identifier)
- **auditor_name**: Auditor Name (e.g., Susan Jones)
- **platform_source_system**: Platform - Source System (e.g., Sample Name)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Source:** COB_AI_AUDIT_PROFILE, COB_AI_USER_PROFILE, COB_AI_INVNTRY_PROFILE for cycle time calculation
""",
)
async def get_completed_audit_count_drilldown(
    request: AuditorManagerCompletedAuditCountDrilldownRequest
) -> CompletedAuditCountDrilldownPaginatedResponse:
    
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Build filters
        lob_filter = build_lob_filter(request.lob, "LOB")
        date_filter = build_date_filter(request.start_date, request.end_date, "PYRESOLVEDTIMESTAMP")
        auditor_filter = build_auditor_filter(request.auditor_ids)
        manager_filter = build_manager_filter_audit(request.manager_ids)
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="completion_ts",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        
        engine = connection_manager.get_engine()
        
        # Get total count
        count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter
        )
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = count_result[0].get("COMPLETED_AUDIT_COUNT", 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Get paginated data
        data_query = COMPLETED_AUDIT_COUNT_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter,
            page_size=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_completed_audit_count_query(data_query, request.sort_by, request.sort_direction)
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        completed_audit_records = [
            CompletedAuditCountRecord(
                work_item=r.get("WORK_ITEM", "N/A"),
                worktype_category=r.get("WORKTYPE_CATEGORY", "N/A"),
                audit_cycle_time=format_cycle_time(r.get("AUDIT_CYCLE_TIME")) if r.get("AUDIT_CYCLE_TIME") else "00:00:00",
                audit_resolved_status=r.get("AUDIT_RESOLVED_STATUS", "N/A"),
                inventory_type=r.get("INVENTORY_TYPE", "N/A"),
                lob=r.get("LOB", "N/A"),
                audit_resolved_date=r.get("AUDIT_RESOLVED_DATE", "N/A"),
                auditor_id=r.get("AUDITOR_ID", "N/A"),
                auditor_name=r.get("AUDITOR_NAME", "N/A"),
                platform_source_system=r.get("PLATFORM_SOURCE_SYSTEM", "N/A"),
                audit_month=r.get("AUDIT_MONTH", "N/A"),
                audit_year=r.get("AUDIT_YEAR", "N/A")
            )
            for r in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the audit work item (PYID starting with 'AUD')",
            "worktype_category": "Category of work type being audited (INTAKESOURCESYSTEM)",
            "audit_cycle_time": "Cycle time from COB_AI_INVNTRY_PROFILE.CYCLE_TIME in hh:mm:ss format",
            "audit_resolved_status": "Status of the audit resolution (PYSTATUSWORK)",
            "inventory_type": "Type of inventory classification (INVNTRY_TYPE)",
            "lob": "Line of Business classification (Medicaid, Medicare, Commercial)",
            "audit_resolved_date": "Date when the audit was resolved (PYRESOLVEDTIMESTAMP)",
            "auditor_id": "Unique identifier of the auditor (AUDIT_SUBJECT_ID)",
            "auditor_name": "Name of the auditor who completed the audit (USERNAME from COB_AI_USER_PROFILE)",
            "platform_source_system": "Platform or source system where the audit was processed (PLATFORM)"
        }

        return CompletedAuditCountDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=completed_audit_records,
            message="Completed audit count records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated completed audit count drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return CompletedAuditCountDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve completed audit count records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


def excel_cell_value(value):
    if value is None:
        return ""

    if isinstance(value, (int, float)):
        return value

    return value

@router.post(
    "/completed-audit-count-drilldown/download-excel",
    summary="Download Completed Audit Count Drilldown as Excel (Auditor Manager)",
    description="""
Download complete audit count drilldown data as an Excel file (Auditor Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **auditor_ids** (optional): List of auditor IDs to filter

**Returns:** Excel file (.xlsx) with all completed audit count records
""",
)
async def download_completed_audit_count_drilldown_excel(
    request: AuditorManagerCompletedAuditCountDrilldownRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        auditor_ids = request.auditor_ids
        
        lob_filter = build_lob_filter(lob, "LOB")
        auditor_filter = build_auditor_filter(auditor_ids)
        manager_filter = build_manager_filter_audit(manager_ids)
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="completion_ts",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )

        engine = connection_manager.get_engine()

        download_query = COMPLETED_AUDIT_COUNT_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter,
            page_size=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Completed Audit Count"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Worktype Category",
            "Audit Cycle Time",
            "Audit Status",
            "Inventory Type",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Auditor Name",
            "Platform - Source System",
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows (empty for now - N/A implementation)
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=excel_cell_value(row.get("WORK_ITEM", "")))
            ws.cell(row=row_num, column=2, value=excel_cell_value(row.get("WORKTYPE_CATEGORY", "")))
            ws.cell(row=row_num, column=3, value=format_cycle_time(row.get("AUDIT_CYCLE_TIME")) if row.get("AUDIT_CYCLE_TIME") else "00:00:00")
            ws.cell(row=row_num, column=4, value=excel_cell_value(row.get("AUDIT_RESOLVED_STATUS", "")))
            ws.cell(row=row_num, column=5, value=excel_cell_value(row.get("INVENTORY_TYPE", "")))
            ws.cell(row=row_num, column=6, value=excel_cell_value(row.get("LOB", "")))
            ws.cell(row=row_num, column=7, value=excel_cell_value(row.get("AUDIT_RESOLVED_DATE", "")))
            ws.cell(row=row_num, column=8, value=excel_cell_value(row.get("AUDIT_MONTH", "")))
            ws.cell(row=row_num, column=9, value=excel_cell_value(
                int(row["AUDIT_YEAR"]) if row.get("AUDIT_YEAR") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=10, value=excel_cell_value(row.get("AUDITOR_NAME", "")))
            ws.cell(row=row_num, column=11, value=excel_cell_value(row.get("PLATFORM_SOURCE_SYSTEM", "")))

        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"completed_audit_count_drilldown_auditor_manager_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for completed audit count drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
