import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import AuditorManagerBaseRequest, AuditorManagerFuseTimeResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

FUSE_TIME_QUERY = f"""
SELECT 
    -- OHI Productive Time (from PRODUCTIVETIME column)
    -- Convert HH:MM:SS string format to hours
    ROUND(SUM(
        CASE 
            WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END
    ) / 3600.0, 2) AS OHI_PRODUCTIVE_TIME_HOURS,
    
    -- Fuse Non-Productive Time (from NON_PRDCTV_DURATION column)
    ROUND(SUM(COALESCE(NON_PRDCTV_DURATION, 0)) / 3600.0, 2) AS FUSE_NON_PRODUCTIVE_TIME_HOURS

FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE TOTALSYSTEMTIME IS NOT NULL
{{date_filter}}
{{lob_filter}}
{{manager_filter}}
{{associate_filter}}
"""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str]) -> str:
    """Build date filter for COB_AI_USER_PROFILE table (uses PXUPDATEDATETIME)"""
    if start_date and end_date:
        return (
            f"AND PXUPDATEDATETIME >= '{start_date}' "
            f"AND PXUPDATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PXUPDATEDATETIME::DATE >= '{start_date}'"
    elif end_date:
        return f"AND PXUPDATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses PYREPORTTO)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses USERID)"""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND USERID IN ('{frontline_associate_ids_str}')"
    return ""


@router.post(
    "/fuse-time",
    response_model=AuditorManagerFuseTimeResponse,
    summary="Get Auditor Manager Fuse Time Metrics",
    description="""
Retrieve fuse time metrics for auditor manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Response Fields:**
- **ohi_productive_time**: OHI productive time in hours (2 decimal places)
- **fuse_non_productive_time**: Fuse non-productive time in hours (2 decimal places)

**Data Sources:** 
- COB_AI_USER_PROFILE (fuse time metrics)
""",
)
async def get_auditor_manager_fuse_time(request: AuditorManagerBaseRequest) -> AuditorManagerFuseTimeResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter = build_associate_filter(request.frontline_associate_ids)
        
        engine = connection_manager.get_engine()

        # Build query
        fuse_time_query = FUSE_TIME_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )

        # Execute query
        records = engine.execute_query(fuse_time_query, limit=1)

        # Extract metrics
        if records:
            ohi_productive_time = float(records[0].get("OHI_PRODUCTIVE_TIME_HOURS", 0.0))
            fuse_non_productive_time = float(records[0].get("FUSE_NON_PRODUCTIVE_TIME_HOURS", 0.0))
        else:
            ohi_productive_time = 0.0
            fuse_non_productive_time = 0.0

        tooltips = {
            "ohi_productive_time": "OHI productive time in hours",
            "fuse_non_productive_time": "Fuse non-productive time in hours"
        }

        return AuditorManagerFuseTimeResponse(
            status="success",
            ohi_productive_time=ohi_productive_time,
            fuse_non_productive_time=fuse_non_productive_time,
            message="Auditor Manager fuse time metrics retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Auditor Manager fuse time query error: {type(e).__name__}: {str(e)}")
        return AuditorManagerFuseTimeResponse(
            status="error",
            ohi_productive_time=0.0,
            fuse_non_productive_time=0.0,
            message=f"Failed to retrieve Auditor Manager fuse time metrics: {str(e)}"
        )
