import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
import config
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import (
    AuditorManagerFuseTimeDrilldownRequest,
    FuseTimeDrilldownPaginatedResponse,
    FuseTimeRecord,
    PageResponse,
)
import math

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

FUSE_TIME_PAGINATED_QUERY = f"""
WITH associate_hierarchy AS (
    SELECT DISTINCT
        AUDITOR_ID,
        DATE(PXCOMMITDATETIME) AS work_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PXCOMMITDATETIME >= '{{start_date}}' 
      AND PXCOMMITDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND AUDITOR_ID IN ({{auditor_ids}})
      AND AUDITOR_MGR_ID IN ({{manager_ids}})
)
SELECT 
    u.USERNAME,
    u.USERID,
    u.LOGINDATE,
    u.FIRSTLOGINTIME,
    u.LASTLOGOUTTIME,
    u.TOTALSYSTEMTIME,
    u.FUSE_NON_PRODUCTIVE_TIME,
    u.PRODUCTIVETIME,
    COALESCE(u.TOTALSYSTEMTIME, 0) - 
    (COALESCE(
        CASE 
            WHEN u.PRODUCTIVETIME IS NOT NULL AND u.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END, 0
    ) + 
    COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0)) AS OTHER_TIME
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u 
INNER JOIN associate_hierarchy ah
    ON u.USERID = ah.AUDITOR_ID
    AND u.LOGINDATE = ah.work_date
ORDER BY u.LOGINDATE DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_FUSE_TIME_ORDER_BY = "u.LOGINDATE DESC"

PRODUCTIVE_TIME_SECONDS_SQL = "CASE WHEN u.PRODUCTIVETIME IS NOT NULL AND u.PRODUCTIVETIME != '' THEN (SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::INTEGER) ELSE 0 END"

OTHER_TIME_SQL = f"COALESCE(u.TOTALSYSTEMTIME, 0) - (COALESCE({PRODUCTIVE_TIME_SECONDS_SQL}, 0) + COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0))"

SORTABLE_FUSE_TIME_COLUMNS = {
    "user_id": "COALESCE(u.USERNAME, 'N/A')",
    "date": "u.LOGINDATE",
    "log_in": "u.FIRSTLOGINTIME",
    "log_out": "u.LASTLOGOUTTIME",
    "total_fuse_time": "COALESCE(u.TOTALSYSTEMTIME, 0)",
    "productive_time": PRODUCTIVE_TIME_SECONDS_SQL,
    "non_productive_time": "COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0)",
    "other_time": OTHER_TIME_SQL,
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_FUSE_TIME_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_FUSE_TIME_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid auditor manager fuse time sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_FUSE_TIME_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid auditor manager fuse time sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_FUSE_TIME_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "date":
        tie_breakers.append("u.LOGINDATE DESC")
    if normalized_sort_by != "user_id":
        tie_breakers.append("u.USERNAME ASC")
    tie_breakers.append("u.USERID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_fuse_time_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_FUSE_TIME_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )

FUSE_TIME_COUNT_QUERY = f"""
WITH associate_hierarchy AS (
    SELECT DISTINCT
        AUDITOR_ID,
        DATE(PXCOMMITDATETIME) AS work_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PXCOMMITDATETIME >= '{{start_date}}' 
      AND PXCOMMITDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND AUDITOR_ID IN ({{auditor_ids}})
      AND AUDITOR_MGR_ID IN ({{manager_ids}})
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u 
INNER JOIN associate_hierarchy ah
    ON u.USERID = ah.AUDITOR_ID
    AND u.LOGINDATE = ah.work_date
"""

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str)[:10], "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def format_time_hhmm(time_str: str) -> str:
    """Format timestamp to HH:MM AM/PM ET format"""
    if not time_str:
        return ""
    try:
        # Parse the full timestamp
        time_obj = datetime.strptime(str(time_str)[:19], "%Y-%m-%d %H:%M:%S")
        # Format to 12-hour time with AM/PM and add ET
        return time_obj.strftime("%I:%M %p ET")
    except:
        return str(time_str)

def format_duration(duration_str: str) -> str:
    """Format duration to HH:MM:SS format"""
    if not duration_str:
        return "00:00:00"
    try:
        if ':' in str(duration_str):
            parts = str(duration_str).split(':')
            hours = int(parts[0])
            minutes = int(parts[1])
            seconds = int(float(parts[2])) if len(parts) > 2 else 0
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        total_seconds = int(float(duration_str))
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    except:
        return str(duration_str)

def build_manager_filter_invntry(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_associate_filter_invntry(auditor_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND PYRESOLVEDUSERID IN ('{auditor_ids_str}')"
    return ""

@router.post(
    "/fuse-time-drilldown",
    response_model=FuseTimeDrilldownPaginatedResponse,
    summary="Get Fuse Time Drilldown (Auditor Manager)",
    description="""
Retrieve paginated list of fuse time records for Auditor Manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **auditor_ids** (optional): List of auditor IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **user_id**: User ID
- **date**: Login date (MM/DD/YYYY format)
- **log_in**: First login time
- **log_out**: Last logout time
- **total_fuse_time**: Total system time formatted as 'X hrs Y mins'
- **non_productive_time**: Fuse non-productive time formatted as 'X hrs Y mins'
- **other_time**: Other time calculated as Total - OHI Productive Time - Non-Productive Time

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (associate hierarchy for manager filtering)
- COB_AI_USER_PROFILE (fuse time and user information)
""",
)

async def get_fuse_time_drilldown(
    request: AuditorManagerFuseTimeDrilldownRequest
) -> FuseTimeDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        start_date = request.start_date
        end_date = request.end_date
        manager_ids = request.manager_ids
        auditor_ids = request.auditor_ids

        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        manager_filter_invntry = build_manager_filter_invntry(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(auditor_ids)
        engine = connection_manager.get_engine()
        
        count_query = FUSE_TIME_COUNT_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            auditor_ids="'" + "', '".join(request.auditor_ids) + "'",
            manager_ids="'" + "', '".join(request.manager_ids) + "'"
        )

        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = FUSE_TIME_PAGINATED_QUERY.format(
            start_date=start_date,
            end_date=end_date,
            auditor_ids="'" + "', '".join(auditor_ids) + "'",
            manager_ids="'" + "', '".join(manager_ids) + "'",
            limit=page_limit,
            offset=offset
        )
        
        data_query = apply_custom_sort_to_fuse_time_query(data_query, request.sort_by, request.sort_direction)
        records = await engine.execute_query_async(data_query, limit=page_limit)

        fuse_time_records = [
            FuseTimeRecord(
                user_id=record.get("USERNAME") or "N/A",
                date=format_date_mmddyyyy(record.get("LOGINDATE")),
                log_in=format_time_hhmm(record.get("FIRSTLOGINTIME")) if record.get("FIRSTLOGINTIME") else None,
                log_out=format_time_hhmm(record.get("LASTLOGOUTTIME")) if record.get("LASTLOGOUTTIME") else None,
                total_fuse_time=format_duration(record.get("TOTALSYSTEMTIME")),
                productive_time=format_duration(record.get("PRODUCTIVETIME")),
                non_productive_time=format_duration(record.get("FUSE_NON_PRODUCTIVE_TIME")),
                other_time=format_duration(record.get("OTHER_TIME"))
            )
            for record in records
        ] if records else []

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "user_id": "Unique identifier for the user",
            "date": "Date when the user logged in",
            "log_in": "Time of first login for the day",
            "log_out": "Time of last logout for the day",
            "total_fuse_time": "Total time spent in the Fuse system",
            "productive_time": "Time spent on productive activities",
            "non_productive_time": "Time spent on non-productive activities in Fuse",
            "other_time": "Other time calculated as Total Fuse Time - (OHI Productive Time + Non-Productive Time)"
        }

        return FuseTimeDrilldownPaginatedResponse(
            status="success",
            screen_id="fuse_time_auditor_manager",
            user_id=request.user_id,
            page=page_response,
            records=fuse_time_records,
            message="Fuse time records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated fuse time drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return FuseTimeDrilldownPaginatedResponse(
            status="error",
            screen_id="fuse_time_auditor_manager",
            user_id=request.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve fuse time records: {str(e)}"
        )


@router.post(
    "/fuse-time-drilldown/download-excel",
    summary="Download Fuse Time Drilldown as Excel (Auditor Manager)",
    description="""
Download complete fuse time drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **auditor_ids** (optional): List of auditor IDs to filter

**Returns:** Excel file (.xlsx) with all fuse time records
""",
)
async def download_fuse_time_drilldown_excel(
    request: AuditorManagerFuseTimeDrilldownRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        auditor_ids = request.auditor_ids
        
        manager_filter_invntry = build_manager_filter_invntry(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(auditor_ids)
        
        engine = connection_manager.get_engine()
        
        # Query with high limit for download (no pagination needed)
        download_query = FUSE_TIME_PAGINATED_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            auditor_ids="'" + "', '".join(request.auditor_ids) + "'",
            manager_ids="'" + "', '".join(request.manager_ids) + "'",
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Fuse Time"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Auditor Name",
            "Date",
            "Log In",
            "Log Out",
            "Total Fuse Time",
            "Productive Time",
            "Non-Productive Time",
            "Unclassified"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("USERNAME", "")))
            ws.cell(row=row_num, column=2, value=format_date_mmddyyyy(str(row.get("LOGINDATE", ""))) if row.get("LOGINDATE") else "")
            ws.cell(row=row_num, column=3, value=format_time_hhmm(str(row.get("FIRSTLOGINTIME", ""))) if row.get("FIRSTLOGINTIME") else "")
            ws.cell(row=row_num, column=4, value=format_time_hhmm(str(row.get("LASTLOGOUTTIME", ""))) if row.get("LASTLOGOUTTIME") else "")
            ws.cell(row=row_num, column=5, value=format_duration(row.get("TOTALSYSTEMTIME", 0)))
            ws.cell(row=row_num, column=6, value=format_duration(row.get("PRODUCTIVETIME", 0)))
            ws.cell(row=row_num, column=7, value=format_duration(row.get("FUSE_NON_PRODUCTIVE_TIME", 0)))
            ws.cell(row=row_num, column=8, value=format_duration(row.get("OTHER_TIME", 0)))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"fuse_time_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for fuse time drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
