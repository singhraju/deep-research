import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import AuditorManagerBaseRequest, AuditorManagerHeaderKPIsResponse, AuditPeriod
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

# Complete Audit Count - uses AUDITOR_ID and AUDITOR_MGR_ID fields
COMPLETED_AUDIT_COUNT_QUERY = f"""
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXCOMMITDATETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
    {{audit_period_filter}}
    {{lob_filter}}
    {{auditor_filter}}
    {{manager_filter}}
)
SELECT
    COUNT(DISTINCT PYID) AS COMPLETED_AUDIT_COUNT
FROM filtered_completion
"""

# Audit Sample Percentage - uses AUDITOR_ID field
AUDIT_SAMPLE_PCT_QUERY = f"""
WITH invntry_base AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        PYSTATUSWORK,
        LOB,
        INTAKESOURCESYSTEM
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
deduped_invntry AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID
    FROM invntry_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      AND INTAKESOURCESYSTEM NOT IN ('ASPEN', 'eCOB Intake')
      AND INTAKESOURCESYSTEM NOT LIKE '%-DUP'
      AND INTAKESOURCESYSTEM NOT LIKE '%Adhoc%'
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXCOMMITDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        PYSTATUSWORK,
        PXCOMMITDATETIME,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        DATE(PXCREATEDATETIME) AS audit_date
    FROM audit_base
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      {{audit_period_filter}}
      {{lob_filter}}
      {{auditor_filter}}
      {{manager_filter}}
),
audited_cases AS (
    SELECT
        i.PYID AS inventory_case,
        a.PYID AS audit_case,
        a.AUDITOR_ID,
        a.PYSTATUSWORK AS audit_status
    FROM deduped_invntry i
    LEFT JOIN deduped_audit a
        ON i.PYID = a.CASE_TO_AUDIT
),
audit_summary AS (
    SELECT
        COUNT(DISTINCT inventory_case) AS total_cases_resolved,
        COUNT(DISTINCT CASE WHEN audit_case IS NOT NULL THEN inventory_case END) AS total_audited,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN inventory_case END) AS open_audits,
        COUNT(DISTINCT CASE WHEN audit_status = 'Resolved-Completed' THEN inventory_case END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN audit_status IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN inventory_case END) AS pending_audits
    FROM audited_cases
)
SELECT
    total_cases_resolved AS TOTAL_CASES_RESOLVED,
    open_audits AS OPEN_AUDITS,
    closed_audits AS CLOSED_AUDITS,
    pending_audits AS PENDING_AUDITS,
    total_audited AS TOTAL_AUDITS,
    total_cases_resolved AS TOTAL_WORK_ITEMS_COMPLETED,
    total_audited AS TOTAL_ITEMS_AUDITED,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS AUDIT_SAMPLE_PCT,
    ROUND((total_audited * 100.0 / NULLIF(total_cases_resolved, 0)), 2) AS OVERALL_AUDIT_SAMPLE_PCT
FROM audit_summary
"""

# Work Items Completed - uses REPORTTOMANAGERID field
WORK_ITEMS_COMPLETED_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        REPORTTOMANAGERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        REPORTTOMANAGERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{auditor_filter_resolved}}
      {{manager_filter_invntry}}
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM filtered_inventory
"""

# Audit Cycle Time - uses AUDITOR_ID and AUDITOR_MGR_ID fields
AUDIT_CYCLE_TIME_QUERY = f"""
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXCOMMITDATETIME,
        a.AUDITCYCLETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.AUDITOR_MGR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      {{audit_period_filter}}
      {{lob_filter}}
      {{auditor_filter}}
      {{manager_filter}}
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts,
        MIN(a.PXCOMMITDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
        ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.AUDITOR_ID,
        c.AUDITOR_MGR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
        ON a.PYID = f.PYID
       AND a.PXCOMMITDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts
)
SELECT
    COUNT(*) AS TOTAL_RESOLVED_AUDITS,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM cycle_time_at_first_positive_ts
"""

# ATA Audit Score - uses AUDIT_SUBJECT_ID and AUDIT_SUBJECT_MGR_ID fields
ATA_AUDIT_SCORE_QUERY = f"""
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{audit_subject_filter}}
      {{audit_subject_manager_filter}}
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)

SELECT
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
"""


ATA_REBUTTALS_QUERY = f"""
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        {{audit_period_filter}}
        {{lob_filter}}
        {{audit_subject_filter}}
        {{audit_subject_manager_filter}}
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS ATA_REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_ata_cases_with_rebuttals
FROM ata_filtered af
INNER JOIN audit_activity_deduped rd
    ON af.PYID = rd.CASEID
    AND rd.rn = 1
"""


ATA_REBUTTAL_PCT_QUERY = f"""
WITH ata_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'ATA%'
        AND ISATACASE = 'Y'
        AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
        AND PXCREATEDATETIME IS NOT NULL
        {{audit_period_filter}}
        {{lob_filter}}
        {{audit_subject_filter}}
        {{audit_subject_manager_filter}}
),
ata_filtered AS (
    SELECT
        PYID,
        AUDIT_SUBJECT_ID
    FROM ata_deduped
    WHERE rn = 1
),
ata_audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'ATA%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS total_rebuttals,

    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS rebuttals_overturned,

    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS rebuttals_upheld,

    COALESCE(
        ROUND(
            (COUNT(DISTINCT CASE
                WHEN act.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
            END) * 100.0)
            / NULLIF(COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY), 0),
            2
        ),
        0
    ) AS rebuttal_overturn_pct
FROM ata_filtered af
INNER JOIN ata_audit_activity_deduped act
    ON af.PYID = act.CASEID
    AND act.rn = 1
"""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def format_cycle_time(minutes: float) -> str:
    total_minutes = int(minutes)
    seconds = int((minutes - total_minutes) * 60)
    return f"{total_minutes} mins. {seconds} secs."

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table (uses AUDIT_SUBJECT_ID)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND AUDIT_SUBJECT_ID IN (SELECT USERID FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE WHERE PYREPORTTO IN ('{manager_ids_str}'))"
    return ""


def build_associate_filter(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table (uses AUDIT_SUBJECT_ID)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{auditor_ids_str}')"
    return ""


def build_auditor_filter(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table (uses AUDITOR_ID field)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND AUDITOR_ID IN ('{auditor_ids_str}')"
    return ""


def build_auditor_filter_resolved(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_INVNTRY_PROFILE table (uses PYRESOLVEDUSERID field)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND PYRESOLVEDUSERID IN ('{auditor_ids_str}')"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses PYREPORTTO field)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_auditor_filter_user(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses USERID field)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND USERID IN ('{auditor_ids_str}')"
    return ""


def build_manager_filter_audit(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table (uses AUDITOR_MGR_ID field)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND AUDITOR_MGR_ID IN ('{manager_ids_str}')"
    return ""


def build_manager_filter_invntry(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_INVNTRY_PROFILE table (uses REPORTTOMANAGERID field)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_audit_subject_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table (uses AUDIT_SUBJECT_MGR_ID field)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND AUDIT_SUBJECT_MGR_ID IN ('{manager_ids_str}')"
    return ""


def build_date_filter_created(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for PXCREATEDATETIME"""
    if start_date and end_date:
        return f"AND PXCREATEDATETIME >= '{start_date}' AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND PXCREATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_auditor_ids_list(auditor_ids: Optional[List[str]] = None) -> str:
    """Build comma-separated list of auditor IDs for IN clause"""
    if auditor_ids and len(auditor_ids) > 0:
        return "', '".join(auditor_ids)
    return ""


def build_date_filter_between(start_date: Optional[str], end_date: Optional[str]) -> str:
    """Build BETWEEN date filter for PYRESOLVEDTIMESTAMP"""
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP::DATE BETWEEN '{start_date}' AND '{end_date}'"
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP::DATE >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP::DATE <= '{end_date}'"
    return ""


def build_invntry_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_INVNTRY_PROFILE table (uses PYRESOLVEDUSERID)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYRESOLVEDUSERID IN (SELECT USERID FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE WHERE PYREPORTTO IN ('{manager_ids_str}'))"
    return ""


def build_invntry_associate_filter(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_INVNTRY_PROFILE table (uses PYRESOLVEDUSERID)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND PYRESOLVEDUSERID IN ('{auditor_ids_str}')"
    return ""


def build_audit_sample_resolved_start_filter(start_date: Optional[str] = None) -> str:
    """Filter for resolved items after start date in audit sample query"""
    if start_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'"
    return ""


def build_audit_sample_resolved_end_filter(end_date: Optional[str] = None) -> str:
    """Filter for resolved items before end date in audit sample query"""
    if end_date:
        return f"AND PYRESOLVEDTIMESTAMP < '{end_date}'"
    return ""


def build_audit_sample_associate_filter(auditor_ids: Optional[List[str]] = None) -> str:
    """Filter for specific auditors in resolved items (uses PYRESOLVEDUSERID)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND PYRESOLVEDUSERID IN ('{auditor_ids_str}')"
    return ""


def build_audit_sample_audit_start_filter(start_date: Optional[str] = None) -> str:
    """Filter for audit items after start date in audit sample query"""
    if start_date:
        return f"AND PXUPDATEDATETIME >= '{start_date}'"
    return ""


def build_audit_sample_audit_end_filter(end_date: Optional[str] = None) -> str:
    """Filter for audit items before end date in audit sample query"""
    if end_date:
        return f"AND PXUPDATEDATETIME < '{end_date}'"
    return ""


def build_audit_sample_audit_associate_filter(auditor_ids: Optional[List[str]] = None) -> str:
    """Filter for specific auditors in audit items (uses AUDIT_SUBJECT_ID)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{auditor_ids_str}')"
    return ""

def get_audit_score_bubble(audit_score_value: float) -> str:
    """Determine audit score status bubble based on value.
    
    Rating Scale:
    - Exceptional: 100%
    - Exceeds: 99% - 99.99%
    - Meets: 98% - 98.99%
    - Approaching: 95% - 97.99%
    - Poor: Below 95%
    """
    if not audit_score_value or audit_score_value == 0.0:
        return "N/A"
    
    if audit_score_value >= 100:
        return "Exceptional"
    elif audit_score_value >= 99:
        return "Exceeds"
    elif audit_score_value >= 98:
        return "Meets"
    elif audit_score_value >= 95:
        return "Approaching"
    else:
        return "Poor"


def build_audit_period_filter(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    audit_periods: Optional[List[AuditPeriod]] = None,
    timestamp_column: str = "completion_ts",
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append((month_value, year_value))

    if valid_periods:
        period_conditions = [
            f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
            for month, year in valid_periods
        ]
        return "AND (" + " OR ".join(period_conditions) + ")"

    if start_date and end_date:
        return (
            f"AND {timestamp_column} >= '{start_date}' "
            f"AND {timestamp_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {timestamp_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {timestamp_column} < DATEADD(day, 1, '{end_date}'::DATE)"

    return ""


def execute_query(engine, query: str, limit: int = 1):
    return engine.execute_query(query, limit=limit)



@router.post(
    "/header-kpis",
    response_model=AuditorManagerHeaderKPIsResponse,
    summary="Get Auditor Manager Header KPIs",
    description="""
Retrieve summary KPIs for auditor manager dashboard header section.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **auditor_ids** (optional): List of auditor IDs to filter

**Response Fields:**
- **complete_audit_count**: Total completed audits (PYID LIKE 'AUD%')
- **audit_sample_percent**: Audit sample percentage
- **work_items_completed**: Total work items completed
- **audit_cycle_time**: Average audit cycle time (hardcoded N/A)
- **ata_audit_score**: ATA audit score (hardcoded N/A)
- **ata_rebuttals**: ATA rebuttals count (hardcoded N/A)

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (audits)
- COB_AI_INVNTRY_PROFILE (work items)
- COB_AI_USER_PROFILE (user relationships)
""",
)
async def get_auditor_manager_header_kpis(request: AuditorManagerBaseRequest) -> AuditorManagerHeaderKPIsResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        auditor_filter = build_auditor_filter(request.auditor_ids)
        auditor_filter_resolved = build_auditor_filter_resolved(request.auditor_ids)
        auditor_ids_list = build_auditor_ids_list(request.auditor_ids)
        date_filter_between = build_date_filter_between(request.start_date, request.end_date)
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        auditor_filter_user = build_auditor_filter_user(request.auditor_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        manager_filter = build_manager_filter_audit(request.manager_ids)
        manager_filter_invntry = build_manager_filter_invntry(request.manager_ids)
        audit_subject_filter = build_associate_filter(request.auditor_ids)
        audit_subject_manager_filter = build_audit_subject_manager_filter(request.manager_ids)
        date_filter_created = build_date_filter_created(request.start_date, request.end_date)
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="completion_ts",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        audit_period_create_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        
        # For audit sample query date placeholders
        start_date_str = f"'{request.start_date}'" if request.start_date else "'1900-01-01'"
        end_date_str = f"'{request.end_date}'" if request.end_date else "'2099-12-31'"
        
        engine = connection_manager.get_engine()

        # Build queries
        audit_count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter
        )
        
        # Build date filter for audit section (uses PXCREATEDATETIME)
        date_filter_ata = build_date_filter(request.start_date, request.end_date, date_column="PXCREATEDATETIME")
        
        audit_sample_query = AUDIT_SAMPLE_PCT_QUERY.format(
            date_filter=date_filter,
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter
        )
        
        work_items_query = WORK_ITEMS_COMPLETED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            auditor_filter_resolved=auditor_filter_resolved,
            manager_filter_invntry=manager_filter_invntry
        )
        
        audit_cycle_time_query = AUDIT_CYCLE_TIME_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter
        )

        ata_audit_score_query = ATA_AUDIT_SCORE_QUERY.format(
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter
        )
        #print(ata_audit_score_query)
        ata_rebuttals_query = ATA_REBUTTALS_QUERY.format(
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter
        )
        #print(ata_rebuttals_query)

        ata_rebuttal_pct_query = ATA_REBUTTAL_PCT_QUERY.format(
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter
        )
        #print(ata_rebuttal_pct_query)
        
        # Execute queries in parallel using asyncio.gather
        (audit_count_records, audit_sample_records, work_items_records,
         audit_cycle_time_records, ata_audit_score_records, ata_rebuttals_records,
         ata_rebuttal_pct_records) = await asyncio.gather(
            engine.execute_query_async(audit_count_query, limit=1),
            engine.execute_query_async(audit_sample_query, limit=1),
            engine.execute_query_async(work_items_query, limit=1),
            engine.execute_query_async(audit_cycle_time_query, limit=1),
            engine.execute_query_async(ata_audit_score_query, limit=1),
            engine.execute_query_async(ata_rebuttals_query, limit=1),
            engine.execute_query_async(ata_rebuttal_pct_query, limit=1)
        )

        # Extract complete audit count
        complete_audit_count_value = int(audit_count_records[0].get("COMPLETED_AUDIT_COUNT", 0)) if audit_count_records else 0
        complete_audit_count = str(complete_audit_count_value)

        # Calculate audit sample percentage
        if audit_sample_records and audit_sample_records[0].get("OVERALL_AUDIT_SAMPLE_PCT") is not None:
            audit_sample_pct_value = float(audit_sample_records[0].get("OVERALL_AUDIT_SAMPLE_PCT", 0))
            audit_sample_percent = f"{audit_sample_pct_value}%"
            total_audited = int(audit_sample_records[0].get("TOTAL_ITEMS_AUDITED", 0))
            total_work = int(audit_sample_records[0].get("TOTAL_WORK_ITEMS_COMPLETED", 0))
            audit_sample_count = f"{total_audited:,} of {total_work:,}"
        else:
            audit_sample_percent = "0.0%"
            audit_sample_count = "0 of 0"

        # Extract work items completed
        work_items_completed_value = int(work_items_records[0].get("TOTAL_COUNT", 0)) if work_items_records else 0
        work_items_completed = str(work_items_completed_value)
        
        # Extract audit cycle time
        if audit_cycle_time_records and audit_cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME_MINUTES") is not None:
            avg_cycle_time_minutes = float(audit_cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME_MINUTES", 0))
            audit_cycle_time = format_cycle_time(avg_cycle_time_minutes)
        else:
            audit_cycle_time = "N/A"
        
        # Extract ATA audit score
        if ata_audit_score_records and ata_audit_score_records[0].get("AVG_ATA_SCORE") is not None:
            avg_ata_score = float(ata_audit_score_records[0].get("AVG_ATA_SCORE", 0))
            ata_audit_score = f"{avg_ata_score:.2f}%"
            ata_audit_score_bubble = get_audit_score_bubble(avg_ata_score)
        else:
            ata_audit_score = "N/A"
            ata_audit_score_bubble = "N/A"
        
        # Extract ATA rebuttals
        if ata_rebuttals_records and ata_rebuttals_records[0].get("ATA_REBUTTAL_COUNT") is not None:
            ata_rebuttal_count = int(ata_rebuttals_records[0].get("ATA_REBUTTAL_COUNT", 0))
            ata_rebuttals = str(ata_rebuttal_count)
        else:
            ata_rebuttals = "0"

        ata_rebuttal_percent = f"{float(ata_rebuttal_pct_records[0].get('REBUTTAL_OVERTURN_PCT') or 0):.2f} % Overturned" if ata_rebuttal_pct_records else "0.00 % Overturned"

        tooltips = {
            "complete_audit_count": "Total number of completed audits (PYID starting with 'AUD')",
            "audit_sample_percent": "Percentage of work items selected for audit",
            "audit_sample_count": "Number of items audited",
            "work_items_completed": "Total number of work items resolved in the selected date range",
            "audit_cycle_time": "Average time to complete an audit (coming soon)",
            "audit_cycle_time_bubble": "Status indicator for audit cycle time (coming soon)",
            "ata_audit_score": "ATA audit score metric (coming soon)",
            "ata_audit_score_bubble": "Quality rating: Exceptional (100%), Exceeds (99-99.99%), Meets (98-98.99%), Approaching (95-97.99%), Poor (<95%)",
            "ata_rebuttals": "ATA rebuttals count (coming soon)",
            "ata_rebuttal_percent": "Percentage of ATA audit rebuttals (coming soon)"
        }

        return AuditorManagerHeaderKPIsResponse(
            status="success",
            complete_audit_count=complete_audit_count,
            audit_sample_percent=audit_sample_percent,
            audit_sample_count=audit_sample_count,
            work_items_completed=work_items_completed,
            audit_cycle_time=audit_cycle_time,
            audit_cycle_time_bubble="N/A",
            ata_audit_score=ata_audit_score,
            ata_audit_score_bubble=ata_audit_score_bubble,
            ata_rebuttals=ata_rebuttals,
            ata_rebuttal_percent=ata_rebuttal_percent,
            message="Auditor Manager header KPIs retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Auditor Manager header KPIs query error: {type(e).__name__}: {str(e)}")
        return AuditorManagerHeaderKPIsResponse(
            status="error",
            complete_audit_count="0",
            audit_sample_percent="0.0%",
            audit_sample_count="N/A",
            work_items_completed="0",
            audit_cycle_time="N/A",
            audit_cycle_time_bubble="N/A",
            ata_audit_score="N/A",
            ata_audit_score_bubble="N/A",
            ata_rebuttals="N/A",
            ata_rebuttal_percent="N/A",
            message=f"Failed to retrieve Auditor Manager header KPIs: {str(e)}"
        )
