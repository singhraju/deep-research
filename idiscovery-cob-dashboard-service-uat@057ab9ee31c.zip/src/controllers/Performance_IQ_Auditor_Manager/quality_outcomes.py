import logging
import asyncio
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import (
    AuditorManagerBaseRequest,
    AuditScoreTrend,
    AuditorManagerCycleTimeTrend,
    AuditorManagerQualityOutcomesResponse
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    ATA_AUDIT_SCORE_QUERY,
    AUDIT_CYCLE_TIME_QUERY,
    ATA_REBUTTALS_QUERY,
    build_lob_filter,
    build_date_filter,
    build_date_filter_between,
    build_date_filter_created,
    build_auditor_filter,
    build_auditor_filter_user,
    build_associate_filter,
    build_audit_subject_manager_filter,
    build_manager_filter_audit,
    build_manager_filter_user,
)

logger = logging.getLogger(__name__)

# Thread pool for async query execution

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()


def format_minutes_to_mins_secs(minutes: float) -> str:
    """Convert decimal minutes to 'X mins Y secs' format"""
    if minutes is None or minutes == 0:
        return "0 mins 0 secs"
    
    total_seconds = int(minutes * 60)
    mins = total_seconds // 60
    secs = total_seconds % 60
    
    return f"{mins} mins {secs} secs"


ATA_SCORE_TREND_QUERY = f"""
WITH date_range AS (
    SELECT
        DATEDIFF(day, '{{start_date}}'::DATE, '{{end_date}}'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
audit_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        AUDITOR_ID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      AND PYID LIKE 'AUD%'
      {{auditor_filter}}
),
auditor_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE 1=1
        {{user_date_filter}}
        {{auditor_filter_user}}
        {{manager_filter_user}}
),
audit_with_manager AS (
    SELECT
        aud.PYID,
        aud.AUDITOR_ID,
        aud.resolved_date
    FROM audit_deduped aud
    INNER JOIN auditor_manager_mapping am
        ON aud.AUDITOR_ID = am.USERID
        AND aud.resolved_date = am.LOGINDATE
    WHERE aud.rn = 1
),
ata_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITOR_ID,
        AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDITOR_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      {{lob_filter}}
      {{auditor_filter}}
),
ata_with_date AS (
    SELECT
        aud.resolved_date AS case_completion_date,
        ata.AUDIT_SCORE,
        ata.PYID AS ata_id
    FROM audit_with_manager aud
    INNER JOIN ata_deduped ata
        ON aud.PYID = ata.CASE_TO_AUDIT
        AND ata.rn = 1
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN a.case_completion_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.case_completion_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.case_completion_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.case_completion_date)
            ELSE DATE_TRUNC('year', a.case_completion_date)
        END AS group_key,
        a.case_completion_date,
        a.AUDIT_SCORE,
        a.ata_id
    FROM ata_with_date a
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_ata_score,
    COUNT(DISTINCT ata_id) AS total_ata_cases,
    MIN(case_completion_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
"""


AUDIT_CYCLE_TIME_TREND_QUERY = f"""
WITH date_range AS (
    SELECT
        DATEDIFF(day, '{{start_date}}'::DATE, '{{end_date}}'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
audit_deduped AS (
    SELECT
        a.PYID,
        a.AUDITCYCLETIME,
        a.AUDITOR_ID,
        DATE(a.PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (PARTITION BY a.PYID ORDER BY a.PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND a.PYRESOLVEDTIMESTAMP IS NOT NULL
        {{date_filter}}
        {{lob_filter}}
        AND a.AUDITCYCLETIME IS NOT NULL
        {{auditor_filter}}
),
auditor_manager_mapping AS (
    SELECT DISTINCT
        USERID,
        LOGINDATE,
        PYREPORTTO
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE 1=1
        {{user_date_filter}}
        {{auditor_filter_user}}
        {{manager_filter_user}}
),
audit_with_manager AS (
    SELECT
        a.PYID,
        a.AUDITCYCLETIME,
        a.resolved_date
    FROM audit_deduped a
    INNER JOIN auditor_manager_mapping am
        ON a.AUDITOR_ID = am.USERID
        AND a.resolved_date = am.LOGINDATE
    WHERE a.rn = 1
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN a.resolved_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.resolved_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.resolved_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.resolved_date)
            ELSE DATE_TRUNC('year', a.resolved_date)
        END AS group_key,
        a.resolved_date,
        a.AUDITCYCLETIME,
        a.PYID
    FROM audit_with_manager a
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(group_key + 6, 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    AVG(AUDITCYCLETIME / 60.0) AS avg_audit_cycle_time_minutes,
    COUNT(DISTINCT PYID) AS total_audits,
    MIN(resolved_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
"""


def execute_query(engine, query: str, limit: int = 1):
    return engine.execute_query(query, limit=limit)




@router.post(
    "/quality-outcomes",
    response_model=AuditorManagerQualityOutcomesResponse,
    summary="Get Auditor Manager Quality Outcomes",
    description="Retrieve ATA score, audit cycle time, and rebuttals for auditor manager dashboard.",
)
async def get_auditor_manager_quality_outcomes(request: AuditorManagerBaseRequest) -> AuditorManagerQualityOutcomesResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        date_filter_between = build_date_filter_between(request.start_date, request.end_date)
        date_filter_created = build_date_filter_created(request.start_date, request.end_date)
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        auditor_filter = build_auditor_filter(request.auditor_ids)
        auditor_filter_user = build_auditor_filter_user(request.auditor_ids)
        audit_subject_filter = build_associate_filter(request.auditor_ids)
        audit_subject_manager_filter = build_audit_subject_manager_filter(request.manager_ids)
        manager_filter = build_manager_filter_audit(request.manager_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)

        start_date = request.start_date or "1900-01-01"
        end_date = request.end_date or "2099-12-31"

        engine = connection_manager.get_engine()

        fmt = dict(
            date_filter=date_filter,
            date_filter_created=date_filter_created,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter,
            audit_subject_filter=audit_subject_filter,
            audit_subject_manager_filter=audit_subject_manager_filter,
            user_date_filter=user_date_filter,
            auditor_filter_user=auditor_filter_user,
            manager_filter_user=manager_filter_user
        )

        ata_score_query = ATA_AUDIT_SCORE_QUERY.format(**fmt)
        ata_trend_query = ATA_SCORE_TREND_QUERY.format(**fmt, start_date=start_date, end_date=end_date)
        cycle_time_query = AUDIT_CYCLE_TIME_QUERY.format(**fmt)
        cycle_time_trend_query = AUDIT_CYCLE_TIME_TREND_QUERY.format(**fmt, start_date=start_date, end_date=end_date)
        rebuttals_query = ATA_REBUTTALS_QUERY.format(
            **fmt,
            date_filter_between=date_filter_between
        )

        (ata_score_records, ata_trend_records, cycle_time_records,
         cycle_time_trend_records, rebuttals_records) = await asyncio.gather(
            engine.execute_query_async(ata_score_query, limit=1),
            engine.execute_query_async(ata_trend_query, limit=10000),
            engine.execute_query_async(cycle_time_query, limit=1),
            engine.execute_query_async(cycle_time_trend_query, limit=10000),
            engine.execute_query_async(rebuttals_query, limit=1)
        )
        
        ata_score = round(float(ata_score_records[0].get("AVG_ATA_SCORE", 0.0)), 2) if ata_score_records and ata_score_records[0].get("AVG_ATA_SCORE") else 0.0

        ata_trend_data = [
            AuditScoreTrend(
                period=r["PERIOD"],
                avg_audit_score=round(float(r["AVG_ATA_SCORE"]), 2) if r["AVG_ATA_SCORE"] else 0.0,
                total_cases=int(r["TOTAL_ATA_CASES"]) if r["TOTAL_ATA_CASES"] else 0
            )
            for r in ata_trend_records
        ] if ata_trend_records else []

        if cycle_time_records and cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME_MINUTES") is not None:
            audit_cycle_time = float(round(float(cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME_MINUTES", 0.0)), 2))
            audit_cycle_time_formatted = format_minutes_to_mins_secs(audit_cycle_time)
        else:
            audit_cycle_time = 0.0
            audit_cycle_time_formatted = "N/A"

        cycle_time_trend_data = [
            AuditorManagerCycleTimeTrend(
                period=r["PERIOD"],
                avg_cycle_time_minutes=round(float(r["AVG_AUDIT_CYCLE_TIME_MINUTES"]), 2) if r["AVG_AUDIT_CYCLE_TIME_MINUTES"] else 0.0,
                avg_cycle_time_formatted=format_minutes_to_mins_secs(float(r["AVG_AUDIT_CYCLE_TIME_MINUTES"]) if r["AVG_AUDIT_CYCLE_TIME_MINUTES"] else 0.0),
                total_audits=int(r["TOTAL_AUDITS"]) if r["TOTAL_AUDITS"] else 0
            )
            for r in cycle_time_trend_records
        ] if cycle_time_trend_records else []

        rebuttal_count = str(int(rebuttals_records[0].get("ATA_REBUTTAL_COUNT") or 0)) if rebuttals_records else "0"

        tooltips = {
            "ata_score": "Average ATA audit score across all audited cases",
            "ata_score_trend": "ATA score trend over time",
            "audit_cycle_time": "Average audit cycle time in minutes",
            "cycle_time_trend": "Audit cycle time trend over time",
            "rebuttal_count": "Total number of ATA rebuttals",
            "rebuttals_overturned": "Percentage of rebuttals overturned (coming soon)"
        }

        return AuditorManagerQualityOutcomesResponse(
            status="success",
            ata_score=ata_score,
            ata_score_trend=ata_trend_data,
            audit_cycle_time=audit_cycle_time,
            cycle_time_trend=cycle_time_trend_data,
            rebuttal_count=rebuttal_count,
            rebuttals_overturned="N/A",
            rebuttals_count_trend={
                "rebuttals": {"2026-04-01": 5},
                "rebuttals_percent": {"2026-04-01": "12.50%"},
                "overturned": {"2026-04-01": 2},
                "upheld": {"2026-04-01": 3}
            },
            message="Auditor Manager quality outcomes retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Auditor Manager quality outcomes query error: {type(e).__name__}: {str(e)}")
        return AuditorManagerQualityOutcomesResponse(
            status="error",
            ata_score=0.0,
            ata_score_trend=[],
            audit_cycle_time=0.0,
            cycle_time_trend=[],
            rebuttal_count="0",
            rebuttals_overturned="N/A",
            rebuttals_count_trend={},
            message=f"Failed to retrieve Auditor Manager quality outcomes: {str(e)}"
        )