import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, CACHE_FULL_DATASET_LIMIT
from schema import (
    AuditorManagerRebuttalDrilldownRequest,
    RebuttalDrilldownPaginatedResponse,
    RebuttalRecord,
    PageResponse,
)
from controllers.Performance_IQ_Auditor_Manager.rebuttals import REBUTTALS_QUERY
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    build_lob_filter,
    build_audit_period_filter,
    build_auditor_filter,
    build_manager_filter_audit
)
import math

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

REBUTTAL_PAGINATED_QUERY = f"""
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        INTAKESOURCESYSTEM,
        PLATFORM,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
),
latest_rebuttal_cases AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        INTAKESOURCESYSTEM,
        PLATFORM,
        PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM audit_base
),
rebuttal_population AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        INTAKESOURCESYSTEM,
        PLATFORM
    FROM latest_rebuttal_cases
    WHERE rn = 1
      AND REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{auditor_filter}}
      {{manager_filter}}
),
completion_candidates AS (
    SELECT
        rp.PYID,
        rp.AUDITOR_ID,
        rp.AUDITOR_NAME,
        rp.LOB,
        rp.AUDIT_MONTH,
        rp.AUDIT_YEAR,
        rp.INTAKESOURCESYSTEM,
        rp.PLATFORM,
        a.PYSTATUSWORK AS completion_status,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY rp.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM rebuttal_population rp
    INNER JOIN audit_base a
        ON rp.PYID = a.PYID
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_NAME,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        INTAKESOURCESYSTEM,
        PLATFORM,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM deduped_audit_activity
    WHERE rn = 1
      AND REBUTTALOUTCOME IS NOT NULL
      AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
      AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    ce.PYID AS WORK_ITEM_ID,
    COALESCE(ce.INTAKESOURCESYSTEM, 'N/A') AS WORKTYPE_CATEGORY,
    CASE
        WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(ce.completion_status, 'N/A')
    END AS OUTCOME_STATUS,
    COALESCE(ce.LOB, 'N/A') AS LOB,
    ce.completion_ts AS RESOLVED_DATE,
    COALESCE(ce.AUDITOR_ID, 'N/A') AS DOMAIN_ID,
    COALESCE(ce.AUDITOR_NAME, 'N/A') AS ASSOCIATE_NAME,
    COALESCE(ce.PLATFORM, 'N/A') AS PLATFORM_SOURCE_SYSTEM,
    COALESCE(aa.ERRORCATEGORYTYPE, 'N/A') AS ERROR_TYPE,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS ERROR_CATEGORY,
    COALESCE(aa.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME,
    COALESCE(ce.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ce.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM completion_event ce
INNER JOIN eligible_rebuttal_line_items aa
    ON ce.PYID = aa.CASEID
ORDER BY ce.completion_ts DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_REBUTTAL_ORDER_BY = "ce.completion_ts DESC"
DISPLAY_REBUTTAL_RESOLVED_DATE_SQL = "DATE(ce.completion_ts)"

DISPLAY_REBUTTAL_OUTCOME_STATUS_SQL = """
CASE
    WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
    WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
    ELSE COALESCE(ce.completion_status, 'N/A')
END
"""

SORTABLE_REBUTTAL_COLUMNS = {
    "work_item_id": "ce.PYID",
    "worktype_category": "COALESCE(ce.INTAKESOURCESYSTEM, 'N/A')",
    "outcome_status": DISPLAY_REBUTTAL_OUTCOME_STATUS_SQL,
    "lob": "COALESCE(ce.LOB, 'N/A')",
    "resolved_date": DISPLAY_REBUTTAL_RESOLVED_DATE_SQL,
    "domain_id": "COALESCE(ce.AUDITOR_ID, 'N/A')",
    "associate_name": "COALESCE(ce.AUDITOR_NAME, 'N/A')",
    "platform_source_system": "COALESCE(ce.PLATFORM, 'N/A')",
    "error_type": "COALESCE(aa.ERRORCATEGORYTYPE, 'N/A')",
    "error_category": "COALESCE(aa.ERRORCATEGORY, 'N/A')",
    "rebuttal_outcome": "COALESCE(aa.REBUTTALOUTCOME, 'N/A')",
    "audit_month": "COALESCE(ce.AUDIT_MONTH, 'N/A')",
    "audit_year": "COALESCE(ce.AUDIT_YEAR, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_REBUTTAL_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_REBUTTAL_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid auditor manager rebuttal sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_REBUTTAL_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid auditor manager rebuttal sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_REBUTTAL_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "resolved_date":
        tie_breakers.append("ce.completion_ts DESC")
    if normalized_sort_by != "work_item_id":
        tie_breakers.append("ce.PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_rebuttal_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_REBUTTAL_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        cleaned = str(date_str)
        if "T" in cleaned:
            cleaned = cleaned.split("T")[0]
        elif " " in cleaned:
            cleaned = cleaned.split(" ")[0]
        date_obj = datetime.strptime(cleaned, "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

@router.post(
    "/rebuttal-drilldown",
    response_model=RebuttalDrilldownPaginatedResponse,
    summary="Get Rebuttal Drilldown (Auditor Manager)",
    description="""
Retrieve paginated list of rebuttal cases for detailed table display (Auditor Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **auditor_ids** (optional): List of auditor IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item_id**: Unique work item identifier (PYID)
- **worktype_category**: Work type category (INTAKESOURCESYSTEM)
- **outcome_status**: Outcome status (PYSTATUSWORK)
- **lob**: Line of Business
- **resolved_date**: Resolved date (MM/DD/YYYY format)
- **platform_source_system**: Platform source system (PLATFORM)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (rebuttal data with direct manager filtering)
- COB_AI_AUDIT_ACTIVITY (rebuttal outcome details)
""",
)

async def get_rebuttal_drilldown(
    request: AuditorManagerRebuttalDrilldownRequest
) -> RebuttalDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        auditor_filter = build_auditor_filter(request.auditor_ids)
        auditor_manager_filter = build_manager_filter_audit(request.manager_ids)

        engine = connection_manager.get_engine()
        
        count_query = REBUTTALS_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=auditor_manager_filter
        )
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = int(count_result[0].get("REBUTTAL_COUNT") or 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = REBUTTAL_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=auditor_manager_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_rebuttal_query(data_query, request.sort_by, request.sort_direction)
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        rebuttal_records = [
            RebuttalRecord(
                work_item_id=r.get("WORK_ITEM_ID") or "N/A",
                worktype_category=r.get("WORKTYPE_CATEGORY") or "N/A",
                outcome_status=r.get("OUTCOME_STATUS") or "N/A",
                lob=r.get("LOB") or "N/A",
                resolved_date=format_date_mmddyyyy(r.get("RESOLVED_DATE")) if r.get("RESOLVED_DATE") else "N/A",
                domain_id=r.get("ASSOCIATE_NAME") or "N/A",
                associate_name=r.get("ASSOCIATE_NAME") or "N/A",  # was missing
                platform_source_system=r.get("PLATFORM_SOURCE_SYSTEM") or "N/A",
                error_category=r.get("ERROR_CATEGORY") or "N/A",
                error_type=r.get("ERROR_TYPE") or "N/A",
                rebuttal_outcome=r.get("REBUTTAL_OUTCOME") or "N/A",
                audit_month=r.get("AUDIT_MONTH") or "N/A",
                audit_year=r.get("AUDIT_YEAR") or "N/A",
            )
            for r in records
        ] if records else []

        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item_id": "Unique identifier for the work item (PYID)",
            "worktype_category": "Work type category or source system",
            "outcome_status": "Outcome status of the rebuttal case",
            "lob": "Line of Business associated with the work item",
            "resolved_date": "Date when the case was resolved",
            "platform_source_system": "Platform or source system where the case was processed",
            "error_type": "Error type classification",
        }

        return RebuttalDrilldownPaginatedResponse(
            status="success",
            screen_id="rebuttal_auditor_manager",
            user_id=request.user_id,
            page=page_response,
            records=rebuttal_records,
            message="Rebuttal records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated rebuttal drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return RebuttalDrilldownPaginatedResponse(
            status="error",
            screen_id="rebuttal_auditor_manager",
            user_id=request.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve rebuttal records: {str(e)}"
        )


@router.post(
    "/rebuttal-drilldown/download-excel",
    summary="Download Rebuttal Drilldown as Excel (Auditor Manager)",
    description="""
Download complete rebuttal drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **auditor_ids** (optional): List of auditor IDs to filter

**Returns:** Excel file (.xlsx) with all rebuttal records
""",
)

async def download_rebuttal_drilldown_excel(
    request: AuditorManagerRebuttalDrilldownRequest  # fix #1 & #5
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        auditor_filter = build_auditor_filter(request.auditor_ids)
        auditor_manager_filter = build_manager_filter_audit(request.manager_ids)
        
        engine = connection_manager.get_engine()
        
        # Query with high limit for download (no pagination needed)
        download_query = REBUTTAL_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=auditor_manager_filter,
            limit=CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Rebuttal Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Worktype Category",
            "Error Type",
            "Error Category",
            "Rebuttal Outcome",
            "Status",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Platform - Source System",
            "Auditor Name",
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment

        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM_ID", "") or "N/A"))
            ws.cell(row=row_num, column=2, value=str(row.get("WORKTYPE_CATEGORY", "") or "N/A"))
            ws.cell(row=row_num, column=3, value=str(row.get("ERROR_TYPE", "") or "N/A"))
            ws.cell(row=row_num, column=4, value=str(row.get("ERROR_CATEGORY", "") or "N/A"))
            ws.cell(row=row_num, column=5, value=str(row.get("REBUTTAL_OUTCOME", "") or "N/A"))
            ws.cell(row=row_num, column=6, value=str(row.get("OUTCOME_STATUS", "") or "N/A"))
            ws.cell(row=row_num, column=7, value=str(row.get("LOB", "") or "N/A"))
            ws.cell(row=row_num, column=8, value=format_date_mmddyyyy(str(row.get("RESOLVED_DATE", ""))) if row.get("RESOLVED_DATE") else "N/A")
            ws.cell(row=row_num, column=9, value=str(row.get("AUDIT_MONTH", "") or "N/A"))
            ws.cell(row=row_num, column=10, value=(
                int(row["AUDIT_YEAR"]) if row.get("AUDIT_YEAR") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=11, value=str(row.get("PLATFORM_SOURCE_SYSTEM", "") or "N/A"))
            ws.cell(row=row_num, column=12, value=str(row.get("ASSOCIATE_NAME", "") or "N/A"))

        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))  # fixed
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"rebuttal_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for rebuttal drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
