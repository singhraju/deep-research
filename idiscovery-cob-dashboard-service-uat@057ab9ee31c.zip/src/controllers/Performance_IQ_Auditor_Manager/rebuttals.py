import logging
from fastapi import APIRouter, HTTPException
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import asyncio 
from db import SnowflakeConnectionManager
from schema import AuditorManagerBaseRequest, AuditorManagerRebuttalsResponse, RebuttalCountTrend
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    ATA_REBUTTALS_QUERY,
    build_lob_filter,
    build_date_filter,
    build_date_filter_between,
    build_auditor_filter,
    build_auditor_filter_user,
    build_manager_filter_user,
    build_auditor_ids_list,
    build_associate_filter,
    build_date_filter_created,
    build_manager_filter_audit,
    build_audit_period_filter
)
from datetime import datetime
from typing import List, Optional
from schema import AuditPeriod

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

REBUTTALS_QUERY = f"""
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        AUDITOR_ID
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        {{audit_period_filter}}
        {{lob_filter}}
        {{auditor_filter}}
        {{manager_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
        AND REBUTTALOUTCOME IS NOT NULL
        AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
        AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS
FROM audit_filtered af
INNER JOIN eligible_rebuttal_line_items rd
    ON af.PYID = rd.CASEID
"""

REBUTTALS_OVERTURN_QUERY = f"""
WITH audit_base AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK,
        REBUTTALFLAG
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        PXCREATEDATETIME
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        {{audit_period_filter}}
        {{lob_filter}}
        {{auditor_filter}}
        {{manager_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
        AND REBUTTALOUTCOME IS NOT NULL
        AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
        AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS TOTAL_REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS REBUTTALS_OVERTURNED,
    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS REBUTTALS_UPHELD,
    COALESCE(
        ROUND(
            (
                COUNT(DISTINCT CASE
                    WHEN act.REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                    THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
                END) * 100.0
            ) / NULLIF(
                COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY),
                0
            ),
            2
        ),
        0
    ) AS REBUTTAL_OVERTURN_PCT
FROM audit_filtered af
INNER JOIN eligible_rebuttal_line_items act
    ON af.PYID = act.CASEID
"""

REBUTTALS_TREND_QUERY = f"""
WITH grouping_logic AS (
    SELECT
        '{{grouping_type}}' AS grouping_type,
        '{{use_audit_period_grouping}}' AS use_audit_period_grouping
),
audit_base AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK,
        REBUTTALFLAG
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        CASE UPPER(TRIM(AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        {{audit_period_filter}}
        {{lob_filter}}
        {{auditor_filter}}
        {{manager_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
        AND REBUTTALOUTCOME IS NOT NULL
        AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
        AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
),
grouped_data AS (
    SELECT
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(af.PXCREATEDATETIME)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(af.PXCREATEDATETIME))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(af.AUDIT_YEAR), af.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(af.PXCREATEDATETIME))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(af.AUDIT_YEAR),
                CASE
                    WHEN af.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN af.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN af.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(af.PXCREATEDATETIME))

            ELSE DATE_TRUNC('year', DATE(af.PXCREATEDATETIME))
        END AS group_key,
        DATE(af.PXCREATEDATETIME) AS created_date,
        af.PYID,
        act.ERRORCATEGORYTYPE,
        act.ERRORCATEGORY,
        act.REBUTTALOUTCOME
    FROM audit_filtered af
    CROSS JOIN grouping_logic g
    INNER JOIN eligible_rebuttal_line_items act
        ON af.PYID = act.CASEID
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    COUNT(DISTINCT PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS OVERTURNED,
    COUNT(DISTINCT CASE
        WHEN REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS UPHELD,
    COALESCE(
        ROUND(
            (
                COUNT(DISTINCT CASE
                    WHEN REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                    THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
                END) * 100.0
            ) / NULLIF(
                COUNT(DISTINCT PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY),
                0
            ),
            2
        ),
        0
    ) AS REBUTTAL_OVERTURN_PCT,
    MIN(created_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY SORT_DATE
"""


def has_valid_audit_periods(audit_periods: Optional[List[AuditPeriod]] = None) -> bool:
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = (period.year or "").strip()

        if not month_value or not year_value:
            continue

        seen_periods.add((month_value.upper(), year_value))

    return bool(seen_periods)


def get_trend_grouping_type(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    audit_periods: Optional[List[AuditPeriod]] = None,
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = (period.year or "").strip()

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append(key)

    if valid_periods:
        month_count = len(valid_periods)

        if month_count == 1:
            return "weekly"
        if month_count <= 6:
            return "monthly"
        return "quarterly"

    range_start = start_date or "1900-01-01"
    range_end = end_date or "2099-12-31"

    total_days = (
        datetime.strptime(range_end, "%Y-%m-%d") -
        datetime.strptime(range_start, "%Y-%m-%d")
    ).days + 1

    if total_days <= 7:
        return "daily"
    if total_days <= 28:
        return "weekly"
    if total_days <= 365:
        return "monthly"
    if total_days <= 1095:
        return "quarterly"
    return "yearly"


def execute_query(engine, query: str, limit: int = 1):
    return engine.execute_query(query, limit=limit)


@router.post(
    "/rebuttals",
    response_model=AuditorManagerRebuttalsResponse,
    summary="Get Auditor Manager Rebuttals Metrics",
    description="""
Retrieve rebuttals metrics for auditor manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter
- **auditor_ids** (optional): List of auditor IDs to filter

**Response Fields:**
- **rebuttal_count**: Total number of ATA rebuttals
- **rebuttals_overturned**: Percentage of rebuttals overturned (N/A)

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (rebuttal data)
- COB_AI_USER_PROFILE (user relationships)
""",
)
async def get_auditor_manager_rebuttals(request: AuditorManagerBaseRequest) -> AuditorManagerRebuttalsResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        date_filter_created = build_date_filter_created(request.start_date, request.end_date)
        date_filter_between = build_date_filter_between(request.start_date, request.end_date)
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        auditor_filter = build_auditor_filter(request.auditor_ids)
        auditor_filter_user = build_auditor_filter_user(request.auditor_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        manager_filter = build_manager_filter_audit(request.manager_ids)
        auditor_ids_list = build_auditor_ids_list(request.auditor_ids)
        audit_subject_filter = build_associate_filter(request.auditor_ids)

        engine = connection_manager.get_engine()

        audit_period_create_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )

        rebuttals_query = REBUTTALS_QUERY.format(
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter
        )

        overturn_query = REBUTTALS_OVERTURN_QUERY.format(
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter
        )

        grouping_type = get_trend_grouping_type(
            request.start_date,
            request.end_date,
            request.audit_periods,
        )

        use_audit_period_grouping = "true" if has_valid_audit_periods(request.audit_periods) else "false"

        trend_query = REBUTTALS_TREND_QUERY.format(
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            auditor_filter=auditor_filter,
            manager_filter=manager_filter,
            grouping_type=grouping_type,
            use_audit_period_grouping=use_audit_period_grouping
        )
        
        records, overturn_records, trend_records = await asyncio.gather(
            engine.execute_query_async(rebuttals_query, limit=1),
            engine.execute_query_async(overturn_query, limit=1),
            engine.execute_query_async(trend_query, limit=1000)
        )
        rebuttal_count = str(int(records[0].get("REBUTTAL_COUNT") or 0)) if records else "0"
        rebuttals_overturned = f"{float(overturn_records[0].get('REBUTTAL_OVERTURN_PCT') or 0):.2f}%" if overturn_records else "0.00%"
        
        # Sort trend records by sort_date in chronological order
        if trend_records:
            trend_records = sorted(trend_records, key=lambda x: x.get("SORT_DATE") or "")
        
        rebuttals_count_trend = RebuttalCountTrend(
            rebuttals={r["PERIOD"]: int(r["REBUTTALS"] or 0) for r in trend_records},
            overturned={r["PERIOD"]: int(r["OVERTURNED"] or 0) for r in trend_records},
            upheld={r["PERIOD"]: int(r["UPHELD"] or 0) for r in trend_records}
        )

        tooltips = {
            "rebuttal_count": "Total number of ATA rebuttals",
            "rebuttals_overturned": "Percentage of rebuttals overturned (coming soon)"
        }

        return AuditorManagerRebuttalsResponse(
            status="success",
            rebuttals=rebuttal_count,
            rebuttals_overturned=rebuttals_overturned,
            rebuttals_count_trend=rebuttals_count_trend,
            message="Auditor Manager rebuttals metrics retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Auditor Manager rebuttals query error: {type(e).__name__}: {str(e)}")
        return AuditorManagerRebuttalsResponse(
            status="error",
            rebuttals="0",
            rebuttals_overturned="N/A",
            rebuttals_count_trend=RebuttalCountTrend(),
            message=f"Failed to retrieve Auditor Manager rebuttals metrics: {str(e)}"
        )