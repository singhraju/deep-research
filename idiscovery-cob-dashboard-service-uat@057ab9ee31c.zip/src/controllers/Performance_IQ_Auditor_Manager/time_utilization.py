import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import AuditorManagerBaseRequest, AuditorManagerTimeUtilizationResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

FUSE_TIME_QUERY = f"""
WITH associate_hierarchy AS (
    -- Get list of associates who reported to specified manager during the period
    SELECT DISTINCT
        PYRESOLVEDUSERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '{{start_date}}' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{associate_filter_invntry}}
      {{manager_filter}}
)
SELECT 
    -- Total Fuse Time Hours = Available Hours (Total System Time - Non Productive Time)
    ROUND((SUM(up.TOTALSYSTEMTIME) / 3600.0) - (SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0), 2) AS TOTAL_FUSE_TIME_HOURS,
    
    -- OHI Productive Time (from PRODUCTIVETIME column)
   
    ROUND(SUM(
        CASE 
            WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END
    ) / 3600.0, 2) AS OHI_PRODUCTIVE_TIME_HOURS,
    
    -- Non-Productive Time (using FUSE_NON_PRODUCTIVE_TIME)
    ROUND(SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0, 2) AS TOTAL_NON_PRODUCTIVE_HOURS,
    
    
    ROUND(
        (SUM(up.TOTALSYSTEMTIME) / 3600.0) - 
        ((SUM(
            CASE 
                WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                    (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
                ELSE 0
            END
        ) / 3600.0) + 
        (SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0)), 
    2) AS OTHER_TIME_HOURS,
    
    -- Percentages (for UI chart display)
    -- Productive %
    ROUND(
        SUM(CASE WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
            (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
             SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
             SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
        ELSE 0 END) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 2
    ) AS PRODUCTIVE_PCT,
    
    -- Non-Productive %
    ROUND(
        SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 2
    ) AS NON_PRODUCTIVE_PCT,
    
    -- Other time%
    ROUND(
        100.0 - 
        COALESCE(
            SUM(CASE WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0 END) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 0
        ) -
        COALESCE(
            SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 0
        ), 2
    ) AS OTHER_PCT
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE up  
INNER JOIN associate_hierarchy ah
    ON up.USERID = ah.PYRESOLVEDUSERID  
WHERE up.TOTALSYSTEMTIME IS NOT NULL
  {{user_date_filter}}
"""


def build_date_filter(start_date: Optional[str], end_date: Optional[str]) -> str:
    """Build date filter for COB_AI_USER_PROFILE table (uses LOGINDATE)"""
    if start_date and end_date:
        return (
            f"AND LOGINDATE >= '{start_date}' "
            f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND LOGINDATE >= '{start_date}'"
    elif end_date:
        return f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_INVNTRY_PROFILE table (uses REPORTTOMANAGERID)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_auditor_filter(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses USERID)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND USERID IN ('{auditor_ids_str}')"
    return ""


def build_associate_filter_invntry(auditor_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_INVNTRY_PROFILE table (uses PYRESOLVEDUSERID)"""
    if auditor_ids and len(auditor_ids) > 0:
        auditor_ids_str = "', '".join(auditor_ids)
        return f"AND PYRESOLVEDUSERID IN ('{auditor_ids_str}')"
    return ""


@router.post(
    "/time-utilization",
    response_model=AuditorManagerTimeUtilizationResponse,
    summary="Get Auditor Manager Time Utilization Metrics",
    description="""
Retrieve time utilization metrics for auditor manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **auditor_ids** (optional): List of auditor IDs to filter

**Response Fields:**
- **productive_hours**: OHI productive time in hours (2 decimal places)
- **fuse_non_productive_time**: Fuse non-productive time in hours (2 decimal places)
- **available_hours**: Total available hours (2 decimal places)
- **staff_utilization_percent**: Staff utilization percentage (2 decimal places)

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (associate hierarchy for manager filtering)
- COB_AI_USER_PROFILE (time utilization metrics)
""",
)
async def get_auditor_manager_time_utilization(request: AuditorManagerBaseRequest) -> AuditorManagerTimeUtilizationResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        user_date_filter = build_date_filter(request.start_date, request.end_date)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(request.auditor_ids)
        start_date = request.start_date or "1900-01-01"
        end_date = request.end_date or "2099-12-31"
        
        engine = connection_manager.get_engine()

        # Build query
        fuse_time_query = FUSE_TIME_QUERY.format(
            start_date=start_date,
            end_date=end_date,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter,
            user_date_filter=user_date_filter
        )

        # Execute query
        records = engine.execute_query(fuse_time_query, limit=1)

        # Extract metrics with proper null handling
        if records:
            total_fuse_time_hours = float(records[0].get("TOTAL_FUSE_TIME_HOURS") or 0.0) #available hours
            ohi_productive_time = float(records[0].get("OHI_PRODUCTIVE_TIME_HOURS") or 0.0) #productive hours
            total_non_productive_hours = float(records[0].get("TOTAL_NON_PRODUCTIVE_HOURS") or 0.0)
            other_time_hours = float(records[0].get("OTHER_TIME_HOURS") or 0.0)
            productive_pct = float(records[0].get("PRODUCTIVE_PCT") or 0.0)
            non_productive_pct = float(records[0].get("NON_PRODUCTIVE_PCT") or 0.0)
            other_pct = float(records[0].get("OTHER_PCT") or 0.0)
        else:
            total_fuse_time_hours = 0.0
            ohi_productive_time = 0.0
            total_non_productive_hours = 0.0
            other_time_hours = 0.0
            productive_pct = 0.0
            non_productive_pct = 0.0
            other_pct = 0.0

        # Calculate staff utilization percentage (using productive percentage)
        staff_utilization_percent = productive_pct

        tooltips = {
            "total_fuse_time_hours": "Total hours logged into FUSE system across all auditors",
            "ohi_productive_time": "OHI system productive time in hours from PRODUCTIVETIME column",
            "total_non_productive_hours": "Total non-productive hours (breaks, meetings, etc.)",
            "other_time_hours": "Other time (Total - (Productive + Non-Productive)) in hours",
            "productive_pct": "Productive time percentage of total fuse time",
            "non_productive_pct": "Non-productive time percentage of total fuse time",
            "other_pct": "Other time percentage of total fuse time",
            "staff_utilization_percent": "Staff utilization percentage (productive percentage)"
        }

        return AuditorManagerTimeUtilizationResponse(
            status="success",
            total_fuse_time_hours=total_fuse_time_hours,
            ohi_productive_time=ohi_productive_time,
            total_non_productive_hours=total_non_productive_hours,
            other_time_hours=other_time_hours,
            productive_pct=productive_pct,
            non_productive_pct=non_productive_pct,
            other_pct=other_pct,
            staff_utilization_percent=staff_utilization_percent,
            message="Auditor Manager time utilization metrics retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Auditor Manager time utilization query error: {type(e).__name__}: {str(e)}")
        return AuditorManagerTimeUtilizationResponse(
            status="error",
            total_fuse_time_hours=0.0,
            ohi_productive_time=0.0,
            total_non_productive_hours=0.0,
            other_time_hours=0.0,
            productive_pct=0.0,
            non_productive_pct=0.0,
            other_pct=0.0,
            staff_utilization_percent=0.0,
            message=f"Failed to retrieve Auditor Manager time utilization metrics: {str(e)}"
        )
