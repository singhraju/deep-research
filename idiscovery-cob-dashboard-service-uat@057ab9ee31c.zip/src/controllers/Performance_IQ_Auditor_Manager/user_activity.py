import logging
from typing import Optional, List
from datetime import datetime, timedelta
import asyncio
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import (
    AuditorManagerBaseRequest,
    AuditorManagerUserActivityResponse,
    AuditorManagerLoginLogoutSession,
    AuditPeriod,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    build_audit_period_filter,
)
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auditor-manager", tags=["Performance_IQ_Auditor_Manager"])

connection_manager = SnowflakeConnectionManager()

# Query to get all individual login/logout sessions from the most recent date for Auditor Manager
USER_ACTIVITY_QUERY = f"""
SELECT 
    DATE(LOGINTIME) as LOGINDATE,
    LOGINTIME as LOGIN_SORT_TS,
    TO_CHAR(LOGINTIME, 'HH12:MI AM') || ' ET' as login_time,
    TO_CHAR(LOGOUTTIME, 'HH12:MI AM') || ' ET' as logout_time
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_ACTIVITY
WHERE DOMAINID = '{{user_id}}'
AND DATE(LOGINTIME) = CURRENT_DATE()
ORDER BY LOGINTIME ASC
"""

# Query to get team rank for Auditor Manager - calculates based on efficiency and ATA scores
# Query to get team rank for Auditor Manager - calculates based on efficiency and ATA scores
AUDIT_TEAM_RANK_QUERY = f"""
WITH offshore_managers AS (
    SELECT DISTINCT USERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE UPPER(PYACCESSGROUP) = 'COB:OFFFRONTLINEMANAGERAUDITOR'
      AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
      AND USERID IN (
          SELECT DISTINCT PYREPORTTO
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
          WHERE PYREPORTTO IS NOT NULL
      )
),
users_with_reportees AS (
    SELECT DISTINCT PYREPORTTO AS USERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE PYREPORTTO IS NOT NULL
      AND PYREPORTTO IN (
          SELECT USERID
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
          WHERE UPPER(PYACCESSGROUP) IN (
              'COB:FRONTLINEAUDITOR',
              'CLMSCCU:AUDITOR',
              'COB:OFFFRONTLINEMANAGERAUDITOR'
          )
          AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
      )
),
auditors AS (
    SELECT
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        COALESCE(PYREPORTTO, 'NONE') AS manager_id,
        PYACCESSGROUP
    FROM (
        SELECT
            USERID,
            USERNAME,
            FIRSTNAME,
            LASTNAME,
            PYREPORTTO,
            PYACCESSGROUP,
            ROW_NUMBER() OVER (
                PARTITION BY USERID
                ORDER BY PXUPDATEDATETIME DESC NULLS LAST
            ) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
        WHERE UPPER(PYACCESSGROUP) IN (
            'COB:FRONTLINEAUDITOR',
            'CLMSCCU:AUDITOR',
            'COB:OFFFRONTLINEMANAGERAUDITOR'
        )
    )
    WHERE rn = 1
      AND USERID NOT IN (SELECT USERID FROM users_with_reportees)
),
audit_base_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME,
        AUDITCYCLETIME,
        ISATACASE
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND COALESCE(ISATACASE, 'N') = 'N'
),
completion_candidates_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY
                CASE
                    WHEN PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                PXCOMMITDATETIME ASC
        ) AS rn
    FROM audit_base_efficiency
    WHERE PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_MGR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_candidates_efficiency
    WHERE rn = 1
),
filtered_completion_efficiency AS (
    SELECT
        PYID,
        AUDITOR_ID,
        completion_ts,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM completion_event_efficiency
    WHERE 1 = 1
      {{audit_period_filter}}
),
first_positive_cycle_ts_efficiency AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.completion_ts,
        MIN(a.PXCOMMITDATETIME) AS cycle_ts
    FROM filtered_completion_efficiency c
    JOIN audit_base_efficiency a
        ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY c.PYID, c.AUDITOR_ID, c.completion_ts
),
cycle_time_at_first_positive AS (
    SELECT
        f.PYID,
        f.AUDITOR_ID,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts_efficiency f
    JOIN audit_base_efficiency a
        ON a.PYID = f.PYID
       AND a.PXCOMMITDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY f.PYID, f.AUDITOR_ID
),
audit_cycle_time AS (
    SELECT
        AUDITOR_ID AS userid,
        AVG(AUDITCYCLETIME) AS avg_cycle_time_seconds,
        COUNT(PYID) AS total_audits
    FROM cycle_time_at_first_positive
    GROUP BY AUDITOR_ID
),
ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        AUDITGOAL,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_MGR_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      AND AUDITGOAL > 0
),
first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),
first_resolved AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),
completion_points_ata AS (
    SELECT
        PYID,
        completion_timestamp
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),
filtered_completion_ata AS (
    SELECT DISTINCT
        a.PYID,
        a.AUDIT_SUBJECT_ID,
        c.completion_timestamp,
        a.AUDIT_YEAR,
        a.AUDIT_MONTH
    FROM ata_filtered_records a
    JOIN completion_points_ata c
        ON a.PYID = c.PYID
    WHERE 1 = 1
      {{ata_audit_period_filter}}
),
ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SUBJECT_ID,
        TRY_TO_DECIMAL(TRIM(a.AUDIT_SCORE)) AS AUDIT_SCORE,
        a.AUDITGOAL,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN filtered_completion_ata fc
        ON a.PYID = fc.PYID
    WHERE a.PXCOMMITDATETIME >= fc.completion_timestamp
),
ata_scores AS (
    SELECT
        AUDIT_SUBJECT_ID AS userid,
        AVG((AUDIT_SCORE / NULLIF(AUDITGOAL, 0)) * 100) AS avg_ata_score_pct,
        COUNT(PYID) AS ata_count
    FROM ata_scores_at_completion
    WHERE rn = 1
    GROUP BY AUDIT_SUBJECT_ID
),
auditor_scores AS (
    SELECT
        a.USERID,
        a.USERNAME,
        a.FIRSTNAME,
        a.LASTNAME,
        a.manager_id,
        a.PYACCESSGROUP,
        COALESCE(act.avg_cycle_time_seconds, 0) AS avg_cycle_time_seconds,
        COALESCE(act.total_audits, 0) AS total_audits,
        COALESCE(ata.avg_ata_score_pct, 0) AS avg_ata_score_pct,
        COALESCE(ata.ata_count, 0) AS ata_count,
        CASE
            WHEN act.avg_cycle_time_seconds > 0
            THEN (20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100
            ELSE 0
        END AS efficiency_score,
        CASE
            WHEN ata.avg_ata_score_pct > 0 AND act.avg_cycle_time_seconds > 0
            THEN ((20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100 + ata.avg_ata_score_pct) / 2
            WHEN act.avg_cycle_time_seconds > 0
            THEN (20.0 / (act.avg_cycle_time_seconds / 60.0)) * 100
            ELSE 0
        END AS final_score,
        CASE
            WHEN om.USERID IS NOT NULL THEN 'Offshore'
            ELSE 'Onshore'
        END AS shore_type
    FROM auditors a
    LEFT JOIN audit_cycle_time act
        ON a.USERID = act.userid
    LEFT JOIN ata_scores ata
        ON a.USERID = ata.userid
    LEFT JOIN offshore_managers om
        ON a.manager_id = om.USERID
),
auditor_rankings AS (
    SELECT
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        manager_id,
        PYACCESSGROUP,
        shore_type,
        final_score,
        RANK() OVER (PARTITION BY shore_type ORDER BY final_score DESC) AS team_rank,
        avg_cycle_time_seconds,
        ROUND(avg_cycle_time_seconds / 60.0, 2) AS avg_cycle_time_minutes,
        total_audits,
        avg_ata_score_pct,
        ata_count,
        efficiency_score
    FROM auditor_scores
    WHERE final_score > 0
)
SELECT
    team_rank AS TEAMRANK,
    shore_type AS SHORETYPE
FROM auditor_rankings
WHERE USERID = '{{user_id}}'
"""


def build_date_filter(start_date: Optional[str], end_date: Optional[str]) -> str:
    """Build date filter for COB_AI_USER_ACTIVITY table (uses LOGINTIME)"""
    if start_date and end_date:
        return (
            f"AND DATE(LOGINTIME) >= '{start_date}' "
            f"AND DATE(LOGINTIME) <= '{end_date}'"
        )
    elif start_date:
        return f"AND DATE(LOGINTIME) >= '{start_date}'"
    elif end_date:
        return f"AND DATE(LOGINTIME) <= '{end_date}'"
    return ""


def build_date_filter_rank(start_date: Optional[str], end_date: Optional[str]) -> str:
    """Build date filter for COB_AI_AUDIT_PROFILE table (uses PYRESOLVEDTIMESTAMP)"""
    if start_date and end_date:
        return (
            f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' "
            f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for audit profile."""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def execute_query(engine, query: str, limit: int = 1):
    """Execute query with specified limit."""
    return engine.execute_query(query, limit=limit)


def format_time_to_et(time_str):
    """Format time string to 'HH:MM AM/PM ET' format"""
    if not time_str or time_str == "N/A":
        return "N/A"
    
    try:
        # Parse the time string (assuming it's in format like "2024-03-31 08:15:00" or "08:15:00")
        if isinstance(time_str, datetime):
            dt = time_str
        elif " " in str(time_str):
            dt = datetime.strptime(str(time_str), "%Y-%m-%d %H:%M:%S")
        else:
            dt = datetime.strptime(str(time_str), "%H:%M:%S")
        
        # Format to 12-hour format with AM/PM
        formatted_time = dt.strftime("%I:%M %p ET").lstrip("0")
        return formatted_time
    except Exception as e:
        logger.warning(f"Failed to format time '{time_str}': {e}")
        return str(time_str)
    
def get_single_audit_period(audit_periods: Optional[List[AuditPeriod]] = None) -> Optional[AuditPeriod]:
    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""
        if month_value and year_value:
            return period
    return None


@router.post(
    "/user-activity",
    response_model=AuditorManagerUserActivityResponse,
    summary="Get Auditor Manager User Activity",
    description="""
Retrieve user activity data including login and logout times for Auditor Manager.

**Input Parameters:**
- **user_id** (required): Logged-in Auditor Manager user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter (not used in this endpoint)

**Response Fields:**
- **sessions**: List of all individual login/logout sessions from the most recent date
- **audit_team_rank**: Audit team rank position (e.g., "6") calculated based on:
  - **Efficiency Component**: (20 min goal / Audit Cycle Time) × 100
  - **Quality Component**: ATA (Audit-the-Auditor) Score
  - **Final Score**: (Efficiency + ATA Score) / 2, or Efficiency only if ATA score unavailable
  - Rank is calculated within manager's team over the specified date range

**Data Sources:** 
- COB_AI_USER_ACTIVITY (individual login/logout session times)
- COB_AI_USER_PROFILE (login dates and auditor information)
- COB_AI_AUDIT_PROFILE (audit cycle time and ATA scores for rank calculation)
""",
)
async def get_auditor_manager_user_activity(request: AuditorManagerBaseRequest) -> AuditorManagerUserActivityResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        date_filter = build_date_filter(request.start_date, request.end_date)
        
        engine = connection_manager.get_engine()

        # Build queries
        user_activity_query = USER_ACTIVITY_QUERY.format(
            user_id=request.user_id,
            date_filter=date_filter
        )
        
        # Use last 90 days if no dates provided for more realistic results
        default_end = datetime.now().strftime('%Y-%m-%d')
        default_start = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')

        rank_start_date = request.start_date or default_start
        rank_end_date = request.end_date or default_end

        audit_period_filter = build_audit_period_filter(
            rank_start_date,
            rank_end_date,
            request.audit_periods,
            timestamp_column="completion_ts",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )

        ata_audit_period_filter = build_audit_period_filter(
            rank_start_date,
            rank_end_date,
            request.audit_periods,
            timestamp_column="completion_timestamp",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )

        audit_rank_query = AUDIT_TEAM_RANK_QUERY.format(
            user_id=request.user_id,
            audit_period_filter=audit_period_filter,
            ata_audit_period_filter=ata_audit_period_filter,
        )
        
        logger.info(
            "Querying team rank for user %s with audit_period_filter=%s and ata_audit_period_filter=%s",
            request.user_id,
            audit_period_filter,
            ata_audit_period_filter,
        )
        
        # Execute queries in parallel using asyncio.gather
        (activity_records, rank_records) = await asyncio.gather(
            engine.execute_query_async(user_activity_query, limit=999),
            engine.execute_query_async(audit_rank_query, limit=1)
        )

        # Extract all individual login/logout sessions from the most recent date
        sessions = []
        if activity_records and len(activity_records) > 0:
            sorted_activity_records = sorted(
                activity_records,
                key=lambda record: (
                    record.get("LOGIN_SORT_TS") is None,
                    record.get("LOGIN_SORT_TS")
                )
            )
            for record in sorted_activity_records:
                login_time = record.get("LOGIN_TIME", "")
                logout_time = record.get("LOGOUT_TIME", "")
                
                sessions.append(AuditorManagerLoginLogoutSession(
                    login_time=login_time,
                    logout_time=logout_time
                ))
        else:
            # No data from database, return empty session
            sessions.append(AuditorManagerLoginLogoutSession(
                login_time="",
                logout_time=""
            ))
        
        # Extract audit team rank
        if rank_records and len(rank_records) > 0:
            rank_value = rank_records[0].get("TEAMRANK")
            audit_team_rank = str(int(rank_value)) if rank_value is not None else "N/A"
            logger.info(f"Team rank for user {request.user_id}: {audit_team_rank}")
        else:
            logger.warning(f"No team rank data found for user {request.user_id}. This may indicate no audit activity in the date range.")
            audit_team_rank = "N/A"

        tooltips = {
            "sessions": "All individual login and logout sessions from the most recent date. Each session represents a separate login/logout event (e.g., before/after lunch break).",
            "audit_team_rank": "Average team rank position calculated based on efficiency (audit cycle time vs. 20 min goal) and quality (ATA score) over the date range"
        }

        return AuditorManagerUserActivityResponse(
            status="success",
            sessions=sessions,
            audit_team_rank=audit_team_rank,
            message="Auditor Manager user activity retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Auditor Manager user activity query error: {type(e).__name__}: {str(e)}")
        return AuditorManagerUserActivityResponse(
            status="error",
            sessions=[],
            audit_team_rank="N/A",
            message=f"Failed to retrieve Auditor Manager user activity: {str(e)}"
        )
