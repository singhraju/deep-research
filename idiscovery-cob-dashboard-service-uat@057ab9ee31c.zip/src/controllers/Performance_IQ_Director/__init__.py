from .demand_inventory import router as demand_inventory_router
from .operational_flow import router as operational_flow_router
from .quality_outcomes import router as quality_outcomes_router
from .header_kpis import router as header_kpis_router
from .associate_utilization import router as associate_utilization_router
from .sla_health import router as sla_health_router
from .managers_list import router as managers_list_router
from .associates_list import router as associates_list_router
from .director_list import router as director_list_router
from .escalation_count_drilldown import router as escalation_count_drilldown_router
from .pended_items_counts_drilldown import router as pended_items_drilldown_router
from .production_pct_achieved_drilldown import router as production_pct_achieved_drilldown_router
from .rebuttal_drilldown import router as rebuttal_drilldown_router
from .audit_score_director_drilldown import router as audit_score_director_drilldown_router
from .fuse_time_director_drilldown import router as fuse_time_director_drilldown_router
from .work_items_director_drilldown import router as work_items_director_drilldown_router
from .ai_coach_director import router as ai_coach_router_director
from .capacity_insight_drilldown import router as capacity_insight_drilldown_router
from .sla_health_drilldown import router as sla_health_drilldown_router
from .completed_audit_count_drilldown import router as completed_audit_count_drilldown_router
from .audit_sample_pct_drilldown import router as audit_sample_pct_drilldown_router
from .watchlist_drilldown import router as watchlist_drilldown_router
from .cycle_takt_drilldown import router as cycle_takt_drilldown_router
from .rework_pct_drilldown import router as rework_pct_drilldown_router
from .audit_error_director_drilldown import router as audit_error_director_drilldown_router
from .staff_utilization_drilldown import router as staff_utilization_drilldown_router
from .director_lob import router as director_lob_router
from .director_user_activity import router as director_user_activity_router

__all__ = [
    "demand_inventory_router",
    "operational_flow_router",
    "quality_outcomes_router",
    "header_kpis_router",
    "associate_utilization_router",
    "sla_health_router",
    "managers_list_router",
    "associates_list_router",
    "director_list_router",
    "escalation_count_drilldown_router",
    "pended_items_drilldown_router",
    "production_pct_achieved_drilldown_router",
    "rebuttal_drilldown_router",
    "audit_score_director_drilldown_router",
    "fuse_time_director_drilldown_router",
    "work_items_director_drilldown_router",
    "ai_coach_router_director",
    "capacity_insight_drilldown_router",
    "sla_health_drilldown_router",
    "completed_audit_count_drilldown_router",
    "audit_sample_pct_drilldown_router",
    "watchlist_drilldown_router",
    "cycle_takt_drilldown_router",
    "rework_pct_drilldown_router",
    "audit_error_director_drilldown_router",
    "staff_utilization_drilldown_router",
    "director_lob_router",
    "director_user_activity_router",
]
