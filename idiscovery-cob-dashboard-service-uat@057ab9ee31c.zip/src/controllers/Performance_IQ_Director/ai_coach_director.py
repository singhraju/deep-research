import logging
from fastapi import APIRouter, Response, status
import config
from schema import DirectorAICoachRequest, DirectorAICoachResponse
from services.openai_service import generate_performance_summary, normalize_ai_summary
from services.metrics_aggregator import fetch_director_metrics

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

@router.post(
    "/ai-coach",
    response_model=DirectorAICoachResponse,
    summary="Get AI Coach Performance Summary",
    description="""
Retrieve AI-generated performance summary based on organizational KPIs and metrics.

**Input Parameters:**
- **user_id** (required): The unique identifier of the user
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format
- **director_id**: List of the User Id of Directors
- **manager_id**: List of the selected Manager's ID
- **associates_id**: List of the selected Associates's ID
- **lob**: List of Line of Business values

**Response Fields:**
- **performance_summary**: AI-generated strategic summary analyzing team KPIs, operational flow, and organizational patterns

**Status:** AI-powered strategic coaching using OpenAI GPT models
""",
)
async def get_ai_coach(request: DirectorAICoachRequest, response: Response) -> DirectorAICoachResponse:
    if not config.is_ai_coach_enabled("director"):
        return DirectorAICoachResponse(
            status="disabled",
            user_id=request.user_id,
            performance_summary="AI Coach feature is currently disabled",
            message="Feature disabled by configuration"
        )
    
    try:
        logger.info(f"Director AI Coach request for user {request.user_id} ({request.start_date} to {request.end_date})")
        logger.info(f"Director AI Coach filters: director_ids={request.director_ids}, manager_ids={request.manager_ids}, "
                   f"frontline_associate_ids={request.frontline_associate_ids}, lob={request.lob}, session_id={request.session_id}")
        
        metrics_data = await fetch_director_metrics(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date,
            director_id=request.director_ids,  # Already a list from schema
            manager_id=request.manager_ids,    # Already a list from schema
            associates_id=request.frontline_associate_ids,  # Already a list from schema
            lob=request.lob,
            session_id=request.session_id
        )
        
        # Log the exact metrics being sent to LLM for debugging
        # Note: volume_forecast_accuracy is excluded upstream in fetch_director_metrics() per 4/10/26 requirements
        logger.info(f"📊 Director AI Coach - Metrics sent to LLM: {metrics_data}")
        
        if "error" in metrics_data:
            logger.error(f"Director AI Coach metrics fetch failed for {request.user_id}: {metrics_data.get('error')}")
            response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            return DirectorAICoachResponse(
                status="error",
                user_id=request.user_id,
                performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
                message=f"Failed to fetch AI Coach metrics: {metrics_data.get('error')}"
            )

        summary = await generate_performance_summary(
            user_id=request.user_id,
            metrics_data=metrics_data,
            role="director",
            start_date=request.start_date,
            end_date=request.end_date,
            lob=request.lob
        )

        summary_text = normalize_ai_summary(summary)["performance_summary"]
        
        return DirectorAICoachResponse(
            status="success",
            user_id=request.user_id,
            performance_summary=summary_text,
            message="AI Coach strategic analysis completed successfully"
        )
        
    except Exception as e:
        logger.error(f"Director AI Coach error for user {request.user_id}: {str(e)}")

        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return DirectorAICoachResponse(
            status="error",
            user_id=request.user_id,
            performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
            message=f"Error: {str(e)}"
        )