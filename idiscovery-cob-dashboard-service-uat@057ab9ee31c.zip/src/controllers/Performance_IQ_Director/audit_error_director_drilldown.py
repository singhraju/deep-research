import logging
import math
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import httpx
import asyncio

from schema import (
    AuditErrorDirectorDrilldownPaginatedRequest,
    AuditErrorDirectorDrilldownPaginatedResponse,
    AuditErrorRecord,
    PageResponse,
    DirectorBaseDownloadRequest,
)
import config
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return f"AND {date_column} >= '{start_date}' AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND UPPER(TRIM(reporttodirectorid)) IN ('{director_ids_str}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND UPPER(TRIM(REPORTTOMANAGERID)) IN ('{manager_ids_str}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "PYRESOLVEDUSERID") -> str:
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND UPPER(TRIM({column})) IN ('{frontline_associate_ids_str}')"
    return ""

AUDIT_ERROR_DRILLDOWN_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(i.PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        UPPER(TRIM(i.REPORTTOMANAGERID)) AS MANAGER_ID,
        i.PYRESOLVEDTIMESTAMP,
        i.INTAKESOURCESYSTEM,
        i.INVNTRY_TYPE,
        i.LOB,
        i.PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
    WHERE UPPER(TRIM(i.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(ap.PYSTATUSWORK)) AS AUDIT_STATUS,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        DATE(ap.PXCREATEDATETIME) AS RESOLVED_DATE,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.createtimestamp AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    ap.AUDIT_CASE_ID AS work_item,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS error_category,
    COALESCE(up.USERNAME, 'N/A') AS associate_name,
    aa.DATE_ASSESSED AS date_assessed,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(i.LOB, 'N/A') AS lob,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(aa.SPECIALISTERRORCORRECTED, 'N/A') AS specialist_error_corrected
FROM invntry_deduped i
JOIN audit_profile_deduped ap
  ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
 AND ap.rn = 1
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
LEFT JOIN deduped_user_profile up
  ON up.USERID = i.ASSOCIATE_ID
 AND up.rn = 1
WHERE i.rn = 1
ORDER BY 
    ap.RESOLVED_DATE DESC,
    ap.AUDIT_CASE_ID,
    aa.ERRORCATEGORY
"""

AUDIT_ERROR_DIRECTOR_DEFAULT_ORDER_BY = """ORDER BY 
    ap.RESOLVED_DATE DESC,
    ap.AUDIT_CASE_ID,
    aa.ERRORCATEGORY"""


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item": "ap.AUDIT_CASE_ID",
        "work_type": "i.INTAKESOURCESYSTEM",
        "error_category": "aa.ERRORCATEGORY",
        "associate_name": "up.USERNAME",
        "date_assessed": "aa.DATE_ASSESSED",
        "inventory_type": "i.INVNTRY_TYPE",
        "lob": "i.LOB",
        "platform": "i.PLATFORM",
        "error_corrected": "aa.SPECIALISTERRORCORRECTED",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return AUDIT_ERROR_DIRECTOR_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, ap.RESOLVED_DATE DESC, ap.AUDIT_CASE_ID, aa.ERRORCATEGORY"

AUDIT_ERROR_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
    WHERE UPPER(TRIM(i.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped i
JOIN audit_profile_deduped ap
  ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
 AND ap.rn = 1
JOIN audit_activity_deduped aa
  ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
 AND aa.rn = 1
WHERE i.rn = 1
"""

@router.post(
    "/audit-error-director-drilldown",
    response_model=AuditErrorDirectorDrilldownPaginatedResponse,
    summary="Get Audit Error Drilldown (Director)",
    description="""
Retrieve paginated list of audit errors for detailed table display (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item**: Unique case/work item identifier
- **work_type**: Type of work item
- **error_category**: Category of the audit error
- **associate_name**: Name of the associate
- **date_assessed**: Date when the audit was assessed
- **inventory_type**: Inventory type classification
- **lob**: Line of Business
- **platform**: Processing platform
- **error_corrected**: Whether the error was corrected

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Source:** Placeholder data for frontend development
""",
)
async def get_audit_error_director_drilldown(
    request: AuditErrorDirectorDrilldownPaginatedRequest
) -> AuditErrorDirectorDrilldownPaginatedResponse:
    """Session-enabled audit error drilldown endpoint with in-memory pagination."""
    return await execute_audit_error_director_drilldown_query(request)


async def execute_audit_error_director_drilldown_query(
    request: AuditErrorDirectorDrilldownPaginatedRequest
) -> AuditErrorDirectorDrilldownPaginatedResponse:
    """Execute audit error drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter(
            request.frontline_associate_ids,
            column="PYRESOLVEDUSERID"
        )
        
        # Get count first
        count_query = AUDIT_ERROR_COUNT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry
        )
        
        engine = connection_manager.get_engine()
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = int(count_result[0].get("TOTAL_COUNT", 0)) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Build paginated query
        offset = (page - 1) * page_limit
        drilldown_query = AUDIT_ERROR_DRILLDOWN_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry
        )
        drilldown_query = drilldown_query.replace(
            AUDIT_ERROR_DIRECTOR_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        drilldown_query += f"\nLIMIT {page_limit} OFFSET {offset}"
        
        # Execute drilldown query
        records = await engine.execute_query_async(drilldown_query, limit=page_limit + 100)
        
        # Map to response model
        audit_error_records = [
            AuditErrorRecord(
                work_item=str(record.get("WORK_ITEM", "N/A")),
                work_type=str(record.get("WORK_TYPE", "N/A")),
                error_category=str(record.get("ERROR_CATEGORY", "N/A")),
                associate_name=str(record.get("ASSOCIATE_NAME", "N/A")),
                date_assessed=format_date_mmddyyyy(str(record.get("DATE_ASSESSED", "N/A")).split()[0]) if record.get("DATE_ASSESSED") and record.get("DATE_ASSESSED") != "N/A" else "N/A",
                inventory_type=str(record.get("INVENTORY_TYPE", "N/A")),
                lob=str(record.get("LOB", "N/A")),
                platform=str(record.get("PLATFORM", "N/A")),
                error_corrected=str(record.get("SPECIALIST_ERROR_CORRECTED", "N/A"))
            )
            for record in records
        ]
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the audit work item/case",
            "work_type": "Type of work item (intake source system)",
            "error_category": "Category of the audit error identified",
            "associate_name": "Name of the associate who worked on the item",
            "date_assessed": "Date when the audit was assessed",
            "inventory_type": "Type of inventory classification for the work item",
            "lob": "Line of Business associated with the work item",
            "platform": "Platform where the work item was processed",
            "error_corrected": "Indicates whether the specialist error was corrected (Y/N)"
        }

        return AuditErrorDirectorDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            user_id=request.user_id,
            page=page_response,
            records=audit_error_records,
            message=f"Retrieved {len(audit_error_records)} audit error records (page {page} of {total_pages})",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated audit error director drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return AuditErrorDirectorDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve audit error records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/audit-error-director-drilldown/download-excel",
    summary="Download Audit Error Drilldown as Excel (Director)",
    description="""
Download complete audit error drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all audit error records (placeholder data)
""",
)
async def download_audit_error_director_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter(
            request.frontline_associate_ids,
            column="PYRESOLVEDUSERID"
        )
        
        # Build and execute query (no pagination for Excel)
        drilldown_query = AUDIT_ERROR_DRILLDOWN_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry
        )
        
        engine = connection_manager.get_engine()
        records = await engine.execute_query_async(drilldown_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        total_records = len(records)

        wb = Workbook()
        ws = wb.active
        ws.title = "Audit Error Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Error Category",
            "Associate Name",
            "Date Assessed",
            "Inventory Type",
            "LOB",
            "Platform",
            "Error Corrected"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, record in enumerate(records, start=2):
            ws.cell(row=row_num, column=1, value=str(record.get("WORK_ITEM", "N/A")))
            ws.cell(row=row_num, column=2, value=str(record.get("WORK_TYPE", "N/A")))
            ws.cell(row=row_num, column=3, value=str(record.get("ERROR_CATEGORY", "N/A")))
            ws.cell(row=row_num, column=4, value=str(record.get("ASSOCIATE_NAME", "N/A")))
            date_assessed = record.get("DATE_ASSESSED")
            ws.cell(row=row_num, column=5, value=format_date_mmddyyyy(str(date_assessed).split()[0]) if date_assessed and date_assessed != "N/A" else "N/A")
            ws.cell(row=row_num, column=6, value=str(record.get("INVENTORY_TYPE", "N/A")))
            ws.cell(row=row_num, column=7, value=str(record.get("LOB", "N/A")))
            ws.cell(row=row_num, column=8, value=str(record.get("PLATFORM", "N/A")))
            ws.cell(row=row_num, column=9, value=str(record.get("SPECIALIST_ERROR_CORRECTED", "N/A")))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"audit_error_director_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for audit error director drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
