import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import StreamingResponse
import httpx
import asyncio
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

from db import SnowflakeConnectionManager
from schema import DirectorBaseDownloadRequest, AuditSamplePctDrilldownPaginatedRequest, AuditSamplePctDrilldownPaginatedResponse, AuditSamplePctRecord, PageResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from io import BytesIO
import math

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

# Comprehensive query to get audit sample percentage data
AUDIT_SAMPLE_PCT_QUERY = f"""
WITH deduped_invntry AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      {{date_filter}}
      {{lob_filter}}
      {{associate_filter_invntry}}
      {{manager_filter}}
      {{director_filter}}
),
work_items AS (
    SELECT 
        PYRESOLVEDUSERID AS USERID,
        COUNT(DISTINCT PYID) AS cases_resolved
    FROM deduped_invntry
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID
),
deduped_audit AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS audit_date,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      {{audit_date_filter}}
      {{lob_filter}}
      {{associate_filter_audit}}
),
audit_summary AS (
    SELECT 
        AUDIT_SUBJECT_ID AS USERID,
        COUNT(DISTINCT CASE WHEN PYSTATUSWORK IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN CASE_TO_AUDIT END) AS open_audits,
        COUNT(DISTINCT CASE WHEN PYSTATUSWORK = 'Resolved-Completed' THEN CASE_TO_AUDIT END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN PYSTATUSWORK IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN CASE_TO_AUDIT END) AS pending_audits,
        COUNT(DISTINCT CASE_TO_AUDIT) AS total_audits
    FROM deduped_audit a
    INNER JOIN deduped_invntry i
        ON a.CASE_TO_AUDIT = i.PYID  -- CORRECTED: Case-level join (was missing)
        AND i.rn = 1
    WHERE a.rn = 1
    GROUP BY a.AUDIT_SUBJECT_ID
),
user_profile AS (
    SELECT 
        USERID,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE 1=1
      {{user_profile_associate_filter}}
)
SELECT 
    u.USERID,
    u.USERNAME AS associate_name,
    COALESCE(a.open_audits, 0) AS open_audits,
    COALESCE(a.closed_audits, 0) AS closed_audits,
    COALESCE(a.pending_audits, 0) AS pending_audits,
    COALESCE(w.cases_resolved, 0) AS total_cases_resolved,
    COALESCE(a.total_audits, 0) AS total_audits,
    ROUND((COALESCE(a.total_audits, 0) * 100.0 / NULLIF(w.cases_resolved, 0)), 2) AS audit_sample_pct
FROM user_profile u
LEFT JOIN work_items w ON u.USERID = w.USERID
LEFT JOIN audit_summary a ON u.USERID = a.USERID
WHERE u.rn = 1
"""

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)


def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Filter for resolved items date range (uses PYRESOLVEDTIMESTAMP)"""
    filters = []
    if start_date:
        filters.append(f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'")
    if end_date:
        # Add one day to end_date to make it inclusive
        filters.append(f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)")
    return "\n      ".join(filters)


def build_audit_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Filter for audit date range (uses PXCREATEDATETIME)"""
    if start_date and end_date:
        return (
            f"AND PXCREATEDATETIME >= '{start_date}' "
            f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PXCREATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Filter for Line of Business"""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"




def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "USERID") -> str:
    """Generic filter for specific associates with configurable column name.
    
    Args:
        frontline_associate_ids: List of associate IDs to filter
        column: Column name to filter on (e.g., 'USERID', 'PYRESOLVEDUSERID', 'AUDIT_SUBJECT_ID')
    """
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{associate_ids_str}')"
    return ""


def build_user_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Filter for user profile LOGINDATE"""
    if start_date and end_date:
        return (
            f"AND LOGINDATE >= '{start_date}' "
            f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND LOGINDATE >= '{start_date}'"
    elif end_date:
        return f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def execute_query(engine, query: str, limit: int = 100):
    return engine.execute_query(query, limit=limit)


def get_sort_value(record: AuditSamplePctRecord, sort_by: Optional[str]):
    sort_key_map = {
        "date_range": record.date_range,
        "open_audits": record.open_audits,
        "closed_audits": record.closed_audits,
        "pending_audits": record.pending_audits,
        "total_cases_resolved": record.total_cases_resolved,
    }
    return sort_key_map.get((sort_by or "").lower(), record.date_range)

@router.post(
    "/audit-sample-pct-drilldown",
    response_model=AuditSamplePctDrilldownPaginatedResponse,
    summary="Get Audit Sample Percentage Drilldown",
    description="""
Retrieve audit sample percentage summary data showing key metrics.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **audit_status** (optional): Audit status filter (e.g., 'Open', 'Closed', 'Pending')
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields:**
- **date_range**: Date range for the audit period (e.g., "1/1/2026 — 1/7/2026")
- **open_audits**: Number of open audits (e.g., 35)
- **closed_audits**: Number of closed audits (e.g., 23)
- **pending_audits**: Number of pending audits (e.g., 3)
- **total_cases_resolved**: Total cases resolved by FL associate during previous week (e.g., 320)

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (resolved cases data)
- COB_AI_AUDIT_PROFILE (audit status data)
""",
)
async def get_audit_sample_pct_drilldown(request: AuditSamplePctDrilldownPaginatedRequest) -> AuditSamplePctDrilldownPaginatedResponse:
    """audit sample pct drilldown endpoint - direct query execution."""
    return await execute_audit_sample_pct_drilldown_query(request)


async def execute_audit_sample_pct_drilldown_query(request: AuditSamplePctDrilldownPaginatedRequest) -> AuditSamplePctDrilldownPaginatedResponse:
    """Execute audit sample pct drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        
        # Build filters
        date_filter = build_date_filter(request.start_date, request.end_date)
        audit_date_filter = build_audit_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(request.lob)
        user_date_filter = build_user_date_filter(request.start_date, request.end_date)
        manager_filter = build_manager_filter(request.manager_ids)
        director_filter = build_director_filter(request.director_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        associate_filter_invntry = build_associate_filter(request.frontline_associate_ids, column="PYRESOLVEDUSERID")
        associate_filter_audit = build_associate_filter(request.frontline_associate_ids, column="AUDIT_SUBJECT_ID")
        user_profile_associate_filter = build_associate_filter(request.frontline_associate_ids, column="USERID")
        
        engine = connection_manager.get_engine()
        
        # Format query with filters
        query = AUDIT_SAMPLE_PCT_QUERY.format(
            date_filter=date_filter,
            audit_date_filter=audit_date_filter,
            lob_filter=lob_filter,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter,
            director_filter=director_filter,
            user_date_filter=user_date_filter,
            manager_filter_user=manager_filter_user,
            associate_filter_user=associate_filter_user,
            associate_filter_audit=associate_filter_audit,
            user_profile_associate_filter=user_profile_associate_filter
        )
        
        # Execute query
        records = await engine.execute_query_async(query, limit=1000000)
        
        # Aggregate results across all associates
        open_audits = 0
        closed_audits = 0
        pending_audits = 0
        total_cases_resolved = 0
        
        if records:
            for record in records:
                open_audits += int(record.get("OPEN_AUDITS", 0))
                closed_audits += int(record.get("CLOSED_AUDITS", 0))
                pending_audits += int(record.get("PENDING_AUDITS", 0))
                total_cases_resolved += int(record.get("TOTAL_CASES_RESOLVED", 0))
        
        # Format date range
        date_range = ""
        if request.start_date and request.end_date:
            start_formatted = format_date_mmddyyyy(request.start_date)
            end_formatted = format_date_mmddyyyy(request.end_date)
            date_range = f"{start_formatted} — {end_formatted}"
        elif request.start_date:
            date_range = f"{format_date_mmddyyyy(request.start_date)} — Present"
        elif request.end_date:
            date_range = f"Up to {format_date_mmddyyyy(request.end_date)}"
        else:
            date_range = "All Time"
        
        # Create summary record with real data
        summary_record = AuditSamplePctRecord(
            date_range=date_range,
            open_audits=open_audits,
            closed_audits=closed_audits,
            pending_audits=pending_audits,
            total_cases_resolved=total_cases_resolved
        )
        
        # Return single summary record (not paginated in traditional sense)
        audit_sample_records = [summary_record]
        audit_sample_records.sort(
            key=lambda x: get_sort_value(x, request.sort_by),
            reverse=str(request.sort_direction).lower() != "asc"
        )
        total_records = 1
        total_pages = 1
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=False,
            has_previous=False
        )

        tooltips = {
            "date_range": "Date range for the audit sample period",
            "open_audits": "Number of audits currently in progress",
            "closed_audits": "Number of audits that have been completed",
            "pending_audits": "Number of audits awaiting review or action",
            "total_cases_resolved": "Total number of cases resolved by frontline associates during the previous week"
        }

        return AuditSamplePctDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=audit_sample_records,
            message="Audit sample percentage summary retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated audit sample percentage drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return AuditSamplePctDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve audit sample percentage summary: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/audit-sample-pct-drilldown/download-excel",
    summary="Download Audit Sample Percentage Drilldown as Excel (Director)",
    description="""
Download complete audit sample percentage drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all audit sample percentage records
""",
)
async def download_audit_sample_pct_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> Response:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Build filters
        date_filter = build_date_filter(request.start_date, request.end_date)
        audit_date_filter = build_audit_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(request.lob)
        user_date_filter = build_user_date_filter(request.start_date, request.end_date)
        manager_filter = build_manager_filter(request.manager_ids)
        director_filter = build_director_filter(request.director_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        associate_filter_invntry = build_associate_filter(request.frontline_associate_ids, column="PYRESOLVEDUSERID")
        associate_filter_audit = build_associate_filter(request.frontline_associate_ids, column="AUDIT_SUBJECT_ID")
        user_profile_associate_filter = build_associate_filter(request.frontline_associate_ids, column="USERID")
        
        engine = connection_manager.get_engine()
        
        # Format query with filters
        query = AUDIT_SAMPLE_PCT_QUERY.format(
            date_filter=date_filter,
            audit_date_filter=audit_date_filter,
            lob_filter=lob_filter,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter,
            director_filter=director_filter,
            user_date_filter=user_date_filter,
            manager_filter_user=manager_filter_user,
            associate_filter_user=associate_filter_user,
            associate_filter_audit=associate_filter_audit,
            user_profile_associate_filter=user_profile_associate_filter
        )
        
        # Execute query
        results = await engine.execute_query_async(query, limit=1000000)
    except Exception as e:
        logger.error(f"Excel download error for audit sample pct drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")

    # STEP 3: Generate Excel file
    try:
        
        # Aggregate results across all associates
        open_audits = 0
        closed_audits = 0
        pending_audits = 0
        total_cases_resolved = 0
        
        # Aggregate with field name compatibility
        for row in results:
            open_audits += int(row.get("open_audits") or row.get("OPEN_AUDITS", 0))
            closed_audits += int(row.get("closed_audits") or row.get("CLOSED_AUDITS", 0))
            pending_audits += int(row.get("pending_audits") or row.get("PENDING_AUDITS", 0))
            total_cases_resolved += int(row.get("total_cases_resolved") or row.get("TOTAL_CASES_RESOLVED", 0))
        
        # Format date range
        date_range = f"{format_date_mmddyyyy(request.start_date) if request.start_date else 'N/A'} to {format_date_mmddyyyy(request.end_date) if request.end_date else 'N/A'}"
        
        # Create Excel workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Audit Sample Pct"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Date Range",
            "Open Audits",
            "Closed Audits",
            "Pending Audits",
            "Total Cases Resolved"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data row
        ws.cell(row=2, column=1, value=date_range)
        ws.cell(row=2, column=2, value=open_audits)
        ws.cell(row=2, column=3, value=closed_audits)
        ws.cell(row=2, column=4, value=pending_audits)
        ws.cell(row=2, column=5, value=total_cases_resolved)
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"audit_sample_pct_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for audit sample pct drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
