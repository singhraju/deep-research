import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import StreamingResponse
import httpx
import asyncio

from db import SnowflakeConnectionManager
from schema import (
    AuditScoreDirectorDrilldownRequest,
    AuditScoreDrilldownPaginatedResponse,
    AuditScoreRecord,
    PageResponse,
    DirectorBaseDownloadRequest,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime
from io import BytesIO
import math

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def clean_resolved_status(status: str) -> str:
    """Convert 'Resolved-Completed' to 'Resolved'"""
    if not status:
        return ""
    return "Resolved" if status.startswith("Resolved") else status

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

AUDIT_SCORE_DIRECTOR_PAGINATED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        INVNTRY_TYPE,
        CYCLE_TIME,  -- ADDED: Get CYCLE_TIME directly from inventory
        REPORTTOMANAGERID,  -- ADDED: Manager hierarchy from inventory
        REPORTTODIRECTORID,  -- ADDED: Director hierarchy from inventory
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{invntry_date_filter}}
      {{invntry_lob_filter}}
      {{associate_filter_invntry}}
      {{manager_filter}}
      {{director_filter}}
),
audit_deduped AS (
    -- Deduplicate audit records with all display columns
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PXUPDATEDATETIME::DATE as audit_date,
        PLATFORM,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      {{lob_filter}}
      {{associate_filter_audit}}
)
SELECT 
    a.PYID,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK,
    a.LOB,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    i.CYCLE_TIME,  -- MODIFIED: Get CYCLE_TIME directly from inventory (per work item)
    i.INVNTRY_TYPE
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT  -- Join inventory work item to audit case
    AND a.rn = 1
WHERE i.rn = 1
ORDER BY a.audit_date DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

AUDIT_SCORE_DIRECTOR_DEFAULT_ORDER_BY = "ORDER BY a.audit_date DESC"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "pyid": "a.PYID",
        "work_type": "a.INTAKESOURCESYSTEM",
        "audit_cycle_time": "i.CYCLE_TIME",
        "resolved_status": "a.PYSTATUSWORK",
        "lob": "a.LOB",
        "audit_resolved": "a.audit_date",
        "auditor_domain_id": "a.AUDIT_SUBJECT_ID",
        "platform": "a.PLATFORM",
        "audit_score": "a.AUDIT_SCORE",
        "targeted_audit_type": "a.TARGET_AUDIT",
        "inventory_type": "i.INVNTRY_TYPE",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return AUDIT_SCORE_DIRECTOR_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, a.audit_date DESC, a.PYID"

AUDIT_SCORE_DIRECTOR_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,  -- ADDED: Need this for hierarchy validation
        REPORTTOMANAGERID,  -- ADDED: Manager hierarchy from inventory
        REPORTTODIRECTORID,  -- ADDED: Director hierarchy from inventory
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{invntry_date_filter}}
      {{invntry_lob_filter}}
      {{associate_filter_invntry}}
      {{manager_filter}}
      {{director_filter}}
),
audit_deduped AS (
    -- Deduplicate audit records by (CASE_TO_AUDIT, AUDIT_SUBJECT_ID)
    -- Includes TARGET_AUDIT flag for counting targeted audits
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        PXUPDATEDATETIME::DATE as audit_date,
        TARGET_AUDIT,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Open-FeedbackReview', 'Open-RebuttalReview', 'Open-UpdateAuditCase', 'Resolved-Completed')
      {{lob_filter}}
      {{associate_filter_audit}}
)
SELECT 
    COUNT(DISTINCT a.PYID) as TOTAL_COUNT,
    SUM(CASE WHEN UPPER(a.TARGET_AUDIT) = 'YES' THEN 1 ELSE 0 END) as TARGET_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT  -- Join inventory work item to audit case
    AND a.rn = 1
WHERE i.rn = 1
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for audit table (PXUPDATEDATETIME)"""
    if start_date and end_date:
        return f"AND a.PXUPDATEDATETIME >= '{start_date}' AND a.PXUPDATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_invntry_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for inventory table (PYRESOLVEDTIMESTAMP)"""
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_invntry_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for inventory table"""
    if lob and len(lob) > 0:
        lob_values = "', '".join(lob)
        return f"AND LOB IN ('{lob_values}')"
    return ""

def build_user_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Filter for user profile LOGINDATE"""
    if start_date and end_date:
        return f"AND LOGINDATE >= '{start_date}' AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""

def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""

def build_associate_filter_audit(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for audit table (uses AUDIT_SUBJECT_ID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{frontline_associate_ids_str}')"
    return ""

def build_associate_filter_user(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for user table."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND USERID IN ('{frontline_associate_ids_str}')"
    return ""

@router.post(
    "/audit-score-director-drilldown",
    response_model=AuditScoreDrilldownPaginatedResponse
)
async def get_audit_score_drilldown(request: AuditScoreDirectorDrilldownRequest) -> AuditScoreDrilldownPaginatedResponse:
    """Session-enabled audit score director drilldown endpoint."""
    return await execute_audit_score_director_drilldown_query(request)


async def execute_audit_score_director_drilldown_query(request: AuditScoreDirectorDrilldownRequest) -> AuditScoreDrilldownPaginatedResponse:
    """Execute audit score director drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        director_ids = request.director_ids
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        lob_filter = build_lob_filter(lob)
        invntry_lob_filter = build_invntry_lob_filter(lob)
        date_filter = build_date_filter(start_date, end_date)
        invntry_date_filter = build_invntry_date_filter(start_date, end_date)
        director_filter = build_director_filter(director_ids)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        associate_filter_audit = build_associate_filter_audit(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        count_query = AUDIT_SCORE_DIRECTOR_COUNT_QUERY.format(
            invntry_date_filter=invntry_date_filter,
            invntry_lob_filter=invntry_lob_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
            associate_filter_audit=associate_filter_audit
        )
        data_query = AUDIT_SCORE_DIRECTOR_PAGINATED_QUERY.format(
            invntry_date_filter=invntry_date_filter,
            invntry_lob_filter=invntry_lob_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
            associate_filter_audit=associate_filter_audit,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            AUDIT_SCORE_DIRECTOR_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        
        # Run COUNT and DATA queries in parallel for better performance
        count_result, records = await asyncio.gather(
            engine.execute_query_async(count_query, limit=1),
            engine.execute_query_async(data_query, limit=page_limit)
        )
        
        total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        target_audit_count = count_result[0].get("TARGET_AUDIT_COUNT", 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        audit_scores = [
            AuditScoreRecord(
                pyid=record.get("PYID") or "",
                work_type=record.get("INTAKESOURCESYSTEM") or "",
                audit_cycle_time=format_cycle_time(record.get("CYCLE_TIME")),
                resolved_status=clean_resolved_status(record.get("PYSTATUSWORK")),
                lob=record.get("LOB") or "",
                audit_resolved=format_date_mmddyyyy(record.get("AUDIT_DATE")),
                auditor_domain_id=record.get("AUDIT_SUBJECT_ID") or "",
                platform=record.get("PLATFORM") or "",
                audit_score=f"{int(record.get('AUDIT_SCORE'))}%" if record.get("AUDIT_SCORE") else "0%",
                targeted_audit_type=record.get("TARGET_AUDIT") or "N/A",
                inventory_type=record.get("INVNTRY_TYPE") or "N/A"
            )
            for record in records
        ] if records else []

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "pyid": "Unique identifier for the audited case",
            "work_type": "Source system or type of work item that was audited",
            "audit_cycle_time": "Time from case creation to audit completion in hh:mm:ss format",
            "resolved_status": "Current status of the audited work item",
            "lob": "Line of Business associated with the audited case",
            "audit_resolved": "Date when the audit was completed",
            "auditor_domain_id": "User ID of the auditor who performed the audit",
            "platform": "Platform where the case was processed",
            "audit_score": "Quality score achieved for this audit as a percentage",
            "targeted_audit_type": "Type of audit performed (targeted vs random)",
            "inventory_type": "Type of inventory or work category"
        }

        return AuditScoreDrilldownPaginatedResponse(
            status="success",
            screen_id="audit_score_director",
            user_id=request.user_id,
            page=page_response,
            records=audit_scores,
            completed_audit_work_items=total_records,
            target_audit_count=target_audit_count,
            message="Audit score director records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated audit score director drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return AuditScoreDrilldownPaginatedResponse(
            status="error",
            screen_id="audit_score_director",
            user_id=request.user_id,
            page=page_response,
            records=[],
            completed_audit_work_items=0,
            target_audit_count=0,
            message=f"Failed to retrieve audit score director records: {str(e)}"
        )


@router.post(
    "/audit-score-director-drilldown/download-excel",
    summary="Download Audit Score Director Drilldown as Excel",
    description="""
Download complete audit score director drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all audit score records
""",
)
async def download_audit_score_director_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> StreamingResponse:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
    try:
            # Build filters
        lob = request.lob
        director_ids = request.director_ids
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        lob_filter = build_lob_filter(lob)
        invntry_lob_filter = build_invntry_lob_filter(lob)
        invntry_date_filter = build_invntry_date_filter(request.start_date, request.end_date)
        director_filter = build_director_filter(director_ids)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        associate_filter_audit = build_associate_filter_audit(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
            # Query with high limit for download (no pagination needed)
        download_query = AUDIT_SCORE_DIRECTOR_PAGINATED_QUERY.format(
            invntry_date_filter=invntry_date_filter,
            invntry_lob_filter=invntry_lob_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
            associate_filter_audit=associate_filter_audit,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
    except Exception as e:
            logger.error(f"Excel download error for audit score director drilldown: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
    
    # STEP 3: Generate Excel file
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "Audit Score Director"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Audit Cycle Time",
            "Resolved Status",
            "LOB",
            "Audit Resolved",
            "Platform",
            "Audit Score",
            "Targeted Audit Type",
            "Inventory Type"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("pyid") or row.get("PYID", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("work_type") or row.get("INTAKESOURCESYSTEM", "")))
            cycle_time = row.get("audit_cycle_time") or row.get("CYCLE_TIME")
            if isinstance(cycle_time, str) and ":" in str(cycle_time):
                ws.cell(row=row_num, column=3, value=cycle_time)
            else:
                ws.cell(row=row_num, column=3, value=format_cycle_time(cycle_time) if cycle_time else "00:00:00")
            resolved_status = row.get("resolved_status") or row.get("PYSTATUSWORK", "")
            ws.cell(row=row_num, column=4, value=clean_resolved_status(str(resolved_status)))
            ws.cell(row=row_num, column=5, value=str(row.get("lob") or row.get("LOB", "")))
            audit_date = row.get("audit_resolved") or row.get("AUDIT_DATE")
            ws.cell(row=row_num, column=6, value=format_date_mmddyyyy(str(audit_date)) if audit_date else "")
            ws.cell(row=row_num, column=7, value=str(row.get("platform") or row.get("PLATFORM", "")))
            ws.cell(row=row_num, column=8, value=str(row.get("audit_score") or row.get("AUDIT_SCORE", "")))
            ws.cell(row=row_num, column=9, value=str(row.get("targeted_audit_type") or row.get("TARGET_AUDIT", "")))
            ws.cell(row=row_num, column=10, value=str(row.get("inventory_type") or row.get("INVNTRY_TYPE", "N/A")))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"audit_score_director_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for audit score director drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
