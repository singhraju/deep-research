import logging
import math
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import httpx

from schema import (
    CapacityInsightDrilldownPaginatedRequest,
    CapacityInsightDrilldownPaginatedResponse,
    CapacityInsightRecord,
    PageResponse,
    DirectorBaseDownloadRequest,
)
import config
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from db import SnowflakeConnectionManager
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "USERID") -> str:
    """Build associate filter with flexible column parameter."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{frontline_associate_ids_str}')"
    return ""

def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PXUPDATEDATETIME") -> str:
    """Build date filter for queries."""
    if start_date and end_date:
        return f"AND {date_column} >= '{start_date}' AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_lob_filter(lob_values: Optional[List[str]] = None) -> str:
    """Build LOB (Line of Business) filter."""
    if lob_values and len(lob_values) > 0:
        lob_values_str = "', '".join(lob_values)
        return f"AND LOB IN ('{lob_values_str}')"
    return ""

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)


def get_capacity_insight_sort_value(item, sort_by: Optional[str]):
    sort_key = (sort_by or "").lower()
    sort_values = {
        "month_prior_year": item["sort_key"],
        "total_required_hours": item["total_required_hours"],
        "total_available_hours": item["total_available_hours"],
        "fte_gap": item["fte_gap"],
        "avg_available_hours_daily": item["avg_available_hours_daily"],
        "total_pto_hours": item["total_pto_hours"],
        "total_uto_hours": item["total_uto_hours"],
        "in_year_required_hours_prediction": item["record"].in_year_required_hours_prediction,
        "in_year_available_hours": item["record"].in_year_available_hours,
        "variance": item["record"].variance,
    }
    return sort_values.get(sort_key, item["sort_key"])

# Capacity Insight Drilldown Query - Enhanced version with all required fields
CAPACITY_INSIGHT_DRILLDOWN_QUERY = f"""
WITH
date_range_config AS (
    SELECT
        '{{start_date}}'::DATE AS period_start,
        '{{end_date}}'::DATE AS period_end
),
grouping_logic AS (
    SELECT
        DATEDIFF(day, period_start, period_end) + 1 AS total_days,
        'monthly' AS grouping_type  -- Always use monthly grouping for capacity insights
    FROM date_range_config
),
date_spine AS (
    SELECT DATEADD(DAY, SEQ4(), drc.period_start) AS spine_date
    FROM TABLE(GENERATOR(ROWCOUNT => 500))
    CROSS JOIN date_range_config drc
    WHERE DATEADD(DAY, SEQ4(), drc.period_start) <= drc.period_end
),
date_periods AS (
    SELECT DISTINCT
        DATE_TRUNC('MONTH', spine_date) AS period_date,  -- Always monthly for drilldown
        LAST_DAY(DATE_TRUNC('MONTH', spine_date)) AS period_end_date,
        EXTRACT(YEAR FROM spine_date) AS period_year,
        EXTRACT(MONTH FROM spine_date) AS period_month
    FROM date_spine
),
date_spine_for_business_days AS (
    SELECT
        dp.period_date,
        dp.period_end_date,
        DATEADD(DAY, gs.SEQ, dp.period_date) AS business_date
    FROM date_periods dp
    CROSS JOIN (
        SELECT SEQ4() AS SEQ 
        FROM TABLE(GENERATOR(ROWCOUNT => 400))
    ) gs
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA holidays
        ON DATEADD(DAY, gs.SEQ, dp.period_date) = holidays.DATE
    WHERE DATEADD(DAY, gs.SEQ, dp.period_date) <= dp.period_end_date
      AND DATEADD(DAY, gs.SEQ, dp.period_date) <= (SELECT period_end FROM date_range_config)  -- Only count days within requested range
      AND DATEADD(DAY, gs.SEQ, dp.period_date) >= (SELECT period_start FROM date_range_config)  -- Only count days within requested range
      AND DAYNAME(DATEADD(DAY, gs.SEQ, dp.period_date)) NOT IN ('Sat', 'Sun')
      AND holidays.DATE IS NULL  -- Exclude holidays
),
business_days_per_period AS (
    SELECT
        dp.period_date,
        dp.period_end_date,
        COALESCE(bd_count.business_days, 0) AS business_days
    FROM date_periods dp
    LEFT JOIN (
        SELECT 
            period_date,
            COUNT(*) AS business_days
        FROM date_spine_for_business_days
        GROUP BY period_date
    ) bd_count ON dp.period_date = bd_count.period_date
),
productive_hrs AS (
    -- Total Fuse Time Hours per day - Dynamic based on past 90 days from end date
    -- Using logic: (Total System Time - Non Productive Time) / 3600.0 to convert seconds to hours
    SELECT
        ROUND(AVG(
            SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT
            + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0
            + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
        ), 2) AS avg_hrs_per_day
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
      AND u.TOTALSYSTEMTIME IS NOT NULL
      AND u.LOGINDATE BETWEEN DATEADD(day, -90, (SELECT period_end FROM date_range_config)) AND (SELECT period_end FROM date_range_config)
),
avail_fte_by_period AS (
    SELECT
        DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE)) AS period_date,  -- Always monthly
        COUNT(DISTINCT w.EMPLOYEE_DOMAIN_ID) AS available_fte
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT period_start FROM date_range_config) AND (SELECT period_end FROM date_range_config)
    GROUP BY DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE))
),
active_associates AS (
    SELECT DISTINCT
        w.EMPLOYEE_DOMAIN_ID AS USERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT period_start FROM date_range_config) AND (SELECT period_end FROM date_range_config)
),
pto_latest_records AS (
    SELECT
        w.EMPLOYEE_DOMAIN_ID,
        TRY_CAST(w.TIME_OFF_DATE AS DATE) AS TIME_OFF_DATE,
        w.HOURS,
        w.TIME_OFF_TYPE,
        w.TIME_OFF_ENTRY_UNIQUE_KEY,
        ROW_NUMBER() OVER (
            PARTITION BY w.EMPLOYEE_DOMAIN_ID, w.TIME_OFF_DATE, w.TIME_OFF_ENTRY_UNIQUE_KEY
            ORDER BY TRY_CAST(w.ASOFTODAY AS DATE) DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    INNER JOIN active_associates a ON w.EMPLOYEE_DOMAIN_ID = a.USERID
    WHERE TRY_CAST(w.TIME_OFF_DATE AS DATE) IS NOT NULL
      AND TRY_CAST(w.TIME_OFF_DATE AS DATE) BETWEEN (SELECT period_start FROM date_range_config) AND (SELECT period_end FROM date_range_config)
      AND w.STATUS = 'Approved'
      AND w.HOURS IS NOT NULL
      AND (w.TIME_OFF_TYPE ILIKE '%Paid Time Off%' 
           OR w.TIME_OFF_TYPE ILIKE '%Non Paid Time%'
           OR w.TIME_OFF_TYPE ILIKE '%Sick Time%'
           OR w.TIME_OFF_TYPE ILIKE '%Other Paid Time%'
           OR w.TIME_OFF_TYPE ILIKE '%Paid Parental Leave%'
           OR w.TIME_OFF_TYPE ILIKE '%Wellness Days%'
           OR w.TIME_OFF_TYPE ILIKE '%On Leave%'
           OR w.TIME_OFF_TYPE ILIKE '%Critical Care Leave%')
),
pto_by_employee_by_day AS (
    SELECT
        EMPLOYEE_DOMAIN_ID,
        TIME_OFF_DATE,
        TIME_OFF_TYPE,
        SUM(HOURS) AS net_hours_per_day
    FROM pto_latest_records
    WHERE rn = 1
    GROUP BY EMPLOYEE_DOMAIN_ID, TIME_OFF_DATE, TIME_OFF_TYPE
),
-- Separate PTO calculation (all except "Non Paid Time")
pto_by_employee_by_period AS (
    SELECT
        DATE_TRUNC('MONTH', pto.TIME_OFF_DATE) AS period_date,  -- Always monthly
        pto.EMPLOYEE_DOMAIN_ID,
        SUM(pto.net_hours_per_day) AS total_pto_hours_per_employee
    FROM pto_by_employee_by_day pto
    WHERE pto.net_hours_per_day > 0
      AND pto.TIME_OFF_TYPE NOT ILIKE '%Non Paid Time%'
    GROUP BY DATE_TRUNC('MONTH', pto.TIME_OFF_DATE), pto.EMPLOYEE_DOMAIN_ID
),
pto_total_by_period AS (
    SELECT
        period_date,
        SUM(total_pto_hours_per_employee) AS total_pto_hours
    FROM pto_by_employee_by_period
    GROUP BY period_date
),
-- Separate UTO calculation (only "Non Paid Time")
uto_by_employee_by_period AS (
    SELECT
        DATE_TRUNC('MONTH', uto.TIME_OFF_DATE) AS period_date,  -- Always monthly
        uto.EMPLOYEE_DOMAIN_ID,
        SUM(uto.net_hours_per_day) AS total_uto_hours_per_employee
    FROM pto_by_employee_by_day uto
    WHERE uto.net_hours_per_day > 0
      AND uto.TIME_OFF_TYPE ILIKE '%Non Paid Time%'
    GROUP BY DATE_TRUNC('MONTH', uto.TIME_OFF_DATE), uto.EMPLOYEE_DOMAIN_ID
),
uto_total_by_period AS (
    SELECT
        period_date,
        SUM(total_uto_hours_per_employee) AS total_uto_hours
    FROM uto_by_employee_by_period
    GROUP BY period_date
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.CYCLE_TIME,
        DATE(inv.pxcreatedatetime) AS resolve_date,
        DATE_TRUNC('WEEK', inv.pxcreatedatetime) AS week_start,
        DATE_TRUNC('MONTH', inv.pxcreatedatetime) AS month_start,
        DATE_TRUNC('QUARTER', inv.pxcreatedatetime) AS quarter_start,
        DATE_TRUNC('YEAR', inv.pxcreatedatetime) AS year_start,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS intakesourcesystem,
        ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY inv.pxupdatedatetime DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE pxcreatedatetime >= '{{start_date}}' AND pxcreatedatetime < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND (LOB IN ('Commercial', 'EGR', 'GRS', 'MMP', 'MedSupp', 'Medicaid', 'Medicare') OR LOB IS NULL)
),
avg_cycle_time AS (
    SELECT
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS intakesourcesystem,
        ROUND(AVG(inv.CYCLE_TIME) / 3600.0, 2) AS avg_cycle_time_hrs
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.CYCLE_TIME IS NOT NULL
      AND inv.PXCREATEDATETIME BETWEEN DATEADD(DAY, -90, (SELECT period_end FROM date_range_config)) AND DATEADD(DAY, 1, (SELECT period_end FROM date_range_config))
    GROUP BY COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown')
),
actual_receipts_by_period AS (
    -- Completed Items = No of work items resolved in the period (Distinct PYID) by intake source system
    SELECT
        month_start AS period_date,  -- Always use monthly for drilldown
        intakesourcesystem,
        COUNT(DISTINCT PYID) AS actual_receipts
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY month_start, intakesourcesystem
),
fte_calculation AS (
    -- Total Fuse Time Hours/day = Dynamic based on past 90 days (Total System Time - Non Productive Time)
    -- For Daily: Total Available Hours per FTE = Total Fuse Time Hours/day * 1 day
    -- For Weekly/Monthly/Quarterly: Total Available Hours per FTE = Total Fuse Time Hours/day * business days in period
    -- Completed Items = No of work items resolved in the period (Distinct PYID)
    -- Total Work Hours Required = Completed Items * Cycle Time (90 days average in hours)
    -- Required FTE = Total Work Hours Required / Total Available Hours per FTE
    SELECT
        ar.period_date,
        ar.intakesourcesystem,
        ar.actual_receipts AS actual_receipts,
        COALESCE(ct.avg_cycle_time_hrs, 0) AS cycle_time_hrs,
        COALESCE((SELECT avg_hrs_per_day FROM productive_hrs), 6.5) AS productive_hrs_per_day,
        bd.business_days,
        af.available_fte,
        -- Total Available Hours per FTE = Total Fuse Time Hours/day * Number of business days
        ROUND(COALESCE((SELECT avg_hrs_per_day FROM productive_hrs), 6.5) * bd.business_days, 2) AS total_available_hrs_per_fte,
        -- Total Work Hours Required = Recieved Items * Cycle Time (hours)
        ROUND(ar.actual_receipts * COALESCE(ct.avg_cycle_time_hrs, 0), 2) AS total_work_hours_required
    FROM actual_receipts_by_period ar
    LEFT JOIN avg_cycle_time ct ON ar.intakesourcesystem = ct.intakesourcesystem
    LEFT JOIN business_days_per_period bd ON ar.period_date = bd.period_date
    LEFT JOIN avail_fte_by_period af ON ar.period_date = af.period_date
),
fte_summary AS (
    SELECT
        fc.period_date,
        -- Aggregate across all intake source systems
        SUM(fc.actual_receipts) AS actual_receipts,
        ROUND(SUM(fc.total_work_hours_required), 2) AS total_work_hours_required,
        MAX(fc.total_available_hrs_per_fte) AS total_available_hrs_per_fte,
        MAX(fc.productive_hrs_per_day) AS productive_hrs_per_day,
        -- Weighted average cycle time
        ROUND(SUM(fc.total_work_hours_required) / NULLIF(SUM(fc.actual_receipts), 0), 2) AS weighted_cycle_time_hrs,
        -- Required FTE = Total Work Hours Required / Total Available Hours per FTE
        CEIL(
            SUM(fc.total_work_hours_required) / NULLIF(MAX(fc.total_available_hrs_per_fte), 0)
        ) AS required_fte
    FROM fte_calculation fc
    GROUP BY fc.period_date
)
SELECT
    TO_VARCHAR(dp.period_date, 'Mon') AS period_label,  -- Always show month name
    EXTRACT(YEAR FROM dp.period_date) AS period_year,
    EXTRACT(MONTH FROM dp.period_date) AS period_month,
    COALESCE(fs.required_fte, 0) AS required_fte,
    COALESCE(fs.total_work_hours_required, 0) AS total_required_hours,
    COALESCE(fs.productive_hrs_per_day, 6.5) AS productive_hrs_per_day,
    COALESCE(bd.business_days, 1) AS business_days,
    COALESCE(pto.total_pto_hours, 0) AS total_pto_hours,
    COALESCE(uto.total_uto_hours, 0) AS total_uto_hours,
    COALESCE(af.available_fte, 0) AS available_fte,
    ROUND(
        (COALESCE(af.available_fte, 0) * COALESCE(bd.business_days, 1) * 8) - 
        COALESCE(pto.total_pto_hours, 0) - COALESCE(uto.total_uto_hours, 0),
        2
    ) AS total_available_hours
FROM date_periods dp
LEFT JOIN fte_summary fs ON dp.period_date = fs.period_date
INNER JOIN avail_fte_by_period af ON dp.period_date = af.period_date  -- Only show months with ASOFTODAY data
LEFT JOIN business_days_per_period bd ON dp.period_date = bd.period_date
LEFT JOIN pto_total_by_period pto ON dp.period_date = pto.period_date
LEFT JOIN uto_total_by_period uto ON dp.period_date = uto.period_date
ORDER BY EXTRACT(YEAR FROM dp.period_date), EXTRACT(MONTH FROM dp.period_date)
"""

@router.post(
    "/capacity-insight-drilldown",
    response_model=CapacityInsightDrilldownPaginatedResponse,
    summary="Get Capacity Insight Drilldown",
    description="""
Retrieve paginated list of capacity insight data for detailed table display.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **month_prior_year**: Month (Prior Year)
- **total_required_hours**: Total Required Hours
- **total_available_hours**: Total Available Hours
- **fte_gap**: FTE Gap
- **avg_available_hours_daily**: Avg Available Hours Daily
- **total_pto_hours**: Total PTO Hours
- **total_uto_hours**: Total UTO Hours
- **in_year_required_hours_prediction**: In Year Required Hours (Prediction)
- **in_year_available_hours**: In Year Available Hours
- **variance**: Variance

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Source:** COB_AI_INVNTRY_PROFILE, COB_AI_USER_PROFILE, COB_AI_WORKDAY_HIST, COB_AI_HOLIDAY_DATA
""",
)
async def get_capacity_insight_drilldown(request: CapacityInsightDrilldownPaginatedRequest) -> CapacityInsightDrilldownPaginatedResponse:
    """Session-enabled capacity insight drilldown endpoint with in-memory pagination."""
    return await execute_capacity_insight_drilldown_query(request)


async def execute_capacity_insight_drilldown_query(request: CapacityInsightDrilldownPaginatedRequest) -> CapacityInsightDrilldownPaginatedResponse:
    """Execute capacity insight drilldown query logic."""
    try:
        page_limit = request.page_size
        page = request.page
        
        # Build filters
        # Use director_ids if provided, otherwise use logged-in user_id
        director_ids_to_filter = request.director_ids 
        director_filter = build_director_filter(director_ids_to_filter)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter(request.frontline_associate_ids, column="PYRESOLVEDUSERID")
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        associate_filter_workday = build_associate_filter(request.frontline_associate_ids, column="EMPLOYEE_DOMAIN_ID")
        date_filter = build_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(request.lob)
        start_date = request.start_date
        end_date = request.end_date
        engine = connection_manager.get_engine()
        
        # Format and execute query
        formatted_query = CAPACITY_INSIGHT_DRILLDOWN_QUERY.format(
            start_date=start_date,
            end_date=end_date,
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter_invntry,
            associate_filter_user=associate_filter_user,
            associate_filter_workday=associate_filter_workday
        )
        print(formatted_query)
        logger.info(f"Executing capacity insight drilldown query for directors: {director_ids_to_filter}, managers: {request.manager_ids}, date range: {start_date} to {end_date}")
        query_results = await engine.execute_query_async(formatted_query, limit=100)
        
        # Transform query results into drilldown records
        all_records = []
        for r in query_results:
            period_label = r.get("PERIOD_LABEL", "")
            period_year = int(r.get("PERIOD_YEAR", 0) or 0)
            period_month = int(r.get("PERIOD_MONTH", 0) or 0)
            required_fte = float(r.get("REQUIRED_FTE", 0) or 0)
            available_fte = float(r.get("AVAILABLE_FTE", 0) or 0)
            total_required_hours = float(r.get("TOTAL_REQUIRED_HOURS", 0) or 0)
            total_available_hours = float(r.get("TOTAL_AVAILABLE_HOURS", 0) or 0)
            total_pto_hours = float(r.get("TOTAL_PTO_HOURS", 0) or 0)
            total_uto_hours = float(r.get("TOTAL_UTO_HOURS", 0) or 0)
            business_days = int(r.get("BUSINESS_DAYS", 1) or 1)
            
            # Calculate derived fields
            fte_gap = available_fte - required_fte
            avg_available_hours_daily = total_available_hours / business_days if business_days > 0 else 0
            
            all_records.append({
                "sort_key": (period_year, period_month),
                "total_required_hours": total_required_hours,
                "total_available_hours": total_available_hours,
                "fte_gap": fte_gap,
                "avg_available_hours_daily": avg_available_hours_daily,
                "total_pto_hours": total_pto_hours,
                "total_uto_hours": total_uto_hours,
                "record": CapacityInsightRecord(
                    month_prior_year=period_label,
                    total_required_hours=str(round(total_required_hours, 2)),
                    total_available_hours=str(round(total_available_hours, 2)),
                    fte_gap=str(round(fte_gap, 2)),
                    avg_available_hours_daily=str(round(avg_available_hours_daily, 2)),
                    total_pto_hours=str(round(total_pto_hours, 2)),
                    total_uto_hours=str(round(total_uto_hours, 2)),
                    in_year_required_hours_prediction="N/A",
                    in_year_available_hours="N/A",
                    variance="N/A"
                )
            })
        
        sort_by = request.sort_by
        sort_reverse = str(request.sort_direction).lower() == "desc"
        all_records.sort(
            key=lambda x: get_capacity_insight_sort_value(x, sort_by),
            reverse=sort_reverse if sort_by else False
        )
        sorted_records = [item["record"] for item in all_records]
        
        total_records = len(sorted_records)
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        capacity_insight_records = sorted_records
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "month_prior_year": "Month from prior year for comparison",
            "total_required_hours": "Total hours required for the month",
            "total_available_hours": "Total hours available for work in the month",
            "fte_gap": "Full-Time Equivalent gap between required and available capacity",
            "avg_available_hours_daily": "Average number of hours available per day",
            "total_pto_hours": "Total Paid Time Off hours",
            "total_uto_hours": "Total Unpaid Time Off hours",
            "in_year_required_hours_prediction": "Predicted in-year required hours",
            "in_year_available_hours": "In-year available hours",
            "variance": "Variance between required and available hours"
        }

        return CapacityInsightDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=capacity_insight_records,
            message="Capacity insight records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated capacity insight drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return CapacityInsightDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve capacity insight records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/capacity-insight-drilldown/download-excel",
    summary="Download Capacity Insight Drilldown as Excel (Director)",
    description="""
Download complete capacity insight drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all capacity insight records
""",
)
async def download_capacity_insight_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> StreamingResponse:
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters and execute query
        # Use director_ids if provided, otherwise use logged-in user_id
        director_ids_to_filter = request.director_ids
        director_filter = build_director_filter(director_ids_to_filter)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter(request.frontline_associate_ids, column="PYRESOLVEDUSERID")
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        associate_filter_workday = build_associate_filter(request.frontline_associate_ids, column="EMPLOYEE_DOMAIN_ID")
        date_filter = build_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(request.lob)
        engine = connection_manager.get_engine()
        
        formatted_query = CAPACITY_INSIGHT_DRILLDOWN_QUERY.format(
            start_date=start_date,
            end_date=end_date,
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter_invntry,
            associate_filter_user=associate_filter_user,
            associate_filter_workday=associate_filter_workday
        )
        
        logger.info(f"Executing Excel download query for directors: {director_ids_to_filter}, managers: {request.manager_ids}, date range: {start_date} to {end_date}")
        query_results = await engine.execute_query_async(formatted_query, limit=100)
        total_records = len(query_results)

        wb = Workbook()
        ws = wb.active
        ws.title = "Capacity Insight Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Month (Prior Year)",
            "Total Required Hours",
            "Total Available Hours",
            "FTE Gap",
            "Avg Available Hours Daily",
            "Total PTO Hours",
            "Total UTO Hours",
            "In Year Required Hours (Prediction)",
            "In Year Available Hours",
            "Variance"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows from query results
        for row_num, r in enumerate(query_results, start=2):
            period_label = r.get("PERIOD_LABEL", "")
            required_fte = float(r.get("REQUIRED_FTE", 0) or 0)
            available_fte = float(r.get("AVAILABLE_FTE", 0) or 0)
            total_required_hours = float(r.get("TOTAL_REQUIRED_HOURS", 0) or 0)
            total_available_hours = float(r.get("TOTAL_AVAILABLE_HOURS", 0) or 0)
            total_pto_hours = float(r.get("TOTAL_PTO_HOURS", 0) or 0)
            total_uto_hours = float(r.get("TOTAL_UTO_HOURS", 0) or 0)
            business_days = int(r.get("BUSINESS_DAYS", 1) or 1)
            
            fte_gap = available_fte - required_fte
            avg_available_hours_daily = total_available_hours / business_days if business_days > 0 else 0
            
            ws.cell(row=row_num, column=1, value=period_label)
            ws.cell(row=row_num, column=2, value=round(total_required_hours, 2))
            ws.cell(row=row_num, column=3, value=round(total_available_hours, 2))
            ws.cell(row=row_num, column=4, value=round(fte_gap, 2))
            ws.cell(row=row_num, column=5, value=round(avg_available_hours_daily, 2))
            ws.cell(row=row_num, column=6, value=round(total_pto_hours, 2))
            ws.cell(row=row_num, column=7, value=round(total_uto_hours, 2))
            ws.cell(row=row_num, column=8, value="N/A")  # in_year_required_hours_prediction
            ws.cell(row=row_num, column=9, value="N/A")  # in_year_available_hours
            ws.cell(row=row_num, column=10, value="N/A")  # variance
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"capacity_insight_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for capacity insight drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
