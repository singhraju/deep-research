import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import StreamingResponse
import httpx
import asyncio

from db import SnowflakeConnectionManager
from schema import (
    CompletedAuditCountDrilldownPaginatedRequest,
    CompletedAuditCountDrilldownPaginatedResponse,
    CompletedAuditCountRecord,
    PageResponse,
    DirectorBaseDownloadRequest,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
import math

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])
connection_manager = SnowflakeConnectionManager()

COMPLETED_AUDIT_COUNT_PAGINATED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        AUDIT_SUBJECT_ID,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
),
deduped_user_profile AS (
    SELECT
        USERID,
        PYREPORTTO,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
audit_cycle_time AS (
    SELECT
        PYRESOLVEDUSERID,
        MAX(CYCLE_TIME) AS CYCLE_TIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE CYCLE_TIME IS NOT NULL
    GROUP BY PYRESOLVEDUSERID
)
SELECT 
    a.PYID AS work_item,
    COALESCE(a.INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(c.CYCLE_TIME::VARCHAR, '0') AS audit_cycle_time,
    COALESCE(a.PYSTATUSWORK, 'N/A') AS audit_resolved_status,
    COALESCE(a.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(a.LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(a.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(a.AUDITOR_ID, 'N/A') AS auditor_id,
    COALESCE(auditor.USERNAME, 'N/A') AS auditor_name,
    COALESCE(a.PLATFORM, 'N/A') AS platform_source_system
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
LEFT JOIN deduped_user_profile auditor
    ON a.AUDITOR_ID = auditor.USERID
    AND auditor.rn = 1
LEFT JOIN audit_cycle_time c
    ON a.AUDIT_SUBJECT_ID = c.PYRESOLVEDUSERID
WHERE i.rn = 1
ORDER BY a.PYRESOLVEDTIMESTAMP DESC
LIMIT {{page_size}} OFFSET {{offset}}
"""

COMPLETED_AUDIT_COUNT_DEFAULT_ORDER_BY = "ORDER BY a.PYRESOLVEDTIMESTAMP DESC"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item": "a.PYID",
        "worktype_category": "a.INTAKESOURCESYSTEM",
        "audit_cycle_time": "c.CYCLE_TIME",
        "audit_resolved_status": "a.PYSTATUSWORK",
        "inventory_type": "a.INVNTRY_TYPE",
        "lob": "a.LOB",
        "audit_resolved_date": "a.PYRESOLVEDTIMESTAMP",
        "auditor_id": "a.AUDITOR_ID",
        "auditor_name": "auditor.USERNAME",
        "platform_source_system": "a.PLATFORM",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return COMPLETED_AUDIT_COUNT_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, a.PYRESOLVEDTIMESTAMP DESC, a.PYID"

COMPLETED_AUDIT_COUNT_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
"""

def build_lob_filter(lob: Optional[List[str]] = None, column_name: str = "a.LOB") -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND ({column_name} IN ('{lob_values}') OR {column_name} IS NULL)"
    elif null_requested:
        return f"AND {column_name} IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND {column_name} IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "a.PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for audit table (uses AUDIT_SUBJECT_ID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{frontline_associate_ids_str}')"
    return ""


def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""


def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

@router.post(
    "/completed-audit-count-drilldown",
    response_model=CompletedAuditCountDrilldownPaginatedResponse,
    summary="Get Completed Audit Count Drilldown",
    description="""
Retrieve paginated list of completed audit counts for detailed table display.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item**: Work Item ID
- **worktype_category**: Worktype Category (e.g., Newborn, Compass, Claims Request, HEW)
- **audit_cycle_time**: Audit Cycle Time (e.g., 00:20:00)
- **audit_resolved_status**: Audit Resolved Status (e.g., Resolved)
- **inventory_type**: Inventory Type (e.g., GB, CB)
- **lob**: Line of Business (e.g., Medicaid, Medicare, Commercial)
- **audit_resolved_date**: Audit Resolved Date (MM/DD/YYYY format)
- **auditor_id**: Auditor ID (unique identifier)
- **auditor_name**: Auditor Name (e.g., Susan Jones)
- **platform_source_system**: Platform - Source System (e.g., Sample Name)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Source:** COB_AI_AUDIT_PROFILE, COB_AI_USER_PROFILE, COB_AI_INVNTRY_PROFILE for cycle time calculation
""",
)
async def get_completed_audit_count_drilldown(request: CompletedAuditCountDrilldownPaginatedRequest) -> CompletedAuditCountDrilldownPaginatedResponse:
    """completed audit count drilldown endpoint - direct query execution."""
    return await execute_completed_audit_count_drilldown_query(request)


async def execute_completed_audit_count_drilldown_query(request: CompletedAuditCountDrilldownPaginatedRequest) -> CompletedAuditCountDrilldownPaginatedResponse:
    """Execute completed audit count drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Build filters
        lob_filter = build_lob_filter(request.lob, "LOB")
        date_filter = build_date_filter(request.start_date, request.end_date, "PYRESOLVEDTIMESTAMP")
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter = build_associate_filter(request.frontline_associate_ids)
        associate_filter_invntry = build_associate_filter_invntry(request.frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached completed_audit_count from quality-outcomes
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Get cached completed audit count from quality-outcomes
                # Build filters dict and hash for cache key
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'director_ids': request.director_ids,
                    'manager_ids': request.manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                cache_key = f"session:{session_id}:{filters_hash}:completed_audit_count"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract COMPLETED_AUDIT_COUNT from cached query result
                    total_records = int(cached_metric[0].get("COMPLETED_AUDIT_COUNT", 0))
                    logger.info(f"✅ Reused cached completed audit count: {total_records} (from quality-outcomes)")
                else:
                    logger.info(f"Cache miss for completed_audit_count, running COUNT query")
                    # Fall back to COUNT query
                    count_query = COMPLETED_AUDIT_COUNT_COUNT_QUERY.format(
                        date_filter=date_filter,
                        lob_filter=lob_filter,
                        director_filter=director_filter,
                        manager_filter=manager_filter,
                        associate_filter=associate_filter,
                        associate_filter_invntry=associate_filter_invntry
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = int(count_result[0].get("COMPLETED_AUDIT_COUNT", 0)) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached completed audit count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = COMPLETED_AUDIT_COUNT_COUNT_QUERY.format(
                    date_filter=date_filter,
                    lob_filter=lob_filter,
                    director_filter=director_filter,
                    manager_filter=manager_filter,
                    associate_filter=associate_filter,
                    associate_filter_invntry=associate_filter_invntry
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = int(count_result[0].get("COMPLETED_AUDIT_COUNT", 0)) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = COMPLETED_AUDIT_COUNT_COUNT_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                director_filter=director_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter,
                associate_filter_invntry=associate_filter_invntry
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = int(count_result[0].get("COMPLETED_AUDIT_COUNT", 0)) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        # Get paginated data
        paginated_query = COMPLETED_AUDIT_COUNT_PAGINATED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            associate_filter_invntry=associate_filter_invntry,
            page_size=page_limit,
            offset=offset
        )
        paginated_query = paginated_query.replace(
            COMPLETED_AUDIT_COUNT_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        
        records = await engine.execute_query_async(paginated_query, limit=page_limit)
        
        completed_audit_records = [
            CompletedAuditCountRecord(
                work_item=record.get("WORK_ITEM", "N/A"),
                worktype_category=record.get("WORKTYPE_CATEGORY", "N/A"),
                audit_cycle_time=format_cycle_time(record.get("AUDIT_CYCLE_TIME")),
                audit_resolved_status=record.get("AUDIT_RESOLVED_STATUS", "N/A"),
                inventory_type=record.get("INVENTORY_TYPE", "N/A"),
                lob=record.get("LOB", "N/A"),
                audit_resolved_date=record.get("AUDIT_RESOLVED_DATE", "N/A"),
                auditor_id=record.get("AUDITOR_ID", "N/A"),
                auditor_name=record.get("AUDITOR_NAME", "N/A"),
                platform_source_system=record.get("PLATFORM_SOURCE_SYSTEM", "N/A")
            )
            for record in records
        ]
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the audit work item (PYID starting with 'AUD')",
            "worktype_category": "Category of work type being audited (INTAKESOURCESYSTEM)",
            "audit_cycle_time": "Cycle time from COB_AI_INVNTRY_PROFILE.CYCLE_TIME in hh:mm:ss format",
            "audit_resolved_status": "Status of the audit resolution (PYSTATUSWORK)",
            "inventory_type": "Type of inventory classification (INVNTRY_TYPE)",
            "lob": "Line of Business classification (Medicaid, Medicare, Commercial)",
            "audit_resolved_date": "Date when the audit was resolved (PYRESOLVEDTIMESTAMP)",
            "auditor_id": "Unique identifier of the auditor (AUDIT_SUBJECT_ID)",
            "auditor_name": "Name of the auditor who completed the audit (USERNAME from COB_AI_USER_PROFILE)",
            "platform_source_system": "Platform or source system where the audit was processed (PLATFORM)"
        }

        return CompletedAuditCountDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=completed_audit_records,
            message="Completed audit count records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated completed audit count drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return CompletedAuditCountDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve completed audit count records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/completed-audit-count-drilldown/download-excel",
    summary="Download Completed Audit Count Drilldown as Excel (Director)",
    description="""
Download complete audit count drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all completed audit count records
""",
)
async def download_completed_audit_count_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> Response:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
    try:
            # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        date_filter = build_date_filter(request.start_date, request.end_date, "PYRESOLVEDTIMESTAMP")
        lob_filter = build_lob_filter(lob, "LOB")
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
            # Query with high limit for download (no pagination needed)
        download_query = COMPLETED_AUDIT_COUNT_PAGINATED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            associate_filter_invntry=associate_filter_invntry,
            page_size=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
    except Exception as e:
            logger.error(f"Excel download error for completed audit count drilldown: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
    
    # STEP 3: Generate Excel file
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "Completed Audit Count"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Worktype Category",
            "Audit Cycle Time",
            "Audit Resolved Status",
            "Inventory Type",
            "LOB",
            "Audit Resolved Date",
            "Auditor ID",
            "Auditor Name",
            "Platform - Source System"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows with field name compatibility
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("work_item") or row.get("WORK_ITEM", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("worktype_category") or row.get("WORKTYPE_CATEGORY", "")))
            audit_cycle_time = row.get("audit_cycle_time") or row.get("AUDIT_CYCLE_TIME")
            if isinstance(audit_cycle_time, str) and ":" in str(audit_cycle_time):
                ws.cell(row=row_num, column=3, value=audit_cycle_time)
            else:
                ws.cell(row=row_num, column=3, value=format_cycle_time(audit_cycle_time) if audit_cycle_time else "00:00:00")
            ws.cell(row=row_num, column=4, value=str(row.get("audit_resolved_status") or row.get("AUDIT_RESOLVED_STATUS", "")))
            ws.cell(row=row_num, column=5, value=str(row.get("inventory_type") or row.get("INVENTORY_TYPE", "")))
            ws.cell(row=row_num, column=6, value=str(row.get("lob") or row.get("LOB", "")))
            ws.cell(row=row_num, column=7, value=str(row.get("audit_resolved_date") or row.get("AUDIT_RESOLVED_DATE", "")))
            ws.cell(row=row_num, column=8, value=str(row.get("auditor_id") or row.get("AUDITOR_ID", "")))
            ws.cell(row=row_num, column=9, value=str(row.get("auditor_name") or row.get("AUDITOR_NAME", "")))
            ws.cell(row=row_num, column=10, value=str(row.get("platform_source_system") or row.get("PLATFORM_SOURCE_SYSTEM", "")))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"completed_audit_count_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for completed audit count drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
