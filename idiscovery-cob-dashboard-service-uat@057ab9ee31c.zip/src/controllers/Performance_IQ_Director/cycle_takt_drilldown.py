import logging
import math
from typing import Dict, List, Optional
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
import httpx

from db import SnowflakeConnectionManager
from schema import (
    CycleTaktDrilldownPaginatedRequest,
    CycleTaktDrilldownPaginatedResponse,
    CycleTaktRecord,
    PageResponse,
    DirectorBaseDownloadRequest,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

# Cycle-Takt drilldown shows completed work items, not backlog items

CYCLE_TAKT_DRILLDOWN_QUERY = f"""
WITH deduped_inventory AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        PLATFORM,
        PYRESOLVEDUSERID,
        CYCLE_TIME,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{lob_filter}}
      {{resolved_date_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
),
deduped_user_profile AS (
    SELECT 
        USERID,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
-- Calculate Takt Time (point-in-time snapshot)
backlog_deduplicated AS (
    SELECT 
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        {{backlog_date_filter}}
        {{lob_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter_backlog}}
),
backlog_total AS (
    SELECT COUNT(DISTINCT PYID) AS total_backlog
    FROM backlog_deduplicated
    WHERE rn = 1
),
active_associates AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID as USERID,
        ROW_NUMBER() OVER (PARTITION BY EMPLOYEE_DOMAIN_ID ORDER BY ASOFTODAY DESC, LOAD_TIMESTAMP DESC) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST
    WHERE JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
        AND TRY_CAST(ASOFTODAY AS DATE) IS NOT NULL
        AND TRY_CAST(ASOFTODAY AS DATE) <= {{end_date_param}}::DATE
        {{associate_filter_user}}
),
active_associates_total AS (
    SELECT COUNT(DISTINCT USERID) AS total_associates
    FROM active_associates
    WHERE rn = 1
),
productive_hrs AS (
    SELECT
        ROUND(AVG(
           SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT
           + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0
           + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
        ), 2) AS avg_hrs_per_day
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
      AND u.TOTALSYSTEMTIME IS NOT NULL
      AND u.LOGINDATE BETWEEN DATEADD(day, -90, {{end_date_param}}::DATE) AND {{end_date_param}}::DATE
),
pto_latest_records AS (
    SELECT 
        w.EMPLOYEE_DOMAIN_ID,
        w.TIME_OFF_DATE,
        w.HOURS,
        w.TIME_OFF_ENTRY_UNIQUE_KEY,
        ROW_NUMBER() OVER (
            PARTITION BY w.EMPLOYEE_DOMAIN_ID, w.TIME_OFF_DATE, w.TIME_OFF_ENTRY_UNIQUE_KEY 
            ORDER BY w.ASOFTODAY DESC, w.LOAD_TIMESTAMP DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    INNER JOIN active_associates a ON w.EMPLOYEE_DOMAIN_ID = a.USERID AND a.rn = 1
    WHERE w.STATUS = 'Approved'
        AND w.TIME_OFF_DATE >= {{end_date_param}}
        AND w.TIME_OFF_DATE <= DATEADD(month, 1, {{end_date_param}}::DATE)
        AND (w.TIME_OFF_TYPE ILIKE '%Paid Time Off%' 
             OR w.TIME_OFF_TYPE ILIKE '%Non Paid Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Sick Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Other Paid Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Paid Parental Leave%'
             OR w.TIME_OFF_TYPE ILIKE '%Wellness Days%'
             OR w.TIME_OFF_TYPE ILIKE '%On Leave%'
             OR w.TIME_OFF_TYPE ILIKE '%Critical Care Leave%')
),
pto_by_employee_by_day AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID,
        TIME_OFF_DATE,
        SUM(CAST(HOURS AS DECIMAL(10,2))) AS net_hours_per_day
    FROM pto_latest_records
    WHERE rn = 1
    GROUP BY EMPLOYEE_DOMAIN_ID, TIME_OFF_DATE
),
pto_by_employee AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID,
        SUM(net_hours_per_day) AS total_pto_uto_hours
    FROM pto_by_employee_by_day
    WHERE net_hours_per_day > 0
    GROUP BY EMPLOYEE_DOMAIN_ID
),
pto_total AS (
    SELECT SUM(total_pto_uto_hours) AS total_pto_hours
    FROM pto_by_employee
),
working_days AS (
    SELECT COUNT(*) AS total_working_days
    FROM (
        SELECT DATEADD(day, SEQ4(), {{end_date_param}}::DATE) AS work_date
        FROM TABLE(GENERATOR(ROWCOUNT => 31))
    ) dates
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA holidays
        ON dates.work_date = holidays.DATE
    WHERE dates.work_date <= DATEADD(month, 1, {{end_date_param}}::DATE)
      AND DAYOFWEEK(dates.work_date) NOT IN (0, 6)
      AND holidays.DATE IS NULL
),
takt_time_calc AS (
    SELECT 
        ROUND(
            (((a.total_associates * w.total_working_days * ph.avg_hrs_per_day) - 
              COALESCE(p.total_pto_hours, 0)) / NULLIF(b.total_backlog, 0)) * 60, 
        2) AS takt_time_mins
    FROM backlog_total b
    CROSS JOIN active_associates_total a
    CROSS JOIN pto_total p
    CROSS JOIN working_days w
    CROSS JOIN productive_hrs ph
)
SELECT
    i.PYID AS work_item,
    i.INTAKESOURCESYSTEM AS work_type,
    i.CYCLE_TIME AS case_cycle_time,
    CASE 
        WHEN i.CYCLE_TIME IS NOT NULL AND t.takt_time_mins IS NOT NULL 
        THEN ROUND((i.CYCLE_TIME / 60.0) - t.takt_time_mins, 2)
        ELSE NULL
    END AS cycle_takt_gap,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.PYRESOLVEDTIMESTAMP AS resolved_date,
    u.USERNAME AS associate,
    i.PLATFORM AS member_source_system
FROM deduped_inventory i
LEFT JOIN deduped_user_profile u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1  -- Latest user profile version only
CROSS JOIN takt_time_calc t
WHERE i.rn = 1  -- Latest inventory version only
ORDER BY i.PXCREATEDATETIME DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

CYCLE_TAKT_DEFAULT_ORDER_BY = "ORDER BY i.PXCREATEDATETIME DESC"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item": "i.PYID",
        "work_type": "i.INTAKESOURCESYSTEM",
        "case_cycle_time": "i.CYCLE_TIME",
        "cycle_takt_gap": "cycle_takt_gap",
        "resolved_status": "i.PYSTATUSWORK",
        "inventory_type": "i.INVNTRY_TYPE",
        "lob": "i.LOB",
        "resolved_date": "i.PYRESOLVEDTIMESTAMP",
        "associate": "u.USERNAME",
        "member_source_system": "i.PLATFORM",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return CYCLE_TAKT_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, i.PXCREATEDATETIME DESC, i.PYID"

CYCLE_TAKT_COUNT_QUERY = f"""
WITH deduped_inventory AS (
    SELECT 
        PYID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{lob_filter}}
      {{resolved_date_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(*) AS TOTAL_COUNT
FROM deduped_inventory
WHERE rn = 1
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_resolved_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for completed work items using PYRESOLVEDTIMESTAMP."""
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_values = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_values}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter - filters by REPORTTOMANAGERID."""
    if manager_ids and len(manager_ids) > 0:
        manager_values = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_values}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "PYRESOLVEDUSERID") -> str:
    """Build associate filter with flexible column parameter."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        associate_values = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{associate_values}')"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""

def build_backlog_date_filter(end_date: Optional[str] = None) -> str:
    """Build date filter for backlog snapshot - items created before end_date and still open or resolved on/after end_date."""
    if end_date:
        return f"""AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)
        AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{end_date}'::DATE))"""
    return ""

async def get_total_associates_count(manager_ids: Optional[List[str]] = None, user_id: str = None) -> int:
    """Get total count of associates under the given managers."""
    # Import here to avoid circular dependency
    from controllers.Performance_IQ_Director.associates_list import get_associates_list
    from schema import AssociateListRequest
    
    if not manager_ids or len(manager_ids) == 0:
        return 0
    
    try:
        associates_request = AssociateListRequest(
            user_id=user_id or "system",
            start_date="2025-01-01",
            end_date="2026-12-31",
            manager_ids=manager_ids,
            search=None,
            limit=5000
        )
        
        response = await get_associates_list(associates_request)
        return response.total_count
    except Exception as e:
        logger.error(f"Error getting total associates count: {str(e)}")
        return 0

async def build_backlog_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for backlog items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If all associates are selected, include manager IDs as well since items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Check if all associates are selected
    all_associates_selected = False
    if manager_ids and len(manager_ids) > 0:
        total_associates = await get_total_associates_count(manager_ids, user_id)
        if total_associates > 0 and len(frontline_associate_ids) == total_associates:
            all_associates_selected = True
            logger.info(f"All {total_associates} associates selected, including manager IDs in takt time backlog filter")
    
    # Build the filter
    if all_associates_selected and manager_ids:
        combined_ids = list(frontline_associate_ids) + list(manager_ids)
        combined_ids_str = "', '".join(combined_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{combined_ids_str}')"
    else:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{frontline_associate_ids_str}')"

def format_date_mmddyyyy(date_str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        if isinstance(date_str, str):
            if 'T' in date_str:
                date_obj = datetime.strptime(date_str.split('T')[0], "%Y-%m-%d")
            else:
                date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        else:
            # Handle date/datetime objects
            date_obj = date_str
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def format_cycle_time(seconds) -> str:
    """Format cycle time from seconds to 'X min. Y sec.' format."""
    if seconds is None or seconds == "":
        return "N/A"
    try:
        # Convert to float if it's a string
        if isinstance(seconds, str):
            seconds = float(seconds)
        
        # Convert seconds to minutes (decimal)
        minutes = seconds / 60.0
        total_minutes = int(minutes)
        remaining_seconds = int((minutes - total_minutes) * 60)
        return f"{total_minutes} min. {remaining_seconds} sec."
    except (ValueError, TypeError):
        return "N/A"

def format_cycle_takt_gap(gap_minutes) -> str:
    """Format cycle-takt gap from minutes to human-readable string.
    
    Positive gap = cycle time > takt time (slower than needed)
    Negative gap = cycle time < takt time (faster than needed)
    """
    if gap_minutes is None or gap_minutes == "":
        return "N/A"
    try:
        # Convert to float if it's a string
        if isinstance(gap_minutes, str):
            gap_minutes = float(gap_minutes)
        
        abs_gap = abs(gap_minutes)
        sign = "+" if gap_minutes > 0 else "-" if gap_minutes < 0 else ""
        
        if abs_gap >= 60:
            # For values >= 60 minutes, show as hours and minutes
            hours = int(abs_gap // 60)
            mins = int(abs_gap % 60)
            return f"{sign}{hours} hrs. {mins} mins."
        else:
            # For values < 60 minutes, show as minutes and seconds
            total_minutes = int(abs_gap)
            seconds = int((abs_gap - total_minutes) * 60)
            return f"{sign}{total_minutes} min. {seconds} sec."
    except (ValueError, TypeError):
        return "N/A"


@router.post(
    "/cycle-takt-drilldown",
    response_model=CycleTaktDrilldownPaginatedResponse,
    summary="Get Cycle-Takt Gap Drilldown",
    description="""
Retrieve paginated cycle-takt gap records for completed work items for the Director dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user id for authentication/authorization
- **start_date** (optional): Start date in YYYY-MM-DD format - filters by resolved date (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format - filters by resolved date (default: no filter)
- **lob** (optional): List of Line of Business values (default: all)
- **manager_ids** (optional): List of manager IDs (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields:**
- **work_item**: Work Item ID
- **work_type**: Work Type
- **case_cycle_time**: Case Cycle Time formatted as 'X min. Y sec.'
- **cycle_takt_gap**: Cycle-Takt Gap
- **resolved_status**: Resolved Status
- **inventory_type**: Inventory Type
- **lob**: Line of Business
- **resolved_date**: Resolved Date (MM/DD/YYYY)
- **associate**: Associate Name
- **member_source_system**: Member Source System

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (completed/resolved work items filtered by PYRESOLVEDTIMESTAMP)
- COB_AI_USER_PROFILE (associate information)
""",
)
async def get_cycle_takt_drilldown(request: CycleTaktDrilldownPaginatedRequest) -> CycleTaktDrilldownPaginatedResponse:
    """Session-enabled cycle takt drilldown endpoint with in-memory pagination."""
    return await execute_cycle_takt_drilldown_query(request)


async def execute_cycle_takt_drilldown_query(request: CycleTaktDrilldownPaginatedRequest) -> CycleTaktDrilldownPaginatedResponse:
    """Execute cycle takt drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Build filters for resolved items
        lob_filter = build_lob_filter(request.lob)
        resolved_date_filter = build_resolved_date_filter(request.start_date, request.end_date)
        director_filter = build_director_filter(getattr(request, 'director_ids', None))
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter = build_associate_filter(request.frontline_associate_ids)
        
        # Build filters for takt time calculation (backlog snapshot)
        backlog_date_filter = build_backlog_date_filter(request.end_date)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        associate_filter_backlog = await build_backlog_associate_filter(
            request.frontline_associate_ids,
            request.manager_ids,
            request.user_id
        )
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        
        # Use end_date for takt time calculation, or CURRENT_DATE if not provided
        end_date_for_takt = f"'{request.end_date}'::DATE" if request.end_date else "CURRENT_DATE"
        
        engine = connection_manager.get_engine()
        
        # Get total count
        count_query = CYCLE_TAKT_COUNT_QUERY.format(
            lob_filter=lob_filter,
            resolved_date_filter=resolved_date_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        print(count_query)
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = int(count_result[0].get("TOTAL_COUNT", 0)) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Get paginated data with takt time calculation
        data_query = CYCLE_TAKT_DRILLDOWN_QUERY.format(
            lob_filter=lob_filter,
            resolved_date_filter=resolved_date_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            backlog_date_filter=backlog_date_filter,
            manager_filter_user=manager_filter_user,
            associate_filter_backlog=associate_filter_backlog,
            associate_filter_user=associate_filter_user,
            end_date_param=end_date_for_takt,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            CYCLE_TAKT_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        print(data_query)
        data_result = await engine.execute_query_async(data_query, limit=page_limit)
        
        # Map SQL results to CycleTaktRecord objects
        records = []
        if data_result:
            for row in data_result:
                records.append(
                    CycleTaktRecord(
                        work_item=str(row.get("WORK_ITEM", "")),
                        work_type=str(row.get("WORK_TYPE", "")),
                        case_cycle_time=format_cycle_time(row.get("CASE_CYCLE_TIME")),
                        cycle_takt_gap=format_cycle_takt_gap(row.get("CYCLE_TAKT_GAP")),
                        resolved_status=str(row.get("RESOLVED_STATUS", "")),
                        inventory_type=str(row.get("INVENTORY_TYPE", "")),
                        lob=str(row.get("LOB", "")),
                        resolved_date=format_date_mmddyyyy(row.get("RESOLVED_DATE")) if row.get("RESOLVED_DATE") else "",
                        associate=str(row.get("ASSOCIATE", "")),
                        member_source_system=str(row.get("MEMBER_SOURCE_SYSTEM", "")),
                    )
                )

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1,
        )

        tooltips: Dict[str, str] = {
            "work_item": "Unique Work Item identifier",
            "work_type": "Business work type for the case",
            "case_cycle_time": "Duration spent resolving the case (formatted as 'X min. Y sec.')",
            "cycle_takt_gap": "Difference between the cycle and takt times for the work item",
            "resolved_status": "Current resolution status (Resolved/Open)",
            "inventory_type": "Inventory bucket (e.g., GB, CB)",
            "lob": "Line of business (Medicaid, Medicare, Commercial)",
            "resolved_date": "Date when the work item was resolved (MM/DD/YYYY)",
            "associate": "Associate name assigned to the work item",
            "member_source_system": "Member Source System",
        }

        return CycleTaktDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=records,
            message="Cycle-Takt gap records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service",
        )

    except Exception as exc:  # pragma: no cover - placeholder
        logger.error(f"Cycle-Takt drilldown failed: {type(exc).__name__}: {str(exc)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False,
        )
        return CycleTaktDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve cycle-takt gap records: {str(exc)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service",
        )


@router.post(
    "/cycle-takt-drilldown/download-excel",
    summary="Download Cycle-Takt Gap Drilldown as Excel (Director)",
    description="""
Download cycle-takt gap drilldown data for completed work items as an Excel file for the Director view.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format - filters by resolved date
- **end_date** (optional): End date in YYYY-MM-DD format - filters by resolved date
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with completed work item data from COB_AI_INVNTRY_PROFILE (filtered by PYRESOLVEDTIMESTAMP).
""",
)
async def download_cycle_takt_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters for resolved items
        lob_filter = build_lob_filter(request.lob)
        resolved_date_filter = build_resolved_date_filter(request.start_date, request.end_date)
        director_filter = build_director_filter(getattr(request, 'director_ids', None))
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter = build_associate_filter(request.frontline_associate_ids)
        
        # Build filters for takt time calculation (backlog snapshot)
        backlog_date_filter = build_backlog_date_filter(request.end_date)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        associate_filter_backlog = await build_backlog_associate_filter(
            request.frontline_associate_ids,
            request.manager_ids,
            request.user_id
        )
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        
        # Use end_date for takt time calculation, or CURRENT_DATE if not provided
        end_date_for_takt = f"'{request.end_date}'::DATE" if request.end_date else "CURRENT_DATE"
        
        engine = connection_manager.get_engine()
        
        # Get all data (no pagination for Excel - use large limit)
        data_query = CYCLE_TAKT_DRILLDOWN_QUERY.format(
            lob_filter=lob_filter,
            resolved_date_filter=resolved_date_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            backlog_date_filter=backlog_date_filter,
            manager_filter_user=manager_filter_user,
            associate_filter_backlog=associate_filter_backlog,
            associate_filter_user=associate_filter_user,
            end_date_param=end_date_for_takt,
            limit=100000,
            offset=0
        )
        
        data_result = await engine.execute_query_async(data_query, limit=1000000)
        total_records = len(data_result) if data_result else 0

        wb = Workbook()
        ws = wb.active
        ws.title = "Cycle-Takt Drilldown"

        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")

        headers = [
            "Work Item",
            "Work Type",
            "Case Cycle Time",
            "Cycle-Takt Gap",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Resolved Date",
            "Associate Name",
            "Member Source System",
        ]

        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment

        # Write data rows
        if data_result:
            for row_num, row in enumerate(data_result, start=2):
                ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM", "")))
                ws.cell(row=row_num, column=2, value=str(row.get("WORK_TYPE", "")))
                ws.cell(row=row_num, column=3, value=format_cycle_time(row.get("CASE_CYCLE_TIME")))
                ws.cell(row=row_num, column=4, value=format_cycle_takt_gap(row.get("CYCLE_TAKT_GAP")))
                ws.cell(row=row_num, column=5, value=str(row.get("RESOLVED_STATUS", "")))
                ws.cell(row=row_num, column=6, value=str(row.get("INVENTORY_TYPE", "")))
                ws.cell(row=row_num, column=7, value=str(row.get("LOB", "")))
                ws.cell(row=row_num, column=8, value=format_date_mmddyyyy(row.get("RESOLVED_DATE")) if row.get("RESOLVED_DATE") else "")
                ws.cell(row=row_num, column=9, value=str(row.get("ASSOCIATE", "")))
                ws.cell(row=row_num, column=10, value=str(row.get("MEMBER_SOURCE_SYSTEM", "")))

        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except Exception:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

        output = BytesIO()
        wb.save(output)
        output.seek(0)

        filename = f"cycle_takt_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    except Exception as exc:
        logger.error(f"Excel download error for cycle takt drilldown: {type(exc).__name__}: {str(exc)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(exc)}")
