import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import DirectorBaseRequest, DemandInventoryResponse, BacklogByStatusItem, AssociateListRequest
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id
from controllers.Performance_IQ_Director.associates_list import get_associates_list

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()


BACKLOG_STATUSES = [
    'Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake',
    'Open-ReviewIntake', 'Pend', 'Pend-Decision'
]

BACKLOG_VOLUME_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        INTAKESOURCESYSTEM,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXUPDATEDATETIME DESC
    ) = 1
)
SELECT
    LOB,
    INTAKESOURCESYSTEM,
    COUNT(PYID) AS BACKLOG_COUNT
FROM latest_inventory
WHERE 1=1
  {{lob_filter}}
  AND (INTAKESOURCESYSTEM NOT LIKE '%-Dup%' OR INTAKESOURCESYSTEM = 'Solution Central-Dup')
  AND PXCREATEDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
  AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{{end_date}}'::DATE))
GROUP BY LOB, INTAKESOURCESYSTEM
ORDER BY LOB, BACKLOG_COUNT DESC
"""


ESCALATION_COUNT_QUERY = f"""
WITH deduped_inventory AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      {{lob_filter}}
      AND PRIORITY IN ('Instant', 'Immediate')
      {{escalation_created_filter}}
      AND (PYSTATUSWORK ILIKE 'Open%' OR PYSTATUSWORK ILIKE 'Pend%')
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT PYID) AS ESCALATION_COUNT
FROM deduped_inventory
WHERE rn = 1  -- Latest inventory version only
"""

PENDED_ITEMS_QUERY = f"""
WITH deduped_invntry AS (
    SELECT DISTINCT
        PYID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1 = 1
      {{lob_filter}}
      {{pended_created_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
),
latest_status AS (
    SELECT
        t.PYID,
        t.PYSTATUSWORK,
        t.PYRESOLVEDTIMESTAMP,
        t.REASSIGNED_TO,
        t.FIRST_ASSIGNED_TO,
        ROW_NUMBER() OVER (
            PARTITION BY t.PYID
            ORDER BY t.PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE t
    INNER JOIN deduped_invntry a
        ON t.PYID = a.PYID
)
SELECT
    COUNT(DISTINCT PYID) AS PENDED_ITEMS_COUNT
FROM latest_status
WHERE rn = 1
  AND PYSTATUSWORK LIKE 'Pend%'
  AND PYRESOLVEDTIMESTAMP IS NULL
"""

WATCHLIST_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        ASSIGNEDTO,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      {{lob_filter}}
      {{watchlist_created_filter}}
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT PYID) AS WATCHLIST_COUNT
FROM invntry_deduped 
WHERE rn = 1
"""

WORK_ITEMS_COMPLETED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        {{date_filter}}
        {{lob_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter}}
)
SELECT COUNT(*) AS COMPLETED_TASKS
FROM invntry_deduped
WHERE rn = 1
"""

NON_VALUE_ADD_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        ACTIONDECISION,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
)
SELECT 
    COUNT(DISTINCT CASE 
        WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
        THEN PYID 
    END) AS non_value_add_count,
    COUNT(DISTINCT PYID) AS total_closed,
    ROUND(
        COUNT(DISTINCT CASE 
            WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
            THEN PYID 
        END) * 100.0 / NULLIF(COUNT(DISTINCT PYID), 0), 
    2) AS non_value_add_pct
FROM invntry_deduped
WHERE rn = 1
"""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_backlog_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Date filter specifically for backlog queries using PXCREATEDATETIME"""
    if start_date and end_date:
        return (
            f"AND PXCREATEDATETIME >= '{start_date}' "
            f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PXCREATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_director_filter(director_ids: Optional[List[str]] = None, column: str = "REPORTTODIRECTORID") -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND {column} IN ('{director_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None, column: str = "REPORTTOMANAGERID") -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND {column} IN ('{manager_ids_str}')"
    return ""


def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "ASSIGNEDTO") -> str:
    """Build associate filter with flexible column parameter."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{frontline_associate_ids_str}')"
    return ""




def build_backlog_created_filter(end_date: Optional[str] = None) -> str:
    """Filter for items that existed before the end date"""
    if end_date:
        return f"AND PXCREATEDATETIME < '{end_date}'"
    return ""


def build_backlog_resolved_filter(end_date: Optional[str] = None) -> str:
    """Filter for items that were still open at end date (not resolved, or resolved after)"""
    if end_date:
        return f"AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= '{end_date}')"
    return ""



def build_pended_created_filter(end_date: Optional[str] = None) -> str:
    """Filter for pended items that existed before the end date"""
    if end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_pended_resolved_filter(end_date: Optional[str] = None) -> str:
    """Filter for pended items that were still open at end date (not resolved, or resolved after)"""
    if end_date:
        return f"AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= '{end_date}')"
    return ""


async def get_total_associates_count(manager_ids: Optional[List[str]] = None, user_id: str = None) -> int:
    """Get total count of associates under the given managers by calling associates_list API."""
    if not manager_ids or len(manager_ids) == 0:
        return 0
    
    try:
        # Create request for associates list API
        # Note: start_date and end_date are required but not used for counting all associates
        associates_request = AssociateListRequest(
            user_id=user_id or "system",
            start_date="2025-01-01",  # Placeholder dates - not used for counting
            end_date="2026-12-31",
            manager_ids=manager_ids,
            search=None,
            limit=5000
        )
        
        # Call the associates list API
        response = await get_associates_list(associates_request)
        
        # Return the total count from the response
        return response.total_count
    except Exception as e:
        logger.error(f"Error getting total associates count from API: {str(e)}")
        return 0


async def build_pended_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for pended items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If all associates are selected (frontline_associate_ids count matches total associates count),
    include manager IDs in the filter as well since items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Check if all associates are selected
    all_associates_selected = False
    if manager_ids and len(manager_ids) > 0:
        total_associates = await get_total_associates_count(manager_ids, user_id)
        if total_associates > 0 and len(frontline_associate_ids) == total_associates:
            all_associates_selected = True
            logger.info(f"All {total_associates} associates selected, including manager IDs in pended filter")
    
    # Build the filter
    if all_associates_selected and manager_ids:
        # Include both associates and managers
        combined_ids = list(frontline_associate_ids) + list(manager_ids)
        combined_ids_str = "', '".join(combined_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{combined_ids_str}')"
    else:
        # Only include associates
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{frontline_associate_ids_str}')"


async def build_escalation_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for escalation items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If all associates are selected (frontline_associate_ids count matches total associates count),
    include manager IDs in the filter as well since items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Check if all associates are selected
    all_associates_selected = False
    if manager_ids and len(manager_ids) > 0:
        total_associates = await get_total_associates_count(manager_ids, user_id)
        if total_associates > 0 and len(frontline_associate_ids) == total_associates:
            all_associates_selected = True
            logger.info(f"All {total_associates} associates selected, including manager IDs in escalation filter")
    
    # Build the filter
    if all_associates_selected and manager_ids:
        # Include both associates and managers
        combined_ids = list(frontline_associate_ids) + list(manager_ids)
        combined_ids_str = "', '".join(combined_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{combined_ids_str}')"
    else:
        # Only include associates
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{frontline_associate_ids_str}')"



def build_escalation_created_filter(end_date: Optional[str] = None) -> str:
    """Filter for escalation items that were created before the end date"""
    if end_date:
        return f"AND PXCREATEDATETIME < '{end_date}'"
    return ""


def build_watchlist_created_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Filter for watchlist items by PXCREATEDATETIME (when item was added to watchlist)"""
    if start_date and end_date:
        return f"AND PXCREATEDATETIME >= '{start_date}' AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND PXCREATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""




@router.post(
    "/demand-inventory",
    response_model=DemandInventoryResponse,
    summary="Get Demand Inventory Metrics",
    description="""
Retrieve demand inventory and work mix metrics for director dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Response Fields:**
- **backlog_volume**: Total count of open/pending work items
- **backlog_by_status**: Breakdown by work status (Assigned, New, Open-*, Pend*)
- **escalation_count**: Count of high priority items (Instant, Immediate, Urgent)
- **escalation_by_priority**: Breakdown by priority level
- **pended_items_count**: Count of items with Pend% status
- **watchlist_count**: Watchlist count (TBD - awaiting definition)
- **work_items_completed**: Count of resolved work items in date range
- **non_value_add_pct**: Percentage of items with no update required

**Data Source:** COB_AI_INVNTRY_PROFILE table
""",
)
async def get_demand_inventory(request: DirectorBaseRequest) -> DemandInventoryResponse:
    """Demand inventory endpoint with metric-level caching."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_demand_inventory_query(request)


async def execute_demand_inventory_query(request: DirectorBaseRequest) -> DemandInventoryResponse:
    """Execute demand inventory query logic (core business logic)."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        
        # For queries using PYRESOLVEDUSERID (completed, nva)
        associate_filter_resolved = build_associate_filter(request.frontline_associate_ids, column="PYRESOLVEDUSERID")
        
        # Filters for backlog query - using date filter with specific columns
        created_date_filter = build_date_filter(None, request.end_date, date_column="PXCREATEDATETIME") if request.end_date else ""
        # For backlog resolved filter: items still open at end date (not resolved, or resolved after)
        resolved_date_filter = f"AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{request.end_date}'::DATE))" if request.end_date else ""
        
        # Filters for pended items query - using date filter with specific column
        pended_created_filter = build_date_filter(None, request.end_date, date_column="PXCREATEDATETIME") if request.end_date else ""
        # Special associate filter for pended items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO)
        # Includes manager IDs if all associates are selected
        pended_associate_filter = await build_pended_associate_filter(request.frontline_associate_ids, request.manager_ids, request.user_id)
        
        # Filters for escalation count query - using date filter with specific column
        escalation_created_filter = build_date_filter(None, request.end_date, date_column="PXCREATEDATETIME") if request.end_date else ""
        # Special associate filter for escalation items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO)
        # Includes manager IDs if all associates are selected
        escalation_associate_filter = await build_escalation_associate_filter(request.frontline_associate_ids, request.manager_ids, request.user_id)
        
        # Filter for watchlist items - using PXCREATEDATETIME (when item was added to watchlist)
        watchlist_created_filter = build_watchlist_created_filter(request.start_date, request.end_date)
        
        engine = connection_manager.get_engine()

        backlog_query = BACKLOG_VOLUME_QUERY.format(
            lob_filter=lob_filter,
            end_date=request.end_date
        )

        escalation_query = ESCALATION_COUNT_QUERY.format(
            lob_filter=lob_filter,
            escalation_created_filter=escalation_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=escalation_associate_filter
        )
        pended_query = PENDED_ITEMS_QUERY.format(
            lob_filter=lob_filter,
            pended_created_filter=pended_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=pended_associate_filter
        )
        watchlist_query = WATCHLIST_COUNT_QUERY.format(
            lob_filter=lob_filter,
            watchlist_created_filter=watchlist_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter_resolved
        )
        completed_query = WORK_ITEMS_COMPLETED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter_resolved
        )
        nva_query = NON_VALUE_ADD_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter_resolved
        )
        # Define async fetch functions for caching
        async def fetch_backlog():
            return await engine.execute_query_async(backlog_query, limit=1000)
        
        async def fetch_escalation():
            return await engine.execute_query_async(escalation_query, limit=100)
        
        async def fetch_pended():
            return await engine.execute_query_async(pended_query, limit=1)
        
        async def fetch_watchlist():
            return await engine.execute_query_async(watchlist_query, limit=1)
        
        async def fetch_completed():
            return await engine.execute_query_async(completed_query, limit=1)
        
        async def fetch_nva():
            return await engine.execute_query_async(nva_query, limit=1)
        
        # Get or fetch cached metrics (only cache if session_id provided)
        session_id = getattr(request, "session_id", None)
        
        # Build filters dict for cache isolation
        filters = {
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
            'director_ids': request.director_ids,
            'manager_ids': request.manager_ids,
            'frontline_associate_ids': request.frontline_associate_ids,
        }
        
        if session_id:
            backlog_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_backlog,
                session_id=session_id,
                metric_name="backlog_volume",
                filters=filters
            )
            
            escalation_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_escalation,
                session_id=session_id,
                metric_name="escalation_count",
                filters=filters
            )
            
            pended_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_pended,
                session_id=session_id,
                metric_name="pended_items",
                filters=filters
            )
            
            watchlist_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_watchlist,
                session_id=session_id,
                metric_name="watchlist_count",
                filters=filters
            )
            
            completed_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_completed,
                session_id=session_id,
                metric_name="work_items_completed",
                filters=filters
            )
            
            nva_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_nva,
                session_id=session_id,
                metric_name="non_value_add",
                filters=filters
            )
        else:
            # Execute all 6 queries in parallel without caching
            logger.info("Executing 6 Director demand inventory queries in parallel")
            (
                backlog_records,
                escalation_records,
                pended_records,
                watchlist_records,
                completed_records,
                nva_records
            ) = await asyncio.gather(
                fetch_backlog(),
                fetch_escalation(),
                fetch_pended(),
                fetch_watchlist(),
                fetch_completed(),
                fetch_nva(),
                return_exceptions=False
            )
            logger.info("Parallel query execution completed")

        backlog_by_status = []

        backlog_volume = sum(int(r.get("BACKLOG_COUNT", 0) or 0) for r in backlog_records) if backlog_records else 0

        escalation_by_priority = [
            {"priority": r.get("PRIORITY", "Unknown"), "count": int(r.get("ESCALATION_COUNT", 0))}
            for r in escalation_records
        ] if escalation_records else []

        escalation_count = sum(item["count"] for item in escalation_by_priority)
        
        pended_items_count = int(pended_records[0].get("PENDED_ITEMS_COUNT", 0) or 0) if pended_records else 0
        watchlist_count = str(int(watchlist_records[0].get("WATCHLIST_COUNT", 0) or 0)) if watchlist_records else "0"
        work_items_completed = int(completed_records[0].get("COMPLETED_TASKS", 0) or 0) if completed_records else 0
        non_value_add_pct = float(nva_records[0].get("NON_VALUE_ADD_PCT", 0) or 0) if nva_records else 0.0

        tooltips = {
            "backlog_volume": "Total count of work items in open/pending statuses (Assigned, New, Open-*, Pend*)",
            "backlog_by_status": "Breakdown of backlog by individual work status",
            "escalation_count": "Count of high priority items requiring immediate attention",
            "escalation_by_priority": "Breakdown by priority level (Instant, Immediate, Urgent)",
            "pended_items_count": "Count of items currently in a pended status",
            "watchlist_count": "Count of items added to watchlist (ISADDTOWATCHLIST='Y') that are not resolved-completed",
            "work_items_completed": "Total resolved work items in the selected date range",
            "non_value_add_pct": "Percentage of completed items with 'Confirmed Existing COB/No Update Required'"
        }

        return DemandInventoryResponse(
            status="success",
            backlog_volume=backlog_volume,
            backlog_by_status=backlog_by_status,
            escalation_count=escalation_count,
            escalation_by_priority=escalation_by_priority,
            pended_items_count=pended_items_count,
            watchlist_count=watchlist_count,
            work_items_completed=work_items_completed,
            non_value_add_pct=non_value_add_pct,
            message="Demand inventory metrics retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Demand inventory query error: {type(e).__name__}: {str(e)}")
        return DemandInventoryResponse(
            status="error",
            backlog_volume=0,
            backlog_by_status=[],
            escalation_count=0,
            escalation_by_priority=[],
            pended_items_count=0,
            watchlist_count="N/A",
            work_items_completed=0,
            non_value_add_pct=0.0,
            message=f"Failed to retrieve demand inventory metrics: {str(e)}"
        )
