import logging
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import DirectorListRequest, DirectorListResponse, DirectorItem
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
from utils import cache_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

DIRECTORS_LIST_QUERY = f"""
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
),
manager AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO,
        REPORTTOUSERNAME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT DISTINCT  
    manager.PYREPORTTO AS DIRECTOR_ID, 
    manager.REPORTTOUSERNAME AS DIRECTOR_NAME 
FROM frontline 
INNER JOIN manager 
    ON frontline.PYREPORTTO = manager.USERID
WHERE 1=1
ORDER BY manager.REPORTTOUSERNAME
"""




@router.post(
    "/directors-list",
    response_model=DirectorListResponse,
    summary="Get List of Directors",
    description="""
Retrieve unique list of directors for filter dropdown.
Shows only directors who had managers reporting to them, who in turn had frontline associates, all active in the last 1 year.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **search** (optional): Search term to filter directors by name

**Response Fields:**
- **status**: Status of the request (success/error)
- **directors**: List of DirectorItem objects containing director_id and director_name
- **total_count**: Total number of directors returned
- **message**: Response message
- **service**: Service name (idiscovery-cob-dashboard-service)

**Data Source:** COB_AI_USER_PROFILE table (filtered to last 1 year of login activity)
**Caching:** Results cached for 6 hours (21,600s)
""",
)
async def get_directors_list(request: DirectorListRequest) -> DirectorListResponse:
    if not connection_manager.validate_config():
        logger.error("[DIRECTORS_LIST] Snowflake credentials not configured")
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    # Build cache key
    cache_key = cache_manager.build_key(
        "directors:list",
        search=request.search or ""
    )
    
    async def fetch_from_db():
        """Fetch directors list from database."""
        try:
            engine = connection_manager.get_engine()
            
            query = DIRECTORS_LIST_QUERY
            records = await engine.execute_query_async(query, limit=500)
            
            directors = [
                {
                    "director_id": r.get("DIRECTOR_ID", ""),
                    "director_name": r.get("DIRECTOR_NAME", "")
                }
                for r in records
                if r.get("DIRECTOR_ID") and r.get("DIRECTOR_NAME")
            ] if records else []

            return {
                "status": "success",
                "directors": directors,
                "total_count": len(directors),
                "message": "Directors list retrieved successfully"
            }

        except Exception as e:
            logger.error(f"[DIRECTORS_LIST] Error occurred: {type(e).__name__}: {str(e)}")
            logger.exception(f"[DIRECTORS_LIST] Full exception traceback:")
            return {
                "status": "error",
                "directors": [],
                "total_count": 0,
                "message": f"Failed to retrieve directors list: {str(e)}"
            }
    
    # Get from cache or fetch from DB (6 hour TTL)
    result = await cache_manager.get_or_fetch(cache_key, fetch_from_db, ttl=METRIC_CACHE_TTL)
    
    # Convert dict to response model
    directors = [DirectorItem(**d) for d in result["directors"]]
    
    return DirectorListResponse(
        status=result["status"],
        directors=directors,
        total_count=result["total_count"],
        message=result["message"]
    )
