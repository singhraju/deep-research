import asyncio
from fastapi import APIRouter, HTTPException
from typing import Optional, List
from schema.models import DirectorLOBRequest, DirectorLOBResponse
from utils import cache_manager
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

# Query to get LOBs from inventory table based on manager-associate relationships
DIRECTOR_LOB_INVENTORY_QUERY = f"""
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    {{director_filter}}
    {{manager_filter}}
    {{associate_filter}}
"""

# Query to get LOBs from audit table (only date and associate filters)
DIRECTOR_LOB_AUDIT_QUERY = f"""
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    {{associate_filter}}
"""


def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for inventory table."""
    if start_date and end_date:
        return (
            f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' "
            f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_director_filter(director_ids: Optional[List[str]] = None, column: str = "REPORTTODIRECTORID") -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND {column} IN ('{director_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None, column: str = "REPORTTOMANAGERID") -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND {column} IN ('{manager_ids_str}')"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""


def build_audit_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for audit table (uses AUDIT_SUBJECT_ID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{frontline_associate_ids_str}')"
    return ""


def build_audit_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for audit table (uses PYRESOLVEDTIMESTAMP)."""
    if start_date and end_date:
        return (
            f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' "
            f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


@router.post(
    "/lobs",
    response_model=DirectorLOBResponse,
    summary="Get List of LOBs for Director View",
    description="""
Returns LOBs filtered by manager-associate relationships for director-level view.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format to filter LOBs by date range - unused
- **end_date** (optional): End date in YYYY-MM-DD format to filter LOBs by date range - unused
- **manager_ids** (optional): List of manager IDs to filter LOBs for associates under these managers
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter LOBs for specific associates

**Response:**
- **lobs**: List of distinct LOBs available based on the filters applied

**Data Sources:**
- COB_AI_INVNTRY_PROFILE (work items)
- COB_AI_AUDIT_PROFILE (audit records)
- COB_AI_USER_PROFILE (manager-associate relationships)

**Caching:** Results are cached for 24 hours based on the filter combination.
""",
)
async def get_director_lobs(request: DirectorLOBRequest) -> DirectorLOBResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    # Build cache key based on all filter parameters
    cache_key = cache_manager.build_key(
        "director_lobs",
        user_id=request.user_id,
        director_ids=",".join(request.director_ids) if request.director_ids else "all",
        manager_ids=",".join(request.manager_ids) if request.manager_ids else "all",
        frontline_associate_ids=",".join(request.frontline_associate_ids) if request.frontline_associate_ids else "all"
    )

    async def fetch_lobs():
        try:
            # Build filters for inventory table
            # date_filter = build_date_filter(request.start_date, request.end_date)
            director_filter = build_director_filter(request.director_ids)
            manager_filter = build_manager_filter(request.manager_ids)
            associate_filter = build_associate_filter(request.frontline_associate_ids)

            # Build filters for audit table (only date and associate)
            # audit_date_filter = build_audit_date_filter(request.start_date, request.end_date)
            audit_associate_filter = build_audit_associate_filter(request.frontline_associate_ids)

            # Format inventory query with filters
            inventory_query = DIRECTOR_LOB_INVENTORY_QUERY.format(
                director_filter=director_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter
            )
            
            # Format audit query with filters (only date and associate)
            audit_query = DIRECTOR_LOB_AUDIT_QUERY.format(
                associate_filter=audit_associate_filter
            )
            
            engine = connection_manager.get_engine()
            
            # Execute both queries
            logger.info("[DIRECTOR_LOB] Executing 2 LOB queries in parallel")
            (inventory_records, audit_records) = await asyncio.gather(
                engine.execute_query_async(inventory_query, limit=100),
                engine.execute_query_async(audit_query, limit=100),
                return_exceptions=False
            )
            logger.info("[DIRECTOR_LOB] Parallel query execution completed")
            
            # Combine and deduplicate LOBs
            lobs_set = set()
            for r in inventory_records:
                lob_value = r.get("LOB")
                if lob_value is not None:  # Include 'None' string but exclude actual None
                    lobs_set.add(lob_value)
            for r in audit_records:
                lob_value = r.get("LOB")
                if lob_value is not None:  # Include 'None' string but exclude actual None
                    lobs_set.add(lob_value)
            
            # Sort LOBs with 'None' at the end
            lobs = sorted([lob for lob in lobs_set if lob != "None"])
            if "None" in lobs_set:
                lobs.append("None")

            return {
                "status": "success",
                "lobs": lobs,
                "message": "Director LOBs retrieved successfully",
                "service": "idiscovery-cob-dashboard-service"
            }
        except Exception as e:
            logger.error(f"Failed to retrieve director LOBs: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to retrieve director LOBs: {str(e)}")

    result = await cache_manager.get_or_fetch(cache_key, fetch_lobs, ttl=METRIC_CACHE_TTL)
    return DirectorLOBResponse(**result)
