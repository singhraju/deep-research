import logging
import uuid
from datetime import datetime
from typing import Optional, List
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import DirectorUserActivityRequest, DirectorUserActivityResponse, DirectorUserActivityData

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

# Query to get skilled sources for a specific associate
SKILLED_SOURCES_QUERY = f"""
SELECT DISTINCT SKILLDESCRIPTION
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_SKILLS
WHERE USERID = '{{associate_id}}'
AND DATE(PXCOMMITDATETIME) = (
    SELECT MAX(DATE(PXCOMMITDATETIME))
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_SKILLS
    WHERE USERID = '{{associate_id}}'
)
"""

# Query to get experience level (ramp) for a specific associate
RAMP_QUERY = f"""
SELECT EXPERIENCELEVEL
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{associate_id}}'
AND LOGINDATE >= '{{start_date}}'
AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
ORDER BY LOGINDATE DESC
LIMIT 1
"""

# Query to get team rank and department rank for a specific associate
RANK_QUERY = f"""
SELECT 
    ROUND(AVG(TEAMRANK))::INT AS TEAMRANK,
    ROUND(AVG(DEPTRANK))::INT AS DEPTRANK
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{associate_id}}'
AND LOGINDATE >= '{{start_date}}'
AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
AND TEAMRANK IS NOT NULL
AND DEPTRANK IS NOT NULL
"""


def execute_sources_query(engine, query: str):
    """Execute skilled sources query."""
    return engine.execute_query(query, limit=100)


def execute_ramp_query(engine, query: str):
    """Execute ramp/experience level query."""
    return engine.execute_query(query, limit=10)


def execute_rank_query(engine, query: str):
    """Execute rank query."""
    return engine.execute_query(query, limit=10)


@router.post(
    "/user-activity",
    response_model=DirectorUserActivityResponse,
    summary="Get Director User Activity",
    description="""
Retrieve user activity data including team rank, department rank, ramp status, and skilled sources for a specific frontline associate.

**Input Parameters:**
- **user_id** (required): The unique identifier of the logged-in director (e.g., 'AB77504')
- **frontline_associate_id** (required): The frontline associate ID (e.g., 'AH40730')
- **start_date** (required): Start date in YYYY-MM-DD format (e.g., '2025-08-01')
- **end_date** (required): End date in YYYY-MM-DD format (e.g., '2026-03-31')

**Response Fields:**
- **team_rank**: Team ranking (NA if not available)
- **department_rank**: Department ranking (NA if not available)
- **ramp**: Experience level/ramp status (e.g., 'Training', 'Ramping', 'Proficient')
- **skilled_sources**: List of intake source systems the associate has worked with

**Data Sources:**
- COB_AI_USER_PROFILE (experience level/ramp)
- COB_AI_INVNTRY_PROFILE (skilled sources)
""",
)
async def get_director_user_activity(request: DirectorUserActivityRequest) -> DirectorUserActivityResponse:
    request_id = f"req_{uuid.uuid4().hex[:14].upper()}"
    generated_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    
    meta = {
        "request_id": request_id,
        "screen_id": "director_user_activity",
        "generated_at": generated_at
    }

    if not connection_manager.validate_config():
        return DirectorUserActivityResponse(
            meta=meta,
            data=None,
            errors=[{
                "code": "INTERNAL_ERROR",
                "message": "Snowflake credentials not configured"
            }]
        )

    try:
        engine = connection_manager.get_engine()
        
        # Format queries
        sources_query = SKILLED_SOURCES_QUERY.format(
            associate_id=request.frontline_associate_id
        )
        
        ramp_query = RAMP_QUERY.format(
            associate_id=request.frontline_associate_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        
        rank_query = RANK_QUERY.format(
            associate_id=request.frontline_associate_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        
        # Execute queries in parallel
        with ThreadPoolExecutor(max_workers=3) as executor:
            sources_future = executor.submit(execute_sources_query, engine, sources_query)
            ramp_future = executor.submit(execute_ramp_query, engine, ramp_query)
            rank_future = executor.submit(execute_rank_query, engine, rank_query)
            
            sources_records = sources_future.result()
            ramp_records = ramp_future.result()
            rank_records = rank_future.result()
        
        # Process skilled sources
        skilled_sources = [
            record.get("SKILLDESCRIPTION")
            for record in sources_records
            if record.get("SKILLDESCRIPTION")
        ] if sources_records else []
        
        # Extract ramp/experience level
        ramp = "N/A"
        if ramp_records and len(ramp_records) > 0:
            experience_level = ramp_records[0].get("EXPERIENCELEVEL")
            if experience_level:
                ramp = str(experience_level)
        
        # Extract team rank and department rank
        team_rank = "N/A"
        department_rank = "N/A"
        if rank_records and len(rank_records) > 0:
            team_rank_value = rank_records[0].get("TEAMRANK")
            dept_rank_value = rank_records[0].get("DEPTRANK")
            if team_rank_value is not None:
                team_rank = str(int(team_rank_value))
            if dept_rank_value is not None:
                department_rank = str(int(dept_rank_value))

        tooltips = {
            "team_rank": "Associate's performance ranking within their team",
            "department_rank": "Associate's performance ranking within their department",
            "ramp": "Experience level or ramp status of the associate",
            "skilled_sources": "List of work source systems the associate has processed work items from"
        }

        return DirectorUserActivityResponse(
            meta=meta,
            data=DirectorUserActivityData(
                team_rank=team_rank,
                department_rank=department_rank,
                ramp=ramp,
                skilled_sources=skilled_sources
            ),
            errors=None,
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Director user activity query error: {type(e).__name__}: {str(e)}")
        return DirectorUserActivityResponse(
            meta=meta,
            data=None,
            errors=[{
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred"
            }]
        )
