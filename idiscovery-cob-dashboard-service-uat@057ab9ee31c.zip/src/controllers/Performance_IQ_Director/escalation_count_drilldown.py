import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import StreamingResponse
import httpx
import asyncio

from db import SnowflakeConnectionManager
from schema import DirectorBaseDownloadRequest, EscalationCountDrilldownPaginatedRequest, EscalationCountDrilldownPaginatedResponse, EscalationCountRecord, PageResponse, AssociateListRequest
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from controllers.Performance_IQ_Director.associates_list import get_associates_list
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime
from io import BytesIO
import math

def format_datetime_mmddyyyy(datetime_str: str) -> str:
    """Convert datetime to MM/DD/YYYY format"""
    if not datetime_str:
        return ""
    try:
        # Handle both date and datetime formats
        if 'T' in str(datetime_str):
            date_obj = datetime.strptime(str(datetime_str).split('T')[0], "%Y-%m-%d")
        else:
            date_obj = datetime.strptime(str(datetime_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(datetime_str)

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def format_priority(priority: str) -> str:
    """Format priority field"""
    if not priority:
        return ""
    return str(priority).title()

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

ESCALATION_COUNT_PAGINATED_QUERY = f"""
WITH deduped_inventory AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PRIORITY,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        INTERNALDUEDATE,
        EXTERNALDUEDATE,
        -- Use REASSIGNED_TO if it exists (non-null), otherwise use FIRST_ASSIGNED_TO
        COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) AS ASSIGNED_USER,
        LOB,
        PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      {{lob_filter}}
      AND PRIORITY IN ('Instant', 'Immediate')
      -- Item existed before end date
      {{escalation_created_filter}}
      -- Open or Pending status (these items don't have resolved dates)
      AND (PYSTATUSWORK ILIKE 'Open%' OR PYSTATUSWORK ILIKE 'Pend%')
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
),
deduped_user_profile AS (
    SELECT 
        USERID,
        PYREPORTTO,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS workitem_type,
    i.PRIORITY,
    i.PYSTATUSWORK AS status,
    i.LOB,
    i.PLATFORM,
    i.PXCREATEDATETIME,
    i.INTERNALDUEDATE,
    i.EXTERNALDUEDATE,
    i.ASSIGNED_USER AS associate_id,
    u.USERNAME AS associate_name
FROM deduped_inventory i
INNER JOIN deduped_user_profile u
    ON i.ASSIGNED_USER = u.USERID
WHERE i.rn = 1  -- Latest inventory version only
  AND u.rn = 1  -- Latest user profile version only
ORDER BY i.PRIORITY, i.PYID
LIMIT {{limit}} OFFSET {{offset}}
"""

ESCALATION_COUNT_DEFAULT_ORDER_BY = "ORDER BY i.PRIORITY, i.PYID"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item_id": "i.PYID",
        "workitem_type": "i.INTAKESOURCESYSTEM",
        "priority": "i.PRIORITY",
        "status": "i.PYSTATUSWORK",
        "lob": "i.LOB",
        "platform": "i.PLATFORM",
        "cob_sla": "DATEDIFF(day, i.PXCREATEDATETIME, i.INTERNALDUEDATE)",
        "elv_due_date": "i.EXTERNALDUEDATE",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return ESCALATION_COUNT_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, i.PRIORITY, i.PYID"

ESCALATION_COUNT_COUNT_QUERY = f"""
WITH deduped_inventory AS (
    SELECT
        PYID,
        -- Use REASSIGNED_TO if it exists (non-null), otherwise use FIRST_ASSIGNED_TO
        COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) AS ASSIGNED_USER,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      {{lob_filter}}
      AND PRIORITY IN ('Instant', 'Immediate')
      -- Item existed before end date
      {{escalation_created_filter}}
      -- Open or Pending status (these items don't have resolved dates)
      AND (PYSTATUSWORK ILIKE 'Open%' OR PYSTATUSWORK ILIKE 'Pend%')
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT PYID) AS ESCALATION_COUNT
FROM deduped_inventory
WHERE rn = 1  -- Latest inventory version only
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    if start_date and end_date:
        return f"AND PXCREATEDATETIME >= '{start_date}' AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_escalation_created_filter(end_date: Optional[str] = None) -> str:
    """Filter for escalation items that were created before the end date"""
    if end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

async def get_total_associates_count(manager_ids: Optional[List[str]] = None, user_id: str = None) -> int:
    """Get total count of associates under the given managers by calling associates_list API."""
    if not manager_ids or len(manager_ids) == 0:
        return 0
    
    try:
        # Create request for associates list API
        # Note: start_date and end_date are required but not used for counting all associates
        associates_request = AssociateListRequest(
            user_id=user_id or "system",
            start_date="2025-01-01",  # Placeholder dates - not used for counting
            end_date="2026-12-31",
            manager_ids=manager_ids,
            search=None,
            limit=5000
        )
        
        # Call the associates list API
        response = await get_associates_list(associates_request)
        
        # Return the total count from the response
        return response.total_count
    except Exception as e:
        logger.error(f"Error getting total associates count from API: {str(e)}")
        return 0


async def build_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for escalation items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If all associates are selected (frontline_associate_ids count matches total associates count),
    include manager IDs in the filter as well since items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Check if all associates are selected
    all_associates_selected = False
    if manager_ids and len(manager_ids) > 0:
        total_associates = await get_total_associates_count(manager_ids, user_id)
        if total_associates > 0 and len(frontline_associate_ids) == total_associates:
            all_associates_selected = True
            logger.info(f"All {total_associates} associates selected, including manager IDs in escalation filter")
    
    # Build the filter
    if all_associates_selected and manager_ids:
        # Include both associates and managers
        combined_ids = list(frontline_associate_ids) + list(manager_ids)
        combined_ids_str = "', '".join(combined_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{combined_ids_str}')"
    else:
        # Only include associates
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{frontline_associate_ids_str}')"

@router.post(
    "/escalation-count-drilldown",
    response_model=EscalationCountDrilldownPaginatedResponse,
    summary="Get Escalation Count Drilldown",
    description="""
Retrieve paginated list of escalated work items for detailed table display.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **priority** (optional): List of priority values (e.g., ['Instant', 'Immediate', 'Urgent'])
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item_id**: Unique work item identifier (PYID)
- **workitem_type**: Type of work item (INTAKESOURCESYSTEM)
- **priority**: Priority level (Instant, Immediate, Urgent)
- **status**: Current work item status
- **lob**: Line of Business
- **platform**: Processing platform

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (escalation data)
""",
)
async def get_escalation_count_drilldown(request: EscalationCountDrilldownPaginatedRequest) -> EscalationCountDrilldownPaginatedResponse:
    """Escalation count drilldown endpoint - direct query execution."""
    return await execute_escalation_count_drilldown_query(request)


async def execute_escalation_count_drilldown_query(request: EscalationCountDrilldownPaginatedRequest) -> EscalationCountDrilldownPaginatedResponse:
    """Execute escalation count drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        priority = request.priority
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        lob_filter = build_lob_filter(lob)
        date_filter = build_date_filter(start_date, end_date)
        escalation_created_filter = build_escalation_created_filter(end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(manager_ids)
        # Use async associate filter with manager ID logic
        associate_filter = await build_associate_filter(frontline_associate_ids, manager_ids, request.user_id)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached escalation_count from demand-inventory
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Get cached escalation count from demand-inventory
                # Build filters dict and hash for cache key
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'director_ids': request.director_ids,
                    'manager_ids': request.manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                cache_key = f"session:{session_id}:{filters_hash}:escalation_count"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Escalation is cached as list of priorities with counts, sum them
                    total_records = sum(int(item.get("ESCALATION_COUNT", 0)) for item in cached_metric)
                    logger.info(f"✅ Reused cached escalation count: {total_records} (from demand-inventory)")
                else:
                    logger.info(f"Cache miss for escalation_count, running COUNT query")
                    # Fall back to COUNT query
                    count_query = ESCALATION_COUNT_COUNT_QUERY.format(
                        lob_filter=lob_filter,
                        escalation_created_filter=escalation_created_filter,
                        director_filter=director_filter,
                        manager_filter=manager_filter,
                        associate_filter=associate_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("ESCALATION_COUNT", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached escalation count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = ESCALATION_COUNT_COUNT_QUERY.format(
                    lob_filter=lob_filter,
                    escalation_created_filter=escalation_created_filter,
                    director_filter=director_filter,
                    manager_filter=manager_filter,
                    associate_filter=associate_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("ESCALATION_COUNT", 0) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = ESCALATION_COUNT_COUNT_QUERY.format(
                lob_filter=lob_filter,
                escalation_created_filter=escalation_created_filter,
                director_filter=director_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("ESCALATION_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Execute data query to fetch paginated records
        data_query = ESCALATION_COUNT_PAGINATED_QUERY.format(
            lob_filter=lob_filter,
            escalation_created_filter=escalation_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            ESCALATION_COUNT_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)

        escalation_records = [
            EscalationCountRecord(
                work_item_id=record.get("WORK_ITEM_ID") or "",
                workitem_type=record.get("WORKITEM_TYPE") or "",
                priority=format_priority(record.get("PRIORITY")) or "",
                status=record.get("STATUS") or "",
                lob=record.get("LOB") or "",
                platform=record.get("PLATFORM") or "",
                cob_sla=str(int((record.get("INTERNALDUEDATE") - record.get("PXCREATEDATETIME")).total_seconds() / 86400)) if record.get("INTERNALDUEDATE") and record.get("PXCREATEDATETIME") else "N/A",
                elv_due_date=format_date_mmddyyyy(str(record.get("EXTERNALDUEDATE")).split()[0]) if record.get("EXTERNALDUEDATE") else "N/A"
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item_id": "Unique identifier for the work item (PYID)",
            "workitem_type": "Type or source system of the work item",
            "priority": "Priority level of the escalated work item",
            "status": "Current status of the work item",
            "lob": "Line of Business associated with the work item",
            "platform": "Platform where the work item is processed",
            "cob_sla": "COB Service Level Agreement - Time difference (in days) between Internal Due Date and Creation Date",
            "elv_due_date": "Elevance Due Date - External deadline for work item completion (EXTERNALDUEDATE)"
        }

        return EscalationCountDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=escalation_records,
            message="Escalation count records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated escalation count drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return EscalationCountDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve escalation count records: {str(e)}"
        )


@router.post(
    "/escalation-count-drilldown/download-excel",
    summary="Download Escalation Count Drilldown as Excel (Director)",
    description="""
Download complete escalation count drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all escalation count records
""",
)
async def download_escalation_count_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> Response:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
    try:
        # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        lob_filter = build_lob_filter(lob)
        escalation_created_filter = build_escalation_created_filter(request.end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(manager_ids)
        # Use async associate filter with manager ID logic
        associate_filter = await build_associate_filter(frontline_associate_ids, manager_ids, request.user_id)
        
        engine = connection_manager.get_engine()
        
        # Query with high limit for download (no pagination needed)
        download_query = ESCALATION_COUNT_PAGINATED_QUERY.format(
            lob_filter=lob_filter,
            escalation_created_filter=escalation_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        records_result = [
            {
                "work_item_id": row.get("WORK_ITEM_ID") or "",
                "workitem_type": row.get("WORKITEM_TYPE") or "",
                "priority": format_priority(row.get("PRIORITY")) or "",
                "status": row.get("STATUS") or "",
                "lob": row.get("LOB") or "",
                "platform": row.get("PLATFORM") or "",
                "cob_sla": str(int((row.get("INTERNALDUEDATE") - row.get("PXCREATEDATETIME")).total_seconds() / 86400)) if row.get("INTERNALDUEDATE") and row.get("PXCREATEDATETIME") else "N/A",
                "elv_due_date": format_date_mmddyyyy(str(row.get("EXTERNALDUEDATE")).split()[0]) if row.get("EXTERNALDUEDATE") else "N/A",
            }
            for row in (data_result or [])
        ]
    except Exception as e:
        logger.error(f"Excel download error for escalation count drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
    
    # STEP 3: Generate Excel file
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "Escalation Count"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item ID",
            "Work Item Type",
            "Priority",
            "Status",
            "LOB",
            "Platform",
            "COB SLA",
            "ELV Due Date"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        # Add data rows with field name compatibility
        for row_num, row in enumerate((records_result or []), start=2):
            if not isinstance(row, dict):
                continue
            ws.cell(row=row_num, column=1, value=str(row.get("work_item_id") or row.get("WORK_ITEM_ID", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("workitem_type") or row.get("WORKITEM_TYPE", "")))
            priority = row.get("priority") or row.get("PRIORITY")
            ws.cell(row=row_num, column=3, value=format_priority(priority) if priority else "")
            ws.cell(row=row_num, column=4, value=str(row.get("status") or row.get("STATUS", "")))
            ws.cell(row=row_num, column=5, value=str(row.get("lob") or row.get("LOB", "")))
            ws.cell(row=row_num, column=6, value=str(row.get("platform") or row.get("PLATFORM", "")))
            ws.cell(row=row_num, column=7, value=str(row.get("cob_sla") or row.get("COB_SLA", "N/A")) or "N/A")
            ws.cell(row=row_num, column=8, value=str(row.get("elv_due_date") or row.get("ELV_DUE_DATE", "N/A")) or "N/A")
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"escalation_count_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for escalation count drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
