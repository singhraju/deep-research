import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import StreamingResponse
import httpx
import asyncio

from db import SnowflakeConnectionManager
from schema import FuseTimeDirectorDrilldownRequest, FuseTimeDrilldownPaginatedResponse, FuseTimeRecord, PageResponse, DirectorBaseDownloadRequest
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime
from io import BytesIO
import math

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

FUSE_TIME_DIRECTOR_PAGINATED_QUERY = f"""
WITH associate_hierarchy AS (
    -- Validate hierarchy using inventory table
    -- Get list of associates who reported to specified manager/director during the period
    -- AND actually completed work (have inventory records)
    SELECT DISTINCT
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS work_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '{{start_date}}' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{associate_filter_invntry}}
      {{manager_filter}}
      {{director_filter}}
)
SELECT 
    u.USERNAME,
    u.USERID,
    u.LOGINDATE,
    u.FIRSTLOGINTIME,
    u.LASTLOGOUTTIME,
    u.TOTALSYSTEMTIME,
    u.FUSE_NON_PRODUCTIVE_TIME,
    u.PRODUCTIVETIME,
    -- Calculate Other Time: Total - (Productive + Non-Productive)
    COALESCE(u.TOTALSYSTEMTIME, 0) - 
    (COALESCE(
        CASE 
            WHEN u.PRODUCTIVETIME IS NOT NULL AND u.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END, 0
    ) + 
    COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0)) AS OTHER_TIME
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u 
INNER JOIN associate_hierarchy ah
    ON u.USERID = ah.PYRESOLVEDUSERID
    AND u.LOGINDATE = ah.work_date
ORDER BY u.LOGINDATE DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

FUSE_TIME_DIRECTOR_COUNT_QUERY = f"""
WITH associate_hierarchy AS (
    -- Validate hierarchy using inventory table
    -- Get list of associates who reported to specified manager/director during the period
    -- AND actually completed work (have inventory records)
    SELECT DISTINCT
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS work_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '{{start_date}}' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{associate_filter_invntry}}
      {{manager_filter}}
      {{director_filter}}
)
SELECT COUNT(*) as TOTAL_COUNT
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u 
INNER JOIN associate_hierarchy ah
    ON u.USERID = ah.PYRESOLVEDUSERID
    AND u.LOGINDATE = ah.work_date
"""

DEFAULT_FUSE_TIME_DIRECTOR_ORDER_BY = "u.LOGINDATE DESC"

PRODUCTIVE_TIME_SECONDS_SQL = """COALESCE(
    CASE
        WHEN u.PRODUCTIVETIME IS NOT NULL AND u.PRODUCTIVETIME != '' THEN
            (SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 +
             SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::INTEGER * 60 +
             SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::INTEGER)
        ELSE 0
    END, 0
)"""

SORTABLE_FUSE_TIME_DIRECTOR_COLUMNS = {
    "user_id": "u.USERNAME",
    "associate_name": "u.USERNAME",
    "date": "u.LOGINDATE",
    "log_in": "u.FIRSTLOGINTIME",
    "log_out": "u.LASTLOGOUTTIME",
    "total_fuse_time": "COALESCE(u.TOTALSYSTEMTIME, 0)",
    "productive_time": PRODUCTIVE_TIME_SECONDS_SQL,
    "non_productive_time": "COALESCE(u.FUSE_NON_PRODUCTIVE_TIME, 0)",
    "other_time": "OTHER_TIME",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_FUSE_TIME_DIRECTOR_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_FUSE_TIME_DIRECTOR_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid fuse time director sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_FUSE_TIME_DIRECTOR_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid fuse time director sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_FUSE_TIME_DIRECTOR_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "date":
        tie_breakers.append("u.LOGINDATE DESC")
    if normalized_sort_by not in {"user_id", "associate_name"}:
        tie_breakers.append("u.USERNAME ASC")
    tie_breakers.append("u.USERID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_fuse_time_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_FUSE_TIME_DIRECTOR_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str)[:10], "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def format_time_hhmm(time_str: str) -> str:
    """Format timestamp to HH:MM AM/PM ET format"""
    if not time_str:
        return ""
    try:
        # Parse the full timestamp
        time_obj = datetime.strptime(str(time_str)[:19], "%Y-%m-%d %H:%M:%S")
        # Format to 12-hour time with AM/PM and add ET
        return time_obj.strftime("%I:%M %p ET")
    except:
        return str(time_str)

def format_duration(duration_str: str) -> str:
    """Format duration to HH:MM:SS format"""
    if not duration_str:
        return "00:00:00"
    try:
        if ':' in str(duration_str):
            parts = str(duration_str).split(':')
            hours = int(parts[0])
            minutes = int(parts[1])
            seconds = int(float(parts[2])) if len(parts) > 2 else 0
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        total_seconds = int(float(duration_str))
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    except:
        return str(duration_str)

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for LOGINDATE in COB_AI_USER_PROFILE"""
    if start_date and end_date:
        return (
            f"AND LOGINDATE >= '{start_date}' "
            f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for COB_AI_USER_PROFILE table (uses USERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND USERID IN ('{frontline_associate_ids_str}')"
    return ""

def build_director_filter_invntry(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""

def build_manager_filter_invntry(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""



@router.post(
    "/fuse-time-director-drilldown",
    response_model=FuseTimeDrilldownPaginatedResponse,
    summary="Get Fuse Time Director Drilldown",
    description="""
Retrieve paginated list of fuse time records with manager-associate relationship aggregation for director-level view.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **user_id**: User ID
- **date**: Login date (MM/DD/YYYY format)
- **log_in**: First login time
- **log_out**: Last logout time
- **total_fuse_time**: Total system time formatted as 'X hrs Y mins'
- **non_productive_time**: Fuse non-productive time formatted as 'X hrs Y mins'
- **other_time**: Other time calculated as Total - OHI Productive Time - Non-Productive Time

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available

**Data Sources:** 
- COB_AI_USER_PROFILE (fuse time and manager-associate relationships)
""",
)
async def get_fuse_time_director_drilldown(
    request: FuseTimeDirectorDrilldownRequest
) -> FuseTimeDrilldownPaginatedResponse:
    """fuse time director drilldown endpoint - direct query execution."""
    return await execute_fuse_time_director_drilldown_query(request)


async def execute_fuse_time_director_drilldown_query(
    request: FuseTimeDirectorDrilldownRequest
) -> FuseTimeDrilldownPaginatedResponse:
    """Execute fuse time director drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        start_date = request.start_date
        end_date = request.end_date
        director_ids = request.director_ids
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids

        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        date_filter = build_date_filter(start_date, end_date)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        director_filter = build_director_filter_invntry(director_ids)
        manager_filter_invntry = build_manager_filter_invntry(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        engine = connection_manager.get_engine()
        
        count_query = FUSE_TIME_DIRECTOR_COUNT_QUERY.format(
            start_date=start_date,
            end_date=end_date,
            director_filter=director_filter,
            manager_filter=manager_filter_invntry,
            associate_filter_invntry=associate_filter_invntry
        )
        data_query = FUSE_TIME_DIRECTOR_PAGINATED_QUERY.format(
            start_date=start_date,
            end_date=end_date,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter_invntry,
            director_filter=director_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_fuse_time_query(data_query, request.sort_by, request.sort_direction)
        
        # Run COUNT and DATA queries in parallel for better performance
        count_result, records = await asyncio.gather(
            engine.execute_query_async(count_query, limit=1),
            engine.execute_query_async(data_query, limit=page_limit)
        )
        
        total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        fuse_time_records = [
            FuseTimeRecord(
                user_id=record.get("USERNAME") or "N/A",
                date=format_date_mmddyyyy(record.get("LOGINDATE")),
                log_in=format_time_hhmm(record.get("FIRSTLOGINTIME")) if record.get("FIRSTLOGINTIME") else None,
                log_out=format_time_hhmm(record.get("LASTLOGOUTTIME")) if record.get("LASTLOGOUTTIME") else None,
                total_fuse_time=format_duration(record.get("TOTALSYSTEMTIME")),
                productive_time=format_duration(record.get("PRODUCTIVETIME")),
                non_productive_time=format_duration(record.get("FUSE_NON_PRODUCTIVE_TIME")),
                other_time=format_duration(record.get('OTHER_TIME', 0))
            )
            for record in records
        ] if records else []

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "user_id": "Unique identifier for the user",
            "date": "Date when the user logged in",
            "log_in": "Time of first login for the day",
            "log_out": "Time of last logout for the day",
            "total_fuse_time": "Total time spent in the Fuse system",
            "productive_time": "Time spent on productive activities",
            "non_productive_time": "Time spent on non-productive activities in Fuse",
            "other_time": "Other Time (calculated as Total - (Productive + Non-Productive))"
        }

        return FuseTimeDrilldownPaginatedResponse(
            status="success",
            screen_id="fuse_time_director",
            user_id=request.user_id,
            page=page_response,
            records=fuse_time_records,
            message="Fuse time director records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated fuse time director drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return FuseTimeDrilldownPaginatedResponse(
            status="error",
            screen_id="fuse_time_director",
            user_id=request.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve fuse time director records: {str(e)}"
        )


@router.post(
    "/fuse-time-director-drilldown/download-excel",
    summary="Download Fuse Time Director Drilldown as Excel",
    description="""
Download complete fuse time director drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all fuse time records
""",
)
async def download_fuse_time_director_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> StreamingResponse:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
    try:
            # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        date_filter = build_date_filter(request.start_date, request.end_date)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        director_filter = build_director_filter_invntry(request.director_ids)
        manager_filter_invntry = build_manager_filter_invntry(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
            # Query with high limit for download (no pagination needed)
        download_query = FUSE_TIME_DIRECTOR_PAGINATED_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter_invntry,
            director_filter=director_filter,
            limit=1000000,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
    except Exception as e:
            logger.error(f"Excel download error for fuse time director drilldown: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
    
    # STEP 3: Generate Excel file
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "Fuse Time Director"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Associate Name",
            "Date",
            "Log In",
            "Log Out",
            "Total Fuse Time",
            "Productive Time",
            "Non-Productive Time",
            "Unclassified",
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("user_id") or row.get("USERNAME", "")))
            login_date = row.get("date") or row.get("LOGINDATE")
            ws.cell(row=row_num, column=2, value=format_date_mmddyyyy(str(login_date)) if login_date else "")
            log_in = row.get("log_in") or row.get("FIRSTLOGINTIME")
            ws.cell(row=row_num, column=3, value=format_time_hhmm(str(log_in)) if log_in else "")
            log_out = row.get("log_out") or row.get("LASTLOGOUTTIME")
            ws.cell(row=row_num, column=4, value=format_time_hhmm(str(log_out)) if log_out else "")
            # For time durations, check if already formatted string or numeric
            total_time = row.get("total_fuse_time") or row.get("TOTALSYSTEMTIME", 0)
            ws.cell(row=row_num, column=5, value=total_time if isinstance(total_time, str) and ":" in total_time else format_duration(total_time))
            productive = row.get("productive_time") or row.get("PRODUCTIVETIME", 0)
            ws.cell(row=row_num, column=6, value=productive if isinstance(productive, str) and ":" in productive else format_duration(productive))
            non_productive = row.get("non_productive_time") or row.get("FUSE_NON_PRODUCTIVE_TIME", 0)
            ws.cell(row=row_num, column=7, value=non_productive if isinstance(non_productive, str) and ":" in non_productive else format_duration(non_productive))
            other = row.get("other_time") or row.get("OTHER_TIME", 0)
            ws.cell(row=row_num, column=8, value=other if isinstance(other, str) and ":" in other else format_duration(other))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"fuse_time_director_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for fuse time director drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
