import asyncio
import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import DirectorBaseRequest, HeaderKPIsResponse, AssociateListRequest
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id
from controllers.Performance_IQ_Director.associates_list import get_associates_list

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()


WORK_ITEMS_COMPLETED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        {{date_filter}}
        {{lob_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter}}
)
SELECT COUNT(*) AS COMPLETED_TASKS
FROM invntry_deduped
WHERE rn = 1
"""

PRODUCTION_PCT_QUERY = f"""
WITH 
invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}} --REPORTTODIRECTORID in ()
      {{manager_filter}} --REPORTTOMANAGERID in ()
      {{associate_filter}} --PYRESOLVEDUSERID in ()
),
associate_work AS (
    SELECT 
        PYRESOLVEDUSERID AS userid,
        COUNT(DISTINCT PYID) AS work_items_completed,
        SUM(RETIME) AS total_retime_min
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID
),
user_daily AS (
    SELECT 
        USERID,
        USERNAME,
        LOGINDATE,
        TOTALSYSTEMTIME,
        non_prdctv_duration AS non_productive_sec,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INT * 60) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 2)::INT) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 3)::INT / 60.0) AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY USERID, LOGINDATE ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE 1=1
      {{user_date_filter}}
      {{manager_filter_user}}
      {{associate_filter_user}}
      AND TOTALSYSTEMTIME IS NOT NULL
),
associate_prod AS (
    SELECT 
        USERID AS userid,
        MAX(USERNAME) AS username,
        SUM(actual_production_min) AS total_prod_min
    FROM user_daily
    WHERE rn = 1
      AND actual_production_min > 0
    GROUP BY USERID
)
SELECT 
    ROUND(
        (SUM(w.total_retime_min) / NULLIF(SUM(p.total_prod_min), 0)) * 100,
        2
    ) AS AVG_PRODUCTION_PCT
FROM associate_work w
LEFT JOIN associate_prod p ON w.userid = p.userid
"""

AUDIT_SCORE_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{associate_filter}}
      {{director_filter}}
      {{manager_filter}}
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      {{lob_filter}}
      {{associate_filter_audit}}
)
SELECT 
    ROUND(AVG(a.AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT i.PYID) AS total_cases_audited
FROM invntry_deduped i  
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
"""

TAKT_TIME_QUERY = f"""
WITH 
-- Step 1: Deduplicate backlog items with filtering (point-in-time snapshot)
backlog_deduplicated AS (
    SELECT 
        PYID,
        PXCREATEDATETIME,
        INTERNALDUEDATE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        {{backlog_date_filter}}
        {{lob_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter_backlog}}
),

-- Step 2: Get total backlog volume
backlog_total AS (
    SELECT COUNT(DISTINCT PYID) AS total_backlog
    FROM backlog_deduplicated
    WHERE rn = 1
),

-- Step 3: Get active associates count using Workday data (eCOB Specialists)
active_associates AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID as USERID,
        ROW_NUMBER() OVER (PARTITION BY EMPLOYEE_DOMAIN_ID ORDER BY ASOFTODAY DESC, LOAD_TIMESTAMP DESC) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST
    WHERE JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
        AND TRY_CAST(ASOFTODAY AS DATE) IS NOT NULL
        AND TRY_CAST(ASOFTODAY AS DATE) <= {{end_date_param}}::DATE
        {{associate_filter_user}}
),

active_associates_total AS (
    SELECT COUNT(DISTINCT USERID) AS total_associates
    FROM active_associates
    WHERE rn = 1
),

-- Step 3.5: Calculate average productive hours per day from past 90 days
productive_hrs AS (
    SELECT
        ROUND(AVG(
           SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT
           + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0
           + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
        ), 2) AS avg_hrs_per_day
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
      AND u.TOTALSYSTEMTIME IS NOT NULL
      AND u.LOGINDATE BETWEEN DATEADD(day, -90, {{end_date_param}}::DATE) AND {{end_date_param}}::DATE
),

-- Step 4: Get latest PTO/UTO records for next 1 month from end_date (deduplicate by employee, date, and entry key)
pto_latest_records AS (
    SELECT 
        w.EMPLOYEE_DOMAIN_ID,
        w.TIME_OFF_DATE,
        w.HOURS,
        w.TIME_OFF_ENTRY_UNIQUE_KEY,
        ROW_NUMBER() OVER (
            PARTITION BY w.EMPLOYEE_DOMAIN_ID, w.TIME_OFF_DATE, w.TIME_OFF_ENTRY_UNIQUE_KEY 
            ORDER BY w.ASOFTODAY DESC, w.LOAD_TIMESTAMP DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    INNER JOIN active_associates a ON w.EMPLOYEE_DOMAIN_ID = a.USERID AND a.rn = 1
    WHERE w.STATUS = 'Approved'
        AND w.TIME_OFF_DATE >= {{end_date_param}}
        AND w.TIME_OFF_DATE <= DATEADD(month, 1, {{end_date_param}}::DATE)
        AND (w.TIME_OFF_TYPE ILIKE '%Paid Time Off%' 
             OR w.TIME_OFF_TYPE ILIKE '%Non Paid Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Sick Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Other Paid Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Paid Parental Leave%'
             OR w.TIME_OFF_TYPE ILIKE '%Wellness Days%'
             OR w.TIME_OFF_TYPE ILIKE '%On Leave%'
             OR w.TIME_OFF_TYPE ILIKE '%Critical Care Leave%')
),

-- Step 5: Aggregate PTO/UTO hours per employee per day (handles positive and negative hours)
pto_by_employee_by_day AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID,
        TIME_OFF_DATE,
        SUM(CAST(HOURS AS DECIMAL(10,2))) AS net_hours_per_day
    FROM pto_latest_records
    WHERE rn = 1
    GROUP BY EMPLOYEE_DOMAIN_ID, TIME_OFF_DATE
),

-- Step 6: Aggregate total PTO/UTO hours by employee across all days
pto_by_employee AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID,
        SUM(net_hours_per_day) AS total_pto_uto_hours
    FROM pto_by_employee_by_day
    WHERE net_hours_per_day > 0  -- Only count positive net hours (actual leave taken)
    GROUP BY EMPLOYEE_DOMAIN_ID
),

-- Step 7: Calculate total PTO/UTO hours across all employees
pto_total AS (
    SELECT SUM(total_pto_uto_hours) AS total_pto_hours
    FROM pto_by_employee
),

-- Step 8: Calculate working days in the next 1-month period from end_date (exclude weekends and holidays)
working_days AS (
    SELECT COUNT(*) AS total_working_days
    FROM (
        SELECT DATEADD(day, SEQ4(), {{end_date_param}}::DATE) AS work_date
        FROM TABLE(GENERATOR(ROWCOUNT => 31))
    ) dates
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA holidays
        ON dates.work_date = holidays.DATE
    WHERE dates.work_date <= DATEADD(month, 1, {{end_date_param}}::DATE)
      AND DAYOFWEEK(dates.work_date) NOT IN (0, 6)  -- Exclude Sunday (0) and Saturday (6)
      AND holidays.DATE IS NULL  -- Exclude holidays
)

-- Step 9: Calculate Overall Takt Time (using dynamic 1-month period with working days only)
SELECT 
    b.total_backlog AS backlog_volume,
    a.total_associates,
    w.total_working_days,
    ROUND(
        (a.total_associates * w.total_working_days * ph.avg_hrs_per_day) - 
        COALESCE(p.total_pto_hours, 0), 
    2) AS avail_man_hours,
    p.total_pto_hours,
    ROUND(
        ((a.total_associates * w.total_working_days * ph.avg_hrs_per_day) - 
         COALESCE(p.total_pto_hours, 0)) / NULLIF(b.total_backlog, 0), 
    2) AS takt_time_hrs,
    ROUND(
        (((a.total_associates * w.total_working_days * ph.avg_hrs_per_day) - 
          COALESCE(p.total_pto_hours, 0)) / NULLIF(b.total_backlog, 0)) * 60, 
    0) AS takt_time_mins
FROM backlog_total b
CROSS JOIN active_associates_total a
CROSS JOIN pto_total p
CROSS JOIN working_days w
CROSS JOIN productive_hrs ph
"""

CYCLE_TIME_AVG_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        CYCLE_TIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
      AND CYCLE_TIME IS NOT NULL
)
SELECT 
    COUNT(DISTINCT PYID) AS total_resolved_items,
    ROUND(AVG(CYCLE_TIME), 2) AS avg_cycle_time_seconds,
    ROUND(AVG(CYCLE_TIME) / 60, 2) AS avg_cycle_time_minutes
FROM invntry_deduped
WHERE rn = 1
"""

def format_takt_time(takt_time_avg: float) -> str:
    """Format takt time from minutes to human-readable string with precise calculation"""
    if takt_time_avg > 0:
        if takt_time_avg >= 60:
            # For values >= 60 minutes, show as hours and minutes
            hours = int(takt_time_avg // 60)
            mins = int(takt_time_avg % 60)
            return f"{hours} hrs. {mins} mins."
        else:
            # For values < 60 minutes, show as minutes and seconds for precision
            total_minutes = int(takt_time_avg)
            seconds = int((takt_time_avg - total_minutes) * 60)
            return f"{total_minutes} min. {seconds} sec."
    return "N/A"

def format_cycle_time(minutes: float) -> str:
    """Format cycle time from decimal minutes to 'X min Y sec' format."""
    total_minutes = int(minutes)
    seconds = int((minutes - total_minutes) * 60)
    return f"{total_minutes} min. {seconds} sec."

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return f"AND {date_column} >= '{start_date}' AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_backlog_date_filter(end_date: Optional[str] = None) -> str:
    """Build date filter for backlog snapshot - items created before end_date and still open or resolved on/after end_date.
    
    Args:
        end_date: Date to take backlog snapshot (default: no filter)
    
    Returns:
        SQL filter string for backlog point-in-time snapshot
    """
    if end_date:
        return f"""AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)
        AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{end_date}'::DATE))"""
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "PYRESOLVEDUSERID") -> str:
    """Build associate filter for inventory/work items tables.
    
    Args:
        frontline_associate_ids: List of associate IDs to filter
        column: Column name to filter on (default: PYRESOLVEDUSERID)
    """
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{frontline_associate_ids_str}')"
    return ""


def build_director_filter(director_ids: Optional[List[str]] = None, column: str = "REPORTTODIRECTORID") -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID).
    
    Args:
        director_ids: List of director IDs to filter
        column: Column name to filter on (default: REPORTTODIRECTORID)
    """
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND {column} IN ('{director_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None, column: str = "REPORTTOMANAGERID") -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID).
    
    Args:
        manager_ids: List of manager IDs to filter
        column: Column name to filter on (default: REPORTTOMANAGERID)
    """
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND {column} IN ('{manager_ids_str}')"
    return ""


def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO).
    
    Args:
        manager_ids: List of manager IDs to filter
    """
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


async def get_total_associates_count(manager_ids: Optional[List[str]] = None, user_id: str = None) -> int:
    """Get total count of associates under the given managers by calling associates_list API."""
    if not manager_ids or len(manager_ids) == 0:
        return 0
    
    try:
        # Create request for associates list API
        # Note: start_date and end_date are required but not used for counting
        associates_request = AssociateListRequest(
            user_id=user_id or "system",
            start_date="2025-01-01",  # Placeholder dates - not used for counting
            end_date="2026-12-31",
            manager_ids=manager_ids,
            search=None,
            limit=5000
        )
        
        # Call the associates list API
        response = await get_associates_list(associates_request)
        
        # Return the total count from the response
        return response.total_count
    except Exception as e:
        logger.error(f"Error getting total associates count from API: {str(e)}")
        return 0


async def build_backlog_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for backlog items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If all associates are selected (frontline_associate_ids count matches total associates count),
    include manager IDs in the filter as well since items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Check if all associates are selected
    all_associates_selected = False
    if manager_ids and len(manager_ids) > 0:
        total_associates = await get_total_associates_count(manager_ids, user_id)
        if total_associates > 0 and len(frontline_associate_ids) == total_associates:
            all_associates_selected = True
            logger.info(f"All {total_associates} associates selected, including manager IDs in takt time backlog filter")
    
    # Build the filter
    if all_associates_selected and manager_ids:
        # Include both associates and managers
        combined_ids = list(frontline_associate_ids) + list(manager_ids)
        combined_ids_str = "', '".join(combined_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{combined_ids_str}')"
    else:
        # Only include associates
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{frontline_associate_ids_str}')"


def get_audit_score_bubble(audit_score_value: float) -> str:
    """Determine audit score status bubble based on value.
    
    Rating Scale:
    - Exceptional: 100%
    - Exceeds: 99% - 99.99%
    - Meets: 98% - 98.99%
    - Approaching: 95.99% - 97.99%
    - Poor: Below 95.99%
    """
    if not audit_score_value or audit_score_value == 0.0:
        return "N/A"
    
    if audit_score_value >= 100:
        return "Exceptional"
    elif audit_score_value >= 99:
        return "Exceeds"
    elif audit_score_value >= 98:
        return "Meets"
    elif audit_score_value >= 95.99:
        return "Approaching"
    else:
        return "Poor"


def get_production_pct_bubble(production_pct_value: float) -> str:
    """Determine production percentage status bubble based on value.
    
    Rating Scale:
    - Exceptional: 120% or above
    - Exceeds: 115.99% - 119.99%
    - Meets: 100% - 114.59%
    - Approaching: 95% - 99.99%
    - Poor: Below 95%
    """
    if not production_pct_value or production_pct_value == 0.0:
        return "N/A"
    
    if production_pct_value >= 120:
        return "Exceptional"
    elif production_pct_value >= 115.99:
        return "Exceeds"
    elif production_pct_value >= 100:
        return "Meets"
    elif production_pct_value >= 95:
        return "Approaching"
    else:
        return "Poor"




@router.post(
    "/header-kpis",
    response_model=HeaderKPIsResponse,
    summary="Get Director Header KPIs",
    description="""Returns key performance indicators for directors:
- Work Items Completed: Total resolved items in date range
- Production %: Average production percentage across associates  
- Audit Score: Average audit quality score
- Cycle Time: Average time to complete work items
- Takt Time: Required completion time per item to meet demand (calculated from backlog, available hours, and PTO/UTO)
- Volume Forecast Accuracy: Awaiting baseline data"""
)
async def get_header_kpis(request: DirectorBaseRequest) -> HeaderKPIsResponse:
    """Header KPIs endpoint with session-based metric-level caching."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_header_kpis_query(request)


async def execute_header_kpis_query(request: DirectorBaseRequest) -> HeaderKPIsResponse:
    """Execute header KPIs query logic with metric-level caching."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        associate_filter = build_associate_filter(request.frontline_associate_ids)
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        associate_filter_audit = build_associate_filter(request.frontline_associate_ids, column="AUDIT_SUBJECT_ID")
        engine = connection_manager.get_engine()

        # Format queries with consistent filter approach
        completed_query = WORK_ITEMS_COMPLETED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        production_query = PRODUCTION_PCT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            user_date_filter=user_date_filter,
            manager_filter_user=manager_filter_user,
            associate_filter_user=associate_filter_user
        )
        audit_query = AUDIT_SCORE_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_audit=associate_filter_audit
        )
        cycle_time_query = CYCLE_TIME_AVG_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        
        # Build takt time query with backlog-specific filters (point-in-time snapshot)
        backlog_date_filter = build_backlog_date_filter(request.end_date)
        # Use async filter that includes manager IDs if all associates are selected
        associate_filter_backlog = await build_backlog_associate_filter(
            request.frontline_associate_ids, 
            request.manager_ids, 
            request.user_id
        )
        
        # Use end_date for takt time calculation, or CURRENT_DATE if not provided
        end_date_for_takt = f"'{request.end_date}'::DATE" if request.end_date else "CURRENT_DATE"
        
        takt_time_query = TAKT_TIME_QUERY.format(
            backlog_date_filter=backlog_date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_backlog=associate_filter_backlog,
            manager_filter_user=manager_filter_user,
            associate_filter_user=associate_filter_user,
            end_date_param=end_date_for_takt
        )
        logger.info("Executing takt time query")
        # Get session_id for caching
        session_id = getattr(request, "session_id", None)
        
        # Build filters dict for cache isolation
        filters = {
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
            'director_ids': request.director_ids,
            'manager_ids': request.manager_ids,
            'frontline_associate_ids': request.frontline_associate_ids,
        }
        
        # Define async fetch functions for each metric
        async def fetch_work_items():
            return await engine.execute_query_async(completed_query, limit=1)
        
        async def fetch_production_pct():
            return await engine.execute_query_async(production_query, limit=1)
        
        async def fetch_audit_score():
            return await engine.execute_query_async(audit_query, limit=1)
        
        async def fetch_cycle_time():
            return await engine.execute_query_async(cycle_time_query, limit=1)
        
        async def fetch_takt_time():
            return await engine.execute_query_async(takt_time_query, limit=1)
        
        # Get or fetch cached metrics (only cache if session_id provided)
        if session_id:
            completed_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_work_items,
                session_id=session_id,
                metric_name="work_items_completed",
                filters=filters
            )
            
            production_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_production_pct,
                session_id=session_id,
                metric_name="production_pct",
                filters=filters
            )
            
            audit_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_score,
                session_id=session_id,
                metric_name="audit_score",
                filters=filters
            )
            
            cycle_time_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_cycle_time,
                session_id=session_id,
                metric_name="cycle_time",
                filters=filters
            )
            
            takt_time_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_takt_time,
                session_id=session_id,
                metric_name="takt_time",
                filters=filters
            )
        else:
            # No session_id - execute all 5 queries in parallel without caching
            logger.info("Executing 5 Director header KPI queries in parallel")
            (
                completed_records,
                production_records,
                audit_records,
                cycle_time_records,
                takt_time_records
            ) = await asyncio.gather(
                fetch_work_items(),
                fetch_production_pct(),
                fetch_audit_score(),
                fetch_cycle_time(),
                fetch_takt_time(),
                return_exceptions=False
            )
            logger.info("Parallel query execution completed")

        work_items_completed = int(completed_records[0].get("COMPLETED_TASKS", 0)) if completed_records else 0
        production_pct_achieved = float(production_records[0].get("AVG_PRODUCTION_PCT", 0)) if production_records and production_records[0].get("AVG_PRODUCTION_PCT") else 0.0
        audit_score_pct = float(audit_records[0].get("AVG_AUDIT_SCORE", 0)) if audit_records and audit_records[0].get("AVG_AUDIT_SCORE") else 0.0

        # Extract takt time from query result
        if takt_time_records and takt_time_records[0].get("TAKT_TIME_MINS"):
            takt_time_mins = float(takt_time_records[0].get("TAKT_TIME_MINS", 0))
            takt_time_str = format_takt_time(takt_time_mins)
        else:
            takt_time_str = "N/A"

        # Extract cycle time average
        if cycle_time_records and cycle_time_records[0].get("AVG_CYCLE_TIME_MINUTES"):
            avg_minutes = float(cycle_time_records[0].get("AVG_CYCLE_TIME_MINUTES", 0))
            cycle_time_str = format_cycle_time(avg_minutes)
        else:
            cycle_time_str = "N/A"

        # Calculate status bubbles
        production_status = get_production_pct_bubble(production_pct_achieved)
        audit_score_status = get_audit_score_bubble(audit_score_pct)

        tooltips = {
            "work_items_completed": "Total number of work items resolved in the selected date range",
            "production_pct_achieved": "Average production percentage achieved across all associates",
            "production_pct_achieved_status": "Performance rating: Exceptional (>=120%), Exceeds (115.99-119.99%), Meets (100-114.59%), Approaching (95-99.99%), Poor (<95%)",
            "audit_score_pct": "Average audit quality score across all audited cases",
            "audit_score_pct_status": "Quality rating: Exceptional (100%), Exceeds (99-99.99%), Meets (98-98.99%), Approaching (95.99-97.99%), Poor (<95.99%)",
            "cycle_time_avg": "Average time to complete a work item from assignment to resolution",
            "takt_time": "Required completion time per item to meet demand. Formula: (Available Man Hours - PTO/UTO) / Backlog Volume. Calculated using working days in next month period and 5.3 hours avg per day",
            "volume_forecast_accuracy": "Accuracy of volume forecasts vs actual (awaiting baseline data)"
        }

        return HeaderKPIsResponse(
            status="success",
            work_items_completed=work_items_completed,
            production_pct_achieved=production_pct_achieved,
            audit_score_pct=audit_score_pct,
            cycle_time_avg=cycle_time_str,
            takt_time=takt_time_str,
            volume_forecast_accuracy="N/A",
            message="Header KPIs retrieved successfully",
            tooltips=tooltips,
            production_pct_achieved_status=production_status,
            audit_score_pct_status=audit_score_status,
            cycle_time_avg_status="N/A"
        )

    except Exception as e:
        logger.error(f"Header KPIs query error: {type(e).__name__}: {str(e)}")
        return HeaderKPIsResponse(
            status="error",
            work_items_completed=0,
            production_pct_achieved=0.0,
            audit_score_pct=0.0,
            cycle_time_avg="N/A",
            takt_time="N/A",
            volume_forecast_accuracy="N/A",
            message=f"Failed to retrieve header KPIs: {str(e)}",
            production_pct_achieved_status="N/A",
            audit_score_pct_status="N/A",
            cycle_time_avg_status="N/A"
        )
