import logging
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import ManagerListRequestForDirector, ManagerListResponse, ManagerItem
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
from utils import cache_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

MANAGERS_LIST_QUERY = f"""
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
),
manager AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYREPORTTO
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT DISTINCT
    manager.USERID AS MANAGER_ID,
    manager.USERNAME AS MANAGER_NAME
FROM frontline
INNER JOIN manager
    ON frontline.PYREPORTTO = manager.USERID
WHERE 1=1
{{directors_filter}}
ORDER BY manager.USERNAME
"""


def build_directors_filter(directors: list = None) -> str:
    """Build filter for managers under selected directors."""
    if directors and len(directors) > 0:
        directors_values = "', '".join(directors)
        return f"AND manager.PYREPORTTO IN ('{directors_values}')"
    return ""


@router.post(
    "/managers-list",
    response_model=ManagerListResponse,
    summary="Get List of Managers",
    description="""
Retrieve unique list of managers for filter dropdown.
Shows only managers who had frontline associates reporting to them in the last 1 year.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **search** (optional): Search term to filter managers by name
- **directors** (required): List of directors ID's

**Response Fields:**
- **status**: Status of the request (success/error)
- **managers**: List of ManagerItem objects containing manager_id and manager_name
- **total_count**: Total number of managers returned
- **message**: Response message
- **service**: Service name (idiscovery-cob-dashboard-service)

**Data Source:** COB_AI_USER_PROFILE table (filtered to last 1 year of login activity)
**Caching:** Results cached for 6 hours (21,600s)
""",
)
async def get_managers_list(request: ManagerListRequestForDirector) -> ManagerListResponse:
    if not connection_manager.validate_config():
        logger.error("[MANAGERS_LIST] Snowflake credentials not configured")
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    # Build cache key
    directors_key = ",".join(request.directors) if request.directors else ""
    cache_key = cache_manager.build_key(
        "managers:list",
        search=request.search or "",
        directors=directors_key
    )
    
    async def fetch_from_db():
        """Fetch managers list from database."""
        try:
            engine = connection_manager.get_engine()
            directors_filter = build_directors_filter(request.directors)
            
            query = MANAGERS_LIST_QUERY.format(
                directors_filter=directors_filter
            )
            
            records = await engine.execute_query_async(query, limit=10001)
            
            managers = [
                {
                    "manager_id": r.get("MANAGER_ID", ""),
                    "manager_name": r.get("MANAGER_NAME", "")
                }
                for r in records
                if r.get("MANAGER_ID") and r.get("MANAGER_NAME")
            ] if records else []

            return {
                "status": "success",
                "managers": managers,
                "total_count": len(managers),
                "message": "Managers list retrieved successfully"
            }

        except Exception as e:
            logger.error(f"[MANAGERS_LIST] Error occurred: {type(e).__name__}: {str(e)}")
            logger.exception(f"[MANAGERS_LIST] Full exception traceback:")
            return {
                "status": "error",
                "managers": [],
                "total_count": 0,
                "message": f"Failed to retrieve managers list: {str(e)}"
            }
    
    # Get from cache or fetch from DB (6 hour TTL)
    result = await cache_manager.get_or_fetch(cache_key, fetch_from_db, ttl=METRIC_CACHE_TTL)
    
    # Convert dict to response model
    managers = [ManagerItem(**m) for m in result["managers"]]
    
    return ManagerListResponse(
        status=result["status"],
        managers=managers,
        total_count=result["total_count"],
        message=result["message"]
    )
