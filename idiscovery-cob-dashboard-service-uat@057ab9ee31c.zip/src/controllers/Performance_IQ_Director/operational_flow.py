import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import DirectorBaseRequest, OperationalFlowResponse, AssignmentTypeItem, TaktTimeItem, AssociateListRequest
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id
from controllers.Performance_IQ_Director.associates_list import get_associates_list

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()


LEAD_TIME_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        COMPANYRECEIVEDDATE,
        PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND COMPANYRECEIVEDDATE IS NOT NULL
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
)
SELECT 
    AVG(DATEDIFF('minute', COMPANYRECEIVEDDATE, PYRESOLVEDTIMESTAMP)) AS LEAD_TIME_AVG_MINUTES
FROM invntry_deduped
WHERE rn = 1
"""

ASSIGNMENT_TYPE_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        ASSIGNED_BY,
        FIRST_ASSIGNED_TO,
        REASSIGNED_BY,
        REASSIGNED_FROM,
        REASSIGNED_TO,
        PYRESOLVEDUSERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE ASSIGNED_BY IS NOT NULL
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
),
frontline_users AS (
    SELECT DISTINCT USERID
    FROM (
        SELECT 
            USERID,
            USERID_PROFILE,
            ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
        WHERE USERID_PROFILE = 'Frontline'
    ) sub
    WHERE rn = 1
)
SELECT 
    CASE WHEN ASSIGNED_BY LIKE 'GNW%' THEN 'GNW Assigned' ELSE 'Manually Assigned' END AS ASSIGNMENT_TYPE,
    COUNT(PYID) AS TOTAL_CNT,
    COUNT(CASE 
        WHEN REASSIGNED_BY IS NOT NULL 
        AND FIRST_ASSIGNED_TO != PYRESOLVEDUSERID 
        -- NEW: For manual assignments, validate REASSIGNED_FROM is frontline
        AND (
            ASSIGNED_BY LIKE 'GNW%'  -- GNW assignments don't need validation
            OR EXISTS (
                SELECT 1 
                FROM frontline_users f 
                WHERE f.USERID = REASSIGNED_FROM  -- Changed from FIRST_ASSIGNED_TO
            )
        )
        THEN PYID 
    END) AS REASSIGNED_CNT,
    ROUND(COUNT(PYID) * 100.0 / SUM(COUNT(PYID)) OVER (), 2) AS ASSIGNMENT_PCT,
    ROUND(COUNT(CASE 
        WHEN REASSIGNED_BY IS NOT NULL 
        AND FIRST_ASSIGNED_TO != PYRESOLVEDUSERID 
        -- NEW: For manual assignments, validate REASSIGNED_FROM is frontline
        AND (
            ASSIGNED_BY LIKE 'GNW%'  -- GNW assignments don't need validation
            OR EXISTS (
                SELECT 1 
                FROM frontline_users f 
                WHERE f.USERID = REASSIGNED_FROM  -- Changed from FIRST_ASSIGNED_TO
            )
        )
        THEN PYID 
    END) * 100.0 / NULLIF(COUNT(PYID), 0), 2) AS REASSIGNED_PCT
FROM invntry_deduped
WHERE rn = 1
GROUP BY CASE WHEN ASSIGNED_BY LIKE 'GNW%' THEN 'GNW Assigned' ELSE 'Manually Assigned' END
"""

# REASSIGN_PCT_QUERY removed - calculated from assignment records instead

CYCLE_TAKT_QUERY = f"""
WITH 
-- Calculate Cycle Time from resolved items
cycle_time_deduped AS (
    SELECT 
        PYID,
        CYCLE_TIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
      AND CYCLE_TIME IS NOT NULL
),

cycle_time_avg AS (
    SELECT 
        ROUND(AVG(CYCLE_TIME) / 60, 2) AS avg_cycle_time_minutes
    FROM cycle_time_deduped
    WHERE rn = 1
),

-- Calculate Takt Time from backlog items (point-in-time snapshot)
backlog_deduplicated AS (
    SELECT 
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        {{backlog_date_filter}}
        {{lob_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter_backlog}}
),

backlog_total AS (
    SELECT COUNT(DISTINCT PYID) AS total_backlog
    FROM backlog_deduplicated
    WHERE rn = 1
),

active_associates AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID as USERID,
        ROW_NUMBER() OVER (PARTITION BY EMPLOYEE_DOMAIN_ID ORDER BY ASOFTODAY DESC, LOAD_TIMESTAMP DESC) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST
    WHERE JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
        AND TRY_CAST(ASOFTODAY AS DATE) IS NOT NULL
        AND TRY_CAST(ASOFTODAY AS DATE) <= {{end_date_param}}::DATE
        {{associate_filter_user}}
),

active_associates_total AS (
    SELECT COUNT(DISTINCT USERID) AS total_associates
    FROM active_associates
    WHERE rn = 1
),

productive_hrs AS (
    SELECT
        ROUND(AVG(
           SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT
           + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0
           + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
        ), 2) AS avg_hrs_per_day
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
      AND u.TOTALSYSTEMTIME IS NOT NULL
      AND u.LOGINDATE BETWEEN DATEADD(day, -90, {{end_date_param}}::DATE) AND {{end_date_param}}::DATE
),

pto_latest_records AS (
    SELECT 
        w.EMPLOYEE_DOMAIN_ID,
        w.TIME_OFF_DATE,
        w.HOURS,
        w.TIME_OFF_ENTRY_UNIQUE_KEY,
        ROW_NUMBER() OVER (
            PARTITION BY w.EMPLOYEE_DOMAIN_ID, w.TIME_OFF_DATE, w.TIME_OFF_ENTRY_UNIQUE_KEY 
            ORDER BY w.ASOFTODAY DESC, w.LOAD_TIMESTAMP DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    INNER JOIN active_associates a ON w.EMPLOYEE_DOMAIN_ID = a.USERID AND a.rn = 1
    WHERE w.STATUS = 'Approved'
        AND w.TIME_OFF_DATE >= {{end_date_param}}
        AND w.TIME_OFF_DATE <= DATEADD(month, 1, {{end_date_param}}::DATE)
        AND (w.TIME_OFF_TYPE ILIKE '%Paid Time Off%' 
             OR w.TIME_OFF_TYPE ILIKE '%Non Paid Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Sick Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Other Paid Time%'
             OR w.TIME_OFF_TYPE ILIKE '%Paid Parental Leave%'
             OR w.TIME_OFF_TYPE ILIKE '%Wellness Days%'
             OR w.TIME_OFF_TYPE ILIKE '%On Leave%'
             OR w.TIME_OFF_TYPE ILIKE '%Critical Care Leave%')
),

pto_by_employee_by_day AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID,
        TIME_OFF_DATE,
        SUM(CAST(HOURS AS DECIMAL(10,2))) AS net_hours_per_day
    FROM pto_latest_records
    WHERE rn = 1
    GROUP BY EMPLOYEE_DOMAIN_ID, TIME_OFF_DATE
),

pto_by_employee AS (
    SELECT 
        EMPLOYEE_DOMAIN_ID,
        SUM(net_hours_per_day) AS total_pto_uto_hours
    FROM pto_by_employee_by_day
    WHERE net_hours_per_day > 0
    GROUP BY EMPLOYEE_DOMAIN_ID
),

pto_total AS (
    SELECT SUM(total_pto_uto_hours) AS total_pto_hours
    FROM pto_by_employee
),

working_days AS (
    SELECT COUNT(*) AS total_working_days
    FROM (
        SELECT DATEADD(day, SEQ4(), {{end_date_param}}::DATE) AS work_date
        FROM TABLE(GENERATOR(ROWCOUNT => 31))
    ) dates
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA holidays
        ON dates.work_date = holidays.DATE
    WHERE dates.work_date <= DATEADD(month, 1, {{end_date_param}}::DATE)
      AND DAYOFWEEK(dates.work_date) NOT IN (0, 6)
      AND holidays.DATE IS NULL
),

takt_time_calc AS (
    SELECT 
        ROUND(
            (((a.total_associates * w.total_working_days * ph.avg_hrs_per_day) - 
              COALESCE(p.total_pto_hours, 0)) / NULLIF(b.total_backlog, 0)) * 60, 
        0) AS takt_time_mins
    FROM backlog_total b
    CROSS JOIN active_associates_total a
    CROSS JOIN pto_total p
    CROSS JOIN working_days w
    CROSS JOIN productive_hrs ph
)

-- Combine both cycle time and takt time in single result
SELECT 
    c.avg_cycle_time_minutes,
    t.takt_time_mins
FROM cycle_time_avg c
CROSS JOIN takt_time_calc t
"""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_backlog_date_filter(end_date: Optional[str] = None) -> str:
    """Build date filter for backlog snapshot - items created before end_date and still open or resolved on/after end_date."""
    if end_date:
        return f"""AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)
        AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{end_date}'::DATE))"""
    return ""


def build_director_filter(director_ids: Optional[List[str]] = None, column: str = "REPORTTODIRECTORID") -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND {column} IN ('{director_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None, column: str = "REPORTTOMANAGERID") -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND {column} IN ('{manager_ids_str}')"
    return ""


def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "PYRESOLVEDUSERID") -> str:
    """Build associate filter with flexible column parameter."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{frontline_associate_ids_str}')"
    return ""


def build_user_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses PYREPORTTO directly)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


async def get_total_associates_count(manager_ids: Optional[List[str]] = None, user_id: str = None) -> int:
    """Get total count of associates under the given managers by calling associates_list API."""
    if not manager_ids or len(manager_ids) == 0:
        return 0
    
    try:
        # Create request for associates list API
        # Note: start_date and end_date are required but not used for counting
        associates_request = AssociateListRequest(
            user_id=user_id or "system",
            start_date="2025-01-01",  # Placeholder dates - not used for counting
            end_date="2026-12-31",
            manager_ids=manager_ids,
            search=None,
            limit=5000
        )
        
        # Call the associates list API
        response = await get_associates_list(associates_request)
        
        # Return the total count from the response
        return response.total_count
    except Exception as e:
        logger.error(f"Error getting total associates count from API: {str(e)}")
        return 0


async def build_backlog_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for backlog items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If all associates are selected (frontline_associate_ids count matches total associates count),
    include manager IDs in the filter as well since items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Check if all associates are selected
    all_associates_selected = False
    if manager_ids and len(manager_ids) > 0:
        total_associates = await get_total_associates_count(manager_ids, user_id)
        if total_associates > 0 and len(frontline_associate_ids) == total_associates:
            all_associates_selected = True
            logger.info(f"All {total_associates} associates selected, including manager IDs in takt time backlog filter")
    
    # Build the filter
    if all_associates_selected and manager_ids:
        # Include both associates and managers
        combined_ids = list(frontline_associate_ids) + list(manager_ids)
        combined_ids_str = "', '".join(combined_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{combined_ids_str}')"
    else:
        # Only include associates
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{frontline_associate_ids_str}')"


def format_cycle_takt_gap(cycle_time_mins: float, takt_time_mins: float) -> str:
    """Format cycle-takt gap from minutes to human-readable string with precise calculation.
    
    Positive gap = cycle time > takt time (slower than needed)
    Negative gap = cycle time < takt time (faster than needed)
    """
    if cycle_time_mins and takt_time_mins:
        gap_mins = cycle_time_mins - takt_time_mins
        abs_gap_mins = abs(gap_mins)
        sign = "+" if gap_mins > 0 else "-" if gap_mins < 0 else ""
        
        if abs_gap_mins >= 60:
            # For values >= 60 minutes, show as hours and minutes
            hours = int(abs_gap_mins // 60)
            mins = int(abs_gap_mins % 60)
            return f"{sign}{hours} hrs. {mins} mins."
        else:
            # For values < 60 minutes, show as minutes and seconds for precision
            total_minutes = int(abs_gap_mins)
            seconds = int((abs_gap_mins - total_minutes) * 60)
            return f"{sign}{total_minutes} min. {seconds} sec."
    return "N/A"






@router.post(
    "/operational-flow",
    response_model=OperationalFlowResponse,
    summary="Get Operational Flow Metrics",
    description="""
Retrieve operational flow and execution metrics for director dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Response Fields:**
- **lead_time_avg_days**: Average lead time in days (from company received to resolution)
- **cycle_takt_gap**: Gap between cycle time and takt time (Cycle Time - Takt Time). Positive = slower than needed, Negative = faster than needed
- **assignment_type_breakdown**: GNW vs Manual assignment breakdown with reassignment percentages
- **reassign_pct**: Overall percentage of items that were reassigned

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (inventory and cycle time data)
- COB_AI_USER_PROFILE (associate and manager data)
- COB_AI_WORKDAY_HIST (PTO/UTO data for takt time calculation)
""",
)
async def get_operational_flow(request: DirectorBaseRequest) -> OperationalFlowResponse:
    """Operational flow endpoint with metric-level caching."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_operational_flow_query(request)


async def execute_operational_flow_query(request: DirectorBaseRequest) -> OperationalFlowResponse:
    """Execute operational flow query logic (core business logic)."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        assignment_date_filter = build_date_filter(request.start_date, request.end_date, date_column="ASSIGNED_DT")
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter = build_associate_filter(request.frontline_associate_ids, column="PYRESOLVEDUSERID")
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        engine = connection_manager.get_engine()

        lead_time_query = LEAD_TIME_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        assignment_query = ASSIGNMENT_TYPE_QUERY.format(
            date_filter=assignment_date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        
        # Build combined cycle-takt query with all necessary filters (point-in-time snapshot)
        backlog_date_filter = build_backlog_date_filter(request.end_date)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        # Use async filter that includes manager IDs if all associates are selected
        associate_filter_backlog = await build_backlog_associate_filter(
            request.frontline_associate_ids,
            request.manager_ids,
            request.user_id
        )
        
        # Use end_date for takt time calculation, or CURRENT_DATE if not provided
        end_date_for_takt = f"'{request.end_date}'::DATE" if request.end_date else "CURRENT_DATE"
        
        cycle_takt_query = CYCLE_TAKT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            backlog_date_filter=backlog_date_filter,
            associate_filter_backlog=associate_filter_backlog,
            manager_filter_user=manager_filter_user,
            associate_filter_user=associate_filter_user,
            end_date_param=end_date_for_takt
        )
        
        # Define async fetch functions for caching
        async def fetch_lead_time():
            return await engine.execute_query_async(lead_time_query, limit=1)
        
        async def fetch_assignment_types():
            return await engine.execute_query_async(assignment_query, limit=100)
        
        async def fetch_cycle_takt():
            return await engine.execute_query_async(cycle_takt_query, limit=1)
        
        # Get or fetch cached metrics (only cache if session_id provided)
        session_id = getattr(request, "session_id", None)
        
        # Build filters dict for cache isolation
        filters = {
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
            'director_ids': request.director_ids,
            'manager_ids': request.manager_ids,
            'frontline_associate_ids': request.frontline_associate_ids,
        }
        
        if session_id:
            lead_time_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_lead_time,
                session_id=session_id,
                metric_name="lead_time",
                filters=filters
            )
            
            assignment_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_assignment_types,
                session_id=session_id,
                metric_name="assignment_types",
                filters=filters
            )
            
            cycle_takt_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_cycle_takt,
                session_id=session_id,
                metric_name="cycle_takt",
                filters=filters
            )
        else:
            # Execute all 3 queries in parallel without caching
            logger.info("Executing 3 Director operational flow queries in parallel")
            (
                lead_time_records,
                assignment_records,
                cycle_takt_records
            ) = await asyncio.gather(
                fetch_lead_time(),
                fetch_assignment_types(),
                fetch_cycle_takt(),
                return_exceptions=False
            )
            logger.info("Parallel query execution completed")

        lead_time_avg_minutes = float(lead_time_records[0].get("LEAD_TIME_AVG_MINUTES", 0)) if lead_time_records and lead_time_records[0].get("LEAD_TIME_AVG_MINUTES") else 0.0
        lead_time_avg_days = round(lead_time_avg_minutes / 1440, 2) if lead_time_avg_minutes else 0.0

        # Extract cycle time and takt time from combined query result
        cycle_time_mins = 0.0
        takt_time_mins = 0.0
        if cycle_takt_records and len(cycle_takt_records) > 0:
            if cycle_takt_records[0].get("AVG_CYCLE_TIME_MINUTES"):
                cycle_time_mins = float(cycle_takt_records[0].get("AVG_CYCLE_TIME_MINUTES", 0))
            if cycle_takt_records[0].get("TAKT_TIME_MINS"):
                takt_time_mins = float(cycle_takt_records[0].get("TAKT_TIME_MINS", 0))
        
        # Calculate cycle-takt gap
        cycle_takt_gap_str = format_cycle_takt_gap(cycle_time_mins, takt_time_mins)

        # Build assignment type breakdown, ensuring both types are always present
        assignment_data = {
            "GNW Assigned": {"percentage": 0.0, "reassigned_percentage": 0.0},
            "Manually Assigned": {"percentage": 0.0, "reassigned_percentage": 0.0}
        }
        
        # Update with actual data from query results
        if assignment_records:
            for r in assignment_records:
                assignment_type = r.get("ASSIGNMENT_TYPE", "Unknown")
                if assignment_type in assignment_data:
                    assignment_data[assignment_type] = {
                        "percentage": float(r.get("ASSIGNMENT_PCT", 0)),
                        "reassigned_percentage": float(r.get("REASSIGNED_PCT", 0))
                    }
        
        assignment_type_breakdown = [
            AssignmentTypeItem(
                assignment_type=assignment_type,
                percentage=data["percentage"],
                reassigned_percentage=data["reassigned_percentage"]
            )
            for assignment_type, data in assignment_data.items()
        ]

        # Calculate total reassignment percentage from assignment records
        total_reassigned_count = sum(int(r.get("REASSIGNED_CNT", 0)) for r in assignment_records) if assignment_records else 0
        total_count = sum(int(r.get("TOTAL_CNT", 0)) for r in assignment_records) if assignment_records else 0
        reassign_pct = round(total_reassigned_count * 100.0 / total_count, 2) if total_count > 0 else 0.0

        tooltips = {
            "lead_time_avg_days": "Average lead time converted to days",
            "cycle_takt_gap": "Difference between cycle time and takt time. Positive = slower than needed, Negative = faster than needed. Formula: Cycle Time - Takt Time",
            "assignment_type_breakdown": "Distribution of work assigned by GNW system vs Manual assignment",
            "reassign_pct": "Percentage of work items that were reassigned to different associates"
        }

        return OperationalFlowResponse(
            status="success",
            lead_time_avg_days=lead_time_avg_days,
            cycle_takt_gap=cycle_takt_gap_str,
            assignment_type_breakdown=assignment_type_breakdown,
            reassign_pct=reassign_pct,
            message="Operational flow metrics retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Operational flow query error: {type(e).__name__}: {str(e)}")
        return OperationalFlowResponse(
            status="error",
            lead_time_avg_days=0.0,
            cycle_takt_gap="N/A",
            assignment_type_breakdown=[],
            reassign_pct=0.0,
            message=f"Failed to retrieve operational flow metrics: {str(e)}"
        )
