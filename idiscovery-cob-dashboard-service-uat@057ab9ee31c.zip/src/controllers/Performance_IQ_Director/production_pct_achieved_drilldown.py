import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import StreamingResponse
import httpx

from db import SnowflakeConnectionManager
from schema import (
    ProductionPctAchievedDrilldownPaginatedRequest,
    ProductionPctAchievedDrilldownPaginatedResponse,
    ProductionPctAchievedRecord,
    PageResponse,
    DirectorBaseDownloadRequest,
    CacheMetadata,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from datetime import datetime
from io import BytesIO
import math

def format_standard_time(retime) -> str:
    """Convert standard time from minutes to hh:mm:ss format"""
    if not retime:
        return "00:00:00"
    try:
        total_minutes = float(retime)
        hours = int(total_minutes // 60)
        minutes = int(total_minutes % 60)
        seconds = int((total_minutes % 1) * 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    except:
        return "00:00:00"

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def format_datetime_mmddyyyy(datetime_str: str) -> str:
    """Convert datetime to MM/DD/YYYY format"""
    if not datetime_str:
        return ""
    try:
        # Handle both date and datetime formats
        if 'T' in str(datetime_str):
            date_obj = datetime.strptime(str(datetime_str).split('T')[0], "%Y-%m-%d")
        else:
            date_obj = datetime.strptime(str(datetime_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(datetime_str)

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

PRODUCTION_PCT_ACHIEVED_QUERY = f"""
WITH
invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        RETIME,
        CYCLE_TIME,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        MARKET,
        PLATFORM,
        ACTIVITYCODE,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{associate_filter_invntry}}
      {{manager_filter}}
      {{director_filter}}
),
invntry_daily AS (
    SELECT
        PYRESOLVEDUSERID AS userid,
        resolved_date,
        COUNT(DISTINCT PYID) AS work_items_completed,
        SUM(RETIME) AS total_retime_min
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID, resolved_date
),
user_daily AS (
    SELECT
        USERID,
        USERNAME,
        LOGINDATE,
        TOTALSYSTEMTIME,
        non_prdctv_duration AS non_productive_sec,
        (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INT * 60) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 2)::INT) +
        (SPLIT_PART(PRODUCTIVETIME, ':', 3)::INT / 60.0) AS actual_production_min,
        ROW_NUMBER() OVER (PARTITION BY USERID, LOGINDATE ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE {{user_date_filter_where}}
      {{associate_filter_user}}
      AND TOTALSYSTEMTIME IS NOT NULL
),
daily_metrics AS (
    SELECT
        i.userid,
        u.USERNAME,
        i.resolved_date,
        i.work_items_completed,
        i.total_retime_min,
        u.actual_production_min
    FROM invntry_daily i
    INNER JOIN user_daily u
        ON i.userid = u.USERID
        AND i.resolved_date = u.LOGINDATE
    WHERE u.rn = 1
      AND u.actual_production_min > 0
),
aggregated_totals AS (
    SELECT
        userid,
        MAX(USERNAME) AS USERNAME,
        SUM(work_items_completed) AS total_work_items,
        SUM(total_retime_min) AS total_retime_min,
        SUM(actual_production_min) AS total_actual_production_min,
        COUNT(DISTINCT resolved_date) AS work_days,
        ROUND(
            (SUM(total_retime_min) / NULLIF(SUM(actual_production_min), 0)) * 100,
            2
        ) AS production_pct_achieved,
        ROUND(
            SUM(actual_production_min) / NULLIF(SUM(total_retime_min) / NULLIF(SUM(work_items_completed), 0), 0),
            0
        ) AS total_expected_tasks
    FROM daily_metrics
    GROUP BY userid
),
user_profile_deduped AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    i.PYRESOLVEDUSERID AS associate,
    COALESCE(u.USERNAME, p.USERNAME) AS associate_name,
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS worktype,
    i.RETIME AS standard_time,
    i.CYCLE_TIME AS case_cycle_time,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.MARKET,
    i.PLATFORM,
    TO_CHAR(i.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY') AS resolved_date,
    i.ACTIVITYCODE AS activity_code,
    'View Details' AS action,
    p.total_work_items,
    p.total_retime_min AS total_expected_min,
    ROUND(p.total_actual_production_min, 0) AS total_actual_production_min,
    p.total_expected_tasks,
    p.production_pct_achieved
FROM invntry_deduped i
INNER JOIN aggregated_totals p
    ON i.PYRESOLVEDUSERID = p.userid
LEFT JOIN user_profile_deduped u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

PRODUCTION_PCT_ACHIEVED_DEFAULT_ORDER_BY = "ORDER BY i.PYRESOLVEDTIMESTAMP DESC"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "associate": "COALESCE(u.USERNAME, p.USERNAME)",
        "work_item_id": "i.PYID",
        "worktype": "i.INTAKESOURCESYSTEM",
        "standard_time": "i.RETIME",
        "case_cycle_time": "TRY_TO_NUMBER(i.CYCLE_TIME)",
        "resolved_status": "i.PYSTATUSWORK",
        "inventory_type": "i.INVNTRY_TYPE",
        "lob": "i.LOB",
        "resolved_date": "i.PYRESOLVEDTIMESTAMP",
        "activity_code": "i.ACTIVITYCODE",
        "platform": "i.PLATFORM",
    }

    normalized_sort_by = (sort_by or "").lower()
    sort_column = sort_columns.get(normalized_sort_by)
    if not sort_column:
        return PRODUCTION_PCT_ACHIEVED_DEFAULT_ORDER_BY

    nulls_clause = " NULLS LAST" if normalized_sort_by == "case_cycle_time" else ""
    return f"ORDER BY {sort_column} {direction}{nulls_clause}, i.PYRESOLVEDTIMESTAMP DESC, i.PYID"

PRODUCTION_PCT_ACHIEVED_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        {{date_filter}}
        {{lob_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter}}
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM invntry_deduped
WHERE rn = 1
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""

def build_associate_filter_user(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for COB_AI_USER_PROFILE table (uses USERID)"""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND USERID IN ('{frontline_associate_ids_str}')"
    return ""

def build_user_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for COB_AI_USER_PROFILE table (uses LOGINDATE)"""
    if start_date and end_date:
        return f"AND LOGINDATE >= '{start_date}' AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""

def build_user_date_filter_where(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for WHERE clause (without AND prefix)"""
    if start_date and end_date:
        return f"LOGINDATE >= '{start_date}' AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return "1=1"

@router.post(
    "/production-pct-achieved-drilldown",
    response_model=ProductionPctAchievedDrilldownPaginatedResponse,
    summary="Get Production Percentage Achieved Drilldown",
    description="""
Retrieve paginated list of production percentage achieved work items for detailed table display.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item_id**: Unique work item identifier (PYID)
- **worktype**: Work type (INTAKESOURCESYSTEM)
- **standard_time**: Standard time in hh:mm:ss format (RETIME converted from minutes)
- **case_cycle_time**: Case cycle time (CYCLE_TIME)
- **resolved_status**: Resolved status (PYSTATUSWORK)
- **inventory_type**: Inventory type (INVNTRY_TYPE)
- **lob**: Line of Business
- **resolved_date**: Resolved date (MM/DD/YYYY format)
- **associate**: Associate name (PYRESOLVEDUSERID)
- **action**: Action button (View Details)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (production data)
""",
)
async def get_production_pct_achieved_drilldown(request: ProductionPctAchievedDrilldownPaginatedRequest) -> ProductionPctAchievedDrilldownPaginatedResponse:
    """production percentage achieved drilldown endpoint - direct query execution."""
    return await execute_production_pct_achieved_drilldown_query(request)


async def execute_production_pct_achieved_drilldown_query(
    request: ProductionPctAchievedDrilldownPaginatedRequest
) -> ProductionPctAchievedDrilldownPaginatedResponse:
    """Execute production pct achieved drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        manager_ids = request.manager_ids
        associates = request.frontline_associate_ids
        
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        lob_filter = build_lob_filter(lob)
        date_filter = build_date_filter(start_date, end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(associates)
        associate_filter_invntry = associate_filter  # Same filter for inventory table
        manager_filter_user = build_manager_filter_user(manager_ids)
        associate_filter_user = build_associate_filter_user(associates)
        user_date_filter = build_user_date_filter(start_date, end_date)
        engine = connection_manager.get_engine()
        
        # Try to reuse cached work_items_completed count from header KPIs
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Get cached work items count from header KPIs
                # Build filters dict and hash for cache key
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'director_ids': request.director_ids,
                    'manager_ids': request.manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                cache_key = f"session:{session_id}:{filters_hash}:work_items_completed"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract COMPLETED_TASKS from cached query result
                    total_records = int(cached_metric[0].get("COMPLETED_TASKS", 0))
                    logger.info(f"✅ Reused cached work items count: {total_records} (from header KPIs)")
                else:
                    logger.info(f"Cache miss for work_items_completed, running COUNT query")
                    # Fall back to COUNT query
                    count_query = PRODUCTION_PCT_ACHIEVED_COUNT_QUERY.format(
                        date_filter=date_filter,
                        lob_filter=lob_filter,
                        director_filter=director_filter,
                        manager_filter=manager_filter,
                        associate_filter=associate_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached work items count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = PRODUCTION_PCT_ACHIEVED_COUNT_QUERY.format(
                    date_filter=date_filter,
                    lob_filter=lob_filter,
                    director_filter=director_filter,
                    manager_filter=manager_filter,
                    associate_filter=associate_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = PRODUCTION_PCT_ACHIEVED_COUNT_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                director_filter=director_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        user_date_filter_where = build_user_date_filter_where(start_date, end_date)
        
        data_query = PRODUCTION_PCT_ACHIEVED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter,
            director_filter=director_filter,
            user_date_filter_where=user_date_filter_where,
            associate_filter_user=associate_filter_user,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            PRODUCTION_PCT_ACHIEVED_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        production_records = [
            ProductionPctAchievedRecord(
                work_item_id=record.get("WORK_ITEM_ID") or "",
                worktype=record.get("WORKTYPE") or "",
                standard_time=format_standard_time(record.get("STANDARD_TIME")),
                case_cycle_time=format_cycle_time(record.get("CASE_CYCLE_TIME")),
                resolved_status=record.get("RESOLVED_STATUS") or "",
                inventory_type=record.get("INVENTORY_TYPE") or "N/A",
                lob=record.get("LOB") or "N/A",
                resolved_date=record.get("RESOLVED_DATE") or "N/A",
                associate=record.get("ASSOCIATE_NAME") or "N/A",
                activity_code=record.get("ACTIVITY_CODE") or "N/A",
                platform=record.get("PLATFORM") or "N/A",
                action=record.get("ACTION", "View Details")
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item_id": "Unique identifier for the work item (PYID)",
            "worktype": "Type of work item or source system",
            "standard_time": "Standard time allocated for this work type in hh:mm:ss format",
            "case_cycle_time": "Actual time taken to complete the work item in hh:mm:ss format",
            "resolved_status": "Status when the work item was resolved",
            "inventory_type": "Type of inventory or work category",
            "lob": "Line of Business associated with the work item",
            "resolved_date": "Date when the work item was resolved",
            "associate": "Associate who resolved the work item",
            "activity_code": "Activity code associated with the work item",
            "action": "Available actions for this work item"
        }

        return ProductionPctAchievedDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=production_records,
            message="Production percentage achieved records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated production percentage achieved drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return ProductionPctAchievedDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve production percentage achieved records: {str(e)}"
        )


@router.post(
    "/production-pct-achieved-drilldown/download-excel",
    summary="Download Production Pct Achieved Drilldown as Excel (Director)",
    description="""
Download complete production percentage achieved drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all production pct achieved records
""",
)
async def download_production_pct_achieved_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> Response:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        associates = request.frontline_associate_ids
        
        date_filter = build_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(lob)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(associates)
        associate_filter_invntry = associate_filter
        manager_filter_user = build_manager_filter_user(manager_ids)
        associate_filter_user = build_associate_filter_user(associates)
        user_date_filter = build_user_date_filter(request.start_date, request.end_date)
        user_date_filter_where = build_user_date_filter_where(request.start_date, request.end_date)
        engine = connection_manager.get_engine()
        
        # Query with high limit for download (no pagination needed)
        download_query = PRODUCTION_PCT_ACHIEVED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter,
            director_filter=director_filter,
            user_date_filter_where=user_date_filter_where,
            associate_filter_user=associate_filter_user,
            limit=1000000,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
    except Exception as e:
        logger.error(f"Excel download error for production pct achieved drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
    
    # STEP 3: Generate Excel file
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "Production Pct Achieved"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Standard Time",
            "Case Cycle Time",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Resolved Date",
            "Associate Name",
            "Activity Code",
            "Platform"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("work_item_id") or row.get("WORK_ITEM_ID", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("worktype") or row.get("WORKTYPE", "")))
            standard_time = row.get("standard_time") or row.get("STANDARD_TIME")
            if isinstance(standard_time, str) and ":" in standard_time:
                ws.cell(row=row_num, column=3, value=standard_time)
            else:
                ws.cell(row=row_num, column=3, value=format_standard_time(standard_time) if standard_time else "00:00:00")
            cycle_time = row.get("case_cycle_time") or row.get("CASE_CYCLE_TIME")
            if isinstance(cycle_time, str) and ":" in cycle_time:
                ws.cell(row=row_num, column=4, value=cycle_time)
            else:
                ws.cell(row=row_num, column=4, value=format_cycle_time(cycle_time) if cycle_time else "00:00:00")
            ws.cell(row=row_num, column=5, value=str(row.get("resolved_status") or row.get("RESOLVED_STATUS", "")))
            ws.cell(row=row_num, column=6, value=str(row.get("inventory_type") or row.get("INVENTORY_TYPE", "N/A")))
            ws.cell(row=row_num, column=7, value=str(row.get("lob") or row.get("LOB", "N/A")))
            ws.cell(row=row_num, column=8, value=str(row.get("resolved_date") or row.get("RESOLVED_DATE", "N/A")))
            ws.cell(row=row_num, column=9, value=str(row.get("associate") or row.get("ASSOCIATE_NAME", "N/A")))
            ws.cell(row=row_num, column=10, value=str(row.get("activity_code") or row.get("ACTIVITY_CODE", "N/A")))
            ws.cell(row=row_num, column=11, value=str(row.get("platform") or row.get("PLATFORM", "N/A")))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"production_pct_achieved_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for production pct achieved drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
