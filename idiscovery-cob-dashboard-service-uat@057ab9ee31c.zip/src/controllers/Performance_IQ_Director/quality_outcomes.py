import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import DirectorBaseRequest, QualityOutcomesResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

AUDIT_SAMPLE_PCT_QUERY = f"""
WITH deduped_invntry AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,  
        REPORTTODIRECTORID, 
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{associate_filter_invntry}}
      {{director_filter}}
      {{manager_filter}}
),
work_items AS (
    SELECT 
        PYRESOLVEDUSERID AS USERID,
        COUNT(DISTINCT PYID) AS cases_resolved
    FROM deduped_invntry
    WHERE rn = 1
    GROUP BY PYRESOLVEDUSERID
),
deduped_audit AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        PYSTATUSWORK,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS audit_date,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Open-FeedbackReview', 'Open-RebuttalReview', 'Open-AuditReview', 'Open-AuditUnassigned')
      AND CASE_TO_AUDIT IS NOT NULL
      AND PYID LIKE 'AUD%'
      {{audit_date_filter}}
      {{lob_filter}}
      {{audit_associate_filter}}
),
audit_summary AS (
    SELECT 
        AUDIT_SUBJECT_ID AS USERID,
        COUNT(DISTINCT CASE WHEN PYSTATUSWORK IN ('Open-FeedbackReview', 'Open-RebuttalReview') THEN CASE_TO_AUDIT END) AS open_audits,
        COUNT(DISTINCT CASE WHEN PYSTATUSWORK = 'Resolved-Completed' THEN CASE_TO_AUDIT END) AS closed_audits,
        COUNT(DISTINCT CASE WHEN PYSTATUSWORK IN ('Open-AuditReview', 'Open-AuditUnassigned') THEN CASE_TO_AUDIT END) AS pending_audits,
        COUNT(DISTINCT CASE_TO_AUDIT) AS total_audits
    FROM deduped_audit a
    INNER JOIN deduped_invntry i
        ON a.CASE_TO_AUDIT = i.PYID  
        AND i.rn = 1
    WHERE a.rn = 1
    GROUP BY a.AUDIT_SUBJECT_ID
),
user_profile AS (
    SELECT 
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE 1=1
        {{associate_filter_user}}
)
SELECT 
    u.USERID,
    u.USERNAME AS associate_name,
    COALESCE(a.open_audits, 0) AS open_audits,
    COALESCE(a.closed_audits, 0) AS closed_audits,
    COALESCE(a.pending_audits, 0) AS pending_audits,
    COALESCE(w.cases_resolved, 0) AS total_cases_resolved,
    COALESCE(a.total_audits, 0) AS total_audits,
    ROUND((COALESCE(a.total_audits, 0) * 100.0 / NULLIF(w.cases_resolved, 0)), 2) AS audit_sample_pct
FROM user_profile u
LEFT JOIN work_items w ON u.USERID = w.USERID
LEFT JOIN audit_summary a ON u.USERID = a.USERID
WHERE u.rn = 1
"""

COMPLETED_AUDIT_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        REPORTTODIRECTORID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        AUDIT_SUBJECT_ID,
        AUDITOR_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
"""

AUDIT_SCORE_AVG_QUERY = f"""
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SCORE,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{associate_filter}}
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        {{date_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter_invntry}}
)
SELECT 
    ROUND(AVG(a.AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
WHERE a.rn = 1
"""

AUDIT_CYCLE_TIME_AVG_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDITCYCLETIME,
        AUDITOR_ID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE 
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND AUDITCYCLETIME IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter_invntry}}
)
SELECT
    COUNT(DISTINCT a.PYID) AS total_resolved_audits,
    ROUND(AVG(a.AUDITCYCLETIME), 2) AS AVG_AUDIT_CYCLE_TIME
FROM audit_deduped a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
WHERE a.rn = 1
"""

REBUTTAL_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(REPORTTODIRECTORID)) AS REPORTTODIRECTORID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PYRESOLVEDTIMESTAMP DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        PYRESOLVEDTIMESTAMP AS audit_resolved_timestamp,
        DATE(PYRESOLVEDTIMESTAMP) AS audit_resolved_date,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE UPPER(TRIM(REBUTTALFLAG)) = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
),
audit_activity_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT a.PYID) AS unique_audit_cases_with_rebuttals,
    COUNT(*) AS total_rebuttal_records
FROM invntry_deduped i
INNER JOIN audit_deduped a 
    ON i.PYID = a.CASE_TO_AUDIT 
    AND a.rn = 1
LEFT JOIN audit_activity_deduped act 
    ON a.PYID = act.CASEID 
    AND act.rn = 1
WHERE i.rn = 1
  AND act.ERRORCATEGORYTYPE IS NOT NULL
  AND act.ERRORCATEGORY IS NOT NULL
"""

REBUTTAL_OVERTURN_PCT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(REPORTTODIRECTORID)) AS REPORTTODIRECTORID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PYRESOLVEDTIMESTAMP DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        PYRESOLVEDTIMESTAMP AS audit_resolved_timestamp,
        DATE(PYRESOLVEDTIMESTAMP) AS audit_resolved_date,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE UPPER(TRIM(REBUTTALFLAG)) = 'Y'
      AND UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
),
audit_activity_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
rebuttal_outcome_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        UPPER(TRIM(REBUTTALOUTCOME)) AS REBUTTALOUTCOME,
        PXUPDATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE REBUTTALOUTCOME IS NOT NULL
)
SELECT
    COUNT(DISTINCT a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS total_rebuttals,
    COUNT(DISTINCT CASE 
        WHEN ro.REBUTTALOUTCOME IN ('ERROR RETRACTED', 'FYI RETRACTED', 'CHANGED TO FYI')
        THEN a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS overturned_count
FROM invntry_deduped i
INNER JOIN audit_deduped a 
    ON i.PYID = a.CASE_TO_AUDIT 
    AND a.rn = 1
LEFT JOIN audit_activity_deduped act 
    ON a.PYID = act.CASEID 
    AND act.rn = 1
LEFT JOIN rebuttal_outcome_deduped ro 
    ON a.PYID = ro.CASEID 
    AND act.ERRORCATEGORYTYPE = ro.ERRORCATEGORYTYPE
    AND act.ERRORCATEGORY = ro.ERRORCATEGORY
    AND ro.rn = 1
WHERE i.rn = 1
"""

REWORK_COUNT_QUERY = f"""
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{rework_date_filter}}
      {{lob_filter}}
      {{associate_filter}}
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter_invntry}}
)
SELECT
    COUNT(DISTINCT a.PYID) AS REWORK_COUNT
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
WHERE a.rn = 1
"""

AUDIT_ERROR_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        i.PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(i.PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        UPPER(TRIM(i.REPORTTOMANAGERID)) AS MANAGER_ID,
        i.PYRESOLVEDTIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
    WHERE UPPER(TRIM(i.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(ap.PYSTATUSWORK)) AS AUDIT_STATUS,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        ap.PXUPDATEDATETIME AS AUDIT_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) = 'RESOLVED-COMPLETED'
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXUPDATEDATETIME AS ACTIVITY_UPDATE_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
final_base AS (
    SELECT
        i.MANAGER_ID,
        i.ASSOCIATE_ID,
        i.ORIGINAL_OHI_CASE_ID,
        i.PYRESOLVEDTIMESTAMP,
        ap.AUDIT_CASE_ID,
        ap.AUDIT_STATUS,
        ap.AUDIT_CREATE_TIMESTAMP,
        ap.AUDIT_UPDATE_TIMESTAMP,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        aa.RESULTTYPE,
        aa.DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.ACTIVITY_UPDATE_TIMESTAMP
    FROM invntry_deduped i
    JOIN audit_profile_deduped ap
      ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
     AND ap.rn = 1
    JOIN audit_activity_deduped aa
      ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
     AND aa.rn = 1
    WHERE i.rn = 1
)
SELECT
    COUNT(DISTINCT ORIGINAL_OHI_CASE_ID) AS COMPLETED_INVENTORY_CASES_AUDITED,
    COUNT(DISTINCT AUDIT_CASE_ID) AS COMPLETED_AUDIT_CASES,
    COUNT(DISTINCT AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS AUDIT_ERROR_COUNT,
    COUNT(DISTINCT CASE
        WHEN UPPER(TRIM(NVL(SPECIALISTERRORCORRECTED, 'NO'))) IN ('Y', 'YES')
        THEN AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS CORRECTED_ERROR_COUNT,
    COUNT(DISTINCT CASE
        WHEN UPPER(TRIM(NVL(SPECIALISTERRORCORRECTED, 'NO'))) IN ('N', 'NO')
        THEN AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS NOT_CORRECTED_ERROR_COUNT
FROM final_base
"""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_date_filter_where(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    """Build date filter for WHERE clause (without AND prefix)"""
    if start_date and end_date:
        return (
            f"{date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"{date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"{date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return "1=1"


def build_audit_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Filter for audit date range (uses PXCREATEDATETIME)"""
    if start_date and end_date:
        return (
            f"AND PXCREATEDATETIME >= '{start_date}' "
            f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PXCREATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_manager_filter_cte(manager_ids: Optional[List[str]] = None) -> str:
    """Build WHERE clause for manager filtering in CTE"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"WHERE PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "AUDIT_SUBJECT_ID") -> str:
    """Build associate filter with flexible column parameter."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{frontline_associate_ids_str}')"
    return ""


def build_user_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_USER_PROFILE table (uses PYREPORTTO)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"WHERE PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_audit_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table manager filter (uses AUDIT_SUBJECT_ID)"""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND AUDIT_SUBJECT_ID IN (SELECT DISTINCT USERID FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE WHERE PYREPORTTO IN ('{manager_ids_str}'))"
    return ""


def build_audit_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table associate filter (uses AUDIT_SUBJECT_ID)"""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{frontline_associate_ids_str}')"
    return ""


def build_associate_filter_audit(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """For COB_AI_AUDIT_PROFILE table auditor filter (uses AUDITOR_ID)"""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{frontline_associate_ids_str}')"
    return ""

def format_cycle_time(seconds: float) -> str:
    """Format cycle time from seconds to 'X min. Y sec.' format."""
    if seconds is None:
        return "N/A"
    total_minutes = int(seconds // 60)
    remaining_seconds = int(seconds % 60)
    return f"{total_minutes} min. {remaining_seconds} sec."


@router.post(
    "/quality-outcomes",
    response_model=QualityOutcomesResponse,
    summary="Get Quality Outcomes Metrics",
    description="""Retrieve quality outcomes and control metrics for director dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **director_ids** (optional): List of director IDs to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Response Fields:**
- **audit_sample_pct**: Audit sample percentage (TBD - needs OHI-Audit PYID mapping)
- **audit_cycle_time_avg**: Average audit cycle time (coming 2/20/2026)
- **completed_audit_count**: Count of completed audits (PYID LIKE 'AUD%')
- **audit_error_count**: Average audit score
- **rebuttal_count**: Count of cases with REBUTTALFLAG = 'Y'
- **rebuttal_overturn_pct**: Rebuttal overturn percentage (ERRORRETRACTEDFLAG coming 2/20/2026)
- **rework_pct**: Rework percentage (TBD - logic pending with business)
- **audit_cycle_time_avg_status**: Status for audit cycle time (N/A - coming 2/20/2026)
- **rework_pct_status**: Status for rework percentage (N/A - TBD)

**Data Source:** COB_AI_AUDIT_PROFILE table
""",
)
async def get_quality_outcomes(request: DirectorBaseRequest) -> QualityOutcomesResponse:
    """Quality outcomes endpoint with metric-level caching."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_quality_outcomes_query(request)


async def execute_quality_outcomes_query(request: DirectorBaseRequest) -> QualityOutcomesResponse:
    """Execute quality outcomes query logic (core business logic)."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        # Use PXCREATEDATETIME for rework queries in audit table
        rework_date_filter = build_date_filter(request.start_date, request.end_date, date_column="PXCREATEDATETIME")
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        associate_filter_invntry = build_associate_filter(request.frontline_associate_ids, column="PYRESOLVEDUSERID")
        associate_filter_audit = build_associate_filter(request.frontline_associate_ids, column="AUDIT_SUBJECT_ID")
        user_manager_filter = build_user_manager_filter(request.manager_ids)
        
        # Filters for audit table (audited items)
        audit_manager_filter = build_audit_manager_filter(request.manager_ids)
        audit_associate_filter = build_audit_associate_filter(request.frontline_associate_ids)
        associate_filter_audit = build_associate_filter_audit(request.frontline_associate_ids)
        
        # Default dates if not provided
        start_date = request.start_date if request.start_date else '2020-01-01'
        end_date = request.end_date if request.end_date else '2099-12-31'
        
        engine = connection_manager.get_engine()

        audit_date_filter = build_audit_date_filter(request.start_date, request.end_date)
        
        audit_sample_query = AUDIT_SAMPLE_PCT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            associate_filter_invntry=associate_filter_invntry,
            director_filter=director_filter,
            manager_filter=manager_filter,
            audit_date_filter=audit_date_filter,
            associate_filter_user=associate_filter_user,
            audit_associate_filter=audit_associate_filter
        )
        audit_count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter_audit,
            associate_filter_invntry=associate_filter_invntry
        )
        audit_score_query = AUDIT_SCORE_AVG_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter_audit,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry
        )
        rebuttal_query = REBUTTAL_COUNT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter_audit,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry
        )
        audit_cycle_time_query = AUDIT_CYCLE_TIME_AVG_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter_audit,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry
        )
        
        rework_query = REWORK_COUNT_QUERY.format(
            rework_date_filter=rework_date_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter_audit,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry
        )
        
        rebuttal_overturn_pct_query = REBUTTAL_OVERTURN_PCT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter_audit,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter,
            director_filter=director_filter
        )
        
        audit_error_query = AUDIT_ERROR_COUNT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry
        )
        
        # Define async fetch functions for caching
        async def fetch_audit_sample():
            return await engine.execute_query_async(audit_sample_query, limit=1000000)
        
        async def fetch_audit_count():
            return await engine.execute_query_async(audit_count_query, limit=1)
        
        async def fetch_audit_score():
            return await engine.execute_query_async(audit_score_query, limit=1)
        
        async def fetch_rebuttal():
            return await engine.execute_query_async(rebuttal_query, limit=1)
        
        async def fetch_audit_cycle_time():
            return await engine.execute_query_async(audit_cycle_time_query, limit=1)
        
        async def fetch_rework():
            return await engine.execute_query_async(rework_query, limit=1)
        
        async def fetch_rebuttal_overturn():
            return await engine.execute_query_async(rebuttal_overturn_pct_query, limit=1)
        
        async def fetch_audit_error():
            return await engine.execute_query_async(audit_error_query, limit=1)
        
        # Get or fetch cached metrics (only cache if session_id provided)
        session_id = getattr(request, "session_id", None)
        
        # Build filters dict for cache isolation
        filters = {
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
            'director_ids': request.director_ids,
            'manager_ids': request.manager_ids,
            'frontline_associate_ids': request.frontline_associate_ids,
        }
        
        if session_id:
            audit_sample_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_sample,
                session_id=session_id,
                metric_name="audit_sample_pct",
                filters=filters
            )
            
            audit_count_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_count,
                session_id=session_id,
                metric_name="completed_audit_count",
                filters=filters
            )
            
            audit_score_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_score,
                session_id=session_id,
                metric_name="audit_score",
                filters=filters
            )
            
            rebuttal_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_rebuttal,
                session_id=session_id,
                metric_name="rebuttal_count",
                filters=filters
            )
            
            audit_cycle_time_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_cycle_time,
                session_id=session_id,
                metric_name="audit_cycle_time",
                filters=filters
            )
            
            rework_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_rework,
                session_id=session_id,
                metric_name="rework_count",
                filters=filters
            )
            
            rebuttal_overturn_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_rebuttal_overturn,
                session_id=session_id,
                metric_name="rebuttal_overturn_pct",
                filters=filters
            )
            
            audit_error_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_error,
                session_id=session_id,
                metric_name="audit_error_count",
                filters=filters
            )
        else:
            # Execute all 8 queries in parallel without caching
            logger.info("Executing 8 Director quality outcomes queries in parallel")
            (
                audit_sample_records,
                audit_count_records,
                audit_score_records,
                rebuttal_records,
                audit_cycle_time_records,
                rework_records,
                rebuttal_overturn_records,
                audit_error_records
            ) = await asyncio.gather(
                fetch_audit_sample(),
                fetch_audit_count(),
                fetch_audit_score(),
                fetch_rebuttal(),
                fetch_audit_cycle_time(),
                fetch_rework(),
                fetch_rebuttal_overturn(),
                fetch_audit_error(),
                return_exceptions=False
            )
            logger.info("Parallel query execution completed")

        # Calculate overall audit sample percentage (weighted average)
        def format_number(num):
            if num >= 1000:
                return f"{num/1000:.1f}K"
            return str(int(num))
        
        if audit_sample_records:
            total_work_items = sum(record.get("TOTAL_CASES_RESOLVED", 0) for record in audit_sample_records)
            total_audited_items = sum(record.get("TOTAL_AUDITS", 0) for record in audit_sample_records)
            audit_sample_pct_value = round((total_audited_items * 100.0 / total_work_items), 2) if total_work_items > 0 else 0.0
            
            audit_sample_pct = f"{audit_sample_pct_value}%"
            audit_sample_count = f"{format_number(total_audited_items)} of {format_number(total_work_items)}"
        else:
            audit_sample_pct = "0.0%"
            audit_sample_count = "0 of 0"
        
        completed_audit_count = int(audit_count_records[0].get("COMPLETED_AUDIT_COUNT", 0)) if audit_count_records else 0
        audit_score_avg = float(audit_score_records[0].get("AVG_AUDIT_SCORE", 0)) if audit_score_records and audit_score_records[0].get("AVG_AUDIT_SCORE") else 0.0
        rebuttal_count = int(rebuttal_records[0].get("REBUTTAL_COUNT", 0)) if rebuttal_records else 0
        rework_count = int(rework_records[0].get("REWORK_COUNT", 0)) if rework_records else 0
        audit_error_count = int(audit_error_records[0].get("AUDIT_ERROR_COUNT", 0)) if audit_error_records else 0
        
        # Get rebuttal overturn percentage
        if rebuttal_overturn_records:
            total_rebuttals = rebuttal_overturn_records[0].get("TOTAL_REBUTTALS", 0)
            overturned_count = rebuttal_overturn_records[0].get("OVERTURNED_COUNT", 0)
            rebuttal_overturn_pct_value = round((overturned_count * 100.0 / total_rebuttals), 2) if total_rebuttals > 0 else 0.0
        else:
            rebuttal_overturn_pct_value = 0.0
        rebuttal_overturn_pct = f"{rebuttal_overturn_pct_value} % Overturned"
        
        # Get audit cycle time average and format from seconds to min/sec
        audit_cycle_time_avg_value = audit_cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME") if audit_cycle_time_records and audit_cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME") else None
        audit_cycle_time_avg = format_cycle_time(audit_cycle_time_avg_value)

        tooltips = {
            "audit_sample_pct": "Percentage of work items selected for audit (awaiting OHI-Audit PYID mapping)",
            "audit_cycle_time_avg": "Average audit cycle time in minutes from AUDITCYCLETIME column",
            "completed_audit_count": "Total number of completed audits (PYID starting with 'AUD')",
            "audit_score_avg": "Average audit quality score across all audited cases",
            "rebuttal_count": "Number of cases where associate submitted a rebuttal",
            "rebuttal_overturn_pct": "Percentage of rebuttals that resulted in error retraction (coming 2/20/2026)",
            "rework_pct": "Count of items with TARGET_AUDIT = 'Rework' in the selected timeframe"
        }

        return QualityOutcomesResponse(
            status="success",
            audit_sample_pct=str(audit_sample_pct),
            audit_sample_count=str(audit_sample_count),
            audit_cycle_time_avg=str(audit_cycle_time_avg),
            completed_audit_count=str(completed_audit_count),
            audit_error_count=str(audit_error_count),
            rebuttal_count=str(rebuttal_count),
            rebuttal_overturn_pct=str(rebuttal_overturn_pct),
            rework_pct=str(rework_count),
            message="Quality outcomes metrics retrieved successfully",
            tooltips=tooltips,
            audit_cycle_time_avg_status="N/A",
            rework_pct_status="N/A"
        )

    except Exception as e:
        logger.error(f"Quality outcomes query error: {type(e).__name__}: {str(e)}")
        return QualityOutcomesResponse(
            status="error",
            audit_sample_pct="N/A",
            audit_sample_count="N/A",
            audit_cycle_time_avg="N/A",
            completed_audit_count="0",
            audit_error_count="N/A",
            rebuttal_count="0",
            rebuttal_overturn_pct="N/A",
            rework_pct="N/A",
            message=f"Failed to retrieve quality outcomes metrics: {str(e)}",
            audit_cycle_time_avg_status="N/A",
            rework_pct_status="N/A"
        )