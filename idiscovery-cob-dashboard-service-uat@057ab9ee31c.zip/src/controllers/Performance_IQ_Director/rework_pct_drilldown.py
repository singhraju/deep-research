import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import httpx
import asyncio

from db import SnowflakeConnectionManager
from schema import ReworkPctDrilldownPaginatedRequest, ReworkPctDrilldownPaginatedResponse, ReworkPctRecord, PageResponse, DirectorBaseDownloadRequest
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
import math
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

REWORK_PAGINATED_QUERY = f"""
WITH deduped_audit AS (
    SELECT
        PYID,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        AUDITOR_ID,
        AUDIT_SCORE,
        CASE_TO_AUDIT,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{rework_date_filter}}
      {{lob_filter}}
      {{associate_filter}}
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter_invntry}}
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
invntry_deduped AS (
    SELECT
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
)
SELECT
    a.PYID AS work_item,
    COALESCE(i.INTAKESOURCESYSTEM, 'N/A') AS work_type,
    COALESCE(i.PYSTATUSWORK, 'N/A') AS resolved_status,
    COALESCE(i.INVNTRY_TYPE, 'N/A') AS inventory_type,
    a.LOB,
    a.resolved_date,
    COALESCE(i.PLATFORM, 'N/A') AS platform,
    COALESCE(CAST(a.AUDIT_SCORE AS VARCHAR), 'N/A') AS audit_score,
    COALESCE(auditor.USERNAME, u.USERNAME, 'N/A') AS auditor_name
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
LEFT JOIN deduped_user_profile auditor
    ON a.AUDITOR_ID = auditor.USERID
    AND auditor.rn = 1
LEFT JOIN invntry_deduped i
    ON a.CASE_TO_AUDIT = i.PYID
    AND i.rn = 1
WHERE a.rn = 1
ORDER BY a.resolved_date DESC, a.PYID
LIMIT {{limit}} OFFSET {{offset}}
"""

REWORK_DEFAULT_ORDER_BY = "ORDER BY a.resolved_date DESC, a.PYID"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item": "a.PYID",
        "work_type": "i.INTAKESOURCESYSTEM",
        "resolved_status": "i.PYSTATUSWORK",
        "inventory_type": "i.INVNTRY_TYPE",
        "lob": "a.LOB",
        "resolved_date": "a.resolved_date",
        "platform": "i.PLATFORM",
        "audit_score": "a.AUDIT_SCORE",
        "auditor_name": "COALESCE(auditor.USERNAME, u.USERNAME, 'N/A')",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return REWORK_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, a.resolved_date DESC, a.PYID"

REWORK_COUNT_QUERY = f"""
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE TARGET_AUDIT = 'Rework'
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{rework_date_filter}}
      {{lob_filter}}
      {{associate_filter}}
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        {{director_filter}}
        {{manager_filter}}
        {{associate_filter_invntry}}
)
SELECT
    COUNT(DISTINCT a.PYID) AS TOTAL_COUNT
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
WHERE a.rn = 1
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""


def build_associate_filter_audit(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for COB_AI_AUDIT_PROFILE table (uses AUDIT_SUBJECT_ID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{frontline_associate_ids_str}')"
    return ""


def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        cleaned = str(date_str)
        if "T" in cleaned:
            cleaned = cleaned.split("T")[0]
        elif " " in cleaned:
            cleaned = cleaned.split(" ")[0]
        date_obj = datetime.strptime(cleaned, "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

@router.post(
    "/rework-pct-drilldown",
    response_model=ReworkPctDrilldownPaginatedResponse,
)
async def get_rework_pct_drilldown(request: ReworkPctDrilldownPaginatedRequest) -> ReworkPctDrilldownPaginatedResponse:
    """rework percentage drilldown endpoint - direct query execution."""
    return await execute_rework_pct_drilldown_query(request)


async def execute_rework_pct_drilldown_query(request: ReworkPctDrilldownPaginatedRequest) -> ReworkPctDrilldownPaginatedResponse:
    """Execute rework pct drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        # Use PXCREATEDATETIME for rework queries in audit table
        rework_date_filter = build_date_filter(request.start_date, request.end_date, date_column="PXCREATEDATETIME")
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(request.frontline_associate_ids)
        associate_filter = build_associate_filter_audit(request.frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached rework_count from quality-outcomes
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Get cached rework count from quality-outcomes
                # Build filters dict and hash for cache key
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'director_ids': request.director_ids,
                    'manager_ids': request.manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                cache_key = f"session:{session_id}:{filters_hash}:rework_count"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract REWORK_COUNT from cached query result
                    total_records = int(cached_metric[0].get("REWORK_COUNT", 0))
                    logger.info(f"✅ Reused cached rework count: {total_records} (from quality-outcomes)")
                else:
                    logger.info(f"Cache miss for rework_count, running COUNT query")
                    # Fall back to COUNT query
                    count_query = REWORK_COUNT_QUERY.format(
                        rework_date_filter=rework_date_filter,
                        lob_filter=lob_filter,
                        associate_filter=associate_filter,
                        director_filter=director_filter,
                        manager_filter=manager_filter,
                        associate_filter_invntry=associate_filter_invntry
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = int(count_result[0].get("TOTAL_COUNT", 0)) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached rework count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = REWORK_COUNT_QUERY.format(
                    rework_date_filter=rework_date_filter,
                    lob_filter=lob_filter,
                    associate_filter=associate_filter,
                    director_filter=director_filter,
                    manager_filter=manager_filter,
                    associate_filter_invntry=associate_filter_invntry
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = int(count_result[0].get("TOTAL_COUNT", 0)) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = REWORK_COUNT_QUERY.format(
                rework_date_filter=rework_date_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                director_filter=director_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = int(count_result[0].get("TOTAL_COUNT", 0)) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Get paginated data
        data_query = REWORK_PAGINATED_QUERY.format(
            rework_date_filter=rework_date_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            REWORK_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        # Format records
        rework_records = [
            ReworkPctRecord(
                work_item=str(record.get("WORK_ITEM", "N/A")),
                work_type=str(record.get("WORK_TYPE", "N/A")),
                resolved_status=str(record.get("RESOLVED_STATUS", "N/A")),
                inventory_type=str(record.get("INVENTORY_TYPE", "N/A")),
                lob=str(record.get("LOB", "N/A")),
                resolved_date=format_date_mmddyyyy(str(record.get("RESOLVED_DATE", ""))) or "N/A",
                platform=str(record.get("PLATFORM", "N/A")),
                audit_score=str(record.get("AUDIT_SCORE", "N/A")),
                auditor_name=str(record.get("AUDITOR_NAME", "N/A"))
            )
            for record in records
        ]
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the rework item",
            "work_type": "Type of work item requiring rework (e.g., Newborn, Compass, HEW, Claim Request)",
            "resolved_status": "Current resolution status of the rework item",
            "inventory_type": "Type of inventory classification (e.g., GB, CB)",
            "lob": "Line of Business (Medicaid, Medicare, Commercial)",
            "resolved_date": "Date when the rework was resolved",
            "platform": "Platform where the rework was processed",
            "audit_score": "Audit score percentage achieved after rework",
            "auditor_name": "Name of the auditor who reviewed the rework"
        }

        return ReworkPctDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=rework_records,
            message="Rework percentage records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated rework percentage drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return ReworkPctDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve rework percentage records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/rework-pct-drilldown/download-excel",
    summary="Download Rework Percentage Drilldown as Excel (Director)",
    description="""
Download complete rework percentage drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all rework percentage records (placeholder data)
""",
)
async def download_rework_pct_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> StreamingResponse:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
    try:
            # Build filters
        lob_filter = build_lob_filter(request.lob)
        # Use PXCREATEDATETIME for rework queries in audit table
        rework_date_filter = build_date_filter(request.start_date, request.end_date, date_column="PXCREATEDATETIME")
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(request.frontline_associate_ids)
        associate_filter = build_associate_filter_audit(request.frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
            # Get all data for download (no pagination)
        download_query = REWORK_PAGINATED_QUERY.format(
            rework_date_filter=rework_date_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
            limit=1000000,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
    except Exception as e:
            logger.error(f"Excel download error for rework pct drilldown: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
    
    # STEP 3: Generate Excel file
    try:
        total_records = len(data_result) if data_result else 0

        wb = Workbook()
        ws = wb.active
        ws.title = "Rework Percentage Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Resolved Date",
            "Platform",
            "Audit Score",
            "Auditor Name"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows with field name compatibility
        for row_num, record in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(record.get("work_item") or record.get("WORK_ITEM", "N/A")))
            ws.cell(row=row_num, column=2, value=str(record.get("work_type") or record.get("WORK_TYPE", "N/A")))
            ws.cell(row=row_num, column=3, value=str(record.get("resolved_status") or record.get("RESOLVED_STATUS", "N/A")))
            ws.cell(row=row_num, column=4, value=str(record.get("inventory_type") or record.get("INVENTORY_TYPE", "N/A")))
            ws.cell(row=row_num, column=5, value=str(record.get("lob") or record.get("LOB", "N/A")))
            resolved_date = record.get("resolved_date") or record.get("RESOLVED_DATE")
            ws.cell(row=row_num, column=6, value=format_date_mmddyyyy(str(resolved_date)) if resolved_date else "N/A")
            ws.cell(row=row_num, column=7, value=str(record.get("platform") or record.get("PLATFORM", "N/A")))
            ws.cell(row=row_num, column=8, value=str(record.get("audit_score") or record.get("AUDIT_SCORE", "N/A")))
            ws.cell(row=row_num, column=9, value=str(record.get("auditor_name") or record.get("AUDITOR_NAME", "N/A")))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"rework_pct_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for rework percentage drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
