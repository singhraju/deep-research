import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import DirectorBaseRequest, SLAHealthResponse, AssociateListRequest
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from controllers.Performance_IQ_Director.associates_list import get_associates_list

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])
connection_manager = SnowflakeConnectionManager()

# COB SLA % QUERY - From sla_health.sql
COB_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        INTERNALDUEDATE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        {{date_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{lob_filter}}
        {{associate_filter}}
)
SELECT 
    COUNT(*) AS total_completed_items,
    SUM(CASE WHEN PYRESOLVEDTIMESTAMP <= INTERNALDUEDATE THEN 1 ELSE 0 END) AS cob_sla_met_count,
    ROUND(
        (SUM(CASE WHEN PYRESOLVEDTIMESTAMP <= INTERNALDUEDATE THEN 1 ELSE 0 END) * 100.0) / 
        NULLIF(COUNT(*), 0), 
        2
    ) AS cob_sla_pct
FROM invntry_deduped
WHERE rn = 1
    AND INTERNALDUEDATE IS NOT NULL
"""

# ELV SLA % QUERY - From sla_health.sql
ELV_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        EXTERNALDUEDATE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        {{date_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{lob_filter}}
        {{associate_filter}}
)
SELECT 
    COUNT(*) AS total_completed_items,
    SUM(CASE WHEN PYRESOLVEDTIMESTAMP <= EXTERNALDUEDATE THEN 1 ELSE 0 END) AS elv_sla_met_count,
    ROUND(
        (SUM(CASE WHEN PYRESOLVEDTIMESTAMP <= EXTERNALDUEDATE THEN 1 ELSE 0 END) * 100.0) / 
        NULLIF(COUNT(*), 0), 
        2
    ) AS elv_sla_pct
FROM invntry_deduped
WHERE rn = 1
    AND EXTERNALDUEDATE IS NOT NULL
"""

# SLA RISK % QUERY - From sla_health.sql
# Percentage of open items at risk of ELV SLA breach within 72 hours (3 days)
SLA_RISK_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        EXTERNALDUEDATE,
        DATEDIFF('hour', CURRENT_TIMESTAMP, EXTERNALDUEDATE) AS hours_until_sla_breach,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
        AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                             'Open-ReviewIntake', 'Pend', 'Pend-Decision')
        {{created_date_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{lob_filter}}
        {{open_associate_filter}}
)
SELECT 
    COUNT(*) AS total_backlog_items,
    SUM(CASE WHEN hours_until_sla_breach <= 72 AND hours_until_sla_breach > 0 THEN 1 ELSE 0 END) AS items_at_sla_risk,
    ROUND(
        (SUM(CASE WHEN hours_until_sla_breach <= 72 AND hours_until_sla_breach > 0 THEN 1 ELSE 0 END) * 100.0) / 
        NULLIF(COUNT(*), 0), 
        2
    ) AS sla_risk_pct
FROM invntry_deduped
WHERE rn = 1
    AND EXTERNALDUEDATE IS NOT NULL
"""

# OUT OF SLA % QUERY - From sla_health.sql
# Percentage of open/pending work items that are past Elevance SLA deadline (EXTERNALDUEDATE)
OUT_OF_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        EXTERNALDUEDATE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
        AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                             'Open-ReviewIntake', 'Pend', 'Pend-Decision')
        {{created_date_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{lob_filter}}
        {{open_associate_filter}}
)
SELECT 
    COUNT(*) AS total_open_items,
    SUM(CASE WHEN CURRENT_DATE > EXTERNALDUEDATE THEN 1 ELSE 0 END) AS elv_out_of_sla_count,
    ROUND(
        (SUM(CASE WHEN CURRENT_DATE > EXTERNALDUEDATE THEN 1 ELSE 0 END) * 100.0) / 
        NULLIF(COUNT(*), 0), 
        2
    ) AS elv_out_of_sla_pct
FROM invntry_deduped
WHERE rn = 1
    AND EXTERNALDUEDATE IS NOT NULL
"""

# COUNT BY SLA QUERY - From sla_health.sql
# Count of open items grouped by days until ELV SLA breach
# SLA Buckets: Out of SLA, 00-02, 03-05, 06-10, 11-15, 16-21, 22-30, 30+
COUNT_BY_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        EXTERNALDUEDATE,
        DATEDIFF('second', CURRENT_TIMESTAMP(), EXTERNALDUEDATE) / 86400.0 AS days_until_breach,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
        AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                             'Open-ReviewIntake', 'Pend', 'Pend-Decision')
        {{created_date_filter}}
        {{director_filter}}
        {{manager_filter}}
        {{lob_filter}}
        {{open_associate_filter}}
),
sla_buckets AS (
    SELECT 'Out of SLA' AS sla_bucket, 0 AS sort_order
    UNION ALL SELECT '00-02', 1
    UNION ALL SELECT '03-05', 2
    UNION ALL SELECT '06-10', 3
    UNION ALL SELECT '11-15', 4
    UNION ALL SELECT '16-21', 5
    UNION ALL SELECT '22-30', 6
    UNION ALL SELECT '30+', 7
),
item_counts AS (
    SELECT 
        CASE 
            WHEN days_until_breach < 0 THEN 'Out of SLA'
            WHEN days_until_breach >= 0 AND days_until_breach < 3 THEN '00-02'
            WHEN days_until_breach >= 3 AND days_until_breach < 6 THEN '03-05'
            WHEN days_until_breach >= 6 AND days_until_breach < 11 THEN '06-10'
            WHEN days_until_breach >= 11 AND days_until_breach < 16 THEN '11-15'
            WHEN days_until_breach >= 16 AND days_until_breach < 22 THEN '16-21'
            WHEN days_until_breach >= 22 AND days_until_breach <= 30 THEN '22-30'
            WHEN days_until_breach > 30 THEN '30+'
            ELSE 'Unknown'
        END AS sla_bucket,
        COUNT(*) AS work_items
    FROM invntry_deduped
    WHERE rn = 1
        AND EXTERNALDUEDATE IS NOT NULL
    GROUP BY 
        CASE 
            WHEN days_until_breach < 0 THEN 'Out of SLA'
            WHEN days_until_breach >= 0 AND days_until_breach < 3 THEN '00-02'
            WHEN days_until_breach >= 3 AND days_until_breach < 6 THEN '03-05'
            WHEN days_until_breach >= 6 AND days_until_breach < 11 THEN '06-10'
            WHEN days_until_breach >= 11 AND days_until_breach < 16 THEN '11-15'
            WHEN days_until_breach >= 16 AND days_until_breach < 22 THEN '16-21'
            WHEN days_until_breach >= 22 AND days_until_breach <= 30 THEN '22-30'
            WHEN days_until_breach > 30 THEN '30+'
            ELSE 'Unknown'
        END
)
SELECT 
    b.sla_bucket,
    b.sort_order,
    COALESCE(c.work_items, 0) AS work_items
FROM sla_buckets b
LEFT JOIN item_counts c ON b.sla_bucket = c.sla_bucket
ORDER BY b.sort_order
"""


def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for resolved timestamp."""
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join([str(d).upper().strip() for d in director_ids])
        return f"AND UPPER(TRIM(REPORTTODIRECTORID)) IN ('{director_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join([str(m).upper().strip() for m in manager_ids])
        return f"AND UPPER(TRIM(REPORTTOMANAGERID)) IN ('{manager_ids_str}')"
    return ""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter."""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter using PYRESOLVEDUSERID (for completed items)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        associate_ids_str = "', '".join([str(a).upper().strip() for a in frontline_associate_ids])
        return f"AND UPPER(TRIM(PYRESOLVEDUSERID)) IN ('{associate_ids_str}')"
    return ""


def build_created_date_filter(end_date: Optional[str] = None) -> str:
    """Build created date filter for open items (items created before end_date)."""
    if end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""




def format_count_with_k(count: int) -> str:
    """Format count with K suffix for thousands (e.g., 29100 -> 29.1K, 30000 -> 30K)."""
    if count == 0:
        return "0"
    
    if count >= 1000:
        k_value = count / 1000.0
        # Format with 1 decimal place, but remove .0 if whole number
        if k_value == int(k_value):
            return f"{int(k_value)}K"
        else:
            return f"{k_value:.1f}K"
    else:
        return str(count)


async def get_total_associates_count(manager_ids: Optional[List[str]] = None, user_id: str = None) -> int:
    """Get total count of associates under the given managers by calling associates_list API."""
    if not manager_ids or len(manager_ids) == 0:
        return 0
    
    try:
        # Create request for associates list API
        # Note: start_date and end_date are required but not used for counting
        associates_request = AssociateListRequest(
            user_id=user_id or "system",
            start_date="2025-01-01",  # Placeholder dates - not used for counting
            end_date="2026-12-31",
            manager_ids=manager_ids,
            search=None,
            limit=5000
        )
        
        # Call the associates list API
        response = await get_associates_list(associates_request)
        
        # Return the total count from the response
        return response.total_count
    except Exception as e:
        logger.error(f"Error getting total associates count from API: {str(e)}")
        return 0


async def build_open_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for open items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If all associates are selected (frontline_associate_ids count matches total associates count),
    include manager IDs in the filter as well since items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Check if all associates are selected
    all_associates_selected = False
    if manager_ids and len(manager_ids) > 0:
        total_associates = await get_total_associates_count(manager_ids, user_id)
        if total_associates > 0 and len(frontline_associate_ids) == total_associates:
            all_associates_selected = True
            logger.info(f"All {total_associates} associates selected, including manager IDs in SLA Health open items filter")
    
    # Build the filter
    if all_associates_selected and manager_ids:
        # Include both associates and managers
        combined_ids = list(frontline_associate_ids) + list(manager_ids)
        combined_ids_str = "', '".join([str(a).upper().strip() for a in combined_ids])
        return f"AND UPPER(TRIM(COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO))) IN ('{combined_ids_str}')"
    else:
        # Only include associates
        associate_ids_str = "', '".join([str(a).upper().strip() for a in frontline_associate_ids])
        return f"AND UPPER(TRIM(COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO))) IN ('{associate_ids_str}')"


@router.post(
    "/sla-health",
    response_model=SLAHealthResponse,
    summary="Get SLA Health Metrics",
    description="""
Retrieve SLA health metrics for director dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format for filtering resolved items
- **end_date** (optional): End date in YYYY-MM-DD format for filtering resolved items
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter
- **director_ids** (optional): List of director IDs to filter

**Response Fields:**
- **cob_sla_pct**:  COB SLA percentage (% of completed items that met INTERNALDUEDATE)
- **completed_cob_sla**:  COB SLA met/total count (e.g., "45/50")
- **elv_sla_pct**:  Elevance SLA percentage (awaiting implementation)
- **completed_elv_sla**:  Elevance SLA met/total count (awaiting implementation)
- **sla_risk_pct**:  SLA risk percentage (awaiting implementation)
- **out_of_sla_pct**:  Out of SLA percentage (awaiting implementation)
- **counts_by_sla**:  Counts by SLA brackets (awaiting implementation)

**Data Source:**
- COB_AI_INVNTRY_PROFILE table from Snowflake
- COB SLA: Compares PYRESOLVEDTIMESTAMP vs INTERNALDUEDATE (completed items)
- ELV SLA: Compares PYRESOLVEDTIMESTAMP vs EXTERNALDUEDATE (completed items)
- SLA Risk: Open items with EXTERNALDUEDATE within 72 hours
- Out of SLA: Open items where CURRENT_DATE > EXTERNALDUEDATE
- Counts by SLA: Groups open items by days until breach (floating point calculation)
""",
)
async def get_sla_health(request: DirectorBaseRequest) -> SLAHealthResponse:
    """Get SLA health metrics including COB SLA percentage and counts."""
    return await execute_sla_health_query(request)


async def execute_sla_health_query(request: DirectorBaseRequest) -> SLAHealthResponse:
    """Execute SLA health query logic (core business logic)."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Build filters
        date_filter = build_date_filter(request.start_date, request.end_date)
        director_filter = build_director_filter(request.director_ids if hasattr(request, 'director_ids') else None)
        manager_filter = build_manager_filter(request.manager_ids)
        lob_filter = build_lob_filter(request.lob)
        associate_filter = build_associate_filter(request.frontline_associate_ids)
        
        # Format COB SLA query
        cob_query = COB_SLA_QUERY.format(
            date_filter=date_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter
        )
        
        engine = connection_manager.get_engine()
        
        # Format ELV SLA query
        elv_query = ELV_SLA_QUERY.format(
            date_filter=date_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            lob_filter=lob_filter,
            associate_filter=associate_filter
        )
        
        # Build filters for open items queries
        created_date_filter = build_created_date_filter(request.end_date)
        # Use async filter that includes manager IDs if all associates are selected
        open_associate_filter = await build_open_associate_filter(
            request.frontline_associate_ids,
            request.manager_ids,
            request.user_id
        )
        
        # Format SLA Risk query
        sla_risk_query = SLA_RISK_QUERY.format(
            created_date_filter=created_date_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            lob_filter=lob_filter,
            open_associate_filter=open_associate_filter
        )
        
        # Format Out of SLA query
        out_of_sla_query = OUT_OF_SLA_QUERY.format(
            created_date_filter=created_date_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            lob_filter=lob_filter,
            open_associate_filter=open_associate_filter
        )
        
        # Format Count by SLA query
        count_by_sla_query = COUNT_BY_SLA_QUERY.format(
            created_date_filter=created_date_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            lob_filter=lob_filter,
            open_associate_filter=open_associate_filter
        )
        
        # Execute all 5 queries in parallel using centralized engine method
        #logger.info("Executing 5 Director SLA health queries in parallel")
        (
            cob_result,
            elv_result,
            risk_result,
            out_of_sla_result,
            count_by_sla_result
        ) = await asyncio.gather(
            engine.execute_query_async(cob_query, limit=1),
            engine.execute_query_async(elv_query, limit=1),
            engine.execute_query_async(sla_risk_query, limit=1),
            engine.execute_query_async(out_of_sla_query, limit=1),
            engine.execute_query_async(count_by_sla_query, limit=10),
            return_exceptions=False
        )
        logger.info("Parallel query execution completed")
        
        # Extract COB SLA results
        if cob_result and len(cob_result) > 0:
            result = cob_result[0]
            
            # Try both uppercase and lowercase column names
            total_completed = int(result.get('TOTAL_COMPLETED_ITEMS') or result.get('total_completed_items', 0) or 0)
            cob_sla_met_count = int(result.get('COB_SLA_MET_COUNT') or result.get('cob_sla_met_count', 0) or 0)
            cob_sla_pct = float(result.get('COB_SLA_PCT') or result.get('cob_sla_pct', 0.0) or 0.0)
        else:
            logger.warning("No results returned from COB SLA query")
            total_completed = 0
            cob_sla_met_count = 0
            cob_sla_pct = 0.0
        
        # Extract ELV SLA results
        if elv_result and len(elv_result) > 0:
            result = elv_result[0]
            
            # Try both uppercase and lowercase column names
            elv_total_completed = int(result.get('TOTAL_COMPLETED_ITEMS') or result.get('total_completed_items', 0) or 0)
            elv_sla_met_count = int(result.get('ELV_SLA_MET_COUNT') or result.get('elv_sla_met_count', 0) or 0)
            elv_sla_pct = float(result.get('ELV_SLA_PCT') or result.get('elv_sla_pct', 0.0) or 0.0)
        else:
            logger.warning("No results returned from ELV SLA query")
            elv_total_completed = 0
            elv_sla_met_count = 0
            elv_sla_pct = 0.0
        
        # Extract SLA Risk results
        if risk_result and len(risk_result) > 0:
            result = risk_result[0]
            
            total_backlog = int(result.get('TOTAL_BACKLOG_ITEMS') or result.get('total_backlog_items', 0) or 0)
            items_at_risk = int(result.get('ITEMS_AT_SLA_RISK') or result.get('items_at_sla_risk', 0) or 0)
            sla_risk_pct = float(result.get('SLA_RISK_PCT') or result.get('sla_risk_pct', 0.0) or 0.0)
        else:
            logger.warning("No results returned from SLA Risk query")
            total_backlog = 0
            items_at_risk = 0
            sla_risk_pct = 0.0
        
        # Extract Out of SLA results
        if out_of_sla_result and len(out_of_sla_result) > 0:
            result = out_of_sla_result[0]
            
            total_open = int(result.get('TOTAL_OPEN_ITEMS') or result.get('total_open_items', 0) or 0)
            out_of_sla_count = int(result.get('ELV_OUT_OF_SLA_COUNT') or result.get('elv_out_of_sla_count', 0) or 0)
            out_of_sla_pct = float(result.get('ELV_OUT_OF_SLA_PCT') or result.get('elv_out_of_sla_pct', 0.0) or 0.0)
        else:
            logger.warning("No results returned from Out of SLA query")
            total_open = 0
            out_of_sla_count = 0
            out_of_sla_pct = 0.0
        
        # Extract Count by SLA results
        counts_by_sla = {}
        if count_by_sla_result and len(count_by_sla_result) > 0:
            # Sort by sort_order to ensure proper bucket ordering (handle 0 correctly)
            def get_sort_order(row):
                sort_val = row.get('SORT_ORDER')
                if sort_val is None:
                    sort_val = row.get('sort_order')
                return int(sort_val) if sort_val is not None else 999
            
            sorted_results = sorted(count_by_sla_result, key=get_sort_order)
            
            for row in sorted_results:
                sla_bucket = row.get('SLA_BUCKET') or row.get('sla_bucket', '')
                work_items = int(row.get('WORK_ITEMS') or row.get('work_items', 0) or 0)
                
                # Add to dictionary with bucket name as key and count as value
                counts_by_sla[sla_bucket] = work_items
        else:
            logger.warning("No results returned from Count by SLA query")
        
        # Format for display
        cob_sla_pct_str = f"{cob_sla_pct:.2f}%" if cob_sla_pct is not None else "0.00%"
        completed_cob_sla_str = f"{format_count_with_k(cob_sla_met_count)} of {format_count_with_k(total_completed)}"
        
        elv_sla_pct_str = f"{elv_sla_pct:.2f}%" if elv_sla_pct is not None else "0.00%"
        completed_elv_sla_str = f"{format_count_with_k(elv_sla_met_count)} of {format_count_with_k(elv_total_completed)}"
        
        sla_risk_pct_str = f"{sla_risk_pct:.2f}%" if sla_risk_pct is not None else "0.00%"
        out_of_sla_pct_str = f"{out_of_sla_pct:.2f}%" if out_of_sla_pct is not None else "0.00%"
        
        tooltips = {
            "cob_sla_pct": "Percentage of completed work items that met COB SLA (INTERNALDUEDATE)",
            "completed_cob_sla": "Count of completed work items that met COB SLA out of total completed items",
            "elv_sla_pct": "Percentage of completed work items that met Elevance SLA (EXTERNALDUEDATE)",
            "completed_elv_sla": "Count of completed work items that met Elevance SLA out of total completed items",
            "sla_risk_pct": "Percentage of open items at risk of ELV SLA breach within 72 hours",
            "out_of_sla_pct": "Percentage of open items currently past Elevance SLA deadline",
            "counts_by_sla": "Count of open items grouped by days until ELV SLA breach (Out of SLA, 00-02, 03-05, 06-10, 11-15, 16-21, 22-30, 30+)"
        }

        return SLAHealthResponse(
            status="success",
            cob_sla_pct=cob_sla_pct_str,
            elv_sla_pct=elv_sla_pct_str,
            completed_elv_sla=completed_elv_sla_str,
            completed_cob_sla=completed_cob_sla_str,
            sla_risk_pct=sla_risk_pct_str,
            out_of_sla_pct=out_of_sla_pct_str,
            counts_by_sla=counts_by_sla,
            message=f"SLA data loaded successfully.",
            tooltips=tooltips
        )
    
    except Exception as e:
        logger.error(f"Error executing SLA health query: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to execute SLA health query: {str(e)}")
