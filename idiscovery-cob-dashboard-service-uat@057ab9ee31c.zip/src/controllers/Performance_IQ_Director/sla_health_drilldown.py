import logging
import math
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import httpx

from db import SnowflakeConnectionManager
from schema import (
    SlaHealthDrilldownPaginatedRequest,
    SlaHealthDrilldownPaginatedResponse,
    SlaHealthRecord,
    PageResponse,
    DirectorBaseDownloadRequest,
    AssociateListRequest,
)
import config
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from controllers.Performance_IQ_Director.associates_list import get_associates_list
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])
connection_manager = SnowflakeConnectionManager()

# SQL queries for SLA health drilldown
SLA_HEALTH_PAGINATED_QUERY = f"""
WITH deduped_inventory AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) AS ASSIGNED_USER,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        REPORTTOMANAGERID,
        REPORTTOMANAGERNAME,
        ASSIGNED_DT,
        INTERNALDUEDATE,
        EXTERNALDUEDATE,
        PXCREATEDATETIME,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
      AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                           'Open-ReviewIntake', 'Pend', 'Pend-Decision')
      {{lob_filter}}
      {{sla_created_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
),
deduped_user_profile AS (
    SELECT 
        USERID,
        USERNAME,
        PYREPORTTO,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    i.PYID AS work_item,
    i.INTAKESOURCESYSTEM AS work_type,
    u.USERNAME AS associate,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.PLATFORM,
    i.REPORTTOMANAGERNAME AS manager_name,
    i.ASSIGNED_DT AS assigned_date,
    i.INTERNALDUEDATE AS cob,
    i.EXTERNALDUEDATE AS elv_due_date
FROM deduped_inventory i
LEFT JOIN deduped_user_profile u
    ON i.ASSIGNED_USER = u.USERID AND u.rn = 1
WHERE i.rn = 1
    AND i.EXTERNALDUEDATE IS NOT NULL
ORDER BY i.PYID
LIMIT {{limit}} OFFSET {{offset}}
"""

SLA_HEALTH_DEFAULT_ORDER_BY = "ORDER BY i.PYID"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item": "i.PYID",
        "work_type": "i.INTAKESOURCESYSTEM",
        "associate": "u.USERNAME",
        "resolved_status": "i.PYSTATUSWORK",
        "inventory_type": "i.INVNTRY_TYPE",
        "lob": "i.LOB",
        "platform": "i.PLATFORM",
        "manager_name": "i.REPORTTOMANAGERNAME",
        "assigned_date": "i.ASSIGNED_DT",
        "cob": "i.INTERNALDUEDATE",
        "elv_due_date": "i.EXTERNALDUEDATE",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return SLA_HEALTH_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, i.PYID"

SLA_HEALTH_COUNT_QUERY = f"""
WITH deduped_inventory AS (
    SELECT
        PYID,
        EXTERNALDUEDATE,
        COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) AS ASSIGNED_USER,
        ROW_NUMBER() OVER (
            PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
      AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                           'Open-ReviewIntake', 'Pend', 'Pend-Decision')
      {{lob_filter}}
      {{sla_created_filter}}
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT PYID) AS SLA_HEALTH_COUNT
FROM deduped_inventory
WHERE rn = 1
    AND EXTERNALDUEDATE IS NOT NULL
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter."""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_sla_created_filter(end_date: Optional[str] = None) -> str:
    """Filter for SLA items created before end_date (includes all items whether resolved or not)."""
    if end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join([str(d).upper().strip() for d in director_ids])
        return f"AND UPPER(TRIM(REPORTTODIRECTORID)) IN ('{director_ids_str}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join([str(m).upper().strip() for m in manager_ids])
        return f"AND UPPER(TRIM(REPORTTOMANAGERID)) IN ('{manager_ids_str}')"
    return ""


async def get_total_associates_count(manager_ids: Optional[List[str]] = None, user_id: str = None) -> int:
    """Get total count of associates under the given managers by calling associates_list API."""
    if not manager_ids or len(manager_ids) == 0:
        return 0
    
    try:
        # Create request for associates list API
        # Note: start_date and end_date are required but not used for counting
        associates_request = AssociateListRequest(
            user_id=user_id or "system",
            start_date="2025-01-01",  # Placeholder dates - not used for counting
            end_date="2026-12-31",
            manager_ids=manager_ids,
            search=None,
            limit=5000
        )
        
        # Call the associates list API
        response = await get_associates_list(associates_request)
        
        # Return the total count from the response
        return response.total_count
    except Exception as e:
        logger.error(f"Error getting total associates count from API: {str(e)}")
        return 0


async def build_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for backlog items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If all associates are selected (frontline_associate_ids count matches total associates count),
    include manager IDs in the filter as well since items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Check if all associates are selected
    all_associates_selected = False
    if manager_ids and len(manager_ids) > 0:
        total_associates = await get_total_associates_count(manager_ids, user_id)
        if total_associates > 0 and len(frontline_associate_ids) == total_associates:
            all_associates_selected = True
            logger.info(f"All {total_associates} associates selected, including manager IDs in SLA Health Drilldown backlog filter")
    
    # Build the filter
    if all_associates_selected and manager_ids:
        # Include both associates and managers
        combined_ids = list(frontline_associate_ids) + list(manager_ids)
        combined_ids_str = "', '".join([str(a).upper().strip() for a in combined_ids])
        return f"AND UPPER(TRIM(COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO))) IN ('{combined_ids_str}')"
    else:
        # Only include associates
        frontline_associate_ids_str = "', '".join([str(a).upper().strip() for a in frontline_associate_ids])
        return f"AND UPPER(TRIM(COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO))) IN ('{frontline_associate_ids_str}')"

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        # Handle both date and datetime formats
        if 'T' in str(date_str):
            date_obj = datetime.strptime(str(date_str).split('T')[0], "%Y-%m-%d")
        else:
            date_obj = datetime.strptime(str(date_str).split()[0], "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

@router.post(
    "/sla-health-drilldown",
    response_model=SlaHealthDrilldownPaginatedResponse,
    summary="Get SLA Health Backlog Drilldown",
    description="""
Retrieve paginated list of SLA health backlog/open items for detailed table display.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item**: Work Item ID (PYID)
- **work_type**: Work Type (INTAKESOURCESYSTEM)
- **associate**: Associate name
- **resolved_status**: Current backlog status (Assigned, New, Open-CAQHPortal, Open-CaptureIntake, Open-ReviewIntake, Pend, Pend-Decision)
- **inventory_type**: Inventory Type (e.g., GB, CB)
- **lob**: Line of Business (e.g., Medicaid, Medicare, Commercial)
- **platform**: Platform (e.g., CIW)
- **manager_name**: Manager Name
- **assigned_date**: Assigned Date (MM/DD/YYYY format)
- **cob**: COB Internal Due Date (INTERNALDUEDATE in MM/DD/YYYY format)
- **elv_due_date**: Elevance Due Date (EXTERNALDUEDATE in MM/DD/YYYY format)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Source:** 
- COB_AI_INVNTRY_PROFILE (inventory data - uses COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) for assigned user, REPORTTOMANAGERNAME for manager name)
- COB_AI_USER_PROFILE (associate names only)
- Shows only BACKLOG items with statuses: Assigned, New, Open-CAQHPortal, Open-CaptureIntake, Open-ReviewIntake, Pend, Pend-Decision
- Filters: PYRESOLVEDTIMESTAMP IS NULL (open items only)
""",
)
async def get_sla_health_drilldown(request: SlaHealthDrilldownPaginatedRequest) -> SlaHealthDrilldownPaginatedResponse:
    """Session-enabled SLA health backlog drilldown endpoint with pagination."""
    return await execute_sla_health_drilldown_query(request)


async def execute_sla_health_drilldown_query(request: SlaHealthDrilldownPaginatedRequest) -> SlaHealthDrilldownPaginatedResponse:
    """Execute SLA health backlog drilldown query logic (open items only)."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        sla_created_filter = build_sla_created_filter(request.end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        # Use async filter that includes manager IDs if all associates are selected
        associate_filter = await build_associate_filter(
            request.frontline_associate_ids,
            request.manager_ids,
            request.user_id
        )
        
        engine = connection_manager.get_engine()
        
        # Get total count
        count_query = SLA_HEALTH_COUNT_QUERY.format(
            lob_filter=lob_filter,
            sla_created_filter=sla_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = count_result[0].get("SLA_HEALTH_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Get paginated data
        data_query = SLA_HEALTH_PAGINATED_QUERY.format(
            lob_filter=lob_filter,
            sla_created_filter=sla_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            SLA_HEALTH_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        # Format records
        sla_health_records = [
            SlaHealthRecord(
                work_item=record.get("WORK_ITEM") or "",
                work_type=record.get("WORK_TYPE") or "",
                associate=record.get("ASSOCIATE") or "",
                resolved_status=record.get("RESOLVED_STATUS") or "",
                inventory_type=record.get("INVENTORY_TYPE") or "",
                lob=record.get("LOB") or "",
                platform=record.get("PLATFORM") or "",
                manager_name=record.get("MANAGER_NAME") or "",
                assigned_date=format_date_mmddyyyy(str(record.get("ASSIGNED_DATE"))) if record.get("ASSIGNED_DATE") else "",
                cob=format_date_mmddyyyy(str(record.get("COB"))) if record.get("COB") else "",
                elv_due_date=format_date_mmddyyyy(str(record.get("ELV_DUE_DATE"))) if record.get("ELV_DUE_DATE") else ""
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the work item (PYID)",
            "work_type": "Type of work item (INTAKESOURCESYSTEM)",
            "associate": "Name of the associate assigned to the work item",
            "resolved_status": "Current backlog status (Assigned, New, Open-CAQHPortal, Open-CaptureIntake, Open-ReviewIntake, Pend, Pend-Decision)",
            "inventory_type": "Type of inventory classification (e.g., GB, CB)",
            "lob": "Line of Business (Medicaid, Medicare, Commercial)",
            "platform": "Platform where the work item was processed",
            "manager_name": "Name of the manager overseeing the work item",
            "assigned_date": "Date when the work item was assigned",
            "cob": "COB Internal Due Date (INTERNALDUEDATE)",
            "elv_due_date": "Elevance Due Date (EXTERNALDUEDATE)"
        }

        return SlaHealthDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=sla_health_records,
            message="SLA health backlog items retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated SLA health drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return SlaHealthDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve SLA health backlog items: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/sla-health-drilldown/download-excel",
    summary="Download SLA Health Backlog Drilldown as Excel (Director)",
    description="""
Download complete SLA health backlog drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate_ids to filter

**Returns:** Excel file (.xlsx) with all backlog SLA health items (Assigned, New, Open-CAQHPortal, Open-CaptureIntake, Open-ReviewIntake, Pend, Pend-Decision)
""",
)
async def download_sla_health_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        sla_created_filter = build_sla_created_filter(request.end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(request.manager_ids)
        # Use async filter that includes manager IDs if all associates are selected
        associate_filter = await build_associate_filter(
            request.frontline_associate_ids,
            request.manager_ids,
            request.user_id
        )
        
        engine = connection_manager.get_engine()
        
        # Query with high limit for download
        download_query = SLA_HEALTH_PAGINATED_QUERY.format(
            lob_filter=lob_filter,
            sla_created_filter=sla_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "SLA Health Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Associate Name",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Platform",
            "Manager Name",
            "Assigned Date",
            "COB",
            "ELV Due Date"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate((data_result or []), start=2):
            if not isinstance(row, dict):
                continue
            ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("WORK_TYPE", "")))
            ws.cell(row=row_num, column=3, value=str(row.get("ASSOCIATE", "")))
            ws.cell(row=row_num, column=4, value=str(row.get("RESOLVED_STATUS", "")))
            ws.cell(row=row_num, column=5, value=str(row.get("INVENTORY_TYPE", "")))
            ws.cell(row=row_num, column=6, value=str(row.get("LOB", "")))
            ws.cell(row=row_num, column=7, value=str(row.get("PLATFORM", "")))
            ws.cell(row=row_num, column=8, value=str(row.get("MANAGER_NAME", "")))
            ws.cell(row=row_num, column=9, value=format_date_mmddyyyy(str(row.get("ASSIGNED_DATE"))) if row.get("ASSIGNED_DATE") else "")
            ws.cell(row=row_num, column=10, value=format_date_mmddyyyy(str(row.get("COB"))) if row.get("COB") else "")
            ws.cell(row=row_num, column=11, value=format_date_mmddyyyy(str(row.get("ELV_DUE_DATE"))) if row.get("ELV_DUE_DATE") else "")
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"sla_health_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for SLA health drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
