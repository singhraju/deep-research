import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import httpx
import asyncio
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from schema import (
    WatchlistDrilldownPaginatedRequest,
    WatchlistDrilldownPaginatedResponse,
    WatchlistRecord,
    PageResponse,
    DirectorBaseDownloadRequest,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from db import SnowflakeConnectionManager
import math

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/director", tags=["Performance_IQ_Director"])

connection_manager = SnowflakeConnectionManager()

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        cleaned = str(date_str)
        if "T" in cleaned:
            cleaned = cleaned.split("T")[0]
        elif " " in cleaned:
            cleaned = cleaned.split(" ")[0]
        date_obj = datetime.strptime(cleaned, "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

WATCHLIST_PAGINATED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PLATFORM,
        INVNTRY_TYPE,
        ISADDTOWATCHLIST,
        PYRESOLVEDUSERID,
        PXCREATEDATETIME,
        EXTERNALDUEDATE,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      {{lob_filter}}
      {{watchlist_created_filter}}
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
),
deduped_user_profile AS (
    SELECT 
        USERID,
        PYREPORTTO,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    i.PYID AS work_item,
    i.INTAKESOURCESYSTEM AS work_type,
    u.USERNAME AS associate,
    i.PYSTATUSWORK AS resolved_status,
    i.INVNTRY_TYPE AS inventory_type,
    i.LOB,
    i.PLATFORM,
    i.EXTERNALDUEDATE AS elv_due_date
FROM invntry_deduped i
INNER JOIN deduped_user_profile u
    ON i.PYRESOLVEDUSERID = u.USERID
WHERE i.rn = 1
  AND u.rn = 1
ORDER BY i.PXCREATEDATETIME DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

WATCHLIST_DEFAULT_ORDER_BY = "ORDER BY i.PXCREATEDATETIME DESC"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item": "i.PYID",
        "work_type": "i.INTAKESOURCESYSTEM",
        "associate": "u.USERNAME",
        "resolved_status": "i.PYSTATUSWORK",
        "inventory_type": "i.INVNTRY_TYPE",
        "lob": "i.LOB",
        "platform": "i.PLATFORM",
        "elv_due_date": "i.EXTERNALDUEDATE",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return WATCHLIST_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, i.PXCREATEDATETIME DESC, i.PYID"

WATCHLIST_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID 
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      {{lob_filter}}
      {{watchlist_created_filter}}
      AND ISADDTOWATCHLIST = 'Y'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      {{director_filter}}
      {{manager_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT PYID) AS WATCHLIST_COUNT
FROM invntry_deduped 
WHERE rn = 1
"""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for PYRESOLVEDTIMESTAMP."""
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_watchlist_created_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for PXCREATEDATETIME (when watchlist item was created)."""
    if start_date and end_date:
        return f"AND PXCREATEDATETIME >= '{start_date}' AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND PXCREATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_director_filter(director_ids: Optional[List[str]] = None) -> str:
    """Build director filter for inventory table (uses REPORTTODIRECTORID)."""
    if director_ids and len(director_ids) > 0:
        director_ids_str = "', '".join(director_ids)
        return f"AND REPORTTODIRECTORID IN ('{director_ids_str}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID for watchlist items)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""

@router.post(
    "/watchlist-drilldown",
    response_model=WatchlistDrilldownPaginatedResponse,
)
async def get_watchlist_drilldown(request: WatchlistDrilldownPaginatedRequest) -> WatchlistDrilldownPaginatedResponse:
    """watchlist drilldown endpoint - direct query execution."""
    return await execute_watchlist_drilldown_query(request)


async def execute_watchlist_drilldown_query(request: WatchlistDrilldownPaginatedRequest) -> WatchlistDrilldownPaginatedResponse:
    """Execute watchlist drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        lob_filter = build_lob_filter(lob)
        watchlist_created_filter = build_watchlist_created_filter(start_date, end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached watchlist_count from demand-inventory
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict and hash for cache key
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'director_ids': request.director_ids,
                    'manager_ids': request.manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                
                # Get cached watchlist count from demand-inventory
                cache_key = f"session:{session_id}:{filters_hash}:watchlist_count"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract WATCHLIST_COUNT from cached query result
                    total_records = int(cached_metric[0].get("WATCHLIST_COUNT", 0))
                    logger.info(f"✅ Reused cached watchlist count: {total_records} (from demand-inventory)")
                else:
                    logger.info(f"Cache miss for watchlist_count, running COUNT query")
                    # Fall back to COUNT query
                    count_query = WATCHLIST_COUNT_QUERY.format(
                        lob_filter=lob_filter,
                        watchlist_created_filter=watchlist_created_filter,
                        director_filter=director_filter,
                        manager_filter=manager_filter,
                        associate_filter=associate_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("WATCHLIST_COUNT", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached watchlist count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = WATCHLIST_COUNT_QUERY.format(
                    lob_filter=lob_filter,
                    watchlist_created_filter=watchlist_created_filter,
                    director_filter=director_filter,
                    manager_filter=manager_filter,
                    associate_filter=associate_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("WATCHLIST_COUNT", 0) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = WATCHLIST_COUNT_QUERY.format(
                lob_filter=lob_filter,
                watchlist_created_filter=watchlist_created_filter,
                director_filter=director_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("WATCHLIST_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        data_query = WATCHLIST_PAGINATED_QUERY.format(
            lob_filter=lob_filter,
            watchlist_created_filter=watchlist_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            WATCHLIST_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        watchlist_records = [
            WatchlistRecord(
                work_item=record.get("WORK_ITEM") or "",
                work_type=record.get("WORK_TYPE") or "",
                associate=record.get("ASSOCIATE") or "",
                resolved_status=record.get("RESOLVED_STATUS") or "",
                inventory_type=record.get("INVENTORY_TYPE") or "",
                lob=record.get("LOB") or "",
                platform=record.get("PLATFORM") or "",
                elv_due_date=format_date_mmddyyyy(str(record.get("ELV_DUE_DATE"))) if record.get("ELV_DUE_DATE") else "N/A"
            )
            for record in records
        ]
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the work item on the watchlist",
            "work_type": "Type of work item (e.g., Newborn, Compass, HEW, Claim Request)",
            "associate": "Name of the associate resolved the work item",
            "resolved_status": "Current resolution status of the work item",
            "inventory_type": "Type of inventory classification (e.g., GB, CB)",
            "lob": "Line of Business (Medicaid, Medicare, Commercial)",
            "platform": "Platform where the work item is processed",
            "elv_due_date": "ELV (Escalation Level) due date for the work item"
        }

        return WatchlistDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=watchlist_records,
            message="Watchlist records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated watchlist drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return WatchlistDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve watchlist records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/watchlist-drilldown/download-excel",
    summary="Download Watchlist Drilldown as Excel (Director)",
    description="""
Download complete watchlist drilldown data as an Excel file (Director version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all watchlist records (placeholder data)
""",
)
async def download_watchlist_drilldown_excel(
    request: DirectorBaseDownloadRequest
) -> StreamingResponse:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
    try:
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        lob_filter = build_lob_filter(lob)
        watchlist_created_filter = build_watchlist_created_filter(request.start_date, request.end_date)
        director_filter = build_director_filter(request.director_ids)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        download_query = WATCHLIST_PAGINATED_QUERY.format(
            lob_filter=lob_filter,
            watchlist_created_filter=watchlist_created_filter,
            director_filter=director_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
    except Exception as e:
            logger.error(f"Excel download error for watchlist drilldown: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
    
    # STEP 3: Generate Excel file
    try:
        total_records = len(data_result)

        wb = Workbook()
        ws = wb.active
        ws.title = "Watchlist Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Associate Name",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Platform",
            "ELV Due Date"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows with field name compatibility
        for row_num, record in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(record.get("work_item") or record.get("WORK_ITEM", "")))
            ws.cell(row=row_num, column=2, value=str(record.get("work_type") or record.get("WORK_TYPE", "")))
            ws.cell(row=row_num, column=3, value=str(record.get("associate") or record.get("ASSOCIATE", "")))
            ws.cell(row=row_num, column=4, value=str(record.get("resolved_status") or record.get("RESOLVED_STATUS", "")))
            ws.cell(row=row_num, column=5, value=str(record.get("inventory_type") or record.get("INVENTORY_TYPE", "N/A")))
            ws.cell(row=row_num, column=6, value=str(record.get("lob") or record.get("LOB", "")))
            ws.cell(row=row_num, column=7, value=str(record.get("platform") or record.get("PLATFORM", "")))
            elv_due_date = record.get("elv_due_date") or record.get("ELV_DUE_DATE")
            ws.cell(row=row_num, column=8, value=format_date_mmddyyyy(str(elv_due_date)) if elv_due_date else "N/A")
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"watchlist_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for watchlist drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
