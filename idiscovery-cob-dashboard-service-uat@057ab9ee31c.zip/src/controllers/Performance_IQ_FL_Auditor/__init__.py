from fastapi import APIRouter
from .header_kpis import router as header_kpis_router
from .rebuttal_count_drilldown import router as rebuttal_count_drilldown_router
from .complete_audit_count_drilldown import router as complete_audit_count_drilldown_router
from .ata_score_drilldown import router as ata_score_drilldown_router
from .work_items_drilldown import router as work_items_drilldown_router
from .ata_score_gauge import router as ata_score_gauge_router
from .audit_cycle_time_gauge import router as audit_cycle_time_gauge_router
from .rebuttals import router as rebuttals_router
from .time_utilization import router as time_utilization_router
from .fuse_time_drilldown import router as fuse_time_drilldown_router
from .lob_list import router as lob_list_router
from .ai_coach import router as ai_coach_router
from .user_activity import router as user_activity_router

# Create main router for FL Auditor endpoints
router = APIRouter()

# Include all FL Auditor sub-routers
router.include_router(header_kpis_router)
router.include_router(rebuttal_count_drilldown_router)
router.include_router(complete_audit_count_drilldown_router)
router.include_router(ata_score_drilldown_router)
router.include_router(work_items_drilldown_router)
router.include_router(ata_score_gauge_router)
router.include_router(audit_cycle_time_gauge_router)
router.include_router(rebuttals_router)
router.include_router(time_utilization_router)
router.include_router(fuse_time_drilldown_router)
router.include_router(lob_list_router)
router.include_router(ai_coach_router)
router.include_router(user_activity_router)

__all__ = ["router"]
