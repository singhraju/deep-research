import logging
from fastapi import APIRouter, Response, status
import config
from schema import FLAuditorBaseRequest, AICoachResponse
from services.openai_service import generate_performance_summary, normalize_ai_summary
from services.metrics_aggregator import fetch_fl_auditor_metrics

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])


@router.post(
    "/ai-coach",
    response_model=AICoachResponse,
    summary="Get FL Auditor AI Coach Insights",
    description="""
Retrieve AI Coach insights and recommendations for FL Auditor.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter

**Response Fields:**
- **message_text**: AI-generated insights for audit performance and quality
- **performance_score**: Performance score percentage (optional)

**Status:** AI-powered auditor coaching using OpenAI GPT models

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (performance metrics for AI analysis)
- OpenAI GPT models (for generating insights)
""",
)
async def get_fl_auditor_ai_coach(request: FLAuditorBaseRequest, response: Response) -> AICoachResponse:
    if not config.is_ai_coach_enabled("fl_auditor"):
        return AICoachResponse(
            status="disabled",
            user_id=request.user_id,
            performance_summary="AI Coach feature is currently disabled",
            message="Feature disabled by configuration"
        )
    
    try:
        logger.info(f"FL Auditor AI Coach request for user {request.user_id}")
        
        metrics_data = await fetch_fl_auditor_metrics(
            user_id=request.user_id,
            start_date=getattr(request, 'start_date', None) or "",
            end_date=getattr(request, 'end_date', None) or "",
            lob=getattr(request, 'lob', None),
            session_id=getattr(request, 'session_id', None)
        )
        
        logger.info(f"FL Auditor AI Coach - Metrics sent to LLM: {metrics_data}")

        if "error" in metrics_data:
            logger.error(f"FL Auditor AI Coach metrics fetch failed for {request.user_id}: {metrics_data.get('error')}")
            response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            return AICoachResponse(
                status="error",
                user_id=request.user_id,
                performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
                message=f"Failed to fetch AI Coach metrics: {metrics_data.get('error')}"
            )

        summary = await generate_performance_summary(
            user_id=request.user_id,
            metrics_data=metrics_data,
            role="fl_auditor",
            start_date=getattr(request, 'start_date', None) or "",
            end_date=getattr(request, 'end_date', None) or "",
            lob=getattr(request, 'lob', None)
        )

        summary_text = normalize_ai_summary(summary)["performance_summary"]
        
        return AICoachResponse(
            status="success",
            user_id=request.user_id,
            performance_summary=summary_text,
            message="AI Coach analysis completed successfully"
        )

    except Exception as e:
        logger.error(f"FL Auditor AI Coach error: {type(e).__name__}: {str(e)}")

        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return AICoachResponse(
            status="error",
            user_id=request.user_id,
            performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
            message=f"Error: {str(e)}"
        )
