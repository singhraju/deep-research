import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from schema import (
    FLAuditorAtaScoreDrilldownRequest,
    FLAuditorAtaScoreDrilldownResponse,
    FLAuditorAtaScoreRecord,
    PageResponse,
    FLAuditorBaseRequest,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
import math
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from services.session_cache_orchestrator import generate_session_id
from controllers.Performance_IQ_FL_Auditor.header_kpis import (
    build_audit_period_filter,
    build_lob_filter,
    build_user_filter_ata,
    ATA_AUDIT_SCORE_QUERY,
)

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def clean_resolved_status(status: str) -> str:
    """Convert completion_type values to display format"""
    if not status:
        return ""
    normalized_status = str(status).strip().upper()
    if normalized_status == "OPEN-FEEDBACKREVIEW":
        return "Open-FeedbackReview"
    elif normalized_status == "RESOLVED-COMPLETED":
        return "Resolved-Completed"
    return str(status)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])

connection_manager = SnowflakeConnectionManager()

AUDIT_SCORE_PAGINATED_QUERY = f"""
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB,
        INTAKESOURCESYSTEM,
        PLATFORM,
        AUDITCYCLETIME,
        INVNTRY_TYPE
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{user_filter}}
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.INTAKESOURCESYSTEM,
        a.PLATFORM,
        a.AUDITCYCLETIME,
        a.INVNTRY_TYPE,
        a.LOB,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SUBJECT_NAME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        INTAKESOURCESYSTEM,
        PLATFORM,
        AUDITCYCLETIME,
        INVNTRY_TYPE,
        LOB,
        AUDIT_SUBJECT_ID,
        AUDIT_SUBJECT_NAME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)
SELECT
    PYID,
    INTAKESOURCESYSTEM,
    completion_type AS PYSTATUSWORK,
    LOB,
    DATE(completion_timestamp) AS AUDIT_DATE,
    AUDIT_SUBJECT_ID AS AUDITOR_ID,
    COALESCE(AUDIT_SUBJECT_NAME, 'N/A') AS AUDIT_SUBJECT_NAME,
    AUDIT_SCORE,
    PLATFORM,
    TARGET_AUDIT,
    AUDITCYCLETIME,
    INVNTRY_TYPE,
    COALESCE(AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM ata_final_records
ORDER BY AUDIT_DATE DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_ATA_SCORE_ORDER_BY = "AUDIT_DATE DESC"

DISPLAY_ATA_SCORE_RESOLVED_STATUS_SQL = """
CASE
    WHEN PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
    WHEN PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
    ELSE COALESCE(PYSTATUSWORK, '')
END
"""
DISPLAY_ATA_SCORE_AUDIT_RESOLVED_SQL = "AUDIT_DATE"

SORTABLE_ATA_SCORE_COLUMNS = {
    "pyid": "PYID",
    "work_type": "COALESCE(INTAKESOURCESYSTEM, '')",
    "audit_cycle_time": "COALESCE(AUDITCYCLETIME, 0)",
    "resolved_status": DISPLAY_ATA_SCORE_RESOLVED_STATUS_SQL,
    "lob": "COALESCE(LOB, '')",
    "audit_resolved": DISPLAY_ATA_SCORE_AUDIT_RESOLVED_SQL,
    "auditor_name": "COALESCE(AUDIT_SUBJECT_NAME, 'N/A')",
    "platform": "COALESCE(PLATFORM, 'N/A')",
    "audit_score": "COALESCE(TRY_TO_DECIMAL(TRIM(AUDIT_SCORE)), 0)",
    "targeted_audit_type": "COALESCE(TARGET_AUDIT, 'N/A')",
    "inventory_type": "COALESCE(INVNTRY_TYPE, 'N/A')",
    "audit_month": "COALESCE(AUDIT_MONTH, 'N/A')",
    "audit_year": "COALESCE(AUDIT_YEAR, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_ATA_SCORE_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_ATA_SCORE_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid FL Auditor ATA score sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_ATA_SCORE_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid FL Auditor ATA score sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_ATA_SCORE_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "audit_resolved":
        tie_breakers.append("AUDIT_DATE DESC")
    if normalized_sort_by != "pyid":
        tie_breakers.append("PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_ata_score_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_ATA_SCORE_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )

# Count query removed - will reuse from header_kpis via ATA_AUDIT_SCORE_QUERY

# Filter builders removed - now imported from header_kpis

@router.post(
    "/ata-score-drilldown",
    response_model=FLAuditorAtaScoreDrilldownResponse,
    summary="Get FL Auditor ATA Score Drilldown",
    description="""
Retrieve paginated drilldown data for FL Auditor ATA audit score metric.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **page** (optional): Page number (default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **pyid**: Unique audited case identifier
- **work_type**: Source system type
- **audit_cycle_time**: Time from creation to audit in hh:mm:ss format
- **resolved_status**: Case status
- **lob**: Line of Business
- **audit_resolved**: Audit completion date (MM/DD/YYYY format)
- **auditor_domain_id**: FL Auditor's user ID
- **platform**: Processing platform
- **audit_score**: Quality score as percentage
- **targeted_audit_type**: Type of audit (targeted vs random)
- **inventory_type**: Type of inventory or work category

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (audit data)
- COB_AI_INVNTRY_PROFILE (cycle time)
""",
)
async def get_ata_score_drilldown(request: FLAuditorAtaScoreDrilldownRequest) -> FLAuditorAtaScoreDrilldownResponse:
    """ATA score drilldown with session-based cache reuse."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Build filters
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        user_filter = build_user_filter_ata(request.user_id)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached ata_audit_score from header KPIs
        total_records = 0
        target_audit_count = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict and hash for cache key
                filters = {
                    'user_id': request.user_id,
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                }
                filters_hash = build_filters_hash(**filters)
                
                # Get cached ATA audit score from header KPIs
                cache_key = f"session:{session_id}:{filters_hash}:ata_audit_score"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract total_ata_cases from cached query result
                    total_records = int(cached_metric[0].get("TOTAL_ATA_CASES", 0))
                    target_audit_count = int(cached_metric[0].get("TARGET_AUDIT_COUNT", 0))
                    logger.info(f"✅ Reused cached ATA audit score count: {total_records} (from header KPIs)")
                else:
                    logger.info(f"Cache miss for ata_audit_score, running COUNT query")
                    # Fall back to COUNT query
                    count_query = ATA_AUDIT_SCORE_QUERY.format(
                        audit_period_filter=audit_period_filter,
                        lob_filter=lob_filter,
                        user_filter_ata=user_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = int(count_result[0].get("TOTAL_ATA_CASES", 0)) if count_result else 0
                    target_audit_count = int(count_result[0].get("TARGET_AUDIT_COUNT", 0)) if count_result else 0
            except Exception as e:
                logger.warning(f"Cache reuse failed: {str(e)}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = ATA_AUDIT_SCORE_QUERY.format(
                    audit_period_filter=audit_period_filter,
                    lob_filter=lob_filter,
                    user_filter_ata=user_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = int(count_result[0].get("TOTAL_ATA_CASES", 0)) if count_result else 0
                target_audit_count = int(count_result[0].get("TARGET_AUDIT_COUNT", 0)) if count_result else 0
        else:
            # No session_id or Redis disabled - run COUNT query
            count_query = ATA_AUDIT_SCORE_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                user_filter_ata=user_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = int(count_result[0].get("TOTAL_ATA_CASES", 0)) if count_result else 0
            target_audit_count = int(count_result[0].get("TARGET_AUDIT_COUNT", 0)) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = AUDIT_SCORE_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter,
            limit=page_limit,
            offset=offset
        )

        data_query = apply_custom_sort_to_ata_score_query(
            data_query,
            request.sort_by,
            request.sort_direction,
        )

        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        audit_scores = [
            FLAuditorAtaScoreRecord(
                pyid=record.get("PYID") or "N/A",
                work_type=record.get("INTAKESOURCESYSTEM") or "N/A",
                audit_cycle_time=format_cycle_time(record.get("AUDITCYCLETIME")),
                resolved_status=clean_resolved_status(record.get("PYSTATUSWORK")),
                lob=record.get("LOB") or "N/A",
                audit_resolved=format_date_mmddyyyy(record.get("AUDIT_DATE")),
                platform=record.get("PLATFORM") or "N/A",
                audit_score=f"{int(record.get('AUDIT_SCORE'))}%" if record.get("AUDIT_SCORE") else "0%",
                targeted_audit_type=record.get("TARGET_AUDIT") or "N/A",
                inventory_type=record.get("INVNTRY_TYPE") or "N/A",
                auditor_name=record.get("AUDIT_SUBJECT_NAME") or "N/A",
                audit_month=record.get("AUDIT_MONTH") or "N/A",
                audit_year=record.get("AUDIT_YEAR") or "N/A",
            )
            for record in records
        ] if records else []

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "pyid": "Unique identifier for the audited case",
            "work_type": "Source system or type of work item that was audited",
            "audit_cycle_time": "Time from case creation to audit completion in hh:mm:ss format",
            "resolved_status": "Current status of the audited work item",
            "lob": "Line of Business associated with the audited case",
            "audit_resolved": "Date when the audit was completed",
            "auditor_name": "Name of the FL Auditor",
            "platform": "Platform where the case was processed",
            "audit_score": "Quality score achieved for this audit as a percentage",
            "targeted_audit_type": "Type of audit performed (targeted vs random)",
            "inventory_type": "Type of inventory or work category",
            "rebuttal_outcome": "Outcome of any rebuttal submitted for this audit"
        }

        return FLAuditorAtaScoreDrilldownResponse(
            status="success",
            screen_id="ata_score_fl_auditor",
            user_id=request.user_id,
            page=page_response,
            records=audit_scores,
            completed_audit_work_items=total_records,
            target_audit_count=target_audit_count,
            message="FL Auditor ATA score records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"FL Auditor ATA score drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return FLAuditorAtaScoreDrilldownResponse(
            status="error",
            screen_id="ata_score_fl_auditor",
            user_id=request.user_id,
            page=page_response,
            records=[],
            completed_audit_work_items=0,
            target_audit_count=0,
            message=f"Failed to retrieve FL Auditor ATA score records: {str(e)}"
        )


@router.post(
    "/ata-score-drilldown/download-excel",
    summary="Download FL Auditor ATA Score Drilldown as Excel",
    description="""
Download complete FL Auditor ATA audit score drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values

**Returns:** Excel file (.xlsx) with all audit score records
""",
)
async def download_ata_score_drilldown_excel(
    request: FLAuditorBaseRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        user_filter = build_user_filter_ata(user_id)
        
        engine = connection_manager.get_engine()
        
        # Query with high limit for download (no pagination needed)
        download_query = AUDIT_SCORE_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "FL Auditor ATA Score"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Audit Status",
            "Inventory Type",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Platform",
            "Audit Score",
            "Targeted Audit Type",
            "Auditor Name"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("PYID", "") or "N/A"))
            ws.cell(row=row_num, column=2, value=str(row.get("INTAKESOURCESYSTEM", "") or "N/A"))
            ws.cell(row=row_num, column=3, value=clean_resolved_status(str(row.get("PYSTATUSWORK", "") or "N/A")))
            ws.cell(row=row_num, column=4, value=str(row.get("INVNTRY_TYPE", "N/A") or "N/A"))
            ws.cell(row=row_num, column=5, value=str(row.get("LOB", "") or "N/A"))
            ws.cell(row=row_num, column=6, value=format_date_mmddyyyy(str(row.get("AUDIT_DATE", ""))) if row.get("AUDIT_DATE") else "")
            ws.cell(row=row_num, column=7, value=str(row.get("AUDIT_MONTH", "") or "N/A"))
            ws.cell(row=row_num, column=8, value=(
                int(row["AUDIT_YEAR"]) if row.get("AUDIT_YEAR") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=9, value=str(row.get("PLATFORM") or "N/A") if row.get("PLATFORM") else "N/A")
            ws.cell(row=row_num, column=10, value=(
                float(row["AUDIT_SCORE"]) if row.get("AUDIT_SCORE") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=11, value=str(row.get("TARGET_AUDIT", "") or "N/A"))
            ws.cell(row=row_num, column=12, value=str(row.get("AUDIT_SUBJECT_NAME", "N/A") or "N/A"))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"fl_auditor_ata_score_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for FL Auditor ATA score drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
