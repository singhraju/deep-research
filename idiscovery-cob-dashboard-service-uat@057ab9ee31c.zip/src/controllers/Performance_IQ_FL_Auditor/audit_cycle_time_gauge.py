import logging
from typing import Optional, List
import asyncio
from datetime import datetime
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import (
    FLAuditorBaseRequest,
    FLAuditorAuditCycleTimeGaugeResponse,
    FLAuditorCycleTimeTrend,
    AuditPeriod,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from controllers.Performance_IQ_FL_Auditor.header_kpis import (
    AUDIT_CYCLE_TIME_QUERY,
    build_lob_filter,
    build_user_filter,
    build_audit_period_filter,
)

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])

connection_manager = SnowflakeConnectionManager()


AUDIT_CYCLE_TIME_TREND_QUERY = f"""
WITH grouping_logic AS (
    SELECT
        '{{grouping_type}}' AS grouping_type,
        '{{use_audit_period_grouping}}' AS use_audit_period_grouping
),
audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXCOMMITDATETIME,
        a.AUDITCYCLETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      {{audit_period_filter}}
      {{lob_filter}}
      {{user_filter}}
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.completion_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        MIN(a.PXCOMMITDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
      ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.completion_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        f.AUDIT_MONTH,
        f.AUDIT_YEAR,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
      ON a.PYID = f.PYID
     AND a.PXCOMMITDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        f.AUDIT_MONTH,
        f.AUDIT_YEAR
),
cycle_time_with_audit_period AS (
    SELECT
        c.PYID,
        c.completion_ts,
        c.cycle_ts,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.AUDITCYCLETIME,
        CASE UPPER(TRIM(c.AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM cycle_time_at_first_positive_ts c
),
grouped_data AS (
    SELECT
        g.grouping_type,
        g.use_audit_period_grouping,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(c.completion_ts)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(c.completion_ts))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(c.AUDIT_YEAR), c.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(c.completion_ts))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(c.AUDIT_YEAR),
                CASE
                    WHEN c.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN c.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN c.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(c.completion_ts))

            ELSE DATE_TRUNC('year', DATE(c.completion_ts))
        END AS group_key,
        DATE(c.completion_ts) AS completion_date,
        c.AUDITCYCLETIME,
        c.PYID
    FROM cycle_time_with_audit_period c
    CROSS JOIN grouping_logic g
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' AND use_audit_period_grouping = 'false' THEN
            TO_CHAR(GREATEST(group_key, '{{start_date}}'::DATE), 'MM/DD') || ' - ' ||
            TO_CHAR(LEAST(DATEADD(day, 6, group_key), '{{end_date}}'::DATE), 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES,
    COUNT(DISTINCT PYID) AS TOTAL_AUDITS,
    MIN(completion_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, use_audit_period_grouping, group_key
ORDER BY SORT_DATE
"""


def format_minutes_to_mins_secs(minutes: float) -> str:
    """Convert decimal minutes to 'X mins Y secs' format"""
    if minutes is None or minutes == 0:
        return "0 mins 0 secs"
    
    total_seconds = int(minutes * 60)
    mins = total_seconds // 60
    secs = total_seconds % 60
    
    return f"{mins} mins {secs} secs"


def execute_query(engine, query: str, limit: int = 1):
    return engine.execute_query(query, limit=limit)


def has_valid_audit_periods(audit_periods: Optional[List[AuditPeriod]] = None) -> bool:
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = (period.year or "").strip()

        if not month_value or not year_value:
            continue

        seen_periods.add((month_value.upper(), year_value))

    return bool(seen_periods)


def get_trend_grouping_type(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    audit_periods: Optional[List[AuditPeriod]] = None,
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = (period.year or "").strip()

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append(key)

    if valid_periods:
        month_count = len(valid_periods)

        if month_count == 1:
            return "weekly"
        if month_count <= 6:
            return "monthly"
        return "quarterly"

    range_start = start_date or "1900-01-01"
    range_end = end_date or "2099-12-31"

    total_days = (
        datetime.strptime(range_end, "%Y-%m-%d") -
        datetime.strptime(range_start, "%Y-%m-%d")
    ).days + 1

    if total_days <= 7:
        return "daily"
    if total_days <= 28:
        return "weekly"
    if total_days <= 365:
        return "monthly"
    if total_days <= 1095:
        return "quarterly"
    return "yearly"


@router.post(
    "/audit-cycle-time-gauge",
    response_model=FLAuditorAuditCycleTimeGaugeResponse,
    summary="Get FL Auditor Audit Cycle Time Gauge",
    description="""
Retrieve audit cycle time gauge metric for FL Auditor dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter

**Response Fields:**
- **audit_cycle_time**: Average audit cycle time in hours (2 decimal places or N/A)
- **trend**: Audit cycle time trend over time (currently empty)

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (audit cycle times)
""",
)
async def get_fl_auditor_audit_cycle_time_gauge(request: FLAuditorBaseRequest) -> FLAuditorAuditCycleTimeGaugeResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        lob_filter = build_lob_filter(request.lob)
        user_filter = build_user_filter(request.user_id)
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            request.audit_periods,
            timestamp_column="completion_ts",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        grouping_type = get_trend_grouping_type(
            request.start_date,
            request.end_date,
            request.audit_periods,
        )
        use_audit_period_grouping = has_valid_audit_periods(request.audit_periods)

        engine = connection_manager.get_engine()

        cycle_time_query = AUDIT_CYCLE_TIME_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter
        )

        trend_query = AUDIT_CYCLE_TIME_TREND_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter,
            grouping_type=grouping_type,
            use_audit_period_grouping=str(use_audit_period_grouping).lower(),
            start_date=request.start_date or "1900-01-01",
            end_date=request.end_date or "2099-12-31"
        )

        cycle_time_records, trend_records = await asyncio.gather(
            engine.execute_query_async(cycle_time_query, limit=1),
            engine.execute_query_async(trend_query, limit=10000)
        )
        
        if cycle_time_records and cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME_MINUTES") is not None:
            avg_minutes = float(cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME_MINUTES", 0.0))
            audit_cycle_time = float(round(avg_minutes, 2))
            audit_cycle_time_formatted = format_minutes_to_mins_secs(avg_minutes)
        else:
            audit_cycle_time = 0.0
            audit_cycle_time_formatted = "N/A"

        # Sort trend records by sort_date in chronological order
        if trend_records:
            trend_records = sorted(trend_records, key=lambda x: x.get("SORT_DATE") or "")

        trend_data = [
            FLAuditorCycleTimeTrend(
                period=r["PERIOD"],
                avg_cycle_time_minutes=round(float(r["AVG_AUDIT_CYCLE_TIME_MINUTES"]), 2) if r["AVG_AUDIT_CYCLE_TIME_MINUTES"] else 0.0,
                avg_cycle_time_formatted=format_minutes_to_mins_secs(float(r["AVG_AUDIT_CYCLE_TIME_MINUTES"]) if r["AVG_AUDIT_CYCLE_TIME_MINUTES"] else 0.0),
                total_audits=int(r["TOTAL_AUDITS"]) if r["TOTAL_AUDITS"] else 0
            )
            for r in trend_records
        ] if trend_records else []

        tooltips = {
            "audit_cycle_time": "Average audit cycle time in minutes",
            "audit_cycle_time_formatted": "Average audit cycle time formatted as 'X mins Y secs'",
            "trend": "Audit cycle time trend over time"
        }

        return FLAuditorAuditCycleTimeGaugeResponse(
            status="success",
            audit_cycle_time=f"{audit_cycle_time:.2f}" if audit_cycle_time > 0 else "N/A",
            audit_cycle_time_formatted=audit_cycle_time_formatted,
            trend=trend_data,
            message="FL Auditor audit cycle time gauge retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"FL Auditor audit cycle time gauge query error: {type(e).__name__}: {str(e)}")
        return FLAuditorAuditCycleTimeGaugeResponse(
            status="error",
            audit_cycle_time="N/A",
            audit_cycle_time_formatted="N/A",
            trend=[],
            message=f"Failed to retrieve FL Auditor audit cycle time gauge: {str(e)}"
        )
