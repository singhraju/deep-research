import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from schema import (
    FLAuditorCompleteAuditDrilldownRequest,
    FLAuditorCompleteAuditDrilldownResponse,
    FLAuditorCompleteAuditRecord,
    PageResponse,
    FLAuditorBaseRequest,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
import math
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from services.session_cache_orchestrator import generate_session_id
from controllers.Performance_IQ_FL_Auditor.header_kpis import (
    build_audit_period_filter,
    build_lob_filter,
    build_user_filter,
    COMPLETED_AUDIT_COUNT_QUERY,
)

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])

connection_manager = SnowflakeConnectionManager()

COMPLETED_AUDIT_COUNT_PAGINATED_QUERY = f"""
WITH audit_base AS (
    SELECT
        a.PYID,
        a.INTAKESOURCESYSTEM,
        a.INVNTRY_TYPE,
        a.LOB,
        a.PLATFORM,
        a.AUDITOR_ID,
        a.AUDITOR_NAME,
        a.AUDITCYCLETIME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXCOMMITDATETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.INTAKESOURCESYSTEM,
        a.INVNTRY_TYPE,
        a.LOB,
        a.PLATFORM,
        a.AUDITOR_ID,
        a.AUDITOR_NAME,
        a.AUDITCYCLETIME,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS completion_status,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN UPPER(TRIM(a.PYSTATUSWORK)) = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN UPPER(TRIM(a.PYSTATUSWORK)) = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE UPPER(TRIM(a.PYSTATUSWORK)) IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID, INTAKESOURCESYSTEM, INVNTRY_TYPE, LOB, PLATFORM,
        AUDITOR_ID, AUDITOR_NAME, AUDITCYCLETIME, AUDIT_MONTH, AUDIT_YEAR,
        completion_status, completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID, INTAKESOURCESYSTEM, INVNTRY_TYPE, LOB, PLATFORM,
        AUDITOR_ID, AUDITOR_NAME, AUDITCYCLETIME, AUDIT_MONTH, AUDIT_YEAR,
        completion_status, completion_ts
    FROM completion_event
    WHERE 1 = 1
      {{audit_period_filter}}
      {{lob_filter}}
      {{user_filter}}
)
SELECT
    PYID AS work_item,
    COALESCE(INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(AUDITCYCLETIME::VARCHAR, '0') AS audit_cycle_time,
    CASE
        WHEN completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(completion_status, 'N/A')
    END AS audit_resolved_status,
    COALESCE(INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(completion_ts, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(AUDITOR_ID, 'N/A') AS auditor_id,
    COALESCE(AUDITOR_NAME, 'N/A') AS auditor_name,
    COALESCE(PLATFORM, 'N/A') AS platform_source_system,
    COALESCE(AUDIT_MONTH, 'N/A') AS audit_month,
    COALESCE(AUDIT_YEAR, 'N/A') AS audit_year
FROM filtered_completion
ORDER BY completion_ts DESC
LIMIT {{page_size}} OFFSET {{offset}}
"""

DEFAULT_COMPLETE_AUDIT_ORDER_BY = "completion_ts DESC"

DISPLAY_COMPLETE_AUDIT_RESOLVED_STATUS_SQL = """
CASE
    WHEN completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
    WHEN completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
    ELSE COALESCE(completion_status, 'N/A')
END
"""
DISPLAY_COMPLETE_AUDIT_RESOLVED_DATE_SQL = "DATE(completion_ts)"

SORTABLE_COMPLETE_AUDIT_COLUMNS = {
    "work_item": "PYID",
    "worktype_category": "COALESCE(INTAKESOURCESYSTEM, 'N/A')",
    "audit_cycle_time": "COALESCE(AUDITCYCLETIME, 0)",
    "audit_resolved_status": DISPLAY_COMPLETE_AUDIT_RESOLVED_STATUS_SQL,
    "inventory_type": "COALESCE(INVNTRY_TYPE, 'N/A')",
    "lob": "COALESCE(LOB, 'N/A')",
    "audit_resolved_date": DISPLAY_COMPLETE_AUDIT_RESOLVED_DATE_SQL,
    "auditor_name": "COALESCE(AUDITOR_NAME, 'N/A')",
    "platform_source_system": "COALESCE(PLATFORM, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_COMPLETE_AUDIT_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_COMPLETE_AUDIT_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid FL Auditor complete audit sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_COMPLETE_AUDIT_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid FL Auditor complete audit sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_COMPLETE_AUDIT_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "audit_resolved_date":
        tie_breakers.append("completion_ts DESC")
    if normalized_sort_by != "work_item":
        tie_breakers.append("PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_complete_audit_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_COMPLETE_AUDIT_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )


@router.post(
    "/complete-audit-count-drilldown",
    response_model=FLAuditorCompleteAuditDrilldownResponse,
    summary="Get FL Auditor Complete Audit Count Drilldown",
    description="""
Retrieve paginated drilldown data for FL Auditor complete audit count metric.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **page** (optional): Page number (default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item**: Work Item ID (PYID starting with 'AUD')
- **worktype_category**: Worktype Category (INTAKESOURCESYSTEM)
- **audit_cycle_time**: Audit Cycle Time in hh:mm:ss format
- **audit_resolved_status**: Audit Resolved Status
- **inventory_type**: Inventory Type (GB, CB)
- **lob**: Line of Business
- **audit_resolved_date**: Audit Resolved Date (MM/DD/YYYY)
- **auditor_id**: FL Auditor ID
- **auditor_name**: FL Auditor Name
- **platform_source_system**: Platform - Source System

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (completed audits)
- COB_AI_USER_PROFILE (user information)
- COB_AI_INVNTRY_PROFILE (cycle time)
""",
)
async def get_complete_audit_count_drilldown(request: FLAuditorCompleteAuditDrilldownRequest) -> FLAuditorCompleteAuditDrilldownResponse:
    """Complete audit count drilldown with session-based cache reuse."""

    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Build filters
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="completion_ts",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(request.lob)
        user_filter = build_user_filter(request.user_id)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached complete_audit_count from header KPIs
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict and hash for cache key
                filters = {
                    'user_id': request.user_id,
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                }
                filters_hash = build_filters_hash(**filters)
                
                # Get cached complete audit count from header KPIs
                cache_key = f"session:{session_id}:{filters_hash}:complete_audit_count"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract COMPLETED_AUDIT_COUNT from cached query result
                    total_records = int(cached_metric[0].get("COMPLETED_AUDIT_COUNT", 0))
                    logger.info(f"Reused cached complete audit count: {total_records} (from header KPIs)")
                else:
                    logger.info(f"Cache miss for complete_audit_count, running COUNT query")
                    # Fall back to COUNT query
                    count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
                        audit_period_filter=audit_period_filter,
                        lob_filter=lob_filter,
                        user_filter=user_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("COMPLETED_AUDIT_COUNT", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Cache reuse failed: {str(e)}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
                    audit_period_filter=audit_period_filter,
                    lob_filter=lob_filter,
                    user_filter=user_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("COMPLETED_AUDIT_COUNT", 0) if count_result else 0
        else:
            # No session_id or Redis disabled - run COUNT query
            count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                user_filter=user_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("COMPLETED_AUDIT_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Get paginated data
        data_query = COMPLETED_AUDIT_COUNT_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter,
            page_size=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_complete_audit_query(
            data_query,
            request.sort_by,
            request.sort_direction,
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        completed_audit_records = [
            FLAuditorCompleteAuditRecord(
                work_item=record.get("WORK_ITEM") or "N/A",
                worktype_category=record.get("WORKTYPE_CATEGORY") or "N/A",
                audit_cycle_time=format_cycle_time(record.get("AUDIT_CYCLE_TIME")),
                audit_resolved_status=record.get("AUDIT_RESOLVED_STATUS") or "N/A",
                inventory_type=record.get("INVENTORY_TYPE") or "N/A",
                lob=record.get("LOB") or "N/A",
                audit_resolved_date=record.get("AUDIT_RESOLVED_DATE") or "N/A",
                auditor_name=record.get("AUDITOR_NAME") or "N/A",
                platform_source_system=record.get("PLATFORM_SOURCE_SYSTEM") or "N/A",
                audit_month=record.get("AUDIT_MONTH") or "N/A",
                audit_year=record.get("AUDIT_YEAR") or "N/A",
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the audit work item (PYID starting with 'AUD')",
            "worktype_category": "Category of work type being audited (INTAKESOURCESYSTEM)",
            "audit_cycle_time": "Cycle time from COB_AI_INVNTRY_PROFILE.CYCLE_TIME in hh:mm:ss format",
            "audit_resolved_status": "Status of the audit resolution (PYSTATUSWORK)",
            "inventory_type": "Type of inventory classification (INVNTRY_TYPE)",
            "lob": "Line of Business classification (Medicaid, Medicare, Commercial)",
            "audit_resolved_date": "Date when the audit was resolved (PYRESOLVEDTIMESTAMP)",
            "auditor_name": "Name of the FL Auditor who completed the audit (USERNAME from COB_AI_USER_PROFILE)",
            "platform_source_system": "Platform or source system where the audit was processed (PLATFORM)"
        }

        return FLAuditorCompleteAuditDrilldownResponse(
            status="success",
            screen_id="complete_audit_count_fl_auditor",
            user_id=request.user_id,
            page=page_response,
            records=completed_audit_records,
            message="FL Auditor completed audit count records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"FL Auditor complete audit count drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return FLAuditorCompleteAuditDrilldownResponse(
            status="error",
            screen_id="complete_audit_count_fl_auditor",
            user_id=request.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve FL Auditor completed audit count records: {str(e)}"
        )


@router.post(
    "/complete-audit-count-drilldown/download-excel",
    summary="Download FL Auditor Complete Audit Count Drilldown as Excel",
    description="""
Download complete FL Auditor audit count drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values

**Returns:** Excel file (.xlsx) with all completed audit count records
""",
)
async def download_complete_audit_count_drilldown_excel(
    request: FLAuditorBaseRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob = request.lob
        
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="completion_ts",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(lob)
        user_filter = build_user_filter(user_id)
        
        engine = connection_manager.get_engine()
            
        # Query with high limit for download (no pagination needed)
        download_query = COMPLETED_AUDIT_COUNT_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter,
            page_size=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "FL Auditor Completed Audits"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Audit Cycle Time",
            "Audit Status",
            "Inventory Type",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Auditor Name",
            "Platform",
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM", "") or "N/A"))
            ws.cell(row=row_num, column=2, value=str(row.get("WORKTYPE_CATEGORY", "") or "N/A"))
            ws.cell(row=row_num, column=3, value=format_cycle_time(row.get("AUDIT_CYCLE_TIME")) if row.get("AUDIT_CYCLE_TIME") else "00:00:00")
            ws.cell(row=row_num, column=4, value=str(row.get("AUDIT_RESOLVED_STATUS", "") or "N/A"))
            ws.cell(row=row_num, column=5, value=str(row.get("INVENTORY_TYPE", "") or "N/A"))
            ws.cell(row=row_num, column=6, value=str(row.get("LOB", "") or "N/A"))
            ws.cell(row=row_num, column=7, value=str(row.get("AUDIT_RESOLVED_DATE", "") or "N/A"))
            ws.cell(row=row_num, column=8, value=str(row.get("AUDIT_MONTH", "") or "N/A"))
            ws.cell(row=row_num, column=9, value=(
                int(row["AUDIT_YEAR"]) if row.get("AUDIT_YEAR") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=10, value=str(row.get("AUDITOR_NAME", "") or "N/A"))
            ws.cell(row=row_num, column=11, value=str(row.get("PLATFORM_SOURCE_SYSTEM", "") or "N/A"))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"fl_auditor_completed_audit_count_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for FL Auditor completed audit count drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
