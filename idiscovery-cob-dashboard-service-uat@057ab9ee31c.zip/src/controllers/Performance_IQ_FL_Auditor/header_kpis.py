import logging
from typing import Optional, List
import asyncio
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import FLAuditorBaseRequest, FLAuditorHeaderKPIsResponse, AuditPeriod
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])

connection_manager = SnowflakeConnectionManager()

# Complete Audit Count - uses AUDITOR_ID field for FL Auditor
COMPLETED_AUDIT_COUNT_QUERY = f"""
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXCOMMITDATETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
    {{audit_period_filter}}
    {{lob_filter}}
    {{user_filter}}
)
SELECT
    COUNT(DISTINCT PYID) AS COMPLETED_AUDIT_COUNT
FROM filtered_completion
"""

# Work Items Completed - uses PYRESOLVEDUSERID
WORK_ITEMS_COMPLETED_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{user_filter_resolved}}
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM filtered_inventory
"""

# Audit Cycle Time - uses AUDITOR_ID field
AUDIT_CYCLE_TIME_QUERY = f"""
WITH audit_base AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        a.PXCOMMITDATETIME,
        a.AUDITCYCLETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
),
completion_candidates AS (
    SELECT
        a.PYID,
        a.AUDITOR_ID,
        a.LOB,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        a.PYSTATUSWORK,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM audit_base a
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        PYID,
        AUDITOR_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        completion_status,
        completion_ts
    FROM completion_event
    WHERE 1 = 1
      {{audit_period_filter}}
      {{lob_filter}}
      {{user_filter}}
),
first_positive_cycle_ts AS (
    SELECT
        c.PYID,
        c.AUDITOR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts,
        MIN(a.PXCOMMITDATETIME) AS cycle_ts
    FROM filtered_completion c
    JOIN audit_base a
        ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_ts
      AND a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        c.PYID,
        c.AUDITOR_ID,
        c.LOB,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts
),
cycle_time_at_first_positive_ts AS (
    SELECT
        f.PYID,
        f.completion_ts,
        f.cycle_ts,
        MAX(a.AUDITCYCLETIME) AS AUDITCYCLETIME
    FROM first_positive_cycle_ts f
    JOIN audit_base a
        ON a.PYID = f.PYID
       AND a.PXCOMMITDATETIME = f.cycle_ts
    WHERE a.AUDITCYCLETIME IS NOT NULL
      AND a.AUDITCYCLETIME > 0
    GROUP BY
        f.PYID,
        f.completion_ts,
        f.cycle_ts
)
SELECT
    COUNT(*) AS TOTAL_RESOLVED_AUDITS,
    ROUND(AVG(AUDITCYCLETIME / 60.0), 2) AS AVG_AUDIT_CYCLE_TIME_MINUTES
FROM cycle_time_at_first_positive_ts
"""

# ATA Audit Score - uses AUDIT_SUBJECT_ID field
ATA_AUDIT_SCORE_QUERY = f"""
WITH ata_filtered_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME,
        PXCREATEDATETIME,
        AUDIT_SUBJECT_ID,
        ISATACASE,
        AUDIT_YEAR,
        AUDIT_MONTH,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE UPPER(PYID) LIKE 'ATA%'
      AND ISATACASE = 'Y'
      AND REGEXP_LIKE(TRIM(AUDIT_SCORE), '^-?[0-9]+(\\.[0-9]+)?$')
      AND AUDIT_SCORE IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{user_filter_ata}}
),

first_feedback_review AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW'
    GROUP BY PYID
),

first_resolved AS (
    SELECT
        PYID,
        MIN(PXCOMMITDATETIME) AS completion_timestamp
    FROM ata_filtered_records
    WHERE PYSTATUSWORK = 'RESOLVED-COMPLETED'
    GROUP BY PYID
),

completion_points AS (
    SELECT
        PYID,
        completion_timestamp,
        'OPEN-FEEDBACKREVIEW' AS completion_type
    FROM first_feedback_review

    UNION ALL

    SELECT
        r.PYID,
        r.completion_timestamp,
        'RESOLVED-COMPLETED' AS completion_type
    FROM first_resolved r
    LEFT JOIN first_feedback_review f
        ON r.PYID = f.PYID
    WHERE f.PYID IS NULL
),

ata_scores_at_completion AS (
    SELECT
        a.PYID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        c.completion_timestamp,
        c.completion_type,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME
        ) AS rn
    FROM ata_filtered_records a
    JOIN completion_points c
        ON a.PYID = c.PYID
    WHERE a.PXCOMMITDATETIME >= c.completion_timestamp
),

ata_final_records AS (
    SELECT
        PYID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        completion_timestamp,
        completion_type
    FROM ata_scores_at_completion
    WHERE rn = 1
)
SELECT 
    ROUND(AVG(TO_NUMBER(TRIM(AUDIT_SCORE))), 2) AS AVG_ATA_SCORE,
    COUNT(DISTINCT PYID) AS total_ata_cases,
    COUNT(CASE WHEN UPPER(TRIM(TARGET_AUDIT)) = 'YES' THEN 1 END) AS target_audit_count
FROM ata_final_records
"""

# Rebuttals - uses AUDITOR_ID field (AUD cases with REBUTTALFLAG='Y')
REBUTTALS_QUERY = f"""
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        AUDITOR_ID
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        {{audit_period_filter}}
        {{lob_filter}}
        {{user_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
        AND REBUTTALOUTCOME IS NOT NULL
        AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
        AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS
FROM audit_filtered af
INNER JOIN eligible_rebuttal_line_items rd
    ON af.PYID = rd.CASEID
"""


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_date_filter_created(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for PXCREATEDATETIME (used for ATA cases)"""
    if start_date and end_date:
        return f"AND PXCREATEDATETIME >= '{start_date}' AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND PXCREATEDATETIME >= '{start_date}'"
    elif end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_rebuttal_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "pxcreatedatetime") -> str:
    """Build date filter for rebuttal queries using pxcreatedatetime as default."""
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_user_filter(user_id: str) -> str:
    """Build filter for FL Auditor (AUDITOR_ID)"""
    return f"AND AUDITOR_ID = '{user_id}'"

def build_user_filter_resolved(user_id: str) -> str:
    """Build filter for FL Auditor (PYRESOLVEDUSERID)"""
    return f"AND PYRESOLVEDUSERID = '{user_id}'"

def build_user_filter_ata(user_id: str) -> str:
    """Build filter for ATA cases (AUDIT_SUBJECT_ID - the auditor being reviewed)"""
    return f"AND AUDIT_SUBJECT_ID = '{user_id}'"


def format_number(value: int) -> str:
    """Format number with comma separators."""
    return f"{value:,}"


def format_cycle_time_mins_secs(minutes: float) -> str:
    """Format cycle time from decimal minutes to 'X mins. YY secs' format.
    
    Args:
        minutes: Time in decimal minutes (e.g., 2.06)
    
    Returns:
        Formatted string like '2 mins. 06 secs'
    """
    if minutes is None or minutes < 0:
        return "N/A"
    
    whole_minutes = int(minutes)
    seconds = int((minutes - whole_minutes) * 60)
    
    return f"{whole_minutes} mins. {seconds:02d} secs"


def calculate_ata_score_bubble(ata_score_str: str) -> str:
    """Calculate bubble status for ATA audit score.
    
    Rating Scale:
    - Exceptional: 100%
    - Exceeds: 99% - 99.99%
    - Meets: 98% - 98.99%
    - Approaching: 95.99% - 97.99%
    - Poor: Below 95.99%
    - N/A: if score is N/A, invalid, or zero
    """
    if ata_score_str == "N/A":
        return "N/A"
    
    try:
        # Remove % sign and convert to float
        score_value = float(ata_score_str.replace("%", "").strip())
        
        # Check if score is zero (handles all zero formats: 0, 0.0, 0.00, etc.)
        if score_value == 0.0:
            return "N/A"
        
        if score_value >= 100.0:
            return "Exceptional"
        elif score_value >= 99.0:
            return "Exceeds"
        elif score_value >= 98.0:
            return "Meets"
        elif score_value >= 95.99:
            return "Approaching"
        else:
            return "Poor"
    except (ValueError, AttributeError):
        return "N/A"

def build_audit_period_filter(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    audit_periods=None,
    timestamp_column: str = "completion_ts",
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    valid_periods = []
    seen_periods = set()
 
    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""
 
        if not month_value or not year_value:
            continue
 
        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue
 
        seen_periods.add(key)
        valid_periods.append((month_value, year_value))
 
    if valid_periods:
        period_conditions = [
            f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
            for month, year in valid_periods
        ]
        return "AND (" + " OR ".join(period_conditions) + ")"
 
    if start_date and end_date:
        return (
            f"AND {timestamp_column} >= '{start_date}' "
            f"AND {timestamp_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {timestamp_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {timestamp_column} < DATEADD(day, 1, '{end_date}'::DATE)"
 
    return ""


@router.post(
    "/header-kpis",
    response_model=FLAuditorHeaderKPIsResponse,
    summary="Get FL Auditor Header KPIs",
    description="""
Retrieve summary KPIs for FL Auditor dashboard header section.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter

**Response Fields:**
- **rebuttal_count**: Total rebuttal count
- **complete_audit_count**: Total completed audits
- **ata_audit_score**: ATA audit score percentage with status bubble
- **audit_cycle_time**: Average audit cycle time with status bubble
- **work_items_completed**: Total work items completed

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (audits)
- COB_AI_USER_PROFILE (user relationships)
""",
)
async def get_fl_auditor_header_kpis(request: FLAuditorBaseRequest) -> FLAuditorHeaderKPIsResponse:
    """Header KPIs endpoint with session-based metric-level caching."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_fl_auditor_header_kpis_query(request)


async def execute_fl_auditor_header_kpis_query(request: FLAuditorBaseRequest) -> FLAuditorHeaderKPIsResponse:
    """Execute header KPIs query logic with metric-level caching."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        user_filter = build_user_filter(request.user_id)
        user_filter_resolved = build_user_filter_resolved(request.user_id)
        user_filter_ata = build_user_filter_ata(request.user_id)
        rebuttal_date_filter = build_rebuttal_date_filter(request.start_date, request.end_date)
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="completion_ts",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        audit_period_create_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        
        engine = connection_manager.get_engine()

        # Format queries
        audit_count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter
        )
        work_items_query = WORK_ITEMS_COMPLETED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            user_filter_resolved=user_filter_resolved
        )
        audit_cycle_time_query = AUDIT_CYCLE_TIME_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter
        )
        ata_audit_score_query = ATA_AUDIT_SCORE_QUERY.format(
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            user_filter_ata=user_filter_ata
        )
        rebuttals_query = REBUTTALS_QUERY.format(
            audit_period_filter=audit_period_create_filter,
            lob_filter=lob_filter,
            user_filter=user_filter
        )
        
        # Get session_id for caching
        session_id = getattr(request, "session_id", None)
        
        # Build filters dict for cache isolation
        filters = {
            'user_id': request.user_id,
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
            'audit_periods': [
                {'month': period.month, 'year': period.year}
                for period in (request.audit_periods or [])
            ],
        }
        
        # Define async fetch functions for each metric
        async def fetch_audit_count():
            return await engine.execute_query_async(audit_count_query, limit=1)
        
        async def fetch_work_items():
            return await engine.execute_query_async(work_items_query, limit=1)
        
        async def fetch_audit_cycle_time():
            return await engine.execute_query_async(audit_cycle_time_query, limit=1)
        
        async def fetch_ata_score():
            return await engine.execute_query_async(ata_audit_score_query, limit=1)
        
        async def fetch_rebuttals():
            return await engine.execute_query_async(rebuttals_query, limit=1)
        
        # Get or fetch cached metrics (only cache if session_id provided)
        if session_id:
            # Execute all metric fetches in parallel using asyncio.gather
            (audit_count_records, work_items_records, audit_cycle_time_records,
             ata_audit_score_records, rebuttals_records) = await asyncio.gather(
                metric_cache_service.get_or_fetch_metric(
                    fetch_func=fetch_audit_count,
                    session_id=session_id,
                    metric_name="complete_audit_count",
                    filters=filters
                ),
                metric_cache_service.get_or_fetch_metric(
                    fetch_func=fetch_work_items,
                    session_id=session_id,
                    metric_name="work_items_completed",
                    filters=filters
                ),
                metric_cache_service.get_or_fetch_metric(
                    fetch_func=fetch_audit_cycle_time,
                    session_id=session_id,
                    metric_name="audit_cycle_time",
                    filters=filters
                ),
                metric_cache_service.get_or_fetch_metric(
                    fetch_func=fetch_ata_score,
                    session_id=session_id,
                    metric_name="ata_audit_score",
                    filters=filters
                ),
                metric_cache_service.get_or_fetch_metric(
                    fetch_func=fetch_rebuttals,
                    session_id=session_id,
                    metric_name="rebuttal_count",
                    filters=filters
                )
            )
        else:
            # No session_id - execute in parallel without caching
            (audit_count_records, work_items_records, audit_cycle_time_records,
             ata_audit_score_records, rebuttals_records) = await asyncio.gather(
                fetch_audit_count(),
                fetch_work_items(),
                fetch_audit_cycle_time(),
                fetch_ata_score(),
                fetch_rebuttals()
            )

        # Extract complete audit count
        complete_audit_count_value = int(audit_count_records[0].get("COMPLETED_AUDIT_COUNT", 0)) if audit_count_records else 0
        complete_audit_count = format_number(complete_audit_count_value) if complete_audit_count_value >= 0 else "N/A"

        # Extract work items completed
        work_items_completed_value = int(work_items_records[0].get("TOTAL_COUNT", 0)) if work_items_records else 0
        work_items_completed = format_number(work_items_completed_value) if work_items_completed_value >= 0 else "N/A"
        
        # Extract audit cycle time
        if audit_cycle_time_records:
            avg_cycle_time_value = audit_cycle_time_records[0].get("AVG_AUDIT_CYCLE_TIME_MINUTES")
            if avg_cycle_time_value is not None:
                avg_cycle_time_minutes = float(avg_cycle_time_value)
                audit_cycle_time = format_cycle_time_mins_secs(avg_cycle_time_minutes)
            else:
                audit_cycle_time = "0"
        else:
            audit_cycle_time = "N/A"
        
        # Extract ATA audit score
        if ata_audit_score_records:
            avg_ata_score_value = ata_audit_score_records[0].get("AVG_ATA_SCORE")
            if avg_ata_score_value is not None:
                avg_ata_score = float(avg_ata_score_value)
                ata_audit_score = f"{avg_ata_score:.2f}%"
            else:
                ata_audit_score = "0.00%"
        else:
            ata_audit_score = "N/A"
        
        # Calculate bubble statuses
        ata_audit_score_bubble = calculate_ata_score_bubble(ata_audit_score)
        
        # Extract rebuttals count
        if rebuttals_records and rebuttals_records[0].get("REBUTTAL_COUNT") is not None:
            rebuttal_count_value = int(rebuttals_records[0].get("REBUTTAL_COUNT", 0))
            rebuttal_count = format_number(rebuttal_count_value)
        else:
            rebuttal_count = "N/A"

        tooltips = {
            "rebuttal_count": "Number of cases where auditor submitted a rebuttal",
            "complete_audit_count": "Total number of completed audits (PYID starting with 'AUD')",
            "ata_audit_score": "ATA audit score percentage - measures audit quality",
            "ata_audit_score_bubble": "Quality rating: Exceptional (100%), Exceeds (99-99.99%), Meets (98-98.99%), Approaching (95.99-97.99%), Poor (<95.99%)",
            "audit_cycle_time": "Average time to complete an audit",
            "work_items_completed": "Total number of work items completed in the selected date range"
        }

        # Build cache metadata if session_id exists
        cache_metadata = None
        if session_id and config.REDIS_ENABLED:
            from schema.models import CacheMetadata
            cache_metadata = CacheMetadata(
                session_id=session_id,
                cache_hit=False  # First call is always a cache miss for metric-level caching
            )

        return FLAuditorHeaderKPIsResponse(
            status="success",
            rebuttal_count=rebuttal_count,
            complete_audit_count=complete_audit_count,
            ata_audit_score=ata_audit_score,
            ata_audit_score_bubble=ata_audit_score_bubble,
            audit_cycle_time=audit_cycle_time,
            work_items_completed=work_items_completed,
            message="FL Auditor header KPIs retrieved successfully",
            tooltips=tooltips,
            cache_metadata=cache_metadata
        )

    except Exception as e:
        logger.error(f"FL Auditor header KPIs query error: {type(e).__name__}: {str(e)}")
        return FLAuditorHeaderKPIsResponse(
            status="error",
            rebuttal_count="N/A",
            complete_audit_count="N/A",
            ata_audit_score="N/A",
            ata_audit_score_bubble="N/A",
            audit_cycle_time="N/A",
            work_items_completed="N/A",
            message=f"Failed to retrieve FL Auditor header KPIs: {str(e)}"
        )
