from fastapi import APIRouter, HTTPException
from typing import Optional, List
from schema import FLAuditorBaseRequest, FLAuditorLOBListResponse
from utils import cache_manager
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
import logging
import asyncio

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])

connection_manager = SnowflakeConnectionManager()

# Query to get LOBs for FL Auditor view - focuses on auditor's own data
FL_AUDITOR_LOB_QUERY = f"""
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    {{user_filter}}
UNION
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
WHERE 1=1
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
    {{auditor_filter}}
ORDER BY LOB
"""


def build_user_filter(user_id: str) -> str:
    """Build user filter for FL Auditor to see only their own LOBs."""
    if user_id:
        return f"AND PYRESOLVEDUSERID = '{user_id}'"
    return ""

def build_auditor_filter(user_id: str) -> str:
    if user_id:
        return f"AND AUDITOR_ID = '{user_id}'"
    return ""

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for inventory and audit tables."""
    if start_date and end_date:
        return (
            f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' "
            f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


@router.post(
    "/lobs",
    response_model=FLAuditorLOBListResponse,
    summary="Get List of LOBs for FL Auditor View",
    description="""
Returns LOBs available for FL Auditor with optional date filtering.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format to filter LOBs by date range
- **end_date** (optional): End date in YYYY-MM-DD format to filter LOBs by date range
- **lob** (optional): List of Line of Business values (not used for filtering LOB list)

**Response:**
- **lobs**: List of distinct LOBs available for the FL Auditor based on the filters applied

**FL Auditor API Behavior:**
- **User filtering**: Returns only LOBs from the logged-in auditor's own work items
- **Date filtering**: Optional date range filtering for LOB availability

**Data Sources:**
- COB_AI_INVNTRY_PROFILE (work items resolved)

**Caching:** Results are cached for 24 hours based on the filter combination.
""",
)
async def get_fl_auditor_lobs(request: FLAuditorBaseRequest) -> FLAuditorLOBListResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    # Build cache key based on all filter parameters
    cache_key = cache_manager.build_key(
        "fl_auditor_lobs",
        user_id=request.user_id
    )

    async def fetch_lobs():
        try:
            # Build filters
            user_filter = build_user_filter(request.user_id)
            auditor_filter = build_auditor_filter(request.user_id)
            # date_filter = build_date_filter(request.start_date, request.end_date)

            # Format query with filters
            query = FL_AUDITOR_LOB_QUERY.format(
                user_filter=user_filter,
                auditor_filter=auditor_filter
            )
            
            engine = connection_manager.get_engine()
            records = await engine.execute_query_async(query)
            lobs = [r.get("LOB") for r in records if r.get("LOB")]

            return {
                "status": "success",
                "lobs": lobs,
                "message": "FL Auditor LOBs retrieved successfully",
                "service": "idiscovery-cob-dashboard-service"
            }
        except Exception as e:
            logger.error(f"Failed to retrieve FL Auditor LOBs: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to retrieve FL Auditor LOBs: {str(e)}")

    result = await cache_manager.get_or_fetch(cache_key, fetch_lobs, ttl=METRIC_CACHE_TTL)
    return FLAuditorLOBListResponse(**result)
