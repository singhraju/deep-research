import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from schema import (
    FLAuditorRebuttalDrilldownRequest,
    FLAuditorRebuttalDrilldownResponse,
    FLAuditorRebuttalRecord,
    PageResponse,
    FLAuditorBaseRequest,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, CACHE_FULL_DATASET_LIMIT
import config
import math
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from services.session_cache_orchestrator import generate_session_id
from controllers.Performance_IQ_FL_Auditor.rebuttals import REBUTTALS_QUERY
from controllers.Performance_IQ_FL_Auditor.header_kpis import (
    build_lob_filter,
    build_user_filter,
    build_audit_period_filter,
)

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        cleaned = str(date_str)
        if "T" in cleaned:
            cleaned = cleaned.split("T")[0]
        elif " " in cleaned:
            cleaned = cleaned.split(" ")[0]
        date_obj = datetime.strptime(cleaned, "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])

connection_manager = SnowflakeConnectionManager()

REBUTTAL_PAGINATED_QUERY = f"""
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        INTAKESOURCESYSTEM,
        PLATFORM,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXCOMMITDATETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
),
latest_rebuttal_cases AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        AUDITOR_ID,
        AUDITOR_NAME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        INTAKESOURCESYSTEM,
        PLATFORM,
        PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM audit_base
),
rebuttal_population AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_NAME,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        INTAKESOURCESYSTEM,
        PLATFORM
    FROM latest_rebuttal_cases
    WHERE rn = 1
      AND REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{user_filter}}
),
completion_candidates AS (
    SELECT
        rp.PYID,
        rp.AUDITOR_ID,
        rp.AUDITOR_NAME,
        rp.LOB,
        rp.AUDIT_MONTH,
        rp.AUDIT_YEAR,
        rp.INTAKESOURCESYSTEM,
        rp.PLATFORM,
        a.PYSTATUSWORK AS completion_status,
        a.PXCOMMITDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY rp.PYID
            ORDER BY
                CASE
                    WHEN a.PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN a.PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                a.PXCOMMITDATETIME ASC
        ) AS rn
    FROM rebuttal_population rp
    INNER JOIN audit_base a
        ON rp.PYID = a.PYID
    WHERE a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        AUDITOR_ID,
        AUDITOR_NAME,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        INTAKESOURCESYSTEM,
        PLATFORM,
        completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM deduped_audit_activity
    WHERE rn = 1
      AND REBUTTALOUTCOME IS NOT NULL
      AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
      AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    ce.PYID AS WORK_ITEM_ID,
    COALESCE(ce.INTAKESOURCESYSTEM, 'N/A') AS WORKTYPE_CATEGORY,
    CASE
        WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
        WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
        ELSE COALESCE(ce.completion_status, 'N/A')
    END AS OUTCOME_STATUS,
    COALESCE(ce.LOB, 'N/A') AS LOB,
    ce.completion_ts AS RESOLVED_DATE,
    COALESCE(ce.AUDITOR_ID, 'N/A') AS DOMAIN_ID,
    COALESCE(ce.AUDITOR_NAME, 'N/A') AS ASSOCIATE_NAME,
    COALESCE(ce.PLATFORM, 'N/A') AS PLATFORM_SOURCE_SYSTEM,
    COALESCE(aa.ERRORCATEGORYTYPE, 'N/A') AS ERROR_TYPE,
    COALESCE(aa.ERRORCATEGORY, 'N/A') AS ERROR_CATEGORY,
    COALESCE(aa.REBUTTALOUTCOME, 'N/A') AS REBUTTAL_OUTCOME,
    COALESCE(ce.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(ce.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM completion_event ce
INNER JOIN eligible_rebuttal_line_items aa
    ON ce.PYID = aa.CASEID
ORDER BY ce.completion_ts DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

DEFAULT_REBUTTAL_ORDER_BY = "ce.completion_ts DESC"
DISPLAY_REBUTTAL_RESOLVED_DATE_SQL = "DATE(ce.completion_ts)"

DISPLAY_REBUTTAL_OUTCOME_STATUS_SQL = """
CASE
    WHEN ce.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
    WHEN ce.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
    ELSE COALESCE(ce.completion_status, 'N/A')
END
"""

SORTABLE_REBUTTAL_COLUMNS = {
    "work_item_id": "ce.PYID",
    "worktype_category": "COALESCE(ce.INTAKESOURCESYSTEM, 'N/A')",
    "outcome_status": DISPLAY_REBUTTAL_OUTCOME_STATUS_SQL,
    "lob": "COALESCE(ce.LOB, 'N/A')",
    "resolved_date": DISPLAY_REBUTTAL_RESOLVED_DATE_SQL,
    "domain_id": "COALESCE(ce.AUDITOR_ID, 'N/A')",
    "associate_name": "COALESCE(ce.AUDITOR_NAME, 'N/A')",
    "platform_source_system": "COALESCE(ce.PLATFORM, 'N/A')",
    "error_type": "COALESCE(aa.ERRORCATEGORYTYPE, 'N/A')",
    "error_category": "COALESCE(aa.ERRORCATEGORY, 'N/A')",
    "rebuttal_outcome": "COALESCE(aa.REBUTTALOUTCOME, 'N/A')",
    "audit_month": "COALESCE(ce.AUDIT_MONTH, 'N/A')",
    "audit_year": "COALESCE(ce.AUDIT_YEAR, 'N/A')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_REBUTTAL_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_REBUTTAL_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid FL Auditor rebuttal sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_REBUTTAL_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid FL Auditor rebuttal sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_REBUTTAL_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "resolved_date":
        tie_breakers.append("ce.completion_ts DESC")
    if normalized_sort_by != "work_item_id":
        tie_breakers.append("ce.PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_rebuttal_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_REBUTTAL_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )



@router.post(
    "/rebuttal-count-drilldown",
    response_model=FLAuditorRebuttalDrilldownResponse,
    summary="Get FL Auditor Rebuttal Count Drilldown",
    description="""
Retrieve paginated drilldown data for FL Auditor rebuttal count metric.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **page** (optional): Page number (default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item_id**: Unique work item identifier (PYID)
- **worktype_category**: Work type category (INTAKESOURCESYSTEM)
- **outcome_status**: Outcome status (PYSTATUSWORK)
- **lob**: Line of Business
- **resolved_date**: Resolved date (MM/DD/YYYY format)
- **domain_id**: FL Auditor domain ID
- **platform_source_system**: Platform source system (PLATFORM)

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (rebuttal data)
- COB_AI_USER_PROFILE (user information)
""",
)
async def get_rebuttal_count_drilldown(request: FLAuditorRebuttalDrilldownRequest) -> FLAuditorRebuttalDrilldownResponse:
    """Rebuttal count drilldown with session-based cache reuse."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        user_id = request.user_id
        
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(lob)
        user_filter = build_user_filter(user_id)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached rebuttal_count from rebuttals endpoint
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict and hash for cache key
                filters = {
                    'user_id': request.user_id,
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                }
                filters_hash = build_filters_hash(**filters)
                
                # Get cached rebuttal count from rebuttals endpoint
                cache_key = f"session:{session_id}:{filters_hash}:rebuttal_count"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract REBUTTAL_COUNT from cached query result (list format)
                    total_records = int(cached_metric[0].get("REBUTTAL_COUNT", 0))
                    logger.info(f"✅ Reused cached rebuttal count: {total_records} (from rebuttals endpoint)")
                else:
                    logger.info(f"Cache miss for rebuttal_count, running COUNT query")
                    # Fall back to COUNT query
                    count_query = REBUTTALS_QUERY.format(
                        audit_period_filter=audit_period_filter,
                        lob_filter=lob_filter,
                        user_filter=user_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("REBUTTAL_COUNT", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Cache reuse failed: {str(e)}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = REBUTTALS_QUERY.format(
                    audit_period_filter=audit_period_filter,
                    lob_filter=lob_filter,
                    user_filter=user_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("REBUTTAL_COUNT", 0) if count_result else 0
        else:
            # No session_id or Redis disabled - run COUNT query
            count_query = REBUTTALS_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                user_filter=user_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("REBUTTAL_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = REBUTTAL_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_rebuttal_query(
            data_query,
            request.sort_by,
            request.sort_direction,
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        rebuttal_records = [
            FLAuditorRebuttalRecord(
                work_item_id=record.get("WORK_ITEM_ID") or "N/A",
                worktype_category=record.get("WORKTYPE_CATEGORY") or "N/A",
                outcome_status=record.get("OUTCOME_STATUS") or "N/A",
                error_category=record.get("ERROR_CATEGORY") or "N/A",
                error_type=record.get("ERROR_TYPE") or "N/A",
                rebuttal_outcome=record.get("REBUTTAL_OUTCOME") or "N/A",
                lob=record.get("LOB") or "N/A",
                resolved_date=format_date_mmddyyyy(record.get("RESOLVED_DATE")) if record.get("RESOLVED_DATE") else "N/A",
                domain_id=record.get("ASSOCIATE_NAME") or "N/A",
                platform_source_system=record.get("PLATFORM_SOURCE_SYSTEM") or "N/A",
                audit_month=record.get("AUDIT_MONTH") or "N/A",
                audit_year=record.get("AUDIT_YEAR") or "N/A"
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item_id": "Unique identifier for the work item (PYID)",
            "worktype_category": "Work type category or source system",
            "outcome_status": "Outcome status of the rebuttal case",
            "error_category": "Category of error identified in the audit",
            "error_type": "Type of error identified in the audit (ERRORCATEGORYTYPE)",
            "rebuttal_outcome": "Outcome of the rebuttal submission",
            "lob": "Line of Business associated with the work item",
            "resolved_date": "Date when the case was resolved",
            "domain_id": "FL Auditor name",
            "platform_source_system": "Platform or source system where the case was processed"
        }

        return FLAuditorRebuttalDrilldownResponse(
            status="success",
            screen_id="rebuttal_fl_auditor",
            user_id=request.user_id,
            page=page_response,
            records=rebuttal_records,
            message="FL Auditor rebuttal records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"FL Auditor rebuttal count drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return FLAuditorRebuttalDrilldownResponse(
            status="error",
            screen_id="rebuttal_fl_auditor",
            user_id=request.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve FL Auditor rebuttal records: {str(e)}"
        )


@router.post(
    "/rebuttal-count-drilldown/download-excel",
    summary="Download FL Auditor Rebuttal Count Drilldown as Excel",
    description="""
Download complete FL Auditor rebuttal drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values

**Returns:** Excel file (.xlsx) with all rebuttal records
""",
)
async def download_rebuttal_count_drilldown_excel(
    request: FLAuditorBaseRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob = request.lob
        
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        lob_filter = build_lob_filter(lob)
        user_filter = build_user_filter(user_id)
        
        engine = connection_manager.get_engine()
        
        # Query with high limit for download (no pagination needed)
        download_query = REBUTTAL_PAGINATED_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter,
            limit=CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "FL Auditor Rebuttals"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Error Type",
            "Error Category",
            "Rebuttal Outcome",
            "Status",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Auditor Name",
            "Platform"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM_ID", "") or "N/A"))
            ws.cell(row=row_num, column=2, value=str(row.get("WORKTYPE_CATEGORY", "") or "N/A"))
            ws.cell(row=row_num, column=3, value=str(row.get("ERROR_TYPE", "") or "N/A"))
            ws.cell(row=row_num, column=4, value=str(row.get("ERROR_CATEGORY", "") or "N/A"))
            ws.cell(row=row_num, column=5, value=str(row.get("REBUTTAL_OUTCOME", "") or "N/A"))
            ws.cell(row=row_num, column=6, value=str(row.get("OUTCOME_STATUS", "") or "N/A"))
            ws.cell(row=row_num, column=7, value=str(row.get("LOB", "") or "N/A"))
            ws.cell(row=row_num, column=8, value=format_date_mmddyyyy(str(row.get("RESOLVED_DATE", ""))) if row.get("RESOLVED_DATE") else "N/A")
            ws.cell(row=row_num, column=9, value=str(row.get("AUDIT_MONTH", "") or "N/A"))
            ws.cell(row=row_num, column=10, value=(
                int(row["AUDIT_YEAR"]) if row.get("AUDIT_YEAR") not in (None, "", "N/A") else ""
            ))
            ws.cell(row=row_num, column=11, value=str(row.get("ASSOCIATE_NAME", "") or "N/A"))
            ws.cell(row=row_num, column=12, value=str(row.get("PLATFORM_SOURCE_SYSTEM", "") or "N/A"))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"fl_auditor_rebuttal_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for FL Auditor rebuttal drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
