import logging
from typing import Optional, List, Dict, Any
import asyncio
from datetime import datetime
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import FLAuditorBaseRequest, FLAuditorRebuttalsResponse, AuditPeriod
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from services.session_cache_orchestrator import generate_session_id
from controllers.Performance_IQ_FL_Auditor.header_kpis import (
    build_lob_filter,
    build_user_filter,
    build_audit_period_filter,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])

connection_manager = SnowflakeConnectionManager()

REBUTTALS_QUERY = f"""
WITH audit_base AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        AUDITOR_ID
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        {{audit_period_filter}}
        {{lob_filter}}
        {{user_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
        AND REBUTTALOUTCOME IS NOT NULL
        AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
        AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS
FROM audit_filtered af
INNER JOIN eligible_rebuttal_line_items rd
    ON af.PYID = rd.CASEID
"""

REBUTTALS_TREND_QUERY = f"""
WITH grouping_logic AS (
    SELECT
        '{{grouping_type}}' AS grouping_type,
        '{{use_audit_period_grouping}}' AS use_audit_period_grouping
),
audit_base AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDITOR_ID,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        PYSTATUSWORK,
        REBUTTALFLAG
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        AUDIT_YEAR,
        AUDIT_MONTH,
        CASE UPPER(TRIM(AUDIT_MONTH))
            WHEN 'JANUARY' THEN 1
            WHEN 'FEBRUARY' THEN 2
            WHEN 'MARCH' THEN 3
            WHEN 'APRIL' THEN 4
            WHEN 'MAY' THEN 5
            WHEN 'JUNE' THEN 6
            WHEN 'JULY' THEN 7
            WHEN 'AUGUST' THEN 8
            WHEN 'SEPTEMBER' THEN 9
            WHEN 'OCTOBER' THEN 10
            WHEN 'NOVEMBER' THEN 11
            WHEN 'DECEMBER' THEN 12
        END AS audit_month_num
    FROM audit_base
    WHERE REBUTTALFLAG = 'Y'
        AND PYID LIKE 'AUD%'
        AND PYSTATUSWORK = 'Resolved-Completed'
        AND PXCREATEDATETIME IS NOT NULL
        {{audit_period_filter}}
        {{lob_filter}}
        {{user_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
        AND ERRORCATEGORYTYPE IS NOT NULL
        AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
        AND REBUTTALOUTCOME IS NOT NULL
        AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
    AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
),
grouped_data AS (
    SELECT
        g.grouping_type,
        g.use_audit_period_grouping,
        CASE
            WHEN g.grouping_type = 'daily' THEN DATE(af.PXCREATEDATETIME)
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', DATE(af.PXCREATEDATETIME))

            WHEN g.grouping_type = 'monthly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(TRY_TO_NUMBER(af.AUDIT_YEAR), af.audit_month_num, 1)

            WHEN g.grouping_type = 'monthly'
            THEN DATE_TRUNC('month', DATE(af.PXCREATEDATETIME))

            WHEN g.grouping_type = 'quarterly'
                 AND g.use_audit_period_grouping = 'true'
            THEN DATE_FROM_PARTS(
                TRY_TO_NUMBER(af.AUDIT_YEAR),
                CASE
                    WHEN af.audit_month_num BETWEEN 1 AND 3 THEN 1
                    WHEN af.audit_month_num BETWEEN 4 AND 6 THEN 4
                    WHEN af.audit_month_num BETWEEN 7 AND 9 THEN 7
                    ELSE 10
                END,
                1
            )

            WHEN g.grouping_type = 'quarterly'
            THEN DATE_TRUNC('quarter', DATE(af.PXCREATEDATETIME))

            ELSE DATE_TRUNC('year', DATE(af.PXCREATEDATETIME))
        END AS group_key,
        DATE(af.PXCREATEDATETIME) AS created_date,
        af.PYID,
        act.ERRORCATEGORYTYPE,
        act.ERRORCATEGORY,
        act.REBUTTALOUTCOME
    FROM audit_filtered af
    CROSS JOIN grouping_logic g
    INNER JOIN eligible_rebuttal_line_items act
        ON af.PYID = act.CASEID
)
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' AND use_audit_period_grouping = 'false' THEN
            TO_CHAR(GREATEST(group_key, '{{start_date}}'::DATE), 'MM/DD') || ' - ' ||
            TO_CHAR(LEAST(DATEADD(day, 6, group_key), '{{end_date}}'::DATE), 'MM/DD')
        WHEN grouping_type = 'weekly' THEN
            TO_CHAR(group_key, 'MM/DD') || ' - ' ||
            TO_CHAR(DATEADD(day, 6, group_key), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS PERIOD,
    COUNT(DISTINCT PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
        THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS OVERTURNED,
    COUNT(DISTINCT CASE
        WHEN REBUTTALOUTCOME IN ('Error Stands', 'FYI Stands', 'Rebuttal Cancelled')
        THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
    END) AS UPHELD,
    COALESCE(
        ROUND(
            (
                COUNT(DISTINCT CASE
                    WHEN REBUTTALOUTCOME IN ('Error Retracted', 'FYI Retracted', 'Changed to FYI')
                    THEN PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY
                END) * 100.0
            ) / NULLIF(
                COUNT(DISTINCT PYID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY),
                0
            ),
            2
        ),
        0
    ) AS REBUTTAL_OVERTURN_PCT,
    MIN(created_date) AS SORT_DATE
FROM grouped_data
GROUP BY grouping_type, use_audit_period_grouping, group_key
ORDER BY SORT_DATE
"""


def has_valid_audit_periods(audit_periods: Optional[List[AuditPeriod]] = None) -> bool:
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = (period.year or "").strip()

        if not month_value or not year_value:
            continue

        seen_periods.add((month_value.upper(), year_value))

    return bool(seen_periods)


def get_trend_grouping_type(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    audit_periods: Optional[List[AuditPeriod]] = None,
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = (period.year or "").strip()

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append(key)

    if valid_periods:
        month_count = len(valid_periods)

        if month_count == 1:
            return "weekly"
        if month_count <= 6:
            return "monthly"
        return "quarterly"

    range_start = start_date or "1900-01-01"
    range_end = end_date or "2099-12-31"

    total_days = (
        datetime.strptime(range_end, "%Y-%m-%d") -
        datetime.strptime(range_start, "%Y-%m-%d")
    ).days + 1

    if total_days <= 7:
        return "daily"
    if total_days <= 28:
        return "weekly"
    if total_days <= 365:
        return "monthly"
    if total_days <= 1095:
        return "quarterly"
    return "yearly"


async def execute_count_query_async(engine, query: str):
    """Execute count query asynchronously and return the rebuttal count as list of records for caching consistency."""
    records = await engine.execute_query_async(query, limit=1)
    return records  # Return full list for consistent cache format


async def execute_trend_query_async(engine, query: str):
    """Execute trend query asynchronously and return all records."""
    return await engine.execute_query_async(query, limit=1000)




@router.post(
    "/rebuttals",
    response_model=FLAuditorRebuttalsResponse,
    summary="Get FL Auditor Rebuttals Metrics",
    description="""
Retrieve rebuttals metrics for FL Auditor dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter

**Response Fields:**
- **rebuttal_count**: Total number of rebuttals (string)
- **rebuttals_overturned**: Percentage of rebuttals overturned (string with 2 decimal places)

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (rebuttal data)
- COB_AI_USER_PROFILE (user information)
""",
)
async def get_fl_auditor_rebuttals(request: FLAuditorBaseRequest) -> FLAuditorRebuttalsResponse:
    """Rebuttals metrics endpoint with session-based metric-level caching."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_fl_auditor_rebuttals_query(request)


async def execute_fl_auditor_rebuttals_query(request: FLAuditorBaseRequest) -> FLAuditorRebuttalsResponse:
    """Execute rebuttals query logic with metric-level caching."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        user_filter = build_user_filter(request.user_id)
        audit_period_filter = build_audit_period_filter(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
            timestamp_column="PXCREATEDATETIME",
            audit_month_column="AUDIT_MONTH",
            audit_year_column="AUDIT_YEAR",
        )
        
        engine = connection_manager.get_engine()

        # Format queries
        grouping_type = get_trend_grouping_type(
            request.start_date,
            request.end_date,
            getattr(request, "audit_periods", None),
        )
        use_audit_period_grouping = "true" if has_valid_audit_periods(getattr(request, "audit_periods", None)) else "false"

        rebuttals_query = REBUTTALS_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter
        )
        trend_query = REBUTTALS_TREND_QUERY.format(
            audit_period_filter=audit_period_filter,
            lob_filter=lob_filter,
            user_filter=user_filter,
            grouping_type=grouping_type,
            use_audit_period_grouping=use_audit_period_grouping,
            start_date=request.start_date or "1900-01-01",
            end_date=request.end_date or "2099-12-31"
        )
        
        # Get session_id for caching
        session_id = getattr(request, "session_id", None)
        
        # Define async fetch functions for each metric
        async def fetch_rebuttal_count():
            return await execute_count_query_async(engine, rebuttals_query)
        
        async def fetch_trend():
            return await execute_trend_query_async(engine, trend_query)
        
        # Build filters dict for cache isolation
        filters = {
            'user_id': request.user_id,
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
            'audit_periods': [
                {'month': period.month, 'year': period.year}
                for period in (request.audit_periods or [])
            ],
        }
        
        # Get or fetch cached metrics (only cache if session_id provided)
        if session_id:
            # Execute both metric fetches in parallel using asyncio.gather
            (rebuttal_count_value, trend_records) = await asyncio.gather(
                metric_cache_service.get_or_fetch_metric(
                    fetch_func=fetch_rebuttal_count,
                    session_id=session_id,
                    metric_name="rebuttal_count",
                    filters=filters
                ),
                metric_cache_service.get_or_fetch_metric(
                    fetch_func=fetch_trend,
                    session_id=session_id,
                    metric_name="rebuttal_trend",
                    filters=filters
                )
            )
        else:
            # No session_id - execute directly without caching in parallel
            rebuttal_count_value, trend_records = await asyncio.gather(
                fetch_rebuttal_count(),
                fetch_trend()
            )

        # Extract metrics
        if rebuttal_count_value and isinstance(rebuttal_count_value, list) and len(rebuttal_count_value) > 0:
            rebuttal_count_int = int(rebuttal_count_value[0].get("REBUTTAL_COUNT", 0))
            rebuttal_count = str(rebuttal_count_int)
        else:
            rebuttal_count = "N/A"
        
        # Build trend data and calculate overall overturn percentage from trend query
        rebuttals_dict: Dict[str, int] = {}
        overturned_dict: Dict[str, int] = {}
        upheld_dict: Dict[str, int] = {}
        total_rebuttals = 0
        total_overturned = 0
        
        for record in trend_records:
            period = record.get("PERIOD")
            rebuttals_count = int(record.get("REBUTTALS") or 0)
            overturned_count = int(record.get("OVERTURNED") or 0)
            upheld_count = int(record.get("UPHELD") or 0)
            
            # Use period as-is (supports daily MM/DD, weekly MM/DD - MM/DD, monthly YYYY-MM, quarterly YYYY-Q#, yearly YYYY)
            period_key = period
            
            rebuttals_dict[period_key] = rebuttals_count
            overturned_dict[period_key] = overturned_count
            upheld_dict[period_key] = upheld_count
            
            # Accumulate totals for overall overturn percentage
            total_rebuttals += rebuttals_count
            total_overturned += overturned_count
        
        # Calculate overall overturn percentage from aggregated trend data
        if total_rebuttals > 0:
            overall_overturn_pct = (total_overturned / total_rebuttals) * 100
            rebuttals_overturned = f"{overall_overturn_pct:.2f}%"
        elif total_rebuttals == 0:
            rebuttals_overturned = "0.00%"
        else:
            rebuttals_overturned = "N/A"

        tooltips = {
            "rebuttal_count": "Total number of rebuttals",
            "rebuttals_overturned": "Percentage of rebuttals that were overturned",
            "rebuttals_count_trend": "Rebuttal trend over time showing total rebuttals, overturned, and upheld counts per period"
        }

        return FLAuditorRebuttalsResponse(
            status="success",
            rebuttal_count=rebuttal_count,
            rebuttals_overturned=rebuttals_overturned,
            rebuttals_count_trend={
                "rebuttals": rebuttals_dict,
                "overturned": overturned_dict,
                "upheld": upheld_dict
            },
            message="FL Auditor rebuttals metrics retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"FL Auditor rebuttals query error: {type(e).__name__}: {str(e)}")
        return FLAuditorRebuttalsResponse(
            status="error",
            rebuttal_count="0",
            rebuttals_overturned="N/A",
            rebuttals_count_trend={
                "rebuttals": {},
                "rebuttals_percent": {},
                "overturned": {},
                "upheld": {}
            },
            message=f"Failed to retrieve FL Auditor rebuttals metrics: {str(e)}"
        )
