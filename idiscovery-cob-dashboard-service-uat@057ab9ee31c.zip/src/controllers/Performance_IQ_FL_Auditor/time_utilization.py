import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import FLAuditorBaseRequest, FLAuditorTimeUtilizationResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from services.session_cache_orchestrator import generate_session_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fl-auditor", tags=["Performance_IQ_FL_Auditor"])

connection_manager = SnowflakeConnectionManager()

FUSE_TIME_QUERY = f"""
SELECT 
    -- Total Fuse Time
    ROUND(SUM(TOTALSYSTEMTIME) / 3600.0, 2) AS TOTAL_FUSE_TIME_HOURS,
    
    -- OHI Productive Time (from PRODUCTIVETIME column)
    -- Convert HH:MM:SS string format to hours
    ROUND(SUM(
        CASE 
            WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END
    ) / 3600.0, 2) AS OHI_PRODUCTIVE_TIME_HOURS,
    
    -- Non-Productive Time (using FUSE_NON_PRODUCTIVE_TIME)
    ROUND(SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0, 2) AS TOTAL_NON_PRODUCTIVE_HOURS,
    
    -- Other Time (calculated as Total - (Productive + Non-Productive))
    ROUND(
        (SUM(TOTALSYSTEMTIME) / 3600.0) - 
        ((SUM(
            CASE 
                WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                    (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                     SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                     SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
                ELSE 0
            END
        ) / 3600.0) + 
        (SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0)), 
    2) AS OTHER_TIME_HOURS,
    
    -- Percentages (for UI chart display)
    ROUND(
        SUM(CASE WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
            (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
             SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
             SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
        ELSE 0 END) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 2
    ) AS PRODUCTIVE_PCT,
    
    ROUND(
        SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 2
    ) AS NON_PRODUCTIVE_PCT,
    
    ROUND(
        100.0 - 
        COALESCE(
            SUM(CASE WHEN PRODUCTIVETIME IS NOT NULL AND PRODUCTIVETIME != '' THEN
                (SPLIT_PART(PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0 END) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 0
        ) -
        COALESCE(
            SUM(COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(TOTALSYSTEMTIME), 0), 0
        ), 2
    ) AS OTHER_PCT

FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE TOTALSYSTEMTIME IS NOT NULL
{{date_filter}}
{{user_filter}}
"""


def build_date_filter(start_date: Optional[str], end_date: Optional[str]) -> str:
    """Build date filter for COB_AI_USER_PROFILE table (uses LOGINDATE)"""
    if start_date and end_date:
        return (
            f"AND LOGINDATE >= '{start_date}' "
            f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND LOGINDATE >= '{start_date}'"
    elif end_date:
        return f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_user_filter(user_id: str) -> str:
    """Build filter for FL Auditor (USERID)"""
    return f"AND USERID = '{user_id}'"


@router.post(
    "/time-utilization",
    response_model=FLAuditorTimeUtilizationResponse,
    summary="Get FL Auditor Time Utilization Metrics",
    description="""
Retrieve time utilization metrics for FL Auditor dashboard (Fuse time only).

**Input Parameters:**
- **user_id** (required): Logged-in FL Auditor user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter

**Response Fields:**
- **total_fuse_time_hours**: Total hours logged into FUSE system (2 decimal places)
- **ohi_productive_time**: OHI productive time in hours (2 decimal places)
- **total_non_productive_hours**: Fuse non-productive time in hours (2 decimal places)
- **other_time_hours**: Other time in hours (2 decimal places)
- **productive_pct**: Productive time percentage (2 decimal places)
- **non_productive_pct**: Non-productive time percentage (2 decimal places)
- **other_pct**: Other time percentage (2 decimal places)

**Data Sources:** 
- COB_AI_USER_PROFILE (time utilization metrics)
""",
)
async def get_fl_auditor_time_utilization(request: FLAuditorBaseRequest) -> FLAuditorTimeUtilizationResponse:
    """Time utilization metrics endpoint with session-based metric-level caching."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_fl_auditor_time_utilization_query(request)


async def execute_fl_auditor_time_utilization_query(request: FLAuditorBaseRequest) -> FLAuditorTimeUtilizationResponse:
    """Execute time utilization query logic with metric-level caching."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        date_filter = build_date_filter(request.start_date, request.end_date)
        user_filter = build_user_filter(request.user_id)
        
        engine = connection_manager.get_engine()

        # Format query
        fuse_time_query = FUSE_TIME_QUERY.format(
            date_filter=date_filter,
            user_filter=user_filter
        )
        
        # Get session_id for caching
        session_id = getattr(request, "session_id", None)
        
        # Build filters dict for cache isolation
        filters = {
            'user_id': request.user_id,
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
        }
        
        # Define async fetch function
        async def fetch_time_utilization():
            return await engine.execute_query_async(fuse_time_query, limit=1)
        
        # Get or fetch cached metric (only cache if session_id provided)
        if session_id:
            records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_time_utilization,
                session_id=session_id,
                metric_name="time_utilization",
                filters=filters
            )
        else:
            # No session_id - execute directly without caching
            records = await fetch_time_utilization()

        # Extract metrics with proper null handling
        if records and records[0].get("TOTAL_FUSE_TIME_HOURS") is not None:
            total_fuse_time_hours = f"{float(records[0].get('TOTAL_FUSE_TIME_HOURS') or 0.0):.2f}"
            ohi_productive_time = f"{float(records[0].get('OHI_PRODUCTIVE_TIME_HOURS') or 0.0):.2f}"
            total_non_productive_hours = f"{float(records[0].get('TOTAL_NON_PRODUCTIVE_HOURS') or 0.0):.2f}"
            other_time_hours = f"{float(records[0].get('OTHER_TIME_HOURS') or 0.0):.2f}"
            productive_pct = f"{float(records[0].get('PRODUCTIVE_PCT') or 0.0):.2f}"
            non_productive_pct = f"{float(records[0].get('NON_PRODUCTIVE_PCT') or 0.0):.2f}"
            other_pct = f"{float(records[0].get('OTHER_PCT') or 0.0):.2f}"
        else:
            total_fuse_time_hours = "N/A"
            ohi_productive_time = "N/A"
            total_non_productive_hours = "N/A"
            other_time_hours = "N/A"
            productive_pct = "N/A"
            non_productive_pct = "N/A"
            other_pct = "N/A"

        tooltips = {
            "total_fuse_time_hours": "Total hours logged into FUSE system",
            "ohi_productive_time": "OHI system productive time in hours from PRODUCTIVETIME column",
            "total_non_productive_hours": "Total non-productive hours (breaks, meetings, etc.)",
            "other_time_hours": "Other time (Total - (Productive + Non-Productive)) in hours",
            "productive_pct": "Productive time percentage of total fuse time",
            "non_productive_pct": "Non-productive time percentage of total fuse time",
            "other_pct": "Other time percentage of total fuse time"
        }

        return FLAuditorTimeUtilizationResponse(
            status="success",
            total_fuse_time_hours=total_fuse_time_hours,
            ohi_productive_time=ohi_productive_time,
            total_non_productive_hours=total_non_productive_hours,
            other_time_hours=other_time_hours,
            productive_pct=productive_pct,
            non_productive_pct=non_productive_pct,
            other_pct=other_pct,
            message="FL Auditor time utilization metrics retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"FL Auditor time utilization query error: {type(e).__name__}: {str(e)}")
        return FLAuditorTimeUtilizationResponse(
            status="error",
            total_fuse_time_hours="N/A",
            ohi_productive_time="N/A",
            total_non_productive_hours="N/A",
            other_time_hours="N/A",
            productive_pct="N/A",
            non_productive_pct="N/A",
            other_pct="N/A",
            message=f"Failed to retrieve FL Auditor time utilization metrics: {str(e)}"
        )
