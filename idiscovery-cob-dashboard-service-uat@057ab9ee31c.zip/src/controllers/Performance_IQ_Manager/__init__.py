from .header_kpis import router as header_kpis_router
from .quality_outcomes import router as quality_outcomes_router
from .associate_utilization import router as associate_utilization_router
from .associates_list import router as associates_list_router
from .pended_items_counts_drilldown import router as pended_items_drilldown_router
from .production_pct_achieved_drilldown import router as production_pct_achieved_drilldown_router
from .rebuttal_drilldown import router as rebuttal_drilldown_router
from .work_items_drilldown import router as work_items_drilldown_router
from .audit_score_drilldown import router as audit_score_drilldown_router
from .rework_drilldown import router as rework_drilldown_router
from .fuse_time_drilldown import router as fuse_time_drilldown_router
from .audit_errors_drilldown import router as audit_errors_drilldown_router
from .complete_audit_count_drilldown import router as complete_audit_count_drilldown_router
from .ai_coach_manager import router as ai_coach_router_manager
from .user_activity import router as user_activity_router
from .manager_list import router as manager_list_router
from .manager_lob import router as manager_lob_router
from .manager_capacity_insight_drilldown import router as manager_capacity_insight_drilldown_router
from .watchlist_manager_drilldown import router as watchlist_manager_drilldown_router
from .staffutilization_drilldown import router as staff_utilization_drilldown_router
__all__ = [
    "header_kpis_router",
    "quality_outcomes_router",
    "associate_utilization_router",
    "associates_list_router",
    "pended_items_drilldown_router",
    "production_pct_achieved_drilldown_router",
    "rebuttal_drilldown_router",
    "work_items_drilldown_router",
    "audit_score_drilldown_router",
    "rework_drilldown_router",
    "fuse_time_drilldown_router",
    "audit_errors_drilldown_router",
    "complete_audit_count_drilldown_router",
    "ai_coach_router_manager",
    "user_activity_router",
    "manager_list_router",
    "manager_lob_router",
    "manager_capacity_insight_drilldown_router",
    "watchlist_manager_drilldown_router",
    "staff_utilization_drilldown_router",
]
