import logging
from typing import Any
from fastapi import APIRouter, Response, status
import config
from schema import ManagerAICoachRequest, ManagerAICoachResponse
from services.openai_service import generate_performance_summary, normalize_ai_summary
from services.metrics_aggregator import fetch_manager_metrics

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])


def _is_zero_or_unavailable_metric_value(value: Any) -> bool:
    if value is None:
        return True

    if isinstance(value, (int, float)):
        return value == 0

    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"", "n/a", "na", "not available", "none"}:
            return True

        cleaned = normalized.replace("%", "").replace(",", "")
        try:
            return float(cleaned) == 0
        except ValueError:
            return False

    return False


def _manager_metrics_are_insufficient(metrics_data: dict[str, Any]) -> bool:
    metric_keys = [
        "work_items_completed",
        "production_pct",
        "audit_score",
        "cycle_time",
        "pended_items",
        "non_value_add_pct",
    ]
    metric_values = [metrics_data.get(key) for key in metric_keys if key in metrics_data]

    if not metric_values:
        return True

    return all(_is_zero_or_unavailable_metric_value(value) for value in metric_values)

@router.post(
    "/ai-coach",
    response_model=ManagerAICoachResponse,
    summary="Get AI Coach Performance Summary",
    description="""
Retrieve AI-generated performance summary based on team KPIs and metrics.

**Input Parameters:**
- **user_id** (optional): User ID to query (manager)
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format
- **manager_ids**: List of manager IDs to filter
- **frontline_associate_ids**: List of frontline associate IDs to filter
- **lob**: List of Line of Business values

**Response Fields:**
- **performance_summary**: AI-generated summary analyzing team performance, coaching opportunities, and management insights

**Status:** AI-powered team management coaching using OpenAI GPT models
""",
)
async def get_ai_coach(request: ManagerAICoachRequest, response: Response) -> ManagerAICoachResponse:
    user_id_str = request.user_id if request.user_id else "manager"
    
    if not config.is_ai_coach_enabled("manager"):
        return ManagerAICoachResponse(
            status="disabled",
            user_id=user_id_str,
            performance_summary="AI Coach feature is currently disabled",
            message="Feature disabled by configuration"
        )
    
    try:
        logger.info(f"Manager AI Coach request for user {user_id_str} ({request.start_date} to {request.end_date})")
        logger.info(f"Manager AI Coach filters: manager_ids={request.manager_ids}, "
                   f"frontline_associate_ids={request.frontline_associate_ids}, lob={request.lob}, session_id={request.session_id}")
        
        metrics_data = await fetch_manager_metrics(
            user_id=user_id_str,
            start_date=request.start_date,
            end_date=request.end_date,
            manager_id=request.manager_ids,
            frontline_associate_ids=request.frontline_associate_ids,
            lob=request.lob,
            session_id=request.session_id
        )

        if "error" in metrics_data:
            logger.error(f"Manager AI Coach metrics fetch failed for {user_id_str}: {metrics_data.get('error')}")
            response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            return ManagerAICoachResponse(
                status="error",
                user_id=user_id_str,
                performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
                message=f"Failed to fetch AI Coach metrics: {metrics_data.get('error')}"
            )

        # Enrich metrics_data with view context so the LLM prompt can distinguish
        # individual associate view from full-team view
        fa_ids = request.frontline_associate_ids
        if fa_ids and len(fa_ids) == 1:
            view_mode = "individual_associate"
        elif fa_ids and len(fa_ids) > 1:
            view_mode = "selected_group"
        else:
            view_mode = "team"
        metrics_data["view_mode"] = view_mode

        if view_mode == "individual_associate":
            # Prefer the human-readable name resolved by fetch_manager_metrics;
            # fall back to the raw user ID if the lookup failed.
            metrics_data["subject"] = (
                metrics_data.pop("associate_name", None) or fa_ids[0]
            )
        elif view_mode == "selected_group":
            metrics_data["subject"] = f"{len(fa_ids)} selected associates"
        else:
            metrics_data["subject"] = "All associates"

        logger.info(f"📊 Manager AI Coach - Metrics sent to LLM: {metrics_data}")

        if _manager_metrics_are_insufficient(metrics_data):
            logger.info(f"Manager AI Coach skipped for {user_id_str}: insufficient non-zero metrics for reliable summary")
            response.status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
            return ManagerAICoachResponse(
                status="error",
                user_id=user_id_str,
                performance_summary="Unable to generate performance summary because the available metrics are insufficient for reliable coaching.",
                message="Insufficient metrics available to generate AI Coach summary"
            )

        summary = await generate_performance_summary(
            user_id=user_id_str,
            metrics_data=metrics_data,
            role="manager",
            start_date=request.start_date,
            end_date=request.end_date,
            lob=request.lob
        )
        
        summary_text = normalize_ai_summary(summary)["performance_summary"]
        
        return ManagerAICoachResponse(
            status="success",
            user_id=user_id_str,
            performance_summary=summary_text,
            message="AI Coach analysis completed successfully"
        )
        
    except Exception as e:
        logger.error(f"Manager AI Coach error for user {user_id_str}: {str(e)}")

        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ManagerAICoachResponse(
            status="error",
            user_id=user_id_str,
            performance_summary="Unable to generate performance summary. Please review your metrics dashboard.",
            message=f"Error: {str(e)}"
        )