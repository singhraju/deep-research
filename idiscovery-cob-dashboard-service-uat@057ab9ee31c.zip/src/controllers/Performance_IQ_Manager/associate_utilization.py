import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import ManagerAssociateUtilizationRequest, AssociateUtilizationResponse, ExperienceLevelItem, AuditScoreTrend, ProductionPercentageTrend, AuditPeriod
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from controllers.Performance_IQ_Manager.header_kpis import build_audit_month_year_filter

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()

FUSE_TIME_SUMMARY_QUERY = f"""
WITH associate_hierarchy AS (
    -- Get list of associates who reported to specified manager during the period
    SELECT DISTINCT
        PYRESOLVEDUSERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '{{start_date}}' 
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{associate_filter_invntry}}
      {{manager_filter}}
)
SELECT 
    -- Total Fuse Time Hours = Available Hours (Total System Time - Non Productive Time)
    ROUND((SUM(up.TOTALSYSTEMTIME) / 3600.0) - (SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0), 2) AS TOTAL_FUSE_TIME_HOURS,
    
    -- OHI Productive Time (from PRODUCTIVETIME column)
   
    ROUND(SUM(
        CASE 
            WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0
        END
    ) / 3600.0, 2) AS OHI_PRODUCTIVE_TIME_HOURS,
    
    -- Non-Productive Time (using FUSE_NON_PRODUCTIVE_TIME)
    ROUND(SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0, 2) AS TOTAL_NON_PRODUCTIVE_HOURS,
    
    
    ROUND(
        (SUM(up.TOTALSYSTEMTIME) / 3600.0) - 
        ((SUM(
            CASE 
                WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                    (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
                ELSE 0
            END
        ) / 3600.0) + 
        (SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) / 3600.0)), 
    2) AS OTHER_TIME_HOURS,
    
    -- Percentages (for UI chart display)
    -- Productive %
    ROUND(
        SUM(CASE WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
            (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
             SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
             SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
        ELSE 0 END) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 2
    ) AS PRODUCTIVE_PCT,
    
    -- Non-Productive %
    ROUND(
        SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 2
    ) AS NON_PRODUCTIVE_PCT,
    
    -- Other time%
    ROUND(
        100.0 - 
        COALESCE(
            SUM(CASE WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                 SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
            ELSE 0 END) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 0
        ) -
        COALESCE(
            SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0)) * 100.0 / NULLIF(SUM(up.TOTALSYSTEMTIME), 0), 0
        ), 2
    ) AS OTHER_PCT
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE up  
INNER JOIN associate_hierarchy ah
    ON up.USERID = ah.PYRESOLVEDUSERID  
WHERE up.TOTALSYSTEMTIME IS NOT NULL
  {{user_date_filter}}
"""

EXPERIENCE_LEVEL_QUERY = f"""
SELECT 
    EXPERIENCELEVEL AS LEVEL,
    COUNT(DISTINCT USERID) AS COUNT,
    ROUND(COUNT(DISTINCT USERID) * 100.0 / SUM(COUNT(DISTINCT USERID)) OVER (), 2) AS PERCENTAGE
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE EXPERIENCELEVEL IS NOT NULL
{{user_date_filter}}
{{associate_filter_user}}
{{manager_filter_user}}
GROUP BY EXPERIENCELEVEL
ORDER BY COUNT DESC
"""

AUDIT_SCORE_TREND_QUERY = f"""
WITH date_range AS (
    -- Calculate total days in the selected date range
    SELECT
        DATEDIFF(day, '{{start_date}}'::DATE, '{{end_date}}'::DATE) + 1 AS total_days
),
grouping_logic AS (
    -- Determine grouping type based on date range length
    SELECT
        total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),
invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID, 
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{lob_filter}}
      {{associate_filter_invntry}}
      {{manager_filter}}
),
audit_deduped AS (
    -- Deduplicate audit records by (CASE_TO_AUDIT, AUDIT_SUBJECT_ID)
    SELECT 
        PYID AS audit_id,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        ROW_NUMBER() OVER (
            PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID 
            ORDER BY PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE AUDIT_SCORE IS NOT NULL
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN (
            'Open-FeedbackReview',
            'Open-RebuttalReview',
            'Open-UpdateAuditCase',
            'Resolved-Completed'
      )
      {{lob_filter}}
      {{associate_filter_audit}}
),
audit_with_completion_date AS (
    -- SIMPLIFIED: Direct join between inventory and audit, no intermediate CTE needed
    -- Links audits to work item completion dates
    SELECT 
        i.PYRESOLVEDTIMESTAMP::DATE AS case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        i.PYID AS case_id,
        a.AUDIT_SUBJECT_ID
    FROM invntry_deduped i
    INNER JOIN audit_deduped a
        ON i.PYID = a.CASE_TO_AUDIT
        AND a.rn = 1
    WHERE i.rn = 1  
),
grouped_data AS (
    -- Group audit data by the appropriate time period
    SELECT 
        g.grouping_type,
        CASE 
            WHEN g.grouping_type = 'daily' THEN a.case_completion_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', a.case_completion_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', a.case_completion_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', a.case_completion_date)
            ELSE DATE_TRUNC('year', a.case_completion_date)
        END AS group_key,
        a.case_completion_date,
        a.AUDIT_SCORE,
        a.audit_id,
        a.case_id,
        a.AUDIT_SUBJECT_ID
    FROM audit_with_completion_date a
    CROSS JOIN grouping_logic g
)
-- Final aggregation and formatting for trend line display
SELECT 
    -- Format period label based on grouping type
    CASE 
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(GREATEST(group_key, '{{start_date}}'::DATE), 'MM/DD') || ' - ' ||
            TO_CHAR(LEAST(DATEADD(day, 6, group_key), '{{end_date}}'::DATE), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT audit_id) AS total_audits,
    COUNT(DISTINCT case_id) AS total_cases_audited,
    COUNT(DISTINCT AUDIT_SUBJECT_ID) AS total_frontline_audited,
    MIN(case_completion_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
"""

AUDIT_SCORE_TREND_AUDIT_PERIOD_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
),
audit_deduped AS (
    SELECT
        a.PYID AS audit_id,
        a.CASE_TO_AUDIT AS case_id,
        UPPER(TRIM(a.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.LOB)) AS LOB,
        CASE
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JAN', 'JANUARY') THEN 1
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('FEB', 'FEBRUARY') THEN 2
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('MAR', 'MARCH') THEN 3
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('APR', 'APRIL') THEN 4
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('MAY') THEN 5
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JUN', 'JUNE') THEN 6
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('JUL', 'JULY') THEN 7
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('AUG', 'AUGUST') THEN 8
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('SEP', 'SEPT', 'SEPTEMBER') THEN 9
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('OCT', 'OCTOBER') THEN 10
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('NOV', 'NOVEMBER') THEN 11
            WHEN UPPER(TRIM(a.AUDIT_MONTH)) IN ('DEC', 'DECEMBER') THEN 12
            ELSE NULL
        END AS audit_month_number,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
    WHERE a.PYID LIKE 'AUD%'
      AND a.AUDIT_SCORE IS NOT NULL
      AND a.AUDIT_SCORE > 0
      AND UPPER(TRIM(a.PYSTATUSWORK)) IN (
            'OPEN-FEEDBACKREVIEW',
            'OPEN-REBUTTALREVIEW',
            'OPEN-UPDATEAUDITCASE',
            'RESOLVED-COMPLETED',
            'RESOLVED-AUTOCLOSE'
      )
      {{lob_filter}}
),
grouped_data AS (
    SELECT
        CASE
            WHEN '{{grouping_type}}' = 'monthly'
                THEN TRIM(a.AUDIT_YEAR) || '-' || LPAD(TO_VARCHAR(a.audit_month_number), 2, '0')
            WHEN '{{grouping_type}}' = 'quarterly'
                THEN TRIM(a.AUDIT_YEAR) || '-Q' || TO_VARCHAR(FLOOR((a.audit_month_number - 1) / 3) + 1)
            ELSE TRIM(a.AUDIT_YEAR)
        END AS period,
        CASE
            WHEN '{{grouping_type}}' = 'monthly'
                THEN TO_DATE(TRIM(a.AUDIT_YEAR) || '-' || LPAD(TO_VARCHAR(a.audit_month_number), 2, '0') || '-01')
            WHEN '{{grouping_type}}' = 'quarterly'
                THEN DATE_FROM_PARTS(
                    TRY_TO_NUMBER(TRIM(a.AUDIT_YEAR)),
                    (FLOOR((a.audit_month_number - 1) / 3) * 3) + 1,
                    1
                )
            ELSE DATE_FROM_PARTS(TRY_TO_NUMBER(TRIM(a.AUDIT_YEAR)), 1, 1)
        END AS sort_date,
        a.AUDIT_SCORE,
        a.audit_id,
        a.case_id,
        a.AUDIT_SUBJECT_ID
    FROM audit_deduped a
    LEFT JOIN latest_inventory i
      ON i.PYID = a.case_id
     AND i.rn = 1
    WHERE a.rn = 1
      {{manager_filter}}
      {{associate_filter_invntry}}
      {{audit_period_filter}}
      AND a.audit_month_number IS NOT NULL
)
SELECT
    period,
    ROUND(AVG(AUDIT_SCORE), 2) AS avg_audit_score,
    COUNT(DISTINCT audit_id) AS total_audits,
    COUNT(DISTINCT case_id) AS total_cases_audited,
    COUNT(DISTINCT AUDIT_SUBJECT_ID) AS total_frontline_audited,
    MIN(sort_date) AS sort_date
FROM grouped_data
GROUP BY period
ORDER BY sort_date
"""

PRODUCTION_TREND_QUERY = f"""
WITH 
-- =====================================================
-- Date Range and Grouping Logic
-- =====================================================
date_range AS (
    SELECT DATEDIFF(day, '{{start_date}}'::DATE, '{{end_date}}'::DATE) + 1 AS total_days
),
grouping_logic AS (
    SELECT total_days,
        CASE
            WHEN total_days <= 7 THEN 'daily'
            WHEN total_days <= 28 THEN 'weekly'
            WHEN total_days <= 365 THEN 'monthly'
            WHEN total_days <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range
),

-- =====================================================
-- STEP 1: Deduplicate Inventory Records (Get Latest State)
-- =====================================================
inventory_deduped AS (
    SELECT 
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.REPORTTOMANAGERID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.RETIME,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PXUPDATEDATETIME,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.LOB,
        
        -- Row number for deduplication (most recent business event)
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID 
            ORDER BY i.PXCOMMITDATETIME DESC, i.INSRT_DT_TIME DESC, i.RETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
),

-- =====================================================
-- STEP 2: Apply Business Filters and Calculate Metrics
-- =====================================================
case_level AS (
    SELECT 
        i.PYRESOLVEDUSERID AS user_id,
        i.INTAKESOURCESYSTEM AS work_type,
        i.PYID AS case_id,
        i.CYCLE_TIME / 60.0 AS cycle_time_min,
        i.RETIME AS retime_min,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PYRESOLVEDTIMESTAMP,
        DATE(i.PYRESOLVEDTIMESTAMP) AS resolved_date,
        i.PXUPDATEDATETIME,
        
        -- Calculate efficiency per case: (RETIME / CYCLE_TIME) × 100
        CASE 
            WHEN i.CYCLE_TIME > 0 THEN (i.RETIME / (i.CYCLE_TIME / 60.0)) * 100
            ELSE 0
        END AS efficiency_pct,
        
        -- Map efficiency to capped score using threshold table
        CASE 
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 75 THEN 75
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 75 
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 90 THEN 90
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 90 
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 98 THEN 97
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 98 
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 100 THEN 100
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 100 
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 150 THEN 115
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS mapped_efficiency
        
    FROM inventory_deduped i
    WHERE i.rn = 1
      AND i.PYSTATUSWORK IN ('Resolved-Completed')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      AND i.PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{lob_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
      AND i.CYCLE_TIME IS NOT NULL
      AND i.CYCLE_TIME > 0
      AND i.RETIME IS NOT NULL
      AND i.RETIME > 0
),

-- =====================================================
-- STEP 3: Work Type Level Aggregation by Date
-- =====================================================
work_type_daily AS (
    SELECT 
        user_id,
        resolved_date,
        work_type,
        COUNT(DISTINCT case_id) AS items_completed,
        SUM(cycle_time_min) AS total_cycle_time_min,
        SUM(retime_min) AS total_retime_min,
        
        -- Efficiency at work type level: (Total RETIME / Total Cycle Time) × 100
        CASE 
            WHEN SUM(cycle_time_min) > 0 
            THEN (SUM(retime_min) / SUM(cycle_time_min)) * 100
            ELSE 0
        END AS work_type_efficiency_pct,
        
        -- Map the work type efficiency to get mapped efficiency
        CASE 
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 75 THEN 75
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 75 
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 90 THEN 90
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 90 
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 98 THEN 97
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 98 
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 100 THEN 100
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 100 
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 150 THEN 115
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS avg_mapped_efficiency
        
    FROM case_level
    GROUP BY user_id, resolved_date, work_type
),

-- =====================================================
-- STEP 4: User Daily Time Tracking (Available Time)
-- =====================================================
user_daily AS (
    SELECT 
        USERID AS user_id,
        LOGINDATE,
        TOTALSYSTEMTIME,
        FUSE_NON_PRODUCTIVE_TIME AS non_productive_sec,
        
        -- Available Time = Total System Time - Non-Productive Time
        TOTALSYSTEMTIME - COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0) AS available_time_sec,
        
        -- Deduplication: most recent record per user per day
        ROW_NUMBER() OVER (
            PARTITION BY USERID, LOGINDATE 
            ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST
        ) AS rn
        
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= '{{start_date}}'
      AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{associate_filter_user}}
      AND TOTALSYSTEMTIME IS NOT NULL
),

-- =====================================================
-- STEP 5: User Daily Available Time
-- =====================================================
user_available_time_daily AS (
    SELECT 
        user_id,
        LOGINDATE AS activity_date,
        SUM(available_time_sec) / 60.0 AS available_time_min
    FROM user_daily
    WHERE rn = 1
      AND available_time_sec > 0
    GROUP BY user_id, LOGINDATE
),

-- =====================================================
-- STEP 6: Daily Aggregation (Per Day Calculation)
-- =====================================================
daily_aggregate AS (
    SELECT 
        w.user_id,
        w.resolved_date AS activity_date,
        
        SUM(w.items_completed) AS total_items_completed,
        SUM(w.total_cycle_time_min) AS total_cycle_time_min,
        SUM(w.total_retime_min) AS total_retime_min,
        
        -- Overall efficiency: (Total RETIME / Total Cycle Time) × 100
        CASE 
            WHEN SUM(w.total_cycle_time_min) > 0 
            THEN (SUM(w.total_retime_min) / SUM(w.total_cycle_time_min)) * 100
            ELSE 0
        END AS overall_efficiency_pct,
        
        -- Weighted average of mapped efficiency by items completed
        CASE 
            WHEN SUM(w.items_completed) > 0 
            THEN SUM(w.items_completed * w.avg_mapped_efficiency) / SUM(w.items_completed)
            ELSE 0
        END AS weighted_mapped_efficiency,
        
        MAX(a.available_time_min) AS available_time_min
        
    FROM work_type_daily w
    LEFT JOIN user_available_time_daily a 
        ON w.user_id = a.user_id 
        AND w.resolved_date = a.activity_date
    GROUP BY w.user_id, w.resolved_date
),

-- =====================================================
-- STEP 7: Daily Production % Calculation
-- =====================================================
daily_production AS (
    SELECT 
        user_id,
        activity_date,
        total_items_completed,
        total_cycle_time_min,
        total_retime_min,
        available_time_min,
        overall_efficiency_pct,
        weighted_mapped_efficiency,
        
        -- Utilization: (Total Cycle Time / Available Time) × 100
        CASE 
            WHEN available_time_min > 0 
            THEN (total_cycle_time_min / available_time_min) * 100
            ELSE 0
        END AS utilization_pct,
        
        -- Final Production %: (Mapped Efficiency × 0.5) + (Utilization × 0.5)
        CASE 
            WHEN available_time_min > 0 
            THEN (weighted_mapped_efficiency * 0.5) + 
                 ((total_cycle_time_min / available_time_min) * 100 * 0.5)
            ELSE 0
        END AS final_production_pct
        
    FROM daily_aggregate
),

-- =====================================================
-- STEP 8: Apply Grouping Logic
-- =====================================================
grouped_data AS (
    SELECT 
        g.grouping_type,
        CASE
            WHEN g.grouping_type = 'daily' THEN d.activity_date
            WHEN g.grouping_type = 'weekly' THEN DATE_TRUNC('week', d.activity_date)
            WHEN g.grouping_type = 'monthly' THEN DATE_TRUNC('month', d.activity_date)
            WHEN g.grouping_type = 'quarterly' THEN DATE_TRUNC('quarter', d.activity_date)
            ELSE DATE_TRUNC('year', d.activity_date)
        END AS group_key,
        d.user_id,
        d.activity_date,
        d.total_items_completed,
        d.total_cycle_time_min,
        d.total_retime_min,
        d.available_time_min,
        d.weighted_mapped_efficiency,
        d.utilization_pct,
        d.final_production_pct
    FROM daily_production d
    CROSS JOIN grouping_logic g
)

-- =====================================================
-- FINAL SELECT: Trendline Output Format
-- =====================================================
SELECT
    CASE
        WHEN grouping_type = 'daily' THEN TO_CHAR(group_key, 'MM/DD')
        WHEN grouping_type = 'weekly' THEN 
            TO_CHAR(GREATEST(group_key, '{{start_date}}'::DATE), 'MM/DD') || ' - ' ||
            TO_CHAR(LEAST(DATEADD(day, 6, group_key), '{{end_date}}'::DATE), 'MM/DD')
        WHEN grouping_type = 'monthly' THEN TO_CHAR(group_key, 'YYYY-MM')
        WHEN grouping_type = 'quarterly' THEN 
            TO_CHAR(group_key, 'YYYY') || '-Q' || QUARTER(group_key)
        ELSE TO_CHAR(group_key, 'YYYY')
    END AS period,
    ROUND(AVG(final_production_pct), 2) AS avg_production_pct,
    SUM(total_items_completed) AS total_work_items,
    ROUND(SUM(total_retime_min), 0) AS total_expected_min,
    ROUND(SUM(total_cycle_time_min), 0) AS total_actual_production_min,
    ROUND(
        SUM(available_time_min) / 
        NULLIF(SUM(total_retime_min) / NULLIF(SUM(total_items_completed), 0), 0),
        0
    ) AS total_expected_tasks,
    COUNT(DISTINCT user_id) AS associate_count,
    MIN(activity_date) AS sort_date
FROM grouped_data
GROUP BY grouping_type, group_key
ORDER BY sort_date
"""

CAPACITY_INSIGHT_QUERY = f"""
WITH
date_range_config AS (
    SELECT
        '{{start_date}}'::DATE AS period_start,
        '{{end_date}}'::DATE AS period_end
),
grouping_logic AS (
    SELECT
        DATEDIFF(day, period_start, period_end) + 1 AS total_days,
        CASE
            WHEN DATEDIFF(day, period_start, period_end) + 1 <= 7 THEN 'daily'
            WHEN DATEDIFF(day, period_start, period_end) + 1 <= 30 THEN 'weekly'
            WHEN DATEDIFF(day, period_start, period_end) + 1 <= 365 THEN 'monthly'
            WHEN DATEDIFF(day, period_start, period_end) + 1 <= 1095 THEN 'quarterly'
            ELSE 'yearly'
        END AS grouping_type
    FROM date_range_config
),
date_spine AS (
    SELECT DATEADD(DAY, SEQ4(), drc.period_start) AS spine_date
    FROM TABLE(GENERATOR(ROWCOUNT => 500))
    CROSS JOIN date_range_config drc
    WHERE DATEADD(DAY, SEQ4(), drc.period_start) <= drc.period_end
),
date_periods AS (
    SELECT DISTINCT
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN spine_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', spine_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', spine_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', spine_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', spine_date)
        END AS period_date,
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN spine_date
            WHEN 'weekly' THEN DATEADD(DAY, 6, DATE_TRUNC('WEEK', spine_date))
            WHEN 'monthly' THEN LAST_DAY(DATE_TRUNC('MONTH', spine_date))
            WHEN 'quarterly' THEN LAST_DAY(DATE_TRUNC('QUARTER', spine_date))
            WHEN 'yearly' THEN LAST_DAY(DATE_TRUNC('YEAR', spine_date))
        END AS period_end_date,
        EXTRACT(YEAR FROM spine_date) AS period_year,
        EXTRACT(MONTH FROM spine_date) AS period_month
    FROM date_spine
),
date_spine_for_business_days AS (
    SELECT
        dp.period_date,
        dp.period_end_date,
        DATEADD(DAY, gs.SEQ, dp.period_date) AS business_date
    FROM date_periods dp
    CROSS JOIN (
        SELECT SEQ4() AS SEQ
        FROM TABLE(GENERATOR(ROWCOUNT => 400))
    ) gs
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA holidays
        ON DATEADD(DAY, gs.SEQ, dp.period_date) = holidays.DATE
    WHERE DATEADD(DAY, gs.SEQ, dp.period_date) <= dp.period_end_date
      AND DATEADD(DAY, gs.SEQ, dp.period_date) <= (SELECT period_end FROM date_range_config)  -- Only count days within requested range
      AND DATEADD(DAY, gs.SEQ, dp.period_date) >= (SELECT period_start FROM date_range_config)  -- Only count days within requested range
      AND DAYNAME(DATEADD(DAY, gs.SEQ, dp.period_date)) NOT IN ('Sat', 'Sun')
      AND holidays.DATE IS NULL  -- Exclude holidays
),
business_days_per_period AS (
    SELECT
        dp.period_date,
        dp.period_end_date,
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN 1
            ELSE COALESCE(bd_count.business_days, 0)
        END AS business_days
    FROM date_periods dp
    LEFT JOIN (
        SELECT
            period_date,
            COUNT(*) AS business_days
        FROM date_spine_for_business_days
        GROUP BY period_date
    ) bd_count ON dp.period_date = bd_count.period_date
),
productive_hrs AS (
    -- Total Fuse Time Hours per day - Dynamic based on past 90 days from end date
    -- Using logic: (Total System Time - Non Productive Time) / 3600.0 to convert seconds to hours
    SELECT
        ROUND(AVG(
            SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT
            + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0
            + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
        ), 2) AS avg_hrs_per_day
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
      AND u.TOTALSYSTEMTIME IS NOT NULL
      AND u.LOGINDATE BETWEEN DATEADD(day, -90, (SELECT period_end FROM date_range_config)) AND (SELECT period_end FROM date_range_config)
),
avail_fte_by_period AS (
    SELECT
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN TRY_CAST(w.ASOFTODAY AS DATE)
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', TRY_CAST(w.ASOFTODAY AS DATE))
        END AS period_date,
        COUNT(DISTINCT w.EMPLOYEE_DOMAIN_ID) AS available_fte
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT period_start FROM date_range_config) AND (SELECT period_end FROM date_range_config)
    GROUP BY
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN TRY_CAST(w.ASOFTODAY AS DATE)
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', TRY_CAST(w.ASOFTODAY AS DATE))
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', TRY_CAST(w.ASOFTODAY AS DATE))
        END
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.CYCLE_TIME,
        DATE(inv.pxcreatedatetime) AS resolve_date,
        DATE_TRUNC('WEEK', inv.pxcreatedatetime) AS week_start,
        DATE_TRUNC('MONTH', inv.pxcreatedatetime) AS month_start,
        DATE_TRUNC('QUARTER', inv.pxcreatedatetime) AS quarter_start,
        DATE_TRUNC('YEAR', inv.pxcreatedatetime) AS year_start,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS intakesourcesystem,
        ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY inv.pxcommitdatetime DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE pxcreatedatetime >= '{{start_date}}' AND pxcreatedatetime < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND (LOB IN ('Commercial', 'EGR', 'GRS', 'MMP', 'MedSupp', 'Medicaid', 'Medicare') OR LOB IS NULL)
),
avg_cycle_time AS (
    SELECT
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS intakesourcesystem,
        ROUND(AVG(inv.CYCLE_TIME) / 3600.0, 2) AS avg_cycle_time_hrs
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
        WHERE inv.CYCLE_TIME IS NOT NULL
          AND inv.PXCREATEDATETIME BETWEEN DATEADD(DAY, -90, (SELECT period_end FROM date_range_config)) AND DATEADD(DAY, 1, (SELECT period_end FROM date_range_config))
    GROUP BY COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown')
),
actual_receipts_by_period AS (
    -- Completed Items = No of work items resolved in the period (Distinct PYID) by intake source system
    SELECT
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN resolve_date
            WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start
            WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start
        END AS period_date,
        intakesourcesystem,
        COUNT(DISTINCT PYID) AS actual_receipts
    FROM invntry_deduped
    WHERE rn = 1
    GROUP BY
        CASE (SELECT grouping_type FROM grouping_logic)
            WHEN 'daily' THEN resolve_date
            WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start
            WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start
        END,
        intakesourcesystem
),
fte_calculation AS (
    -- Total Fuse Time Hours/day = Dynamic based on past 90 days (Total System Time - Non Productive Time)
    -- For Daily: Total Available Hours per FTE = Total Fuse Time Hours/day * 1 day
    -- For Weekly/Monthly/Quarterly: Total Available Hours per FTE = Total Fuse Time Hours/day * business days in period
    -- Completed Items = No of work items resolved in the period (Distinct PYID)
    -- Total Work Hours Required = Completed Items * Cycle Time (90 days average in hours)
    -- Required FTE = Total Work Hours Required / Total Available Hours per FTE
    SELECT
        ar.period_date,
        ar.intakesourcesystem,
        ar.actual_receipts AS actual_receipts,
        COALESCE(ct.avg_cycle_time_hrs, 0) AS cycle_time_hrs,
        COALESCE((SELECT avg_hrs_per_day FROM productive_hrs), 6.5) AS productive_hrs_per_day,
        bd.business_days,
        af.available_fte,
        -- Total Available Hours per FTE = Total Fuse Time Hours/day * Number of business days
        ROUND(COALESCE((SELECT avg_hrs_per_day FROM productive_hrs), 6.5) * bd.business_days , 2) AS total_available_hrs_per_fte,
        -- Total Work Hours Required = Recieved Items * Cycle Time (hours)
        ROUND(ar.actual_receipts * COALESCE(ct.avg_cycle_time_hrs, 0), 2) AS total_work_hours_required
    FROM actual_receipts_by_period ar
    LEFT JOIN avg_cycle_time ct ON ar.intakesourcesystem = ct.intakesourcesystem
    LEFT JOIN business_days_per_period bd ON ar.period_date = bd.period_date
    LEFT JOIN avail_fte_by_period af ON ar.period_date = af.period_date
),
fte_summary AS (
    SELECT
        fc.period_date,
        -- Aggregate across all intake source systems
        SUM(fc.actual_receipts) AS actual_receipts,
        ROUND(SUM(fc.total_work_hours_required), 2) AS total_work_hours_required,
        MAX(fc.total_available_hrs_per_fte) AS total_available_hrs_per_fte,
        MAX(fc.productive_hrs_per_day) AS productive_hrs_per_day,
        -- Weighted average cycle time
        ROUND(SUM(fc.total_work_hours_required) / NULLIF(SUM(fc.actual_receipts), 0), 2) AS weighted_cycle_time_hrs,
        -- Required FTE = Total Work Hours Required / Total Available Hours per FTE
        CEIL(
            SUM(fc.total_work_hours_required) / NULLIF(MAX(fc.total_available_hrs_per_fte), 0)
        ) AS required_fte
    FROM fte_calculation fc
    GROUP BY fc.period_date
)
SELECT
    CASE (SELECT grouping_type FROM grouping_logic)
        WHEN 'daily' THEN TO_VARCHAR(dp.period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_VARCHAR(dp.period_date, 'MM/DD/YY') || '-' || TO_VARCHAR(dp.period_end_date, 'MM/DD/YY')
        WHEN 'monthly' THEN TO_VARCHAR(dp.period_date, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_VARCHAR(dp.period_date, 'YYYY') || '-Q' || QUARTER(dp.period_date)
        WHEN 'yearly' THEN TO_VARCHAR(dp.period_date, 'YYYY')
    END AS period_label,
    COALESCE(fs.required_fte, 0) AS required_fte,
    -- Available FTE count from Workday (eCOB Specialists in the period)
    COALESCE(af.available_fte, 0) AS available_fte,
    fs.actual_receipts,
    fs.total_work_hours_required,
    fs.productive_hrs_per_day as hours_per_day,
    fs.total_available_hrs_per_fte
FROM date_periods dp
LEFT JOIN fte_summary fs ON dp.period_date = fs.period_date
INNER JOIN avail_fte_by_period af ON dp.period_date = af.period_date
LEFT JOIN business_days_per_period bd ON dp.period_date = bd.period_date
WHERE
    CASE
        WHEN (SELECT grouping_type FROM grouping_logic) = 'daily' THEN
            DAYNAME(dp.period_date) NOT IN ('Sat', 'Sun')
        ELSE TRUE
    END
ORDER BY dp.period_date
"""

AUDIT_MONTH_TO_NUMBER = {
    "JAN": 1, "JANUARY": 1,
    "FEB": 2, "FEBRUARY": 2,
    "MAR": 3, "MARCH": 3,
    "APR": 4, "APRIL": 4,
    "MAY": 5,
    "JUN": 6, "JUNE": 6,
    "JUL": 7, "JULY": 7,
    "AUG": 8, "AUGUST": 8,
    "SEP": 9, "SEPT": 9, "SEPTEMBER": 9,
    "OCT": 10, "OCTOBER": 10,
    "NOV": 11, "NOVEMBER": 11,
    "DEC": 12, "DECEMBER": 12,
}

def get_valid_audit_periods(audit_periods: Optional[List[AuditPeriod]] = None):
    """Validate and sort audit periods."""
    valid_periods = []
    seen = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""
        month_number = AUDIT_MONTH_TO_NUMBER.get(month_value.upper())

        if not month_value or not year_value or month_number is None:
            continue

        try:
            year_number = int(year_value)
        except (TypeError, ValueError):
            continue

        key = (year_number, month_number)
        if key in seen:
            continue

        seen.add(key)
        valid_periods.append({
            "period": period,
            "year_number": year_number,
            "month_number": month_number,
        })

    valid_periods.sort(key=lambda item: (item["year_number"], item["month_number"]))
    return valid_periods

def determine_audit_period_grouping(valid_audit_periods) -> str:
    """Determine grouping type based on number of audit periods."""
    unique_months = {
        (period["year_number"], period["month_number"])
        for period in valid_audit_periods
    }
    if len(unique_months) <= 6:
        return "monthly"

    unique_quarters = {
        (period["year_number"], ((period["month_number"] - 1) // 3) + 1)
        for period in valid_audit_periods
    }
    if len(unique_quarters) <= 6:
        return "quarterly"

    return "yearly"


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "LOGINDATE") -> str:
    if start_date and end_date:
        return f"AND {date_column} >= '{start_date}' AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "USERID") -> str:
    """Build associate filter with flexible column parameter."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{frontline_associate_ids_str}')"
    return ""


def build_associate_filter_coalesce(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter using COALESCE(REASSIGNED_TO, ASSIGNEDTO) pattern."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND COALESCE(REASSIGNED_TO, ASSIGNEDTO) IN ('{frontline_associate_ids_str}')"
    return ""


def execute_query(engine, query: str, limit: int = 100):
    """Synchronous query execution (legacy)."""
    return engine.execute_query(query, limit=limit)


def execute_trend_query(engine, query: str):
    """Synchronous trend query execution (legacy)."""
    return engine.execute_query(query)




def sort_key(item: AuditScoreTrend):
    period = item.period
    # Handle different period formats for sorting
    if '-Q' in period:  # Quarterly: 2024-Q1
        year, quarter = period.split('-Q')
        return (int(year), int(quarter))
    elif len(period) == 7 and '-' in period:  # Monthly: 2024-01
        year, month = period.split('-')
        return (int(year), int(month))
    elif '/' in period and ' - ' in period:  # Weekly: 01/01 - 01/07
        start_date = period.split(' - ')[0]
        month, day = start_date.split('/')
        return (int(month), int(day))
    elif '/' in period:  # Daily: 01/01
        month, day = period.split('/')
        return (int(month), int(day))
    else:  # Yearly: 2024
        return (int(period), 0)


@router.post(
    "/associate-utilization",
    response_model=AssociateUtilizationResponse,
    summary="Get Associate Utilization Metrics",
    description="""
Retrieve associate utilization and capacity metrics for manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Response Fields:**
- **staff_utilization_pct**: Staff utilization percentage (requires Workday integration)
- **capacity_insights**: Capacity insights showing Required FTE vs Available FTE with PTO/UTO deductions
- **total_fuse_time_hours**: Total available hours (Total System Time - Non-Productive Time)
- **total_non_productive_hours**: Total non-productive time in hours
- **ohi_productive_time**: OHI productive time (PRODUCTIVETIME coming 3/27/2026)
- **experience_level_distribution**: Distribution of associates by experience level
- **utilization_trend**: Time-based trend showing utilization metrics over the selected period
- **production_trend**: Time-based trend showing production percentage efficiency against expected standards

**Data Sources:** 
- COB_AI_USER_PROFILE table (utilization and time data)
- COB_AI_INVNTRY_PROFILE table (task and production data)
""",
)
async def get_associate_utilization(request: ManagerAssociateUtilizationRequest) -> AssociateUtilizationResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date, date_column="PXUPDATEDATETIME")
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        manager_filter = build_manager_filter(request.manager_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        associate_filter_invntry = build_associate_filter(request.frontline_associate_ids, column="PYRESOLVEDUSERID")
        associate_filter_coalesce = build_associate_filter_coalesce(request.frontline_associate_ids)
        associate_filter_audit = build_associate_filter(request.frontline_associate_ids, column="AUDIT_SUBJECT_ID")
        associate_filter_workday = build_associate_filter(request.frontline_associate_ids, column="EMPLOYEE_DOMAIN_ID")
        start_date = request.start_date
        end_date = request.end_date
        engine = connection_manager.get_engine()

        fuse_time_query = FUSE_TIME_SUMMARY_QUERY.format(
            start_date=start_date,
            end_date=end_date,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter,
            user_date_filter=user_date_filter
        )
        experience_query = EXPERIENCE_LEVEL_QUERY.format(
            user_date_filter=user_date_filter,
            manager_filter_user=manager_filter_user,
            associate_filter_user=associate_filter_user
        )
        
        # Determine audit mode: audit_period or date_range
        valid_audit_periods = get_valid_audit_periods(request.audit_periods)
        has_audit_periods = bool(valid_audit_periods)
        
        if has_audit_periods:
            # Use audit period query with month/year filtering
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=[period["period"] for period in valid_audit_periods],
                audit_month_column="a.AUDIT_MONTH",
                audit_year_column="a.AUDIT_YEAR",
            )
            grouping_type = determine_audit_period_grouping(valid_audit_periods)
            
            audit_score_trend_query = AUDIT_SCORE_TREND_AUDIT_PERIOD_QUERY.format(
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                audit_period_filter=audit_period_filter,
                grouping_type=grouping_type
            )
        else:
            # Use date range query (legacy mode)
            audit_score_trend_query = AUDIT_SCORE_TREND_QUERY.format(
                start_date=request.start_date,
                end_date=request.end_date,
                lob_filter=lob_filter,
                associate_filter_invntry=associate_filter_invntry,
                manager_filter=manager_filter,
                associate_filter_audit=associate_filter_audit
            )
        
        production_trend_query = PRODUCTION_TREND_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            associate_filter_user=associate_filter_user,
            lob_filter=lob_filter,
            associate_filter_invntry=associate_filter_invntry,
            manager_filter=manager_filter,
            manager_filter_user=manager_filter_user
        )
        
        capacity_insight_query = CAPACITY_INSIGHT_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter_coalesce,
            associate_filter_invntry=associate_filter_invntry,
            associate_filter_user=associate_filter_user,
            associate_filter_workday=associate_filter_workday
        )
        
        # Execute all 5 queries in parallel using async
        logger.info("Executing 5 Manager associate utilization queries in parallel")
        (
            fuse_time_records,
            experience_records,
            audit_score_trend_records,
            production_trend_records,
            capacity_insight_records
        ) = await asyncio.gather(
            engine.execute_query_async(fuse_time_query, limit=1),
            engine.execute_query_async(experience_query, limit=100),
            engine.execute_query_async(audit_score_trend_query, limit=1000),
            engine.execute_query_async(production_trend_query, limit=1000),
            engine.execute_query_async(capacity_insight_query, limit=100),
            return_exceptions=False
        )
        logger.info("Parallel query execution completed")

        total_fuse_time_hours = float(fuse_time_records[0].get("TOTAL_FUSE_TIME_HOURS", 0) or 0) if fuse_time_records else 0.0
        total_non_productive_hours = float(fuse_time_records[0].get("TOTAL_NON_PRODUCTIVE_HOURS", 0) or 0) if fuse_time_records else 0.0
        ohi_productive_time_hours = float(fuse_time_records[0].get("OHI_PRODUCTIVE_TIME_HOURS", 0) or 0) if fuse_time_records else 0.0
        other_time_hours = float(fuse_time_records[0].get("OTHER_TIME_HOURS", 0) or 0) if fuse_time_records else 0.0
        productive_pct = float(fuse_time_records[0].get("PRODUCTIVE_PCT", 0) or 0) if fuse_time_records else 0.0
        non_productive_pct = float(fuse_time_records[0].get("NON_PRODUCTIVE_PCT", 0) or 0) if fuse_time_records else 0.0
        other_pct = float(fuse_time_records[0].get("OTHER_PCT", 0) or 0) if fuse_time_records else 0.0

        experience_level_distribution = [
            ExperienceLevelItem(
                level=r.get("LEVEL", "Unknown"),
                count=int(r.get("COUNT", 0) or 0),
                percentage=float(r.get("PERCENTAGE", 0) or 0)
            )
            for r in experience_records
        ] if experience_records else []
        utilization_trend = [
            AuditScoreTrend(
                period=r.get("PERIOD", ""),
                avg_audit_score=float(r.get("AVG_AUDIT_SCORE", 0) or 0),
                total_cases=int(r.get("TOTAL_CASES_AUDITED", 0) or 0)
            )
            for r in audit_score_trend_records
        ] if audit_score_trend_records else []

        production_trend = [
            ProductionPercentageTrend(
                period=r.get("PERIOD", ""),
                production_percentage=float(r.get("AVG_PRODUCTION_PCT", 0) or 0),
                total_tasks=int(r.get("TOTAL_WORK_ITEMS", 0) or 0)
            )
            for r in production_trend_records
        ] if production_trend_records else []
        
        # Sort capacity insights by date (descending - most recent first)
        capacity_insights = dict(sorted({
            r.get("PERIOD_LABEL", ""): {
                "required_fte": max(int(r.get("REQUIRED_FTE", 0) or 0), 0),
                "available_fte": max(int(float(r.get("AVAILABLE_FTE", 0) or 0)), 0)
            }
            for r in capacity_insight_records
        }.items())) if capacity_insight_records else {}

        utilization_trend.sort(key=sort_key)
        production_trend.sort(key=sort_key)

        tooltips = {
            "staff_utilization_pct": "Percentage of staff time utilized for productive work (requires Workday)",
            "total_fuse_time_hours": "Total available hours (Total System Time - Non-Productive Time)",
            "total_non_productive_hours": "Total non-productive hours (breaks, meetings, etc.)",
            "ohi_productive_time": "OHI system productive time in hours from PRODUCTIVETIME column",
            "other_time_hours": "Other time in hours (calculated as Total - (Productive + Non-Productive))",
            "productive_pct": "Productive time percentage of total fuse time",
            "non_productive_pct": "Non-productive time percentage of total fuse time",
            "other_pct": "Other time percentage of total fuse time",
            "experience_level_distribution": "Distribution of associates by experience level (ramp/learning curve)",
            "utilization_trend": "Utilization trend over time (avg_audit_score=utilization_pct, total_cases=associate_count)",
            "production_trend": "Production percentage trend showing task completion efficiency against expected time standards",
            "capacity_insights": "Capacity insights showing Required FTE vs Available FTE with PTO/UTO deductions based on actual receipts"
        }

        return AssociateUtilizationResponse(
            status="success",
            staff_utilization_pct="N/A",
            total_fuse_time_hours=total_fuse_time_hours,
            total_non_productive_hours=total_non_productive_hours,
            ohi_productive_time=ohi_productive_time_hours,
            other_time_hours=other_time_hours,
            productive_pct=productive_pct,
            non_productive_pct=non_productive_pct,
            other_pct=other_pct,
            experience_level_distribution=experience_level_distribution,
            utilization_trend=utilization_trend,
            production_trend=production_trend,
            capacity_insights=capacity_insights,
            message="Associate utilization metrics retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Associate utilization query error: {type(e).__name__}: {str(e)}")
        return AssociateUtilizationResponse(
            status="error",
            staff_utilization_pct="N/A",
            total_fuse_time_hours=0.0,
            total_non_productive_hours=0.0,
            ohi_productive_time=0.0,
            other_time_hours=0.0,
            productive_pct=0.0,
            non_productive_pct=0.0,
            other_pct=0.0,
            experience_level_distribution=[],
            utilization_trend=[],
            production_trend=[],
            capacity_insights={},
            message=f"Failed to retrieve associate utilization metrics: {str(e)}"
        )
