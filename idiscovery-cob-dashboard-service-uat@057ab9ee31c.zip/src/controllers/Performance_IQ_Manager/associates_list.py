import logging
from fastapi import APIRouter, HTTPException
from typing import Optional, List

from db import SnowflakeConnectionManager
from schema import AssociateListRequest, AssociateListResponse, AssociateItem
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
from utils import cache_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()

ASSOCIATES_LIST_QUERY = f"""
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYREPORTTO
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID IS NOT NULL 
        AND PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
)
SELECT DISTINCT
    frontline.USERID AS ASSOCIATE_ID,
    frontline.USERNAME AS ASSOCIATE_NAME
FROM frontline
WHERE 1=1
{{manager_filter}}
ORDER BY frontline.USERNAME
"""




def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    if manager_ids and len(manager_ids) > 0:
        manager_list = "', '".join(manager_ids)
        return f"AND frontline.PYREPORTTO IN ('{manager_list}')"
    return ""


@router.post(
    "/associates-list",
    response_model=AssociateListResponse,
    summary="Get List of Frontline Associates",
    description="""
Retrieve list of frontline associates for filter dropdown with search capability.
Shows all associates who logged in within the last 1 year.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **manager_ids** (optional): Filter associates by manager's ID
- **search** (optional): Search term to filter associates by ID or name
- **limit** (optional): Maximum number of results (default: 1000, max: 5000)

**Response Fields:**
- **associates**: List of associates with ID, name, manager, and experience level
- **total_count**: Total number of associates returned

**Data Source:** COB_AI_USER_PROFILE table (filtered to last 1 year of login activity)
**Caching:** Results cached for 6 hours (21,600s)
""",
)
async def get_associates_list(request: AssociateListRequest) -> AssociateListResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    # Build cache key
    cache_key = cache_manager.build_key(
        "associates:list",
        manager_ids=",".join(request.manager_ids or []),
        search=request.search or "",
        limit=request.limit
    )
    
    async def fetch_from_db():
        """Fetch associates list from Snowflake."""
        try:
            engine = connection_manager.get_engine()
            manager_filter = build_manager_filter(request.manager_ids)
            
            query = ASSOCIATES_LIST_QUERY.format(
                manager_filter=manager_filter
            )
            records = await engine.execute_query_async(query, limit=request.limit)

            associates = [
                {
                    "associate_id": r.get("ASSOCIATE_ID", ""),
                    "associate_name": r.get("ASSOCIATE_NAME"),
                    "manager_name": "",
                    "experience_level": ""
                }
                for r in records
                if r.get("ASSOCIATE_ID")
            ] if records else []

            return {
                "status": "success",
                "associates": associates,
                "total_count": len(associates),
                "message": "Associates list retrieved successfully"
            }

        except Exception as e:
            logger.error(f"Associates list query error: {type(e).__name__}: {str(e)}")
            return {
                "status": "error",
                "associates": [],
                "total_count": 0,
                "message": f"Failed to retrieve associates list: {str(e)}"
            }
    
    # Get from cache or fetch from DB (6 hour TTL)
    result = await cache_manager.get_or_fetch(cache_key, fetch_from_db, ttl=METRIC_CACHE_TTL)
    
    # Convert dict to response model
    associates = [AssociateItem(**a) for a in result["associates"]]
    return AssociateListResponse(
        status=result["status"],
        associates=associates,
        total_count=result["total_count"],
        message=result["message"]
    )
