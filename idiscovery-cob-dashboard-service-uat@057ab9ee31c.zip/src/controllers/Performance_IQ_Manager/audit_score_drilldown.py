import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import (
    AuditScoreManagerDrilldownRequest,
    AuditScoreDrilldownPaginatedResponse,
    AuditScoreRecord,
    PageResponse,
    ManagerBaseDownloadRequest,
    AuditPeriod,
)
import math
import config

def build_audit_month_year_filter(
    audit_periods: Optional[List[AuditPeriod]] = None,
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    """Build SQL filter for audit month/year periods."""
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append((month_value, year_value))

    if not valid_periods:
        return ""

    conditions = [
        f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
        for month, year in valid_periods
    ]

    return "AND (" + " OR ".join(conditions) + ")"

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return "N/A"
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def clean_resolved_status(status: str) -> str:
    """Convert 'Resolved-Completed' to 'Resolved'"""
    if not status:
        return "N/A"
    return "Resolved" if status.startswith("Resolved") else status

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()


AUDIT_SCORE_MANAGER_PAGINATED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        INVNTRY_TYPE,
        CYCLE_TIME,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        UPPER(TRIM(LOB)) AS LOB,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        AUDIT_SCORE,
        TARGET_AUDIT,
        INTAKESOURCESYSTEM,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        UPPER(TRIM(LOB)) AS LOB,
        PXUPDATEDATETIME::DATE as audit_date,
        PLATFORM,
        AUDIT_MONTH,
        AUDIT_YEAR,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
)
SELECT 
    a.PYID,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK,
    a.LOB,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    i.CYCLE_TIME,
    i.INVNTRY_TYPE,
    a.AUDIT_MONTH,
    a.AUDIT_YEAR
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
  AND i.PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
  AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
  {{invntry_date_filter}}
  {{invntry_lob_filter}}
  {{associate_filter_invntry}}
  {{manager_filter}}
  AND a.AUDIT_SCORE IS NOT NULL
  AND a.PYID LIKE 'AUD%'
  AND a.PYSTATUSWORK IN (
        'OPEN-FEEDBACKREVIEW',
        'OPEN-REBUTTALREVIEW',
        'OPEN-UPDATEAUDITCASE',
        'RESOLVED-COMPLETED'
  )
  {{lob_filter}}
  {{associate_filter_audit}}
ORDER BY a.audit_date DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

AUDIT_SCORE_MANAGER_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDTIMESTAMP,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        UPPER(TRIM(LOB)) AS LOB,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
),
audit_deduped AS (
    SELECT 
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        PXUPDATEDATETIME::DATE as audit_date,
        TARGET_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        UPPER(TRIM(LOB)) AS LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
)
SELECT 
    COUNT(DISTINCT a.PYID) as TOTAL_COUNT,
    SUM(CASE WHEN UPPER(a.TARGET_AUDIT) = 'YES' THEN 1 ELSE 0 END) as TARGET_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
  AND i.PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
  AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
  {{invntry_date_filter}}
  {{invntry_lob_filter}}
  {{associate_filter_invntry}}
  {{manager_filter}}
  AND a.PYID LIKE 'AUD%'
  AND a.PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'OPEN-REBUTTALREVIEW', 'OPEN-UPDATEAUDITCASE', 'RESOLVED-COMPLETED')
  {{lob_filter}}
  {{associate_filter_audit}}
"""

AUDIT_SCORE_MANAGER_PAGINATED_AUDIT_PERIOD_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        a.PYID,
        a.CASE_TO_AUDIT,
        UPPER(TRIM(a.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(a.AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.INTAKESOURCESYSTEM,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        UPPER(TRIM(a.LOB)) AS LOB,
        a.PXUPDATEDATETIME::DATE AS audit_date,
        a.PLATFORM,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
),
latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        INVNTRY_TYPE,
        CYCLE_TIME,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
)
SELECT
    a.PYID,
    a.INTAKESOURCESYSTEM,
    a.PYSTATUSWORK,
    COALESCE(a.LOB, 'N/A') AS LOB,
    a.audit_date,
    a.AUDIT_SUBJECT_ID,
    a.AUDIT_SCORE,
    a.PLATFORM,
    a.TARGET_AUDIT,
    i.CYCLE_TIME,
    i.INVNTRY_TYPE,
    COALESCE(a.AUDIT_MONTH, 'N/A') AS AUDIT_MONTH,
    COALESCE(a.AUDIT_YEAR, 'N/A') AS AUDIT_YEAR
FROM audit_deduped a
LEFT JOIN latest_inventory i
  ON i.PYID = a.CASE_TO_AUDIT
 AND i.rn = 1
WHERE a.rn = 1
  AND a.PYID LIKE 'AUD%'
  AND a.AUDIT_SCORE IS NOT NULL
  AND a.AUDIT_SCORE > 0
  AND a.PYSTATUSWORK IN (
        'OPEN-FEEDBACKREVIEW',
        'OPEN-REBUTTALREVIEW',
        'OPEN-UPDATEAUDITCASE',
        'RESOLVED-COMPLETED',
        'RESOLVED-AUTOCLOSE'
  )
  {{manager_filter}}
  {{associate_filter_audit}}
  {{lob_filter_audit}}
  {{audit_period_filter}}
ORDER BY a.audit_date DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

AUDIT_SCORE_MANAGER_COUNT_AUDIT_PERIOD_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        a.PYID,
        a.CASE_TO_AUDIT,
        UPPER(TRIM(a.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(a.AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        a.AUDIT_SCORE,
        a.TARGET_AUDIT,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.LOB)) AS LOB,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
),
latest_inventory AS (
    SELECT
        PYID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
)
SELECT
    COUNT(DISTINCT a.PYID) AS TOTAL_COUNT,
    COUNT(DISTINCT CASE WHEN UPPER(TRIM(a.TARGET_AUDIT)) = 'YES' THEN a.PYID END) AS TARGET_AUDIT_COUNT
FROM audit_deduped a
LEFT JOIN latest_inventory i
  ON i.PYID = a.CASE_TO_AUDIT
 AND i.rn = 1
WHERE a.rn = 1
  AND a.PYID LIKE 'AUD%'
  AND a.AUDIT_SCORE IS NOT NULL
  AND a.AUDIT_SCORE > 0
  AND a.PYSTATUSWORK IN (
        'OPEN-FEEDBACKREVIEW',
        'OPEN-REBUTTALREVIEW',
        'OPEN-UPDATEAUDITCASE',
        'RESOLVED-COMPLETED',
        'RESOLVED-AUTOCLOSE'
  )
  {{manager_filter}}
  {{associate_filter_audit}}
  {{lob_filter_audit}}
  {{audit_period_filter}}
"""

AUDIT_SCORE_DEFAULT_ORDER_BY = "ORDER BY a.audit_date DESC"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "pyid": "a.PYID",
        "work_type": "a.INTAKESOURCESYSTEM",
        "audit_cycle_time": "i.CYCLE_TIME",
        "resolved_status": "a.PYSTATUSWORK",
        "lob": "a.LOB",
        "audit_resolved": "a.audit_date",
        "auditor_domain_id": "a.AUDIT_SUBJECT_ID",
        "platform": "a.PLATFORM",
        "audit_score": "a.AUDIT_SCORE",
        "targeted_audit_type": "a.TARGET_AUDIT",
        "inventory_type": "i.INVNTRY_TYPE",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return AUDIT_SCORE_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, a.PYID"


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for audit table with a. prefix (used in date range queries)."""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l.strip().upper() for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (UPPER(TRIM(a.LOB)) IN ('{lob_values}') OR a.LOB IS NULL)"
    elif null_requested:
        return "AND a.LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND UPPER(TRIM(a.LOB)) IN ('{lob_values}')"


def build_lob_filter_audit(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for audit table with a. prefix."""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l.strip().upper() for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (UPPER(TRIM(a.LOB)) IN ('{lob_values}') OR a.LOB IS NULL)"
    elif null_requested:
        return "AND a.LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND UPPER(TRIM(a.LOB)) IN ('{lob_values}')"


def build_invntry_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for inventory table with i. prefix"""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l.strip().upper() for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (UPPER(TRIM(i.LOB)) IN ('{lob_values}') OR i.LOB IS NULL)"
    elif null_requested:
        return "AND i.LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND UPPER(TRIM(i.LOB)) IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None, date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    """Build date filter for date range queries."""
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_invntry_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for inventory table (PYRESOLVEDTIMESTAMP)."""
    if start_date and end_date:
        return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND PYRESOLVEDTIMESTAMP::DATE >= '{start_date}'"
    elif end_date:
        return f"AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_user_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Filter for user profile LOGINDATE"""
    if start_date and end_date:
        return f"AND LOGINDATE >= '{start_date}' AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""

def build_manager_filter_audit(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for audit table using AUDIT_SUBJECT_MGR_ID."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND a.AUDIT_SUBJECT_MGR_ID IN ('{manager_ids_str}')"
    return ""

def build_associate_filter_audit(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for audit table using AUDIT_SUBJECT_ID."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND a.AUDIT_SUBJECT_ID IN ('{associate_ids_str}')"
    return ""

def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""

def build_associate_filter_user(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for COB_AI_USER_PROFILE table (uses USERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND USERID IN ('{frontline_associate_ids_str}')"
    return ""


@router.post(
    "/audit-score-manager-drilldown",
    response_model=AuditScoreDrilldownPaginatedResponse,
    summary="Get Audit Score Manager Drilldown",
    description="""
Retrieve paginated list of audit scores with manager-auditor relationship aggregation for manager-level view.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **pyid**: Unique audited case identifier
- **work_type**: Source system type
- **audit_cycle_time**: Days from creation to audit
- **resolved_status**: Case status
- **lob**: Line of Business
- **audit_resolved**: Audit completion date (MM/DD/YYYY format)
- **auditor_domain_id**: Auditor's user ID
- **platform**: Processing platform
- **audit_score**: Quality score as percentage (e.g., '95%')
- **targeted_audit_type**: Type of audit (targeted vs random)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (audit data)
- COB_AI_INVNTRY_PROFILE (cycle time)
- COB_AI_USER_PROFILE (manager-associate relationships)
""",
)
async def get_audit_score_manager_drilldown(
    request: AuditScoreManagerDrilldownRequest
) -> AuditScoreDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        lob_filter = build_lob_filter(lob)
        lob_filter_audit = build_lob_filter_audit(lob)
        invntry_lob_filter = build_invntry_lob_filter(lob)
        date_filter = build_date_filter(start_date, end_date)
        invntry_date_filter = build_invntry_date_filter(start_date, end_date)
        manager_filter = build_manager_filter(manager_ids)
        manager_filter_audit = build_manager_filter_audit(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        associate_filter_audit = build_associate_filter_audit(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        # Determine audit mode: audit_period or date_range
        valid_audit_periods = [
            period
            for period in (request.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)
        
        if has_audit_periods:
            # Use audit period query with month/year filtering
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="a.AUDIT_MONTH",
                audit_year_column="a.AUDIT_YEAR",
            )
            
            count_query = AUDIT_SCORE_MANAGER_COUNT_AUDIT_PERIOD_QUERY.format(
                lob_filter_audit=lob_filter_audit,
                manager_filter=manager_filter,
                associate_filter_audit=associate_filter_audit,
                audit_period_filter=audit_period_filter
            )
            
            data_query = AUDIT_SCORE_MANAGER_PAGINATED_AUDIT_PERIOD_QUERY.format(
                lob_filter_audit=lob_filter_audit,
                manager_filter=manager_filter,
                associate_filter_audit=associate_filter_audit,
                audit_period_filter=audit_period_filter,
                limit=page_limit,
                offset=offset
            )
        else:
            # Use date range query (legacy mode)
            count_query = AUDIT_SCORE_MANAGER_COUNT_QUERY.format(
                invntry_date_filter=invntry_date_filter,
                invntry_lob_filter=invntry_lob_filter,
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                associate_filter_audit=associate_filter_audit
            )
            
            data_query = AUDIT_SCORE_MANAGER_PAGINATED_QUERY.format(
                invntry_date_filter=invntry_date_filter,
                invntry_lob_filter=invntry_lob_filter,
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                associate_filter_audit=associate_filter_audit,
                limit=page_limit,
                offset=offset
            )
        
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = int(count_result[0].get("TOTAL_COUNT") or 0) if count_result else 0
        target_audit_count = int(count_result[0].get("TARGET_AUDIT_COUNT") or 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        data_query = data_query.replace(
            AUDIT_SCORE_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        audit_scores = [
            AuditScoreRecord(
                pyid=record.get("PYID") or "N/A",
                work_type=record.get("INTAKESOURCESYSTEM") or "N/A",
                audit_cycle_time=format_cycle_time(record.get("CYCLE_TIME")),
                resolved_status=clean_resolved_status(record.get("PYSTATUSWORK")),
                lob=record.get("LOB") or "N/A",
                audit_resolved=format_date_mmddyyyy(record.get("AUDIT_DATE")),
                auditor_domain_id=record.get("AUDIT_SUBJECT_ID") or "N/A",
                platform=record.get("PLATFORM") or "N/A",
                audit_score=f"{int(record.get('AUDIT_SCORE'))}%" if record.get("AUDIT_SCORE") else "0%",
                targeted_audit_type=record.get("TARGET_AUDIT") or "N/A",
                inventory_type=record.get("INVNTRY_TYPE") or "N/A",
                audit_month=str(record.get("AUDIT_MONTH") or "N/A"),
                audit_year=str(record.get("AUDIT_YEAR") or "N/A")
            )
            for record in records
        ] if records else []

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "pyid": "Unique identifier for the audited case",
            "work_type": "Source system or type of work item that was audited",
            "audit_cycle_time": "Time from case creation to audit completion in hh:mm:ss format",
            "resolved_status": "Current status of the audited work item",
            "lob": "Line of Business associated with the audited case",
            "audit_resolved": "Date when the audit was completed",
            "auditor_domain_id": "User ID of the auditor who performed the audit",
            "platform": "Platform where the case was processed",
            "audit_score": "Quality score achieved for this audit as a percentage",
            "targeted_audit_type": "Type of audit performed (targeted vs random)",
            "inventory_type": "Type of inventory or work category",
            "audit_month": "Audit month associated with the audited case",
            "audit_year": "Audit year associated with the audited case",
            "target_audit_count": "Number of audits flagged as targeted for managers' associates in the selected period"
        }

        return AuditScoreDrilldownPaginatedResponse(
            status="success",
            screen_id="audit_score_manager",
            user_id=request.user_id,
            page=page_response,
            records=audit_scores,
            completed_audit_work_items=total_records,
            target_audit_count=target_audit_count,
            message="Audit score manager records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated audit score manager drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return AuditScoreDrilldownPaginatedResponse(
            status="error",
            screen_id="audit_score_manager",
            user_id=request.user_id,
            page=page_response,
            records=[],
            completed_audit_work_items=0,
            target_audit_count=0,
            message=f"Failed to retrieve audit score manager records: {str(e)}"
        )


@router.post(
    "/audit-score-manager-drilldown/download-excel",
    summary="Download Audit Score Manager Drilldown as Excel",
    description="""
Download complete audit score manager drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all audit score records
""",
)
async def download_audit_score_manager_drilldown_excel(
    request: ManagerBaseDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        date_filter = build_date_filter(request.start_date, request.end_date)
        invntry_date_filter = build_invntry_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(lob)
        lob_filter_audit = build_lob_filter_audit(lob)
        invntry_lob_filter = build_invntry_lob_filter(lob)
        manager_filter = build_manager_filter(manager_ids)
        manager_filter_audit = build_manager_filter_audit(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        associate_filter_audit = build_associate_filter_audit(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        # Determine audit mode: audit_period or date_range
        valid_audit_periods = [
            period
            for period in (request.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)
        
        if has_audit_periods:
            # Use audit period query with month/year filtering
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="a.AUDIT_MONTH",
                audit_year_column="a.AUDIT_YEAR",
            )
            
            download_query = AUDIT_SCORE_MANAGER_PAGINATED_AUDIT_PERIOD_QUERY.format(
                lob_filter_audit=lob_filter_audit,
                manager_filter=manager_filter,
                associate_filter_audit=associate_filter_audit,
                audit_period_filter=audit_period_filter,
                limit=config.CACHE_FULL_DATASET_LIMIT,
                offset=0
            )
        else:
            # Use date range query (legacy mode)
            download_query = AUDIT_SCORE_MANAGER_PAGINATED_QUERY.format(
                invntry_date_filter=invntry_date_filter,
                invntry_lob_filter=invntry_lob_filter,
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                associate_filter_audit=associate_filter_audit,
                limit=config.CACHE_FULL_DATASET_LIMIT,
                offset=0
            )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Audit Score Manager"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Audit Cycle Time",
            "Audit Status",
            "Inventory Type",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Platform",
            "Audit Score",
            "Targeted Audit Type"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("PYID", "")))  # Work Item
            ws.cell(row=row_num, column=2, value=str(row.get("INTAKESOURCESYSTEM", "")))  # Work Type
            ws.cell(row=row_num, column=3, value=format_cycle_time(row.get("CYCLE_TIME")))  # Audit Cycle Time
            ws.cell(row=row_num, column=4, value=clean_resolved_status(str(row.get("PYSTATUSWORK", ""))))  # Audit Status
            ws.cell(row=row_num, column=5, value=str(row.get("INVNTRY_TYPE", "N/A")))  # Inventory Type
            ws.cell(row=row_num, column=6, value=str(row.get("LOB", "")))  # LOB
            ws.cell(row=row_num, column=7, value=format_date_mmddyyyy(str(row.get("AUDIT_DATE", ""))) if row.get("AUDIT_DATE") else "")  # Audit Date
            ws.cell(row=row_num, column=8, value=str(row.get("AUDIT_MONTH", "N/A")))  # Audit Month
            ws.cell(row=row_num, column=9, value=int(row.get("AUDIT_YEAR")) if row.get("AUDIT_YEAR") not in (None, "", "N/A") else "")  # Audit Year
            ws.cell(row=row_num, column=10, value=str(row.get("PLATFORM", "")))  # Platform
            ws.cell(row=row_num, column=11, value=float(row.get("AUDIT_SCORE")) if row.get("AUDIT_SCORE") not in (None, "", "N/A") else "")  # Audit Score
            ws.cell(row=row_num, column=12, value=str(row.get("TARGET_AUDIT", "")))  # Targeted Audit Type
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"audit_score_manager_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for audit score manager drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
