import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from schema import (
    CompletedAuditCountDrilldownPaginatedRequest,
    CompletedAuditCountDrilldownPaginatedResponse,
    CompletedAuditCountRecord,
    PageResponse,
    ManagerBaseDownloadRequest,
    AuditPeriod,
)
import math
from controllers.Performance_IQ_Manager.quality_outcomes import (
    COMPLETED_AUDIT_COUNT_QUERY,
    COMPLETED_AUDIT_COUNT_AUDIT_PERIOD_QUERY,
)

def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])
connection_manager = SnowflakeConnectionManager()


COMPLETED_AUDIT_COUNT_MANAGER_PAGINATED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        AUDIT_SUBJECT_ID,
        AUDITOR_ID,
        AUDIT_MONTH,
        AUDIT_YEAR,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
),
deduped_user_profile AS (
    SELECT
        USERID,
        PYREPORTTO,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
audit_cycle_time AS (
    SELECT
        PYRESOLVEDUSERID,
        MAX(CYCLE_TIME) AS CYCLE_TIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE CYCLE_TIME IS NOT NULL
    GROUP BY PYRESOLVEDUSERID
)
SELECT 
    a.PYID AS work_item,
    COALESCE(a.INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
    COALESCE(c.CYCLE_TIME::VARCHAR, '0') AS audit_cycle_time,
    COALESCE(a.PYSTATUSWORK, 'N/A') AS audit_resolved_status,
    COALESCE(a.INVNTRY_TYPE, 'N/A') AS inventory_type,
    COALESCE(a.LOB, 'N/A') AS lob,
    COALESCE(TO_CHAR(a.PYRESOLVEDTIMESTAMP, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
    COALESCE(a.AUDITOR_ID, 'N/A') AS auditor_id,
    COALESCE(auditor.USERNAME, 'N/A') AS auditor_name,
    COALESCE(a.PLATFORM, 'N/A') AS platform_source_system,
    COALESCE(a.AUDIT_MONTH, 'N/A') AS audit_month,
    COALESCE(a.AUDIT_YEAR, 'N/A') AS audit_year,
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
LEFT JOIN deduped_user_profile auditor
    ON a.AUDITOR_ID = auditor.USERID
    AND auditor.rn = 1
LEFT JOIN audit_cycle_time c
    ON a.AUDIT_SUBJECT_ID = c.PYRESOLVEDUSERID
WHERE i.rn = 1
ORDER BY a.PYRESOLVEDTIMESTAMP DESC
LIMIT {{page_size}} OFFSET {{offset}}
"""

COMPLETED_AUDIT_COUNT_MANAGER_AUDIT_PERIOD_PAGINATED_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        UPPER(TRIM(AUDITOR_ID)) AS AUDITOR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND CASE_TO_AUDIT IS NOT NULL
),
completion_candidates AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        AUDITOR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK,
        PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY
                CASE
                    WHEN PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base
    WHERE PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        INTAKESOURCESYSTEM,
        INVNTRY_TYPE,
        LOB,
        PLATFORM,
        AUDITOR_ID,
        AUDITCYCLETIME,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
filtered_completion AS (
    SELECT
        c.PYID,
        c.INTAKESOURCESYSTEM,
        c.INVNTRY_TYPE,
        c.LOB,
        c.PLATFORM,
        c.AUDITOR_ID,
        c.AUDITCYCLETIME,
        c.AUDIT_MONTH,
        c.AUDIT_YEAR,
        c.completion_status,
        c.completion_ts
    FROM completion_event c
    INNER JOIN filtered_inventory i
        ON c.CASE_TO_AUDIT = i.ORIGINAL_OHI_CASE_ID
    WHERE 1 = 1
      {{audit_period_filter}}
      {{lob_filter}}
      {{associate_filter}}
),
final_base AS (
    SELECT
        c.PYID AS work_item,
        COALESCE(c.INTAKESOURCESYSTEM, 'N/A') AS worktype_category,
        COALESCE(c.AUDITCYCLETIME, 0) AS raw_audit_cycle_time,
        COALESCE(c.AUDITCYCLETIME::VARCHAR, '0') AS audit_cycle_time,
        CASE
            WHEN c.completion_status = 'OPEN-FEEDBACKREVIEW' THEN 'Open-FeedbackReview'
            WHEN c.completion_status = 'RESOLVED-COMPLETED' THEN 'Resolved-Completed'
            ELSE COALESCE(c.completion_status, 'N/A')
        END AS audit_resolved_status,
        COALESCE(c.INVNTRY_TYPE, 'N/A') AS inventory_type,
        COALESCE(c.LOB, 'N/A') AS lob,
        COALESCE(TO_CHAR(c.completion_ts, 'MM/DD/YYYY'), 'N/A') AS audit_resolved_date,
        COALESCE(c.AUDITOR_ID, 'N/A') AS auditor_id,
        COALESCE(auditor.USERNAME, 'N/A') AS auditor_name,
        COALESCE(c.PLATFORM, 'N/A') AS platform_source_system,
        COALESCE(c.AUDIT_MONTH, 'N/A') AS audit_month,
        COALESCE(c.AUDIT_YEAR, 'N/A') AS audit_year,
        c.completion_ts
    FROM filtered_completion c
    LEFT JOIN deduped_user_profile auditor
        ON c.AUDITOR_ID = auditor.USERID
       AND auditor.rn = 1
)
SELECT
    work_item,
    worktype_category,
    audit_cycle_time,
    audit_resolved_status,
    inventory_type,
    lob,
    audit_resolved_date,
    auditor_id,
    auditor_name,
    platform_source_system,
    audit_month,
    audit_year
FROM final_base
ORDER BY completion_ts DESC
LIMIT {{page_size}} OFFSET {{offset}}
"""

COMPLETED_AUDIT_COUNT_MANAGER_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        LOB,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM invntry_deduped i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
WHERE i.rn = 1
"""

DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY = "completion_ts DESC"
DISPLAY_COMPLETED_AUDIT_RESOLVED_DATE_SQL = "DATE(completion_ts)"

SORTABLE_COMPLETED_AUDIT_COUNT_COLUMNS = {
    "work_item": "work_item",
    "worktype_category": "worktype_category",
    "audit_cycle_time": "COALESCE(raw_audit_cycle_time, 0)",
    "audit_resolved_status": "audit_resolved_status",
    "inventory_type": "inventory_type",
    "lob": "lob",
    "audit_resolved_date": DISPLAY_COMPLETED_AUDIT_RESOLVED_DATE_SQL,
    "auditor_id": "auditor_id",
    "auditor_name": "auditor_name",
    "platform_source_system": "platform_source_system",
    "audit_month": "audit_month",
    "audit_year": "audit_year",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_COMPLETED_AUDIT_COUNT_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid completed audit count sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid completed audit count sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "audit_resolved_date":
        tie_breakers.append("completion_ts DESC")
    if normalized_sort_by != "work_item":
        tie_breakers.append("work_item ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_completed_audit_count_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_COMPLETED_AUDIT_COUNT_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )


def build_lob_filter(lob: Optional[List[str]] = None, column_name: str = "a.LOB") -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND ({column_name} IN ('{lob_values}') OR {column_name} IS NULL)"
    elif null_requested:
        return f"AND {column_name} IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND {column_name} IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "a.PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_id.strip().upper() for manager_id in manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_audit_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_id.strip().upper() for manager_id in manager_ids)
        return f"AND AUDIT_SUBJECT_MGR_ID IN ('{manager_ids_str}')"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "AUDIT_SUBJECT_ID") -> str:
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(associate_id.strip().upper() for associate_id in frontline_associate_ids)
        return f"AND {column} IN ('{frontline_associate_ids_str}')"
    return ""


def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(associate_id.strip().upper() for associate_id in frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""


def build_audit_month_year_filter(
    audit_periods: Optional[List[AuditPeriod]] = None,
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append((month_value, year_value))

    if not valid_periods:
        return ""

    conditions = [
        f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
        for month, year in valid_periods
    ]

    return "AND (" + " OR ".join(conditions) + ")"


@router.post(
    "/completed-audit-count-drilldown",
    response_model=CompletedAuditCountDrilldownPaginatedResponse,
    summary="Get Completed Audit Count Drilldown (Manager)",
    description="""
Retrieve paginated list of completed audit counts for detailed table display (Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs (not used for filtering in Manager APIs)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item**: Work Item ID
- **worktype_category**: Worktype Category (e.g., Newborn, Compass, Claims Request, HEW)
- **audit_cycle_time**: Audit Cycle Time (e.g., 00:20:00)
- **audit_resolved_status**: Audit Resolved Status (e.g., Resolved)
- **inventory_type**: Inventory Type (e.g., GB, CB)
- **lob**: Line of Business (e.g., Medicaid, Medicare, Commercial)
- **audit_resolved_date**: Audit Resolved Date (MM/DD/YYYY format)
- **auditor_id**: Auditor ID (unique identifier)
- **auditor_name**: Auditor Name (e.g., Susan Jones)
- **platform_source_system**: Platform - Source System (e.g., Sample Name)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Source:** COB_AI_AUDIT_PROFILE, COB_AI_USER_PROFILE, COB_AI_INVNTRY_PROFILE for cycle time calculation
""",
)
async def get_completed_audit_count_drilldown(
    request: CompletedAuditCountDrilldownPaginatedRequest
) -> CompletedAuditCountDrilldownPaginatedResponse:
    
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit

        lob_filter = build_lob_filter(request.lob, "LOB")
        date_filter = build_date_filter(request.start_date, request.end_date, "PYRESOLVEDTIMESTAMP")

        manager_ids = request.manager_ids if request.manager_ids else [request.user_id]
        manager_filter = build_manager_filter(manager_ids)
        audit_manager_filter = build_audit_manager_filter(manager_ids)

        associate_filter = build_associate_filter(request.frontline_associate_ids, "AUDIT_SUBJECT_ID")
        associate_filter_invntry = build_associate_filter_invntry(request.frontline_associate_ids)

        valid_audit_periods = [
            period
            for period in (request.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)

        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="AUDIT_MONTH",
                audit_year_column="AUDIT_YEAR",
            )

            count_query = COMPLETED_AUDIT_COUNT_AUDIT_PERIOD_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )

            paginated_query = COMPLETED_AUDIT_COUNT_MANAGER_AUDIT_PERIOD_PAGINATED_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                page_size=page_limit,
                offset=offset,
            )
        else:
            count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter,
                associate_filter_invntry=associate_filter_invntry,
            )

            paginated_query = COMPLETED_AUDIT_COUNT_MANAGER_PAGINATED_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter,
                associate_filter_invntry=associate_filter_invntry,
                page_size=page_limit,
                offset=offset,
            )

        engine = connection_manager.get_engine()

        total_records = 0
        session_id = getattr(request, "session_id", None)

        if session_id and config.REDIS_ENABLED:
            try:
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'manager_ids': manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                cache_key = f"session:{session_id}:{filters_hash}:completed_audit_count"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)

                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    total_records = int(cached_metric[0].get("COMPLETED_AUDIT_COUNT", 0))
                    logger.info(f"✅ Reused cached completed audit count: {total_records} (from quality-outcomes)")
                else:
                    logger.info("Cache miss for completed_audit_count, running COUNT query")
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = int(count_result[0].get("COMPLETED_AUDIT_COUNT", 0)) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached completed audit count: {e}, falling back to COUNT query")
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = int(count_result[0].get("COMPLETED_AUDIT_COUNT", 0)) if count_result else 0
        else:
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = int(count_result[0].get("COMPLETED_AUDIT_COUNT", 0)) if count_result else 0

        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0

        paginated_query = apply_custom_sort_to_completed_audit_count_query(
            paginated_query,
            request.sort_by,
            request.sort_direction,
        )
        records = await engine.execute_query_async(paginated_query, limit=page_limit)

        completed_audit_records = [
            CompletedAuditCountRecord(
                work_item=record.get("WORK_ITEM", "N/A"),
                worktype_category=record.get("WORKTYPE_CATEGORY", "N/A"),
                audit_cycle_time=format_cycle_time(record.get("AUDIT_CYCLE_TIME")),
                audit_resolved_status=record.get("AUDIT_RESOLVED_STATUS", "N/A"),
                inventory_type=record.get("INVENTORY_TYPE", "N/A"),
                lob=record.get("LOB", "N/A"),
                audit_resolved_date=record.get("AUDIT_RESOLVED_DATE", "N/A"),
                auditor_id=record.get("AUDITOR_ID", "N/A"),
                auditor_name=record.get("AUDITOR_NAME", "N/A"),
                platform_source_system=record.get("PLATFORM_SOURCE_SYSTEM", "N/A"),
                audit_month=record.get("AUDIT_MONTH", "N/A"),
                audit_year=record.get("AUDIT_YEAR", "N/A"),
            )
            for record in records
        ]

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the audit work item (PYID starting with 'AUD')",
            "worktype_category": "Category of work type being audited (INTAKESOURCESYSTEM)",
            "audit_cycle_time": "Audit cycle time in hh:mm:ss format",
            "audit_resolved_status": "Status of the audit resolution",
            "inventory_type": "Type of inventory classification (INVNTRY_TYPE)",
            "lob": "Line of Business classification (Medicaid, Medicare, Commercial)",
            "audit_resolved_date": "Date when the audit was resolved",
            "auditor_id": "Unique identifier of the auditor who performed the audit (AUDITOR_ID)",
            "auditor_name": "Name of the auditor who completed the audit",
            "platform_source_system": "Platform or source system where the audit was processed (PLATFORM)",
            "audit_month": "Audit month associated with the audit case",
            "audit_year": "Audit year associated with the audit case"
        }

        return CompletedAuditCountDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=completed_audit_records,
            message="Completed audit count records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated completed audit count drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return CompletedAuditCountDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve completed audit count records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/completed-audit-count-drilldown/download-excel",
    summary="Download Completed Audit Count Drilldown as Excel (Manager)",
    description="""
Download complete audit count drilldown data as an Excel file (Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all completed audit count records
""",
)
async def download_completed_audit_count_drilldown_excel(
    request: ManagerBaseDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"

        lob_filter = build_lob_filter(request.lob, "LOB")
        date_filter = build_date_filter(request.start_date, request.end_date, "PYRESOLVEDTIMESTAMP")

        manager_ids = request.manager_ids if request.manager_ids else [request.user_id]
        manager_filter = build_manager_filter(manager_ids)
        audit_manager_filter = build_audit_manager_filter(manager_ids)

        associate_filter = build_associate_filter(request.frontline_associate_ids, "AUDIT_SUBJECT_ID")
        associate_filter_invntry = build_associate_filter_invntry(request.frontline_associate_ids)

        valid_audit_periods = [
            period
            for period in (request.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)

        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="AUDIT_MONTH",
                audit_year_column="AUDIT_YEAR",
            )

            download_query = COMPLETED_AUDIT_COUNT_MANAGER_AUDIT_PERIOD_PAGINATED_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                page_size=config.CACHE_FULL_DATASET_LIMIT,
                offset=0,
            )
        else:
            download_query = COMPLETED_AUDIT_COUNT_MANAGER_PAGINATED_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter,
                associate_filter_invntry=associate_filter_invntry,
                page_size=config.CACHE_FULL_DATASET_LIMIT,
                offset=0,
            )

        engine = connection_manager.get_engine()
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)

        wb = Workbook()
        ws = wb.active
        ws.title = "Completed Audit Count"

        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")

        headers = [
            "Work Item",
            "Work Type",
            "Audit Cycle Time",
            "Audit Status",
            "Inventory Type",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Auditor Name",
            "Platform"
        ]

        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment

        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("WORKTYPE_CATEGORY", "")))
            ws.cell(row=row_num, column=3, value=format_cycle_time(row.get("AUDIT_CYCLE_TIME")) if row.get("AUDIT_CYCLE_TIME") else "00:00:00")
            ws.cell(row=row_num, column=4, value=str(row.get("AUDIT_RESOLVED_STATUS", "")))
            ws.cell(row=row_num, column=5, value=str(row.get("INVENTORY_TYPE", "")))
            ws.cell(row=row_num, column=6, value=str(row.get("LOB", "")))
            ws.cell(row=row_num, column=7, value=str(row.get("AUDIT_RESOLVED_DATE", "")))
            ws.cell(row=row_num, column=8, value=str(row.get("AUDIT_MONTH", "")))
            ws.cell(row=row_num, column=9, value=str(row.get("AUDIT_YEAR", "")))
            ws.cell(row=row_num, column=10, value=str(row.get("AUDITOR_NAME", "")))
            ws.cell(row=row_num, column=11, value=str(row.get("PLATFORM_SOURCE_SYSTEM", "")))

        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

        output = BytesIO()
        wb.save(output)
        output.seek(0)

        filename = f"completed_audit_count_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for completed audit count drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
