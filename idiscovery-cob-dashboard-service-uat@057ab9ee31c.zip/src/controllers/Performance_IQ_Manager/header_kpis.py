import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import ManagerBaseRequest, ManagerHeaderKPIsResponse, AssociateListRequest, AuditPeriod
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id

from controllers.Performance_IQ_Manager.associates_list import get_associates_list

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()

WORK_ITEMS_COMPLETED_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        REPORTTOMANAGERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
)
SELECT COUNT(DISTINCT PYID) AS COMPLETED_TASKS
FROM latest_inventory
WHERE PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP IS NOT NULL
  {{date_filter}}
  {{lob_filter}}
  {{manager_filter}}
  {{associate_filter}}
"""

PRODUCTION_PCT_QUERY = f"""
WITH 
-- =====================================================
-- STEP 1: Deduplicate Inventory Records (Get Latest State)
-- =====================================================
inventory_deduped AS (
    SELECT 
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.REPORTTOMANAGERID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.RETIME,
        i.PXCOMMITDATETIME,
        i.INSRT_DT_TIME,
        i.PXUPDATEDATETIME,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.LOB,
        
        -- Row number for deduplication (most recent business event)
        -- Primary: PXCOMMITDATETIME (when case was committed - business event)
        -- Secondary: INSRT_DT_TIME (ETL sequence - most recent data load)
        -- Tertiary: RETIME (quality indicator - higher RETIME preferred)
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID 
            ORDER BY i.PXCOMMITDATETIME DESC, i.INSRT_DT_TIME DESC, i.RETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
),

-- =====================================================
-- STEP 2: Apply Business Filters and Calculate Metrics
-- =====================================================
case_level AS (
    SELECT 
        i.PYRESOLVEDUSERID AS user_id,
        i.INTAKESOURCESYSTEM AS work_type,
        i.PYID AS case_id,
        i.CYCLE_TIME / 60.0 AS cycle_time_min,  -- Convert seconds to minutes
        i.RETIME AS retime_min,
        
        -- Calculate efficiency per case: (RETIME / CYCLE_TIME) * 100
        CASE 
            WHEN i.CYCLE_TIME > 0 THEN (i.RETIME / (i.CYCLE_TIME / 60.0)) * 100
            ELSE 0
        END AS efficiency_pct,
        
        -- Map efficiency to capped score using threshold table
        CASE 
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 75 THEN 75
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 75 
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 90 THEN 90
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 90 
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 < 98 THEN 97
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 >= 98 
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 100 THEN 100
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 100 
                 AND (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 <= 150 THEN 115
            WHEN (i.RETIME / NULLIF(i.CYCLE_TIME / 60.0, 0)) * 100 > 150 THEN 125
            ELSE 75  -- Default to lowest if calculation fails
        END AS mapped_efficiency
        
    FROM inventory_deduped i
    WHERE i.rn = 1  -- Get only the latest record per case
      AND i.PYSTATUSWORK IN ('Resolved-Completed')
      AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{manager_filter}}
      {{associate_filter}}
      AND i.CYCLE_TIME IS NOT NULL
      AND i.CYCLE_TIME > 0
      AND i.RETIME IS NOT NULL
      AND i.RETIME > 0
),

-- =====================================================
-- STEP 3: Work Type Level Aggregation
-- =====================================================
work_type_level AS (
    SELECT 
        user_id,
        work_type,
        COUNT(DISTINCT case_id) AS items_completed,
        SUM(cycle_time_min) AS total_cycle_time_min,
        SUM(retime_min) AS total_retime_min,
        
        -- Efficiency at work type level: (Total RETIME / Total Cycle Time) × 100
        CASE 
            WHEN SUM(cycle_time_min) > 0 
            THEN (SUM(retime_min) / SUM(cycle_time_min)) * 100
            ELSE 0
        END AS work_type_efficiency_pct,
        
        -- Map the work type efficiency to get mapped efficiency
        CASE 
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 75 THEN 75
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 75 
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 90 THEN 90
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 90 
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 < 98 THEN 97
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 >= 98 
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 100 THEN 100
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 100 
                 AND (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 <= 150 THEN 115
            WHEN (SUM(retime_min) / NULLIF(SUM(cycle_time_min), 0)) * 100 > 150 THEN 125
            ELSE 75
        END AS avg_mapped_efficiency
        
    FROM case_level
    GROUP BY user_id, work_type
),

-- =====================================================
-- STEP 4: User Daily Time Tracking (Available Time)
-- =====================================================
user_daily AS (
    SELECT 
        USERID AS user_id,
        LOGINDATE,
        TOTALSYSTEMTIME,
        FUSE_NON_PRODUCTIVE_TIME AS non_productive_sec,
        
        -- Available Time = Total System Time - Non-Productive Time
        TOTALSYSTEMTIME - COALESCE(FUSE_NON_PRODUCTIVE_TIME, 0) AS available_time_sec,
        
        -- Deduplication: most recent record per user per day
        ROW_NUMBER() OVER (
            PARTITION BY USERID, LOGINDATE 
            ORDER BY PXUPDATEDATETIME DESC, TOTALSYSTEMTIME DESC NULLS LAST
        ) AS rn
        
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE 1 = 1
      {{user_date_filter}}
      --{{manager_filter_user}}
      {{associate_filter_user}}
      AND TOTALSYSTEMTIME IS NOT NULL
),

-- =====================================================
-- STEP 5: User Aggregate Available Time
-- =====================================================
user_available_time AS (
    SELECT 
        user_id,
        -- Sum available time across all login days, convert seconds to minutes
        SUM(available_time_sec) / 60.0 AS total_available_time_min
    FROM user_daily
    WHERE rn = 1  -- Use deduplicated records only
      AND available_time_sec > 0  -- Exclude zero or negative available time
    GROUP BY user_id
),

-- =====================================================
-- STEP 6: User Level Aggregation (Final Calculation)
-- =====================================================
user_aggregate AS (
    SELECT 
        w.user_id,
        
        -- Total items completed across all work types
        SUM(w.items_completed) AS total_items_completed,
        
        -- Total cycle time across all work types
        SUM(w.total_cycle_time_min) AS total_cycle_time_min,
        
        -- Total RETIME across all work types
        SUM(w.total_retime_min) AS total_retime_min,
        
        -- Overall efficiency: (Total RETIME / Total Cycle Time) × 100
        CASE 
            WHEN SUM(w.total_cycle_time_min) > 0 
            THEN (SUM(w.total_retime_min) / SUM(w.total_cycle_time_min)) * 100
            ELSE 0
        END AS overall_efficiency_pct,
        
        -- Weighted average of mapped efficiency by items completed
        -- Formula: SUMPRODUCT(items, mapped_eff) / SUM(items)
        CASE 
            WHEN SUM(w.items_completed) > 0 
            THEN SUM(w.items_completed * w.avg_mapped_efficiency) / SUM(w.items_completed)
            ELSE 0
        END AS weighted_mapped_efficiency,
        
        -- Available time from user time tracking
        MAX(a.total_available_time_min) AS total_available_time_min
        
    FROM work_type_level w
    LEFT JOIN user_available_time a ON w.user_id = a.user_id
    GROUP BY w.user_id
),

-- =====================================================
-- STEP 7: Final Production % Calculation
-- =====================================================
final_calculation AS (
    SELECT 
        user_id,
        total_items_completed,
        total_cycle_time_min,
        total_retime_min,
        total_available_time_min,
        overall_efficiency_pct,
        weighted_mapped_efficiency,
        
        -- Utilization: (Total Cycle Time / Available Time) × 100
        CASE 
            WHEN total_available_time_min > 0 
            THEN (total_cycle_time_min / total_available_time_min) * 100
            ELSE 0
        END AS utilization_pct,
        
        -- Final Production %: (Mapped Efficiency × 0.5) + (Utilization × 0.5)
        CASE 
            WHEN total_available_time_min > 0 
            THEN (weighted_mapped_efficiency * 0.5) + 
                 ((total_cycle_time_min / total_available_time_min) * 100 * 0.5)
            ELSE 0
        END AS final_production_pct
        
    FROM user_aggregate
)

-- =====================================================
-- FINAL SELECT: Aggregate for Manager/Associate Level
-- =====================================================
SELECT 
    ROUND(AVG(final_production_pct), 2) AS AVG_PRODUCTION_PCT,
    ROUND(AVG(weighted_mapped_efficiency), 2) AS AVG_MAPPED_EFFICIENCY,
    ROUND(AVG(utilization_pct), 2) AS AVG_UTILIZATION,
    ROUND(AVG(overall_efficiency_pct), 2) AS AVG_EFFICIENCY,
    SUM(total_items_completed) AS TOTAL_ITEMS_COMPLETED,
    COUNT(DISTINCT user_id) AS TOTAL_USERS
FROM final_calculation
"""

AUDIT_SCORE_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        REPORTTOMANAGERID,
        PYSTATUSWORK,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{manager_filter}}
      {{associate_filter}}
),
audit_deduped AS (
    SELECT 
        a.PYID,
        a.CASE_TO_AUDIT,
        a.AUDIT_SUBJECT_ID,
        a.AUDIT_SCORE,
        a.PYSTATUSWORK,
        a.LOB,
        ROW_NUMBER() OVER (PARTITION BY a.CASE_TO_AUDIT, a.AUDIT_SUBJECT_ID ORDER BY a.PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
)
SELECT 
    ROUND(AVG(a.AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT i.PYID) AS total_cases_audited
FROM filtered_inventory i
INNER JOIN audit_deduped a
    ON i.PYID = a.CASE_TO_AUDIT
    AND a.rn = 1
    AND a.AUDIT_SCORE IS NOT NULL
    AND a.AUDIT_SCORE > 0
    AND a.PYID LIKE 'AUD%'
    AND a.PYSTATUSWORK IN (
        'Open-FeedbackReview',
        'Open-RebuttalReview',
        'Open-UpdateAuditCase',
        'Resolved-Completed',
        'Resolved-AutoClose'
    )
    {{lob_filter}}
    {{associate_filter_audit}}
"""

AUDIT_SCORE_AUDIT_PERIOD_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        a.PYID,
        a.CASE_TO_AUDIT,
        UPPER(TRIM(a.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(a.AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        a.AUDIT_SCORE,
        a.AUDIT_MONTH,
        a.AUDIT_YEAR,
        UPPER(TRIM(a.LOB)) AS LOB,
        UPPER(TRIM(a.PYSTATUSWORK)) AS PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY a.PYID
            ORDER BY a.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
),
latest_inventory AS (
    SELECT
        PYID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
)
SELECT
    ROUND(AVG(a.AUDIT_SCORE), 2) AS AVG_AUDIT_SCORE,
    COUNT(DISTINCT a.PYID) AS total_audits,
    COUNT(DISTINCT a.CASE_TO_AUDIT) AS total_cases_audited
FROM audit_deduped a
LEFT JOIN latest_inventory i
  ON i.PYID = a.CASE_TO_AUDIT
 AND i.rn = 1
WHERE a.rn = 1
  AND a.PYID LIKE 'AUD%'
  AND a.AUDIT_SCORE IS NOT NULL
  AND a.AUDIT_SCORE > 0
  AND a.PYSTATUSWORK IN (
        'OPEN-FEEDBACKREVIEW',
        'OPEN-REBUTTALREVIEW',
        'OPEN-UPDATEAUDITCASE',
        'RESOLVED-COMPLETED',
        'RESOLVED-AUTOCLOSE'
  )
  {{manager_filter_inventory}}
  {{associate_filter_audit}}
  {{lob_filter_audit}}
  {{audit_period_filter}}
"""


ACTIVE_USERS_COUNT_QUERY = f"""
SELECT COUNT(DISTINCT USERID) AS ACTIVE_USERS
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE LOGINDATE >= DATEADD('day', -7, CURRENT_DATE())
{{user_manager_filter}}
"""

CYCLE_TIME_AVG_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        REPORTTOMANAGERID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        CYCLE_TIME,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    COUNT(DISTINCT PYID) AS total_resolved_items,
    ROUND(AVG(CYCLE_TIME), 2) AS avg_cycle_time_seconds,
    ROUND(AVG(CYCLE_TIME) / 60, 2) AS avg_cycle_time_minutes
FROM latest_inventory
WHERE PYSTATUSWORK IN ('Resolved-Completed')
  AND PYRESOLVEDTIMESTAMP IS NOT NULL
  {{date_filter}}
  {{lob_filter}}
  {{manager_filter}}
  {{associate_filter}}
  AND CYCLE_TIME IS NOT NULL
"""

NON_VALUE_ADD_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        ACTIONDECISION,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        LOB,
        PYRESOLVEDUSERID,
        REPORTTOMANAGERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, INSRT_DT_TIME DESC NULLS LAST
    ) = 1
)
SELECT
    COUNT(DISTINCT CASE
        WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%'
        THEN PYID
    END) AS NON_VALUE_ADD_COUNT,
    COUNT(DISTINCT PYID) AS TOTAL_CLOSED,
    ROUND(
        COUNT(DISTINCT CASE
            WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%'
            THEN PYID
        END) * 100.0 / NULLIF(COUNT(DISTINCT PYID), 0),
        2
    ) AS NON_VALUE_ADD_PCT
FROM invntry_deduped
WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
  AND PYRESOLVEDTIMESTAMP IS NOT NULL
  {{date_filter}}
  {{lob_filter}}
  {{associate_filter}}
  {{manager_filter}}
"""

PENDED_ITEMS_QUERY = f"""
WITH latest_status AS (
    SELECT
        t.PYID,
        t.PYSTATUSWORK,
        t.PYRESOLVEDTIMESTAMP,
        t.REASSIGNED_TO,
        t.FIRST_ASSIGNED_TO,
        t.PXCREATEDATETIME,
        t.REPORTTOMANAGERID,
        t.LOB,
        ROW_NUMBER() OVER (
            PARTITION BY t.PYID
            ORDER BY t.PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE t
)
SELECT
    COUNT(DISTINCT PYID) AS PENDED_ITEMS_COUNT
FROM latest_status
WHERE rn = 1
  AND PYSTATUSWORK LIKE 'Pend%'
  AND PYRESOLVEDTIMESTAMP IS NULL
  {{lob_filter}}
  {{pended_created_filter}}
  {{manager_filter}}
  {{associate_filter}}
"""

SLA_BUCKET_HOURS = {
    '4 hours': 8,
    '2 days': 16,
    '10 days': 56,
    '30 days': 82
}



def format_cycle_time_from_seconds(seconds: float) -> str:
    """Format cycle time from seconds to 'X min. Y sec.' format."""
    total_minutes = int(seconds // 60)
    remaining_seconds = int(seconds % 60)
    return f"{total_minutes} min. {remaining_seconds} sec."

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return f"AND {date_column} >= '{start_date}' AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_user_date_filter(start_date: Optional[str], end_date: Optional[str]) -> str:
    if start_date and end_date:
        return (
            f"AND LOGINDATE >= '{start_date}' "
            f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND LOGINDATE >= '{start_date}'"
    elif end_date:
        return f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None, column: str = "PYRESOLVEDUSERID") -> str:
    """Build associate filter for inventory/work items tables.
    
    Args:
        frontline_associate_ids: List of associate IDs to filter
        column: Column name to filter on (default: PYRESOLVEDUSERID)
    """
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND {column} IN ('{frontline_associate_ids_str}')"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None, column: str = "REPORTTOMANAGERID") -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID).
    
    Args:
        manager_ids: List of manager IDs to filter
        column: Column name to filter on (default: REPORTTOMANAGERID)
    """
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND {column} IN ('{manager_ids_str}')"
    return ""


def build_lob_filter_audit(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for audit table with a. prefix."""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l.strip().upper() for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (UPPER(TRIM(a.LOB)) IN ('{lob_values}') OR a.LOB IS NULL)"
    elif null_requested:
        return "AND a.LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND UPPER(TRIM(a.LOB)) IN ('{lob_values}')"


def build_manager_filter_audit(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for audit table using AUDIT_SUBJECT_MGR_ID."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND a.AUDIT_SUBJECT_MGR_ID IN ('{manager_ids_str}')"
    return ""


async def build_associate_filter_pended(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for pended items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If ALL associates under the selected managers are present in frontline_associate_ids,
    include the manager IDs in the filter as well since pended items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Build base filter with selected associates
    # Use COALESCE directly since ASSIGNED_USER alias is not available in WHERE clause
    frontline_associate_ids_str = "', '".join(frontline_associate_ids)
    base_filter = f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{frontline_associate_ids_str}')"
    
    # Check if we should also include manager IDs
    # This happens when ALL associates under the selected managers are in frontline_associate_ids
    if manager_ids and len(manager_ids) > 0:
        try:
            # Get all associates under the selected managers from the API
            associates_request = AssociateListRequest(
                user_id=user_id or "system",
                start_date="2025-01-01",
                end_date="2026-12-31",
                manager_ids=manager_ids,
                search=None,
                limit=5000
            )
            response = await get_associates_list(associates_request)
            
            # Extract associate IDs from the response
            all_manager_associates = {item.associate_id for item in response.associates}
            selected_ids_set = set(frontline_associate_ids)
            
            # Check if ALL associates under selected managers are in the selected list
            if all_manager_associates and all_manager_associates.issubset(selected_ids_set):
                # Include managers in the filter
                combined_ids = list(frontline_associate_ids) + list(manager_ids)
                combined_ids_str = "', '".join(combined_ids)
                return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{combined_ids_str}')"
        except Exception as e:
            logger.error(f"Error checking manager associates: {str(e)}")
    
    # Return base filter without manager IDs
    return base_filter


def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO).
    
    Args:
        manager_ids: List of manager IDs to filter
    """
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""


def build_pended_created_filter(end_date: Optional[str] = None) -> str:
    """Filter for pended items that existed before the end date"""
    if end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_audit_month_year_filter(
    audit_periods: Optional[List[AuditPeriod]] = None,
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    """Build filter for audit month and year periods.
    
    Args:
        audit_periods: List of AuditPeriod objects with month and year
        audit_month_column: Column name for audit month (default: AUDIT_MONTH)
        audit_year_column: Column name for audit year (default: AUDIT_YEAR)
    
    Returns:
        SQL filter string like: AND ((AUDIT_MONTH = 'January' AND AUDIT_YEAR = '2024') OR ...)
    """
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append((month_value, year_value))

    if not valid_periods:
        return ""

    conditions = [
        f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
        for month, year in valid_periods
    ]

    return "AND (" + " OR ".join(conditions) + ")"


def get_audit_score_bubble(audit_score_value: float) -> str:
    """Determine audit score status bubble based on value.
    
    Rating Scale:
    - Exceptional: 100%
    - Exceeds: 99% - 99.99%
    - Meets: 98% - 98.99%
    - Approaching: 95% - 97.99%
    - Poor: Below 95%
    """
    if not audit_score_value or audit_score_value == 0.0:
        return "N/A"
    
    if audit_score_value >= 100:
        return "Exceptional"
    elif audit_score_value >= 99:
        return "Exceeds"
    elif audit_score_value >= 98:
        return "Meets"
    elif audit_score_value >= 95:
        return "Approaching"
    else:
        return "Poor"


def get_production_pct_bubble(production_pct_value: float) -> str:
    """Determine production percentage status bubble based on value.
    
    Rating Scale:
    - Exceptional: 120% or above
    - Exceeds: 115.99% - 119.99%
    - Meets: 100% - 114.59%
    - Approaching: 95% - 99.99%
    - Poor: Below 95%
    """
    if not production_pct_value or production_pct_value == 0.0:
        return "N/A"
    
    if production_pct_value >= 120:
        return "Exceptional"
    elif production_pct_value >= 115.99:
        return "Exceeds"
    elif production_pct_value >= 100:
        return "Meets"
    elif production_pct_value >= 95:
        return "Approaching"
    else:
        return "Poor"


def execute_query(engine, query: str, limit: int = 1):
    """Synchronous query execution (legacy, use execute_query_async for new code)."""
    return engine.execute_query(query, limit=limit)




@router.post(
    "/header-kpis",
    response_model=ManagerHeaderKPIsResponse,
    summary="Get Manager Header KPIs",
    description="""
Retrieve summary KPIs for manager dashboard header section.

**Input Parameters:**
- **manager_id** (required): Manager ID to filter team data
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **frontline_associate** (optional): Specific associate ID to filter

**Response Fields:**
- **work_items_completed**: Total work items completed by team in date range
- **production_pct_achieved**: Average production percentage achieved by team
- **audit_score_pct**: Average audit score percentage for team
- **cycle_time_avg**: Average cycle time
- **production_pct_achieved_status**: Status bubble for production percentage
  - "Exceptional" (>=120%), "Exceeds" (115.99-119.99%), "Meets" (100-114.59%), "Approaching" (95-99.99%), "Poor" (<95%), "N/A" (no data)
- **audit_score_pct_status**: Status bubble for audit score percentage
  - "Exceptional" (>=100%), "Exceeds" (99-99.99%), "Meets" (98-98.99%), "Approaching" (95-97.99%), "Poor" (<95%), "N/A" (no data)
- **cycle_time_avg_status**: Status for cycle time

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (work items, production)
- COB_AI_USER_PROFILE (work time)
- COB_AI_AUDIT_PROFILE (audit scores)
""",
)
async def get_header_kpis(request: ManagerBaseRequest) -> ManagerHeaderKPIsResponse:
    """Header KPIs endpoint with session-based metric-level caching."""
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_header_kpis_query(request)


async def execute_header_kpis_query(request: ManagerBaseRequest) -> ManagerHeaderKPIsResponse:
    """Execute header KPIs query logic with metric-level caching."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        lob_filter_audit = build_lob_filter_audit(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        manager_filter = build_manager_filter(request.manager_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        manager_filter_inventory = build_manager_filter(request.manager_ids, column="i.REPORTTOMANAGERID")
        manager_filter_audit = build_manager_filter_audit(request.manager_ids)
        associate_filter = build_associate_filter(request.frontline_associate_ids)
        associate_filter_user = build_associate_filter(request.frontline_associate_ids, column="USERID")
        associate_filter_inventory = build_associate_filter(request.frontline_associate_ids, column="i.USERID")
        associate_filter_audit = build_associate_filter(request.frontline_associate_ids, column="AUDIT_SUBJECT_ID")
        
        # Use async associate filter for pended items with conditional manager inclusion
        associate_filter_pended = await build_associate_filter_pended(
            request.frontline_associate_ids, 
            request.manager_ids, 
            request.user_id
        )
        
        engine = connection_manager.get_engine()

        # Format queries with consistent filter approach
        completed_query = WORK_ITEMS_COMPLETED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        production_query = PRODUCTION_PCT_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            user_date_filter=user_date_filter,
            manager_filter_user=manager_filter_user,
            associate_filter_user=associate_filter_user
        )
        
        # Determine audit mode: audit_period or date_range
        logger.info(f"🔍 DEBUG: request.audit_periods = {request.audit_periods}")
        valid_audit_periods = [
            period
            for period in (request.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]
        has_audit_periods = bool(valid_audit_periods)
        logger.info(f"🔍 DEBUG: valid_audit_periods = {valid_audit_periods}, has_audit_periods = {has_audit_periods}")
        
        normalized_audit_periods = sorted({
            f"{(period.month or '').strip().upper()}-{str(period.year).strip()}"
            for period in valid_audit_periods
        })
        
        if has_audit_periods:
            # Use audit period query with month/year filtering
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="a.AUDIT_MONTH",
                audit_year_column="a.AUDIT_YEAR",
            )
            audit_query = AUDIT_SCORE_AUDIT_PERIOD_QUERY.format(
                lob_filter_audit=lob_filter_audit,
                manager_filter_inventory=manager_filter_inventory,
                associate_filter_audit=associate_filter_audit,
                audit_period_filter=audit_period_filter
            )
        else:
            # Use date range query (legacy mode)
            audit_query = AUDIT_SCORE_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_audit=associate_filter_audit
            )
        
        cycle_time_query = CYCLE_TIME_AVG_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        
        nva_query = NON_VALUE_ADD_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter
        )
        
        pended_created_filter = build_pended_created_filter(request.end_date)

        pended_query = PENDED_ITEMS_QUERY.format(
            lob_filter=lob_filter,
            pended_created_filter=pended_created_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter_pended
        )
        
        # Get session_id for caching
        session_id = getattr(request, "session_id", None)
        
        # Define async fetch functions for parallel execution
        async def fetch_work_items():
            return await engine.execute_query_async(completed_query, limit=1)
        
        async def fetch_production_pct():
            return await engine.execute_query_async(production_query, limit=1)
        
        async def fetch_audit_score():
            return await engine.execute_query_async(audit_query, limit=1)
        
        async def fetch_cycle_time():
            return await engine.execute_query_async(cycle_time_query, limit=1)
        
        async def fetch_non_value_add():
            return await engine.execute_query_async(nva_query, limit=1)
        
        async def fetch_pended_items():
            return await engine.execute_query_async(pended_query, limit=1)
        
        # Build filters dict for cache isolation
        base_filters = {
            'start_date': request.start_date,
            'end_date': request.end_date,
            'lob': request.lob,
            'manager_ids': request.manager_ids,
            'frontline_associate_ids': request.frontline_associate_ids,
        }
        
        # Separate filters for audit score with audit mode info
        audit_filters = {
            **base_filters,
            'audit_mode': 'audit_period' if has_audit_periods else 'date_range',
            'audit_periods': normalized_audit_periods if has_audit_periods else None,
        }
        
        # Get or fetch cached metrics (only cache if session_id provided)
        if session_id:
            completed_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_work_items,
                session_id=session_id,
                metric_name="work_items_completed",
                filters=base_filters
            )
            
            production_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_production_pct,
                session_id=session_id,
                metric_name="production_pct",
                filters=base_filters
            )
            
            audit_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_score,
                session_id=session_id,
                metric_name="audit_score",
                filters=audit_filters
            )
            
            cycle_time_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_cycle_time,
                session_id=session_id,
                metric_name="cycle_time",
                filters=base_filters
            )
            
            nva_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_non_value_add,
                session_id=session_id,
                metric_name="non_value_add",
                filters=base_filters
            )
            
            pended_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_pended_items,
                session_id=session_id,
                metric_name="pended_items",
                filters=base_filters
            )
        else:
            # No session_id - execute all 6 queries in parallel without caching
            logger.info("Executing 6 Manager header KPI queries in parallel")
            (
                completed_records,
                production_records,
                audit_records,
                cycle_time_records,
                nva_records,
                pended_records
            ) = await asyncio.gather(
                fetch_work_items(),
                fetch_production_pct(),
                fetch_audit_score(),
                fetch_cycle_time(),
                fetch_non_value_add(),
                fetch_pended_items(),
                return_exceptions=False
            )
            logger.info("Parallel query execution completed")

        work_items_completed = int(completed_records[0].get("COMPLETED_TASKS", 0)) if completed_records else 0
        production_pct_achieved = float(production_records[0].get("AVG_PRODUCTION_PCT", 0)) if production_records and production_records[0].get("AVG_PRODUCTION_PCT") else 0.0
        audit_score_pct = float(audit_records[0].get("AVG_AUDIT_SCORE", 0)) if audit_records and audit_records[0].get("AVG_AUDIT_SCORE") else 0.0
        non_value_add_pct = float(nva_records[0].get("NON_VALUE_ADD_PCT", 0) or 0) if nva_records else 0.0
        pended_items_count = int(pended_records[0].get("PENDED_ITEMS_COUNT", 0)) if pended_records else 0

        # Extract cycle time average
        if cycle_time_records and cycle_time_records[0].get("AVG_CYCLE_TIME_SECONDS"):
            avg_seconds = float(cycle_time_records[0].get("AVG_CYCLE_TIME_SECONDS", 0))
            cycle_time_str = format_cycle_time_from_seconds(avg_seconds)
        else:
            cycle_time_str = "N/A"

        # Calculate status bubbles
        production_status = get_production_pct_bubble(production_pct_achieved)
        audit_score_status = get_audit_score_bubble(audit_score_pct)

        tooltips = {
            "work_items_completed": "Total number of work items resolved in the selected date range",
            "production_pct_achieved": "Comprehensive production metric calculated as: (Mapped Efficiency × 50%) + (Utilization × 50%). Efficiency is calculated per work type using RETIME/Cycle Time and mapped to thresholds (<75%=75, 75-90%=90, 90-98%=97, 98-100%=100, 100-150%=115, >150%=125). Weighted average is computed across work types by items completed. Utilization = (Total Cycle Time / Available Time) × 100. Available Time = Total System Time - Non-Productive Time.",
            "production_pct_achieved_status": "Performance rating: Exceptional (>=120%), Exceeds (115.99-119.99%), Meets (100-114.59%), Approaching (95-99.99%), Poor (<95%)",
            "audit_score_pct": "Average audit quality score across all audited cases",
            "audit_score_pct_status": "Quality rating: Exceptional (>=100%), Exceeds (99-99.99%), Meets (98-98.99%), Approaching (95-97.99%), Poor (<95%)",
            "cycle_time_avg": "Average time to complete a work item from assignment to resolution",
            "pended_items_count": "Total number of work items currently in pending status",
            "non_value_add_pct": "Percentage of completed items with 'Confirmed Existing COB/No Update Required'",
            "volume_forecast_accuracy": "Accuracy of volume forecasts vs actual (awaiting baseline data)"
        }

        return ManagerHeaderKPIsResponse(
            status="success",
            work_items_completed=work_items_completed,
            production_pct_achieved=production_pct_achieved,
            audit_score_pct=audit_score_pct,
            cycle_time_avg=cycle_time_str,
            pended_items_count=pended_items_count,
            non_value_add_pct=non_value_add_pct,
            message="Header KPIs retrieved successfully",
            tooltips=tooltips,
            production_pct_achieved_status=production_status,
            audit_score_pct_status=audit_score_status,
            cycle_time_avg_status="N/A"
        )

    except Exception as e:
        logger.error(f"Manager header KPIs query error: {type(e).__name__}: {str(e)}")
        return ManagerHeaderKPIsResponse(
            status="error",
            work_items_completed=0,
            production_pct_achieved=0.0,
            audit_score_pct=0.0,
            cycle_time_avg="N/A",
            pended_items_count=0,
            non_value_add_pct=0.0,
            message=f"Failed to retrieve manager header KPIs: {str(e)}",
            production_pct_achieved_status="N/A",
            audit_score_pct_status="N/A",
            cycle_time_avg_status="N/A"
        )
