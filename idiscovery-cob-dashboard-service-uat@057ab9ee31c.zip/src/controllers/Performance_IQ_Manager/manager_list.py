"""
Manager List Endpoint
Fetches list of managers for the manager dashboard
"""

import logging
import asyncio
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import ManagerListRequest, ManagerListResponse, ManagerItem
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
from utils.redis_cache import CacheManager

# Initialize router and logger
router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])
logger = logging.getLogger(__name__)

connection_manager = SnowflakeConnectionManager()
cache_manager = CacheManager()

MANAGERS_LIST_QUERY = f"""
WITH frontline AS (
    SELECT DISTINCT
        USERID,
        PYREPORTTO,
        REPORTTOUSERNAME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        AND LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
),
manager AS (
    SELECT DISTINCT
        USERID,
        USERNAME,
        PYACCESSGROUP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= DATEADD(year, -1, CURRENT_DATE())
)
SELECT DISTINCT
    manager.USERID AS MANAGER_ID,
    manager.USERNAME AS MANAGER_NAME
FROM frontline
INNER JOIN manager
    ON frontline.PYREPORTTO = manager.USERID
WHERE manager.USERID IS NOT NULL
  AND manager.USERNAME IS NOT NULL
  {{access_group_filter}}
ORDER BY manager.USERNAME
"""


def get_user_access_group(user_id: str, engine) -> str:
    """
    Get the PYACCESSGROUP for the logged-in user (legacy sync version).
    
    Args:
        user_id: User ID to look up
        engine: Database engine
    
    Returns:
        PYACCESSGROUP value or empty string if not found
    """
    query = f"""
    SELECT PYACCESSGROUP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID = '{user_id}'
        AND PYACCESSGROUP IS NOT NULL
    ORDER BY LOGINDATE DESC
    LIMIT 1
    """
    try:
        records = engine.execute_query(query, limit=1)
        if records and len(records) > 0:
            return records[0].get("PYACCESSGROUP", "")
    except Exception as e:
        logger.warning(f"Failed to get user access group for {user_id}: {str(e)}")
    return ""


async def get_user_access_group_async(engine, user_id: str) -> str:
    """Async version of get_user_access_group."""
    query = f"""
    SELECT PYACCESSGROUP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID = '{user_id}'
        AND PYACCESSGROUP IS NOT NULL
    ORDER BY LOGINDATE DESC
    LIMIT 1
    """
    try:
        records = await engine.execute_query_async(query, limit=1)
        if records and len(records) > 0:
            return records[0].get("PYACCESSGROUP", "")
    except Exception as e:
        logger.warning(f"Failed to get user access group for {user_id}: {str(e)}")
    return ""


def build_access_group_filter(user_access_group: str) -> str:
    """
    Build filter for manager PYACCESSGROUP based on logged-in user's access group.
    If user is 'COB:OffFrontLineManager', only show managers with same access group.
    
    Args:
        user_access_group: The logged-in user's PYACCESSGROUP
    
    Returns:
        SQL filter string or empty string
    """
    if user_access_group == "COB:OffFrontLineManager":
        return "AND manager.PYACCESSGROUP = 'COB:OffFrontLineManager'"
    return ""


@router.post(
    "/managers-list",
    response_model=ManagerListResponse,
    summary="Get List of Managers",
    description="""
Retrieve unique list of managers for filter dropdown.
Shows managers who had frontline associates reporting to them in the last 1 year.
If logged-in user has PYACCESSGROUP='COB:OffFrontLineManager', only shows managers with same access group.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **search** (optional): Search term to filter managers by name

**Response Fields:**
- **status**: Status of the request (success/error)
- **managers**: List of ManagerItem objects containing manager_id and manager_name
- **total_count**: Total number of managers returned
- **message**: Response message
- **service**: Service name (idiscovery-cob-dashboard-service)

**Data Source:** COB_AI_USER_PROFILE table (filtered to last 1 year of login activity)
**Caching:** Results cached for 6 hours (21,600s)
""",
)
async def get_managers_list(request: ManagerListRequest) -> ManagerListResponse:
    if not connection_manager.validate_config():
        logger.error("[MANAGERS_LIST] Snowflake credentials not configured")
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    # Build cache key (include user_id since access group filtering depends on it)
    cache_key = cache_manager.build_key(
        "managers:list",
        user_id=request.user_id,
        search=request.search or ""
    )
    
    async def fetch_from_db():
        """Fetch managers list from database."""
        try:
            engine = connection_manager.get_engine()
            
            # Execute 2 queries in parallel: user access group + managers list
            logger.info("[MANAGERS_LIST] Executing 2 queries in parallel")
            
            # First, get user access group to build filter
            user_access_group = await get_user_access_group_async(request.user_id, engine)
            access_group_filter = build_access_group_filter(user_access_group)
            
            logger.info(f"[MANAGERS_LIST] User {request.user_id} has access group: {user_access_group}")
            
            query = MANAGERS_LIST_QUERY.format(
                access_group_filter=access_group_filter
            )
            
            # Execute main query asynchronously
            records = await engine.execute_query_async(query, limit=10001)
            logger.info("[MANAGERS_LIST] Parallel query execution completed")
            
            managers = [
                {
                    "manager_id": r.get("MANAGER_ID", ""),
                    "manager_name": r.get("MANAGER_NAME", "")
                }
                for r in records
                if r.get("MANAGER_ID") and r.get("MANAGER_NAME")
            ] if records else []

            return {
                "status": "success",
                "managers": managers,
                "total_count": len(managers),
                "message": "Managers list retrieved successfully"
            }

        except Exception as e:
            logger.error(f"[MANAGERS_LIST] Error occurred: {type(e).__name__}: {str(e)}")
            logger.exception(f"[MANAGERS_LIST] Full exception traceback:")
            return {
                "status": "error",
                "managers": [],
                "total_count": 0,
                "message": f"Failed to retrieve managers list: {str(e)}"
            }
    
    # Get from cache or fetch from DB (6 hour TTL)
    result = await cache_manager.get_or_fetch(cache_key, fetch_from_db, ttl=METRIC_CACHE_TTL)
    
    # Convert dict to response model
    managers = [ManagerItem(**m) for m in result["managers"]]
    
    return ManagerListResponse(
        status=result["status"],
        managers=managers,
        total_count=result["total_count"],
        message=result["message"]
    )
