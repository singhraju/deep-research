import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
import httpx

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from schema import (
    PendedItemsDrilldownPaginatedRequest,
    PendedItemsDrilldownPaginatedResponse,
    PendedItemsRecord,
    PageResponse,
    ManagerBaseDownloadRequest,
    AssociateListRequest
)
from controllers.Performance_IQ_Manager.associates_list import get_associates_list
import math

def calculate_days_pended(pend_date: str) -> str:
    """Calculate days pended from pend date to current date"""
    if not pend_date:
        return "0"
    try:
        if 'T' in str(pend_date):
            pend_dt = datetime.strptime(str(pend_date).split('T')[0], "%Y-%m-%d")
        else:
            pend_dt = datetime.strptime(str(pend_date), "%Y-%m-%d")
        current_dt = datetime.now()
        days_diff = (current_dt - pend_dt).days
        return str(max(0, days_diff))
    except:
        return "0"

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        # Handle datetime strings by taking only the date part
        date_part = str(date_str).split(' ')[0] if ' ' in str(date_str) else str(date_str)
        # Handle ISO format with 'T'
        if 'T' in date_part:
            date_part = date_part.split('T')[0]
        date_obj = datetime.strptime(date_part, "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def format_datetime_mmddyyyy(datetime_str: str) -> str:
    """Convert datetime to MM/DD/YYYY format"""
    if not datetime_str:
        return ""
    try:
        # Handle both date and datetime formats
        if 'T' in str(datetime_str):
            date_obj = datetime.strptime(str(datetime_str).split('T')[0], "%Y-%m-%d")
        else:
            date_obj = datetime.strptime(str(datetime_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(datetime_str)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()

PENDED_ITEMS_PAGINATED_QUERY = f"""
WITH latest_status AS (
    SELECT
        t.PYID,
        t.INTAKESOURCESYSTEM,
        t.PYSTATUSWORK,
        t.LOB,
        t.PXCREATEDATETIME,
        t.PXUPDATEDATETIME,
        t.PEND_CREATE_DT,
        t.PEND_RESOLVED_DT,
        t.INTERNALDUEDATE,
        t.REASSIGNED_TO,
        t.FIRST_ASSIGNED_TO,
        COALESCE(t.REASSIGNED_TO, t.FIRST_ASSIGNED_TO) AS assigned_user,
        t.PYRESOLVEDTIMESTAMP,
        t.REPORTTOMANAGERID,
        ROW_NUMBER() OVER (
            PARTITION BY t.PYID
            ORDER BY t.PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE t
),
user_profile_deduped AS (
    SELECT
        USERID,
        PYREPORTTO,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    i.PYID AS work_item_id,
    i.INTAKESOURCESYSTEM AS worktype_category,
    i.PYSTATUSWORK AS status,
    i.LOB,
    DATEDIFF('day', i.PEND_CREATE_DT, COALESCE(i.PEND_RESOLVED_DT, CURRENT_DATE)) AS days_pended,
    i.PEND_CREATE_DT AS pend_date,
    i.INTERNALDUEDATE AS due_date,
    i.PEND_RESOLVED_DT AS resolved_date,
    u.USERNAME AS associate_name
FROM latest_status i
INNER JOIN user_profile_deduped u
    ON i.assigned_user = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
  AND i.PYSTATUSWORK LIKE 'Pend%'
  AND i.PYRESOLVEDTIMESTAMP IS NULL
  {{lob_filter}}
  {{pended_created_filter}}
  {{manager_filter}}
  {{associate_filter}}
ORDER BY i.PXCREATEDATETIME DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

PENDED_ITEMS_COUNT_QUERY = f"""
WITH latest_status AS (
    SELECT
        t.PYID,
        t.PYSTATUSWORK,
        t.PYRESOLVEDTIMESTAMP,
        t.REASSIGNED_TO,
        t.FIRST_ASSIGNED_TO,
        t.PXCREATEDATETIME,
        t.REPORTTOMANAGERID,
        t.LOB,
        ROW_NUMBER() OVER (
            PARTITION BY t.PYID
            ORDER BY t.PXCOMMITDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE t
)
SELECT
    COUNT(DISTINCT PYID) AS TOTAL_COUNT
FROM latest_status
WHERE rn = 1
  AND PYSTATUSWORK LIKE 'Pend%'
  AND PYRESOLVEDTIMESTAMP IS NULL
  {{lob_filter}}
  {{pended_created_filter}}
  {{manager_filter}}
  {{associate_filter}}
"""

PENDED_ITEMS_DEFAULT_ORDER_BY = "ORDER BY i.PXCREATEDATETIME DESC"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item_id": "i.PYID",
        "worktype_category": "i.INTAKESOURCESYSTEM",
        "status": "i.PYSTATUSWORK",
        "lob": "i.LOB",
        "days_pended": "DATEDIFF('day', i.PEND_CREATE_DT, COALESCE(i.PEND_RESOLVED_DT, CURRENT_DATE))",
        "pend_date": "i.PEND_CREATE_DT",
        "due_date": "i.INTERNALDUEDATE",
        "resolved_date": "i.PEND_RESOLVED_DT",
        "associate_name": "u.USERNAME",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return PENDED_ITEMS_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, i.PXCREATEDATETIME DESC, i.PYID"

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    if start_date and end_date:
        return f"AND PXCREATEDATETIME >= '{start_date}' AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

async def get_total_associates_count(manager_id: str = None, user_id: str = None) -> int:
    """Get total count of associates under the given manager by calling associates_list API."""
    if not manager_id:
        return 0
    
    try:
        # Create request for associates list API
        # Note: start_date and end_date are required but not used for counting all associates
        associates_request = AssociateListRequest(
            user_id=user_id or "system",
            start_date="2025-01-01",  # Placeholder dates - not used for counting
            end_date="2026-12-31",
            manager_ids=[manager_id],  # Pass as list (schema expects manager_ids, not manager_id)
            search=None,
            limit=5000
        )
        
        # Call the associates list API
        response = await get_associates_list(associates_request)
        
        # Return the total count from the response
        return response.total_count
    except Exception as e:
        logger.error(f"Error getting total associates count from API: {str(e)}")
        return 0


async def build_associate_filter(
    frontline_associate_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    user_id: str = None
) -> str:
    """Build associate filter for pended items using COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO).
    
    If ALL associates under the selected managers are present in frontline_associate_ids,
    include the manager IDs in the filter as well since pended items can be assigned to managers.
    """
    if not frontline_associate_ids or len(frontline_associate_ids) == 0:
        return ""
    
    # Build base filter with selected associates
    frontline_associate_ids_str = "', '".join(frontline_associate_ids)
    base_filter = f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{frontline_associate_ids_str}')"
    
    # Check if we should also include manager IDs
    # This happens when ALL associates under the selected managers are in frontline_associate_ids
    if manager_ids and len(manager_ids) > 0:
        try:
            # Get all associates under the selected managers from the API
            associates_request = AssociateListRequest(
                user_id=user_id or "system",
                start_date="2025-01-01",
                end_date="2026-12-31",
                manager_ids=manager_ids,
                search=None,
                limit=5000
            )
            response = await get_associates_list(associates_request)
            
            # Extract associate IDs from the response
            all_manager_associates = {item.associate_id for item in response.associates}
            selected_ids_set = set(frontline_associate_ids)
            
            # Check if ALL associates under selected managers are in the selected list
            if all_manager_associates and all_manager_associates.issubset(selected_ids_set):
                # Include managers in the filter
                combined_ids = list(frontline_associate_ids) + list(manager_ids)
                combined_ids_str = "', '".join(combined_ids)
                return f"AND COALESCE(REASSIGNED_TO, FIRST_ASSIGNED_TO) IN ('{combined_ids_str}')"
        except Exception as e:
            logger.error(f"Error checking manager associates: {str(e)}")
    
    # Return base filter without manager IDs
    return base_filter


def build_pended_created_filter(end_date: Optional[str] = None) -> str:
    """Filter for pended items that existed before the end date"""
    if end_date:
        return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

@router.post(
    "/pended-items-drilldown",
    response_model=PendedItemsDrilldownPaginatedResponse,
    summary="Get Pended Items Drilldown",
    description="""
Retrieve paginated list of pended work items for detailed table display.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **status** (optional): List of status values (e.g., ['Pend', 'Pending'])
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item_id**: Unique work item identifier (PYID)
- **worktype_category**: Work type category (INTAKESOURCESYSTEM)
- **status**: Current work item status
- **lob**: Line of Business
- **days_pended**: Number of days the item has been pended
- **pend_date**: Date when the item was pended (MM/DD/YYYY format)
- **due_date**: Due date for the work item (MM/DD/YYYY format)
- **resolved_date**: Resolved date (MM/DD/YYYY format)
- **associate_name**: Associate name (PYRESOLVEDUSERID)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (pended items data)
- COB_AI_USER_PROFILE (manager-associate relationships)
""",
)
async def get_pended_items_drilldown(
    request: PendedItemsDrilldownPaginatedRequest
) -> PendedItemsDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        status = request.status
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        lob_filter = build_lob_filter(lob)
        pended_created_filter = build_pended_created_filter(end_date)
        manager_filter = build_manager_filter(manager_ids)
        # Use async associate filter with manager IDs logic
        associate_filter = await build_associate_filter(frontline_associate_ids, manager_ids, request.user_id)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached pended_items count from header KPIs
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict and hash for cache key
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'manager_ids': request.manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                
                # Get cached pended items count from header KPIs
                cache_key = f"session:{session_id}:{filters_hash}:pended_items"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract PENDED_ITEMS_COUNT from cached query result
                    total_records = int(cached_metric[0].get("PENDED_ITEMS_COUNT", 0))
                    logger.info(f"✅ Reused cached pended items count: {total_records} (from header KPIs)")
                else:
                    logger.info(f"Cache miss for pended_items, running COUNT query")
                    # Fall back to COUNT query
                    count_query = PENDED_ITEMS_COUNT_QUERY.format(
                        lob_filter=lob_filter,
                        pended_created_filter=pended_created_filter,
                        manager_filter=manager_filter,
                        associate_filter=associate_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached pended items count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = PENDED_ITEMS_COUNT_QUERY.format(
                    lob_filter=lob_filter,
                    pended_created_filter=pended_created_filter,
                    manager_filter=manager_filter,
                    associate_filter=associate_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = PENDED_ITEMS_COUNT_QUERY.format(
                lob_filter=lob_filter,
                pended_created_filter=pended_created_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        data_query = PENDED_ITEMS_PAGINATED_QUERY.format(
            lob_filter=lob_filter,
            pended_created_filter=pended_created_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            PENDED_ITEMS_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        print(data_query)
        records = await engine.execute_query_async(data_query, limit=page_limit)
        pended_items_records = [
            PendedItemsRecord(
                work_item_id=record.get("WORK_ITEM_ID"),
                worktype_category=record.get("WORKTYPE_CATEGORY"),
                status=record.get("STATUS"),
                lob=record.get("LOB") or "",
                days_pended=str(record.get("DAYS_PENDED", 0)),
                pend_date=format_date_mmddyyyy(record.get("PEND_DATE")),
                due_date=format_date_mmddyyyy(str(record.get("DUE_DATE")).split()[0]) if record.get("DUE_DATE") else "N/A",
                resolved_date=format_date_mmddyyyy(record.get("RESOLVED_DATE")) if record.get("RESOLVED_DATE") else "N/A",
                associate_name=record.get("ASSOCIATE_NAME")
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item_id": "Unique identifier for the work item (PYID)",
            "worktype_category": "Work type category or source system",
            "status": "Current status of the pended work item",
            "lob": "Line of Business associated with the work item",
            "days_pended": "Number of days the item has been in pended status",
            "pend_date": "Date when the work item was pended",
            "due_date": "Due date for completing the work item",
            "resolved_date": "Date when the work item was resolved (if applicable)",
            "associate_name": "Associate responsible for the work item"
        }

        return PendedItemsDrilldownPaginatedResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=pended_items_records,
            message="Pended items retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated pended items drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return PendedItemsDrilldownPaginatedResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve pended items records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/pended-items-drilldown/download-excel",
    summary="Download Pended Items Drilldown as Excel (Manager)",
    description="""
Download complete pended items drilldown data as an Excel file (Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all pended items records
""",
)
async def download_pended_items_drilldown_excel(
    request: ManagerBaseDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        lob_filter = build_lob_filter(lob)
        pended_created_filter = build_pended_created_filter(request.end_date)
        manager_filter = build_manager_filter(manager_ids)
        # Use async associate filter with manager IDs logic
        associate_filter = await build_associate_filter(frontline_associate_ids, manager_ids, request.user_id)
        
        engine = connection_manager.get_engine()
        
        # Query with high limit for download (no pagination needed)
        download_query = PENDED_ITEMS_PAGINATED_QUERY.format(
            lob_filter=lob_filter,
            pended_created_filter=pended_created_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Pended Items"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Status",
            "LOB",
            "Days Pended",
            "Pend Date",
            "Due Date",
            "Resolved Date",
            "Associate Name"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM_ID", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("WORKTYPE_CATEGORY", "")))
            ws.cell(row=row_num, column=3, value=str(row.get("STATUS", "")))
            ws.cell(row=row_num, column=4, value=str(row.get("LOB", "")))
            ws.cell(row=row_num, column=5, value=str(row.get("DAYS_PENDED", "0")))
            ws.cell(row=row_num, column=6, value=format_date_mmddyyyy(str(row.get("PEND_DATE", ""))) if row.get("PEND_DATE") else "")
            due_date = row.get("DUE_DATE")
            ws.cell(row=row_num, column=7, value=format_date_mmddyyyy(str(due_date).split()[0]) if due_date else "N/A")
            ws.cell(row=row_num, column=8, value=format_date_mmddyyyy(str(row.get("RESOLVED_DATE", ""))) if row.get("RESOLVED_DATE") else "N/A")
            ws.cell(row=row_num, column=9, value=str(row.get("ASSOCIATE_NAME", "")))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"pended_items_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for pended items drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
