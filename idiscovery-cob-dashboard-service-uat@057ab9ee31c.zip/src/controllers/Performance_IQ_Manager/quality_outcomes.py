import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import ManagerQualityOutcomesRequest, ManagerQualityOutcomesSimpleResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from services.session_cache_orchestrator import generate_session_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()

# 1. Rebuttal Count Query
REBUTTAL_COUNT_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
latest_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT
    FROM latest_audit
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
      AND REBUTTALOUTCOME IS NOT NULL
      AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
      AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS,
    COUNT(*) AS TOTAL_REBUTTAL_RECORDS
FROM filtered_inventory i
INNER JOIN filtered_audit a
    ON i.PYID = a.CASE_TO_AUDIT
INNER JOIN eligible_rebuttal_line_items rd
    ON a.PYID = rd.CASEID
"""

REBUTTAL_COUNT_AUDIT_PERIOD_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        PXCREATEDATETIME,
        LOB,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        AUDIT_YEAR,
        AUDIT_MONTH,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE CASE_TO_AUDIT IS NOT NULL
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        ab.PYID
    FROM audit_base ab
    INNER JOIN filtered_inventory i
        ON ab.CASE_TO_AUDIT = i.ORIGINAL_OHI_CASE_ID
    WHERE REBUTTALFLAG = 'Y'
      AND ab.PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{associate_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
      AND REBUTTALOUTCOME IS NOT NULL
      AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
      AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS UNIQUE_AUDIT_CASES_WITH_REBUTTALS,
    COUNT(*) AS TOTAL_REBUTTAL_RECORDS
FROM audit_filtered af
INNER JOIN eligible_rebuttal_line_items rd
    ON af.PYID = rd.CASEID
"""

# 2. Rebuttal Overturn Query
REBUTTAL_OVERTURN_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
latest_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT
    FROM latest_audit
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        UPPER(TRIM(REBUTTALOUTCOME)) AS REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
      AND REBUTTALOUTCOME IS NOT NULL
      AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
      AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    COUNT(DISTINCT a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS TOTAL_REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('ERROR RETRACTED', 'FYI RETRACTED', 'CHANGED TO FYI')
        THEN a.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS OVERTURNED_COUNT
FROM filtered_inventory i
INNER JOIN filtered_audit a
    ON i.PYID = a.CASE_TO_AUDIT
INNER JOIN eligible_rebuttal_line_items act
    ON a.PYID = act.CASEID
"""

REBUTTAL_OVERTURN_AUDIT_PERIOD_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        PXCREATEDATETIME,
        LOB,
        AUDIT_YEAR,
        AUDIT_MONTH,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE CASE_TO_AUDIT IS NOT NULL
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        ab.PYID
    FROM audit_base ab
    INNER JOIN filtered_inventory i
        ON ab.CASE_TO_AUDIT = i.ORIGINAL_OHI_CASE_ID
    WHERE REBUTTALFLAG = 'Y'
      AND ab.PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND PXCREATEDATETIME IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{associate_filter}}
),
audit_activity_deduped AS (
    SELECT
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        UPPER(TRIM(REBUTTALOUTCOME)) AS REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
      AND REBUTTALOUTCOME IS NOT NULL
      AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
      AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    COUNT(DISTINCT af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY) AS TOTAL_REBUTTALS,
    COUNT(DISTINCT CASE
        WHEN act.REBUTTALOUTCOME IN ('ERROR RETRACTED', 'FYI RETRACTED', 'CHANGED TO FYI')
        THEN af.PYID || '|' || act.ERRORCATEGORYTYPE || '|' || act.ERRORCATEGORY
    END) AS OVERTURNED_COUNT
FROM audit_filtered af
INNER JOIN eligible_rebuttal_line_items act
    ON af.PYID = act.CASEID
"""

# 3. Complete Audit Count Query
COMPLETED_AUDIT_COUNT_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
latest_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT
    FROM latest_audit
    WHERE PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT a.PYID) AS COMPLETED_AUDIT_COUNT
FROM filtered_inventory i
INNER JOIN filtered_audit a
    ON i.PYID = a.CASE_TO_AUDIT
"""

COMPLETED_AUDIT_COUNT_AUDIT_PERIOD_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        PXUPDATEDATETIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE PYID LIKE 'AUD%'
      AND CASE_TO_AUDIT IS NOT NULL
),
completion_candidates AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK,
        PXUPDATEDATETIME AS completion_ts,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY
                CASE
                    WHEN PYSTATUSWORK = 'OPEN-FEEDBACKREVIEW' THEN 1
                    WHEN PYSTATUSWORK = 'RESOLVED-COMPLETED' THEN 2
                    ELSE 99
                END,
                PXUPDATEDATETIME ASC
        ) AS rn
    FROM audit_base
    WHERE PYSTATUSWORK IN ('OPEN-FEEDBACKREVIEW', 'RESOLVED-COMPLETED')
),
completion_event AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        LOB,
        AUDIT_MONTH,
        AUDIT_YEAR,
        PYSTATUSWORK AS completion_status,
        completion_ts
    FROM completion_candidates
    WHERE rn = 1
),
filtered_completion AS (
    SELECT
        c.PYID
    FROM completion_event c
    INNER JOIN filtered_inventory i
        ON c.CASE_TO_AUDIT = i.ORIGINAL_OHI_CASE_ID
    WHERE 1 = 1
      {{audit_period_filter}}
      {{lob_filter}}
      {{associate_filter}}
)
SELECT
    COUNT(DISTINCT PYID) AS COMPLETED_AUDIT_COUNT
FROM filtered_completion
"""

# 3. Rework Count Query
REWORK_COUNT_QUERY = f"""
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        TARGET_AUDIT,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        PXCREATEDATETIME,
        LOB,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
associate_hierarchy AS (
    SELECT
        PYID,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
)
SELECT
    COUNT(DISTINCT a.PYID) AS REWORK_COUNT
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
WHERE a.TARGET_AUDIT = 'Rework'
  AND a.PYRESOLVEDTIMESTAMP IS NOT NULL
  {{rework_date_filter}}
  {{lob_filter}}
  {{manager_filter}}
  {{associate_filter_invntry}}
"""

# 4. Fuse Time Query (from fuse_time_drilldown.py pattern)
FUSE_TIME_QUERY = f"""
SELECT 
    SUM(COALESCE(u.TOTALSYSTEMTIME, 0)) AS TOTAL_FUSE_TIME_SECONDS
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
WHERE 1=1
    {{date_filter}}
    {{manager_filter}}
    {{associate_filter}}
"""

# 5. Watchlist Count Query
WATCHLIST_COUNT_QUERY = f"""
WITH user_with_manager AS (
    SELECT
        UPPER(TRIM(USERID)) AS USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        COALESCE(UPPER(TRIM(PYREPORTTO)), 'NONE') AS manager_id,
        REPORTTOFIRSTNAME AS manager_firstname,
        REPORTTOLASTNAME AS manager_lastname,
        PYACCESSGROUP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY USERID
        ORDER BY LOGINDATE DESC NULLS LAST, LASTLOGOUTTIME DESC NULLS LAST
    ) = 1
),
inventory_lob AS (
    SELECT
        PYID,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
watchlist_deduped AS (
    SELECT
        w.CASEID,
        UPPER(TRIM(w.USERID)) AS USERID,
        w.INVNTRY_TYPE,
        w.WATCHLISTCREATEDATE,
        w.WATCHLISTDUEDATE,
        w.WATCHLISTENDDATE,
        w.WATCHLISTACTION,
        w.FOLLOWUPREASON,
        w.LINKEDCASEID,
        w.INTAKESOURCESYSTEM,
        w.PXUPDATEDATETIME,
        w.PXCREATEDATETIME,
        i.LOB,
        ROW_NUMBER() OVER (
            PARTITION BY w.CASEID
            ORDER BY w.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WATCHLIST w
    LEFT JOIN inventory_lob i
        ON w.CASEID = i.PYID
    WHERE 1 = 1
      AND w.WATCHLISTCREATEDATE IS NOT NULL
      AND w.WATCHLISTCREATEDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
      {{watchlist_lob_clause}}
),
watchlist_with_user_info AS (
    SELECT
        w.CASEID,
        w.USERID,
        w.INVNTRY_TYPE,
        w.WATCHLISTCREATEDATE,
        w.WATCHLISTDUEDATE,
        w.WATCHLISTENDDATE,
        w.WATCHLISTACTION,
        w.FOLLOWUPREASON,
        w.LINKEDCASEID,
        w.INTAKESOURCESYSTEM,
        w.PXUPDATEDATETIME,
        w.PXCREATEDATETIME,
        w.LOB,
        u.USERNAME,
        u.FIRSTNAME,
        u.LASTNAME,
        u.manager_id,
        u.manager_firstname,
        u.manager_lastname,
        u.PYACCESSGROUP
    FROM watchlist_deduped w
    LEFT JOIN user_with_manager u
        ON w.USERID = u.USERID
    WHERE w.rn = 1
      {{watchlist_associate_clause}}
      {{watchlist_manager_clause}}
),
active_at_any_point AS (
    SELECT
        CASEID
    FROM watchlist_with_user_info
    WHERE
        (
            WATCHLISTCREATEDATE >= '{{start_date}}'::DATE
            AND WATCHLISTCREATEDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
        )
        OR
        (
            WATCHLISTCREATEDATE < '{{start_date}}'::DATE
            AND (
                WATCHLISTENDDATE IS NULL
                OR WATCHLISTENDDATE >= '{{start_date}}'::DATE
            )
        )
)
SELECT
    COUNT(DISTINCT CASEID) AS WATCHLIST_COUNT
FROM active_at_any_point
"""

# 6. Audit Error Count Query
AUDIT_ERROR_COUNT_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.REPORTTOMANAGERID,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY i.PYID
        ORDER BY i.PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS ASSOCIATE_ID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS MANAGER_ID,
        PYRESOLVEDTIMESTAMP
    FROM latest_inventory
    WHERE UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        ap.PXCREATEDATETIME AS AUDIT_CREATE_TIMESTAMP,
        ap.PXCOMMITDATETIME AS AUDIT_COMMIT_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      AND ap.PXCREATEDATETIME IS NOT NULL
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXCOMMITDATETIME AS ACTIVITY_COMMIT_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
final_base AS (
    SELECT
        i.MANAGER_ID,
        i.ASSOCIATE_ID,
        i.ORIGINAL_OHI_CASE_ID,
        i.PYRESOLVEDTIMESTAMP,
        ap.AUDIT_CASE_ID,
        ap.AUDIT_CREATE_TIMESTAMP,
        ap.AUDIT_COMMIT_TIMESTAMP,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        aa.RESULTTYPE,
        aa.DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.ACTIVITY_COMMIT_TIMESTAMP
    FROM filtered_inventory i
    JOIN audit_profile_deduped ap
      ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
     AND ap.rn = 1
    JOIN audit_activity_deduped aa
      ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
     AND aa.rn = 1
)
SELECT
    COUNT(DISTINCT AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS AUDIT_ERROR_COUNT
FROM final_base
"""

AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        i.PYID,
        i.PYRESOLVEDUSERID,
        i.REPORTTOMANAGERID,
        i.PYSTATUSWORK,
        i.LOB,
        ROW_NUMBER() OVER (
            PARTITION BY i.PYID
            ORDER BY i.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID,
        PYRESOLVEDUSERID,
        REPORTTOMANAGERID
    FROM latest_inventory
    WHERE rn = 1
      AND UPPER(TRIM(PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_profile_deduped AS (
    SELECT
        ap.PYID AS AUDIT_CASE_ID,
        ap.CASE_TO_AUDIT AS ORIGINAL_OHI_CASE_ID,
        UPPER(TRIM(ap.AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        ap.AUDIT_MONTH,
        ap.AUDIT_YEAR,
        ap.PXCOMMITDATETIME AS AUDIT_COMMIT_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY ap.PYID
            ORDER BY ap.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE ap
    WHERE ap.PYID LIKE 'AUD%'
      AND ap.CASE_TO_AUDIT IS NOT NULL
      AND UPPER(TRIM(ap.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSE')
      {{lob_filter}}
      {{associate_filter}}
),
audit_activity_deduped AS (
    SELECT
        aa.CASEID AS AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY,
        UPPER(TRIM(aa.RESULTTYPE)) AS RESULTTYPE,
        aa.PXCREATEDATETIME AS DATE_ASSESSED,
        aa.SPECIALISTERRORCORRECTED,
        aa.PXCOMMITDATETIME AS ACTIVITY_COMMIT_TIMESTAMP,
        ROW_NUMBER() OVER (
            PARTITION BY aa.CASEID, aa.ERRORCATEGORYTYPE, aa.ERRORCATEGORY
            ORDER BY aa.PXCOMMITDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY aa
    WHERE aa.CASEID LIKE 'AUD%'
      AND aa.ERRORCATEGORYTYPE IS NOT NULL
      AND aa.ERRORCATEGORY IS NOT NULL
      AND UPPER(TRIM(aa.RESULTTYPE)) IN ('ERROR', 'FYI')
),
final_base AS (
    SELECT
        ap.AUDIT_CASE_ID,
        aa.ERRORCATEGORYTYPE,
        aa.ERRORCATEGORY
    FROM filtered_inventory i
    JOIN audit_profile_deduped ap
      ON ap.ORIGINAL_OHI_CASE_ID = i.ORIGINAL_OHI_CASE_ID
     AND ap.rn = 1
    JOIN audit_activity_deduped aa
      ON aa.AUDIT_CASE_ID = ap.AUDIT_CASE_ID
     AND aa.rn = 1
    WHERE 1 = 1
      {{audit_period_filter}}
)
SELECT
    COUNT(DISTINCT AUDIT_CASE_ID || '|' || ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) AS AUDIT_ERROR_COUNT
FROM final_base
"""



def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l.strip().upper() for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (UPPER(TRIM(LOB)) IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND UPPER(TRIM(LOB)) IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str], end_date: Optional[str], date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""

def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""

def build_associate_filter_user(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for COB_AI_USER_PROFILE table (uses USERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND USERID IN ('{frontline_associate_ids_str}')"
    return ""


def build_associate_filter_audit(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for COB_AI_AUDIT_PROFILE table (uses AUDIT_SUBJECT_ID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{frontline_associate_ids_str}')"
    return ""


def execute_query(engine, query: str, limit: int = 1):
    """Synchronous query execution (legacy)."""
    return engine.execute_query(query, limit=limit)


def format_fuse_time(total_seconds: int) -> str:
    """
    Format fuse time intelligently based on magnitude:
    - Less than 1 hour: "X min. Y sec."
    - Less than 24 hours: "X hours. Y min."
    - 24 hours or more: "X day. Y hours."
    """
    if total_seconds == 0:
        return "0"
    
    days = total_seconds // 86400  # 86400 seconds in a day
    remaining_after_days = total_seconds % 86400
    hours = remaining_after_days // 3600
    remaining_after_hours = remaining_after_days % 3600
    minutes = remaining_after_hours // 60
    seconds = remaining_after_hours % 60
    
    # If less than 1 hour, show minutes and seconds
    if total_seconds < 3600:
        return f"{minutes} min. {seconds} sec."
    
    # If less than 24 hours, show hours and minutes
    elif total_seconds < 86400:
        hour_word = "hour" if hours == 1 else "hours"
        return f"{hours} {hour_word}. {minutes} min."
    
    # If 24 hours or more, show days and hours
    else:
        day_word = "day" if days == 1 else "days"
        hour_word = "hour" if hours == 1 else "hours"
        return f"{days} {day_word}. {hours} {hour_word}."


def build_audit_month_year_filter(
    audit_periods=None,
    audit_month_column: str = "AUDIT_MONTH",
    audit_year_column: str = "AUDIT_YEAR",
) -> str:
    valid_periods = []
    seen_periods = set()

    for period in audit_periods or []:
        month_value = (period.month or "").strip()
        year_value = str(period.year).strip() if period.year is not None else ""

        if not month_value or not year_value:
            continue

        key = (month_value.upper(), year_value)
        if key in seen_periods:
            continue

        seen_periods.add(key)
        valid_periods.append((month_value, year_value))

    if not valid_periods:
        return ""

    conditions = [
        f"(UPPER(TRIM({audit_month_column})) = UPPER('{month}') AND TRIM({audit_year_column}) = '{year}')"
        for month, year in valid_periods
    ]

    return "AND (" + " OR ".join(conditions) + ")"


@router.post(
    "/quality-outcomes",
    response_model=ManagerQualityOutcomesSimpleResponse,
    summary="Get Quality Outcomes Metrics",
    description="""Retrieve quality outcomes and control metrics for manager dashboard.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values to filter
- **manager_ids** (optional): List of manager IDs to filter associates
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Response Fields:**
- **rebuttal_count**: Count of cases with REBUTTALFLAG = 'Y'
- **rework_pct**: Rework percentage (TBD - logic pending with business)
- **watchlist_count**: Watchlist count (TBD - awaiting definition)
- **completed_audit_count**: Count of completed audits (PYID LIKE 'AUD%')
- **audit_error_count**: Average audit score (audit errors metric)

**Data Source:** COB_AI_AUDIT_PROFILE table
""",
)
async def get_quality_outcomes(request: ManagerQualityOutcomesRequest) -> ManagerQualityOutcomesSimpleResponse:
    # Auto-generate session_id if missing and caching is enabled
    if config.REDIS_ENABLED and not getattr(request, "session_id", None):
        request.session_id = generate_session_id()
        logger.info(f"Auto-generated session_id: {request.session_id}")
    
    return await execute_quality_outcomes_query(request)


async def execute_quality_outcomes_query(request: ManagerQualityOutcomesRequest) -> ManagerQualityOutcomesSimpleResponse:
    """Execute quality outcomes query logic with metric-level caching."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        # Use PXCREATEDATETIME for rework queries in audit table
        rework_date_filter = build_date_filter(request.start_date, request.end_date, date_column="a.PXCREATEDATETIME")
        # Use PXCREATEDATETIME for watchlist query
        watchlist_date_filter = build_date_filter(request.start_date, request.end_date, date_column="PXCREATEDATETIME")
        user_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        manager_filter = build_manager_filter(request.manager_ids)
        manager_filter_user = build_manager_filter_user(request.manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(request.frontline_associate_ids)
        associate_filter_user = build_associate_filter_user(request.frontline_associate_ids)
        associate_filter = build_associate_filter_audit(request.frontline_associate_ids)
        valid_audit_periods = [
            period
            for period in (request.audit_periods or [])
            if (period.month or "").strip() and str(period.year).strip()
        ]

        has_audit_periods = bool(valid_audit_periods)

        audit_manager_filter = ""
        if request.manager_ids and len(request.manager_ids) > 0:
            manager_ids_str = "', '".join(manager_id.strip().upper() for manager_id in request.manager_ids)
            audit_manager_filter = f"AND AUDIT_SUBJECT_MGR_ID IN ('{manager_ids_str}')"
        
        engine = connection_manager.get_engine()

        # Format the 5 required queries
        if has_audit_periods:
            rebuttal_audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="AUDIT_MONTH",
                audit_year_column="AUDIT_YEAR",
            )

            rebuttal_query = REBUTTAL_COUNT_AUDIT_PERIOD_QUERY.format(
                audit_period_filter=rebuttal_audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )

            audit_count_query = COMPLETED_AUDIT_COUNT_AUDIT_PERIOD_QUERY.format(
                audit_period_filter=rebuttal_audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )

            audit_error_query = AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY.format(
                audit_period_filter=rebuttal_audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )
        else:
            rebuttal_query = REBUTTAL_COUNT_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )

            audit_count_query = COMPLETED_AUDIT_COUNT_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )

            audit_error_query = AUDIT_ERROR_COUNT_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )
        
        
        rework_manager_filter = ""
        if request.manager_ids and len(request.manager_ids) > 0:
            mgr_ids_str = "', '".join(request.manager_ids)
            rework_manager_filter = f"AND ah.REPORTTOMANAGERID IN ('{mgr_ids_str}')"

        rework_associate_filter = ""
        if request.frontline_associate_ids and len(request.frontline_associate_ids) > 0:
            assoc_ids_str = "', '".join(request.frontline_associate_ids)
            rework_associate_filter = f"AND ah.PYRESOLVEDUSERID IN ('{assoc_ids_str}')"

        rework_query = REWORK_COUNT_QUERY.format(
            rework_date_filter=rework_date_filter,
            lob_filter=lob_filter,
            manager_filter=rework_manager_filter,
            associate_filter_invntry=rework_associate_filter,
        )
        
        # Use LOGINDATE for USER_PROFILE table instead of PYRESOLVEDTIMESTAMP
        fuse_date_filter = build_date_filter(request.start_date, request.end_date, date_column="LOGINDATE")
        # For USER_PROFILE table, manager filter is disabled and associate filter uses USERID
        fuse_manager_filter = ""  # Disabled for Manager APIs
        fuse_associate_filter = ""
        if request.frontline_associate_ids and len(request.frontline_associate_ids) > 0:
            frontline_associate_ids_str = "', '".join(request.frontline_associate_ids)
            fuse_associate_filter = f"AND u.USERID IN ('{frontline_associate_ids_str}')"
        fuse_time_query = FUSE_TIME_QUERY.format(
            date_filter=fuse_date_filter,
            manager_filter=fuse_manager_filter,
            associate_filter=fuse_associate_filter
        )

        watchlist_lob_clause = ""
        if request.lob and len(request.lob) > 0:
            null_requested = "None" in request.lob
            non_null_lobs = [l for l in request.lob if l != "None"]

            if null_requested and non_null_lobs:
                lob_values = "', '".join(non_null_lobs)
                watchlist_lob_clause = f"AND (i.LOB IN ('{lob_values}') OR i.LOB IS NULL)"
            elif null_requested:
                watchlist_lob_clause = "AND i.LOB IS NULL"
            elif non_null_lobs:
                lob_values = "', '".join(non_null_lobs)
                watchlist_lob_clause = f"AND i.LOB IN ('{lob_values}')"

        watchlist_associate_clause = ""
        if request.frontline_associate_ids and len(request.frontline_associate_ids) > 0:
            associate_values = "', '".join(associate_id.strip().upper() for associate_id in request.frontline_associate_ids)
            watchlist_associate_clause = f"AND w.USERID IN ('{associate_values}')"

        watchlist_manager_clause = ""
        if request.manager_ids and len(request.manager_ids) > 0:
            manager_values = "', '".join(manager_id.strip().upper() for manager_id in request.manager_ids)
            watchlist_manager_clause = f"AND u.manager_id IN ('{manager_values}')"
        
        # Format watchlist query - uses PYRESOLVEDUSERID for associate filter
        watchlist_query = WATCHLIST_COUNT_QUERY.format(
            start_date=request.start_date or "2020-01-01",
            end_date=request.end_date or "2099-12-31",
            watchlist_lob_clause=watchlist_lob_clause,
            watchlist_associate_clause=watchlist_associate_clause,
            watchlist_manager_clause=watchlist_manager_clause,
        )
        
        # Format rebuttal overturn query
        if has_audit_periods:
            rebuttal_overturn_query = REBUTTAL_OVERTURN_AUDIT_PERIOD_QUERY.format(
                audit_period_filter=rebuttal_audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )
        else:
            rebuttal_overturn_query = REBUTTAL_OVERTURN_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )
        
        # Define fetch functions for each metric
        def fetch_rebuttal():
            return execute_query(engine, rebuttal_query)
        
        def fetch_audit_count():
            return execute_query(engine, audit_count_query)
        
        def fetch_rework():
            return execute_query(engine, rework_query)
        
        def fetch_fuse_time():
            return execute_query(engine, fuse_time_query)
        
        def fetch_watchlist_count():
            return execute_query(engine, watchlist_query)
        
        def fetch_rebuttal_overturn():
            return execute_query(engine, rebuttal_overturn_query)
        
        def fetch_audit_error():
            return execute_query(engine, audit_error_query)
        
        # Get or fetch cached metrics (only cache if session_id provided)
        session_id = getattr(request, "session_id", None)
        if session_id:
            rebuttal_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_rebuttal,
                session_id=session_id,
                metric_name="rebuttal_count"
            )
            
            audit_count_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_count,
                session_id=session_id,
                metric_name="completed_audit_count"
            )
            
            rework_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_rework,
                session_id=session_id,
                metric_name="rework_count"
            )
            
            fuse_time_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_fuse_time,
                session_id=session_id,
                metric_name="fuse_time"
            )
            
            watchlist_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_watchlist_count,
                session_id=session_id,
                metric_name="watchlist_count"
            )
            
            rebuttal_overturn_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_rebuttal_overturn,
                session_id=session_id,
                metric_name="rebuttal_overturn"
            )
            
            audit_error_records = await metric_cache_service.get_or_fetch_metric(
                fetch_func=fetch_audit_error,
                session_id=session_id,
                metric_name="audit_error_count"
            )
        else:
            # No session_id - execute all 7 queries in parallel without caching
            logger.info("Executing 7 Manager quality outcomes queries in parallel")
            (
                rebuttal_records,
                audit_count_records,
                rework_records,
                fuse_time_records,
                watchlist_records,
                rebuttal_overturn_records,
                audit_error_records
            ) = await asyncio.gather(
                engine.execute_query_async(rebuttal_query, limit=1),
                engine.execute_query_async(audit_count_query, limit=1),
                engine.execute_query_async(rework_query, limit=1),
                engine.execute_query_async(fuse_time_query, limit=1),
                engine.execute_query_async(watchlist_query, limit=1),
                engine.execute_query_async(rebuttal_overturn_query, limit=1),
                engine.execute_query_async(audit_error_query, limit=1),
                return_exceptions=False
            )
            logger.info("Parallel query execution completed")

        # Extract results from the queries - only populate fields used in UI
        rebuttal_count = int(rebuttal_records[0].get("REBUTTAL_COUNT", 0)) if rebuttal_records else 0
        completed_audit_count = int(audit_count_records[0].get("COMPLETED_AUDIT_COUNT", 0)) if audit_count_records else 0
        audit_error_count = int(audit_error_records[0].get("AUDIT_ERROR_COUNT", 0)) if audit_error_records else 0
        
        # Calculate fuse_time from database and format appropriately
        total_fuse_seconds = int(fuse_time_records[0].get("TOTAL_FUSE_TIME_SECONDS", 0)) if fuse_time_records and fuse_time_records[0].get("TOTAL_FUSE_TIME_SECONDS") else 0
        fuse_time = format_fuse_time(total_fuse_seconds)
        
        # Extract rework count from query results
        rework_count = int(rework_records[0].get("REWORK_COUNT", 0)) if rework_records else 0
        rework_pct = str(rework_count)  # Return count as string
        
        # Extract watchlist count from query results
        watchlist_count = int(watchlist_records[0].get("WATCHLIST_COUNT", 0)) if watchlist_records else 0
        
        # Calculate rebuttal overturn percentage from query results
        if rebuttal_overturn_records and len(rebuttal_overturn_records) > 0:
            total_rebuttals = int(rebuttal_overturn_records[0].get("TOTAL_REBUTTALS", 0))
            overturned_count = int(rebuttal_overturn_records[0].get("OVERTURNED_COUNT", 0))
            
            if total_rebuttals > 0:
                overturn_pct = (overturned_count / total_rebuttals) * 100
                rebuttal_overturn_pct = f"{overturn_pct:.2f} % Overturned"
            else:
                rebuttal_overturn_pct = "0.00 % Overturned"
        else:
            rebuttal_overturn_pct = "N/A"

        tooltips = {
            "rebuttal_count": "Number of cases where associate submitted a rebuttal",
            "rebuttal_overturn_pct": "Percentage of rebuttals that were overturned (Error Retracted, FYI Retracted, Changed to FYI)",
            "rework_pct": "Count of items with TARGET_AUDIT = 'Rework' in the selected timeframe",
            "fuse_time": "Total FUSE time in hours",
            "completed_audit_count": "Total number of completed audits (PYID starting with 'AUD')",
            "audit_error_count": "Total number of audit errors (ERROR or FYI) found across all completed audits",
            "watchlist_count": "Number of work items on the watchlist (ISADDTOWATCHLIST = 'Y')"
        }

        return ManagerQualityOutcomesSimpleResponse(
            status="success",
            completed_audit_count=completed_audit_count,
            audit_error_count=str(audit_error_count),
            rebuttal_count=rebuttal_count,
            rebuttal_overturn_pct=rebuttal_overturn_pct,
            rework_pct=rework_pct,
            fuse_time=fuse_time,
            watchlist_count=watchlist_count,
            message="Quality outcomes metrics retrieved successfully",
            tooltips=tooltips,
            session_id=getattr(request, "session_id", None)
        )

    except Exception as e:
        logger.error(f"Quality outcomes query error: {type(e).__name__}: {str(e)}")
        return ManagerQualityOutcomesSimpleResponse(
            status="error",
            completed_audit_count=0,
            audit_error_count="N/A",
            rebuttal_count=0,
            rebuttal_overturn_pct="N/A",
            rework_pct="N/A",
            fuse_time="N/A",
            watchlist_count=0,
            message=f"Failed to retrieve quality outcomes metrics: {str(e)}"
        )
