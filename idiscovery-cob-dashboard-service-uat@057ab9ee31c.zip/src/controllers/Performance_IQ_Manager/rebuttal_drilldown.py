import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from schema import (
    RebuttalDrilldownPaginatedRequest,
    RebuttalDrilldownPaginatedResponse,
    RebuttalRecord,
    PageResponse,
    ManagerBaseDownloadRequest,
)
import math
from .quality_outcomes import (
    REBUTTAL_COUNT_QUERY, 
    REBUTTAL_COUNT_AUDIT_PERIOD_QUERY,
    build_audit_month_year_filter
)

def format_datetime_mmddyyyy(datetime_str: str) -> str:
    """Convert datetime to MM/DD/YYYY format"""
    if not datetime_str:
        return ""
    try:
        # Handle both date and datetime formats
        if 'T' in str(datetime_str):
            date_obj = datetime.strptime(str(datetime_str).split('T')[0], "%Y-%m-%d")
        else:
            date_obj = datetime.strptime(str(datetime_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(datetime_str)

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str), "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

def format_outcome_status(status: str) -> str:
    """Format outcome status"""
    if not status:
        return ""
    return str(status).strip()

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()

REBUTTAL_PAGINATED_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        resolved_date
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{manager_filter}}
      {{associate_filter_invntry}}
),
latest_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(AUDIT_SUBJECT_MGR_ID)) AS AUDIT_SUBJECT_MGR_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        LOB,
        INTAKESOURCESYSTEM,
        PYRESOLVEDTIMESTAMP AS audit_resolved_timestamp,
        DATE(PYRESOLVEDTIMESTAMP) AS audit_resolved_date,
        PLATFORM,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        AUDIT_SUBJECT_ID,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        audit_resolved_timestamp,
        audit_resolved_date,
        PLATFORM,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM latest_audit
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND CASE_TO_AUDIT IS NOT NULL
      {{lob_filter}}
      {{associate_filter}}
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
audit_activity_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
      AND REBUTTALOUTCOME IS NOT NULL
      AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
      AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    a.PYID as work_item_id,
    a.INTAKESOURCESYSTEM as worktype_category,
    a.PYSTATUSWORK as outcome_status,
    a.LOB,
    i.resolved_date as resolved_date,
    a.AUDIT_SUBJECT_ID as audit_subject_id,
    u.USERNAME as auditor_name,
    a.PLATFORM as platform_source_system,
    rd.ERRORCATEGORY as error_category,
    rd.ERRORCATEGORYTYPE as error_type,
    rd.REBUTTALOUTCOME as rebuttal_outcome,
    a.AUDIT_MONTH as audit_month,
    a.AUDIT_YEAR as audit_year
FROM filtered_inventory i
INNER JOIN filtered_audit a
    ON i.PYID = a.CASE_TO_AUDIT
INNER JOIN eligible_rebuttal_line_items rd
    ON a.PYID = rd.CASEID
LEFT JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

# Audit Period version - filters by AUDIT_MONTH/AUDIT_YEAR instead of resolved date
REBUTTAL_PAGINATED_AUDIT_PERIOD_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        DATE(PYRESOLVEDTIMESTAMP) AS resolved_date,
        UPPER(TRIM(PYRESOLVEDUSERID)) AS PYRESOLVEDUSERID,
        UPPER(TRIM(REPORTTOMANAGERID)) AS REPORTTOMANAGERID,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID AS ORIGINAL_OHI_CASE_ID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{manager_filter}}
      {{associate_filter_invntry}}
),
audit_base AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        UPPER(TRIM(AUDIT_SUBJECT_ID)) AS AUDIT_SUBJECT_ID,
        UPPER(TRIM(REBUTTALFLAG)) AS REBUTTALFLAG,
        UPPER(TRIM(PYSTATUSWORK)) AS PYSTATUSWORK,
        LOB,
        INTAKESOURCESYSTEM,
        PYRESOLVEDTIMESTAMP AS audit_resolved_timestamp,
        DATE(PYRESOLVEDTIMESTAMP) AS audit_resolved_date,
        PLATFORM,
        PXCREATEDATETIME,
        AUDIT_MONTH,
        AUDIT_YEAR
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE CASE_TO_AUDIT IS NOT NULL
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
audit_filtered AS (
    SELECT
        ab.PYID,
        ab.CASE_TO_AUDIT,
        ab.AUDIT_SUBJECT_ID,
        ab.INTAKESOURCESYSTEM,
        ab.PYSTATUSWORK,
        ab.LOB,
        ab.audit_resolved_timestamp,
        ab.audit_resolved_date,
        ab.PLATFORM,
        ab.AUDIT_MONTH,
        ab.AUDIT_YEAR
    FROM audit_base ab
    INNER JOIN filtered_inventory i
        ON ab.CASE_TO_AUDIT = i.ORIGINAL_OHI_CASE_ID
    WHERE ab.REBUTTALFLAG = 'Y'
      AND ab.PYID LIKE 'AUD%'
      AND ab.PYSTATUSWORK = 'RESOLVED-COMPLETED'
      AND ab.PXCREATEDATETIME IS NOT NULL
      {{audit_period_filter}}
      {{lob_filter}}
      {{associate_filter}}
),
deduped_user_profile AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
audit_activity_deduped AS (
    SELECT 
        CASEID,
        UPPER(TRIM(ERRORCATEGORYTYPE)) AS ERRORCATEGORYTYPE,
        UPPER(TRIM(ERRORCATEGORY)) AS ERRORCATEGORY,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, UPPER(TRIM(ERRORCATEGORYTYPE)), UPPER(TRIM(ERRORCATEGORY))
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
),
eligible_rebuttal_line_items AS (
    SELECT
        CASEID,
        ERRORCATEGORYTYPE,
        ERRORCATEGORY,
        REBUTTALOUTCOME
    FROM audit_activity_deduped
    WHERE rn = 1
      AND REBUTTALOUTCOME IS NOT NULL
      AND NULLIF(TRIM(REBUTTALOUTCOME), '') IS NOT NULL
      AND UPPER(TRIM(REBUTTALOUTCOME)) <> 'N/A'
)
SELECT
    a.PYID as work_item_id,
    a.INTAKESOURCESYSTEM as worktype_category,
    a.PYSTATUSWORK as outcome_status,
    a.LOB,
    a.audit_resolved_date as resolved_date,
    a.AUDIT_SUBJECT_ID as audit_subject_id,
    u.USERNAME as auditor_name,
    a.PLATFORM as platform_source_system,
    rd.ERRORCATEGORY as error_category,
    rd.ERRORCATEGORYTYPE as error_type,
    rd.REBUTTALOUTCOME as rebuttal_outcome,
    a.AUDIT_MONTH as audit_month,
    a.AUDIT_YEAR as audit_year
FROM audit_filtered a
INNER JOIN eligible_rebuttal_line_items rd
    ON a.PYID = rd.CASEID
LEFT JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
ORDER BY a.audit_resolved_timestamp DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

# REBUTTAL_COUNT_QUERY and REBUTTAL_COUNT_AUDIT_PERIOD_QUERY are now imported from quality_outcomes.py

REBUTTAL_DEFAULT_ORDER_BY = "ORDER BY i.PYRESOLVEDTIMESTAMP DESC"
REBUTTAL_AUDIT_PERIOD_DEFAULT_ORDER_BY = "ORDER BY a.audit_resolved_timestamp DESC"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item_id": "a.PYID",
        "worktype_category": "a.INTAKESOURCESYSTEM",
        "outcome_status": "a.PYSTATUSWORK",
        "lob": "a.LOB",
        "resolved_date": "i.PYRESOLVEDTIMESTAMP",
        "domain_id": "COALESCE(u.USERNAME, a.AUDIT_SUBJECT_ID)",
        "platform_source_system": "a.PLATFORM",
        "error_category": "rd.ERRORCATEGORY",
        "error_type": "rd.ERRORCATEGORYTYPE",
        "rebuttal_outcome": "rd.REBUTTALOUTCOME",
        "audit_month": "a.AUDIT_MONTH",
        "audit_year": "a.AUDIT_YEAR",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return REBUTTAL_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, a.PYID, rd.ERRORCATEGORYTYPE, rd.ERRORCATEGORY"

def build_sort_clause_audit_period(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    """Build sort clause for audit period queries (no inventory table)."""
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item_id": "a.PYID",
        "worktype_category": "a.INTAKESOURCESYSTEM",
        "outcome_status": "a.PYSTATUSWORK",
        "lob": "a.LOB",
        "resolved_date": "a.audit_resolved_timestamp",
        "domain_id": "COALESCE(u.USERNAME, a.AUDIT_SUBJECT_ID)",
        "platform_source_system": "a.PLATFORM",
        "error_category": "rd.ERRORCATEGORY",
        "error_type": "rd.ERRORCATEGORYTYPE",
        "rebuttal_outcome": "rd.REBUTTALOUTCOME",
        "audit_month": "a.AUDIT_MONTH",
        "audit_year": "a.AUDIT_YEAR",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return REBUTTAL_AUDIT_PERIOD_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, a.PYID, rd.ERRORCATEGORYTYPE, rd.ERRORCATEGORY"

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None, date_column: str = "PYRESOLVEDTIMESTAMP") -> str:
    """Build date filter for rebuttal queries. Default uses PYRESOLVEDTIMESTAMP from inventory."""
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column}::DATE >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_user_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for LOGINDATE column in COB_AI_USER_PROFILE."""
    if start_date and end_date:
        return (
            f"AND LOGINDATE >= '{start_date}' "
            f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND LOGINDATE::DATE >= '{start_date}'"
    elif end_date:
        return f"AND LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_manager_filter_user(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for COB_AI_USER_PROFILE table (uses PYREPORTTO)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND PYREPORTTO IN ('{manager_ids_str}')"
    return ""

def build_associate_filter_user(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for COB_AI_USER_PROFILE table (uses USERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND USERID IN ('{frontline_associate_ids_str}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for COB_AI_AUDIT_PROFILE table (uses AUDIT_SUBJECT_ID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND AUDIT_SUBJECT_ID IN ('{frontline_associate_ids_str}')"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""

@router.post(
    "/rebuttal-drilldown",
    response_model=RebuttalDrilldownPaginatedResponse,
    summary="Get Rebuttal Drilldown (Manager)",
    description="""
Retrieve paginated list of rebuttal cases for detailed table display (Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs (not used for filtering in Manager APIs)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **work_item_id**: Unique work item identifier (PYID)
- **worktype_category**: Work type category (INTAKESOURCESYSTEM)
- **outcome_status**: Outcome status (PYSTATUSWORK)
- **lob**: Line of Business
- **resolved_date**: Resolved date (MM/DD/YYYY format)
- **domain_id**: Domain ID associated with the audit
- **platform_source_system**: Platform source system (PLATFORM)
- **error_category**: Error category identified during audit
- **error_type**: Error type classification
- **rebuttal_outcome**: Outcome of the rebuttal decision

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Data Sources:** 
- COB_AI_AUDIT_PROFILE (rebuttal data)
- COB_AI_AUDIT_ACTIVITY (error category and rebuttal outcome)
- COB_AI_USER_PROFILE (associate information)
""",
)
async def get_rebuttal_drilldown(
    request: RebuttalDrilldownPaginatedRequest
) -> RebuttalDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        audit_periods = request.audit_periods
        
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Validate audit periods
        valid_audit_periods = []
        if audit_periods:
            for period in audit_periods:
                if period.month and period.year:
                    valid_audit_periods.append(period)
        
        has_audit_periods = bool(valid_audit_periods)
        
        lob_filter = build_lob_filter(lob)
        date_filter = build_date_filter(start_date, end_date)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        
        # Build audit manager filter for audit period queries
        audit_manager_filter = ""
        if manager_ids and len(manager_ids) > 0:
            manager_ids_str = "', '".join(manager_id.strip().upper() for manager_id in manager_ids)
            audit_manager_filter = f"AND AUDIT_SUBJECT_MGR_ID IN ('{manager_ids_str}')"
        
        engine = connection_manager.get_engine()
        
        # Always run the appropriate COUNT query to ensure correct totals
        # Don't reuse cache from quality outcomes as it may be stale or for different filter mode
        total_records = 0
        
        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="AUDIT_MONTH",
                audit_year_column="AUDIT_YEAR",
            )
            count_query = REBUTTAL_COUNT_AUDIT_PERIOD_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
            )
        else:
            count_query = REBUTTAL_COUNT_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry
            )
        
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = count_result[0].get("REBUTTAL_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Use appropriate query based on audit_periods
        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="AUDIT_MONTH",
                audit_year_column="AUDIT_YEAR",
            )
            data_query = REBUTTAL_PAGINATED_AUDIT_PERIOD_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                limit=page_limit,
                offset=offset
            )
            data_query = data_query.replace(
                REBUTTAL_AUDIT_PERIOD_DEFAULT_ORDER_BY,
                build_sort_clause_audit_period(request.sort_by, request.sort_direction),
                1
            )
        else:
            data_query = REBUTTAL_PAGINATED_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                limit=page_limit,
                offset=offset
            )
            data_query = data_query.replace(
                REBUTTAL_DEFAULT_ORDER_BY,
                build_sort_clause(request.sort_by, request.sort_direction),
                1
            )
        
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        rebuttal_records = [
            RebuttalRecord(
                work_item_id=record.get("WORK_ITEM_ID") or "N/A",
                worktype_category=record.get("WORKTYPE_CATEGORY") or "N/A",
                outcome_status=format_outcome_status(record.get("OUTCOME_STATUS")) or "N/A",
                lob=record.get("LOB") or "",
                resolved_date=format_date_mmddyyyy(record.get("RESOLVED_DATE")),
                domain_id=record.get("AUDITOR_NAME") or record.get("AUDIT_SUBJECT_ID") or "N/A",
                platform_source_system=record.get("PLATFORM_SOURCE_SYSTEM") or "",
                error_category=record.get("ERROR_CATEGORY") or "N/A",
                error_type=record.get("ERROR_TYPE") or "N/A",
                rebuttal_outcome=record.get("REBUTTAL_OUTCOME") or "N/A",
                associate_name=record.get("AUDITOR_NAME") or "N/A",
                audit_month=record.get("AUDIT_MONTH") or "N/A",
                audit_year=record.get("AUDIT_YEAR") or "N/A"
            )
            for record in records
        ] if records else []
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item_id": "Unique identifier for the work item (PYID)",
            "worktype_category": "Work type category or source system",
            "outcome_status": "Outcome status of the rebuttal case",
            "lob": "Line of Business associated with the work item",
            "resolved_date": "Audit Date - Date when the audit was resolved",
            "domain_id": "Domain ID associated with the audit",
            "platform_source_system": "Platform or source system where the case was processed",
            "error_category": "Error category identified during audit",
            "error_type": "Error type classification",
            "rebuttal_outcome": "Outcome of the rebuttal decision",
            "audit_month": "Audit Month",
            "audit_year": "Audit Year"
        }

        return RebuttalDrilldownPaginatedResponse(
            status="success",
            screen_id="rebuttal_manager",
            user_id=request.user_id,
            page=page_response,
            records=rebuttal_records,
            message="Rebuttal records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Paginated rebuttal drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return RebuttalDrilldownPaginatedResponse(
            status="error",
            screen_id="rebuttal_manager",
            user_id=request.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve rebuttal records: {str(e)}"
        )


@router.post(
    "/rebuttal-drilldown/download-excel",
    summary="Download Rebuttal Drilldown as Excel (Manager)",
    description="""
Download complete rebuttal drilldown data as an Excel file (Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs (not used for filtering in Manager APIs)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all rebuttal records
""",
)
async def download_rebuttal_drilldown_excel(
    request: ManagerBaseDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        audit_periods = request.audit_periods
        
        # Validate audit periods
        valid_audit_periods = []
        if audit_periods:
            for period in audit_periods:
                if period.month and period.year:
                    valid_audit_periods.append(period)
        
        has_audit_periods = bool(valid_audit_periods)
        
        lob_filter = build_lob_filter(lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(frontline_associate_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        
        # Build audit manager filter for audit period queries
        audit_manager_filter = ""
        if manager_ids and len(manager_ids) > 0:
            manager_ids_str = "', '".join(manager_id.strip().upper() for manager_id in manager_ids)
            audit_manager_filter = f"AND AUDIT_SUBJECT_MGR_ID IN ('{manager_ids_str}')"
        
        engine = connection_manager.get_engine()
        
        # Use appropriate query based on audit_periods
        if has_audit_periods:
            audit_period_filter = build_audit_month_year_filter(
                audit_periods=valid_audit_periods,
                audit_month_column="AUDIT_MONTH",
                audit_year_column="AUDIT_YEAR",
            )
            download_query = REBUTTAL_PAGINATED_AUDIT_PERIOD_QUERY.format(
                audit_period_filter=audit_period_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                limit=config.CACHE_FULL_DATASET_LIMIT,
                offset=0
            )
        else:
            download_query = REBUTTAL_PAGINATED_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                associate_filter=associate_filter,
                manager_filter=manager_filter,
                associate_filter_invntry=associate_filter_invntry,
                limit=config.CACHE_FULL_DATASET_LIMIT,
                offset=0
            )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Rebuttal Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Error Type",
            "Error Category",
            "Rebuttal Outcome",
            "Status",
            "LOB",
            "Audit Date",
            "Audit Month",
            "Audit Year",
            "Associate Name"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("WORK_ITEM_ID", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("WORKTYPE_CATEGORY", "")))
            ws.cell(row=row_num, column=3, value=str(row.get("ERROR_TYPE") or "N/A"))
            ws.cell(row=row_num, column=4, value=str(row.get("ERROR_CATEGORY") or "N/A"))
            ws.cell(row=row_num, column=5, value=str(row.get("REBUTTAL_OUTCOME") or "N/A"))
            ws.cell(row=row_num, column=6, value=format_outcome_status(str(row.get("OUTCOME_STATUS", ""))))
            ws.cell(row=row_num, column=7, value=str(row.get("LOB", "")))
            ws.cell(row=row_num, column=8, value=format_date_mmddyyyy(str(row.get("RESOLVED_DATE", ""))) if row.get("RESOLVED_DATE") else "")
            ws.cell(row=row_num, column=9, value=str(row.get("AUDIT_MONTH") or "N/A"))
            ws.cell(row=row_num, column=10, value=str(row.get("AUDIT_YEAR") or "N/A"))
            ws.cell(row=row_num, column=11, value=str(row.get("AUDITOR_NAME") or row.get("AUDIT_SUBJECT_ID") or "N/A"))
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"rebuttal_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for rebuttal drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")