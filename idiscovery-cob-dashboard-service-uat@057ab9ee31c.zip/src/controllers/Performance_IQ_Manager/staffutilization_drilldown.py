import logging
import math
from io import BytesIO
from typing import Optional, List, Dict

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from pydantic import BaseModel, Field

from db import SnowflakeConnectionManager
from schema import (
    ManagerAssociateUtilizationBreakdownRequest,
    PageResponse,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()


class StaffUtilizationDrilldownPaginatedRequest(ManagerAssociateUtilizationBreakdownRequest):
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")


class StaffUtilizationAssociateRow(BaseModel):
    associate_id: str
    associate_name: str
    staff_utilization_pct: float = 0
    available_hours: float = 0
    productive_hours: float = 0


class StaffUtilizationTeamTotalRow(BaseModel):
    staff_utilization_pct: float = 0
    available_hours: float = 0
    productive_hours: float = 0


class StaffUtilizationManagerGroup(BaseModel):
    manager_id: str
    manager_name: str
    associates: List[StaffUtilizationAssociateRow] = Field(default_factory=list)
    team_total: Optional[StaffUtilizationTeamTotalRow] = None


class StaffUtilizationPeriodGroup(BaseModel):
    period_start: str
    period_end: str
    period_label: str
    managers: List[StaffUtilizationManagerGroup] = Field(default_factory=list)


class StaffUtilizationDrilldownPaginatedResponse(BaseModel):
    status: str
    view_type: str
    page: PageResponse
    periods: List[StaffUtilizationPeriodGroup] = Field(default_factory=list)
    message: str
    tooltips: Optional[Dict[str, str]] = None
    service: str = "idiscovery-cob-dashboard-service"


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""


def build_associate_filter_invntry(frontline_associate_ids: Optional[List[str]] = None) -> str:
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND PYRESOLVEDUSERID IN ('{associate_ids_str}')"
    return ""


def normalize_view_type(view_type: str) -> str:
    normalized = (view_type or "weekly").strip().lower()
    if normalized not in {"daily", "weekly", "monthly"}:
        raise ValueError("view_type must be one of: daily, weekly, monthly")
    return normalized


def build_period_expressions(view_type: str, start_date: str, end_date: str):
    start_date_sql = f"'{start_date}'::DATE"
    end_date_sql = f"'{end_date}'::DATE"

    if view_type == "daily":
        period_start_expr = "DATE(up.LOGINDATE)"
        period_end_expr = "DATE(up.LOGINDATE)"
        period_label_expr = "TO_VARCHAR(period_start, 'MM/DD/YYYY')"
    elif view_type == "weekly":
        full_week_start_expr = (
            "DATEADD(DAY, 1 - DAYOFWEEKISO(DATE(up.LOGINDATE)), DATE(up.LOGINDATE))"
        )
        period_start_expr = f"GREATEST({full_week_start_expr}, {start_date_sql})"
        period_end_expr = f"LEAST(DATEADD(DAY, 6, {full_week_start_expr}), {end_date_sql})"
        period_label_expr = "TO_VARCHAR(period_start, 'MM/DD/YYYY') || ' - ' || TO_VARCHAR(period_end, 'MM/DD/YYYY')"
    else:
        period_start_expr = f"GREATEST(DATE_TRUNC('MONTH', up.LOGINDATE), {start_date_sql})"
        period_end_expr = f"LEAST(LAST_DAY(up.LOGINDATE), {end_date_sql})"
        period_label_expr = "TO_VARCHAR(period_start, 'Mon YYYY')"

    return period_start_expr, period_end_expr, period_label_expr


def build_breakdown_query(
    start_date: str,
    end_date: str,
    view_type: str,
    manager_filter: str,
    associate_filter_invntry: str,
) -> str:
    period_start_expr, period_end_expr, period_label_expr = build_period_expressions(
        view_type, start_date, end_date
    )

    return f"""
WITH associate_hierarchy AS (
    SELECT DISTINCT
        PYRESOLVEDUSERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP >= '{start_date}'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)
      {associate_filter_invntry}
      {manager_filter}
),
user_names AS (
    SELECT
        USERID,
        USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC NULLS LAST, LOGINDATE DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERNAME IS NOT NULL
),
filtered_user_rows AS (
    SELECT
        {period_start_expr} AS period_start,
        {period_end_expr} AS period_end,
        up.PYREPORTTO AS manager_id,
        COALESCE(up.REPORTTOUSERNAME, mgr.USERNAME, up.PYREPORTTO, 'Unknown') AS manager_name,
        up.USERID AS associate_id,
        COALESCE(up.USERNAME, assoc.USERNAME, up.USERID, 'Unknown') AS associate_name,
        up.LOGINDATE AS login_date,
        COALESCE(up.TOTALSYSTEMTIME, 0) AS total_system_seconds,
        COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0) AS non_productive_seconds,
        up.PRODUCTIVETIME AS productive_time
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE up
    INNER JOIN associate_hierarchy ah
        ON up.USERID = ah.PYRESOLVEDUSERID
    LEFT JOIN user_names mgr
        ON up.PYREPORTTO = mgr.USERID
        AND mgr.rn = 1
    LEFT JOIN user_names assoc
        ON up.USERID = assoc.USERID
        AND assoc.rn = 1
    WHERE up.TOTALSYSTEMTIME IS NOT NULL
      AND up.LOGINDATE >= '{start_date}'
      AND up.LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)
),
raw_aggregated AS (
    SELECT
        period_start,
        period_end,
        manager_id,
        manager_name,
        associate_id,
        associate_name,
        SUM(total_system_seconds) AS total_system_seconds,
        SUM(non_productive_seconds) AS non_productive_seconds
    FROM filtered_user_rows
    GROUP BY
        period_start,
        period_end,
        manager_id,
        manager_name,
        associate_id,
        associate_name
),
productive_aggregated AS (
    SELECT
        period_start,
        period_end,
        manager_id,
        associate_id,
        SUM(
            CASE
                WHEN productive_time IS NOT NULL AND productive_time != '' THEN
                    SPLIT_PART(productive_time, ':', 1)::INTEGER * 3600 +
                    SPLIT_PART(productive_time, ':', 2)::INTEGER * 60 +
                    SPLIT_PART(productive_time, ':', 3)::INTEGER
                ELSE 0
            END
        ) AS productive_seconds
    FROM filtered_user_rows
    GROUP BY
        period_start,
        period_end,
        manager_id,
        associate_id
),
base_rows AS (
    SELECT
        raw.period_start,
        raw.period_end,
        raw.manager_id,
        raw.manager_name,
        raw.associate_id,
        raw.associate_name,
        raw.total_system_seconds,
        raw.non_productive_seconds,
        COALESCE(prod.productive_seconds, 0) AS productive_seconds
    FROM raw_aggregated raw
    LEFT JOIN productive_aggregated prod
        ON raw.period_start = prod.period_start
        AND raw.period_end = prod.period_end
        AND COALESCE(raw.manager_id, '') = COALESCE(prod.manager_id, '')
        AND COALESCE(raw.associate_id, '') = COALESCE(prod.associate_id, '')
),
rollup AS (
    SELECT
        period_start,
        period_end,
        manager_id,
        manager_name,
        associate_id,
        associate_name,
        SUM(total_system_seconds) AS total_system_seconds,
        SUM(non_productive_seconds) AS non_productive_seconds,
        SUM(productive_seconds) AS productive_seconds
    FROM base_rows
    GROUP BY GROUPING SETS (
        (period_start, period_end, manager_id, manager_name, associate_id, associate_name),
        (period_start, period_end, manager_id, manager_name)
    )
)
SELECT
    period_start AS PERIOD_START_DATE,
    period_end AS PERIOD_END_DATE,
    TO_VARCHAR(period_start, 'MM/DD/YYYY') AS PERIOD_START,
    TO_VARCHAR(period_end, 'MM/DD/YYYY') AS PERIOD_END,
    {period_label_expr} AS PERIOD_LABEL,
    manager_id AS MANAGER_ID,
    manager_name AS MANAGER_NAME,
    CASE
        WHEN associate_id IS NULL THEN 'TEAM_TOTAL'
        ELSE associate_id
    END AS ASSOCIATE_ID,
    CASE
        WHEN associate_id IS NULL THEN 'Team Total'
        ELSE associate_name
    END AS ASSOCIATE_NAME,
    CASE
        WHEN associate_id IS NULL THEN TRUE
        ELSE FALSE
    END AS IS_TEAM_TOTAL,
    ROUND(total_system_seconds / 3600.0, 2) AS TOTAL_SYSTEM_HOURS,
    ROUND(non_productive_seconds / 3600.0, 2) AS NON_PRODUCTIVE_HOURS,
    ROUND((total_system_seconds - non_productive_seconds) / 3600.0, 2) AS AVAILABLE_HOURS,
    ROUND(productive_seconds / 3600.0, 2) AS PRODUCTIVE_HOURS,
    ROUND(GREATEST(total_system_seconds - non_productive_seconds - productive_seconds, 0) / 3600.0, 2) AS OTHER_HOURS,
    ROUND(productive_seconds * 100.0 / NULLIF(total_system_seconds - non_productive_seconds, 0), 2) AS STAFF_UTL_PCT,
    ROUND(productive_seconds * 100.0 / NULLIF(total_system_seconds, 0), 2) AS PRODUCTIVE_PCT_OF_TOTAL_SYSTEM,
    CASE
        WHEN associate_id IS NULL THEN 1
        ELSE 0
    END AS TEAM_TOTAL_SORT_FLAG
FROM rollup
"""


def build_breakdown_count_query(
    start_date: str,
    end_date: str,
    view_type: str,
    manager_filter: str,
    associate_filter_invntry: str,
) -> str:
    base_query = build_breakdown_query(
        start_date=start_date,
        end_date=end_date,
        view_type=view_type,
        manager_filter=manager_filter,
        associate_filter_invntry=associate_filter_invntry,
    )
    return f"""
WITH breakdown AS (
{base_query}
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM (
    SELECT PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_ID, MANAGER_NAME
    FROM breakdown
    GROUP BY PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_ID, MANAGER_NAME
) manager_groups
"""


def build_breakdown_paginated_query(
    start_date: str,
    end_date: str,
    view_type: str,
    manager_filter: str,
    associate_filter_invntry: str,
    limit: int,
    offset: int,
) -> str:
    base_query = build_breakdown_query(
        start_date=start_date,
        end_date=end_date,
        view_type=view_type,
        manager_filter=manager_filter,
        associate_filter_invntry=associate_filter_invntry,
    )
    return f"""
WITH breakdown AS (
{base_query}
),
paged_groups AS (
    SELECT PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_ID, MANAGER_NAME
    FROM breakdown
    GROUP BY PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_ID, MANAGER_NAME
    ORDER BY PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_NAME, MANAGER_ID
    LIMIT {limit} OFFSET {offset}
)
SELECT b.*
FROM breakdown b
INNER JOIN paged_groups pg
    ON b.PERIOD_START_DATE = pg.PERIOD_START_DATE
    AND b.PERIOD_END_DATE = pg.PERIOD_END_DATE
    AND COALESCE(b.MANAGER_ID, '') = COALESCE(pg.MANAGER_ID, '')
    AND COALESCE(b.MANAGER_NAME, '') = COALESCE(pg.MANAGER_NAME, '')
ORDER BY b.PERIOD_START_DATE, b.PERIOD_END_DATE, b.MANAGER_NAME, b.MANAGER_ID, b.TEAM_TOTAL_SORT_FLAG, b.ASSOCIATE_NAME, b.ASSOCIATE_ID
"""


def build_breakdown_page_row_count_query(
    start_date: str,
    end_date: str,
    view_type: str,
    manager_filter: str,
    associate_filter_invntry: str,
    limit: int,
    offset: int,
) -> str:
    base_query = build_breakdown_query(
        start_date=start_date,
        end_date=end_date,
        view_type=view_type,
        manager_filter=manager_filter,
        associate_filter_invntry=associate_filter_invntry,
    )
    return f"""
WITH breakdown AS (
{base_query}
),
paged_groups AS (
    SELECT PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_ID, MANAGER_NAME
    FROM breakdown
    GROUP BY PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_ID, MANAGER_NAME
    ORDER BY PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_NAME, MANAGER_ID
    LIMIT {limit} OFFSET {offset}
)
SELECT COUNT(*) AS TOTAL_COUNT
FROM breakdown b
INNER JOIN paged_groups pg
    ON b.PERIOD_START_DATE = pg.PERIOD_START_DATE
    AND b.PERIOD_END_DATE = pg.PERIOD_END_DATE
    AND COALESCE(b.MANAGER_ID, '') = COALESCE(pg.MANAGER_ID, '')
    AND COALESCE(b.MANAGER_NAME, '') = COALESCE(pg.MANAGER_NAME, '')
"""


def build_breakdown_download_query(
    start_date: str,
    end_date: str,
    view_type: str,
    manager_filter: str,
    associate_filter_invntry: str,
) -> str:
    base_query = build_breakdown_query(
        start_date=start_date,
        end_date=end_date,
        view_type=view_type,
        manager_filter=manager_filter,
        associate_filter_invntry=associate_filter_invntry,
    )
    return f"""
WITH breakdown AS (
{base_query}
)
SELECT *
FROM breakdown
ORDER BY PERIOD_START_DATE, PERIOD_END_DATE, MANAGER_NAME, MANAGER_ID, TEAM_TOTAL_SORT_FLAG, ASSOCIATE_NAME, ASSOCIATE_ID
"""


def build_grouped_periods(records: List[dict]) -> List[StaffUtilizationPeriodGroup]:
    periods_map: Dict[tuple, dict] = {}

    for record in records:
        period_key = (
            record.get("PERIOD_START", "") or "",
            record.get("PERIOD_END", "") or "",
            record.get("PERIOD_LABEL", "") or "",
        )

        if period_key not in periods_map:
            periods_map[period_key] = {
                "period_start": period_key[0],
                "period_end": period_key[1],
                "period_label": period_key[2],
                "managers": [],
                "manager_index": {},
            }

        period_entry = periods_map[period_key]
        manager_key = (
            record.get("MANAGER_ID", "") or "",
            record.get("MANAGER_NAME", "") or "Unknown",
        )

        if manager_key not in period_entry["manager_index"]:
            manager_group = StaffUtilizationManagerGroup(
                manager_id=manager_key[0],
                manager_name=manager_key[1],
            )
            period_entry["manager_index"][manager_key] = manager_group
            period_entry["managers"].append(manager_group)

        manager_group = period_entry["manager_index"][manager_key]
        staff_utilization_pct = float(record.get("STAFF_UTL_PCT", 0) or 0)
        available_hours = float(record.get("AVAILABLE_HOURS", 0) or 0)
        productive_hours = float(record.get("PRODUCTIVE_HOURS", 0) or 0)

        if bool(record.get("IS_TEAM_TOTAL", False)):
            manager_group.team_total = StaffUtilizationTeamTotalRow(
                staff_utilization_pct=staff_utilization_pct,
                available_hours=available_hours,
                productive_hours=productive_hours,
            )
        else:
            manager_group.associates.append(
                StaffUtilizationAssociateRow(
                    associate_id=record.get("ASSOCIATE_ID", "") or "",
                    associate_name=record.get("ASSOCIATE_NAME", "") or "Unknown",
                    staff_utilization_pct=staff_utilization_pct,
                    available_hours=available_hours,
                    productive_hours=productive_hours,
                )
            )

    return [
        StaffUtilizationPeriodGroup(
            period_start=period_entry["period_start"],
            period_end=period_entry["period_end"],
            period_label=period_entry["period_label"],
            managers=period_entry["managers"],
        )
        for period_entry in periods_map.values()
    ]


@router.post(
    "/staff_utilization_drilldown",
    response_model=StaffUtilizationDrilldownPaginatedResponse,
    summary="Get Manager Associate Utilization Breakdown",
    description="""
Retrieve manager-associate utilization rows for daily, weekly, or monthly frontend table rendering.

Input:
- user_id
- start_date
- end_date
- manager_ids
- frontline_associate_ids
- view_type (daily/weekly/monthly)

Returns:
- associate rows
- team total row per manager/period
- productive, available, non-productive, other hours
- staff utilization %
""",
)
async def get_associate_utilization_breakdown(
    request: StaffUtilizationDrilldownPaginatedRequest,
) -> StaffUtilizationDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        view_type = normalize_view_type(request.view_type)
        page_limit = request.page_size
        page = request.page
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(request.frontline_associate_ids)

        count_query = build_breakdown_count_query(
            start_date=request.start_date,
            end_date=request.end_date,
            view_type=view_type,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
        )
        engine = connection_manager.get_engine()
        count_result = await engine.execute_query_async(count_query, limit=1)
        total_records = int(count_result[0].get("TOTAL_COUNT", 0) or 0) if count_result else 0
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        page = min(page, total_pages) if total_pages > 0 else 1
        offset = (page - 1) * page_limit

        page_row_count_query = build_breakdown_page_row_count_query(
            start_date=request.start_date,
            end_date=request.end_date,
            view_type=view_type,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
            limit=page_limit,
            offset=offset,
        )
        page_row_count_result = await engine.execute_query_async(page_row_count_query, limit=1)
        page_row_limit = int(page_row_count_result[0].get("TOTAL_COUNT", 0) or 0) if page_row_count_result else 0

        query = build_breakdown_paginated_query(
            start_date=request.start_date,
            end_date=request.end_date,
            view_type=view_type,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
            limit=page_limit,
            offset=offset,
        )
        records = (
            await engine.execute_query_async(query, limit=page_row_limit)
            if page_row_limit > 0
            else []
        )

        periods = build_grouped_periods(records or [])

        tooltips = {
            "staff_utilization_pct": "Productive hours divided by available hours for the selected period",
            "available_hours": "Available hours calculated as total system hours minus non-productive hours",
            "productive_hours": "Productive hours converted from PRODUCTIVETIME",
        }

        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1,
        )

        return StaffUtilizationDrilldownPaginatedResponse(
            status="success",
            view_type=view_type,
            page=page_response,
            periods=periods,
            message="Manager associate utilization breakdown retrieved successfully",
            tooltips=tooltips,
        )

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Associate utilization breakdown query error: {type(e).__name__}: {str(e)}")
        return StaffUtilizationDrilldownPaginatedResponse(
            status="error",
            view_type=request.view_type or "weekly",
            page=PageResponse(
                page_limit=request.page_size,
                page=request.page,
                total_records=0,
                total_pages=0,
                cursor=None,
                has_next=False,
                has_previous=request.page > 1,
            ),
            periods=[],
            message=f"Failed to retrieve associate utilization breakdown: {str(e)}",
        )


@router.post(
    "/staff_utilization_drilldown/download-excel",
    summary="Download Manager Staff Utilization Drilldown as Excel",
)
async def download_associate_utilization_breakdown_excel(
    request: StaffUtilizationDrilldownPaginatedRequest,
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        view_type = normalize_view_type(request.view_type)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter_invntry = build_associate_filter_invntry(request.frontline_associate_ids)

        download_query = build_breakdown_download_query(
            start_date=request.start_date,
            end_date=request.end_date,
            view_type=view_type,
            manager_filter=manager_filter,
            associate_filter_invntry=associate_filter_invntry,
        )

        engine = connection_manager.get_engine()
        records = await engine.execute_query_async(download_query, limit=None)
        periods = build_grouped_periods(records or [])

        wb = Workbook()
        ws = wb.active
        ws.title = "Manager Staff Utilization"

        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        section_fill = PatternFill(start_color="D9EAF7", end_color="D9EAF7", fill_type="solid")
        section_font = Font(bold=True)

        headers = [
            "Manager Name",
            "Associate Name",
            "Staff Utilization %",
            "Available Hours",
            "Productive Hours",
        ]

        current_row = 1

        for period in periods:
            ws.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=len(headers))
            section_cell = ws.cell(row=current_row, column=1, value=period.period_label or period.period_start)
            section_cell.fill = section_fill
            section_cell.font = section_font
            section_cell.alignment = Alignment(horizontal="center", vertical="center")
            current_row += 1

            for col_num, header in enumerate(headers, 1):
                cell = ws.cell(row=current_row, column=col_num, value=header)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = header_alignment
            current_row += 1

            for manager in period.managers:
                manager_start_row = current_row
                associate_rows = manager.associates or []

                for associate in associate_rows:
                    ws.cell(row=current_row, column=2, value=str(associate.associate_name or "Unknown"))
                    pct_cell = ws.cell(row=current_row, column=3, value=float(associate.staff_utilization_pct or 0) / 100.0)
                    pct_cell.number_format = "0.00%"
                    ws.cell(row=current_row, column=4, value=float(associate.available_hours or 0))
                    ws.cell(row=current_row, column=5, value=float(associate.productive_hours or 0))
                    current_row += 1

                team_total = manager.team_total
                if team_total is not None:
                    total_font = Font(bold=True)
                    name_cell = ws.cell(row=current_row, column=2, value="Team Total")
                    name_cell.font = total_font
                    pct_cell = ws.cell(row=current_row, column=3, value=float(team_total.staff_utilization_pct or 0) / 100.0)
                    pct_cell.number_format = "0.00%"
                    pct_cell.font = total_font
                    hours_cell = ws.cell(row=current_row, column=4, value=float(team_total.available_hours or 0))
                    hours_cell.font = total_font
                    prod_cell = ws.cell(row=current_row, column=5, value=float(team_total.productive_hours or 0))
                    prod_cell.font = total_font
                    current_row += 1

                manager_end_row = current_row - 1
                if manager_end_row >= manager_start_row:
                    ws.merge_cells(start_row=manager_start_row, start_column=1, end_row=manager_end_row, end_column=1)
                    manager_cell = ws.cell(row=manager_start_row, column=1, value=str(manager.manager_name or "Unknown"))
                    manager_cell.alignment = Alignment(vertical="center")

        for column_index in range(1, len(headers) + 1):
            max_length = 0
            column_letter = get_column_letter(column_index)
            for row_cells in ws.iter_rows(min_col=column_index, max_col=column_index):
                cell = row_cells[0]
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except Exception:
                    pass
            ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

        output = BytesIO()
        wb.save(output)
        output.seek(0)

        filename = f"manager_staff_utilization_drilldown_{request.user_id}_{request.start_date or 'N_A'}_to_{request.end_date or 'N_A'}.xlsx"

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Manager staff utilization Excel download error: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")