import logging
import asyncio
import uuid
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter
from collections import defaultdict

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from schema import ManagerUserActivityRequest, ManagerUserActivityResponse, ManagerUserActivityData, LoginLogoutRecord, SessionRecord

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()

# Query to get login/logout records for a specific associate
LOGIN_LOGOUT_QUERY = f"""
SELECT 
    DATE(LOGINTIME) as LOGINDATE,
    LOGINTIME as LOGIN_SORT_TS,
    TO_CHAR(LOGINTIME, 'HH12:MI AM') || ' ET' as login_time,
    TO_CHAR(LOGOUTTIME, 'HH12:MI AM') || ' ET' as logout_time
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_ACTIVITY
WHERE DOMAINID = '{{associate_id}}'
AND DATE(LOGINTIME) = CURRENT_DATE()
ORDER BY LOGINTIME ASC
"""

# Query to get skilled sources for a specific associate
SKILLED_SOURCES_QUERY = f"""
SELECT DISTINCT SKILLDESCRIPTION
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_SKILLS
WHERE USERID = '{{associate_id}}'
AND DATE(PXCOMMITDATETIME) = (
    SELECT MAX(DATE(PXCOMMITDATETIME))
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_SKILLS
    WHERE USERID = '{{associate_id}}'
)
"""

# Query to get experience level (ramp) for a specific associate
RAMP_QUERY = f"""
SELECT EXPERIENCELEVEL
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{associate_id}}'
AND LOGINDATE >= '{{start_date}}'
AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
ORDER BY LOGINDATE DESC
LIMIT 1
"""

# Query to get team rank and department rank for a specific associate
RANK_QUERY = f"""
SELECT 
    ROUND(AVG(TEAMRANK))::INT AS TEAMRANK,
    ROUND(AVG(DEPTRANK))::INT AS DEPTRANK
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{associate_id}}'
AND LOGINDATE >= '{{start_date}}'
AND LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
AND TEAMRANK IS NOT NULL
AND DEPTRANK IS NOT NULL
"""


def execute_login_query(engine, query: str):
    """Execute login/logout query (legacy)."""
    return engine.execute_query(query, limit=100)


def execute_sources_query(engine, query: str):
    """Execute skilled sources query (legacy)."""
    return engine.execute_query(query, limit=100)


def execute_ramp_query(engine, query: str):
    """Execute ramp/experience level query (legacy)."""
    return engine.execute_query(query, limit=10)


def execute_rank_query(engine, query: str):
    """Execute rank query (legacy)."""
    return engine.execute_query(query, limit=10)


@router.post(
    "/user-activity",
    response_model=ManagerUserActivityResponse,
    summary="Get Manager User Activity",
    description="""
Retrieve user activity data including team rank, department rank, ramp status, and skilled sources for a specific frontline associate.

**Input Parameters:**
- **user_id** (required): The unique identifier of the logged-in manager (e.g., 'AB77504')
- **frontline_associate_id** (required): The frontline associate ID (e.g., 'AH40730')
- **start_date** (required): Start date in YYYY-MM-DD format (e.g., '2025-08-01')
- **end_date** (required): End date in YYYY-MM-DD format (e.g., '2026-03-31')

**Response Fields:**
- **team_rank**: Team ranking (NA if not available)
- **department_rank**: Department ranking (NA if not available)
- **ramp**: Experience level/ramp status (e.g., 'Training', 'Ramping', 'Proficient')
- **skilled_sources**: List of intake source systems the associate has worked with

**Data Sources:**
- COB_AI_USER_PROFILE (experience level/ramp)
- COB_AI_INVNTRY_PROFILE (skilled sources)
""",
)
async def get_manager_user_activity(request: ManagerUserActivityRequest) -> ManagerUserActivityResponse:
    request_id = f"req_{uuid.uuid4().hex[:14].upper()}"
    generated_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    
    meta = {
        "request_id": request_id,
        "screen_id": "manager_user_activity",
        "generated_at": generated_at
    }

    if not connection_manager.validate_config():
        return ManagerUserActivityResponse(
            meta=meta,
            data=None,
            errors=[{
                "code": "INTERNAL_ERROR",
                "message": "Snowflake credentials not configured"
            }]
        )

    try:
        engine = connection_manager.get_engine()
        
        # Handle list-based associate_ids - use first associate if provided
        associate_id = None
        if request.associate_ids and len(request.associate_ids) > 0:
            associate_id = request.associate_ids[0]
        
        if not associate_id:
            return ManagerUserActivityResponse(
                meta=meta,
                data=None,
                errors=[{
                    "code": "VALIDATION_ERROR",
                    "message": "Associate ID is required"
                }]
            )
        
        # Format queries
        login_query = LOGIN_LOGOUT_QUERY.format(
            associate_id=associate_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        
        sources_query = SKILLED_SOURCES_QUERY.format(
            associate_id=associate_id
        )
        
        ramp_query = RAMP_QUERY.format(
            associate_id=associate_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        
        rank_query = RANK_QUERY.format(
            associate_id=associate_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        
        # Execute all 4 queries in parallel using async
        logger.info("Executing 4 Manager user activity queries in parallel")
        (
            login_records,
            sources_records,
            ramp_records,
            rank_records
        ) = await asyncio.gather(
            engine.execute_query_async(login_query, limit=100),
            engine.execute_query_async(sources_query, limit=100),
            engine.execute_query_async(ramp_query, limit=10),
            engine.execute_query_async(rank_query, limit=10),
            return_exceptions=False
        )
        logger.info("Parallel query execution completed")
        
        # Process login/logout records
        sessions_by_date = defaultdict(list)
        for record in login_records:
            date_key = str(record.get("LOGINDATE")) if record.get("LOGINDATE") else ""
            sessions_by_date[date_key].append({
                "login_sort_ts": record.get("LOGIN_SORT_TS"),
                "login": record.get("LOGIN_TIME"),
                "logout": record.get("LOGOUT_TIME")
            })

        login_logout_list = [
            LoginLogoutRecord(
                date=date,
                sessions=[
                    SessionRecord(
                        login=session.get("login"),
                        logout=session.get("logout")
                    )
                    for session in sorted(
                        sessions,
                        key=lambda session: (
                            session.get("login_sort_ts") is None,
                            session.get("login_sort_ts")
                        )
                    )
                ]
            )
            for date, sessions in sorted(sessions_by_date.items())
        ] if sessions_by_date else []
        
        # Process skilled sources
        skilled_sources = [
            record.get("SKILLDESCRIPTION")
            for record in sources_records
            if record.get("SKILLDESCRIPTION")
        ] if sources_records else []

        # Extract ramp/experience level
        ramp = "N/A"
        if ramp_records and len(ramp_records) > 0:
            experience_level = ramp_records[0].get("EXPERIENCELEVEL")
            if experience_level:
                ramp = str(experience_level)
        
        # Extract team rank and department rank
        team_rank = "N/A"
        department_rank = "N/A"
        if rank_records and len(rank_records) > 0:
            team_rank_value = rank_records[0].get("TEAMRANK")
            dept_rank_value = rank_records[0].get("DEPTRANK")
            if team_rank_value is not None:
                team_rank = str(int(team_rank_value))
            if dept_rank_value is not None:
                department_rank = str(int(dept_rank_value))

        tooltips = {
            "login_logout_records": "Login and logout times for the associate within the selected date range",
            "team_rank": "Associate's performance ranking within their team",
            "department_rank": "Associate's performance ranking within their department",
            "ramp": "Experience level or ramp status of the associate",
            "skilled_sources": "List of work source systems the associate has processed work items from"
        }

        return ManagerUserActivityResponse(
            meta=meta,
            data=ManagerUserActivityData(
                associate_id=associate_id,
                login_logout_records=login_logout_list,
                team_rank=team_rank,
                department_rank=department_rank,
                ramp=ramp,
                skilled_sources=skilled_sources
            ),
            errors=None,
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Manager user activity query error: {type(e).__name__}: {str(e)}")
        return ManagerUserActivityResponse(
            meta=meta,
            data=None,
            errors=[{
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred"
            }]
        )
