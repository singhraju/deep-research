import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
import math

from schema import (
    ManagerWatchlistDrilldownRequest,
    ManagerWatchlistDrilldownResponse,
    WatchlistRecord,
    PageResponse,
    ManagerBaseDownloadRequest,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from db import SnowflakeConnectionManager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()

def format_date_mmddyyyy(date_str: str) -> str:
    """Convert date to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        cleaned = str(date_str)
        if "T" in cleaned:
            cleaned = cleaned.split("T")[0]
        elif " " in cleaned:
            cleaned = cleaned.split(" ")[0]
        date_obj = datetime.strptime(cleaned, "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)

WATCHLIST_PAGINATED_QUERY = f"""
WITH config AS (
    SELECT
        '{{start_date}}'::DATE AS start_date,
        '{{end_date}}'::DATE AS end_date
),
user_with_manager AS (
    SELECT
        UPPER(TRIM(USERID)) AS USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        COALESCE(UPPER(TRIM(PYREPORTTO)), 'NONE') AS manager_id,
        REPORTTOFIRSTNAME AS manager_firstname,
        REPORTTOLASTNAME AS manager_lastname,
        PYACCESSGROUP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY USERID
        ORDER BY LOGINDATE DESC NULLS LAST, LASTLOGOUTTIME DESC NULLS LAST
    ) = 1
),
inventory_details AS (
    SELECT
        PYID,
        LOB,
        PLATFORM
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
watchlist_deduped AS (
    SELECT
        w.CASEID,
        UPPER(TRIM(w.USERID)) AS USERID,
        w.INVNTRY_TYPE,
        w.WATCHLISTCREATEDATE,
        w.WATCHLISTDUEDATE,
        w.WATCHLISTENDDATE,
        w.WATCHLISTACTION,
        w.FOLLOWUPREASON,
        w.LINKEDCASEID,
        w.INTAKESOURCESYSTEM,
        w.PXUPDATEDATETIME,
        w.PXCREATEDATETIME,
        i.LOB,
        i.PLATFORM,
        ROW_NUMBER() OVER (
            PARTITION BY w.CASEID
            ORDER BY w.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WATCHLIST w
    CROSS JOIN config c
    LEFT JOIN inventory_details i
        ON w.CASEID = i.PYID
    WHERE 1 = 1
      AND w.WATCHLISTCREATEDATE IS NOT NULL
      AND w.WATCHLISTCREATEDATE <= c.end_date
      {{lob_filter}}
),
watchlist_with_user_info AS (
    SELECT
        w.CASEID,
        w.USERID,
        w.INVNTRY_TYPE,
        w.WATCHLISTCREATEDATE,
        w.WATCHLISTDUEDATE,
        w.WATCHLISTENDDATE,
        w.WATCHLISTACTION,
        w.FOLLOWUPREASON,
        w.LINKEDCASEID,
        w.INTAKESOURCESYSTEM,
        w.PXUPDATEDATETIME,
        w.PXCREATEDATETIME,
        w.LOB,
        u.USERNAME,
        u.FIRSTNAME,
        u.LASTNAME,
        u.manager_id,
        u.manager_firstname,
        u.manager_lastname,
        u.PYACCESSGROUP,
        w.PLATFORM,
    FROM watchlist_deduped w
    LEFT JOIN user_with_manager u
        ON w.USERID = u.USERID
    WHERE w.rn = 1
      {{associate_filter}}
      {{manager_filter}}
),
active_at_any_point AS (
    SELECT
        CASEID,
        USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        manager_id,
        manager_firstname,
        manager_lastname,
        PYACCESSGROUP,
        INVNTRY_TYPE,
        LOB,
        WATCHLISTCREATEDATE,
        WATCHLISTDUEDATE,
        WATCHLISTENDDATE,
        WATCHLISTACTION,
        FOLLOWUPREASON,
        LINKEDCASEID,
        INTAKESOURCESYSTEM,
        PXUPDATEDATETIME,
        PXCREATEDATETIME,
        PLATFORM,
        CASE
            WHEN WATCHLISTCREATEDATE >= c.start_date
                 AND WATCHLISTCREATEDATE <= c.end_date
            THEN 'CREATED_DURING_PERIOD'
            WHEN WATCHLISTCREATEDATE < c.start_date
                 AND (WATCHLISTENDDATE IS NULL OR WATCHLISTENDDATE >= c.start_date)
            THEN 'CREATED_BEFORE_ACTIVE_DURING'
            ELSE 'OTHER'
        END AS inclusion_reason,
        DATEDIFF(day, WATCHLISTCREATEDATE, COALESCE(WATCHLISTENDDATE, CURRENT_DATE())) AS days_on_watchlist,
        CASE
            WHEN WATCHLISTENDDATE IS NULL THEN 'STILL_ACTIVE'
            WHEN WATCHLISTENDDATE >= c.start_date
                 AND WATCHLISTENDDATE <= c.end_date
            THEN 'REMOVED_DURING_PERIOD'
            WHEN WATCHLISTENDDATE > c.end_date
            THEN 'REMOVED_AFTER_PERIOD'
            ELSE 'REMOVED_BEFORE_PERIOD'
        END AS removal_status,
        CASE
            WHEN WATCHLISTDUEDATE IS NULL THEN 'NO_DUE_DATE'
            WHEN WATCHLISTDUEDATE < CURRENT_DATE() THEN 'OVERDUE'
            WHEN WATCHLISTDUEDATE = CURRENT_DATE() THEN 'DUE_TODAY'
            WHEN WATCHLISTDUEDATE > CURRENT_DATE() THEN 'NOT_DUE'
            ELSE 'UNKNOWN'
        END AS due_status,
        CASE
            WHEN WATCHLISTDUEDATE IS NOT NULL
            THEN DATEDIFF(day, CURRENT_DATE(), WATCHLISTDUEDATE)
            ELSE NULL
        END AS days_to_due_date
    FROM watchlist_with_user_info
    CROSS JOIN config c
    WHERE
        (
            WATCHLISTCREATEDATE >= c.start_date
            AND WATCHLISTCREATEDATE <= c.end_date
        )
        OR
        (
            WATCHLISTCREATEDATE < c.start_date
            AND (WATCHLISTENDDATE IS NULL OR WATCHLISTENDDATE >= c.start_date)
        )
)
SELECT
    CASEID AS WORK_ITEM,
    INTAKESOURCESYSTEM AS WORK_TYPE,
    USERNAME AS ASSOCIATE,
    removal_status AS RESOLVED_STATUS,
    INVNTRY_TYPE AS INVENTORY_TYPE,
    LOB AS LOB,
    PLATFORM AS PLATFORM,
    WATCHLISTDUEDATE AS ELV_DUE_DATE
FROM active_at_any_point
ORDER BY WATCHLISTCREATEDATE DESC, CASEID
LIMIT {{limit}} OFFSET {{offset}}
"""

WATCHLIST_COUNT_QUERY = f"""
WITH config AS (
    SELECT
        '{{start_date}}'::DATE AS start_date,
        '{{end_date}}'::DATE AS end_date
),
user_with_manager AS (
    SELECT
        UPPER(TRIM(USERID)) AS USERID,
        USERNAME,
        FIRSTNAME,
        LASTNAME,
        COALESCE(UPPER(TRIM(PYREPORTTO)), 'NONE') AS manager_id,
        REPORTTOFIRSTNAME AS manager_firstname,
        REPORTTOLASTNAME AS manager_lastname,
        PYACCESSGROUP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY USERID
        ORDER BY LOGINDATE DESC NULLS LAST, LASTLOGOUTTIME DESC NULLS LAST
    ) = 1
),
inventory_lob AS (
    SELECT
        PYID,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
),
watchlist_deduped AS (
    SELECT
        w.CASEID,
        UPPER(TRIM(w.USERID)) AS USERID,
        w.WATCHLISTCREATEDATE,
        w.WATCHLISTENDDATE,
        i.LOB,
        ROW_NUMBER() OVER (
            PARTITION BY w.CASEID
            ORDER BY w.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WATCHLIST w
    CROSS JOIN config c
    LEFT JOIN inventory_lob i
        ON w.CASEID = i.PYID
    WHERE 1 = 1
      AND w.WATCHLISTCREATEDATE IS NOT NULL
      AND w.WATCHLISTCREATEDATE <= c.end_date
      {{lob_filter}}
),
watchlist_with_user_info AS (
    SELECT
        w.CASEID,
        w.USERID,
        w.WATCHLISTCREATEDATE,
        w.WATCHLISTENDDATE
    FROM watchlist_deduped w
    LEFT JOIN user_with_manager u
        ON w.USERID = u.USERID
    WHERE w.rn = 1
      {{associate_filter}}
      {{manager_filter}}
),
active_at_any_point AS (
    SELECT
        CASEID
    FROM watchlist_with_user_info
    CROSS JOIN config c
    WHERE
        (
            WATCHLISTCREATEDATE >= c.start_date
            AND WATCHLISTCREATEDATE <= c.end_date
        )
        OR
        (
            WATCHLISTCREATEDATE < c.start_date
            AND (WATCHLISTENDDATE IS NULL OR WATCHLISTENDDATE >= c.start_date)
        )
)
SELECT
    COUNT(DISTINCT CASEID) AS WATCHLIST_COUNT
FROM active_at_any_point
"""

WATCHLIST_DEFAULT_ORDER_BY = "ORDER BY WATCHLISTCREATEDATE DESC, CASEID"


def build_sort_clause(sort_by: Optional[str], sort_direction: Optional[str]) -> str:
    direction = "ASC" if str(sort_direction).lower() == "asc" else "DESC"
    sort_columns = {
        "work_item": "CASEID",
        "work_type": "INTAKESOURCESYSTEM",
        "associate": "USERNAME",
        "resolved_status": "removal_status",
        "inventory_type": "INVNTRY_TYPE",
        "lob": "LOB",
        "platform": "PLATFORM",
        "elv_due_date": "WATCHLISTDUEDATE",
    }

    sort_column = sort_columns.get((sort_by or "").lower())
    if not sort_column:
        return WATCHLIST_DEFAULT_ORDER_BY

    return f"ORDER BY {sort_column} {direction}, CASEID"

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    """Build date filter for PXCREATEDATETIME."""
    if start_date and end_date:
        return f"AND PXCREATEDATETIME >= '{start_date}' AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND u.manager_id IN ('{manager_ids_str}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND w.USERID IN ('{frontline_associate_ids_str}')"
    return ""

@router.post(
    "/watchlist-manager-drilldown",
    response_model=ManagerWatchlistDrilldownResponse,
    summary="Get Manager Watchlist Drilldown",
    description="""
Retrieve paginated list of watchlist items for Manager view.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)
- **session_id** (optional): Session ID for cache reuse

**Response Fields (per record):**
- **work_item**: Unique work item identifier (PYID)
- **work_type**: Work type (INTAKESOURCESYSTEM)
- **associate**: Associate name
- **resolved_status**: Current resolution status
- **inventory_type**: Inventory type classification (e.g., GB, CB)
- **lob**: Line of Business
- **platform**: Platform where work item is processed
- **elv_due_date**: ELV due date (placeholder)

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available
- **has_next/has_previous**: Navigation flags

**Cache Reuse:**
If session_id is provided and quality_outcomes was called first, the drilldown will reuse the cached watchlist_count, eliminating a duplicate COUNT query.

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (watchlist items data)
- COB_AI_USER_PROFILE (user information)
""",
)
async def get_watchlist_manager_drilldown(request: ManagerWatchlistDrilldownRequest) -> ManagerWatchlistDrilldownResponse:
    """Manager watchlist drilldown endpoint - direct query execution with cache reuse."""
    return await execute_watchlist_manager_drilldown_query(request)


async def execute_watchlist_manager_drilldown_query(request: ManagerWatchlistDrilldownRequest) -> ManagerWatchlistDrilldownResponse:
    """Execute manager watchlist drilldown query logic."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        start_date = request.start_date
        end_date = request.end_date
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        lob_filter = build_lob_filter(lob)
        #date_filter = build_date_filter(start_date, end_date)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        # Try to reuse cached watchlist_count from quality-outcomes
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Get cached watchlist count from quality-outcomes
                # Build filters dict and hash for cache key
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'manager_ids': request.manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                cache_key = f"session:{session_id}:{filters_hash}:watchlist_count"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract WATCHLIST_COUNT from cached query result
                    total_records = int(cached_metric[0].get("WATCHLIST_COUNT", 0))
                    logger.info(f"✅ Reused cached watchlist count: {total_records} (from quality-outcomes)")
                else:
                    logger.info(f"Cache miss for watchlist_count, running COUNT query")
                    # Fall back to COUNT query
                    count_query = WATCHLIST_COUNT_QUERY.format(
                        start_date=request.start_date,
                        end_date=request.end_date,
                        lob_filter=lob_filter,
                        manager_filter=manager_filter,
                        associate_filter=associate_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("WATCHLIST_COUNT", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached watchlist count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = WATCHLIST_COUNT_QUERY.format(
                    start_date=request.start_date,
                    end_date=request.end_date,
                    lob_filter=lob_filter,
                    manager_filter=manager_filter,
                    associate_filter=associate_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("WATCHLIST_COUNT", 0) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = WATCHLIST_COUNT_QUERY.format(
                start_date=request.start_date or "2020-01-01",
                end_date=request.end_date or "2099-12-31",
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("WATCHLIST_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        data_query = WATCHLIST_PAGINATED_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = data_query.replace(
            WATCHLIST_DEFAULT_ORDER_BY,
            build_sort_clause(request.sort_by, request.sort_direction),
            1
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        watchlist_records = [
            WatchlistRecord(
                work_item=record.get("WORK_ITEM") or "N/A",
                work_type=record.get("WORK_TYPE") or "N/A",
                associate=record.get("ASSOCIATE") or "N/A",
                resolved_status=record.get("RESOLVED_STATUS") or "N/A",
                inventory_type=record.get("INVENTORY_TYPE") or "N/A",
                lob=record.get("LOB") or "N/A",
                platform=record.get("PLATFORM") or "N/A",
                elv_due_date=format_date_mmddyyyy(str(record.get("ELV_DUE_DATE"))) if record.get("ELV_DUE_DATE") else "N/A"
            )
            for record in records
        ]
        
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        tooltips = {
            "work_item": "Unique identifier for the work item on the watchlist",
            "work_type": "Type of work item (e.g., Newborn, Compass, HEW, Claim Request)",
            "associate": "Name of the associate resolved the work item",
            "resolved_status": "Current resolution status of the work item",
            "inventory_type": "Type of inventory classification (e.g., GB, CB)",
            "lob": "Line of Business (Medicaid, Medicare, Commercial)",
            "platform": "Platform where the work item is processed",
            "elv_due_date": "ELV (Escalation Level) due date for the work item"
        }

        return ManagerWatchlistDrilldownResponse(
            status="success",
            screen_id=request.screen_id,
            page=page_response,
            records=watchlist_records,
            message="Watchlist records retrieved successfully",
            tooltips=tooltips,
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Paginated watchlist drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return ManagerWatchlistDrilldownResponse(
            status="error",
            screen_id=request.screen_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve watchlist records: {str(e)}",
            tooltips={},
            service="idiscovery-cob-dashboard-service"
        )


@router.post(
    "/watchlist-manager-drilldown/download-excel",
    summary="Download Watchlist Drilldown as Excel (Manager)",
    description="""
Download complete watchlist drilldown data as an Excel file (Manager version).

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **session_id** (optional): Session ID for cache reuse (enables instant downloads)
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all watchlist records
""",
)
async def download_watchlist_manager_drilldown_excel(
    request: ManagerBaseDownloadRequest
) -> StreamingResponse:
    user_id = request.user_id
    start_date = request.start_date or "N/A"
    end_date = request.end_date or "N/A"
    
    # Query database directly (no caching)
    if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
    try:
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        lob_filter = build_lob_filter(lob)
        #date_filter = build_date_filter(request.start_date, request.end_date)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        download_query = WATCHLIST_PAGINATED_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
    except Exception as e:
            logger.error(f"Excel download error for watchlist drilldown: {type(e).__name__}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
    
    # Generate Excel file
    try:
        total_records = len(data_result)

        wb = Workbook()
        ws = wb.active
        ws.title = "Watchlist Drilldown"
        
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        headers = [
            "Work Item",
            "Work Type",
            "Associate Name",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Platform",
            "ELV Due Date"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows with field name compatibility (both uppercase DB and lowercase cache)
        for row_num, record in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(record.get("work_item") or record.get("WORK_ITEM", "")))
            ws.cell(row=row_num, column=2, value=str(record.get("work_type") or record.get("WORK_TYPE", "")))
            ws.cell(row=row_num, column=3, value=str(record.get("associate") or record.get("ASSOCIATE", "")))
            ws.cell(row=row_num, column=4, value=str(record.get("resolved_status") or record.get("RESOLVED_STATUS", "")))
            ws.cell(row=row_num, column=5, value=str(record.get("inventory_type") or record.get("INVENTORY_TYPE", "N/A")))
            ws.cell(row=row_num, column=6, value=str(record.get("lob") or record.get("LOB", "")))
            ws.cell(row=row_num, column=7, value=str(record.get("platform") or record.get("PLATFORM", "")))
            elv_due_date = record.get("elv_due_date") or record.get("ELV_DUE_DATE")
            ws.cell(row=row_num, column=8, value=format_date_mmddyyyy(str(elv_due_date)) if elv_due_date else "N/A")
        
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"watchlist_manager_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for watchlist drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
