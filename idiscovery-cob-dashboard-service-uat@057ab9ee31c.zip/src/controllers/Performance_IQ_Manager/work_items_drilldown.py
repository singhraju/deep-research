import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from schema import (
    WorkItemsManagerDrilldownRequest,
    WorkItemsDrilldownPaginatedResponse,
    WorkItemRecord,
    PageResponse,
    ManagerBaseDownloadRequest,
)
import math

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/manager", tags=["Performance_IQ_Manager"])

connection_manager = SnowflakeConnectionManager()




WORK_ITEMS_MANAGER_PAGINATED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        i.PYID,
        i.INTAKESOURCESYSTEM,
        i.CYCLE_TIME,
        i.PYSTATUSWORK,
        i.LOB,
        i.INVNTRY_TYPE,
        i.PYRESOLVEDTIMESTAMP,
        i.PYRESOLVEDUSERID,
        i.PLATFORM,
        i.RETIME,
        ROW_NUMBER() OVER (PARTITION BY i.PYID ORDER BY i.RETIME DESC NULLS LAST, i.PXCOMMITDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
    WHERE i.PYSTATUSWORK IN ('Resolved-Completed')
        AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
        {{date_filter}}
        {{lob_filter}}
        {{manager_filter}}
        {{associate_filter}}
),
user_profile_deduped AS (
    SELECT
        USERID,
        USERNAME AS USERNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
)
SELECT
    i.PYID,
    i.INTAKESOURCESYSTEM,
    i.CYCLE_TIME,
    i.PYSTATUSWORK,
    i.LOB,
    i.PYRESOLVEDTIMESTAMP,
    i.PYRESOLVEDUSERID,
    u.USERNAME AS ASSOCIATE_NAME,
    i.PLATFORM,
    i.INVNTRY_TYPE
FROM invntry_deduped i
LEFT JOIN user_profile_deduped u
    ON i.PYRESOLVEDUSERID = u.USERID
    AND u.rn = 1
WHERE i.rn = 1
ORDER BY i.PYRESOLVEDTIMESTAMP DESC
LIMIT {{limit}} OFFSET {{offset}}
"""

WORK_ITEMS_MANAGER_COUNT_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        i.PYID,
        i.PYSTATUSWORK,
        i.PYRESOLVEDTIMESTAMP,
        i.PYRESOLVEDUSERID,
        i.REPORTTOMANAGERID,
        i.LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY i.PYID
        ORDER BY i.PXCOMMITDATETIME DESC NULLS LAST
    ) = 1
)
SELECT COUNT(DISTINCT i.PYID) AS TOTAL_COUNT
FROM latest_inventory i
WHERE i.PYSTATUSWORK IN ('Resolved-Completed')
  AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
  {{date_filter}}
  {{lob_filter}}
  {{manager_filter}}
  {{associate_filter}}
"""

WORK_ITEMS_MANAGER_DEFAULT_ORDER_BY = "ORDER BY i.PYRESOLVEDTIMESTAMP DESC"


DEFAULT_WORK_ITEMS_MANAGER_ORDER_BY = "i.PYRESOLVEDTIMESTAMP DESC"

DISPLAY_WORK_ITEMS_MANAGER_DOMAIN_ID_SQL = "COALESCE(u.USERNAME, i.PYRESOLVEDUSERID, 'N/A')"
DISPLAY_WORK_ITEMS_MANAGER_RESOLVED_STATUS_SQL = "CASE WHEN i.PYSTATUSWORK LIKE 'Resolved%' THEN 'Resolved' ELSE COALESCE(i.PYSTATUSWORK, '') END"
DISPLAY_WORK_ITEMS_MANAGER_RESOLVED_DATE_SQL = "DATE(i.PYRESOLVEDTIMESTAMP)"

SORTABLE_WORK_ITEMS_MANAGER_COLUMNS = {
    "pyid": "i.PYID",
    "work_type": "i.INTAKESOURCESYSTEM",
    "case_cycle_time": "COALESCE(i.CYCLE_TIME, 0)",
    "resolved_status": DISPLAY_WORK_ITEMS_MANAGER_RESOLVED_STATUS_SQL,
    "lob": "COALESCE(i.LOB, '')",
    "resolved_date": DISPLAY_WORK_ITEMS_MANAGER_RESOLVED_DATE_SQL,
    "domain_id": DISPLAY_WORK_ITEMS_MANAGER_DOMAIN_ID_SQL,
    "platform": "COALESCE(i.PLATFORM, '')",
    "inventory_type": "COALESCE(i.INVNTRY_TYPE, '')",
}


def build_order_by_clause(sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return DEFAULT_WORK_ITEMS_MANAGER_ORDER_BY

    normalized_sort_by = sort_by.strip().lower()
    sort_expression = SORTABLE_WORK_ITEMS_MANAGER_COLUMNS.get(normalized_sort_by)
    normalized_direction = (sort_direction or "desc").strip().lower()

    if sort_expression is None:
        logger.warning("Invalid manager work items sort_by '%s'; falling back to default ordering", sort_by)
        return DEFAULT_WORK_ITEMS_MANAGER_ORDER_BY

    if normalized_direction not in {"asc", "desc"}:
        logger.warning("Invalid manager work items sort_direction '%s'; falling back to default ordering", sort_direction)
        return DEFAULT_WORK_ITEMS_MANAGER_ORDER_BY

    tie_breakers = []
    if normalized_sort_by != "resolved_date":
        tie_breakers.append("i.PYRESOLVEDTIMESTAMP DESC")
    if normalized_sort_by != "pyid":
        tie_breakers.append("i.PYID ASC")

    return ", ".join([f"{sort_expression} {normalized_direction.upper()}", *tie_breakers])


def apply_custom_sort_to_work_items_query(query: str, sort_by: Optional[str] = None, sort_direction: Optional[str] = None) -> str:
    if not sort_by:
        return query

    order_by_clause = build_order_by_clause(sort_by, sort_direction)
    return query.replace(
        f"ORDER BY {DEFAULT_WORK_ITEMS_MANAGER_ORDER_BY}",
        f"ORDER BY {order_by_clause}",
        1,
    )


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (i.LOB IN ('{lob_values}') OR i.LOB IS NULL)"
    elif null_requested:
        return "AND i.LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND i.LOB IN ('{lob_values}')"


def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:
    if start_date and end_date:
        return f"AND i.PYRESOLVEDTIMESTAMP >= '{start_date}' AND i.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""


def build_manager_filter(manager_ids: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory table (uses REPORTTOMANAGERID)."""
    if manager_ids and len(manager_ids) > 0:
        manager_ids_str = "', '".join(manager_ids)
        return f"AND i.REPORTTOMANAGERID IN ('{manager_ids_str}')"
    return ""

def build_associate_filter(frontline_associate_ids: Optional[List[str]] = None) -> str:
    """Build associate filter for inventory table (uses PYRESOLVEDUSERID)."""
    if frontline_associate_ids and len(frontline_associate_ids) > 0:
        frontline_associate_ids_str = "', '".join(frontline_associate_ids)
        return f"AND i.PYRESOLVEDUSERID IN ('{frontline_associate_ids_str}')"
    return ""


def format_cycle_time(cycle_time) -> str:
    """Convert cycle time from seconds to hh:mm:ss format"""
    if not cycle_time:
        return "00:00:00"
    try:
        total_seconds = int(float(cycle_time))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    except:
        return "00:00:00"


def format_date_mmddyyyy(date_str: str) -> str:
    """Convert datetime to MM/DD/YYYY format"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(str(date_str)[:10], "%Y-%m-%d")
        return date_obj.strftime("%m/%d/%Y")
    except:
        return str(date_str)


def clean_resolved_status(status: str) -> str:
    """Convert 'Resolved-Completed' to 'Resolved'"""
    if not status:
        return ""
    return "Resolved" if status.startswith("Resolved") else status


@router.post(
    "/work-items-manager-drilldown",
    response_model=WorkItemsDrilldownPaginatedResponse,
    summary="Get Work Items Manager Drilldown",
    description="""
Retrieve paginated list of resolved work items with manager-associate relationship aggregation for manager-level view.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (optional): Start date in YYYY-MM-DD format (default: no filter)
- **end_date** (optional): End date in YYYY-MM-DD format (default: no filter)
- **lob** (optional): List of Line of Business values (e.g., ['Commercial']) (default: all)
- **manager_ids** (optional): List of manager IDs to filter (default: all)
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter (default: all)
- **page** (optional): Page number (starts from 1, default: 1)
- **page_size** (optional): Records per page (default: 20, max: 100)

**Response Fields (per record):**
- **pyid**: Unique case/work item identifier
- **work_type**: Source system (INTAKESOURCESYSTEM)
- **case_cycle_time**: Time from creation to resolution in hh:mm:ss format
- **resolved_status**: Status (e.g., 'Resolved')
- **lob**: Line of Business
- **resolved_date**: Resolution date (MM/DD/YYYY format)
- **domain_id**: User who resolved it
- **platform**: Processing platform

**Pagination Response:**
- **total_records**: Total matching records
- **total_pages**: Total pages available

**Data Sources:** 
- COB_AI_INVNTRY_PROFILE (work items)
- COB_AI_USER_PROFILE (manager-associate relationships)
""",
)
async def get_work_items_manager_drilldown(
    request: WorkItemsManagerDrilldownRequest
) -> WorkItemsDrilldownPaginatedResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    try:
        engine = connection_manager.get_engine()
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        date_filter = build_date_filter(request.start_date, request.end_date)
        manager_filter = build_manager_filter(request.manager_ids)
        associate_filter = build_associate_filter(request.frontline_associate_ids)
        
        # Calculate pagination
        page_limit = request.page_size
        page = request.page
        offset = (page - 1) * page_limit
        
        # Try to reuse cached work_items_completed count from header KPIs
        total_records = 0
        session_id = getattr(request, "session_id", None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Get cached work items count from header KPIs
                # Build filters dict and hash for cache key
                filters = {
                    'start_date': request.start_date,
                    'end_date': request.end_date,
                    'lob': request.lob,
                    'manager_ids': request.manager_ids,
                    'frontline_associate_ids': request.frontline_associate_ids,
                }
                filters_hash = build_filters_hash(**filters)
                cache_key = f"session:{session_id}:{filters_hash}:work_items_completed"
                cached_metric = await metric_cache_service.cache_manager.get(cache_key)
                
                if cached_metric and isinstance(cached_metric, list) and len(cached_metric) > 0:
                    # Extract COMPLETED_TASKS from cached query result
                    total_records = int(cached_metric[0].get("COMPLETED_TASKS", 0))
                    logger.info(f"✅ Reused cached work items count: {total_records} (from header KPIs)")
                else:
                    logger.info(f"Cache miss for work_items_completed, running COUNT query")
                    # Fall back to COUNT query
                    count_query = WORK_ITEMS_MANAGER_COUNT_QUERY.format(
                        date_filter=date_filter,
                        lob_filter=lob_filter,
                        manager_filter=manager_filter,
                        associate_filter=associate_filter
                    )
                    count_result = await engine.execute_query_async(count_query, limit=1)
                    total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
            except Exception as e:
                logger.warning(f"Error accessing cached work items count: {e}, falling back to COUNT query")
                # Fall back to COUNT query on error
                count_query = WORK_ITEMS_MANAGER_COUNT_QUERY.format(
                    date_filter=date_filter,
                    lob_filter=lob_filter,
                    manager_filter=manager_filter,
                    associate_filter=associate_filter
                )
                count_result = await engine.execute_query_async(count_query, limit=1)
                total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        else:
            # No session_id or caching disabled - run COUNT query
            count_query = WORK_ITEMS_MANAGER_COUNT_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter,
                manager_filter=manager_filter,
                associate_filter=associate_filter
            )
            count_result = await engine.execute_query_async(count_query, limit=1)
            total_records = count_result[0].get("TOTAL_COUNT", 0) if count_result else 0
        
        total_pages = math.ceil(total_records / page_limit) if total_records > 0 else 0
        
        # Get data
        data_query = WORK_ITEMS_MANAGER_PAGINATED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=page_limit,
            offset=offset
        )
        data_query = apply_custom_sort_to_work_items_query(
            data_query,
            request.sort_by,
            request.sort_direction,
        )
        records = await engine.execute_query_async(data_query, limit=page_limit)
        
        # Transform records
        work_items = [
            WorkItemRecord(
                pyid=record.get("PYID"),
                work_type=record.get("INTAKESOURCESYSTEM"),
                case_cycle_time=format_cycle_time(record.get("CYCLE_TIME")),
                resolved_status=clean_resolved_status(record.get("PYSTATUSWORK")),
                lob=record.get("LOB") or "",
                resolved_date=format_date_mmddyyyy(record.get("PYRESOLVEDTIMESTAMP")),
                domain_id=record.get("ASSOCIATE_NAME") or record.get("PYRESOLVEDUSERID") or "N/A",
                platform=record.get("PLATFORM") or "",
                inventory_type=record.get("INVNTRY_TYPE") or ""
            )
            for record in records
        ] if records else []

        # Build pagination response
        page_response = PageResponse(
            page_limit=page_limit,
            page=page,
            total_records=total_records,
            total_pages=total_pages,
            cursor=None,
            has_next=page < total_pages,
            has_previous=page > 1
        )

        # Build tooltips
        tooltips = {
            "pyid": "Unique identifier for the work item/case",
            "work_type": "Source system or type of work item (e.g., intake source)",
            "case_cycle_time": "Time from case creation to resolution in hh:mm:ss format",
            "resolved_status": "Current status of the work item (e.g., Resolved)",
            "lob": "Line of Business associated with the work item",
            "resolved_date": "Date when the work item was resolved",
            "domain_id": "User ID of the person who resolved the work item",
            "platform": "Platform where the work item was processed"
        }

        return WorkItemsDrilldownPaginatedResponse(
            status="success",
            screen_id="work_items_manager",
            user_id=request.user_id,
            page=page_response,
            records=work_items,
            message="Work items manager records retrieved successfully",
            tooltips=tooltips
        )

    except Exception as e:
        logger.error(f"Work items drilldown error: {type(e).__name__}: {str(e)}")
        page_response = PageResponse(
            page_limit=request.page_size,
            page=request.page,
            total_records=0,
            total_pages=0,
            cursor=None,
            has_next=False,
            has_previous=False
        )
        return WorkItemsDrilldownPaginatedResponse(
            status="error",
            screen_id="work_items_manager",
            user_id=request.user_id,
            page=page_response,
            records=[],
            message=f"Failed to retrieve work items manager records: {str(e)}"
        )


@router.post(
    "/work-items-manager-drilldown/download-excel",
    summary="Download Work Items Manager Drilldown as Excel",
    description="""
Download complete work items manager drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (optional): Start date in YYYY-MM-DD format
- **end_date** (optional): End date in YYYY-MM-DD format
- **lob** (optional): List of Line of Business values
- **manager_ids** (optional): List of manager IDs to filter
- **frontline_associate_ids** (optional): List of frontline associate IDs to filter

**Returns:** Excel file (.xlsx) with all work items records
""",
)
async def download_work_items_manager_drilldown_excel(
    request: ManagerBaseDownloadRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        user_id = request.user_id
        start_date = request.start_date or "N/A"
        end_date = request.end_date or "N/A"
        
        # Build filters
        lob = request.lob
        manager_ids = request.manager_ids
        frontline_associate_ids = request.frontline_associate_ids
        
        date_filter = build_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(lob)
        manager_filter = build_manager_filter(manager_ids)
        associate_filter = build_associate_filter(frontline_associate_ids)
        
        engine = connection_manager.get_engine()
        
        # Query with high limit for download (no pagination needed)
        download_query = WORK_ITEMS_MANAGER_PAGINATED_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            associate_filter=associate_filter,
            limit=config.CACHE_FULL_DATASET_LIMIT,
            offset=0
        )
        
        data_result = await engine.execute_query_async(download_query, limit=config.CACHE_FULL_DATASET_LIMIT)
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Work Items Manager"

        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")

        headers = [
            "Work Item",
            "Work Type",
            "Case Cycle Time",
            "Resolved Status",
            "Inventory Type",
            "LOB",
            "Resolved Date",
            "Associate Name",
            "Platform"
        ]

        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment

        # Add data rows
        for row_num, row in enumerate(data_result, start=2):
            ws.cell(row=row_num, column=1, value=str(row.get("PYID", "")))
            ws.cell(row=row_num, column=2, value=str(row.get("INTAKESOURCESYSTEM", "")))
            ws.cell(row=row_num, column=3, value=format_cycle_time(row.get("CYCLE_TIME")) if row.get("CYCLE_TIME") else "00:00:00")
            ws.cell(row=row_num, column=4, value=clean_resolved_status(str(row.get("PYSTATUSWORK", ""))))
            ws.cell(row=row_num, column=5, value=str(row.get("INVNTRY_TYPE", "")))
            ws.cell(row=row_num, column=6, value=str(row.get("LOB", "")))
            ws.cell(row=row_num, column=7, value=format_date_mmddyyyy(str(row.get("PYRESOLVEDTIMESTAMP", ""))) if row.get("PYRESOLVEDTIMESTAMP") else "")
            ws.cell(row=row_num, column=8, value=str(row.get("ASSOCIATE_NAME") or "N/A"))
            ws.cell(row=row_num, column=9, value=str(row.get("PLATFORM", "")))

        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

        output = BytesIO()
        wb.save(output)
        output.seek(0)

        filename = f"work_items_manager_drilldown_{user_id}_{start_date}_to_{end_date}.xlsx"

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )

    except Exception as e:
        logger.error(f"Excel download error for work items manager drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
