from fastapi import APIRouter
from .ai_coach import router as ai_coach_router
from .demand_inventory import router as demand_inventory_router
from .filter_lists import router as filter_lists_router
from .staffing_core import router as staffing_core_router
from .header_kpis import router as header_kpis_router
from .membership import router as membership_router
from .capacity import router as capacity_router
from .what_if_analysis import router as what_if_analysis_router
from .actual_projected_membership import router as actual_projected_membership_router
from .change_tracking import router as change_tracking_router 
from .irp_projection import router as irp_projection_router
from .total_work_drilldown import router as total_work_drilldown_router
from .total_production_drilldown import router as total_production_drilldown_router
from .out_of_sla_drilldown import router as out_of_sla_drilldown_router
from .what_if_sla_impact import router as what_if_sla_impact_router

# Create main router for WorkForce IQ endpoints
router = APIRouter()

# Include all WorkForce IQ sub-routers
router.include_router(header_kpis_router)
router.include_router(membership_router)
router.include_router(capacity_router)
router.include_router(ai_coach_router)
router.include_router(demand_inventory_router)
router.include_router(filter_lists_router)
router.include_router(what_if_analysis_router)
router.include_router(staffing_core_router)
router.include_router(actual_projected_membership_router)
router.include_router(change_tracking_router)
router.include_router(irp_projection_router)
router.include_router(total_work_drilldown_router)
router.include_router(total_production_drilldown_router)
router.include_router(out_of_sla_drilldown_router)
router.include_router(what_if_sla_impact_router)
__all__ = [
    "router",
]
