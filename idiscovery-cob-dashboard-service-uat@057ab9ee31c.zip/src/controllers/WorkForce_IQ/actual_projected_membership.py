import asyncio
import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema.workforce_iq_models import (
    ActualVsProjectedMembershipRequest,
    ActualVsProjectedMembershipResponse,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, MEMBERSHIP_LOB_MAP

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()


# =============================================================================
# SQL QUERIES
# =============================================================================

COMBINED_MEMBERSHIP_TREND_QUERY = f"""
WITH input_params AS (
    SELECT 
        '{{start_date}}'::DATE AS from_date,
        '{{end_date}}'::DATE AS to_date,
        '{{grouping_level}}'::VARCHAR AS time_range
),
date_params AS (
    SELECT 
        YEAR(ip.from_date) AS from_year,
        MONTH(ip.from_date) AS from_month,
        YEAR(ip.to_date) AS to_year,
        MONTH(ip.to_date) AS to_month,
        YEAR(CURRENT_DATE) AS current_year,
        MONTH(CURRENT_DATE) AS current_month,
        (YEAR(ip.from_date) * 100 + MONTH(ip.from_date)) AS from_year_month,
        (YEAR(ip.to_date) * 100 + MONTH(ip.to_date)) AS to_year_month,
        (YEAR(CURRENT_DATE) * 100 + MONTH(CURRENT_DATE)) AS current_year_month,
        ip.from_date,
        ip.to_date,
        ip.time_range
    FROM input_params ip
),
membership_data AS (
    SELECT 
        m.YEAR,
        m.MONTH,
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        m.PROJECTED_MEMBERSHIP,
        CASE 
            WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
            WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
            WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
            WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
            WHEN UPPER(m.MONTH) = 'MAY' THEN 5
            WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
            WHEN UPPER(m.MONTH) = 'JULY' THEN 7
            WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
            WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
            WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
            WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
            WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            ELSE NULL
        END AS month_num,
        (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) AS year_month,
        CASE 
            WHEN (m.YEAR * 100 + 
                CASE 
                    WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                    WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                    WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                    WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                    WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                    WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                    WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                    WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                    WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                    WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                    WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                    WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                    ELSE NULL
                END
            ) < (SELECT current_year_month FROM date_params)
            THEN TRUE
            ELSE FALSE
        END AS is_past_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    CROSS JOIN date_params dp
    WHERE 1=1
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) BETWEEN dp.from_year_month AND dp.to_year_month
        {{lob_filter}}
),
monthly_totals AS (
    SELECT 
        md.YEAR,
        md.MONTH,
        md.month_num,
        md.year_month,
        SUM(md.PROJECTED_MEMBERSHIP) AS monthly_projected_total,
        SUM(CASE WHEN md.is_past_month THEN md.ACTUAL_MEMBERSHIP ELSE NULL END) AS monthly_actual_total,
        TO_DATE(md.YEAR || '-' || LPAD(md.month_num, 2, '0') || '-01', 'YYYY-MM-DD') AS month_start_date
    FROM membership_data md
    GROUP BY md.YEAR, md.MONTH, md.month_num, md.year_month
),
daily_data AS (
    SELECT 
        DATEADD(day, seq.day_num - 1, mt.month_start_date) AS time_period_date,
        TO_CHAR(DATEADD(day, seq.day_num - 1, mt.month_start_date), 'YYYY-MM-DD') AS time_period,
        mt.monthly_projected_total AS projected_membership,
        mt.monthly_actual_total AS actual_membership,
        CASE 
            WHEN mt.monthly_actual_total IS NOT NULL 
            THEN mt.monthly_actual_total - mt.monthly_projected_total
            ELSE NULL
        END AS variance_count,
        CASE 
            WHEN mt.monthly_actual_total IS NOT NULL AND mt.monthly_projected_total <> 0
            THEN ROUND(((mt.monthly_actual_total - mt.monthly_projected_total) / mt.monthly_projected_total) * 100, 2)
            ELSE NULL
        END AS variance_percentage,
        'daily' AS granularity
    FROM monthly_totals mt
    CROSS JOIN (
        SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) AS day_num
        FROM TABLE(GENERATOR(ROWCOUNT => 31))
    ) seq
    CROSS JOIN date_params dp
    WHERE dp.time_range = 'daily'
        AND seq.day_num <= DAY(LAST_DAY(mt.month_start_date))
        AND DATEADD(day, seq.day_num - 1, mt.month_start_date) BETWEEN dp.from_date AND dp.to_date
),
weekly_data AS (
    SELECT DISTINCT
        DATE_TRUNC('week', DATEADD(day, seq.day_num - 1, mt.month_start_date)) AS time_period_date,
        TO_CHAR(DATE_TRUNC('week', DATEADD(day, seq.day_num - 1, mt.month_start_date)), 'YYYY-MM-DD') AS time_period,
        mt.monthly_projected_total AS projected_membership,
        mt.monthly_actual_total AS actual_membership,
        CASE 
            WHEN mt.monthly_actual_total IS NOT NULL 
            THEN mt.monthly_actual_total - mt.monthly_projected_total
            ELSE NULL
        END AS variance_count,
        CASE 
            WHEN mt.monthly_actual_total IS NOT NULL AND mt.monthly_projected_total <> 0
            THEN ROUND(((mt.monthly_actual_total - mt.monthly_projected_total) / mt.monthly_projected_total) * 100, 2)
            ELSE NULL
        END AS variance_percentage,
        'weekly' AS granularity
    FROM monthly_totals mt
    CROSS JOIN (
        SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) AS day_num
        FROM TABLE(GENERATOR(ROWCOUNT => 31))
    ) seq
    CROSS JOIN date_params dp
    WHERE dp.time_range = 'weekly'
        AND seq.day_num <= DAY(LAST_DAY(mt.month_start_date))
        AND DATEADD(day, seq.day_num - 1, mt.month_start_date) BETWEEN dp.from_date AND dp.to_date
),
monthly_data AS (
    SELECT 
        mt.month_start_date AS time_period_date,
        TO_CHAR(mt.month_start_date, 'YYYY-MM') AS time_period,
        mt.monthly_projected_total AS projected_membership,
        mt.monthly_actual_total AS actual_membership,
        CASE 
            WHEN mt.monthly_actual_total IS NOT NULL 
            THEN mt.monthly_actual_total - mt.monthly_projected_total
            ELSE NULL
        END AS variance_count,
        CASE 
            WHEN mt.monthly_actual_total IS NOT NULL AND mt.monthly_projected_total <> 0
            THEN ROUND(((mt.monthly_actual_total - mt.monthly_projected_total) / mt.monthly_projected_total) * 100, 2)
            ELSE NULL
        END AS variance_percentage,
        'monthly' AS granularity
    FROM monthly_totals mt
    CROSS JOIN date_params dp
    WHERE dp.time_range = 'monthly'
),
yearly_data AS (
    SELECT 
        TO_DATE(mt.YEAR || '-01-01', 'YYYY-MM-DD') AS time_period_date,
        TO_CHAR(mt.YEAR) AS time_period,
        SUM(mt.monthly_projected_total) AS projected_membership,
        SUM(mt.monthly_actual_total) AS actual_membership,
        CASE 
            WHEN SUM(mt.monthly_actual_total) IS NOT NULL 
            THEN SUM(mt.monthly_actual_total) - SUM(mt.monthly_projected_total)
            ELSE NULL
        END AS variance_count,
        CASE 
            WHEN SUM(mt.monthly_actual_total) IS NOT NULL AND SUM(mt.monthly_projected_total) <> 0
            THEN ROUND(((SUM(mt.monthly_actual_total) - SUM(mt.monthly_projected_total)) / SUM(mt.monthly_projected_total)) * 100, 2)
            ELSE NULL
        END AS variance_percentage,
        'yearly' AS granularity
    FROM monthly_totals mt
    CROSS JOIN date_params dp
    WHERE dp.time_range = 'yearly'
    GROUP BY mt.YEAR
),
combined_data AS (
    SELECT * FROM daily_data
    UNION ALL
    SELECT * FROM weekly_data
    UNION ALL
    SELECT * FROM monthly_data
    UNION ALL
    SELECT * FROM yearly_data
)
SELECT 
    time_period AS TIME_PERIOD,
    time_period_date AS PERIOD_DATE,
    projected_membership AS PROJECTED_MEMBERSHIP,
    actual_membership AS ACTUAL_MEMBERSHIP,
    variance_count AS VARIANCE_COUNT,
    variance_percentage AS VARIANCE_PERCENTAGE,
    granularity AS GROUPING_LEVEL
FROM combined_data
ORDER BY time_period_date ASC
"""


# =============================================================================
# Helper Functions
# =============================================================================

def format_membership_value(value: Optional[float]) -> Optional[str]:
    """
    Format membership value as millions with 1 decimal place using floor.
    
    Args:
        value: Raw membership count (e.g., 41887333)
    
    Returns:
        Formatted string (e.g., "41.8M") or None if value is None
    
    Examples:
        41887333 -> "41.8M"
        27000000 -> "27.0M"
    """
    if value is None:
        return None
    millions = value / 1_000_000
    floored = int(millions * 10) / 10  # Floor to 1 decimal place
    return f"{floored:.1f}M"


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for membership queries, mapping payload LOB values to membership table values."""
    if not lob or len(lob) == 0:
        return ""
    mapped = set()
    for l in lob:
        if l in MEMBERSHIP_LOB_MAP:
            mapped.add(MEMBERSHIP_LOB_MAP[l])
    if not mapped:
        return ""
    lob_values = "', '".join(mapped)
    return f"AND m.LOB IN ('{lob_values}')"


# =============================================================================
# API Endpoint
# =============================================================================

@router.post("/actual-vs-projected-membership", response_model=ActualVsProjectedMembershipResponse, summary="Get Actual vs Projected Membership Trend")
async def get_actual_vs_projected_membership(request: ActualVsProjectedMembershipRequest):
    """
    Get actual vs projected membership trend data with variance gap.
    
    Executes a combined query to retrieve actual and projected membership by period,
    along with variance calculations.
    
    **Filters:**
    - start_date, end_date: Date range filter (required)
    - grouping_level: Aggregation level (daily/weekly/monthly/yearly)
    - lob: Line of Business filter (optional)
    - session_id: Session ID for Redis caching (optional)
    
    **Returns:**
    - data: Combined actual and projected membership trend data with variance gap
    - period_count: Number of periods returned
    `
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        logger.info(f"Actual vs Projected Membership request: {request.model_dump()}")
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        
        # Get grouping level (default to 'monthly' if not provided)
        grouping_level = getattr(request, 'grouping_level', 'monthly')
        
        # Get engine
        engine = connection_manager.get_engine()
        
        # Build combined query
        combined_query = COMBINED_MEMBERSHIP_TREND_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            lob_filter=lob_filter
        )
        
        # Execute query
        logger.info(f"Executing combined membership trend query with grouping_level={grouping_level}")
        results = await engine.execute_query_async(combined_query, limit=1000)
        
        logger.info(f"Query execution completed, returned {len(results)} records")
        
        # Process results
        combined_data = []
        for row in results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            
            actual_membership = float(row.get('ACTUAL_MEMBERSHIP') or 0) if row.get('ACTUAL_MEMBERSHIP') is not None else None
            projected_membership = float(row.get('PROJECTED_MEMBERSHIP') or 0) if row.get('PROJECTED_MEMBERSHIP') is not None else None
            variance_percentage = float(row.get('VARIANCE_PERCENTAGE')) if row.get('VARIANCE_PERCENTAGE') is not None else None
            
            # Round raw values
            actual_membership_rounded = round(actual_membership) if actual_membership else None
            projected_membership_rounded = round(projected_membership) if projected_membership else None
            
            combined_row = {
                'GROUPING_LEVEL': row.get('GROUPING_LEVEL'),
                'PERIOD_DATE': period_date,
                'PERIOD_LABEL': row.get('TIME_PERIOD'),
                'ACTUAL_MEMBERSHIP': actual_membership_rounded,
                'PROJECTED_MEMBERSHIP': projected_membership_rounded,
                'ACTUAL_MEMBERSHIP_FORMATTED': format_membership_value(actual_membership_rounded),
                'PROJECTED_MEMBERSHIP_FORMATTED': format_membership_value(projected_membership_rounded),
                'VARIANCE_GAP_PCT': variance_percentage
            }
            combined_data.append(combined_row)
        
        # Sort by PERIOD_DATE chronologically
        combined_data.sort(key=lambda x: x['PERIOD_DATE'])
        
        return ActualVsProjectedMembershipResponse(
            status="success",
            data=combined_data,
            period_count=len(combined_data),
            message="Actual vs projected membership data retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_actual_vs_projected_membership: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
