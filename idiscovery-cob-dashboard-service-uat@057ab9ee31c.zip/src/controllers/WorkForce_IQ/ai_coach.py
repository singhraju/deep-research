import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, Response, status

import config
from controllers.common.user_role import get_user_role
from schema import WorkforceIQAICoachRequest, AICoachResponse, UserRoleRequest
from services.metric_cache_service import metric_cache_service
from services.metrics_aggregator import fetch_workforce_metrics
from services.openai_service import generate_performance_summary, normalize_ai_summary
from services.session_cache_orchestrator import generate_session_id

logger = logging.getLogger(__name__)

WORKFORCE_PERSONA_LABELS = {
    "director": "Director",
    "manager": "Manager",
    "auditor_manager": "Auditor Manager",
}

WORKFORCE_PERSONA_METRICS = {
    "director": {
        # Only the 10 active metrics from header_kpis
        "staff_utilization_pct",
        "cycle_time_per_fte",
        "capacity_per_fte",
        "backlog_volume",
        "days_work_on_hand",
        "avg_resolved_per_day",
        "net_inventory_change",
        "sla_risk_pct",
        "required_fte",
        "actual_fte",
    },
    "manager": {
        # Only the 10 active metrics from header_kpis
        "staff_utilization_pct",
        "cycle_time_per_fte",
        "capacity_per_fte",
        "backlog_volume",
        "days_work_on_hand",
        "avg_resolved_per_day",
        "net_inventory_change",
        "sla_risk_pct",
        "required_fte",
        "actual_fte",
    },
    "auditor_manager": {
        # Only the 10 active metrics from header_kpis
        "staff_utilization_pct",
        "cycle_time_per_fte",
        "capacity_per_fte",
        "backlog_volume",
        "days_work_on_hand",
        "avg_resolved_per_day",
        "net_inventory_change",
        "sla_risk_pct",
        "required_fte",
        "actual_fte",
    },
}

WORKFORCE_ALL_METRICS = {
    # Only the 10 active metrics from header_kpis
    "staff_utilization_pct",
    "cycle_time_per_fte",
    "capacity_per_fte",
    "backlog_volume",
    "days_work_on_hand",
    "avg_resolved_per_day",
    "net_inventory_change",
    "sla_risk_pct",
    "required_fte",
    "actual_fte",
}


def _normalize_workforce_persona(value: Optional[str]) -> Optional[str]:
    if not value:
        return None

    normalized = value.strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "director": "director",
        "manager": "manager",
        "auditor_manager": "auditor_manager",
        "audit_manager": "auditor_manager",
        "wfm": "manager",
        "workforce_manager": "manager",
    }
    return aliases.get(normalized)


async def resolve_workforce_persona(user_id: str, requested_persona: Optional[str] = None) -> Optional[str]:
    if requested_persona is not None:
        return _normalize_workforce_persona(requested_persona)

    role_response = await get_user_role(UserRoleRequest(user_id=user_id))
    return _normalize_workforce_persona(getattr(role_response, "user_role", None))


def _scope_workforce_metrics_for_persona(metrics_data: Dict[str, Any], persona: str) -> Dict[str, Any]:
    allowed_metrics = WORKFORCE_ALL_METRICS
    scoped_metrics = {
        metric_name: metric_value
        for metric_name, metric_value in metrics_data.get("metrics", {}).items()
        if metric_name in allowed_metrics
    }
    scoped_data_gaps = [
        metric_name
        for metric_name in metrics_data.get("data_gaps", [])
        if metric_name in allowed_metrics
    ]

    scoped_metrics_data = dict(metrics_data)
    scoped_metrics_data["metrics"] = scoped_metrics
    scoped_metrics_data["data_gaps"] = scoped_data_gaps
    scoped_metrics_data["persona"] = persona
    scoped_metrics_data["persona_label"] = WORKFORCE_PERSONA_LABELS[persona]
    return scoped_metrics_data

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])


@router.post("/ai-coach", response_model=AICoachResponse)
async def get_workforce_ai_coach(request: WorkforceIQAICoachRequest, response: Response) -> AICoachResponse:
    """
    WorkforceIQ AI Coach endpoint - provides strategic workforce insights.
    
    Analyzes comprehensive workforce metrics including:
    - Staffing gaps and capacity constraints
    - Inventory flow balance (receipts vs resolved)
    - SLA risk and backlog pressure
    - Membership variance and demand utilization
    - Workforce productivity and shrinkage
    
    Returns AI-generated coaching with confidence, severity, and recommended actions.
    """
    if not config.is_ai_coach_enabled("workforce"):
        return AICoachResponse(
            status="disabled",
            user_id=request.user_id,
            performance_summary="AI Coach feature is currently disabled",
            message="Feature disabled by configuration",
        )

    try:
        persona = await resolve_workforce_persona(request.user_id, request.persona)
        if persona is None:
            response.status_code = status.HTTP_422_UNPROCESSABLE_CONTENT
            return AICoachResponse(
                status="error",
                user_id=request.user_id,
                performance_summary="Unable to generate workforce summary because Workforce IQ AI Coach is only available for director, manager, and auditor manager personas.",
                message="Unsupported Workforce persona for AI Coach",
            )

        session_id = request.session_id
        if config.REDIS_ENABLED and not session_id:
            session_id = generate_session_id()
            logger.info(f"Auto-generated session_id: {session_id}")

        logger.info(
            f"Workforce AI Coach request for user {request.user_id}, persona={persona}, "
            f"period {request.start_date} to {request.end_date}"
        )

        metrics_data = await fetch_workforce_metrics(
            user_id=request.user_id,
            start_date=request.start_date,
            end_date=request.end_date,
            lob=request.lob,
            staffing_category=request.staffing_category,
            work_type=request.work_type,
            manager=request.manager,
            market=request.market,
            funding_model=request.funding_model,
            session_id=session_id,
        )

        logger.info(
            f"Workforce AI Coach - Metrics sent to LLM for {request.user_id}: "
            f"{list(metrics_data.get('metrics', {}).keys())}"
        )

        if "error" in metrics_data:
            logger.error(
                "Workforce AI Coach metrics fetch failed for %s: %s",
                request.user_id,
                metrics_data.get("error"),
            )
            response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            return AICoachResponse(
                status="error",
                user_id=request.user_id,
                performance_summary="Unable to generate workforce summary. Please review your Workforce IQ dashboard.",
                message=f"Failed to fetch AI Coach metrics: {metrics_data.get('error')}",
                data_gaps=metrics_data.get("data_gaps", []),
            )

        metrics_data = _scope_workforce_metrics_for_persona(metrics_data, persona)
        if not metrics_data.get("metrics"):
            response.status_code = status.HTTP_422_UNPROCESSABLE_CONTENT
            return AICoachResponse(
                status="error",
                user_id=request.user_id,
                performance_summary="Unable to generate workforce summary because the available Workforce IQ metrics are insufficient for this persona.",
                message="Insufficient Workforce metrics available for persona-aware AI Coach",
                data_gaps=metrics_data.get("data_gaps", []),
            )

        start_time = time.time()
        summary = await generate_performance_summary(
            user_id=request.user_id,
            metrics_data=metrics_data,
            role="workforce",
            start_date=request.start_date,
            end_date=request.end_date,
            lob=request.lob,
        )
        latency_ms = int((time.time() - start_time) * 1000)

        normalized_summary = normalize_ai_summary(summary, include_legacy_key=True)
        summary_text = normalized_summary.get("performance_summary", "")
        parsed_payload = normalized_summary.get("parsed_payload", {})

        return AICoachResponse(
            status="success",
            user_id=request.user_id,
            performance_summary=summary_text,
            message=f"Workforce AI Coach {WORKFORCE_PERSONA_LABELS[persona]} analysis completed successfully",
            confidence=parsed_payload.get("confidence"),
            primary_issue=parsed_payload.get("primary_issue"),
            primary_metric=parsed_payload.get("primary_metric"),
            secondary_issues=parsed_payload.get("secondary_issues"),
            data_gaps=parsed_payload.get("data_gaps") or metrics_data.get("data_gaps", []),
            recommended_action=parsed_payload.get("recommended_action"),
            severity=parsed_payload.get("severity"),
            metadata={
                "role": "workforce",
                "persona": persona,
                "metrics_analyzed": list(metrics_data.get("metrics", {}).keys()),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "latency_ms": latency_ms,
                "session_id": session_id,
            },
        )

    except Exception as e:
        logger.error(
            f"Workforce AI Coach error for {request.user_id}: {type(e).__name__}: {str(e)}",
            exc_info=True,
        )
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return AICoachResponse(
            status="error",
            user_id=request.user_id,
            performance_summary="An unexpected error occurred while generating workforce insights.",
            message=f"AI Coach error: {str(e)}",
        )
