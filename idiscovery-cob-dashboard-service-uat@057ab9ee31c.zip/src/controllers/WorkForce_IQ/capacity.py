import asyncio
import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import WorkforceIQCapacityKPIsRequest, WorkforceIQCapacityKPIsResponse
from controllers.WorkForce_IQ.header_kpis import build_intake_source_filter
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()


# =============================================================================
# SQL QUERIES
# =============================================================================

CAPACITY_PER_FTE_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        RESOLVEDUSERNAME,
        PYSTATUSWORK,
        CYCLE_TIME,
        DATE(PYRESOLVEDTIMESTAMP) AS PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        ASSOCIATEACCESSGROUP,
        LOB,
        MARKET,
        FUNDINGMODEL,
        INTAKESOURCESYSTEM
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        RESOLVEDUSERNAME
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{manager_filter}}
      AND ASSOCIATEACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
),
grouped_count AS (
    SELECT
        PYRESOLVEDTIMESTAMP,
        PYRESOLVEDUSERID,
        COUNT(DISTINCT PYID) AS resolved_count
    FROM filtered_inventory
    GROUP BY PYRESOLVEDTIMESTAMP, PYRESOLVEDUSERID
)
SELECT
    ROUND(AVG(resolved_count), 2) AS CAPACITY_PER_FTE
FROM grouped_count
"""

CASES_PER_HOUR_QUERY = f"""
WITH input_params AS (
    SELECT 
        '{{start_date}}'::DATE AS from_date,
        '{{end_date}}'::DATE AS to_date
),
date_params AS (
    SELECT 
        YEAR(CURRENT_DATE) AS current_year,
        MONTH(CURRENT_DATE) AS current_month,
        (YEAR(CURRENT_DATE) * 100 + MONTH(CURRENT_DATE)) AS current_year_month,
        ip.from_date,
        ip.to_date
    FROM input_params ip
),
completed_work_items AS (
    SELECT 
        inv.PYID,
        inv.LOB,
        inv.REPORTTOMANAGERID,
        inv.REPORTTOMANAGERNAME,
        inv.INTAKESOURCESYSTEM AS STAFFING_CATEGORY,
        inv.INTAKESOURCESYSTEM AS WORK_TYPE,
        inv.MARKET,
        inv.FUNDINGMODEL,
        inv.PYRESOLVEDTIMESTAMP,
        inv.CYCLE_TIME,
        YEAR(inv.PYRESOLVEDTIMESTAMP) AS resolved_year,
        MONTH(inv.PYRESOLVEDTIMESTAMP) AS resolved_month,
        (YEAR(inv.PYRESOLVEDTIMESTAMP) * 100 + MONTH(inv.PYRESOLVEDTIMESTAMP)) AS resolved_year_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    CROSS JOIN date_params dp
    WHERE 1=1
        AND inv.PYRESOLVEDTIMESTAMP >= dp.from_date
        AND inv.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, dp.to_date)
        AND inv.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND inv.CYCLE_TIME IS NOT NULL
        AND inv.CYCLE_TIME > 0
        {{lob_filter}}
        {{manager_filter}}
        {{intake_source_filter}}
        {{market_filter}}
        {{funding_model_filter}}
),
productivity_metrics AS (
    SELECT 
        COUNT(DISTINCT PYID) AS total_completed_cases,
        SUM(CYCLE_TIME) AS total_cycle_time_seconds,
        CASE 
            WHEN COUNT(DISTINCT PYID) = 0 THEN NULL
            ELSE ROUND((SUM(CYCLE_TIME) / COUNT(DISTINCT PYID)) / 60.0, 2)
        END AS weighted_cycle_time_minutes,
        CASE 
            WHEN SUM(CYCLE_TIME) = 0 THEN NULL
            WHEN SUM(CYCLE_TIME) IS NULL THEN NULL
            ELSE ROUND((3600.0 * COUNT(DISTINCT PYID)) / SUM(CYCLE_TIME), 2)
        END AS cases_per_hour
    FROM completed_work_items
)
SELECT 
    cases_per_hour AS CASES_PER_HOUR,
    total_completed_cases AS TOTAL_COMPLETED_CASES,
    total_cycle_time_seconds AS TOTAL_CYCLE_TIME_SECONDS,
    ROUND(total_cycle_time_seconds / 60.0, 2) AS TOTAL_CYCLE_TIME_MINUTES,
    weighted_cycle_time_minutes AS WEIGHTED_CYCLE_TIME_MINUTES,
    ROUND(60.0 / NULLIF(weighted_cycle_time_minutes, 0), 2) AS CASES_PER_HOUR_VERIFICATION,
    (SELECT from_date FROM date_params) AS PERIOD_START,
    (SELECT to_date FROM date_params) AS PERIOD_END
FROM productivity_metrics
"""

AVG_FTE_HOURS_QUERY = f"""
WITH input_params AS (
    SELECT 
        '{{start_date}}'::DATE AS from_date,
        '{{end_date}}'::DATE AS to_date
),
user_staffing_cat AS (
    SELECT
        up.USERID,
        xw.STAFFING_CATEGORY AS STAFFING_CATEGORY,
        ROW_NUMBER() OVER (PARTITION BY up.USERID ORDER BY up.logindate DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE up
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xw
        ON TRIM(up.STAFFINGCATEGORY) = TRIM(xw.STAFFING_CATEGORY)
    WHERE up.USERID IS NOT NULL
),
frontline_productive_hours AS (
    SELECT 
        up.USERID,
        up.USERNAME,
        up.FIRSTNAME,
        up.LASTNAME,
        up.LOGINDATE,
        up.PRODUCTIVETIME,
        
        -- Convert PRODUCTIVETIME (h:mm:ss) to decimal hours inline
        CAST(SPLIT_PART(up.PRODUCTIVETIME, ':', 1) AS DECIMAL(10,2)) +
        (CAST(SPLIT_PART(up.PRODUCTIVETIME, ':', 2) AS DECIMAL(10,2)) / 60.0) +
        (CAST(SPLIT_PART(up.PRODUCTIVETIME, ':', 3) AS DECIMAL(10,2)) / 3600.0) AS productive_hours_decimal,
        
        wd.JOB_PROFILE_NAME
        
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE up
    INNER JOIN (
        SELECT DISTINCT
            w.EMPLOYEE_DOMAIN_ID,
            w.JOB_PROFILE_NAME,
            w.MANAGER_DOMAIN_ID,
            usc.STAFFING_CATEGORY
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
        LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
        CROSS JOIN input_params ip
        WHERE w.ASOFTODAY BETWEEN ip.from_date AND ip.to_date
          AND w.JOB_PROFILE_NAME LIKE 'eCOB%'
          {{staffing_category_filter_workday}}
          {{manager_filter_workday}}
    ) wd ON up.USERID = wd.EMPLOYEE_DOMAIN_ID
    
    CROSS JOIN input_params ip
    
    WHERE 1=1
        AND up.LOGINDATE BETWEEN ip.from_date AND ip.to_date
        AND up.PRODUCTIVETIME IS NOT NULL
        AND up.PRODUCTIVETIME <> ''
        AND up.PRODUCTIVETIME <> '0'
),
avg_calculation AS (
    SELECT 
        COUNT(DISTINCT USERID) AS total_associates,
        COUNT(DISTINCT LOGINDATE) AS total_login_days,
        COUNT(*) AS total_records,
        SUM(productive_hours_decimal) AS total_productive_hours,
        AVG(productive_hours_decimal) AS avg_productive_hours_per_day
    FROM frontline_productive_hours
)
SELECT 
    ROUND(avg_productive_hours_per_day, 2) AS AVG_FTE_HOURS,
    total_associates AS TOTAL_FRONTLINE_ASSOCIATES,
    total_login_days AS TOTAL_UNIQUE_LOGIN_DAYS,
    total_records AS TOTAL_LOGIN_RECORDS,
    ROUND(total_productive_hours, 2) AS TOTAL_PRODUCTIVE_HOURS,
    (SELECT from_date FROM input_params) AS PERIOD_START,
    (SELECT to_date FROM input_params) AS PERIOD_END
FROM avg_calculation
"""

SHRINKAGE_PERCENT_QUERY = f"""
WITH config AS (
    SELECT 
        '{{start_date}}'::DATE AS date_from,
        '{{end_date}}'::DATE AS date_to
),
effective_range AS (
    SELECT
        date_from,
        LEAST(date_to, CURRENT_DATE()) AS date_to,
        CASE WHEN date_from > CURRENT_DATE() THEN TRUE ELSE FALSE END AS is_future
    FROM config
),
-- =====================================================
-- AVAILABLE FTE LOGIC (Daily logic only, no grouping)
-- =====================================================
user_staffing_cat AS (
    SELECT
        up.USERID,
        xw.STAFFING_CATEGORY AS STAFFING_CATEGORY,
        ROW_NUMBER() OVER (PARTITION BY up.USERID ORDER BY up.logindate DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE up
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xw
        ON TRIM(up.STAFFINGCATEGORY) = TRIM(xw.STAFFING_CATEGORY)
    WHERE up.USERID IS NOT NULL
),
historical_avail AS (
    SELECT DISTINCT w.EMPLOYEE_DOMAIN_ID AS userid, w.MANAGER_DOMAIN_ID AS manager_id,
        TRY_CAST(w.ASOFTODAY AS DATE) AS snapshot_date,
        COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) <= CURRENT_DATE()
      AND DAYOFWEEK(TRY_CAST(w.ASOFTODAY AS DATE)) NOT IN (0, 6)
      {{manager_filter_workday}}        
      {{staffing_category_filter_workday}}
),
-- Historical average - using DAILY logic only (most recent day)
historical_avg AS (
    SELECT COUNT(DISTINCT userid) AS avg_historical_fte
    FROM historical_avail
    WHERE snapshot_date = (
        SELECT MAX(snapshot_date) 
        FROM historical_avail 
        WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
    )
),
onboard_data AS (
    SELECT
        TRY_CAST(op.FUTURE_START_DATE AS DATE) AS start_date,
        op.ONBOARDING_COUNT,
        COALESCE(UPPER(TRIM(op.LOB)), 'NONE') AS LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_OPEN_POSITIONS op
    WHERE TRY_CAST(op.FUTURE_START_DATE AS DATE) IS NOT NULL
        AND COALESCE(UPPER(TRIM(op.LOB)), 'NONE') IN ('COMMERCIAL', 'GB MEDICAID', 'GB MEDICARE', 'NONE')
),
onboard_by_period AS (
    SELECT
        start_date AS period_date,
        start_date AS onboard_complete_date,
        SUM(ONBOARDING_COUNT) AS onboard_fte
    FROM onboard_data
    WHERE start_date >= DATEADD(DAY, -15, (SELECT MAX(snapshot_date) FROM historical_avail WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)))
    GROUP BY period_date, start_date
),
historical_grouped AS (
    SELECT
        snapshot_date AS period_date,
        COUNT(DISTINCT userid) AS AVAIL_FTE
    FROM historical_avail
    WHERE snapshot_date BETWEEN (SELECT date_from FROM config) AND LEAST((SELECT date_to FROM config), CURRENT_DATE())
      AND snapshot_date < CURRENT_DATE()
    GROUP BY period_date
),
future_periods AS (
    SELECT
        DATEADD(DAY, SEQ4(), CURRENT_DATE()) AS period_date
    FROM TABLE(GENERATOR(ROWCOUNT => 1000000))
    WHERE period_date <= (SELECT date_to FROM config)
      AND period_date >= CURRENT_DATE()
),
future_grouped AS (
    SELECT
        fp.period_date,
        CASE
            WHEN DAYOFWEEK(fp.period_date) IN (0, 6) THEN NULL
            ELSE ROUND(COALESCE((SELECT avg_historical_fte FROM historical_avg), 0)
                 + COALESCE((SELECT SUM(onboard_fte) FROM onboard_by_period WHERE onboard_complete_date <= fp.period_date), 0), 0)
        END AS AVAIL_FTE
    FROM future_periods fp
),
available_combined AS (
    SELECT period_date, AVAIL_FTE FROM historical_grouped
    UNION ALL
    SELECT period_date, AVAIL_FTE FROM future_grouped
),
-- =====================================================
-- ACTUAL FTE LOGIC (Daily logic only, no grouping)
-- =====================================================
total_head AS (
    SELECT DISTINCT
        TRY_CAST(w.ASOFTODAY AS DATE) AS snapshot_date,
        w.EMPLOYEE_DOMAIN_ID AS userid,
        w.MANAGER_DOMAIN_ID AS manager_id,
        COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
      AND (SELECT is_future FROM effective_range) = FALSE
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT date_from FROM effective_range) AND (SELECT date_to FROM effective_range)
      AND DAYOFWEEK(TRY_CAST(w.ASOFTODAY AS DATE)) NOT IN (0, 6)
      {{manager_filter_workday}}        
      {{staffing_category_filter_workday}}
),
time_off AS (
    SELECT userid, manager_id, time_off_date, hours_off, STAFFING_CATEGORY
    FROM (
        SELECT
            w.EMPLOYEE_DOMAIN_ID AS userid,
            w.MANAGER_DOMAIN_ID AS manager_id,
            TRY_CAST(w.TIME_OFF_DATE AS DATE) AS time_off_date,
            TRY_CAST(w.HOURS AS FLOAT) AS hours_off,
            COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY,
            ROW_NUMBER() OVER (
                PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.TIME_OFF_DATE AS DATE), w.TIME_OFF_TYPE, w.HOURS
                ORDER BY w.EMPLOYEE_DOMAIN_ID
            ) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
        LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
        WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
          AND w.STATUS IN ('Approved', 'Submitted')
          AND w.TIME_OFF_TYPE IN (
              -- Scheduled PTO
              'Paid Time Off - Approved/Scheduled',
              'Paid Time Off',
              'Paid Time Off - Supplemental',
 
              -- Unscheduled PTO
              'Paid Time Off - Unapproved/Unscheduled',
 
              -- Sick Time (all types that reduce available capacity)
              'Sick Time',
              'Sick Time - Approved',
              'Sick Time - Unapproved',
              'Sick Time - Supplemental',
              'Sick Time - Intermittent LOA',
 
              -- Wellness and Care Leave
              'Wellness Days Off',
              'Paid Time Off - Kin Care/CA Sick',
              'Critical Care Leave',
 
              -- Parental Leave
              'Paid Parental Leave',
              'Other Paid Time - New Parent Transition',
 
              -- Other Paid Time Off
              'Other Paid Time - Bereavement',
              'Other Paid Time - Jury Duty',
              'Other Paid Time - Voting',
              'Other Paid Time - Voluntary Time Off/Community Service',
              'Other Paid Off - Business Disruption/Sent Home/Lack of Work',
 
              -- Intermittent LOA (affects daily capacity)
              'Paid Time Off - Intermittent LOA',
              'Other Paid Time - Intermittent LOA',
              'Non Paid Time - Intermittent LOA',
 
              -- Approved Unpaid Time
              'Non Paid Time - Approved/Voluntary',
 
              -- Workers Comp and Special Cases
              'Non Paid Time - Worker''s Compensation',
              'Non Paid Time - Victims of Domestic Violence & Crimes',
              'Non Paid Time - Unapproved'
          )
          AND (SELECT is_future FROM effective_range) = FALSE
          AND TRY_CAST(w.TIME_OFF_DATE AS DATE) IS NOT NULL
          AND TRY_CAST(w.TIME_OFF_DATE AS DATE) BETWEEN (SELECT date_from FROM effective_range) AND (SELECT date_to FROM effective_range)
          {{manager_filter_workday}}    
          {{staffing_category_filter_workday}}       
    ) WHERE rn = 1
),
grouped_head AS (
    SELECT
        snapshot_date AS period_date,
        COUNT(DISTINCT userid) AS total_head_count
    FROM total_head
    WHERE snapshot_date < CURRENT_DATE()
    GROUP BY period_date
),
holidays AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),
holiday_count_per_period AS (
    SELECT
        h.holiday_date AS period_date,
        COUNT(*) AS holiday_count
    FROM holidays h
    WHERE DAYOFWEEK(h.holiday_date) NOT IN (0, 6)
    GROUP BY period_date
),
time_off_with_periods AS (
    SELECT
        time_off_date AS period_date,
        hours_off
    FROM time_off
),
adjusted_time_off AS (
    SELECT
        t.period_date,
        ROUND(SUM(t.hours_off) / 8.0, 2) AS adjusted_fte_off
    FROM time_off_with_periods t
    GROUP BY t.period_date
),
actual_fte_calculation AS (
    SELECT
        g.period_date,
        CASE
            WHEN EXISTS (SELECT 1 FROM holidays h WHERE h.holiday_date = g.period_date) THEN NULL
            ELSE GREATEST(CEIL(g.total_head_count - COALESCE(at.adjusted_fte_off, 0)), 0)
        END AS ACTUAL_FTE
    FROM grouped_head g
    LEFT JOIN adjusted_time_off at ON g.period_date = at.period_date
),
-- =====================================================
-- FINAL AGGREGATION AND SHRINKAGE CALCULATION
-- =====================================================
available_aggregated AS (
    SELECT 
        SUM(AVAIL_FTE) AS total_available_fte,
        COUNT(DISTINCT period_date) AS period_count,
        ROUND(AVG(AVAIL_FTE), 2) AS avg_available_fte
    FROM available_combined
    WHERE AVAIL_FTE IS NOT NULL
),
actual_aggregated AS (
    SELECT 
        SUM(ACTUAL_FTE) AS total_actual_fte,
        COUNT(DISTINCT period_date) AS period_count,
        ROUND(AVG(ACTUAL_FTE), 2) AS avg_actual_fte
    FROM actual_fte_calculation
    WHERE ACTUAL_FTE IS NOT NULL
),
final_shrinkage AS (
    SELECT
        (SELECT date_from FROM config) AS PERIOD_START,
        (SELECT date_to FROM config) AS PERIOD_END,
        aa.total_available_fte AS AVAILABLE_FTE,
        aga.total_actual_fte AS ACTUAL_FTE,
        CASE 
            WHEN aa.total_available_fte = 0 THEN NULL
            WHEN aa.total_available_fte IS NULL THEN NULL
            ELSE ROUND(((aa.total_available_fte - aga.total_actual_fte) / aa.total_available_fte) * 100, 2)
        END AS SHRINKAGE_PERCENT
    FROM available_aggregated aa, actual_aggregated aga
)
SELECT
    PERIOD_START,
    PERIOD_END,
    SHRINKAGE_PERCENT,
    AVAILABLE_FTE,
    ACTUAL_FTE
FROM final_shrinkage
"""


# =============================================================================
# Filter Building Functions
# =============================================================================

def build_date_filter(start_date: str, end_date: str) -> str:
    """Build date filter for PYRESOLVEDTIMESTAMP column."""
    return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for inventory queries."""
    if not lob or len(lob) == 0:
        return ""
    lob_values = "', '".join(lob)
    return f"AND COALESCE(LOB, 'None') IN ('{lob_values}')"


def build_manager_filter(manager: Optional[List[str]] = None) -> str:
    """Build manager filter for inventory queries."""
    if not manager or len(manager) == 0:
        return ""
    manager_values = "', '".join(manager)
    return f"AND COALESCE(REPORTTOMANAGERID, 'None') IN ('{manager_values}')"


def build_staffing_category_filter(staffing_category: Optional[List[str]] = None) -> str:
    """Build staffing category filter for inventory queries."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    null_requested = "None" in staffing_category
    non_null_categories = [cat for cat in staffing_category if cat != "None"]
    
    if null_requested and non_null_categories:
        category_values = "', '".join(non_null_categories)
        return f"AND (inv.INTAKESOURCESYSTEM IN ('{category_values}') OR inv.INTAKESOURCESYSTEM IS NULL)"
    elif null_requested:
        return "AND inv.INTAKESOURCESYSTEM IS NULL"
    else:
        category_values = "', '".join(non_null_categories)
        return f"AND inv.INTAKESOURCESYSTEM IN ('{category_values}')"


def build_work_type_filter(work_type: Optional[List[str]] = None) -> str:
    """Build work type filter for inventory queries."""
    if not work_type or len(work_type) == 0:
        return ""
    
    null_requested = "None" in work_type
    non_null_types = [wt for wt in work_type if wt != "None"]
    
    if null_requested and non_null_types:
        work_type_values = "', '".join(non_null_types)
        return f"AND (inv.INTAKESOURCESYSTEM IN ('{work_type_values}') OR inv.INTAKESOURCESYSTEM IS NULL)"
    elif null_requested:
        return "AND inv.INTAKESOURCESYSTEM IS NULL"
    else:
        work_type_values = "', '".join(non_null_types)
        return f"AND inv.INTAKESOURCESYSTEM IN ('{work_type_values}')"


def build_market_filter(market: Optional[List[str]] = None) -> str:
    """Build market filter for inventory queries."""
    if not market or len(market) == 0:
        return ""
    
    null_requested = "None" in market
    non_null_markets = [m for m in market if m != "None"]
    
    if null_requested and non_null_markets:
        market_values = "', '".join(non_null_markets)
        return f"AND (inv.MARKET IN ('{market_values}') OR inv.MARKET IS NULL)"
    elif null_requested:
        return "AND inv.MARKET IS NULL"
    else:
        market_values = "', '".join(non_null_markets)
        return f"AND inv.MARKET IN ('{market_values}')"


def build_funding_model_filter(funding_model: Optional[List[str]] = None) -> str:
    """Build funding model filter for inventory queries."""
    if not funding_model or len(funding_model) == 0:
        return ""
    
    null_requested = "None" in funding_model
    non_null_models = [fm for fm in funding_model if fm != "None"]
    
    if null_requested and non_null_models:
        funding_model_values = "', '".join(non_null_models)
        return f"AND (inv.FUNDINGMODEL IN ('{funding_model_values}') OR inv.FUNDINGMODEL IS NULL)"
    elif null_requested:
        return "AND inv.FUNDINGMODEL IS NULL"
    else:
        funding_model_values = "', '".join(non_null_models)
        return f"AND inv.FUNDINGMODEL IN ('{funding_model_values}')"


def build_lob_filter_workday(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for workday queries (uses user_lob mapping)."""
    if not lob or len(lob) == 0:
        return ""
    lob_values = "', '".join([l.upper() for l in lob])
    return f"AND COALESCE(ul.LOB, 'NONE') IN ('{lob_values}')"


def build_manager_filter_workday(manager: Optional[List[str]] = None) -> str:
    """Build manager filter for workday queries."""
    if not manager or len(manager) == 0:
        return ""
    manager_values = "', '".join([m.upper() for m in manager])
    return f"AND UPPER(TRIM(w.MANAGER_DOMAIN_ID)) IN ('{manager_values}')"


def build_staffing_category_filter_workday(staffing_category: Optional[List[str]] = None) -> str:
    """Build staffing category filter for workday queries (uses user_staffing_cat mapping)."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    category_values = "', '".join([s.upper() for s in staffing_category])
    return f"AND COALESCE(usc.STAFFING_CATEGORY, 'None') IN ('{category_values}')"


@router.post("/capacity", response_model=WorkforceIQCapacityKPIsResponse)
async def get_workforce_iq_capacity(request: WorkforceIQCapacityKPIsRequest):
    """
    Get Workforce IQ Capacity metrics.
    
    Returns capacity metrics including capacity per FTE, cases per hour, avg FTE hours, and shrinkage.
    
    **Filters:**
    - start_date, end_date: Date range filter (required)
    - lob: Line of Business filter (optional)
    - manager: Manager filter (optional)
    - session_id: Session ID for Redis caching (optional)
    
    **Returns:**
    - capacity_per_fte: Capacity per FTE (formatted as "XX cases")
    - cases_per_hour: Cases per hour
    - avg_fte_hours: Average FTE hours per day
    - shrinkage_pct: Shrinkage percentage (placeholder)
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        logger.info(f"Workforce IQ Capacity request: {request.model_dump()}")

        engine = connection_manager.get_engine()

        
        # Build filters
        date_filter = build_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(request.lob)
        manager_filter = build_manager_filter(request.manager)
        intake_source_filter = build_intake_source_filter(request.work_type)
        work_type_filter = build_work_type_filter(request.work_type)
        market_filter = build_market_filter(request.market)
        funding_model_filter = build_funding_model_filter(request.funding_model)
        
        # Build queries
        capacity_query = CAPACITY_PER_FTE_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            manager_filter=manager_filter
        )
        
        cases_per_hour_query = CASES_PER_HOUR_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            manager_filter=manager_filter,
            intake_source_filter=intake_source_filter,
            market_filter=market_filter,
            funding_model_filter=funding_model_filter
        )

        staffing_category_filter_workday = build_staffing_category_filter_workday(request.staffing_category)
        manager_filter_workday = build_manager_filter_workday(request.manager)
        
        avg_fte_hours_query = AVG_FTE_HOURS_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            staffing_category_filter_workday=staffing_category_filter_workday,
            manager_filter_workday=manager_filter_workday
        )
        
        shrinkage_query = SHRINKAGE_PERCENT_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            staffing_category_filter_workday=staffing_category_filter_workday,
            manager_filter_workday=manager_filter_workday
        )
        
        # Define async fetch functions
        async def fetch_capacity():
            return await engine.execute_query_async(capacity_query, limit=1)
        
        async def fetch_cases_per_hour():
            return await engine.execute_query_async(cases_per_hour_query, limit=1)
        
        async def fetch_avg_fte_hours():
            return await engine.execute_query_async(avg_fte_hours_query, limit=1)
        
        async def fetch_shrinkage():
            return await engine.execute_query_async(shrinkage_query, limit=1)
        
        # Execute all 4 queries in parallel
        logger.info("Executing 4 capacity queries in parallel")
        capacity_records, cases_per_hour_records, avg_fte_hours_records, shrinkage_records = await asyncio.gather(
            fetch_capacity(),
            fetch_cases_per_hour(),
            fetch_avg_fte_hours(),
            fetch_shrinkage(),
            return_exceptions=False
        )
        logger.info("Parallel query execution completed")
        
        # Extract capacity per FTE from capacity query
        if capacity_records and len(capacity_records) > 0:
            record = capacity_records[0]
            capacity_per_fte_value = float(record.get('CAPACITY_PER_FTE', 0) or 0)
            
            # Format capacity per FTE as "XX.XX cases"
            capacity_per_fte = f"{capacity_per_fte_value:.2f} cases"
        else:
            capacity_per_fte = "-"
        
        # Extract cases per hour from dedicated query
        if cases_per_hour_records and len(cases_per_hour_records) > 0:
            cph_record = cases_per_hour_records[0]
            cases_per_hour_value = float(cph_record.get('CASES_PER_HOUR', 0) or 0)
            
            if cases_per_hour_value > 0:
                cases_per_hour = f"{cases_per_hour_value:.1f}"
            else:
                cases_per_hour = "-"
        else:
            cases_per_hour = "-"
        
        # Extract avg FTE hours from dedicated query
        if avg_fte_hours_records and len(avg_fte_hours_records) > 0:
            fte_record = avg_fte_hours_records[0]
            avg_fte_hours_value = float(fte_record.get('AVG_FTE_HOURS', 0) or 0)
            
            if avg_fte_hours_value > 0:
                avg_fte_hours = f"{avg_fte_hours_value:.1f}"
            else:
                avg_fte_hours = "-"
        else:
            avg_fte_hours = "-"
        
        # Extract shrinkage from dedicated query
        if shrinkage_records and len(shrinkage_records) > 0:
            shrinkage_record = shrinkage_records[0]
            shrinkage_value = float(shrinkage_record.get('SHRINKAGE_PERCENT', 0) or 0)
            
            if shrinkage_value > 0:
                shrinkage_pct = f"{shrinkage_value:.1f}%"
            else:
                shrinkage_pct = "-"
        else:
            shrinkage_pct = "-"
        
        return WorkforceIQCapacityKPIsResponse(
            status="success",
            capacity_per_fte=capacity_per_fte,
            cases_per_hour=cases_per_hour,
            avg_fte_hours=avg_fte_hours,
            shrinkage_pct=shrinkage_pct,
            message="Workforce IQ Capacity retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )

    except Exception as e:
        logger.error(f"Error in get_workforce_iq_capacity: {str(e)}")
        return WorkforceIQCapacityKPIsResponse(
            status="error",
            capacity_per_fte="-",
            cases_per_hour="-",
            avg_fte_hours="-",
            shrinkage_pct="-",
            message=f"Failed to retrieve Workforce IQ Capacity: {str(e)}",
            service="idiscovery-cob-dashboard-service"
        )
