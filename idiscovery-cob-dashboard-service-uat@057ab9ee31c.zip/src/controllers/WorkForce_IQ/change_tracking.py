import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, CHANGE_TRACKING_KPIS, CHANGE_TRACKING_SAVINGS_TYPES, METRIC_CACHE_TTL, REDIS_ENABLED
from schema.workforce_iq_models import ChangeTrackingMetricsRequest, ChangeTrackingMetricsResponse, ChangeTrackingFetchRequest, ChangeTrackingFetchResponse, ChangeTrackingAddRequest, ChangeTrackingAddResponse, ChangeTrackingEditRequest, ChangeTrackingEditData, ChangeTrackingEditResponse, ChangeTrackingManageRequest, ChangeTrackingManageResponse, ChangeTrackingMetricsDetailRequest, ChangeTrackingMetricsDetailResponse, MetricDetail, ChangeTrackingUpdateRequest, ChangeTrackingUpdateResponse, ChangeTrackingTrendRequest, ChangeTrackingTrendResponse, TrendDataPoint, WorkforceIQWorkTypeListResponse
from utils.redis_cache import cache_manager

logger = logging.getLogger(__name__)

connection_manager = SnowflakeConnectionManager()

METRIC_NAME_TO_COLUMN = {
    "Cycle Time": "CYCLE_TIME",
    "Audit Score %": "AUDIT_SCORE_PCT",
    "Flip Rate Manual": "FLIP_RATE_MANUAL",
    "Flip Rate Touchless": "FLIP_RATE_TOUCHLESS",
    "Non-Value Add %": "NON_VALUE_ADD_PCT",
    "Lead Accuracy": "LEAD_ACCURACY"
}

METRIC_COLUMN_ORDER = [
    "CYCLE_TIME",
    "AUDIT_SCORE_PCT",
    "FLIP_RATE_MANUAL",
    "FLIP_RATE_TOUCHLESS",
    "NON_VALUE_ADD_PCT",
    "LEAD_ACCURACY"
]

FLIP_ACTION_DECISIONS = (
    "Added New COB Policy",
    "Change to Existing COB Policy/Primacy Lead"
)

FLIP_PRIMACY_DETERMINATIONS = (
    "Elevance Secondary",
    "Elevance Tertiary"
)


def build_change_tracking_lob_filter(lob_str: str, column_name: str = "LOB") -> str:
    if not lob_str:
        return ""

    lobs = [lob.strip() for lob in lob_str.split(",") if lob.strip()]
    if not lobs:
        return ""

    null_requested = "None" in lobs
    non_null_lobs = [lob for lob in lobs if lob != "None"]

    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND ({column_name} IN ('{lob_values}') OR {column_name} IS NULL)"
    if null_requested:
        return f"AND {column_name} IS NULL"

    lob_values = "', '".join(non_null_lobs)
    return f"AND {column_name} IN ('{lob_values}')"


def build_change_tracking_work_type_filter(work_type_str: str, column_name: str = "INTAKESOURCESYSTEM") -> str:
    if not work_type_str:
        return ""

    work_types = [wt.strip() for wt in work_type_str.split(",") if wt.strip()]
    if not work_types:
        return ""

    null_requested = "None" in work_types
    non_null_types = [wt.upper() for wt in work_types if wt != "None"]

    if null_requested and non_null_types:
        work_type_values = "', '".join(non_null_types)
        return f"AND (UPPER(TRIM({column_name})) IN ('{work_type_values}') OR {column_name} IS NULL)"
    if null_requested:
        return f"AND {column_name} IS NULL"

    work_type_values = "', '".join(non_null_types)
    return f"AND UPPER(TRIM({column_name})) IN ('{work_type_values}')"


def build_flip_rate_metric_query(date_predicates: str, work_type_filter: str, resolved_status: str, rate_alias: str, flip_cases_alias: str, total_cases_alias: str) -> str:
    action_decisions_sql = ", ".join([f"'{value}'" for value in FLIP_ACTION_DECISIONS])
    primacy_determinations_sql = ", ".join([f"'{value}'" for value in FLIP_PRIMACY_DETERMINATIONS])

    return f"""
            WITH invntry_deduped AS (
                SELECT
                    PYID,
                    ACTIONDECISION,
                    PRIMACYDETERMINATION,
                    ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK = '{resolved_status}'
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  {date_predicates}
                  {work_type_filter}
            )
            SELECT
                COUNT(DISTINCT CASE
                    WHEN ACTIONDECISION IN ({action_decisions_sql})
                     AND PRIMACYDETERMINATION IN ({primacy_determinations_sql})
                    THEN PYID
                END) AS {flip_cases_alias},
                COUNT(DISTINCT PYID) AS {total_cases_alias},
                ROUND(
                    COUNT(DISTINCT CASE
                        WHEN ACTIONDECISION IN ({action_decisions_sql})
                         AND PRIMACYDETERMINATION IN ({primacy_determinations_sql})
                        THEN PYID
                    END) * 100.0 / NULLIF(COUNT(DISTINCT PYID), 0),
                    2
                ) AS {rate_alias}
            FROM invntry_deduped
            WHERE rn = 1
            """


def build_flip_rate_trend_cte(cte_name: str, date_trunc: str, period_format: str, start_date: str, end_date: str, work_type_filter: str, resolved_status: str, rate_alias: str) -> str:
    action_decisions_sql = ", ".join([f"'{value}'" for value in FLIP_ACTION_DECISIONS])
    primacy_determinations_sql = ", ".join([f"'{value}'" for value in FLIP_PRIMACY_DETERMINATIONS])

    return f"""
        {cte_name} AS (
            SELECT
                DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP) AS period_start,
                TO_CHAR(DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP), '{period_format}') AS period_label,
                ROUND(
                    COUNT(DISTINCT CASE
                        WHEN ACTIONDECISION IN ({action_decisions_sql})
                         AND PRIMACYDETERMINATION IN ({primacy_determinations_sql})
                        THEN PYID
                    END) * 100.0 / NULLIF(COUNT(DISTINCT PYID), 0),
                    2
                ) AS {rate_alias},
                COUNT(DISTINCT PYID) AS total_cases
            FROM (
                SELECT
                    PYID,
                    ACTIONDECISION,
                    PRIMACYDETERMINATION,
                    PYRESOLVEDTIMESTAMP,
                    ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK = '{resolved_status}'
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  AND PYRESOLVEDTIMESTAMP >= '{start_date}'::DATE
                  AND PYRESOLVEDTIMESTAMP <= '{end_date}'::DATE
                  {work_type_filter}
            ) invntry_deduped
            WHERE rn = 1
            GROUP BY DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP)
        )
    """

# ============================================================================
# Change Tracking Router
# ============================================================================
router = APIRouter(prefix="/workforce-iq/change-tracking", tags=["WorkForce_IQ"])

@router.post(
    "/metrics",
    response_model=ChangeTrackingMetricsResponse,
    summary="Get Change Tracking Metrics",
    description="Returns KPIs and Savings Types dropdown values for Workforce IQ"
)
async def get_change_tracking_metrics(request: ChangeTrackingMetricsRequest):
    """Returns KPIs and Savings Types dropdown values from configuration"""
    try:
        logger.info(f"[CHANGE_TRACKING_METRICS] User ID: {request.user_id}")
        return ChangeTrackingMetricsResponse(
            status="success",
            kpis=CHANGE_TRACKING_KPIS,
            savings_types=CHANGE_TRACKING_SAVINGS_TYPES,
            message="Change tracking metrics retrieved successfully"
        )
    except Exception as e:
        logger.error(f"Change tracking metrics error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve change tracking metrics: {str(e)}")


@router.post(
    "/work-types",
    response_model=WorkforceIQWorkTypeListResponse,
    summary="Get Change Tracking Work Types",
    description="Returns distinct work types from COB_AI_INVNTRY_PROFILE for the last 18 months."
)
async def get_change_tracking_work_types(request: ChangeTrackingMetricsRequest):
    """Returns distinct work types for change tracking from the last 18 months of inventory data."""
    try:
        logger.info(f"[CHANGE_TRACKING_WORK_TYPES] User ID: {request.user_id}")

        cache_key = "change_tracking:work_types:last_18_months"
        if REDIS_ENABLED:
            cached_data = await cache_manager.get(cache_key)
            if cached_data:
                logger.info(f"[CHANGE_TRACKING_WORK_TYPES] Cache hit - returning {len(cached_data)} work types")
                return WorkforceIQWorkTypeListResponse(
                    status="success",
                    work_types=cached_data,
                    message="Change tracking work types retrieved successfully (cached)"
                )

        query = f"""
        SELECT DISTINCT COALESCE(INTAKESOURCESYSTEM, 'None') AS WORKTYPE
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        WHERE PXUPDATEDATETIME >= DATEADD(month, -18, CURRENT_DATE())
        ORDER BY WORKTYPE
        """

        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000)

        work_types = [
            {"work_type_id": row["WORKTYPE"], "work_type_name": row["WORKTYPE"]}
            for row in results
            if row.get("WORKTYPE")
        ]

        if REDIS_ENABLED:
            await cache_manager.set(cache_key, work_types, ttl=METRIC_CACHE_TTL)
            logger.info(f"[CHANGE_TRACKING_WORK_TYPES] Cached {len(work_types)} work types with TTL={METRIC_CACHE_TTL}s")

        return WorkforceIQWorkTypeListResponse(
            status="success",
            work_types=work_types,
            message="Change tracking work types retrieved successfully"
        )
    except Exception as e:
        logger.error(f"Failed to retrieve change tracking work types: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve change tracking work types: {str(e)}")

@router.post(
    "/fetch",
    response_model=ChangeTrackingFetchResponse,
    summary="Get Change Tracking Data",
    description="Fetches data from COB_AI_CHANGE_TRACKING table with optional status filter (ACTIVE, ARCHIVE, or ALL)"
)
async def fetch_change_tracking_data(request: ChangeTrackingFetchRequest):
    """Fetches change tracking data from database with optional status filter"""
    try:
        logger.info(f"[CHANGE_TRACKING_FETCH] User ID: {request.user_id}, Status: {request.status}")
        
        # Validate status - DELETE is not a valid status for fetching (it's an action that removes records)
        if request.status and request.status.upper() == "DELETE":
            raise HTTPException(
                status_code=400, 
                detail="Invalid status filter 'DELETE'. Valid values are: ACTIVE, ARCHIVE, or ALL"
            )
        
        # Build SQL query with fixed columns
        query = f"""
        SELECT INITIATIVE_YEAR, INITIATIVE_ID, INITIATIVE_NAME, TRACKING_START_DATE, CHANGE_DESCRIPTION, LOB, WORK_TYPE, KPI_METRIC, STATUS,
               CYCLE_TIME, AUDIT_SCORE_PCT, FLIP_RATE_MANUAL, FLIP_RATE_TOUCHLESS, NON_VALUE_ADD_PCT, LEAD_ACCURACY
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
        """
        
        # Add status filter if provided
        if request.status and request.status.upper() != "ALL":
            query += f" WHERE STATUS = '{request.status.upper()}'"
        
        # Execute query
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=10000)
        
        # Convert results to list of dicts
        data = [dict(row) for row in results] if results else []
        
        logger.info(f"[CHANGE_TRACKING_FETCH] Retrieved {len(data)} records from database")
        
        return ChangeTrackingFetchResponse(
            status="success",
            data=data,
            message=f"Change tracking data retrieved successfully ({len(data)} records)"
        )
    except Exception as e:
        logger.error(f"Change tracking fetch error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve change tracking data: {str(e)}")



async def build_metric_update_fields(metric_values: dict, selected_kpis: Optional[List[str]] = None, include_unselected: bool = False) -> tuple:
    """
    Helper function to build UPDATE fields and values from calculated metrics.
    
    Args:
        metric_values: Dictionary of metric names to values
        
    Returns:
        Tuple of (field_names, field_values) for SQL UPDATE/INSERT
        
    Note:
        Always includes all metric fields. If a metric value is None (no data found),
        it will be set to 'NA' in the database.
    """
    update_fields = []
    update_values = []

    if selected_kpis is None:
        selected_columns = set(METRIC_COLUMN_ORDER)
    else:
        selected_columns = {
            METRIC_NAME_TO_COLUMN[kpi]
            for kpi in selected_kpis
            if kpi in METRIC_NAME_TO_COLUMN
        }

    for column_name in METRIC_COLUMN_ORDER:
        if include_unselected or column_name in selected_columns:
            update_fields.append(column_name)
            update_values.append(str(metric_values[column_name]) if metric_values.get(column_name) is not None else "'NA'")
    
    return update_fields, update_values


def build_unselected_metric_clear_fields(selected_kpis: Optional[List[str]] = None) -> tuple:
    clear_fields = []
    clear_values = []

    if selected_kpis is None:
        selected_columns = set()
    else:
        selected_columns = {
            METRIC_NAME_TO_COLUMN[kpi]
            for kpi in selected_kpis
            if kpi in METRIC_NAME_TO_COLUMN
        }

    for column_name in METRIC_COLUMN_ORDER:
        if column_name not in selected_columns:
            clear_fields.append(column_name)
            clear_values.append("'NA'")

    return clear_fields, clear_values


async def calculate_metric_values(engine, kpi_metrics: list, lob_str: str, work_type_str: str, tracking_start_month: str):
    """
    Calculate metric values based on KPI metrics selected.
    Executes multiple metric calculations in parallel using asyncio.gather for better performance.
    Returns a dict with metric column names and their calculated values.
    """
    import asyncio
    metric_values = {
        "CYCLE_TIME": None,
        "AUDIT_SCORE_PCT": None,
        "FLIP_RATE_MANUAL": None,
        "FLIP_RATE_TOUCHLESS": None,
        "NON_VALUE_ADD_PCT": None,
        "LEAD_ACCURACY": None
    }
    
    # Map KPI metric names to column names
    metric_mapping = {
        "Cycle Time": "CYCLE_TIME",
        "Audit Score %": "AUDIT_SCORE_PCT",
        "Flip Rate Manual": "FLIP_RATE_MANUAL",
        "Flip Rate Touchless": "FLIP_RATE_TOUCHLESS",
        "Non-Value Add %": "NON_VALUE_ADD_PCT",
        "Lead Accuracy": "LEAD_ACCURACY"
    }
    
    # Build work type filter for INTAKESOURCESYSTEM (supports multiple work types)
    work_type_filter = ""
    if work_type_str:
        work_types = [wt.strip() for wt in work_type_str.split(",")]
        if len(work_types) == 1:
            work_type_filter = f"AND INTAKESOURCESYSTEM = '{work_types[0]}'"
        else:
            work_types_sql = ", ".join([f"'{wt}'" for wt in work_types])
            work_type_filter = f"AND INTAKESOURCESYSTEM IN ({work_types_sql})"
    non_flip_work_type_filter = build_change_tracking_work_type_filter(work_type_str)
    lob_filter = build_change_tracking_lob_filter(lob_str)
    
    logger.info(f"[METRIC_CALC] Work type filter: {non_flip_work_type_filter}")
    logger.info(f"[METRIC_CALC] LOB filter: {lob_filter}")
    logger.info(f"[METRIC_CALC] Date range: {tracking_start_month} (90 days before)")
    
    # Build queries for each selected metric
    queries = []
    query_metrics = []
    
    for kpi in kpi_metrics:
        column_name = metric_mapping.get(kpi)
        if not column_name:
            continue
            
        if kpi == "Cycle Time":
            # Calculate 90-day average Cycle Time BEFORE tracking start date
            query = f"""
            WITH invntry_deduped AS (
                SELECT 
                    PYID,
                    CYCLE_TIME,
                    INTAKESOURCESYSTEM,
                    ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  AND PYRESOLVEDTIMESTAMP >= DATEADD(day, -90, '{tracking_start_month}'::DATE)
                  AND PYRESOLVEDTIMESTAMP < '{tracking_start_month}'::DATE
                  {non_flip_work_type_filter}
                  {lob_filter}
                  AND CYCLE_TIME IS NOT NULL
            )
            SELECT 
                COUNT(DISTINCT PYID) AS TOTAL_RESOLVED_ITEMS,
                ROUND(AVG(CYCLE_TIME), 2) AS AVG_CYCLE_TIME_SECONDS,
                ROUND(AVG(CYCLE_TIME) / 60, 2) AS AVG_CYCLE_TIME_MINUTES
            FROM invntry_deduped
            WHERE rn = 1
            """
            
            logger.info(f"[METRIC_CALC] Cycle Time SQL:\n{query}")
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append(("CYCLE_TIME", "Cycle Time"))
                
        elif kpi == "Audit Score %":
                # Calculate 90-day average Audit Score % BEFORE tracking start date
                query = f"""
                WITH invntry_deduped AS (
                    SELECT 
                        PYID,
                        PYRESOLVEDTIMESTAMP,
                        INTAKESOURCESYSTEM,
                        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
                    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
                      AND PYRESOLVEDTIMESTAMP IS NOT NULL
                      AND PYRESOLVEDTIMESTAMP >= DATEADD(day, -90, '{tracking_start_month}'::DATE)
                      AND PYRESOLVEDTIMESTAMP < '{tracking_start_month}'::DATE
                      {non_flip_work_type_filter}
                      {lob_filter}
                ),
                audit_deduped AS (
                    SELECT 
                        PYID,
                        CASE_TO_AUDIT,
                        AUDIT_SUBJECT_ID,
                        AUDIT_SCORE,
                        TARGET_AUDIT,
                        ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
                    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
                    WHERE AUDIT_SCORE IS NOT NULL
                      AND PYID LIKE 'AUD%'
                      AND PYSTATUSWORK IN ('Open-FeedbackReview', 'Open-RebuttalReview', 'Open-UpdateAuditCase', 'Resolved-Completed')
                      {lob_filter}
                )
                SELECT 
                    AVG(CAST(a.AUDIT_SCORE AS FLOAT)) as AUDIT_SCORE_AVG,
                    COUNT(DISTINCT a.PYID) as TOTAL_AUDITS,
                    COUNT(DISTINCT i.PYID) as TOTAL_WORK_ITEMS,
                    MIN(i.PYRESOLVEDTIMESTAMP) as EARLIEST_WORK_ITEM,
                    MAX(i.PYRESOLVEDTIMESTAMP) as LATEST_WORK_ITEM,
                    SUM(CASE WHEN UPPER(a.TARGET_AUDIT) = 'YES' THEN 1 ELSE 0 END) as TARGET_AUDIT_COUNT
                FROM invntry_deduped i
                INNER JOIN audit_deduped a
                    ON i.PYID = a.CASE_TO_AUDIT
                    AND a.rn = 1
                WHERE i.rn = 1
                """
                
                queries.append(engine.execute_query_async(query, limit=1))
                query_metrics.append(("AUDIT_SCORE_PCT", "Audit Score %"))
                    
        elif kpi in ("Flip Rate Manual", "Flip Rate Touchless"):
            resolved_status = "Resolved-Completed" if kpi == "Flip Rate Manual" else "Resolved-Touchless"
            column_alias = metric_mapping[kpi]
            flip_cases_alias = "FLIP_CASES_MANUAL" if kpi == "Flip Rate Manual" else "FLIP_CASES_TOUCHLESS"
            total_cases_alias = "TOTAL_MANUAL_CASES" if kpi == "Flip Rate Manual" else "TOTAL_TOUCHLESS_CASES"
            date_predicates = f"""
                  AND PYRESOLVEDTIMESTAMP >= DATEADD(day, -90, '{tracking_start_month}'::DATE)
                  AND PYRESOLVEDTIMESTAMP < '{tracking_start_month}'::DATE"""
            query = build_flip_rate_metric_query(
                date_predicates=date_predicates,
                work_type_filter=work_type_filter,
                resolved_status=resolved_status,
                rate_alias=column_alias,
                flip_cases_alias=flip_cases_alias,
                total_cases_alias=total_cases_alias
            )
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append((column_alias, kpi))
                
        elif kpi == "Non-Value Add %":
            # Calculate 90-day average Non-Value Add % BEFORE tracking start date
            query = f"""
            WITH invntry_deduped AS (
                SELECT 
                    PYID,
                    ACTIONDECISION,
                    INTAKESOURCESYSTEM,
                    ROW_NUMBER() OVER (
                        PARTITION BY PYID 
                        ORDER BY PXUPDATEDATETIME DESC
                    ) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  AND PYRESOLVEDTIMESTAMP >= DATEADD(day, -90, '{tracking_start_month}'::DATE)
                  AND PYRESOLVEDTIMESTAMP < '{tracking_start_month}'::DATE
                  {non_flip_work_type_filter}
                  {lob_filter}
                  AND ACTIONDECISION IS NOT NULL
            )
            SELECT 
                COUNT(DISTINCT CASE 
                    WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
                    THEN PYID 
                END) AS NON_VALUE_ADD_COUNT,
                COUNT(DISTINCT PYID) AS TOTAL_CLOSED,
                ROUND(
                    COUNT(DISTINCT CASE 
                        WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
                        THEN PYID 
                    END) * 100.0 / NULLIF(COUNT(DISTINCT PYID), 0), 
                    2
                ) AS NON_VALUE_ADD_PCT
            FROM invntry_deduped
            WHERE rn = 1
            """
            
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append(("NON_VALUE_ADD_PCT", "Non-Value Add %"))
                
        elif kpi == "Lead Accuracy":
            # Calculate 90-day average Lead Accuracy % BEFORE tracking start date
            query = f"""
            WITH invntry_deduped AS (
                SELECT 
                    PYID,
                    LEADACCURACY,
                    INTAKESOURCESYSTEM,
                    PYRESOLVEDTIMESTAMP,
                    ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK = 'Resolved-Completed'
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  AND PYRESOLVEDTIMESTAMP >= DATEADD(day, -90, '{tracking_start_month}'::DATE)
                  AND PYRESOLVEDTIMESTAMP < '{tracking_start_month}'::DATE
                  {non_flip_work_type_filter}
                  {lob_filter}
                  AND LEADACCURACY IS NOT NULL
            )
            SELECT 
                COUNT(DISTINCT PYID) AS TOTAL_COMPLETED_CASES,
                SUM(CASE 
                    WHEN UPPER(LEADACCURACY) IN ('COB LEAD 100% ACCURATE', 'COB LEAD ACCURATE BUT REQUIRED CHANGES') 
                    THEN 1 ELSE 0 
                END) AS ACCURATE_LEADS,
                SUM(CASE 
                    WHEN UPPER(LEADACCURACY) = 'COB LEAD INACCURATE' 
                    THEN 1 ELSE 0 
                END) AS INACCURATE_LEADS,
                ROUND(
                    (SUM(CASE 
                        WHEN UPPER(LEADACCURACY) IN ('COB LEAD 100% ACCURATE', 'COB LEAD ACCURATE BUT REQUIRED CHANGES') 
                        THEN 1 ELSE 0 
                    END) * 100.0) / NULLIF(COUNT(DISTINCT PYID), 0),
                    2
                ) AS LEAD_ACCURACY_PCT
            FROM invntry_deduped
            WHERE rn = 1
            """
            
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append(("LEAD_ACCURACY", "Lead Accuracy"))
    
    # Execute all queries in parallel using asyncio.gather
    if queries:
        try:
            logger.info(f"[METRIC_CALC] Executing {len(queries)} metric queries in parallel: {[m[1] for m in query_metrics]}")
            results = await asyncio.gather(*queries, return_exceptions=True)
            
            # Process results
            for idx, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error(f"[METRIC_CALC] {query_metrics[idx][1]} calculation failed: {str(result)}")
                    continue
                    
                column_name, metric_name = query_metrics[idx]
                
                if metric_name == "Cycle Time":
                    if result and result[0].get("AVG_CYCLE_TIME_MINUTES") is not None:
                        avg_cycle_time_minutes = float(result[0]["AVG_CYCLE_TIME_MINUTES"])
                        total_items = int(result[0]["TOTAL_RESOLVED_ITEMS"]) if result[0].get("TOTAL_RESOLVED_ITEMS") else 0
                        
                        metric_values[column_name] = round(avg_cycle_time_minutes, 2)
                        logger.info(
                            f"[METRIC_CALC] {metric_name}: {avg_cycle_time_minutes:.2f} minutes "
                            f"(based on {total_items} work items in 90 days before {tracking_start_month})"
                        )
                    else:
                        logger.warning(f"[METRIC_CALC] No data found for {metric_name}")
                        metric_values[column_name] = None
                
                elif metric_name == "Audit Score %":
                    if result and result[0].get("AUDIT_SCORE_AVG") is not None:
                        audit_score_avg = float(result[0]["AUDIT_SCORE_AVG"])
                        total_audits = int(result[0]["TOTAL_AUDITS"]) if result[0].get("TOTAL_AUDITS") else 0
                        total_work_items = int(result[0]["TOTAL_WORK_ITEMS"]) if result[0].get("TOTAL_WORK_ITEMS") else 0
                        target_audit_count = int(result[0]["TARGET_AUDIT_COUNT"]) if result[0].get("TARGET_AUDIT_COUNT") else 0
                        
                        metric_values[column_name] = round(audit_score_avg, 2)
                        logger.info(
                            f"[METRIC_CALC] {metric_name}: {audit_score_avg:.2f}% "
                            f"({total_audits} audits / {total_work_items} work items / "
                            f"{target_audit_count} targeted in 90 days before {tracking_start_month})"
                        )
                    else:
                        logger.warning(f"[METRIC_CALC] No data found for {metric_name}")
                        metric_values[column_name] = None
                
                elif metric_name in ("Flip Rate Manual", "Flip Rate Touchless"):
                    if result and result[0].get(column_name) is not None:
                        flip_rate_value = float(result[0][column_name])
                        flip_cases_key = "FLIP_CASES_MANUAL" if metric_name == "Flip Rate Manual" else "FLIP_CASES_TOUCHLESS"
                        total_cases_key = "TOTAL_MANUAL_CASES" if metric_name == "Flip Rate Manual" else "TOTAL_TOUCHLESS_CASES"
                        flip_cases = int(result[0][flip_cases_key]) if result[0].get(flip_cases_key) else 0
                        total_cases = int(result[0][total_cases_key]) if result[0].get(total_cases_key) else 0
                        
                        metric_values[column_name] = round(flip_rate_value, 2)
                        logger.info(
                            f"[METRIC_CALC] {metric_name}: {flip_rate_value:.2f}% "
                            f"({flip_cases} flip cases / {total_cases} total cases in 90 days before {tracking_start_month})"
                        )
                    else:
                        logger.warning(f"[METRIC_CALC] No data found for {metric_name}")
                        metric_values[column_name] = None
                
                elif metric_name == "Non-Value Add %":
                    if result and result[0].get("NON_VALUE_ADD_PCT") is not None:
                        non_value_add_pct = float(result[0]["NON_VALUE_ADD_PCT"])
                        non_value_add_count = int(result[0]["NON_VALUE_ADD_COUNT"]) if result[0].get("NON_VALUE_ADD_COUNT") else 0
                        total_closed = int(result[0]["TOTAL_CLOSED"]) if result[0].get("TOTAL_CLOSED") else 0
                        
                        metric_values[column_name] = round(non_value_add_pct, 2)
                        logger.info(
                            f"[METRIC_CALC] {metric_name}: {non_value_add_pct:.2f}% "
                            f"({non_value_add_count} no-update cases / {total_closed} total closed "
                            f"in 90 days before {tracking_start_month})"
                        )
                    else:
                        logger.warning(f"[METRIC_CALC] No data found for {metric_name}")
                        metric_values[column_name] = None
                
                elif metric_name == "Lead Accuracy":
                    if result and result[0].get("LEAD_ACCURACY_PCT") is not None:
                        lead_accuracy_pct = float(result[0]["LEAD_ACCURACY_PCT"])
                        total_cases = int(result[0]["TOTAL_COMPLETED_CASES"]) if result[0].get("TOTAL_COMPLETED_CASES") else 0
                        accurate_leads = int(result[0]["ACCURATE_LEADS"]) if result[0].get("ACCURATE_LEADS") else 0
                        inaccurate_leads = int(result[0]["INACCURATE_LEADS"]) if result[0].get("INACCURATE_LEADS") else 0
                        
                        metric_values[column_name] = round(lead_accuracy_pct, 2)
                        logger.info(
                            f"[METRIC_CALC] {metric_name}: {lead_accuracy_pct:.2f}% "
                            f"({accurate_leads} accurate / {inaccurate_leads} inaccurate / "
                            f"{total_cases} total cases in 90 days before {tracking_start_month})"
                        )
                    else:
                        logger.warning(f"[METRIC_CALC] No data found for {metric_name}")
                        metric_values[column_name] = None
                        
        except Exception as e:
            logger.error(f"[METRIC_CALC] Parallel execution failed: {str(e)}")
    
    return metric_values


@router.post(
    "/add",
    response_model=ChangeTrackingAddResponse,
    summary="Add Change Tracking Data",
    description="Inserts a new record into COB_AI_CHANGE_TRACKING table with calculated KPI metrics"
)
async def add_change_tracking_data(request: ChangeTrackingAddRequest):
    """Inserts new change tracking data into database with calculated metric values"""
    try:
        logger.info(f"[CHANGE_TRACKING_ADD] User ID: {request.created_by}, Initiative: {request.initiative_name}")
        
        # Convert list fields to comma-separated strings
        savings_type_str = ", ".join(request.savings_type) if request.savings_type else ""
        work_type_str = ", ".join(request.work_type) if request.work_type else ""
        kpi_metric_str = ", ".join(request.kpi_metric) if request.kpi_metric else ""
        lob_str = ", ".join(request.lob) if request.lob else ""
        
        # Get database engine
        engine = connection_manager.get_engine()
        
        # Calculate metric values based on selected KPIs
        logger.info(f"[CHANGE_TRACKING_ADD] Calculating metrics for KPIs: {request.kpi_metric}")
        metric_values = await calculate_metric_values(
            engine, 
            request.kpi_metric, 
            lob_str, 
            work_type_str, 
            request.tracking_start_month
        )
        
        # Build metric columns and values using common helper
        metric_columns, metric_vals = await build_metric_update_fields(
            metric_values,
            selected_kpis=request.kpi_metric,
            include_unselected=False
        )
        
        # Build INSERT query with metric columns
        columns = "INITIATIVE_NAME, INITIATIVE_YEAR, SAVINGS_TYPE, WORK_TYPE, KPI_METRIC, LOB, TOTAL_ESTIMATED_VALUE, TRACKING_START_DATE, CHANGE_DESCRIPTION, STATUS, CREATED_BY"
        values = f"'{request.initiative_name}', '{request.initiative_year}', '{savings_type_str}', '{work_type_str}', '{kpi_metric_str}', '{lob_str}', '{request.total_estimated_value}', '{request.tracking_start_month}', '{request.change_description}', '{request.status.upper()}', '{request.created_by}'"
        
        if metric_columns:
            columns += ", " + ", ".join(metric_columns)
            values += ", " + ", ".join(metric_vals)
        
        query = f"""
        INSERT INTO {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
        ({columns})
        VALUES
        ({values})
        """
        
        # Execute query
        await engine.execute_query_async(query)
        
        logger.info(f"[CHANGE_TRACKING_ADD] Successfully inserted initiative: {request.initiative_name} with metrics: {metric_values}")
        
        return ChangeTrackingAddResponse(
            status="success",
            message=f"Change tracking data added successfully with calculated metrics: {', '.join([k for k, v in metric_values.items() if v is not None])}",
            service="idiscovery-cob-dashboard-service"
        )
    except Exception as e:
        logger.error(f"Change tracking add error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to add change tracking data: {str(e)}")

@router.post(
    "/edit",
    response_model=ChangeTrackingEditResponse,
    summary="Get Change Tracking Initiative Detail",
    description="Fetches a single change tracking initiative by initiative_id for edit form prefill"
)
async def get_change_tracking_detail(request: ChangeTrackingEditRequest):
    """Fetch a single change tracking initiative by initiative ID."""
    try:
        logger.info(f"[CHANGE_TRACKING_DETAIL] User ID: {request.user_id}, Initiative ID: {request.initiative_id}")

        query = f"""
        SELECT INITIATIVE_ID, INITIATIVE_NAME, INITIATIVE_YEAR, SAVINGS_TYPE, WORK_TYPE, KPI_METRIC, LOB,
               TOTAL_ESTIMATED_VALUE, TRACKING_START_DATE, CHANGE_DESCRIPTION, STATUS,
               CREATED_BY, CREATED_TS, UPDATED_BY, UPDATED_TS
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
        WHERE INITIATIVE_ID = {request.initiative_id}
        """

        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1)

        data = [dict(row) for row in results] if results else []
        if not data:
            raise HTTPException(status_code=404, detail=f"Initiative not found for initiative_id={request.initiative_id}")

        record = data[0]
        
        # Build ChangeTrackingEditData object
        edit_data = ChangeTrackingEditData(
            initiative_id=record.get("INITIATIVE_ID"),
            initiative_name=record.get("INITIATIVE_NAME"),
            initiative_year=str(record.get("INITIATIVE_YEAR") or ""),
            savings_type=[item.strip() for item in str(record.get("SAVINGS_TYPE") or "").split(",") if item.strip()],
            work_type=[item.strip() for item in str(record.get("WORK_TYPE") or "").split(",") if item.strip()],
            kpi_metric=[item.strip() for item in str(record.get("KPI_METRIC") or "").split(",") if item.strip()],
            lob=[item.strip() for item in str(record.get("LOB") or "").split(",") if item.strip()],
            total_estimated_value=record.get("TOTAL_ESTIMATED_VALUE"),
            tracking_start_month=str(record.get("TRACKING_START_DATE") or ""),
            change_description=record.get("CHANGE_DESCRIPTION"),
            status=record.get("STATUS"),
            created_by=record.get("CREATED_BY"),
            created_ts=str(record.get("CREATED_TS") or ""),
            updated_by=record.get("UPDATED_BY"),
            updated_ts=str(record.get("UPDATED_TS") or "")
        )

        return ChangeTrackingEditResponse(
            status="success",
            data=edit_data,
            message="Change tracking initiative retrieved successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Change tracking detail error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve change tracking initiative: {str(e)}")


@router.post(
    "/update",
    response_model=ChangeTrackingUpdateResponse,
    summary="Update Change Tracking Initiative",
    description="Updates a change tracking initiative and recalculates metrics if KPI/Work Type/Date changed"
)
async def update_change_tracking_initiative(request: ChangeTrackingUpdateRequest):
    """
    Update a change tracking initiative.
    
    Recalculates metrics if:
    - KPI metrics changed or added
    - Work type changed
    - Tracking start month changed
    
    Directly updates without recalculation:
    - Initiative name, year, savings type, LOB, description, total estimated value
    """
    try:
        logger.info(f"[CHANGE_TRACKING_UPDATE] User: {request.user_id}, Initiative ID: {request.initiative_id}")
        logger.info(f"[UPDATE] Request payload - work_type: {request.work_type}, kpi_metric: {request.kpi_metric}, tracking_start_month: {request.tracking_start_month}")
        
        engine = connection_manager.get_engine()
        
        # Step 1: Fetch existing record
        fetch_query = f"""
        SELECT INITIATIVE_ID, INITIATIVE_NAME, INITIATIVE_YEAR, SAVINGS_TYPE, WORK_TYPE, KPI_METRIC, LOB,
               TOTAL_ESTIMATED_VALUE, TRACKING_START_DATE, CHANGE_DESCRIPTION, STATUS,
               CYCLE_TIME, AUDIT_SCORE_PCT, FLIP_RATE_MANUAL, FLIP_RATE_TOUCHLESS, NON_VALUE_ADD_PCT, LEAD_ACCURACY
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
        WHERE INITIATIVE_ID = {request.initiative_id}
        """
        
        existing_data = await engine.execute_query_async(fetch_query, limit=1)
        if not existing_data:
            raise HTTPException(status_code=404, detail=f"Initiative ID {request.initiative_id} not found")
        
        existing = existing_data[0]
        
        logger.info(f"[UPDATE] Existing record from DB: WORK_TYPE={existing.get('WORK_TYPE')}, KPI_METRIC={existing.get('KPI_METRIC')}, TRACKING_START_DATE={existing.get('TRACKING_START_DATE')}")
        
        # Step 2: Determine if recalculation is needed
        needs_recalculation = False
        recalc_reason = []
        
        # Check KPI metrics change
        existing_kpis = set([k.strip() for k in str(existing.get("KPI_METRIC") or "").split(",") if k.strip()])
        new_kpis = set(request.kpi_metric)
        if existing_kpis != new_kpis:
            needs_recalculation = True
            recalc_reason.append("KPI metrics changed")
            logger.info(f"[UPDATE] KPI changed: {existing_kpis} -> {new_kpis}")
        
        # Check work type change
        existing_work_types = set([w.strip() for w in str(existing.get("WORK_TYPE") or "").split(",") if w.strip()])
        new_work_types = set(request.work_type)
        
        logger.info(f"[UPDATE] Work type comparison - Existing: {existing_work_types} vs New: {new_work_types}")
        
        if existing_work_types != new_work_types:
            needs_recalculation = True
            recalc_reason.append("Work type changed")
            logger.info(f"[UPDATE] Work type changed: {existing_work_types} -> {new_work_types}")
        
        # Check tracking start month change
        existing_date_raw = existing.get("TRACKING_START_DATE")
        logger.info(f"[UPDATE] Raw date from DB: {existing_date_raw} (type: {type(existing_date_raw)})")
        
        # Convert to string and extract date part only (YYYY-MM-DD)
        if existing_date_raw:
            existing_date_str = str(existing_date_raw)
            # Handle datetime objects or strings with timestamps
            if ' ' in existing_date_str:
                existing_date = existing_date_str.split()[0]
            elif 'T' in existing_date_str:
                existing_date = existing_date_str.split('T')[0]
            else:
                existing_date = existing_date_str
        else:
            existing_date = ""
        
        logger.info(f"[UPDATE] Date comparison - Existing: '{existing_date}' vs New: '{request.tracking_start_month}'")
        
        if existing_date != request.tracking_start_month:
            needs_recalculation = True
            recalc_reason.append("Tracking start date changed")
            logger.info(f"[UPDATE] ✅ Tracking date changed: {existing_date} -> {request.tracking_start_month}")
        else:
            logger.info(f"[UPDATE] ❌ Tracking date NOT changed (same value)")
        
        # Step 3: Build update values (all fields are required, so always update)
        update_fields = [
            "INITIATIVE_NAME",
            "INITIATIVE_YEAR", 
            "SAVINGS_TYPE",
            "WORK_TYPE",
            "KPI_METRIC",
            "LOB",
            "TOTAL_ESTIMATED_VALUE",
            "TRACKING_START_DATE",
            "CHANGE_DESCRIPTION"
        ]
        
        update_values = [
            f"'{request.initiative_name}'",
            f"'{request.initiative_year}'",
            f"'{', '.join(request.savings_type)}'",
            f"'{', '.join(request.work_type)}'",
            f"'{', '.join(request.kpi_metric)}'",
            f"'{', '.join(request.lob)}'",
            str(request.total_estimated_value),
            f"'{request.tracking_start_month}'",
            f"'{request.change_description}'"
        ]

        clear_metric_fields, clear_metric_values = build_unselected_metric_clear_fields(request.kpi_metric)
        update_fields.extend(clear_metric_fields)
        update_values.extend(clear_metric_values)
        
        # Step 4: Recalculate metrics if needed
        if needs_recalculation:
            logger.info(f"[UPDATE] 🔄 RECALCULATING METRICS. Reasons: {', '.join(recalc_reason)}")
            logger.info(f"[UPDATE] Recalculation params - KPIs: {request.kpi_metric}, Work Types: {request.work_type}, LOB: {request.lob}, Date: {request.tracking_start_month}")
            
            # Use request values directly (all fields are required now)
            lob_str = ", ".join(request.lob)
            work_type_str = ", ".join(request.work_type)
            
            before_metrics = await calculate_metric_values(
                engine=engine,
                kpi_metrics=request.kpi_metric,
                lob_str=lob_str,
                work_type_str=work_type_str,
                tracking_start_month=request.tracking_start_month
            )
            
            logger.info(f"[UPDATE] Calculated metrics: {before_metrics}")
            
            # Add metric fields to update using common helper
            metric_fields, metric_vals = await build_metric_update_fields(
                before_metrics,
                selected_kpis=request.kpi_metric,
                include_unselected=False
            )
            update_fields.extend(metric_fields)
            update_values.extend(metric_vals)
            
            logger.info(f"[UPDATE] Added {len(metric_fields)} metric fields to update: {metric_fields}")
        else:
            logger.info(f"[UPDATE] ⏭️ SKIPPING recalculation - no changes detected in KPI/Work Type/Date")
        
        # Always update timestamp and user
        update_fields.append("UPDATED_BY")
        update_values.append(f"'{request.user_id or 'SYSTEM'}'")
        update_fields.append("UPDATED_TS")
        update_values.append("CURRENT_TIMESTAMP()")
        
        # Step 5: Execute UPDATE query
        if update_fields:
            set_clause = ", ".join([f"{field} = {value}" for field, value in zip(update_fields, update_values)])
            update_query = f"""
            UPDATE {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
            SET {set_clause}
            WHERE INITIATIVE_ID = {request.initiative_id}
            """
            
            logger.info(f"[UPDATE] ========== EXECUTING UPDATE ==========")
            logger.info(f"[UPDATE] Initiative ID: {request.initiative_id}")
            logger.info(f"[UPDATE] Total fields to update: {len(update_fields)}")
            logger.info(f"[UPDATE] Update fields: {update_fields}")
            logger.info(f"[UPDATE] Update values: {update_values}")
            logger.info(f"[UPDATE] Full SQL Query:\n{update_query}")
            logger.info(f"[UPDATE] =========================================")
            
            result = await engine.execute_query_async(update_query)
            logger.info(f"[UPDATE] Query executed. Result: {result}")
            
            # Verify the update
            verify_query = f"""
            SELECT INITIATIVE_ID, INITIATIVE_NAME, WORK_TYPE, KPI_METRIC, TRACKING_START_DATE, 
                   CYCLE_TIME, AUDIT_SCORE_PCT, FLIP_RATE_MANUAL, FLIP_RATE_TOUCHLESS, NON_VALUE_ADD_PCT, LEAD_ACCURACY, UPDATED_BY, UPDATED_TS
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
            WHERE INITIATIVE_ID = {request.initiative_id}
            """
            verify_result = await engine.execute_query_async(verify_query, limit=1)
            if verify_result:
                logger.info(f"[UPDATE] Verification - Updated record: {dict(verify_result[0])}")
            else:
                logger.warning(f"[UPDATE] Verification failed - No record found for initiative_id={request.initiative_id}")
        
        message = "Change tracking initiative updated successfully"
        if needs_recalculation:
            message += f". Metrics recalculated due to: {', '.join(recalc_reason)}"
        
        logger.info(f"[UPDATE] Success: {message}")
        
        return ChangeTrackingUpdateResponse(
            status="success",
            initiative_id=request.initiative_id,
            recalculated_metrics=needs_recalculation,
            message=message
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[CHANGE_TRACKING_UPDATE] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to update change tracking initiative: {str(e)}")


@router.post(
    "/manage",
    response_model=ChangeTrackingManageResponse,
    summary="Manage Change Tracking Status",
    description="Set initiative status to ACTIVE, ARCHIVE, or DELETE based on initiative_id"
)
async def manage_change_tracking_data(request: ChangeTrackingManageRequest):
    """
    Manage change tracking initiative status based on initiative_id.
    
    Actions:
    - active: Set status to ACTIVE
    - archive: Set status to ARCHIVE
    - delete: Permanently delete the record from database
    """
    try:
        action = request.action.lower()
        logger.info(f"[CHANGE_TRACKING_MANAGE] Action: {action}, User: {request.user_id}, Initiative ID: {request.initiative_id}")
        
        if not request.initiative_id:
            raise HTTPException(status_code=400, detail="initiative_id is required")
        
        engine = connection_manager.get_engine()
        
        # Check if initiative exists
        check_query = f"""
        SELECT INITIATIVE_ID, STATUS 
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
        WHERE INITIATIVE_ID = {request.initiative_id}
        """
        result = await engine.execute_query_async(check_query, limit=1)
        if not result:
            raise HTTPException(status_code=404, detail=f"Initiative ID {request.initiative_id} not found")
        
        current_status = result[0].get("STATUS", "")
        
        # ========================================================================
         # ========================================================================
        if action == "active":
            if current_status == "ACTIVE":
                return ChangeTrackingManageResponse(
                    status="success",
                    message=f"Initiative ID {request.initiative_id} is already active",
                    initiative_id=request.initiative_id,
                    action="active"
                )
            
            query = f"""
            UPDATE {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
            SET 
                STATUS = 'ACTIVE',
                UPDATED_BY = '{request.user_id}',
                UPDATED_TS = CURRENT_TIMESTAMP()
            WHERE INITIATIVE_ID = {request.initiative_id}
            """
            
            await engine.execute_query_async(query)
            
            logger.info(f"[CHANGE_TRACKING_MANAGE] Set initiative ID {request.initiative_id} to ACTIVE")
            
            return ChangeTrackingManageResponse(
                status="success",
                message=f"Initiative ID {request.initiative_id} set to ACTIVE successfully",
                initiative_id=request.initiative_id,
                action="active"
            )
        
        # ========================================================================
        # ARCHIVE ACTION - Set status to ARCHIVE
        # ========================================================================
        elif action == "archive":
            if current_status == "ARCHIVE":
                return ChangeTrackingManageResponse(
                    status="success",
                    message=f"Initiative ID {request.initiative_id} is already archived",
                    initiative_id=request.initiative_id,
                    action="archive"
                )
            
            query = f"""
            UPDATE {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
            SET 
                STATUS = 'ARCHIVE',
                UPDATED_BY = '{request.user_id}',
                UPDATED_TS = CURRENT_TIMESTAMP()
            WHERE INITIATIVE_ID = {request.initiative_id}
            """
            
            await engine.execute_query_async(query)
            
            logger.info(f"[CHANGE_TRACKING_MANAGE] Set initiative ID {request.initiative_id} to ARCHIVE")
            
            return ChangeTrackingManageResponse(
                status="success",
                message=f"Initiative ID {request.initiative_id} archived successfully",
                initiative_id=request.initiative_id,
                action="archive"
            )
        
        # ========================================================================
        # DELETE ACTION - Permanently delete from database
        # ========================================================================
        elif action == "delete":
            query = f"""
            DELETE FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
            WHERE INITIATIVE_ID = {request.initiative_id}
            """
            
            await engine.execute_query_async(query)
            
            logger.info(f"[CHANGE_TRACKING_MANAGE] Deleted initiative ID {request.initiative_id}")
            
            return ChangeTrackingManageResponse(
                status="success",
                message=f"Initiative ID {request.initiative_id} deleted successfully",
                initiative_id=request.initiative_id,
                action="delete"
            )
        
        # ========================================================================
        # INVALID ACTION
        # ========================================================================
        else:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid action '{action}'. Allowed actions: active, archive, delete"
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[CHANGE_TRACKING_MANAGE] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to manage change tracking data: {str(e)}")
@router.post(
    "/metrics-detail",
    response_model=ChangeTrackingMetricsDetailResponse,
    summary="Get Change Tracking Metrics Detail (Before/After)",
    description="Fetches Before and After metric values for a specific initiative. Before = 90 days before tracking start date. After = tracking start date to current date."
)
async def get_change_tracking_metrics_detail(request: ChangeTrackingMetricsDetailRequest):
    """Fetches Before and After metric values for a specific change tracking initiative"""
    try:
        logger.info(f"[CHANGE_TRACKING_METRICS_DETAIL] User ID: {request.user_id}, Initiative ID: {request.initiative_id}")
        
        engine = connection_manager.get_engine()
        
        # Fetch initiative details from database
        query = f"""
        SELECT 
            INITIATIVE_ID,
            INITIATIVE_NAME,
            WORK_TYPE,
            LOB,
            KPI_METRIC,
            TRACKING_START_DATE,
            CYCLE_TIME,
            AUDIT_SCORE_PCT,
            FLIP_RATE_MANUAL,
            FLIP_RATE_TOUCHLESS,
            NON_VALUE_ADD_PCT,
            LEAD_ACCURACY
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_CHANGE_TRACKING
        WHERE INITIATIVE_ID = {request.initiative_id}
        """
        
        result = await engine.execute_query_async(query, limit=1)
        
        if not result:
            raise HTTPException(status_code=404, detail=f"Initiative ID {request.initiative_id} not found")
        
        initiative = result[0]
        initiative_name = initiative.get("INITIATIVE_NAME", "")
        tracking_start_date = str(initiative.get("TRACKING_START_DATE", ""))
        work_type_str = initiative.get("WORK_TYPE", "")
        lob_str = initiative.get("LOB", "")
        kpi_metric_str = initiative.get("KPI_METRIC", "")
        
        # Parse comma-separated values
        work_types = [wt.strip() for wt in work_type_str.split(",")] if work_type_str else []
        lobs = [lob.strip() for lob in lob_str.split(",")] if lob_str else []
        kpi_metrics = [kpi.strip() for kpi in kpi_metric_str.split(",")] if kpi_metric_str else []
        
        # Get "Before" values from database (already calculated and stored)
        before_values = {
            "Cycle Time": initiative.get("CYCLE_TIME"),
            "Audit Score %": initiative.get("AUDIT_SCORE_PCT"),
            "Flip Rate Manual": initiative.get("FLIP_RATE_MANUAL"),
            "Flip Rate Touchless": initiative.get("FLIP_RATE_TOUCHLESS"),
            "Non-Value Add %": initiative.get("NON_VALUE_ADD_PCT"),
            "Lead Accuracy": initiative.get("LEAD_ACCURACY")
        }
        
        # Calculate "After" values (from tracking start date to current date)
        logger.info(f"[CHANGE_TRACKING_METRICS_DETAIL] Calculating After metrics for {len(kpi_metrics)} KPIs")
        after_values = await calculate_after_metric_values(engine, kpi_metrics, lob_str, work_type_str, tracking_start_date)
        
        # Build metrics list with Before/After values and improvement rate
        metrics = []
        unit_mapping = {
            "Cycle Time": "minutes",
            "Audit Score %": "%",
            "Flip Rate Manual": "%",
            "Flip Rate Touchless": "%",
            "Non-Value Add %": "%",
            "Lead Accuracy": "%"
        }
        
        # Define which metrics are "higher is better" vs "lower is better"
        higher_is_better = {"Audit Score %", "Lead Accuracy"}
        lower_is_better = {"Cycle Time", "Non-Value Add %", "Flip Rate Manual", "Flip Rate Touchless"}
        
        for kpi in kpi_metrics:
            before_val = before_values.get(kpi)
            after_val = after_values.get(kpi)
            
            # Convert to float if not None (database may return strings)
            if before_val is not None and str(before_val).strip().upper() != "NA":
                before_val = float(before_val)
            else:
                before_val = None
            if after_val is not None and str(after_val).strip().upper() != "NA":
                after_val = float(after_val)
            else:
                after_val = None
            
            # Calculate improvement rate based on metric type
            improvement_rate = None
            if before_val is not None and after_val is not None and before_val != 0:
                if kpi in higher_is_better:
                    # For metrics where higher is better: ((After - Before) / Before) × 100
                    improvement_rate = round(((after_val - before_val) / before_val) * 100, 2)
                else:
                    # For metrics where lower is better: ((Before - After) / Before) × 100
                    improvement_rate = round(((before_val - after_val) / before_val) * 100, 2)
            
            metrics.append(MetricDetail(
                kpi_name=kpi,
                before_value=before_val,
                after_value=after_val,
                improvement_rate=improvement_rate,
                unit=unit_mapping.get(kpi, "")
            ))
        
        return ChangeTrackingMetricsDetailResponse(
            status="success",
            initiative_id=request.initiative_id,
            initiative_name=initiative_name,
            tracking_start_date=tracking_start_date,
            work_type=work_types,
            lob=lobs,
            metrics=metrics,
            message="Metrics retrieved successfully"
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[CHANGE_TRACKING_METRICS_DETAIL] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve metrics detail: {str(e)}")


async def calculate_after_metric_values(engine, kpi_metrics: list, lob_str: str, work_type_str: str, tracking_start_date: str):
    """
    Calculate metric values AFTER the tracking start date (from tracking start to current date).
    Similar to calculate_metric_values but with different date range.
    """
    import asyncio
    from datetime import datetime
    
    metric_values = {
        "Cycle Time": None,
        "Audit Score %": None,
        "Flip Rate Manual": None,
        "Flip Rate Touchless": None,
        "Non-Value Add %": None,
        "Lead Accuracy": None
    }
    
    # Build work type filter
    work_type_filter = ""
    if work_type_str:
        work_types = [wt.strip() for wt in work_type_str.split(",")]
        if len(work_types) == 1:
            work_type_filter = f"AND INTAKESOURCESYSTEM = '{work_types[0]}'"
        else:
            work_types_sql = ", ".join([f"'{wt}'" for wt in work_types])
            work_type_filter = f"AND INTAKESOURCESYSTEM IN ({work_types_sql})"
    non_flip_work_type_filter = build_change_tracking_work_type_filter(work_type_str)
    lob_filter = build_change_tracking_lob_filter(lob_str)
    
    # Get current date
    current_date = datetime.now().strftime("%Y-%m-%d")
    
    # Build queries for each selected metric
    queries = []
    query_metrics = []
    
    for kpi in kpi_metrics:
        if kpi == "Cycle Time":
            query = f"""
            WITH invntry_deduped AS (
                SELECT 
                    PYID,
                    CYCLE_TIME,
                    ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  AND PYRESOLVEDTIMESTAMP >= '{tracking_start_date}'::DATE
                  AND PYRESOLVEDTIMESTAMP <= '{current_date}'::DATE
                  {non_flip_work_type_filter}
                  {lob_filter}
                  AND CYCLE_TIME IS NOT NULL
            )
            SELECT 
                ROUND(AVG(CYCLE_TIME) / 60, 2) AS AVG_CYCLE_TIME_MINUTES
            FROM invntry_deduped
            WHERE rn = 1
            """
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append("Cycle Time")
                
        elif kpi == "Audit Score %":
            query = f"""
            WITH invntry_deduped AS (
                SELECT 
                    PYID,
                    ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  AND PYRESOLVEDTIMESTAMP >= '{tracking_start_date}'::DATE
                  AND PYRESOLVEDTIMESTAMP <= '{current_date}'::DATE
                  {non_flip_work_type_filter}
                  {lob_filter}
            ),
            audit_deduped AS (
                SELECT 
                    PYID,
                    CASE_TO_AUDIT,
                    AUDIT_SCORE,
                    ROW_NUMBER() OVER (PARTITION BY CASE_TO_AUDIT, AUDIT_SUBJECT_ID ORDER BY PXUPDATEDATETIME DESC) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
                WHERE AUDIT_SCORE IS NOT NULL
                  AND PYID LIKE 'AUD%'
                  AND PYSTATUSWORK IN ('Open-FeedbackReview', 'Open-RebuttalReview', 'Open-UpdateAuditCase', 'Resolved-Completed')
                  {lob_filter}
            )
            SELECT 
                AVG(CAST(a.AUDIT_SCORE AS FLOAT)) as AUDIT_SCORE_AVG
            FROM invntry_deduped i
            INNER JOIN audit_deduped a ON i.PYID = a.CASE_TO_AUDIT AND a.rn = 1
            WHERE i.rn = 1
            """
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append("Audit Score %")
                    
        elif kpi in ("Flip Rate Manual", "Flip Rate Touchless"):
            resolved_status = "Resolved-Completed" if kpi == "Flip Rate Manual" else "Resolved-Touchless"
            rate_alias = "FLIP_RATE_MANUAL" if kpi == "Flip Rate Manual" else "FLIP_RATE_TOUCHLESS"
            flip_cases_alias = "FLIP_CASES_MANUAL" if kpi == "Flip Rate Manual" else "FLIP_CASES_TOUCHLESS"
            total_cases_alias = "TOTAL_MANUAL_CASES" if kpi == "Flip Rate Manual" else "TOTAL_TOUCHLESS_CASES"
            date_predicates = f"""
                  AND PYRESOLVEDTIMESTAMP >= '{tracking_start_date}'::DATE
                  AND PYRESOLVEDTIMESTAMP <= '{current_date}'::DATE"""
            query = build_flip_rate_metric_query(
                date_predicates=date_predicates,
                work_type_filter=work_type_filter,
                resolved_status=resolved_status,
                rate_alias=rate_alias,
                flip_cases_alias=flip_cases_alias,
                total_cases_alias=total_cases_alias
            )
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append(kpi)
                    
        elif kpi == "Non-Value Add %":
            # Calculate Non-Value Add % AFTER tracking start date (to current date)
            query = f"""
            WITH invntry_deduped AS (
                SELECT 
                    PYID,
                    ACTIONDECISION,
                    ROW_NUMBER() OVER (
                        PARTITION BY PYID 
                        ORDER BY PXUPDATEDATETIME DESC
                    ) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  AND PYRESOLVEDTIMESTAMP >= '{tracking_start_date}'::DATE
                  AND PYRESOLVEDTIMESTAMP <= '{current_date}'::DATE
                  {non_flip_work_type_filter}
                  {lob_filter}
                  AND ACTIONDECISION IS NOT NULL
            )
            SELECT 
                ROUND(
                    COUNT(DISTINCT CASE 
                        WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
                        THEN PYID 
                    END) * 100.0 / NULLIF(COUNT(DISTINCT PYID), 0), 
                    2
                ) AS NON_VALUE_ADD_PCT
            FROM invntry_deduped
            WHERE rn = 1
            """
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append("Non-Value Add %")
                    
        elif kpi == "Lead Accuracy":
            query = f"""
            WITH invntry_deduped AS (
                SELECT 
                    PYID,
                    LEADACCURACY,
                    ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
                FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
                WHERE PYSTATUSWORK = 'Resolved-Completed'
                  AND PYRESOLVEDTIMESTAMP IS NOT NULL
                  AND PYRESOLVEDTIMESTAMP >= '{tracking_start_date}'::DATE
                  AND PYRESOLVEDTIMESTAMP <= '{current_date}'::DATE
                  {non_flip_work_type_filter}
                  {lob_filter}
                  AND LEADACCURACY IS NOT NULL
            )
            SELECT 
                ROUND(
                    (SUM(CASE 
                        WHEN UPPER(LEADACCURACY) IN ('COB LEAD 100% ACCURATE', 'COB LEAD ACCURATE BUT REQUIRED CHANGES') 
                        THEN 1 ELSE 0 
                    END) * 100.0) / NULLIF(COUNT(DISTINCT PYID), 0),
                    2
                ) AS LEAD_ACCURACY_PCT
            FROM invntry_deduped
            WHERE rn = 1
            """
            queries.append(engine.execute_query_async(query, limit=1))
            query_metrics.append("Lead Accuracy")
    
    # Execute all queries in parallel
    if queries:
        try:
            logger.info(f"[AFTER_METRICS] Executing {len(queries)} queries in parallel from {tracking_start_date} to {current_date}")
            results = await asyncio.gather(*queries, return_exceptions=True)
            
            # Process results
            for idx, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error(f"[AFTER_METRICS] {query_metrics[idx]} calculation failed: {str(result)}")
                    continue
                    
                metric_name = query_metrics[idx]
                
                if metric_name == "Cycle Time" and result and result[0].get("AVG_CYCLE_TIME_MINUTES") is not None:
                    metric_values["Cycle Time"] = round(float(result[0]["AVG_CYCLE_TIME_MINUTES"]), 2)
                    
                elif metric_name == "Audit Score %" and result and result[0].get("AUDIT_SCORE_AVG") is not None:
                    metric_values["Audit Score %"] = round(float(result[0]["AUDIT_SCORE_AVG"]), 2)
                    
                elif metric_name == "Flip Rate Manual" and result and result[0].get("FLIP_RATE_MANUAL") is not None:
                    metric_values["Flip Rate Manual"] = round(float(result[0]["FLIP_RATE_MANUAL"]), 2)

                elif metric_name == "Flip Rate Touchless" and result and result[0].get("FLIP_RATE_TOUCHLESS") is not None:
                    metric_values["Flip Rate Touchless"] = round(float(result[0]["FLIP_RATE_TOUCHLESS"]), 2)
                    
                elif metric_name == "Non-Value Add %" and result and result[0].get("NON_VALUE_ADD_PCT") is not None:
                    metric_values["Non-Value Add %"] = round(float(result[0]["NON_VALUE_ADD_PCT"]), 2)
                    
                elif metric_name == "Lead Accuracy" and result and result[0].get("LEAD_ACCURACY_PCT") is not None:
                    metric_values["Lead Accuracy"] = round(float(result[0]["LEAD_ACCURACY_PCT"]), 2)
                        
        except Exception as e:
            logger.error(f"[AFTER_METRICS] Parallel execution failed: {str(e)}")
    
    return metric_values


@router.post(
    "/trend",
    response_model=ChangeTrackingTrendResponse,
    summary="Get Change Tracking Metrics Trend Line",
    description="Fetches trend line data for change tracking metrics over time with configurable time periods (monthly/weekly/yearly)"
)
async def get_change_tracking_trend(request: ChangeTrackingTrendRequest):
    """
    Get trend line data for change tracking metrics.
    
    Supports multiple time periods:
    - monthly: Aggregated by month
    - weekly: Aggregated by week
    - yearly: Aggregated by year
    
    Filters by work type and calculates selected KPI metrics.
    """
    try:
        logger.info(f"[CHANGE_TRACKING_TREND] User: {request.user_id}, Period: {request.time_period}, "
                   f"Date Range: {request.start_date} to {request.end_date}, Work Types: {request.work_type}")
        selected_kpis = request.kpi_metrics or []
        
        # Validate time_period
        if request.time_period not in ['monthly', 'weekly', 'yearly']:
            raise HTTPException(
                status_code=400, 
                detail="Invalid time_period. Must be 'monthly', 'weekly', or 'yearly'"
            )
        
        # Determine date truncation and format based on time_period
        if request.time_period == 'monthly':
            date_trunc = 'MONTH'
            period_format = 'YYYY-MM'
            period_end_calc = "LAST_DAY(COALESCE(ct.period_start, aud.period_start, frm.period_start, frt.period_start, nva.period_start, la.period_start))"
        elif request.time_period == 'weekly':
            date_trunc = 'WEEK'
            period_format = 'YYYY-"W"IW'
            period_end_calc = "DATEADD(DAY, 6, COALESCE(ct.period_start, aud.period_start, frm.period_start, frt.period_start, nva.period_start, la.period_start))"
        else:  # yearly
            date_trunc = 'YEAR'
            period_format = 'YYYY'
            period_end_calc = "LAST_DAY(COALESCE(ct.period_start, aud.period_start, frm.period_start, frt.period_start, nva.period_start, la.period_start), 'YEAR')"
        
        # Build work type filter
        work_type_str = ", ".join([f"'{wt}'" for wt in request.work_type])
        work_type_filter = f"AND INTAKESOURCESYSTEM IN ({work_type_str})"
        
        flip_rate_manual_cte = build_flip_rate_trend_cte(
            cte_name="flip_rate_manual_data",
            date_trunc=date_trunc,
            period_format=period_format,
            start_date=request.start_date,
            end_date=request.end_date,
            work_type_filter=work_type_filter,
            resolved_status="Resolved-Completed",
            rate_alias="flip_rate_manual"
        )
        flip_rate_touchless_cte = build_flip_rate_trend_cte(
            cte_name="flip_rate_touchless_data",
            date_trunc=date_trunc,
            period_format=period_format,
            start_date=request.start_date,
            end_date=request.end_date,
            work_type_filter=work_type_filter,
            resolved_status="Resolved-Touchless",
            rate_alias="flip_rate_touchless"
        )
        
        # Build the query dynamically
        query = f"""
        WITH cycle_time_data AS (
            SELECT 
                DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP) AS period_start,
                TO_CHAR(DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP), '{period_format}') AS period_label,
                ROUND(AVG(CYCLE_TIME) / 60, 2) AS avg_cycle_time_minutes,
                COUNT(DISTINCT PYID) AS total_cases
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
            WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
              AND PYRESOLVEDTIMESTAMP IS NOT NULL
              AND PYRESOLVEDTIMESTAMP >= '{request.start_date}'::DATE
              AND PYRESOLVEDTIMESTAMP <= '{request.end_date}'::DATE
              {work_type_filter}
              AND CYCLE_TIME IS NOT NULL
            GROUP BY DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP)
        ),
        audit_score_data AS (
            SELECT 
                DATE_TRUNC('{date_trunc}', i.PYRESOLVEDTIMESTAMP) AS period_start,
                TO_CHAR(DATE_TRUNC('{date_trunc}', i.PYRESOLVEDTIMESTAMP), '{period_format}') AS period_label,
                ROUND(AVG(CAST(a.AUDIT_SCORE AS FLOAT)), 2) AS avg_audit_score,
                COUNT(DISTINCT a.PYID) AS total_audits
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE i
            INNER JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
                ON i.PYID = a.CASE_TO_AUDIT
            WHERE i.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
              AND i.PYRESOLVEDTIMESTAMP IS NOT NULL
              AND i.PYRESOLVEDTIMESTAMP >= '{request.start_date}'::DATE
              AND i.PYRESOLVEDTIMESTAMP <= '{request.end_date}'::DATE
              {work_type_filter.replace('INTAKESOURCESYSTEM', 'i.INTAKESOURCESYSTEM')}
              AND a.AUDIT_SCORE IS NOT NULL
              AND a.PYID LIKE 'AUD%'
            GROUP BY DATE_TRUNC('{date_trunc}', i.PYRESOLVEDTIMESTAMP)
        ),
        {flip_rate_manual_cte},
        {flip_rate_touchless_cte},
        non_value_add_data AS (
            SELECT 
                DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP) AS period_start,
                TO_CHAR(DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP), '{period_format}') AS period_label,
                ROUND(
                    COUNT(DISTINCT CASE 
                        WHEN ACTIONDECISION LIKE '%Confirmed Existing COB/No Update Required%' 
                        THEN PYID 
                    END) * 100.0 / NULLIF(COUNT(DISTINCT PYID), 0),
                    2
                ) AS non_value_add_pct,
                COUNT(DISTINCT PYID) AS total_cases
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
            WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
              AND PYRESOLVEDTIMESTAMP IS NOT NULL
              AND PYRESOLVEDTIMESTAMP >= '{request.start_date}'::DATE
              AND PYRESOLVEDTIMESTAMP <= '{request.end_date}'::DATE
              {work_type_filter}
              AND ACTIONDECISION IS NOT NULL
            GROUP BY DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP)
        ),
        lead_accuracy_data AS (
            SELECT 
                DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP) AS period_start,
                TO_CHAR(DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP), '{period_format}') AS period_label,
                ROUND(
                    (SUM(CASE 
                        WHEN UPPER(LEADACCURACY) IN ('COB LEAD 100% ACCURATE', 'COB LEAD ACCURATE BUT REQUIRED CHANGES') 
                        THEN 1 ELSE 0 
                    END) * 100.0) / NULLIF(COUNT(DISTINCT PYID), 0),
                    2
                ) AS lead_accuracy_pct,
                COUNT(DISTINCT PYID) AS total_cases
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
            WHERE PYSTATUSWORK = 'Resolved-Completed'
              AND PYRESOLVEDTIMESTAMP IS NOT NULL
              AND PYRESOLVEDTIMESTAMP >= '{request.start_date}'::DATE
              AND PYRESOLVEDTIMESTAMP <= '{request.end_date}'::DATE
              {work_type_filter}
              AND LEADACCURACY IS NOT NULL
            GROUP BY DATE_TRUNC('{date_trunc}', PYRESOLVEDTIMESTAMP)
        )
        SELECT 
            COALESCE(ct.period_label, aud.period_label, frm.period_label, frt.period_label, nva.period_label, la.period_label) AS period,
            COALESCE(ct.period_start, aud.period_start, frm.period_start, frt.period_start, nva.period_start, la.period_start) AS period_start,
            {period_end_calc} AS period_end,
            ct.avg_cycle_time_minutes AS cycle_time,
            aud.avg_audit_score AS audit_score_pct,
            frm.flip_rate_manual AS flip_rate_manual,
            frt.flip_rate_touchless AS flip_rate_touchless,
            nva.non_value_add_pct,
            la.lead_accuracy_pct,
            COALESCE(ct.total_cases, 0) AS cycle_time_cases,
            COALESCE(aud.total_audits, 0) AS audit_cases,
            COALESCE(frm.total_cases, 0) AS flip_rate_manual_cases,
            COALESCE(frt.total_cases, 0) AS flip_rate_touchless_cases,
            COALESCE(nva.total_cases, 0) AS non_value_add_cases,
            COALESCE(la.total_cases, 0) AS lead_accuracy_cases
        FROM cycle_time_data ct
        FULL OUTER JOIN audit_score_data aud ON ct.period_start = aud.period_start
        FULL OUTER JOIN flip_rate_manual_data frm ON COALESCE(ct.period_start, aud.period_start) = frm.period_start
        FULL OUTER JOIN flip_rate_touchless_data frt ON COALESCE(ct.period_start, aud.period_start, frm.period_start) = frt.period_start
        FULL OUTER JOIN non_value_add_data nva ON COALESCE(ct.period_start, aud.period_start, frm.period_start, frt.period_start) = nva.period_start
        FULL OUTER JOIN lead_accuracy_data la ON COALESCE(ct.period_start, aud.period_start, frm.period_start, frt.period_start, nva.period_start) = la.period_start
        WHERE ct.period_start IS NOT NULL 
           OR aud.period_start IS NOT NULL
           OR frm.period_start IS NOT NULL
           OR frt.period_start IS NOT NULL
           OR nva.period_start IS NOT NULL
           OR la.period_start IS NOT NULL
        ORDER BY COALESCE(ct.period_start, aud.period_start, frm.period_start, frt.period_start, nva.period_start, la.period_start)
        """
        
        logger.info(f"[CHANGE_TRACKING_TREND] Executing trend query for {request.time_period} period")
        
        # Execute query
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=10000)
        
        # Build response data
        trend_data = []
        for row in results:
            cycle_time = float(row["CYCLE_TIME"]) if "Cycle Time" in selected_kpis and row.get("CYCLE_TIME") is not None else None
            audit_score_pct = float(row["AUDIT_SCORE_PCT"]) if "Audit Score %" in selected_kpis and row.get("AUDIT_SCORE_PCT") is not None else None
            flip_rate_manual = float(row["FLIP_RATE_MANUAL"]) if "Flip Rate Manual" in selected_kpis and row.get("FLIP_RATE_MANUAL") is not None else None
            flip_rate_touchless = float(row["FLIP_RATE_TOUCHLESS"]) if "Flip Rate Touchless" in selected_kpis and row.get("FLIP_RATE_TOUCHLESS") is not None else None
            non_value_add_pct = float(row["NON_VALUE_ADD_PCT"]) if "Non-Value Add %" in selected_kpis and row.get("NON_VALUE_ADD_PCT") is not None else None
            lead_accuracy_pct = float(row["LEAD_ACCURACY_PCT"]) if "Lead Accuracy" in selected_kpis and row.get("LEAD_ACCURACY_PCT") is not None else None

            if selected_kpis and all(value is None for value in [cycle_time, audit_score_pct, flip_rate_manual, flip_rate_touchless, non_value_add_pct, lead_accuracy_pct]):
                continue

            trend_data.append(TrendDataPoint(
                period=str(row.get("PERIOD") or ""),
                period_start=str(row.get("PERIOD_START") or ""),
                period_end=str(row.get("PERIOD_END") or ""),
                cycle_time=cycle_time,
                audit_score_pct=audit_score_pct,
                flip_rate_manual=flip_rate_manual,
                flip_rate_touchless=flip_rate_touchless,
                non_value_add_pct=non_value_add_pct,
                lead_accuracy_pct=lead_accuracy_pct,
                cycle_time_cases=int(row.get("CYCLE_TIME_CASES") or 0) if "Cycle Time" in selected_kpis else 0,
                audit_cases=int(row.get("AUDIT_CASES") or 0) if "Audit Score %" in selected_kpis else 0,
                flip_rate_manual_cases=int(row.get("FLIP_RATE_MANUAL_CASES") or 0) if "Flip Rate Manual" in selected_kpis else 0,
                flip_rate_touchless_cases=int(row.get("FLIP_RATE_TOUCHLESS_CASES") or 0) if "Flip Rate Touchless" in selected_kpis else 0,
                non_value_add_cases=int(row.get("NON_VALUE_ADD_CASES") or 0) if "Non-Value Add %" in selected_kpis else 0,
                lead_accuracy_cases=int(row.get("LEAD_ACCURACY_CASES") or 0) if "Lead Accuracy" in selected_kpis else 0
            ))
        
        logger.info(f"[CHANGE_TRACKING_TREND] Retrieved {len(trend_data)} data points")
        
        return ChangeTrackingTrendResponse(
            status="success",
            time_period=request.time_period,
            start_date=request.start_date,
            end_date=request.end_date,
            work_types=request.work_type,
            kpi_metrics=request.kpi_metrics,
            data=trend_data,
            message=f"Trend data retrieved successfully for {len(trend_data)} {request.time_period} periods"
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[CHANGE_TRACKING_TREND] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve trend data: {str(e)}")


# ============================================================================
# Export router for inclusion in main __init__.py
# ============================================================================
__all__ = [
    "router",
]
