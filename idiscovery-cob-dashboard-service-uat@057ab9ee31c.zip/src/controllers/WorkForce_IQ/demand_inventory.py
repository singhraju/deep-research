import logging
import asyncio
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment

from db import SnowflakeConnectionManager
import config
from schema.workforce_iq_models import (
    ReceiptsVsResolvedRequest,
    ReceiptsAgeRequest,
    ReceiptsVsResolvedCombinedResponse,
    ReceiptsAgeCombinedResponse,
    AgeDrilldownRequest,
    AgeDrilldownResponse,
    SourceTypeBreakdownRequest,
    SourceTypeBreakdownResponse,
    InventoryByMarketRequest,
    InventoryByMarketResponse,
    TrendAnalysisRequest,
    TrendAnalysisResponse,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config
from services.session_cache_orchestrator import generate_session_id
from services.workforce_session_cache_service import workforce_session_cache_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()

# ============================================================================
# SQL QUERIES - PLACEHOLDERS (TO BE FILLED IN LATER)
# ============================================================================

SOURCE_TYPE_BREAKDOWN_QUERY = f"""
WITH selected_work_types_input AS (
    {{work_type_selection}}
),
has_selection AS (
    SELECT COUNT(*) > 0 AS is_selected FROM selected_work_types_input
),
invntry_deduped AS (
    SELECT 
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.LOB,
        inv.INTAKESOURCESYSTEM,
        inv.MARKET,
        inv.FUNDINGMODEL,
        inv.REPORTTOMANAGERID,
        inv.PXCREATEDATETIME,
        inv.PYRESOLVEDTIMESTAMP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID 
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
filtered_data AS (
    SELECT 
        d.PYID,
        COALESCE(TRIM(d.INTAKESOURCESYSTEM), 'None') AS work_type
    FROM invntry_deduped d
    CROSS JOIN has_selection hs
    WHERE hs.is_selected = TRUE
      AND d.PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 'Open-ReviewIntake', 'Pend', 'Pend-Decision')
      -- Created before or on end_date
      AND d.PXCREATEDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
      -- Current date: still open (not yet resolved)
      -- Past date: was open at that time AND still open today
      AND (
          d.PYRESOLVEDTIMESTAMP IS NULL
          OR d.PYRESOLVEDTIMESTAMP >= CURRENT_DATE()
      )
      {{manager_filter}}
      {{lob_filter}}
      {{market_filter}}
      {{funding_model_filter}}
      {{work_type_filter}}
      {{staffing_filter_exists}}
),
all_types AS (
    SELECT DISTINCT UPPER(TRIM(work_type)) AS work_type FROM selected_work_types_input
)
SELECT
    a.work_type AS source_type,
    COUNT(f.PYID) AS case_count,
    SUM(COUNT(f.PYID)) OVER () AS total_count,
    COALESCE(ROUND(COUNT(f.PYID) * 100.0 / NULLIF(SUM(COUNT(f.PYID)) OVER (), 0), 2), 0) AS percentage
FROM all_types a
LEFT JOIN filtered_data f ON UPPER(TRIM(f.work_type)) = a.work_type
GROUP BY a.work_type
ORDER BY case_count DESC, a.work_type
"""

INVENTORY_BY_MARKET_QUERY = f"""
WITH selected_markets AS (
    {{market_selection}}
),
has_selection AS (
    SELECT COUNT(*) > 0 AS is_selected FROM selected_markets
),
invntry_deduped AS (
    SELECT 
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.LOB,
        inv.INTAKESOURCESYSTEM,
        inv.MARKET,
        inv.FUNDINGMODEL,
        inv.REPORTTOMANAGERID,
        inv.PXCREATEDATETIME,
        inv.PYRESOLVEDTIMESTAMP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID 
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
filtered_data AS (
    SELECT 
        d.PYID,
        COALESCE(TRIM(d.MARKET), 'None') AS market
    FROM invntry_deduped d
    CROSS JOIN has_selection hs
    WHERE hs.is_selected = TRUE
      AND d.PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 'Open-ReviewIntake', 'Pend', 'Pend-Decision')
      -- Created before or on end_date
      AND d.PXCREATEDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
      -- Current date: still open (not yet resolved)
      -- Past date: was open at that time AND still open today
      AND (
          d.PYRESOLVEDTIMESTAMP IS NULL
          OR d.PYRESOLVEDTIMESTAMP >= CURRENT_DATE()
      )
      AND COALESCE(TRIM(d.MARKET), 'None') IN (SELECT market FROM selected_markets)
      {{manager_filter}}
      {{lob_filter}}
      {{work_type_filter}}
      {{funding_model_filter}}
      {{staffing_filter_exists}}
),
all_markets AS (
    SELECT DISTINCT market FROM selected_markets
)
SELECT
    a.market,
    COUNT(f.PYID) AS case_count,
    SUM(COUNT(f.PYID)) OVER () AS total_count,
    ROUND(COUNT(f.PYID) * 100.0 / NULLIF(SUM(COUNT(f.PYID)) OVER (), 0), 2) AS percentage
FROM all_markets a
LEFT JOIN filtered_data f ON a.market = f.market
GROUP BY a.market
ORDER BY case_count DESC, a.market
"""

PROJECTED_VS_ACTUAL_RECEIPTS_QUERY = f"""
WITH date_range_calc AS (
    SELECT
        '{{start_date}}'::DATE AS start_date,
        '{{end_date}}'::DATE AS end_date,
        DATEADD(YEAR, -1, '{{start_date}}'::DATE) AS py_start,
        DATEADD(YEAR, -1, '{{end_date}}'::DATE) AS py_end,
        '{{grouping_level}}' AS grouping_level
),
cy_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.LOB,
        inv.INTAKESOURCESYSTEM,
        inv.MARKET,
        inv.FUNDINGMODEL,
        inv.PXCREATEDATETIME,
        inv.REPORTTOMANAGERID,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        DATE_TRUNC('WEEK', inv.PXCREATEDATETIME) AS week_start,
        DATE_TRUNC('MONTH', inv.PXCREATEDATETIME) AS month_start,
        DATE_TRUNC('QUARTER', inv.PXCREATEDATETIME) AS quarter_start,
        DATE_TRUNC('YEAR', inv.PXCREATEDATETIME) AS year_start
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC) = 1
),
py_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.LOB,
        inv.INTAKESOURCESYSTEM,
        inv.MARKET,
        inv.FUNDINGMODEL,
        inv.PXCREATEDATETIME,
        inv.REPORTTOMANAGERID,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        DATE_TRUNC('WEEK', inv.PXCREATEDATETIME) AS week_start,
        DATE_TRUNC('MONTH', inv.PXCREATEDATETIME) AS month_start,
        DATE_TRUNC('QUARTER', inv.PXCREATEDATETIME) AS quarter_start,
        DATE_TRUNC('YEAR', inv.PXCREATEDATETIME) AS year_start
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY inv.PXCOMMITDATETIME DESC NULLS LAST, inv.insrt_dt_time DESC) = 1
),
date_spine AS (
    SELECT
        drc.grouping_level,
        CASE
            WHEN drc.grouping_level = 'daily' THEN DATEADD(DAY, seq.seq, drc.start_date)
            WHEN drc.grouping_level = 'weekly' THEN DATEADD(WEEK, seq.seq, DATE_TRUNC('WEEK', drc.start_date))
            WHEN drc.grouping_level = 'monthly' THEN DATEADD(MONTH, seq.seq, DATE_TRUNC('MONTH', drc.start_date))
            WHEN drc.grouping_level = 'quarterly' THEN DATEADD(QUARTER, seq.seq, DATE_TRUNC('QUARTER', drc.start_date))
            WHEN drc.grouping_level = 'yearly' THEN DATEADD(YEAR, seq.seq, DATE_TRUNC('YEAR', drc.start_date))
        END AS period_date
    FROM date_range_calc drc
    CROSS JOIN (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq FROM TABLE(GENERATOR(ROWCOUNT => 3660))) seq
    WHERE CASE
            WHEN drc.grouping_level = 'daily' THEN DATEADD(DAY, seq.seq, drc.start_date)
            WHEN drc.grouping_level = 'weekly' THEN DATEADD(WEEK, seq.seq, DATE_TRUNC('WEEK', drc.start_date))
            WHEN drc.grouping_level = 'monthly' THEN DATEADD(MONTH, seq.seq, DATE_TRUNC('MONTH', drc.start_date))
            WHEN drc.grouping_level = 'quarterly' THEN DATEADD(QUARTER, seq.seq, DATE_TRUNC('QUARTER', drc.start_date))
            WHEN drc.grouping_level = 'yearly' THEN DATEADD(YEAR, seq.seq, DATE_TRUNC('YEAR', drc.start_date))
        END <= drc.end_date
),
all_periods AS (
    SELECT
        ds.grouping_level,
        ds.period_date,
        CASE
            WHEN ds.grouping_level = 'daily' THEN TO_CHAR(ds.period_date, 'YYYY-MM-DD')
            WHEN ds.grouping_level = 'weekly' THEN TO_CHAR(ds.period_date, 'YYYY-MM-DD')
            WHEN ds.grouping_level = 'monthly' THEN LTRIM(TO_CHAR(ds.period_date, 'MM/YYYY'), '0')
            WHEN ds.grouping_level = 'quarterly' THEN CONCAT(TO_CHAR(ds.period_date, 'YYYY'), '-Q', QUARTER(ds.period_date))
            WHEN ds.grouping_level = 'yearly' THEN TO_CHAR(ds.period_date, 'YYYY')
        END AS period_label
    FROM date_spine ds
),
cy_aggregated AS (
    SELECT
        drc.grouping_level,
        CASE
            WHEN drc.grouping_level = 'daily' THEN cy.create_date
            WHEN drc.grouping_level = 'weekly' THEN cy.week_start
            WHEN drc.grouping_level = 'monthly' THEN cy.month_start
            WHEN drc.grouping_level = 'quarterly' THEN cy.quarter_start
            WHEN drc.grouping_level = 'yearly' THEN cy.year_start
        END AS period_date,
        COUNT(cy.PYID) AS current_year_actual_receipts
    FROM cy_deduped cy
    CROSS JOIN date_range_calc drc
    WHERE cy.PXCREATEDATETIME >= (SELECT start_date FROM date_range_calc)
      AND cy.PXCREATEDATETIME < DATEADD(DAY, 1, (SELECT end_date FROM date_range_calc))
      AND DATE(cy.PXCREATEDATETIME) <= (SELECT end_date FROM date_range_calc)
      AND (cy.PYSTATUSWORK IN ('Resolved-Completed','Resolved-DupClose','Resolved-BulkAutoClose','New','Pend-Decision','Resolved-AutoCloseLink','Open-ReviewIntake','Pend','Open-AuditReview','Open-CAQHPortal'))
      {{lob_filter_cy}}
      {{work_type_filter_cy}}
      {{manager_filter_cy}}
    --   {{market_filter_cy}}
    --   {{funding_model_filter_cy}}
      {{staffing_filter_cy_exists}}
    GROUP BY 1, 2
),
py_aggregated AS (
    SELECT
        drc.grouping_level,
        CASE
            WHEN drc.grouping_level = 'daily' THEN 
                -- Map to next day (same weekday) in current year, accounting for leap years
                -- If previous year (py year) is leap year OR current year (py+1) is leap year, go back 2 days
                -- Otherwise go back 1 day (standard 364 days back)
                CASE
                    WHEN (MOD(YEAR(py.create_date), 4) = 0 AND (MOD(YEAR(py.create_date), 100) != 0 OR MOD(YEAR(py.create_date), 400) = 0))
                         OR (MOD(YEAR(py.create_date) + 1, 4) = 0 AND (MOD(YEAR(py.create_date) + 1, 100) != 0 OR MOD(YEAR(py.create_date) + 1, 400) = 0))
                    THEN DATEADD(DAY, -2, DATEADD(YEAR, 1, py.create_date))
                    ELSE DATEADD(DAY, -1, DATEADD(YEAR, 1, py.create_date))
                END
            WHEN drc.grouping_level = 'weekly' THEN DATE_TRUNC('WEEK', DATEADD(YEAR, 1, py.create_date))
            WHEN drc.grouping_level = 'monthly' THEN DATEADD(YEAR, 1, py.month_start)
            WHEN drc.grouping_level = 'quarterly' THEN DATEADD(YEAR, 1, py.quarter_start)
            WHEN drc.grouping_level = 'yearly' THEN DATEADD(YEAR, 1, py.year_start)
        END AS period_date,
        COUNT(py.PYID) AS prior_year_actual_receipts
    FROM py_deduped py
    CROSS JOIN date_range_calc drc
    WHERE py.PXCREATEDATETIME >= DATEADD(DAY, 1, (SELECT py_start FROM date_range_calc))
      AND py.PXCREATEDATETIME < DATEADD(DAY, 2, (SELECT py_end FROM date_range_calc))
      AND (py.PYSTATUSWORK IN ('Resolved-Completed','Resolved-DupClose','Resolved-BulkAutoClose','New','Pend-Decision','Resolved-AutoCloseLink','Open-ReviewIntake','Pend','Open-AuditReview','Open-CAQHPortal'))
      {{lob_filter_py}}
      {{work_type_filter_py}}
      {{manager_filter_py}}
    --   {{market_filter_py}}
    --   {{funding_model_filter_py}}
      {{staffing_filter_py_exists}}
    GROUP BY 1, 2
),
prior_year_membership AS (
    SELECT
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        DATE_FROM_PARTS(m.YEAR, 
            CASE m.MONTH
                WHEN 'January' THEN 1 WHEN 'February' THEN 2 WHEN 'March' THEN 3
                WHEN 'April' THEN 4 WHEN 'May' THEN 5 WHEN 'June' THEN 6
                WHEN 'July' THEN 7 WHEN 'August' THEN 8 WHEN 'September' THEN 9
                WHEN 'October' THEN 10 WHEN 'November' THEN 11 WHEN 'December' THEN 12
            END, 1) AS month_start_date
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_MEMBERSHIP_DATA m
    WHERE m.YEAR BETWEEN YEAR((SELECT py_start FROM date_range_calc)) AND YEAR((SELECT py_end FROM date_range_calc))
        {{lob_filter_membership}}
),
py_membership_agg AS (
    SELECT
        pm.month_start_date,
        SUM(pm.ACTUAL_MEMBERSHIP) AS prior_year_actual_membership
    FROM prior_year_membership pm
    GROUP BY pm.month_start_date
),
current_year_membership AS (
    SELECT
        m.LOB,
        m.PROJECTED_MEMBERSHIP,
        DATE_FROM_PARTS(m.YEAR, 
            CASE m.MONTH
                WHEN 'January' THEN 1 WHEN 'February' THEN 2 WHEN 'March' THEN 3
                WHEN 'April' THEN 4 WHEN 'May' THEN 5 WHEN 'June' THEN 6
                WHEN 'July' THEN 7 WHEN 'August' THEN 8 WHEN 'September' THEN 9
                WHEN 'October' THEN 10 WHEN 'November' THEN 11 WHEN 'December' THEN 12
            END, 1) AS month_start_date
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_MEMBERSHIP_DATA m
    WHERE m.YEAR BETWEEN YEAR((SELECT start_date FROM date_range_calc)) AND YEAR((SELECT end_date FROM date_range_calc))
        {{lob_filter_membership}}
),
cy_membership_agg AS (
    SELECT
        cm.month_start_date,
        SUM(cm.PROJECTED_MEMBERSHIP) AS current_year_projected_membership
    FROM current_year_membership cm
    GROUP BY cm.month_start_date
)
SELECT
    ap.grouping_level AS GROUPING_LEVEL,
    ap.period_date,
    ap.period_label,
    COALESCE(cy.current_year_actual_receipts, 0) AS ACTUAL_RECEIPTS,
    COALESCE(py.prior_year_actual_receipts, 0) AS prior_year_actual_receipts,
    CASE
        WHEN COALESCE(py.prior_year_actual_receipts, 0) = 0 THEN NULL
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 3
            FROM py_membership_agg pma
            WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
              AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 12
            FROM py_membership_agg pma
            WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
        )
    END AS prior_year_actual_membership,
    CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN cm_monthly.current_year_projected_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 3
            FROM cy_membership_agg cma
            WHERE cma.month_start_date >= DATE_TRUNC('QUARTER', ap.period_date)
              AND cma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', ap.period_date))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 12
            FROM cy_membership_agg cma
            WHERE YEAR(cma.month_start_date) = YEAR(ap.period_date)
        )
    END AS current_year_projected_membership,
    COALESCE(py.prior_year_actual_receipts, 0) / 
    NULLIF(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 3
            FROM py_membership_agg pma
            WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
              AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 12
            FROM py_membership_agg pma
            WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
        )
    END, 0) AS utilization_rate,
    ROUND(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN cm_monthly.current_year_projected_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 3
            FROM cy_membership_agg cma
            WHERE cma.month_start_date >= DATE_TRUNC('QUARTER', ap.period_date)
              AND cma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', ap.period_date))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 12
            FROM cy_membership_agg cma
            WHERE YEAR(cma.month_start_date) = YEAR(ap.period_date)
        )
    END *
    (COALESCE(py.prior_year_actual_receipts, 0) / 
    NULLIF(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 3
            FROM py_membership_agg pma
            WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
              AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 12
            FROM py_membership_agg pma
            WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
        )
    END, 0)), 0) AS PROJECTED_RECEIPTS,
    ROUND(((COALESCE(cy.current_year_actual_receipts, 0) - ROUND(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN cm_monthly.current_year_projected_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 3
            FROM cy_membership_agg cma
            WHERE cma.month_start_date >= DATE_TRUNC('QUARTER', ap.period_date)
              AND cma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', ap.period_date))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 12
            FROM cy_membership_agg cma
            WHERE YEAR(cma.month_start_date) = YEAR(ap.period_date)
        )
    END *
    (COALESCE(py.prior_year_actual_receipts, 0) / 
    NULLIF(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 3
            FROM py_membership_agg pma
            WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
              AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 12
            FROM py_membership_agg pma
            WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
        )
    END, 0)), 0)) / NULLIF(ROUND(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN cm_monthly.current_year_projected_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 3
            FROM cy_membership_agg cma
            WHERE cma.month_start_date >= DATE_TRUNC('QUARTER', ap.period_date)
              AND cma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', ap.period_date))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 12
            FROM cy_membership_agg cma
            WHERE YEAR(cma.month_start_date) = YEAR(ap.period_date)
        )
    END *
    (COALESCE(py.prior_year_actual_receipts, 0) / 
    NULLIF(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 3
            FROM py_membership_agg pma
            WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
              AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 12
            FROM py_membership_agg pma
            WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
        )
    END, 0)), 0), 0)) * 100, 2) AS variance_pct,
    CASE
        WHEN ap.period_date < CURRENT_DATE() THEN 'PAST'
        WHEN ap.period_date = CURRENT_DATE() THEN 'CURRENT'
        ELSE 'FUTURE'
    END AS date_category
FROM all_periods ap
LEFT JOIN cy_aggregated cy ON ap.period_date = cy.period_date AND ap.grouping_level = cy.grouping_level
LEFT JOIN py_aggregated py ON ap.period_date = py.period_date AND ap.grouping_level = py.grouping_level
LEFT JOIN py_membership_agg pm_monthly ON DATE_TRUNC('MONTH', DATEADD(YEAR, -1, ap.period_date)) = pm_monthly.month_start_date
    AND ap.grouping_level IN ('daily', 'weekly', 'monthly')
LEFT JOIN cy_membership_agg cm_monthly ON DATE_TRUNC('MONTH', ap.period_date) = cm_monthly.month_start_date
    AND ap.grouping_level IN ('daily', 'weekly', 'monthly')
ORDER BY ap.period_date
"""

PROJECTED_RESOLVED_QUERY = f"""
-- Projected Resolved = Working Days x (Productive mins/day x Projected FTE) / Avg Cycle Time mins
-- Uses exact Projected FTE logic (with UTO/PTO deduction)

WITH config AS (
    SELECT
        '{{start_date}}'::DATE AS start_date,
        '{{end_date}}'::DATE AS end_date,
        '{{grouping_level}}' AS grouping_level,
        NULL AS filter_market
),

date_spine AS (
    SELECT DATEADD(DAY, seq.seq, dr.start_date) AS period_date
    FROM config dr
    CROSS JOIN (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq FROM TABLE(GENERATOR(ROWCOUNT => 100000))) seq
    WHERE DATEADD(DAY, seq.seq, dr.start_date) <= dr.end_date
        AND ((SELECT grouping_level FROM config) != 'daily' OR DAYOFWEEK(DATEADD(DAY, seq.seq, dr.start_date)) NOT IN (0, 6))
),

holidays AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),

all_dates_in_range AS (
    SELECT DATEADD(DAY, seq.seq, (SELECT start_date FROM config)) AS calendar_date
    FROM (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq FROM TABLE(GENERATOR(ROWCOUNT => 10000))) seq
    WHERE DATEADD(DAY, seq.seq, (SELECT start_date FROM config)) <= (SELECT end_date FROM config)
),

working_days_per_period AS (
    SELECT DISTINCT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ad.calendar_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', ad.calendar_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', ad.calendar_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', ad.calendar_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', ad.calendar_date)
        END AS period_date,
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN 1
            ELSE (
                SELECT COUNT(DISTINCT ad2.calendar_date)
                FROM all_dates_in_range ad2
                LEFT JOIN holidays h ON h.holiday_date = ad2.calendar_date
                WHERE DAYOFWEEK(ad2.calendar_date) NOT IN (0, 6)
                  AND h.holiday_date IS NULL
                  AND CASE (SELECT grouping_level FROM config)
                      WHEN 'weekly' THEN DATE_TRUNC('WEEK', ad2.calendar_date) = DATE_TRUNC('WEEK', ad.calendar_date)
                      WHEN 'monthly' THEN DATE_TRUNC('MONTH', ad2.calendar_date) = DATE_TRUNC('MONTH', ad.calendar_date)
                      WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', ad2.calendar_date) = DATE_TRUNC('QUARTER', ad.calendar_date)
                      WHEN 'yearly' THEN DATE_TRUNC('YEAR', ad2.calendar_date) = DATE_TRUNC('YEAR', ad.calendar_date)
                  END
            )
        END AS working_days
    FROM all_dates_in_range ad
),

productive_time AS (
    SELECT
        ROUND(AVG(
            SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT * 60.0 +
            SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT +
            SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 60.0
        ), 2) AS avg_productive_mins_per_day
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_USER_PROFILE u
    WHERE UPPER(u.PYACCESSGROUP) LIKE '%FRONTLINE%'
        AND u.PRODUCTIVETIME IS NOT NULL
        AND CASE
            WHEN (SELECT end_date FROM config) < CURRENT_DATE() THEN
                u.LOGINDATE >= DATEADD(DAY, -90, (SELECT end_date FROM config))
                AND u.LOGINDATE <= (SELECT end_date FROM config)
            ELSE
                u.LOGINDATE >= DATEADD(DAY, -90, CURRENT_DATE())
                AND u.LOGINDATE <= CURRENT_DATE()
        END
),

user_staffing_cat AS (
    -- Keep logindate so join can pick the most recent record valid as of each snapshot_date
    SELECT
        up.USERID,
        xw.STAFFING_CATEGORY AS STAFFING_CATEGORY,
        up.logindate
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_USER_PROFILE up
    LEFT JOIN {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_STAFFING_CATEGORY_XWALK xw
        ON TRIM(up.STAFFINGCATEGORY) = TRIM(xw.STAFFING_CATEGORY)
    WHERE up.USERID IS NOT NULL
),

historical_avail AS (
    -- Match ACTUAL_FTE_QUERY: join on logindate <= snapshot_date, pick latest per employee/date
    -- Staffing category filter applied on the resolved usc column inside the subquery
    -- to avoid excluding users whose logindate is after snapshot_date (LEFT JOIN gives NULL → 'None')
    SELECT
        userid,
        manager_id,
        snapshot_date,
        STAFFING_CATEGORY
    FROM (
        SELECT
            w.EMPLOYEE_DOMAIN_ID AS userid,
            w.MANAGER_DOMAIN_ID AS manager_id,
            TRY_CAST(w.ASOFTODAY AS DATE) AS snapshot_date,
            COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY,
            ROW_NUMBER() OVER (
                PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.ASOFTODAY AS DATE)
                ORDER BY usc.logindate DESC NULLS LAST
            ) AS rn_sc
        FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_WORKDAY_HIST w
        LEFT JOIN user_staffing_cat usc
            ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID)
            AND usc.logindate <= TRY_CAST(w.ASOFTODAY AS DATE)
        WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
            AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
            AND TRY_CAST(w.ASOFTODAY AS DATE) <= CURRENT_DATE()
            AND DAYOFWEEK(TRY_CAST(w.ASOFTODAY AS DATE)) NOT IN (0, 6)
    )
    WHERE rn_sc = 1
        -- {{manager_filter}}
),

historical_avail_filtered AS (
    SELECT * FROM historical_avail
    WHERE 1=1
        {{staffing_category_filter_historical}}
),

historical_avg AS (
    SELECT (
        SELECT avail_count FROM (
            SELECT snapshot_date, COUNT(DISTINCT userid) AS avail_count
            FROM historical_avail
            WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
            GROUP BY snapshot_date
            ORDER BY snapshot_date DESC LIMIT 1
        )
    ) AS avg_historical_fte
),

onboard_data AS (
    SELECT
        TRY_CAST(op.FUTURE_START_DATE AS DATE) AS start_date,
        op.ONBOARDING_COUNT,
        COALESCE(UPPER(TRIM(op.LOB)), 'NONE') AS LOB
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_OPEN_POSITIONS op
    WHERE TRY_CAST(op.FUTURE_START_DATE AS DATE) IS NOT NULL
        {{lob_filter_onboard}}
),

onboard_by_period AS (
    SELECT
        start_date AS onboard_complete_date,
        SUM(ONBOARDING_COUNT) AS onboard_fte
    FROM onboard_data
    WHERE start_date >= DATEADD(DAY, -15, (SELECT MAX(snapshot_date) FROM historical_avail WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)))
    GROUP BY start_date
),

historical_grouped_base AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN snapshot_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', snapshot_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', snapshot_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', snapshot_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', snapshot_date)
        END AS period_date,
        COUNT(DISTINCT userid) AS base_fte_count
    FROM historical_avail_filtered
    WHERE snapshot_date BETWEEN (SELECT start_date FROM config) AND (SELECT end_date FROM config)
        AND CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN snapshot_date < CURRENT_DATE()
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', snapshot_date) < DATE_TRUNC('WEEK', CURRENT_DATE())
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', snapshot_date) < DATE_TRUNC('MONTH', CURRENT_DATE())
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', snapshot_date) < DATE_TRUNC('QUARTER', CURRENT_DATE())
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', snapshot_date) < DATE_TRUNC('YEAR', CURRENT_DATE())
        END
    GROUP BY period_date
),

historical_grouped AS (
    SELECT
        hgb.period_date,
        hgb.base_fte_count + COALESCE((
            SELECT SUM(onboard_fte) FROM onboard_by_period 
            WHERE onboard_complete_date > CURRENT_DATE()
              AND onboard_complete_date <= hgb.period_date
        ), 0) AS avail_fte_count
    FROM historical_grouped_base hgb
),

future_grouped_avail AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ds.period_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', ds.period_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', ds.period_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', ds.period_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', ds.period_date)
        END AS period_date,
        COALESCE((SELECT avg_historical_fte FROM historical_avg), 0)
        + COALESCE((
            SELECT SUM(onboard_fte) FROM onboard_by_period 
            WHERE onboard_complete_date > CURRENT_DATE()
              AND onboard_complete_date <= ds.period_date
        ), 0) AS avail_fte_count
    FROM date_spine ds
    WHERE ds.period_date >= CURRENT_DATE()
    GROUP BY period_date
),

available_fte AS (
    SELECT period_date, avail_fte_count FROM historical_grouped
    UNION ALL
    SELECT period_date, avail_fte_count FROM future_grouped_avail
),

time_off_raw AS (
    -- Match ACTUAL_FTE_QUERY: dedup on TIME_OFF_ENTRY_UNIQUE_KEY, order by ASOFTODAY DESC then logindate DESC
    SELECT
        w.EMPLOYEE_DOMAIN_ID AS userid,
        w.MANAGER_DOMAIN_ID AS manager_id,
        TRY_CAST(w.TIME_OFF_DATE AS DATE) AS time_off_date,
        TRY_CAST(w.HOURS AS FLOAT) AS hours_off,
        COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.TIME_OFF_DATE AS DATE), w.TIME_OFF_TYPE, w.TIME_OFF_ENTRY_UNIQUE_KEY
            ORDER BY w.ASOFTODAY DESC, usc.logindate DESC NULLS LAST
        ) AS rn
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_WORKDAY_HIST w
    LEFT JOIN user_staffing_cat usc
        ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID)
        AND usc.logindate <= TRY_CAST(w.TIME_OFF_DATE AS DATE)
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
        AND w.STATUS IN ('Approved', 'Submitted')
        AND w.TIME_OFF_TYPE IN (
            -- Scheduled PTO
            'Paid Time Off - Approved/Scheduled',
            'Paid Time Off',
            'Paid Time Off - Supplemental',
            
            -- Unscheduled PTO
            'Paid Time Off - Unapproved/Unscheduled',
            
            -- Sick Time (all types that reduce available capacity)
            'Sick Time',
            'Sick Time - Approved',
            'Sick Time - Unapproved',
            'Sick Time - Supplemental',
            'Sick Time - Intermittent LOA',
            
            -- Wellness and Care Leave
            'Wellness Days Off',
            'Paid Time Off - Kin Care/CA Sick',
            'Critical Care Leave',
            
            -- Parental Leave
            'Paid Parental Leave',
            'Other Paid Time - New Parent Transition',
            
            -- Other Paid Time Off
            'Other Paid Time - Bereavement',
            'Other Paid Time - Jury Duty',
            'Other Paid Time - Voting',
            'Other Paid Time - Voluntary Time Off/Community Service',
            'Other Paid Time - Business Disruption/Sent Home/Lack of Work',
            
            -- Intermittent LOA (affects daily capacity)
            'Paid Time Off - Intermittent LOA',
            'Other Paid Time - Intermittent LOA',
            'Non Paid Time - Intermittent LOA',
            
            -- Approved Unpaid Time
            'Non Paid Time - Approved/Voluntary',
            
            -- Workers Comp and Special Cases
            'Non Paid Time - Worker''s Compensation',
            'Non Paid Time - Victims of Domestic Violence & Crimes',
            'Non Paid Time - Unapproved'
        )
        AND TRY_CAST(w.TIME_OFF_DATE AS DATE) IS NOT NULL
        AND TRY_CAST(w.TIME_OFF_DATE AS DATE) BETWEEN (SELECT start_date FROM config) AND (SELECT end_date FROM config)
        {{manager_filter}}
        {{staffing_category_filter_timeoff}}
),

time_off AS (
    SELECT userid, manager_id, time_off_date, hours_off, STAFFING_CATEGORY
    FROM time_off_raw
    WHERE rn = 1
),

holidays_resolved AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),
holiday_count_per_period_resolved AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN h.holiday_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', h.holiday_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', h.holiday_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', h.holiday_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', h.holiday_date)
        END AS period_date,
        COUNT(*) AS holiday_count
    FROM holidays_resolved h
    WHERE DAYOFWEEK(h.holiday_date) NOT IN (0, 6)
    GROUP BY 1
),
time_off_with_periods_resolved AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN time_off_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', time_off_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', time_off_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', time_off_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', time_off_date)
        END AS period_date,
        hours_off
    FROM time_off t
    WHERE EXISTS (
        SELECT 1 FROM historical_avail_filtered haf
        WHERE UPPER(haf.userid) = UPPER(t.userid)
          AND haf.snapshot_date = t.time_off_date
    )
),
actual_pto AS (
    SELECT
        t.period_date,
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ROUND(SUM(t.hours_off) / 8.0, 2)
            WHEN 'weekly' THEN 
                CASE WHEN (5 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (5 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'monthly' THEN 
                CASE WHEN (22 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (22 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'quarterly' THEN 
                CASE WHEN (65 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (65 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'yearly' THEN 
                CASE WHEN (260 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (260 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
        END AS pto_headcount
    FROM time_off_with_periods_resolved t
    LEFT JOIN holiday_count_per_period_resolved hc ON t.period_date = hc.period_date
    GROUP BY t.period_date, hc.holiday_count
),

static_pto AS (
    SELECT
        MONTH,
        REPLACE(CB_PTO_PERCENT, '%', '')::FLOAT / 100 AS cb_pto_pct,
        REPLACE(GB_PTO_PERCENT, '%', '')::FLOAT / 100 AS gb_pto_pct
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_PROJECTED_STATIC_PTO
),

staffing_category_pto_mapping AS (
    SELECT
        af.period_date,
        SUM(CASE 
            WHEN ha.STAFFING_CATEGORY IN ('CB - E/I', 'CB-Claim Edits', 'CB-Inquiries') THEN 1
            ELSE 0
        END) AS cb_count,
        SUM(CASE 
            WHEN ha.STAFFING_CATEGORY NOT IN ('CB - E/I', 'CB-Claim Edits', 'CB-Inquiries') OR ha.STAFFING_CATEGORY IS NULL THEN 1
            ELSE 0
        END) AS gb_count,
        COUNT(*) AS total_count
    FROM available_fte af
    LEFT JOIN historical_avail ha ON 1=1
    GROUP BY af.period_date
),

projected_fte_calc AS (
    SELECT
        af.period_date,
        af.avail_fte_count AS available_fte,
        CASE
            WHEN af.period_date <= DATEADD(DAY, 14, CURRENT_DATE())
            THEN COALESCE(ap.pto_headcount, 0)
            ELSE ROUND(af.avail_fte_count * COALESCE(
                (scpm.cb_count * sp.cb_pto_pct + scpm.gb_count * sp.gb_pto_pct) / NULLIF(scpm.total_count, 0),
                (sp.cb_pto_pct + sp.gb_pto_pct) / 2
            ), 1)
        END AS uto_pto_count,
        CEIL(af.avail_fte_count -
            CASE
                WHEN af.period_date <= DATEADD(DAY, 14, CURRENT_DATE())
                THEN COALESCE(ap.pto_headcount, 0)
                ELSE ROUND(af.avail_fte_count * COALESCE(
                    (scpm.cb_count * sp.cb_pto_pct + scpm.gb_count * sp.gb_pto_pct) / NULLIF(scpm.total_count, 0),
                    (sp.cb_pto_pct + sp.gb_pto_pct) / 2
                ), 1)
            END
        ) AS projected_fte
    FROM available_fte af
    LEFT JOIN actual_pto ap ON af.period_date = ap.period_date
    LEFT JOIN static_pto sp ON UPPER(LEFT(TO_CHAR(af.period_date, 'MON'), 3)) = UPPER(LEFT(sp.MONTH, 3))
    LEFT JOIN staffing_category_pto_mapping scpm ON af.period_date = scpm.period_date
),

avg_cycle_time AS (
    SELECT
        ROUND(AVG(inv.CYCLE_TIME) / 60.0, 2) AS avg_cycle_time_min
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.CYCLE_TIME IS NOT NULL
        AND inv.PYSTATUSWORK IN ('Resolved-Completed')
        AND CASE
            WHEN (SELECT end_date FROM config) < CURRENT_DATE() THEN
                inv.PYRESOLVEDTIMESTAMP >= DATEADD(DAY, -90, (SELECT end_date FROM config))
                AND inv.PYRESOLVEDTIMESTAMP < DATEADD(DAY, 1, (SELECT end_date FROM config))
            ELSE
                inv.PYRESOLVEDTIMESTAMP >= DATEADD(DAY, -90, CURRENT_DATE())
                AND inv.PYRESOLVEDTIMESTAMP < DATEADD(DAY, 1, CURRENT_DATE())
        END
        {{lob_filter_cycle}}
        -- {{staffing_filter}}
        {{work_type_filter}}
        {{market_filter}}
),

projected_resolved AS (
    SELECT
        pf.period_date,
        pf.projected_fte,
        wd.working_days,
        (SELECT avg_productive_mins_per_day FROM productive_time) AS productive_mins_per_day,
        (SELECT avg_cycle_time_min FROM avg_cycle_time) AS avg_cycle_time_min,
        CASE
            WHEN (SELECT avg_cycle_time_min FROM avg_cycle_time) IS NULL OR (SELECT avg_cycle_time_min FROM avg_cycle_time) = 0 THEN 0
            ELSE ROUND(
                wd.working_days * ((SELECT avg_productive_mins_per_day FROM productive_time) * pf.projected_fte) / (SELECT avg_cycle_time_min FROM avg_cycle_time),
                0
            )
        END AS projected_resolved_count
    FROM projected_fte_calc pf
    INNER JOIN working_days_per_period wd ON pf.period_date = wd.period_date
    WHERE pf.projected_fte IS NOT NULL
)
SELECT
    (SELECT grouping_level FROM config) AS GROUPING_LEVEL,
    pr.period_date AS PERIOD_DATE,
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN TO_CHAR(pr.period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_CHAR(pr.period_date, 'YYYY-MM-DD')
        WHEN 'monthly' THEN TO_CHAR(pr.period_date, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_CHAR(pr.period_date, 'YYYY') || '-Q' || QUARTER(pr.period_date)
        WHEN 'yearly' THEN TO_CHAR(pr.period_date, 'YYYY')
    END AS PERIOD_LABEL,
    CASE 
        WHEN (SELECT grouping_level FROM config) = 'daily' AND EXISTS (SELECT 1 FROM holidays h WHERE h.holiday_date = pr.period_date) THEN NULL
        ELSE pr.projected_fte
    END AS PROJECTED_FTE,
    pr.working_days AS WORKING_DAYS,
    pr.productive_mins_per_day AS PRODUCTIVE_MINS_PER_DAY,
    pr.avg_cycle_time_min AS AVG_CYCLE_TIME_MIN,
    CASE 
        WHEN (SELECT grouping_level FROM config) = 'daily' AND EXISTS (SELECT 1 FROM holidays h WHERE h.holiday_date = pr.period_date) THEN NULL
        ELSE pr.projected_resolved_count
    END AS PROJECTED_RESOLVED
FROM projected_resolved pr
ORDER BY pr.period_date
"""


ACTUAL_RESOLVED_QUERY = f"""
WITH date_range_calc AS (
    SELECT
        '{{start_date}}'::DATE AS period_start,
        '{{end_date}}'::DATE AS period_end,
        '{{grouping_level}}' AS grouping_level
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        DATE(inv.PYRESOLVEDTIMESTAMP) AS resolved_date,
        DATE_TRUNC('WEEK', inv.PYRESOLVEDTIMESTAMP) AS week_start,
        DATE_TRUNC('MONTH', inv.PYRESOLVEDTIMESTAMP) AS month_start,
        DATE_TRUNC('QUARTER', inv.PYRESOLVEDTIMESTAMP) AS quarter_start,
        DATE_TRUNC('YEAR', inv.PYRESOLVEDTIMESTAMP) AS year_start,
        inv.PXCREATEDATETIME,
        inv.PYRESOLVEDTIMESTAMP,
        inv.PYSTATUSWORK,
        inv.INTAKESOURCESYSTEM,
        inv.LOB,
        inv.REPORTTOMANAGERID,
        inv.REPORTTODIRECTORID,
        inv.MARKET,
        inv.FUNDINGMODEL
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
aggregated_data AS (
    SELECT
        drc.grouping_level,
        CASE WHEN drc.grouping_level = 'daily' THEN id.resolved_date END AS period_date_daily,
        CASE WHEN drc.grouping_level = 'daily' THEN TO_CHAR(id.resolved_date, 'YYYY-MM-DD') END AS period_label_daily,
        CASE WHEN drc.grouping_level = 'weekly' THEN id.week_start END AS period_date_weekly,
        CASE WHEN drc.grouping_level = 'weekly' THEN TO_CHAR(id.week_start, 'YYYY-MM-DD') END AS period_label_weekly,
        CASE WHEN drc.grouping_level = 'monthly' THEN id.month_start END AS period_date_monthly,
        CASE WHEN drc.grouping_level = 'monthly' THEN LTRIM(TO_CHAR(id.month_start, 'MM/YYYY'), '0') END AS period_label_monthly,
        CASE WHEN drc.grouping_level = 'quarterly' THEN id.quarter_start END AS period_date_quarterly,
        CASE WHEN drc.grouping_level = 'quarterly' THEN CONCAT(TO_CHAR(id.quarter_start, 'YYYY'), '-Q', QUARTER(id.quarter_start)) END AS period_label_quarterly,
        CASE WHEN drc.grouping_level = 'yearly' THEN id.year_start END AS period_date_yearly,
        CASE WHEN drc.grouping_level = 'yearly' THEN TO_CHAR(id.year_start, 'YYYY') END AS period_label_yearly,
        id.PYID,
        id.PYSTATUSWORK
    FROM invntry_deduped id
    CROSS JOIN date_range_calc drc
    WHERE UPPER(TRIM(id.PYSTATUSWORK)) IN ('RESOLVED-COMPLETED', 'RESOLVED-AUTOCLOSELINK')
      AND id.PYRESOLVEDTIMESTAMP >= (SELECT period_start FROM date_range_calc)
      AND id.PYRESOLVEDTIMESTAMP < DATEADD(day, 1, (SELECT period_end FROM date_range_calc))
      AND DATE(id.PYRESOLVEDTIMESTAMP) <= CURRENT_DATE()
      AND id.PYRESOLVEDTIMESTAMP IS NOT NULL
      {{manager_filter}}
      {{lob_filter}}
      {{work_type_filter}}
      {{market_filter}}
      {{funding_model_filter}}
      {{staffing_filter_exists}}
)
SELECT
    grouping_level,
    COALESCE(period_date_daily, period_date_weekly, period_date_monthly, period_date_quarterly, period_date_yearly) AS period_date,
    COALESCE(period_label_daily, period_label_weekly, period_label_monthly, period_label_quarterly, period_label_yearly) AS period_label,
    COUNT(DISTINCT PYID) AS actual_resolved,
    COUNT(DISTINCT CASE WHEN UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-COMPLETED' THEN PYID END) AS resolved_completed,
    COUNT(DISTINCT CASE WHEN UPPER(TRIM(PYSTATUSWORK)) = 'RESOLVED-AUTOCLOSELINK' THEN PYID END) AS resolved_autocloselink
FROM aggregated_data
GROUP BY 
    grouping_level,
    COALESCE(period_date_daily, period_date_weekly, period_date_monthly, period_date_quarterly, period_date_yearly),
    COALESCE(period_label_daily, period_label_weekly, period_label_monthly, period_label_quarterly, period_label_yearly)
ORDER BY period_date
"""

ELEVANCE_AGE_QUERY = f"""
WITH all_age_buckets AS (
    SELECT '00-02' AS age_bucket, 1 AS bucket_order
    UNION ALL SELECT '03-05', 2
    UNION ALL SELECT '06-10', 3
    UNION ALL SELECT '11-15', 4
    UNION ALL SELECT '16-20', 5
    UNION ALL SELECT '21-30', 6
    UNION ALL SELECT '31-60', 7
    UNION ALL SELECT '61+', 8
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.COMPANYRECEIVEDDATE,
        DATE(inv.COMPANYRECEIVEDDATE) AS company_received_date,
        inv.PYSTATUSWORK,
        inv.INTAKESOURCESYSTEM,
        inv.LOB,
        inv.REPORTTOMANAGERID,
        inv.REPORTTODIRECTORID,
        inv.MARKET,
        inv.PYRESOLVEDTIMESTAMP,
        DATEDIFF(day, DATE(inv.COMPANYRECEIVEDDATE), CURRENT_DATE()) AS age_days
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
case_age_buckets AS (
    SELECT
        PYID,
        age_days,
        CASE
            WHEN age_days < 0 THEN 'Future'
            WHEN age_days BETWEEN 0 AND 2 THEN '00-02'
            WHEN age_days BETWEEN 3 AND 5 THEN '03-05'
            WHEN age_days BETWEEN 6 AND 10 THEN '06-10'
            WHEN age_days BETWEEN 11 AND 15 THEN '11-15'
            WHEN age_days BETWEEN 16 AND 20 THEN '16-20'
            WHEN age_days BETWEEN 21 AND 30 THEN '21-30'
            WHEN age_days BETWEEN 31 AND 60 THEN '31-60'
            WHEN age_days >= 61 THEN '61+'
            ELSE 'Unknown'
        END AS age_bucket
    FROM invntry_deduped
    WHERE PYRESOLVEDTIMESTAMP is null
      AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 'Open-ReviewIntake', 'Pend', 'Pend-Decision')
      {{manager_filter}}
      {{lob_filter}}
      {{work_type_filter}}
      {{market_filter}}
)
SELECT
    aab.age_bucket,
    COALESCE(COUNT(DISTINCT cab.PYID), 0) AS case_count,
    aab.bucket_order,
    'elevance' AS age_type
FROM all_age_buckets aab
LEFT JOIN case_age_buckets cab
    ON aab.age_bucket = cab.age_bucket
GROUP BY aab.age_bucket, aab.bucket_order
ORDER BY aab.bucket_order
"""

COB_AGE_QUERY = f"""
WITH all_age_buckets AS (
    SELECT '00-02' AS age_bucket, 1 AS bucket_order
    UNION ALL SELECT '03-05', 2
    UNION ALL SELECT '06-10', 3
    UNION ALL SELECT '11-15', 4
    UNION ALL SELECT '16-20', 5
    UNION ALL SELECT '21-30', 6
    UNION ALL SELECT '31-60', 7
    UNION ALL SELECT '61+', 8
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PXCREATEDATETIME,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        inv.PYSTATUSWORK,
        inv.INTAKESOURCESYSTEM,
        inv.LOB,
        inv.REPORTTOMANAGERID,
        inv.REPORTTODIRECTORID,
        inv.MARKET,
        inv.PYRESOLVEDTIMESTAMP,
        DATEDIFF(day, DATE(inv.PXCREATEDATETIME), CURRENT_DATE()) AS age_days
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
case_age_buckets AS (
    SELECT
        PYID,
        age_days,
        CASE
            WHEN age_days < 0 THEN 'Future'
            WHEN age_days BETWEEN 0 AND 2 THEN '00-02'
            WHEN age_days BETWEEN 3 AND 5 THEN '03-05'
            WHEN age_days BETWEEN 6 AND 10 THEN '06-10'
            WHEN age_days BETWEEN 11 AND 15 THEN '11-15'
            WHEN age_days BETWEEN 16 AND 20 THEN '16-20'
            WHEN age_days BETWEEN 21 AND 30 THEN '21-30'
            WHEN age_days BETWEEN 31 AND 60 THEN '31-60'
            WHEN age_days >= 61 THEN '61+'
            ELSE 'Unknown'
        END AS age_bucket
    FROM invntry_deduped
    WHERE PYRESOLVEDTIMESTAMP is null
      AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 'Open-ReviewIntake', 'Pend', 'Pend-Decision')
      {{manager_filter}}
      {{lob_filter}}
      {{work_type_filter}}
      {{market_filter}}
)
SELECT
    aab.age_bucket,
    COALESCE(COUNT(DISTINCT cab.PYID), 0) AS case_count,
    aab.bucket_order,
    'cob' AS age_type
FROM all_age_buckets aab
LEFT JOIN case_age_buckets cab
    ON aab.age_bucket = cab.age_bucket
GROUP BY aab.age_bucket, aab.bucket_order
ORDER BY aab.bucket_order
"""



ELEVANCE_AGE_DRILLDOWN_QUERY = f"""
WITH user_names AS (
    SELECT USERID, FIRSTNAME, LASTNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC NULLS LAST) AS urn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.COMPANYRECEIVEDDATE,
        DATE(inv.COMPANYRECEIVEDDATE) AS elevance_date,
        inv.PXCREATEDATETIME,
        DATE(inv.PXCREATEDATETIME) AS cob_date,
        inv.PYSTATUSWORK,
        inv.INTAKESOURCESYSTEM,
        inv.LOB,
        inv.REPORTTOMANAGERID,
        inv.REPORTTOMANAGERNAME,
        inv.MARKET,
        inv.FUNDINGMODEL,
        inv.ASSIGNEDTO,
        inv.PYRESOLVEDTIMESTAMP,
        inv.PRIORITY,
        DATEDIFF(day, DATE(inv.COMPANYRECEIVEDDATE), CURRENT_DATE()) AS age_days
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
age_classified AS (
    SELECT
        PYID,
        age_days,
        elevance_date,
        cob_date,
        PYSTATUSWORK,
        INTAKESOURCESYSTEM,
        LOB,
        REPORTTOMANAGERID,
        REPORTTOMANAGERNAME,
        MARKET,
        FUNDINGMODEL,
        ASSIGNEDTO,
        PRIORITY,
        CASE
            WHEN age_days < 0 THEN 'Future'
            WHEN age_days BETWEEN 0 AND 2 THEN '00-02'
            WHEN age_days BETWEEN 3 AND 5 THEN '03-05'
            WHEN age_days BETWEEN 6 AND 10 THEN '06-10'
            WHEN age_days BETWEEN 11 AND 15 THEN '11-15'
            WHEN age_days BETWEEN 16 AND 20 THEN '16-20'
            WHEN age_days BETWEEN 21 AND 30 THEN '21-30'
            WHEN age_days BETWEEN 31 AND 60 THEN '31-60'
            WHEN age_days >= 61 THEN '61+'
            ELSE 'Unknown'
        END AS age_bucket
    FROM invntry_deduped
    WHERE PYRESOLVEDTIMESTAMP is null
      AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 'Open-ReviewIntake', 'Pend', 'Pend-Decision')
      {{lob_filter}}
      {{work_type_filter}}
      {{manager_filter}}
      {{market_filter}}
      {{funding_model_filter}}
)
SELECT
    ac.age_days AS DATA_AGED,
    ac.PYID AS WORK_ITEM,
    ac.age_bucket AS AGE_BUCKET,
    COALESCE(ac.PRIORITY, 'None') AS DRILLING,
    ac.INTAKESOURCESYSTEM AS INTAKE_SOURCE,
    ac.cob_date AS COB_CREATE_DATE,
    ac.elevance_date AS ELEVANCE_RECEIVED_DATE,
    COALESCE(usr.FIRSTNAME || ' ' || usr.LASTNAME, ac.ASSIGNEDTO) AS ASSIGNED_TO,
    ac.PYSTATUSWORK AS STATUS,
    ac.LOB,
    ac.MARKET,
    ac.FUNDINGMODEL,
    ac.REPORTTOMANAGERNAME AS MANAGER_NAME,
    COALESCE(ac.PRIORITY, 'None') AS PRIORITY
FROM age_classified ac
LEFT JOIN user_names usr
    ON UPPER(TRIM(ac.ASSIGNEDTO)) = UPPER(TRIM(usr.USERID)) AND usr.urn = 1
WHERE ac.age_bucket IN ({{age_buckets}})
ORDER BY ac.age_days DESC, ac.PYID
"""

COB_AGE_DRILLDOWN_QUERY = f"""
WITH user_names AS (
    SELECT USERID, FIRSTNAME, LASTNAME,
        ROW_NUMBER() OVER (PARTITION BY USERID ORDER BY PXUPDATEDATETIME DESC NULLS LAST) AS urn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.COMPANYRECEIVEDDATE,
        DATE(inv.COMPANYRECEIVEDDATE) AS elevance_date,
        inv.PXCREATEDATETIME,
        DATE(inv.PXCREATEDATETIME) AS cob_date,
        inv.PYSTATUSWORK,
        inv.INTAKESOURCESYSTEM,
        inv.LOB,
        inv.REPORTTOMANAGERID,
        inv.REPORTTOMANAGERNAME,
        inv.MARKET,
        inv.FUNDINGMODEL,
        inv.ASSIGNEDTO,
        inv.PYRESOLVEDTIMESTAMP,
        inv.PRIORITY,
        DATEDIFF(day, DATE(inv.PXCREATEDATETIME), CURRENT_DATE()) AS age_days
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
age_classified AS (
    SELECT
        PYID,
        age_days,
        elevance_date,
        cob_date,
        PYSTATUSWORK,
        INTAKESOURCESYSTEM,
        LOB,
        REPORTTOMANAGERID,
        REPORTTOMANAGERNAME,
        MARKET,
        FUNDINGMODEL,
        ASSIGNEDTO,
        PRIORITY,
        CASE
            WHEN age_days < 0 THEN 'Future'
            WHEN age_days BETWEEN 0 AND 2 THEN '00-02'
            WHEN age_days BETWEEN 3 AND 5 THEN '03-05'
            WHEN age_days BETWEEN 6 AND 10 THEN '06-10'
            WHEN age_days BETWEEN 11 AND 15 THEN '11-15'
            WHEN age_days BETWEEN 16 AND 20 THEN '16-20'
            WHEN age_days BETWEEN 21 AND 30 THEN '21-30'
            WHEN age_days BETWEEN 31 AND 60 THEN '31-60'
            WHEN age_days >= 61 THEN '61+'
            ELSE 'Unknown'
        END AS age_bucket
    FROM invntry_deduped
    WHERE PYRESOLVEDTIMESTAMP is null
      AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 'Open-ReviewIntake', 'Pend', 'Pend-Decision')
      {{manager_filter}}
      {{lob_filter}}
      {{work_type_filter}}
      {{market_filter}}
      {{funding_model_filter}}
)
SELECT
    ac.age_days AS DATA_AGED,
    ac.PYID AS WORK_ITEM,
    ac.age_bucket AS AGE_BUCKET,
    COALESCE(ac.PRIORITY, 'None') AS DRILLING,
    ac.INTAKESOURCESYSTEM AS INTAKE_SOURCE,
    ac.cob_date AS COB_CREATE_DATE,
    ac.elevance_date AS ELEVANCE_RECEIVED_DATE,
    COALESCE(usr.FIRSTNAME || ' ' || usr.LASTNAME, ac.ASSIGNEDTO) AS ASSIGNED_TO,
    ac.PYSTATUSWORK AS STATUS,
    ac.LOB,
    ac.MARKET,
    ac.FUNDINGMODEL,
    ac.REPORTTOMANAGERNAME AS MANAGER_NAME,
    COALESCE(ac.PRIORITY, 'None') AS PRIORITY
FROM age_classified ac
LEFT JOIN user_names usr
    ON UPPER(TRIM(ac.ASSIGNEDTO)) = UPPER(TRIM(usr.USERID)) AND usr.urn = 1
WHERE ac.age_bucket IN ({{age_buckets}})
ORDER BY ac.age_days DESC, ac.PYID
"""

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def build_date_filter(start_date: Optional[str] = None, end_date: Optional[str] = None, date_column: str = "PXCREATEDATETIME") -> str:
    """Build date filter for SQL queries with flexible date column.
    
    Args:
        start_date: Start date in YYYY-MM-DD format
        end_date: End date in YYYY-MM-DD format
        date_column: Column name to filter on (default: PXCREATEDATETIME)
    
    Returns:
        SQL filter string
    """
    if start_date and end_date:
        return (
            f"AND {date_column} >= '{start_date}' "
            f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
        )
    elif start_date:
        return f"AND {date_column} >= '{start_date}'"
    elif end_date:
        return f"AND {date_column} < DATEADD(day, 1, '{end_date}'::DATE)"
    return ""

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for SQL queries.
    
    Handles 'None' string to match NULL values in database.
    
    Args:
        lob: List of LOB values to filter
    
    Returns:
        SQL filter string
    """
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l.upper() for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (UPPER(TRIM(inv.LOB)) IN ('{lob_values}') OR inv.LOB IS NULL)"
    elif null_requested:
        return "AND inv.LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND UPPER(TRIM(inv.LOB)) IN ('{lob_values}')"

def build_staffing_category_filter(staffing_category: Optional[List[str]] = None, table_alias: str = "usr", use_derived: bool = False) -> str:
    """Build staffing category filter for SQL queries.
    
    Args:
        staffing_category: List of staffing categories to filter
        table_alias: Table alias for STAFFINGCATEGORY column (default: usr)
        use_derived: If True, uses derived_staffing_category from crosswalk join (default: False)
    
    Returns:
        SQL filter string
    """
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    null_requested = "None" in staffing_category
    non_null_categories = [c for c in staffing_category if c != "None"]
    
    # Determine column name based on use_derived flag
    column_name = "derived_staffing_category" if use_derived else f"{table_alias}.STAFFINGCATEGORY"
    
    if null_requested and non_null_categories:
        category_values = "', '".join(non_null_categories)
        return f"AND ({column_name} IN ('{category_values}') OR {column_name} IS NULL)"
    elif null_requested:
        return f"AND {column_name} IS NULL"
    else:
        category_values = "', '".join(non_null_categories)
        return f"AND {column_name} IN ('{category_values}')"

def build_work_type_filter(work_type: Optional[List[str]] = None) -> str:
    """Build work type filter for SQL queries.
    
    Handles 'None' string to match NULL values in database.
    
    Args:
        work_type: List of work types (INTAKESOURCESYSTEM) to filter
    
    Returns:
        SQL filter string
    """
    if not work_type or len(work_type) == 0:
        return ""
    
    null_requested = "None" in work_type
    non_null_types = [wt.upper() for wt in work_type if wt != "None"]
    
    if null_requested and non_null_types:
        work_type_values = "', '".join(non_null_types)
        return f"AND (UPPER(inv.INTAKESOURCESYSTEM) IN ('{work_type_values}') OR inv.INTAKESOURCESYSTEM IS NULL)"
    elif null_requested:
        return "AND inv.INTAKESOURCESYSTEM IS NULL"
    else:
        work_type_values = "', '".join(non_null_types)
        return f"AND UPPER(inv.INTAKESOURCESYSTEM) IN ('{work_type_values}')"


def build_receipts_work_type_filter(work_type: Optional[List[str]] = None, column_prefix: str = "") -> str:
    """Build work type filter for receipts calculations (actual and projected).
    
    Always excludes 'Facets Pend' and 'CCERT' from receipts calculations
    as these intake sources should not be included in receipts metrics.
    
    Args:
        work_type: List of work types (INTAKESOURCESYSTEM) to filter
        column_prefix: Optional column prefix (e.g., 'cy.', 'py.') for the INTAKESOURCESYSTEM column
    
    Returns:
        SQL filter string with exclusions
    """
    # Define sources to always exclude from receipts calculations
    excluded_sources = ['FACETS PEND', 'CCERT']
    
    col_name = f"{column_prefix}INTAKESOURCESYSTEM" if column_prefix else "INTAKESOURCESYSTEM"
    
    if not work_type or len(work_type) == 0:
        # No user filter - just exclude unwanted sources
        excluded_list = "', '".join(excluded_sources)
        return f"AND COALESCE(UPPER({col_name}), 'None') NOT IN ('{excluded_list}')"
    
    # Filter out excluded sources from user selections
    null_requested = "None" in work_type
    non_null_types = [wt.upper() for wt in work_type if wt != "None" and wt.upper() not in excluded_sources]
    
    if not non_null_types and not null_requested:
        # User only selected excluded sources - return filter that excludes them
        excluded_list = "', '".join(excluded_sources)
        return f"AND COALESCE(UPPER({col_name}), 'None') NOT IN ('{excluded_list}')"
    
    # Build filter with valid types AND exclusion of unwanted sources
    excluded_list = "', '".join(excluded_sources)
    
    if null_requested and non_null_types:
        work_type_values = "', '".join(non_null_types)
        return f"AND (UPPER({col_name}) IN ('{work_type_values}') OR {col_name} IS NULL) AND COALESCE(UPPER({col_name}), 'None') NOT IN ('{excluded_list}')"
    elif null_requested:
        return f"AND {col_name} IS NULL AND COALESCE(UPPER({col_name}), 'None') NOT IN ('{excluded_list}')"
    else:
        work_type_values = "', '".join(non_null_types)
        return f"AND UPPER({col_name}) IN ('{work_type_values}') AND COALESCE(UPPER({col_name}), 'None') NOT IN ('{excluded_list}')"

def build_market_filter(market: Optional[List[str]] = None) -> str:
    """Build market filter for SQL queries.
    
    Handles 'None' string to match NULL values in database.
    
    Args:
        market: List of markets to filter
    
    Returns:
        SQL filter string
    """
    if not market or len(market) == 0:
        return ""
    
    null_requested = "None" in market
    non_null_markets = [m for m in market if m != "None"]
    
    if null_requested and non_null_markets:
        market_values = "', '".join(non_null_markets)
        return f"AND (inv.MARKET IN ('{market_values}') OR inv.MARKET IS NULL)"
    elif null_requested:
        return "AND inv.MARKET IS NULL"
    else:
        market_values = "', '".join(non_null_markets)
        return f"AND inv.MARKET IN ('{market_values}')"

def build_manager_filter(manager_ids: Optional[List[str]] = None, column: str = "REPORTTOMANAGERID") -> str:
    """Build manager filter for inventory table.
    
    Handles 'None' string to match NULL values in database.
    
    Args:
        manager_ids: List of manager IDs to filter
        column: Column name for manager ID (default: REPORTTOMANAGERID)
    
    Returns:
        SQL filter string
    """
    if not manager_ids or len(manager_ids) == 0:
        return ""
    
    null_requested = "None" in manager_ids
    non_null_managers = [m for m in manager_ids if m != "None"]
    
    if null_requested and non_null_managers:
        manager_ids_str = "', '".join([m.upper() for m in non_null_managers])
        return f"AND (UPPER(TRIM(inv.{column})) IN ('{manager_ids_str}') OR inv.{column} IS NULL)"
    elif null_requested:
        return f"AND inv.{column} IS NULL"
    else:
        manager_ids_str = "', '".join([m.upper() for m in manager_ids])
        return f"AND UPPER(TRIM(inv.{column})) IN ('{manager_ids_str}')"

def build_funding_model_filter(funding_model: Optional[List[str]] = None) -> str:
    """Build funding model filter for SQL queries.
    
    Handles 'None' string to match NULL values in database.
    
    Args:
        funding_model: List of funding models to filter
    
    Returns:
        SQL filter string
    """
    if not funding_model or len(funding_model) == 0:
        return ""
    
    null_requested = "None" in funding_model
    non_null_models = [fm for fm in funding_model if fm != "None"]
    
    if null_requested and non_null_models:
        funding_model_values = "', '".join(non_null_models)
        return f"AND (inv.FUNDINGMODEL IN ('{funding_model_values}') OR inv.FUNDINGMODEL IS NULL)"
    elif null_requested:
        return "AND inv.FUNDINGMODEL IS NULL"
    else:
        funding_model_values = "', '".join(non_null_models)
        return f"AND inv.FUNDINGMODEL IN ('{funding_model_values}')"

def build_work_type_selection(work_type: Optional[List[str]]) -> str:
    """Build work type selection CTE SQL.
    
    Behavior:
    - None/null: Return all work types from database (no filter applied)
    - Empty list []: Return empty set (explicitly unselected all, show zeros)
    - List with values: Return only selected work types
    """
    # Case 1: None/null - no filter applied, show all work types
    if work_type is None:
        return f"""
        SELECT DISTINCT COALESCE(TRIM(INTAKESOURCESYSTEM), 'None') AS work_type
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        """
    
    # Case 2: Empty list [] - explicitly unselected all, show zeros
    if len(work_type) == 0:
        return "SELECT NULL AS work_type WHERE 1=0"
    
    # Case 3: Specific work types selected
    work_type_unions = []
    for i, wt in enumerate(work_type):
        if i == 0:
            work_type_unions.append(f"SELECT '{wt}' AS work_type")
        else:
            work_type_unions.append(f"SELECT '{wt}'")
    
    return " UNION ".join(work_type_unions)

def build_market_selection(market: Optional[List[str]]) -> str:
    """Build market selection CTE SQL.
    
    Behavior:
    - None/null: Return all markets from database (no filter applied)
    - Empty list []: Return empty set (explicitly unselected all, show zeros)
    - List with values: Return only selected markets
    """
    # Case 1: None/null - no filter applied, show all markets
    if market is None:
        return f"""
        SELECT DISTINCT COALESCE(TRIM(MARKET), 'None') AS market
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        """
    
    # Case 2: Empty list [] - explicitly unselected all, show zeros
    if len(market) == 0:
        return "SELECT NULL AS market WHERE 1=0"
    
    # Case 3: Specific markets selected
    market_unions = []
    for i, mkt in enumerate(market):
        if i == 0:
            market_unions.append(f"SELECT '{mkt}' AS market")
        else:
            market_unions.append(f"SELECT '{mkt}'")
    
    return " UNION ".join(market_unions)


async def warm_age_caches(request: ReceiptsAgeRequest) -> Dict[str, Any]:
    """
    Warm receipts age cache with bucket counts.
    
    Executes receipts age count queries for Elevance and COB age buckets,
    then returns results for session caching.
    
    Args:
        request: ReceiptsAgeRequest with filter parameters
        
    Returns:
        Dictionary with age_response
    """
    try:
        logger.info("Starting age cache warming")
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        
        # Create no-prefix versions for queries
        lob_filter_no_prefix = lob_filter.replace('inv.', '') if lob_filter else ''
        work_type_filter_no_prefix = work_type_filter.replace('inv.', '') if work_type_filter else ''
        manager_filter_no_prefix = manager_filter.replace('inv.', '') if manager_filter else ''
        market_filter_no_prefix = market_filter.replace('inv.', '') if market_filter else ''
        
        engine = connection_manager.get_engine()
        
        # Build age count queries
        elevance_query = ELEVANCE_AGE_QUERY.format(
            lob_filter=lob_filter_no_prefix,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix
        )
        
        cob_query = COB_AGE_QUERY.format(
            lob_filter=lob_filter_no_prefix,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix
        )
        
        # Execute both age count queries in parallel
        elevance_results, cob_results = await asyncio.gather(
            engine.execute_query_async(elevance_query, 1000),
            engine.execute_query_async(cob_query, 1000)
        )
        
        # Process age bucket results
        elevance_age_raw = [dict(row) for row in elevance_results]
        cob_age_raw = [dict(row) for row in cob_results]
        
        elevance_age_raw.sort(key=lambda x: x.get('BUCKET_ORDER', 0), reverse=True)
        cob_age_raw.sort(key=lambda x: x.get('BUCKET_ORDER', 0), reverse=True)
        
        elevance_age = [{k: v for k, v in item.items() if k != 'BUCKET_ORDER'} for item in elevance_age_raw]
        cob_age = [{k: v for k, v in item.items() if k != 'BUCKET_ORDER'} for item in cob_age_raw]
        
        # Create response object
        age_response = {
            "status": "success",
            "elevance_age": elevance_age,
            "cob_age": cob_age,
            "message": "Receipts age data retrieved successfully",
            "service": "idiscovery-cob-dashboard-service"
        }
        
        logger.info(f"Successfully warmed age cache: {len(elevance_age)} elevance buckets, {len(cob_age)} cob buckets")
        
        return {
            "age_response": age_response
        }
        
    except Exception as e:
        logger.error(f"Error warming age caches: {e}", exc_info=True)
        raise


# ============================================================================
# API ENDPOINTS
# ============================================================================

@router.post("/source-type-breakdown", response_model=SourceTypeBreakdownResponse, summary="Get Source Type Breakdown")
async def get_source_type_breakdown(request: SourceTypeBreakdownRequest):
    """
    Get source type breakdown (pie chart data).
    
    Returns work type distribution with counts and percentages.
    
    **Filters:**
    - start_date, end_date: Date range filter
    - lob: Line of Business filter
    - staffing_category: Staffing category filter
    - work_type: Work type filter (INTAKESOURCESYSTEM)
    - manager: Manager IDs filter
    - market: Market filter
    - funding_model: Funding model filter
    
    **Returns:**
    - work_type: Work type name
    - case_count: Number of cases
    - percentage: Percentage of total
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Build filters
        date_filter = build_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(request.lob)
        staffing_filter = build_staffing_category_filter(request.staffing_category, use_derived=True)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        funding_model_filter = build_funding_model_filter(getattr(request, 'funding_model', None))
        work_type_selection = build_work_type_selection(request.work_type)
        work_type_filter = build_work_type_filter(request.work_type)
        
        # Create d. prefix versions for filtered_data CTE (selecting from invntry_deduped aliased as 'd')
        manager_filter_no_prefix = manager_filter.replace('inv.', 'd.') if manager_filter else ''
        lob_filter_no_prefix = lob_filter.replace('inv.', 'd.') if lob_filter else ''
        market_filter_no_prefix = market_filter.replace('inv.', 'd.') if market_filter else ''
        funding_model_filter_no_prefix = funding_model_filter.replace('inv.', 'd.') if funding_model_filter else ''
        work_type_filter_no_prefix = work_type_filter.replace('inv.', 'd.') if work_type_filter else ''
        staffing_filter_xwalk = staffing_filter.replace('derived_staffing_category', 'xwalk.STAFFING_CATEGORY') if staffing_filter else ''
        date_filter_d_prefix = date_filter.replace('PXCREATEDATETIME', 'd.PXCREATEDATETIME') if date_filter else ''
        
        # Build conditional EXISTS clause for staffing filter
        if staffing_filter_xwalk:
            staffing_filter_exists = f"""AND EXISTS (
          SELECT 1
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
          WHERE TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(d.INTAKESOURCESYSTEM))
            {staffing_filter_xwalk}
      )"""
        else:
            staffing_filter_exists = ""
        
        # Format query
        query = SOURCE_TYPE_BREAKDOWN_QUERY.format(
            end_date=request.end_date,
            lob_filter=lob_filter_no_prefix,
            staffing_filter_exists=staffing_filter_exists,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix,
            funding_model_filter=funding_model_filter_no_prefix,
            work_type_selection=work_type_selection,
            work_type_filter=work_type_filter_no_prefix
        )

        # Execute query
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000000)
        
        # Format response and combine -DUP variants only
        combined_data = {}
        detail_mapping = {}
        
        for row in results:
            row_dict = dict(row)
            source_type = row_dict.get("SOURCE_TYPE", "")
            case_count = row_dict.get("CASE_COUNT", 0)
            percentage = row_dict.get("PERCENTAGE", 0.0)
            
            # Only combine entries ending with -DUP (not other variants like -NEWBORN)
            if source_type.upper().endswith('-DUP'):
                base_name = source_type[:-4].strip()  # Remove last 4 characters ("-DUP")
            else:
                base_name = source_type.strip()
            
            # Store detailed entry
            if base_name not in detail_mapping:
                detail_mapping[base_name] = []
            detail_mapping[base_name].append({
                "SOURCE_TYPE": source_type,
                "CASE_COUNT": case_count,
                "PERCENTAGE": f"{percentage:.2f}"
            })
            
            # Combine counts and percentages for same base name
            if base_name in combined_data:
                combined_data[base_name]["CASE_COUNT"] += case_count
                combined_data[base_name]["PERCENTAGE"] += percentage
            else:
                combined_data[base_name] = {
                    "SOURCE_TYPE": base_name,
                    "CASE_COUNT": case_count,
                    "PERCENTAGE": percentage,
                    "details": []
                }
        
        # Add detailed breakdown to each combined entry
        for base_name, combined_entry in combined_data.items():
            combined_entry["details"] = detail_mapping.get(base_name, [])
        
        # Convert to list and sort by percentage descending
        data = list(combined_data.values())
        data.sort(key=lambda x: (x.get("PERCENTAGE", 0), x.get("SOURCE_TYPE", "")), reverse=True)
        
        return SourceTypeBreakdownResponse(
            status="success",
            data=data,
            total_count=sum(item.get("CASE_COUNT", 0) for item in data),
            message="Source type breakdown retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_source_type_breakdown: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/inventory-by-market", response_model=InventoryByMarketResponse, summary="Get Inventory by Market")
async def get_inventory_by_market(request: InventoryByMarketRequest):
    """
    Get inventory by market (bar chart data).
    
    Returns case counts by market.
    
    **Filters:**
    - start_date, end_date: Date range filter
    - lob: Line of Business filter
    - staffing_category: Staffing category filter
    - work_type: Work type filter
    - manager: Manager IDs filter
    - market: Market filter
    - funding_model: Funding model filter
    
    **Returns:**
    - market: Market name
    - case_count: Number of cases
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Build filters
        date_filter = build_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(request.lob)
        staffing_filter = build_staffing_category_filter(request.staffing_category, use_derived=True)
        work_type_filter = build_work_type_filter(request.work_type)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        funding_model_filter = build_funding_model_filter(getattr(request, 'funding_model', None))
        market_selection = build_market_selection(getattr(request, 'market', None))
        
        # Create d. prefix versions for filtered_data CTE (selecting from invntry_deduped aliased as 'd')
        manager_filter_no_prefix = manager_filter.replace('inv.', 'd.') if manager_filter else ''
        lob_filter_no_prefix = lob_filter.replace('inv.', 'd.') if lob_filter else ''
        work_type_filter_no_prefix = work_type_filter.replace('inv.', 'd.') if work_type_filter else ''
        funding_model_filter_no_prefix = funding_model_filter.replace('inv.', 'd.') if funding_model_filter else ''
        staffing_filter_xwalk = staffing_filter.replace('derived_staffing_category', 'xwalk.STAFFING_CATEGORY') if staffing_filter else ''
        date_filter_d_prefix = date_filter.replace('PXCREATEDATETIME', 'd.PXCREATEDATETIME') if date_filter else ''
        
        # Build conditional EXISTS clause for staffing filter
        if staffing_filter_xwalk:
            staffing_filter_exists = f"""AND EXISTS (
          SELECT 1
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
          WHERE TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(d.INTAKESOURCESYSTEM))
            {staffing_filter_xwalk}
      )"""
        else:
            staffing_filter_exists = ""
        
        # Format query
        query = INVENTORY_BY_MARKET_QUERY.format(
            end_date=request.end_date,
            lob_filter=lob_filter_no_prefix,
            staffing_filter_exists=staffing_filter_exists,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            funding_model_filter=funding_model_filter_no_prefix,
            market_selection=market_selection
        )
        # Execute query
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000000)
        
        # Format response and sort by percentage descending
        data = [dict(row) for row in results]
        data.sort(key=lambda x: (x.get("PERCENTAGE", 0), x.get("MARKET", "")), reverse=True)
        
        return InventoryByMarketResponse(
            status="success",
            data=data,
            total_count=sum(item.get("CASE_COUNT", 0) for item in data),
            message="Inventory by market retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_inventory_by_market: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/trend-analysis", response_model=TrendAnalysisResponse, summary="Get Trend Analysis & Recommendation")
async def get_trend_analysis(request: TrendAnalysisRequest):
    """
    Get trend analysis and recommendations.
    
    Returns trend analysis summary.
    
    **Filters:**
    - start_date, end_date: Date range filter
    - lob: Line of Business filter
    - staffing_category: Staffing category filter
    - work_type: Work type filter
    
    **Returns:**
    - summary: Trend analysis summary (currently set to "N/A")
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # For now, return N/A as summary
        return TrendAnalysisResponse(
            status="success",
            summary="N/A",
            message="Trend analysis retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_trend_analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


def build_age_bucket_filter(age_buckets: Optional[List[str]]) -> str:
    """Build age bucket filter for drilldown queries.
    
    Args:
        age_buckets: List of age buckets to filter (e.g., ['00-02', '31-60'])
    
    Returns:
        SQL IN clause with age buckets
    """
    if not age_buckets or len(age_buckets) == 0:
        return "'00-02', '03-05', '06-10', '11-15', '16-20', '21-30', '31-60', '61+'"
    
    # Quote each bucket for SQL
    quoted_buckets = [f"'{bucket}'" for bucket in age_buckets]
    return ", ".join(quoted_buckets)


@router.post("/elevance-age-drilldown", response_model=AgeDrilldownResponse, summary="Get Elevance Age Drilldown Details")
async def get_elevance_age_drilldown(request: AgeDrilldownRequest):
    """
    Get detailed drilldown data for Elevance Age buckets.
    
    Returns individual work items within selected age buckets based on COMPANYRECEIVEDDATE.
    
    **Filters:**
    - age_buckets: List of age buckets to drill into (e.g., ['00-02', '31-60'])
    - lob: Line of Business filter
    - work_type: Work type filter
    - manager: Manager IDs filter
    - market: Market filter
    - funding_model: Funding model filter
    
    **Returns:**
    - data: List of work items with details
    - total_count: Total number of records
    - age_buckets: Age buckets selected
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        import time
        start_time = time.time()
        
        logger.info("Elevance age drilldown request started")
        
        # Build filters
        filter_start = time.time()
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        funding_model_filter = build_funding_model_filter(getattr(request, 'funding_model', None))
        age_bucket_filter = build_age_bucket_filter(request.age_buckets)
        
        # Create no-prefix versions for age_classified CTE (selecting from invntry_deduped)
        lob_filter_no_prefix = lob_filter.replace('inv.', '') if lob_filter else ''
        work_type_filter_no_prefix = work_type_filter.replace('inv.', '') if work_type_filter else ''
        manager_filter_no_prefix = manager_filter.replace('inv.', '') if manager_filter else ''
        market_filter_no_prefix = market_filter.replace('inv.', '') if market_filter else ''
        funding_model_filter_no_prefix = funding_model_filter.replace('inv.', '') if funding_model_filter else ''
        filter_duration = (time.time() - filter_start) * 1000
        logger.debug(f"Filter building completed in {filter_duration:.2f}ms")
        
        # Format query
        query = ELEVANCE_AGE_DRILLDOWN_QUERY.format(
            lob_filter=lob_filter_no_prefix,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix,
            funding_model_filter=funding_model_filter_no_prefix,
            age_buckets=age_bucket_filter
        )
        
        # Calculate pagination parameters for Snowflake query
        page = request.page or 1
        page_size = request.page_size or 100
        offset = (page - 1) * page_size
        
        # Get engine instance
        engine = connection_manager.get_engine()
        
        # Get real-time count for accurate pagination (don't rely on cached counts)
        count_query = f"SELECT COUNT(*) as total FROM ({query}) AS subquery"
        count_start = time.time()
        logger.debug(f"Executing COUNT query for pagination")
        count_results = await engine.execute_query_async(count_query, limit=1)
        filtered_count = count_results[0]['TOTAL'] if count_results else 0
        count_duration = (time.time() - count_start) * 1000
        logger.debug(f"COUNT query completed in {count_duration:.2f}ms - Filtered count: {filtered_count}")
        
        # Add LIMIT and OFFSET to query for efficient pagination at database level
        paginated_query = f"{query} LIMIT {page_size} OFFSET {offset}"
        
        # Execute paginated query (only fetch requested page)
        query_start = time.time()
        logger.info(f"Executing Elevance age drilldown Snowflake query (page {page}, size {page_size}, offset {offset})")
        results = await engine.execute_query_async(paginated_query, limit=page_size)
        query_duration = (time.time() - query_start) * 1000
        result_count = len(results) if results else 0
        logger.info(f"Snowflake query completed in {query_duration:.2f}ms - Retrieved {result_count} rows for page {page}")
        
        # Format response and replace NULL values with 'N/A'
        processing_start = time.time()
        data = []
        for row in results:
            row_dict = dict(row)
            # Replace None/NULL values with 'N/A'
            for key, value in row_dict.items():
                if value is None:
                    row_dict[key] = 'N/A'
            data.append(row_dict)
        processing_duration = (time.time() - processing_start) * 1000
        logger.debug(f"Data processing completed in {processing_duration:.2f}ms")
        
        # Get age bucket counts from cached receipts-age response if available
        age_bucket_counts = {}
        session_id = getattr(request, 'session_id', None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict for cache isolation (must match receipts-age filters)
                filters = {
                    'lob': request.lob,
                    'work_type': request.work_type,
                    'manager': getattr(request, 'manager', None),
                    'market': getattr(request, 'market', None)
                }
                
                cached_age_response = await workforce_session_cache_service.get_cached_result(
                    session_id=session_id,
                    endpoint_name="receipts_age",
                    filters=filters
                )
                
                if cached_age_response and isinstance(cached_age_response, dict):
                    # Extract elevance_age counts from cached response
                    elevance_age = cached_age_response.get("elevance_age", [])
                    for bucket_data in elevance_age:
                        bucket = bucket_data.get("AGE_BUCKET")
                        count = bucket_data.get("CASE_COUNT", 0)
                        if bucket:
                            age_bucket_counts[bucket] = count
                    logger.info(f"Using age bucket counts from cached receipts-age for Elevance drilldown")
            except Exception as e:
                logger.warning(f"Could not retrieve counts from cache, will calculate from drilldown: {e}")
        
        # Fallback: Use filtered_count if cache not available (accurate count)
        if not age_bucket_counts:
            # Build age_bucket_counts from current page (for display purposes only)
            for row in data:
                bucket = row.get('AGE_BUCKET', 'Unknown')
                age_bucket_counts[bucket] = age_bucket_counts.get(bucket, 0) + 1
            
            # Use filtered_count as total_count (actual count from COUNT query)
            total_count = filtered_count
            logger.info(f"Cache unavailable - using filtered_count ({filtered_count}) as total_count for Elevance drilldown")
        else:
            # Calculate total_count from cached age bucket counts (for selected buckets)
            total_count = 0
            if request.age_buckets:
                # User selected specific buckets - sum counts for those buckets
                for bucket in request.age_buckets:
                    total_count += age_bucket_counts.get(bucket, 0)
            else:
                # No specific buckets selected - sum all bucket counts
                total_count = sum(age_bucket_counts.values())
        
        # Calculate pagination metadata based on filtered_count (real-time count)
        total_pages = (filtered_count + page_size - 1) // page_size if filtered_count > 0 else 1
        has_next = page < total_pages
        has_previous = page > 1
        
        logger.debug(f"Pagination metadata - Page {page}/{total_pages}, Returned {len(data)} records")
        
        total_duration = (time.time() - start_time) * 1000
        logger.info(f"Elevance age drilldown completed in {total_duration:.2f}ms - Filtered: {filtered_count}, Returned: {len(data)} (Count: {count_duration:.2f}ms, Query: {query_duration:.2f}ms, Processing: {processing_duration:.2f}ms)")
        
        return AgeDrilldownResponse(
            status="success",
            data=data,
            total_count=total_count,
            filtered_count=filtered_count,
            age_bucket_counts=age_bucket_counts,
            age_buckets=request.age_buckets if request.age_buckets else ['00-02', '03-05', '06-10', '11-15', '16-20', '21-30', '31-60', '61+'],
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            has_next=has_next,
            has_previous=has_previous,
            message="Elevance age drilldown data retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_elevance_age_drilldown: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/cob-age-drilldown", response_model=AgeDrilldownResponse, summary="Get COB Age Drilldown Details")
async def get_cob_age_drilldown(request: AgeDrilldownRequest):
    """
    Get detailed drilldown data for COB Age buckets.
    
    Returns individual work items within selected age buckets based on PXCREATEDATETIME.
    
    **Filters:**
    - age_buckets: List of age buckets to drill into (e.g., ['00-02', '31-60'])
    - lob: Line of Business filter
    - work_type: Work type filter
    - manager: Manager IDs filter
    - market: Market filter
    - funding_model: Funding model filter
    
    **Returns:**
    - data: List of work items with details
    - total_count: Total number of records
    - age_buckets: Age buckets selected
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        import time
        start_time = time.time()
        
        logger.info("COB age drilldown request started")
        
        # Build filters
        filter_start = time.time()
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        funding_model_filter = build_funding_model_filter(getattr(request, 'funding_model', None))
        age_bucket_filter = build_age_bucket_filter(request.age_buckets)
        
        # Create no-prefix versions for age_classified CTE (selecting from invntry_deduped)
        lob_filter_no_prefix = lob_filter.replace('inv.', '') if lob_filter else ''
        work_type_filter_no_prefix = work_type_filter.replace('inv.', '') if work_type_filter else ''
        manager_filter_no_prefix = manager_filter.replace('inv.', '') if manager_filter else ''
        market_filter_no_prefix = market_filter.replace('inv.', '') if market_filter else ''
        funding_model_filter_no_prefix = funding_model_filter.replace('inv.', '') if funding_model_filter else ''
        filter_duration = (time.time() - filter_start) * 1000
        logger.debug(f"Filter building completed in {filter_duration:.2f}ms")
        
        # Format query
        query = COB_AGE_DRILLDOWN_QUERY.format(
            lob_filter=lob_filter_no_prefix,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix,
            funding_model_filter=funding_model_filter_no_prefix,
            age_buckets=age_bucket_filter
        )
        
        # Calculate pagination parameters for Snowflake query
        page = request.page or 1
        page_size = request.page_size or 100
        offset = (page - 1) * page_size
        
        # Get engine instance
        engine = connection_manager.get_engine()
        
        # Get real-time count for accurate pagination (don't rely on cached counts)
        count_query = f"SELECT COUNT(*) as total FROM ({query}) AS subquery"
        count_start = time.time()
        logger.debug(f"Executing COUNT query for pagination")
        count_results = await engine.execute_query_async(count_query, limit=1)
        filtered_count = count_results[0]['TOTAL'] if count_results else 0
        count_duration = (time.time() - count_start) * 1000
        logger.debug(f"COUNT query completed in {count_duration:.2f}ms - Filtered count: {filtered_count}")
        
        # Add LIMIT and OFFSET to query for efficient pagination at database level
        paginated_query = f"{query} LIMIT {page_size} OFFSET {offset}"

        # Execute paginated query (only fetch requested page)
        query_start = time.time()
        logger.info(f"Executing COB age drilldown Snowflake query (page {page}, size {page_size}, offset {offset})")
        results = await engine.execute_query_async(paginated_query, limit=page_size)
        query_duration = (time.time() - query_start) * 1000
        result_count = len(results) if results else 0
        logger.info(f"Snowflake query completed in {query_duration:.2f}ms - Retrieved {result_count} rows for page {page}")
        
        # Format response and replace NULL values with 'N/A'
        processing_start = time.time()
        data = []
        for row in results:
            row_dict = dict(row)
            # Replace None/NULL values with 'N/A'
            for key, value in row_dict.items():
                if value is None:
                    row_dict[key] = 'N/A'
            data.append(row_dict)
        processing_duration = (time.time() - processing_start) * 1000
        logger.debug(f"Data processing completed in {processing_duration:.2f}ms")
        
        # Get age bucket counts from cached receipts-age response if available
        age_bucket_counts = {}
        session_id = getattr(request, 'session_id', None)
        
        if session_id and config.REDIS_ENABLED:
            try:
                # Build filters dict for cache isolation (must match receipts-age filters)
                filters = {
                    'lob': request.lob,
                    'work_type': request.work_type,
                    'manager': getattr(request, 'manager', None),
                    'market': getattr(request, 'market', None)
                }
                
                cached_age_response = await workforce_session_cache_service.get_cached_result(
                    session_id=session_id,
                    endpoint_name="receipts_age",
                    filters=filters
                )
                
                if cached_age_response and isinstance(cached_age_response, dict):
                    # Extract cob_age counts from cached response
                    cob_age = cached_age_response.get("cob_age", [])
                    for bucket_data in cob_age:
                        bucket = bucket_data.get("AGE_BUCKET")
                        count = bucket_data.get("CASE_COUNT", 0)
                        if bucket:
                            age_bucket_counts[bucket] = count
                    logger.info(f"Using age bucket counts from cached receipts-age for COB drilldown")
            except Exception as e:
                logger.warning(f"Could not retrieve counts from cache, will calculate from drilldown: {e}")
        
        # Fallback: Use filtered_count if cache not available (accurate count)
        if not age_bucket_counts:
            # Build age_bucket_counts from current page (for display purposes only)
            for row in data:
                bucket = row.get('AGE_BUCKET', 'Unknown')
                age_bucket_counts[bucket] = age_bucket_counts.get(bucket, 0) + 1
            
            # Use filtered_count as total_count (actual count from COUNT query)
            total_count = filtered_count
            logger.info(f"Cache unavailable - using filtered_count ({filtered_count}) as total_count for COB drilldown")
        else:
            # Calculate total_count from cached age bucket counts (for selected buckets)
            total_count = 0
            if request.age_buckets:
                # User selected specific buckets - sum counts for those buckets
                for bucket in request.age_buckets:
                    total_count += age_bucket_counts.get(bucket, 0)
            else:
                # No specific buckets selected - sum all bucket counts
                total_count = sum(age_bucket_counts.values())
        
        # Calculate pagination metadata based on filtered_count (real-time count)
        total_pages = (filtered_count + page_size - 1) // page_size if filtered_count > 0 else 1
        has_next = page < total_pages
        has_previous = page > 1
        
        logger.debug(f"Pagination metadata - Page {page}/{total_pages}, Returned {len(data)} records")
        
        total_duration = (time.time() - start_time) * 1000
        logger.info(f"COB age drilldown completed in {total_duration:.2f}ms - Filtered: {filtered_count}, Returned: {len(data)} (Count: {count_duration:.2f}ms, Query: {query_duration:.2f}ms, Processing: {processing_duration:.2f}ms)")
        
        return AgeDrilldownResponse(
            status="success",
            data=data,
            total_count=total_count,
            filtered_count=filtered_count,
            age_bucket_counts=age_bucket_counts,
            age_buckets=request.age_buckets if request.age_buckets else ['00-02', '03-05', '06-10', '11-15', '16-20', '21-30', '31-60', '61+'],
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            has_next=has_next,
            has_previous=has_previous,
            message="COB age drilldown data retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_cob_age_drilldown: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# COMBINED APIs
# =============================================================================

@router.post("/receipts-vs-resolved", response_model=ReceiptsVsResolvedCombinedResponse, summary="Get Receipts vs Resolved Combined Data")
async def get_receipts_vs_resolved(request: ReceiptsVsResolvedRequest):
    """
    Get combined receipts vs resolved data with variance gap and forecast accuracy.
    
    Executes separate queries for receipts, resolved, and forecast accuracy,
    then combines the results into a single response.
    
    **Filters:**
    - start_date, end_date: Date range filter (required)
    - grouping_level: Aggregation level (daily/weekly/monthly/quarterly/yearly)
    - lob: Line of Business filter
    - staffing_category: Staffing category filter
    - work_type: Work type filter
    - manager: Manager IDs filter
    - market: Market filter
    - funding_model: Funding model filter
    
    **Returns:**
    - data: Combined receipts and resolved trend data with variance gap
    - period_count: Number of periods returned
    - forecast_accuracy_pct: Forecast accuracy percentage
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        staffing_filter = build_staffing_category_filter(request.staffing_category, use_derived=True)
        staffing_filter_up = build_staffing_category_filter(request.staffing_category, table_alias='up')  # For queries using 'up' alias
        work_type_filter = build_work_type_filter(request.work_type)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        funding_model_filter = build_funding_model_filter(getattr(request, 'funding_model', None))
        
        # Build receipts-specific filters that exclude Facets Pend and CCERT
        receipts_work_type_filter_cy = build_receipts_work_type_filter(request.work_type, column_prefix='cy.')
        receipts_work_type_filter_py = build_receipts_work_type_filter(request.work_type, column_prefix='py.')
        
        # Build filter versions with cy./py. prefix for aggregation CTEs (after deduplication)
        lob_filter_cy = lob_filter.replace('inv.', 'cy.') if lob_filter else ''
        work_type_filter_cy = work_type_filter.replace('inv.', 'cy.') if work_type_filter else ''
        market_filter_cy = market_filter.replace('inv.', 'cy.') if market_filter else ''
        funding_model_filter_cy = funding_model_filter.replace('inv.', 'cy.') if funding_model_filter else ''
        manager_filter_cy = manager_filter.replace('inv.', 'cy.') if manager_filter else ''
        staffing_filter_xwalk_cy = staffing_filter.replace('derived_staffing_category', 'xwalk.STAFFING_CATEGORY') if staffing_filter else ''
        
        lob_filter_py = lob_filter.replace('inv.', 'py.') if lob_filter else ''
        work_type_filter_py = work_type_filter.replace('inv.', 'py.') if work_type_filter else ''
        market_filter_py = market_filter.replace('inv.', 'py.') if market_filter else ''
        funding_model_filter_py = funding_model_filter.replace('inv.', 'py.') if funding_model_filter else ''
        manager_filter_py = manager_filter.replace('inv.', 'py.') if manager_filter else ''
        staffing_filter_xwalk_py = staffing_filter.replace('derived_staffing_category', 'xwalk.STAFFING_CATEGORY') if staffing_filter else ''
        
        # Build conditional EXISTS clauses for staffing filters
        if staffing_filter_xwalk_cy:
            staffing_filter_cy_exists = f"""AND EXISTS (
          SELECT 1
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
          WHERE TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(cy.INTAKESOURCESYSTEM))
            {staffing_filter_xwalk_cy}
      )"""
        else:
            staffing_filter_cy_exists = ""
        
        if staffing_filter_xwalk_py:
            staffing_filter_py_exists = f"""AND EXISTS (
          SELECT 1
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
          WHERE TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(py.INTAKESOURCESYSTEM))
            {staffing_filter_xwalk_py}
      )"""
        else:
            staffing_filter_py_exists = ""
        
        # Build filters without table prefix for PROJECTED_RESOLVED_QUERY avg_cycle_time CTE
        # Note: lob_filter keeps 'inv.' prefix for avg_cycle_time CTE to avoid ambiguity with xwalk.LOB
        lob_filter_cycle_time = build_lob_filter(request.lob) if build_lob_filter(request.lob) else ''
        work_type_filter_no_prefix = build_work_type_filter(request.work_type).replace('inv.', '') if build_work_type_filter(request.work_type) else ''
        market_filter_no_prefix = build_market_filter(getattr(request, 'market', None)).replace('inv.', '') if build_market_filter(getattr(request, 'market', None)) else ''
        
        # Build manager filter for workday history (uses MANAGER_DOMAIN_ID column without table prefix)
        manager_list = getattr(request, 'manager', None)
        if manager_list and len(manager_list) > 0:
            manager_ids_str = "', '".join([m.upper() for m in manager_list])
            manager_filter_workday = f"AND UPPER(TRIM(w.MANAGER_DOMAIN_ID)) IN ('{manager_ids_str}')"
        else:
            manager_filter_workday = ""
        
        # Build staffing category filters for PROJECTED_RESOLVED_QUERY
        staffing_category_list = request.staffing_category if request.staffing_category else []
        if staffing_category_list:
            null_requested = "None" in staffing_category_list
            non_null_categories = [c for c in staffing_category_list if c != "None"]
            
            if null_requested and non_null_categories:
                category_values = "', '".join(non_null_categories)
                # historical: outer query uses alias STAFFING_CATEGORY (usc not in scope)
                staffing_category_filter_historical = f"AND (COALESCE(STAFFING_CATEGORY, 'None') IN ('{category_values}') OR STAFFING_CATEGORY IS NULL)"
                staffing_category_filter_timeoff = f"AND (COALESCE(usc.STAFFING_CATEGORY, 'None') IN ('{category_values}') OR usc.STAFFING_CATEGORY IS NULL)"
            elif null_requested:
                staffing_category_filter_historical = "AND (COALESCE(STAFFING_CATEGORY, 'None') = 'None' OR STAFFING_CATEGORY IS NULL)"
                staffing_category_filter_timeoff = "AND (COALESCE(usc.STAFFING_CATEGORY, 'None') = 'None' OR usc.STAFFING_CATEGORY IS NULL)"
            else:
                category_values = "', '".join(non_null_categories)
                staffing_category_filter_historical = f"AND COALESCE(STAFFING_CATEGORY, 'None') IN ('{category_values}')"
                staffing_category_filter_timeoff = f"AND COALESCE(usc.STAFFING_CATEGORY, 'None') IN ('{category_values}')"
        else:
            staffing_category_filter_historical = ""
            staffing_category_filter_timeoff = ""
        
        # Build LOB filter for onboard_data (OPEN_POSITIONS table still uses LOB)
        if request.lob and len(request.lob) > 0:
            # For onboard_data (uses COALESCE with op.LOB) - map to OPEN_POSITIONS_LOB_MAP values
            mapped_lobs_onboard = list(set([config.OPEN_POSITIONS_LOB_MAP.get(l, l.upper() if l != "None" else "NONE").upper() for l in request.lob]))
            quoted_lobs_onboard = "', '".join(mapped_lobs_onboard)
            lob_filter_onboard = f"AND COALESCE(UPPER(TRIM(op.LOB)), 'NONE') IN ('{quoted_lobs_onboard}')"
            # For membership_data (uses m.LOB) - map to MEMBERSHIP_LOB_MAP values
            mapped_lobs_membership = list(set([config.MEMBERSHIP_LOB_MAP.get(l, l.upper() if l != "None" else "NONE") for l in request.lob]))
            quoted_lobs_membership = "', '".join(mapped_lobs_membership)
            lob_filter_membership = f"AND UPPER(TRIM(m.LOB)) IN ('{quoted_lobs_membership}')"
        else:
            lob_filter_onboard = ""
            lob_filter_membership = ""
        
        # Build staffing filter for avg_cycle_time CTE (uses xwalk.STAFFING_CATEGORY_TYPE)
        if request.staffing_category and len(request.staffing_category) > 0:
            null_requested = "None" in request.staffing_category
            non_null_categories = [c.upper() for c in request.staffing_category if c != "None"]
            
            if null_requested and non_null_categories:
                category_values = "', '".join(non_null_categories)
                staffing_filter_xwalk = f"AND (UPPER(TRIM(xwalk.STAFFING_CATEGORY_TYPE)) IN ('{category_values}') OR xwalk.STAFFING_CATEGORY_TYPE IS NULL)"
            elif null_requested:
                staffing_filter_xwalk = "AND xwalk.STAFFING_CATEGORY_TYPE IS NULL"
            else:
                category_values = "', '".join(non_null_categories)
                staffing_filter_xwalk = f"AND UPPER(TRIM(xwalk.STAFFING_CATEGORY_TYPE)) IN ('{category_values}')"
        else:
            staffing_filter_xwalk = ""
        
        # Get grouping level (default to 'monthly' if not provided)
        grouping_level = getattr(request, 'grouping_level', 'monthly')
        
        engine = connection_manager.get_engine()
        
        # Build queries
        projected_vs_actual_receipts_query = PROJECTED_VS_ACTUAL_RECEIPTS_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            lob_filter=lob_filter,
            lob_filter_membership=lob_filter_membership,
            lob_filter_cy=lob_filter_cy,
            lob_filter_py=lob_filter_py,
            work_type_filter=work_type_filter,
            work_type_filter_cy=receipts_work_type_filter_cy,  # Use receipts filter (excludes Facets Pend & CCERT)
            work_type_filter_py=receipts_work_type_filter_py,  # Use receipts filter (excludes Facets Pend & CCERT)
            manager_filter=manager_filter,
            manager_filter_cy=manager_filter_cy,
            manager_filter_py=manager_filter_py,
            market_filter=market_filter,
            market_filter_cy=market_filter_cy,
            market_filter_py=market_filter_py,
            funding_model_filter=funding_model_filter,
            funding_model_filter_cy=funding_model_filter_cy,
            funding_model_filter_py=funding_model_filter_py,
            staffing_filter=staffing_filter,
            staffing_filter_cy_exists=staffing_filter_cy_exists,
            staffing_filter_py_exists=staffing_filter_py_exists,
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )

        projected_resolved_query = PROJECTED_RESOLVED_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            staffing_category_filter_historical=staffing_category_filter_historical,
            lob_filter_onboard=lob_filter_onboard,
            staffing_category_filter_timeoff=staffing_category_filter_timeoff,
            lob_filter_cycle=lob_filter_cycle_time,
            staffing_filter=staffing_filter_xwalk,
            work_type_filter=work_type_filter_no_prefix,
            market_filter=market_filter_no_prefix,
            manager_filter=manager_filter_workday,
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )

        # Build id. prefix versions for actual_resolved_query aggregated_data CTE
        manager_filter_id = manager_filter.replace('inv.', 'id.') if manager_filter else ''
        lob_filter_id = lob_filter.replace('inv.', 'id.') if lob_filter else ''
        work_type_filter_id = work_type_filter.replace('inv.', 'id.') if work_type_filter else ''
        market_filter_id = market_filter.replace('inv.', 'id.') if market_filter else ''
        funding_model_filter_id = funding_model_filter.replace('inv.', 'id.') if funding_model_filter else ''
        staffing_filter_xwalk_id = staffing_filter.replace('derived_staffing_category', 'xwalk.STAFFING_CATEGORY') if staffing_filter else ''
        
        # Build conditional EXISTS clause for staffing filter in actual_resolved_query
        if staffing_filter_xwalk_id:
            staffing_filter_exists_resolved = f"""AND EXISTS (
          SELECT 1
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
          WHERE TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(id.INTAKESOURCESYSTEM))
            {staffing_filter_xwalk_id}
      )"""
        else:
            staffing_filter_exists_resolved = ""
        
        actual_resolved_query = ACTUAL_RESOLVED_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            lob_filter=lob_filter_id,
            staffing_filter_exists=staffing_filter_exists_resolved,
            work_type_filter=work_type_filter_id,
            manager_filter=manager_filter_id,
            market_filter=market_filter_id,
            funding_model_filter=funding_model_filter_id
        )

        # Execute all three queries in parallel using asyncio.gather
        projected_vs_actual_receipts_results, projected_resolved_results, actual_resolved_results = await asyncio.gather(
            engine.execute_query_async(projected_vs_actual_receipts_query, 1000),
            engine.execute_query_async(projected_resolved_query, 1000),
            engine.execute_query_async(actual_resolved_query, 1000)
        )
        
        # Convert PERIOD_DATE to date type to avoid datetime/date comparison issues
        # The combined query now returns both PROJECTED_RECEIPTS and ACTUAL_RECEIPTS
        projected_vs_actual_receipts_data = {}
        for row in projected_vs_actual_receipts_results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            projected_vs_actual_receipts_data[period_date] = dict(row)
        
        projected_resolved_data = {}
        for row in projected_resolved_results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            projected_resolved_data[period_date] = dict(row)
        
        actual_resolved_data = {}
        for row in actual_resolved_results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            actual_resolved_data[period_date] = dict(row)
        
        # Merge all data sources
        combined_data = []
        all_periods = set(projected_vs_actual_receipts_data.keys()) | set(projected_resolved_data.keys()) | set(actual_resolved_data.keys())
        
        for period_date in sorted(all_periods):
            receipts_row = projected_vs_actual_receipts_data.get(period_date, {})
            projected_resolved_row = projected_resolved_data.get(period_date, {})
            actual_resolved_row = actual_resolved_data.get(period_date, {})
            
            actual_receipts = float(receipts_row.get('ACTUAL_RECEIPTS', 0) or 0)
            projected_receipts = float(receipts_row.get('PROJECTED_RECEIPTS', 0) or 0)
            projected_resolved = float(projected_resolved_row.get('PROJECTED_RESOLVED', 0) or 0)
            actual_resolved = float(actual_resolved_row.get('ACTUAL_RESOLVED', 0) or 0)
            resolved_completed = float(actual_resolved_row.get('RESOLVED_COMPLETED', 0) or 0)
            resolved_autocloselink = float(actual_resolved_row.get('RESOLVED_AUTOCLOSELINK', 0) or 0)
            
            # Calculate variance gap percentage for receipts
            receipts_variance_gap_pct = None
            if projected_receipts > 0 and actual_receipts > 0:
                receipts_variance_gap_pct = round((projected_receipts - actual_receipts) * 100.0 / actual_receipts)
            
            # Calculate variance gap percentage for resolved
            resolved_variance_gap_pct = None
            if projected_resolved > 0 and actual_resolved > 0:
                resolved_variance_gap_pct = round((projected_resolved - actual_resolved) * 100.0 / actual_resolved)
            
            # Build actual resolved breakdown for tooltip
            actual_resolved_breakdown = []
            if actual_resolved > 0:
                actual_resolved_breakdown.append({
                    "status": "Total Actual Resolved",
                    "count": round(actual_resolved)
                })
            if resolved_completed > 0:
                actual_resolved_breakdown.append({
                    "status": "Resolved-Completed",
                    "count": round(resolved_completed)
                })
            if resolved_autocloselink > 0:
                actual_resolved_breakdown.append({
                    "status": "Resolved-AutoCloseLink",
                    "count": round(resolved_autocloselink)
                })
            
            combined_row = {
                'GROUPING_LEVEL': receipts_row.get('GROUPING_LEVEL') or projected_resolved_row.get('GROUPING_LEVEL') or actual_resolved_row.get('GROUPING_LEVEL'),
                'PERIOD_DATE': period_date,
                'PERIOD_LABEL': receipts_row.get('PERIOD_LABEL') or projected_resolved_row.get('PERIOD_LABEL') or actual_resolved_row.get('PERIOD_LABEL'),
                'PROJECTED_RECEIPTS': round(projected_receipts) if projected_receipts else None,
                'ACTUAL_RECEIPTS': round(actual_receipts) if actual_receipts else None,
                'PROJECTED_RESOLVED': round(projected_resolved) if projected_resolved else None,
                'ACTUAL_RESOLVED': round(actual_resolved) if actual_resolved else None,
                'RECEIPTS_VARIANCE_GAP_PCT': receipts_variance_gap_pct,
                'RESOLVED_VARIANCE_GAP_PCT': resolved_variance_gap_pct,
                'ACTUAL_RESOLVED_BREAKDOWN': actual_resolved_breakdown if actual_resolved_breakdown else None,
            }
            combined_data.append(combined_row)
        
        # Calculate forecast accuracy
        # NOTE: Current implementation calculates accuracy from the same filtered data used for the chart.
        # Per requirements, Forecast Accuracy should apply: LOB, Staffing Category, Work Type, Market
        # but NOT apply: Manager, Funding Model filters.
        # The Projected queries already exclude Manager/Funding Model, but Actual queries include them.
        # This means the current Forecast Accuracy is affected by Manager/Funding Model filters.
        # TODO: If strict separation is required, create separate Actual queries without Manager/Funding Model
        # for Forecast Accuracy calculation only.
        
        # Only include periods where both projected and actual data exist (complete data)
        # Exclude future dates (where actual data doesn't exist yet)
        from datetime import date as date_type
        today = date_type.today()
        
        receipts_accuracies = []
        resolved_accuracies = []
        
        for period_date in sorted(all_periods):
            # Determine if period is complete based on grouping level
            period_is_complete = False
            
            if grouping_level == 'daily':
                period_is_complete = period_date < today
            elif grouping_level == 'weekly':
                # Week is complete if the week end date (Saturday) is in the past
                from datetime import timedelta
                week_end = period_date + timedelta(days=6)
                period_is_complete = week_end < today
            elif grouping_level == 'monthly':
                # Month is complete if we're in a different month
                period_is_complete = (period_date.year < today.year) or \
                                   (period_date.year == today.year and period_date.month < today.month)
            elif grouping_level == 'quarterly':
                # Quarter is complete if we're in a different quarter
                period_quarter = (period_date.month - 1) // 3
                today_quarter = (today.month - 1) // 3
                period_is_complete = (period_date.year < today.year) or \
                                   (period_date.year == today.year and period_quarter < today_quarter)
            elif grouping_level == 'yearly':
                # Year is complete if we're in a different year
                period_is_complete = period_date.year < today.year
            
            # Skip incomplete or future periods for forecast accuracy calculation
            if not period_is_complete:
                continue
            
            receipts_row = projected_vs_actual_receipts_data.get(period_date, {})
            projected_resolved_row = projected_resolved_data.get(period_date, {})
            actual_resolved_row = actual_resolved_data.get(period_date, {})
            
            actual_receipts = float(receipts_row.get('ACTUAL_RECEIPTS', 0) or 0)
            projected_receipts = float(receipts_row.get('PROJECTED_RECEIPTS', 0) or 0)
            projected_resolved = float(projected_resolved_row.get('PROJECTED_RESOLVED', 0) or 0)
            actual_resolved = float(actual_resolved_row.get('ACTUAL_RESOLVED', 0) or 0)
            
            # Calculate receipts accuracy using sMAPE (Symmetric Mean Absolute Percentage Error)
            # Formula: Accuracy = 100 - sMAPE, where sMAPE = (|Actual - Forecast| / (|Actual| + |Forecast|)) * 100
            # This naturally produces accuracy values between 0-100%
            if projected_receipts > 0 and actual_receipts > 0:
                smape_receipts = (abs(actual_receipts - projected_receipts) / (abs(actual_receipts) + abs(projected_receipts))) * 100
                receipts_accuracy = 100 - smape_receipts
                receipts_accuracies.append(receipts_accuracy)
            
            # Calculate resolved accuracy using sMAPE (Symmetric Mean Absolute Percentage Error)
            # Formula: Accuracy = 100 - sMAPE, where sMAPE = (|Actual - Forecast| / (|Actual| + |Forecast|)) * 100
            # This naturally produces accuracy values between 0-100%
            if projected_resolved > 0 and actual_resolved > 0:
                smape_resolved = (abs(actual_resolved - projected_resolved) / (abs(actual_resolved) + abs(projected_resolved))) * 100
                resolved_accuracy = 100 - smape_resolved
                resolved_accuracies.append(resolved_accuracy)
        
        # Calculate average forecast accuracy using sMAPE-based accuracy
        # sMAPE ensures values stay within 0-100% range even with large forecast errors
        
        receipts_avg_accuracy = None
        resolved_avg_accuracy = None
        
        if receipts_accuracies:
            receipts_avg_accuracy = sum(receipts_accuracies) / len(receipts_accuracies)
        
        if resolved_accuracies:
            resolved_avg_accuracy = sum(resolved_accuracies) / len(resolved_accuracies)
        
        # Average the two accuracy percentages
        if receipts_avg_accuracy is not None and resolved_avg_accuracy is not None:
            forecast_accuracy_pct = round((receipts_avg_accuracy + resolved_avg_accuracy) / 2, 2)
        elif receipts_avg_accuracy is not None:
            forecast_accuracy_pct = round(receipts_avg_accuracy, 2)
        elif resolved_avg_accuracy is not None:
            forecast_accuracy_pct = round(resolved_avg_accuracy, 2)
        else:
            forecast_accuracy_pct = None  # No complete data available
        
        return ReceiptsVsResolvedCombinedResponse(
            status="success",
            data=combined_data,
            period_count=len(combined_data),
            forecast_accuracy_pct=forecast_accuracy_pct,
            message="Receipts vs resolved data retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_receipts_vs_resolved: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/receipts-age", response_model=ReceiptsAgeCombinedResponse, summary="Get Receipts Age Combined Data")
async def get_receipts_age(request: ReceiptsAgeRequest):
    """
    Get combined receipts age distribution data (Elevance Age + COB Age).
    
    **Session-Based Caching:** Uses session_id to coordinate cache warming and prevent
    duplicate queries when users rapidly change filters. On first call, warms all 3 age
    endpoints (receipts-age, elevance-age-drilldown, cob-age-drilldown) with lock coordination.
    
    **Filters:**
    - lob: Line of Business filter
    - work_type: Work type filter
    - manager: Manager IDs filter
    - market: Market filter
    - session_id: Session identifier for cache coordination (recommended)
    
    **Returns:**
    - elevance_age: Age distribution based on COMPANYRECEIVEDDATE
    - cob_age: Age distribution based on PXCREATEDATETIME
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Auto-generate session_id if not provided (matches Performance IQ pattern)
        # This ensures fresh data on filter changes
        if config.REDIS_ENABLED and not getattr(request, 'session_id', None):
            from services.workforce_session_cache_service import generate_workforce_session_id
            request.session_id = generate_workforce_session_id()
            logger.info(f"Auto-generated session_id: {request.session_id}")
        
        session_id = getattr(request, 'session_id', None)
        
        # If session_id available and caching enabled, use session cache
        if session_id and config.REDIS_ENABLED:
            logger.info(f"Using session cache for receipts-age, session_id: {session_id}")
            
            # Build filters dict for cache isolation (matches Performance IQ pattern)
            filters = {
                'lob': request.lob,
                'work_type': request.work_type,
                'manager': getattr(request, 'manager', None),
                'market': getattr(request, 'market', None)
            }
            
            # Try to get from cache first
            cached_result = await workforce_session_cache_service.get_cached_result(
                session_id=session_id,
                endpoint_name="receipts_age",
                filters=filters
            )
            
            if cached_result:
                logger.info(f"Cache hit for receipts-age, session {session_id}")
                response = ReceiptsAgeCombinedResponse(**cached_result)
                response.session_id = session_id
                return response
            
            # Cache miss - trigger comprehensive warming with lock coordination
            logger.info(f"Cache miss for receipts-age, warming all age caches for session {session_id}")
            
            result = await workforce_session_cache_service.warm_age_caches(
                session_id=session_id,
                warm_func=warm_age_caches,
                request=request,
                filters=filters
            )
            
            # Return the age_response from warming result
            if result and "age_response" in result:
                response = ReceiptsAgeCombinedResponse(**result["age_response"])
                response.session_id = session_id
                return response
        
        # No session_id or caching disabled - execute directly
        logger.info("Executing receipts-age query directly (no session cache)")
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        
        # Create no-prefix versions for case_age_buckets CTE (selecting from invntry_deduped)
        lob_filter_no_prefix = lob_filter.replace('inv.', '') if lob_filter else ''
        work_type_filter_no_prefix = work_type_filter.replace('inv.', '') if work_type_filter else ''
        manager_filter_no_prefix = manager_filter.replace('inv.', '') if manager_filter else ''
        market_filter_no_prefix = market_filter.replace('inv.', '') if market_filter else ''
        
        engine = connection_manager.get_engine()
        
        # Build queries
        elevance_query = ELEVANCE_AGE_QUERY.format(
            lob_filter=lob_filter_no_prefix,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix
        )
        
        cob_query = COB_AGE_QUERY.format(
            lob_filter=lob_filter_no_prefix,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix
        )

        # Execute both queries in parallel using asyncio.gather
        elevance_results, cob_results = await asyncio.gather(
            engine.execute_query_async(elevance_query, 1000),
            engine.execute_query_async(cob_query, 1000)
        )
        
        elevance_age_raw = [dict(row) for row in elevance_results]
        cob_age_raw = [dict(row) for row in cob_results]
        
        # Sort by BUCKET_ORDER descending and remove BUCKET_ORDER from response
        elevance_age_raw.sort(key=lambda x: x.get('BUCKET_ORDER', 0), reverse=True)
        cob_age_raw.sort(key=lambda x: x.get('BUCKET_ORDER', 0), reverse=True)
        
        # Remove BUCKET_ORDER field from response
        elevance_age = [{k: v for k, v in item.items() if k != 'BUCKET_ORDER'} for item in elevance_age_raw]
        cob_age = [{k: v for k, v in item.items() if k != 'BUCKET_ORDER'} for item in cob_age_raw]
        
        return ReceiptsAgeCombinedResponse(
            status="success",
            session_id=session_id,
            elevance_age=elevance_age,
            cob_age=cob_age,
            message="Receipts age data retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_receipts_age: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/elevance-age-drilldown/download-excel",
    summary="Download Elevance Age Drilldown as Excel",
    description="""
Download complete Elevance Age drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (optional): Logged-in user ID
- **age_buckets** (optional): List of age buckets to drill into (e.g., ['00-02', '31-60'])
- **lob** (optional): List of Line of Business values
- **work_type** (optional): List of work types
- **manager** (optional): List of manager IDs
- **market** (optional): List of markets
- **funding_model** (optional): List of funding models

**Returns:** Excel file (.xlsx) with all Elevance Age drilldown records
""",
)
async def download_elevance_age_drilldown_excel(
    request: AgeDrilldownRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        import time
        start_time = time.time()
        
        user_id = request.user_id or "user"
        age_buckets_str = "_".join(request.age_buckets) if request.age_buckets else "all"
        
        logger.info("Elevance Excel download request started")
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        funding_model_filter = build_funding_model_filter(getattr(request, 'funding_model', None))
        age_bucket_filter = build_age_bucket_filter(request.age_buckets)
        
        # Create no-prefix versions for age_classified CTE (selecting from invntry_deduped)
        lob_filter_no_prefix = lob_filter.replace('inv.', '') if lob_filter else ''
        work_type_filter_no_prefix = work_type_filter.replace('inv.', '') if work_type_filter else ''
        manager_filter_no_prefix = manager_filter.replace('inv.', '') if manager_filter else ''
        market_filter_no_prefix = market_filter.replace('inv.', '') if market_filter else ''
        funding_model_filter_no_prefix = funding_model_filter.replace('inv.', '') if funding_model_filter else ''
        
        # Format query
        query = ELEVANCE_AGE_DRILLDOWN_QUERY.format(
            lob_filter=lob_filter_no_prefix,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix,
            funding_model_filter=funding_model_filter_no_prefix,
            age_buckets=age_bucket_filter
        )
        
        # Execute query with high limit for download
        query_start = time.time()
        logger.info(f"Executing Elevance Excel download Snowflake query (limit: {config.CACHE_FULL_DATASET_LIMIT})")
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=config.CACHE_FULL_DATASET_LIMIT)
        query_duration = (time.time() - query_start) * 1000
        result_count = len(results) if results else 0
        logger.info(f"Snowflake query completed in {query_duration:.2f}ms - Retrieved {result_count} rows")
        
        # Create Excel workbook in write-only mode for better performance with large datasets
        excel_start = time.time()
        logger.info(f"Starting Excel generation for {result_count} rows")
        wb = Workbook(write_only=True)
        ws = wb.create_sheet("Elevance Age Drilldown")
        
        # Define headers
        headers = [
            "Age (Days)",
            "Work Item",
            "Priority",
            "Intake Source",
            "COB Create Date",
            "Elevance Received Date",
            "Assigned To",
            "Status",
            "LOB",
            "Market",
            "Funding Model",
            "Manager Name"
        ]
        
        # Set fixed column widths (more efficient than auto-adjustment)
        ws.column_dimensions['A'].width = 15  # Age (Days)
        ws.column_dimensions['B'].width = 20  # Work Item
        ws.column_dimensions['C'].width = 15  # Priority
        ws.column_dimensions['D'].width = 25  # Intake Source
        ws.column_dimensions['E'].width = 20  # COB Create Date
        ws.column_dimensions['F'].width = 25  # Elevance Received Date
        ws.column_dimensions['G'].width = 25  # Assigned To
        ws.column_dimensions['H'].width = 20  # Status
        ws.column_dimensions['I'].width = 15  # LOB
        ws.column_dimensions['J'].width = 15  # Market
        ws.column_dimensions['K'].width = 20  # Funding Model
        ws.column_dimensions['L'].width = 25  # Manager Name

        # Write headers (write-only mode doesn't support cell styling after write)
        ws.append(headers)
        
        # Stream data rows directly (memory efficient)
        for row in results:
            ws.append([
                row.get("DATA_AGED") if row.get("DATA_AGED") is not None else "N/A",
                str(row.get("WORK_ITEM")) if row.get("WORK_ITEM") is not None else "N/A",
                str(row.get("DRILLING")) if row.get("DRILLING") is not None else "N/A",
                str(row.get("INTAKE_SOURCE")) if row.get("INTAKE_SOURCE") is not None else "N/A",
                str(row.get("COB_CREATE_DATE")) if row.get("COB_CREATE_DATE") is not None else "N/A",
                str(row.get("ELEVANCE_RECEIVED_DATE")) if row.get("ELEVANCE_RECEIVED_DATE") is not None else "N/A",
                str(row.get("ASSIGNED_TO")) if row.get("ASSIGNED_TO") is not None else "N/A",
                str(row.get("STATUS")) if row.get("STATUS") is not None else "N/A",
                str(row.get("LOB")) if row.get("LOB") is not None else "N/A",
                str(row.get("MARKET")) if row.get("MARKET") is not None else "N/A",
                str(row.get("FUNDINGMODEL")) if row.get("FUNDINGMODEL") is not None else "N/A",
                str(row.get("MANAGER_NAME")) if row.get("MANAGER_NAME") is not None else "N/A"
            ])
        
        # Save to BytesIO
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        excel_duration = (time.time() - excel_start) * 1000
        file_size_mb = len(output.getvalue()) / (1024 * 1024)
        logger.info(f"Excel generation completed in {excel_duration:.2f}ms - File size: {file_size_mb:.2f} MB")
        
        total_duration = (time.time() - start_time) * 1000
        logger.info(f"Elevance Excel download completed in {total_duration:.2f}ms (Query: {query_duration:.2f}ms, Excel: {excel_duration:.2f}ms) - {result_count} rows")
        
        filename = f"elevance_age_drilldown_{user_id}_{age_buckets_str}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except Exception as e:
        logger.error(f"Excel download error for elevance age drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")


@router.post(
    "/cob-age-drilldown/download-excel",
    summary="Download COB Age Drilldown as Excel",
    description="""
Download complete COB Age drilldown data as an Excel file.

**Input Parameters:**
- **user_id** (optional): Logged-in user ID
- **age_buckets** (optional): List of age buckets to drill into (e.g., ['00-02', '31-60'])
- **lob** (optional): List of Line of Business values
- **work_type** (optional): List of work types
- **manager** (optional): List of manager IDs
- **market** (optional): List of markets
- **funding_model** (optional): List of funding models

**Returns:** Excel file (.xlsx) with all COB Age drilldown records
""",
)
async def download_cob_age_drilldown_excel(
    request: AgeDrilldownRequest
) -> StreamingResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        import time
        start_time = time.time()
        
        user_id = request.user_id or "user"
        age_buckets_str = "_".join(request.age_buckets) if request.age_buckets else "all"
        
        logger.info("COB Excel download request started")
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        funding_model_filter = build_funding_model_filter(getattr(request, 'funding_model', None))
        age_bucket_filter = build_age_bucket_filter(request.age_buckets)
        
        # Create no-prefix versions for age_classified CTE (selecting from invntry_deduped)
        lob_filter_no_prefix = lob_filter.replace('inv.', '') if lob_filter else ''
        work_type_filter_no_prefix = work_type_filter.replace('inv.', '') if work_type_filter else ''
        manager_filter_no_prefix = manager_filter.replace('inv.', '') if manager_filter else ''
        market_filter_no_prefix = market_filter.replace('inv.', '') if market_filter else ''
        funding_model_filter_no_prefix = funding_model_filter.replace('inv.', '') if funding_model_filter else ''
        
        # Format query
        query = COB_AGE_DRILLDOWN_QUERY.format(
            lob_filter=lob_filter_no_prefix,
            work_type_filter=work_type_filter_no_prefix,
            manager_filter=manager_filter_no_prefix,
            market_filter=market_filter_no_prefix,
            funding_model_filter=funding_model_filter_no_prefix,
            age_buckets=age_bucket_filter
        )
        
        # Execute query with high limit for download
        query_start = time.time()
        logger.info(f"Executing COB Excel download Snowflake query (limit: {config.CACHE_FULL_DATASET_LIMIT})")
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=config.CACHE_FULL_DATASET_LIMIT)
        query_duration = (time.time() - query_start) * 1000
        result_count = len(results) if results else 0
        logger.info(f"Snowflake query completed in {query_duration:.2f}ms - Retrieved {result_count} rows")
        
        # Create Excel workbook in write-only mode for better performance with large datasets
        excel_start = time.time()
        logger.info(f"Starting Excel generation for {result_count} rows")
        wb = Workbook(write_only=True)
        ws = wb.create_sheet("COB Age Drilldown")
        
        # Define headers
        headers = [
            "Age (Days)",
            "Work Item",
            "Priority",
            "Intake Source",
            "COB Create Date",
            "Elevance Received Date",
            "Assigned To",
            "Status",
            "LOB",
            "Market",
            "Funding Model",
            "Manager Name"
        ]
        
        # Set fixed column widths (more efficient than auto-adjustment)
        ws.column_dimensions['A'].width = 15  # Age (Days)
        ws.column_dimensions['B'].width = 20  # Work Item
        ws.column_dimensions['C'].width = 15  # Priority
        ws.column_dimensions['D'].width = 25  # Intake Source
        ws.column_dimensions['E'].width = 20  # COB Create Date
        ws.column_dimensions['F'].width = 25  # Elevance Received Date
        ws.column_dimensions['G'].width = 25  # Assigned To
        ws.column_dimensions['H'].width = 20  # Status
        ws.column_dimensions['I'].width = 15  # LOB
        ws.column_dimensions['J'].width = 15  # Market
        ws.column_dimensions['K'].width = 20  # Funding Model
        ws.column_dimensions['L'].width = 25  # Manager Name

        # Write headers (write-only mode doesn't support cell styling after write)
        ws.append(headers)
        
        # Stream data rows directly (memory efficient)
        for row in results:
            ws.append([
                row.get("DATA_AGED") if row.get("DATA_AGED") is not None else "N/A",
                str(row.get("WORK_ITEM")) if row.get("WORK_ITEM") is not None else "N/A",
                str(row.get("DRILLING")) if row.get("DRILLING") is not None else "N/A",
                str(row.get("INTAKE_SOURCE")) if row.get("INTAKE_SOURCE") is not None else "N/A",
                str(row.get("COB_CREATE_DATE")) if row.get("COB_CREATE_DATE") is not None else "N/A",
                str(row.get("ELEVANCE_RECEIVED_DATE")) if row.get("ELEVANCE_RECEIVED_DATE") is not None else "N/A",
                str(row.get("ASSIGNED_TO")) if row.get("ASSIGNED_TO") is not None else "N/A",
                str(row.get("STATUS")) if row.get("STATUS") is not None else "N/A",
                str(row.get("LOB")) if row.get("LOB") is not None else "N/A",
                str(row.get("MARKET")) if row.get("MARKET") is not None else "N/A",
                str(row.get("FUNDINGMODEL")) if row.get("FUNDINGMODEL") is not None else "N/A",
                str(row.get("MANAGER_NAME")) if row.get("MANAGER_NAME") is not None else "N/A"
            ])
        
        # Save to BytesIO
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        excel_duration = (time.time() - excel_start) * 1000
        file_size_mb = len(output.getvalue()) / (1024 * 1024)
        logger.info(f"Excel generation completed in {excel_duration:.2f}ms - File size: {file_size_mb:.2f} MB")
        
        total_duration = (time.time() - start_time) * 1000
        logger.info(f"COB Excel download completed in {total_duration:.2f}ms (Query: {query_duration:.2f}ms, Excel: {excel_duration:.2f}ms) - {result_count} rows")
        
        filename = f"cob_age_drilldown_{user_id}_{age_buckets_str}.xlsx"
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except Exception as e:
        logger.error(f"Excel download error for COB age drilldown: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel file: {str(e)}")
