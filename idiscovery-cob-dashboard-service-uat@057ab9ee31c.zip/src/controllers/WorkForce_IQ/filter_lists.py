"""
Workforce IQ Filter List APIs
Consolidated file containing all filter list endpoints (LOB, Manager, Staffing Category, Work Type, Market, Funding Model)
"""
from fastapi import APIRouter, HTTPException
from typing import Optional, List
import json
from schema import (
    WorkforceIQSimpleRequest,
    WorkforceIQManagerRequest,
    WorkforceIQMarketRequest,
    WorkforceIQLOBListResponse,
    WorkforceIQManagerListResponse, ManagerItem,
    WorkforceIQStaffingCategoryListResponse, StaffingCategoryItem,
    WorkforceIQStaffingCategorySubcategoriesResponse, StaffingCategoryWithSubcategories,
    WorkforceIQWorkTypeRequest, WorkforceIQWorkTypeListResponse, WorkTypeItem,
    WorkforceIQMarketListResponse, MarketItem,
    WorkforceIQFundingModelListResponse, FundingModelItem
)
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from utils.redis_cache import cache_manager
import config
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()

# =============================================================================
# LOB List API
# =============================================================================

@router.post(
    "/lobs",
    response_model=WorkforceIQLOBListResponse,
    summary="Get List of LOBs for Workforce IQ View",
    description="""
Returns distinct LOBs available for Workforce IQ based on date range.

**Input Parameters:**
- **user_id** (required): Logged-in user ID for authentication and authorization
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format

**Response:**
- **lobs**: List of distinct LOB values from database

**Workforce IQ API Behavior:**
- Queries COB_AI_INVNTRY_PROFILE table
- Filters by PXCREATEDATETIME date range
- Returns distinct LOB values
""",
)
async def get_workforce_iq_lobs(request: WorkforceIQSimpleRequest) -> WorkforceIQLOBListResponse:
    """Get LOB list for Workforce IQ from database with Redis caching."""
    # Validate Snowflake configuration
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Check cache first
        cache_key = "workforce_iq:filters:lobs"
        if config.REDIS_ENABLED:
            cached_data = await cache_manager.get(cache_key)
            if cached_data:
                logger.info(f"[WORKFORCE_IQ_LOB] Cache hit - returning {len(cached_data)} LOBs from cache")
                return WorkforceIQLOBListResponse(
                    status="success",
                    lobs=cached_data,
                    message="Workforce IQ LOBs retrieved successfully (cached)",
                    service="idiscovery-cob-dashboard-service"
                )
        
        logger.info(f"[WORKFORCE_IQ_LOB] Cache miss - fetching LOBs from database")
        
        # Build SQL query with parameterized approach
        query = f"""
        SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        WHERE PXUPDATEDATETIME >= DATEADD(month, -18, CURRENT_DATE())
        ORDER BY LOB
        """
        
        # Execute query
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000)
        
        # Extract LOB values (column name is 'LOB' not 'LOB_NAME')
        lobs = [row['LOB'] for row in results if row.get('LOB')]
        
        logger.info(f"[WORKFORCE_IQ_LOB] Retrieved {len(lobs)} LOBs from database")
        
        # Cache the result
        if config.REDIS_ENABLED:
            await cache_manager.set(cache_key, lobs, ttl=config.METRIC_CACHE_TTL)
            logger.info(f"[WORKFORCE_IQ_LOB] Cached {len(lobs)} LOBs with TTL={config.METRIC_CACHE_TTL}s")
        
        return WorkforceIQLOBListResponse(
            status="success",
            lobs=lobs,
            message="Workforce IQ LOBs retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
    except Exception as e:
        logger.error(f"Failed to retrieve Workforce IQ LOBs: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve Workforce IQ LOBs: {str(e)}")


# =============================================================================
# Manager List API - Helper Functions
# =============================================================================

async def get_user_access_group(user_id: str, engine) -> str:
    """
    Get the PYACCESSGROUP for the logged-in user.
    
    Args:
        user_id: User ID to look up
        engine: Database engine
    
    Returns:
        PYACCESSGROUP value or empty string if not found
    """
    query = f"""
    SELECT PYACCESSGROUP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE USERID = '{user_id}'
        AND PYACCESSGROUP IS NOT NULL
    ORDER BY LOGINDATE DESC
    LIMIT 1
    """
    try:
        records = await engine.execute_query_async(query, limit=1)
        if records and len(records) > 0:
            return records[0].get("PYACCESSGROUP", "")
    except Exception as e:
        logger.warning(f"Failed to get user access group for {user_id}: {str(e)}")
    return ""


def build_access_group_filter(user_access_group: str) -> str:
    """
    Build filter for manager PYACCESSGROUP based on logged-in user's access group.
    If user is 'COB:OffFrontLineManager', only show managers with same access group.
    
    Args:
        user_access_group: The logged-in user's PYACCESSGROUP
    
    Returns:
        SQL filter string or empty string
    """
    if user_access_group == "COB:OffFrontLineManager":
        return "AND manager.REPORTTOMANAGERACCESSGROUP = 'COB:OffFrontLineManager'"
    return ""


def build_lob_filter(lobs: Optional[List[str]]) -> str:
    """
    Build LOB filter for manager query.
    
    Args:
        lobs: List of LOB values to filter
    
    Returns:
        SQL filter string or empty string
    """
    if lobs and len(lobs) > 0:
        lobs_str = "', '".join(lobs)
        return f"AND manager.LOB IN ('{lobs_str}')"
    return ""


def build_category_filter(category_value: Optional[List[str]]) -> str:
    """
    Build staffing category filter for manager query.
    
    Args:
        category_value: List of staffing category values to filter
    
    Returns:
        SQL filter string or empty string
    """
    if category_value and len(category_value) > 0:
        categories_str = "', '".join(category_value)
        return f"AND x.STAFFING_CATEGORY IN ('{categories_str}')"
    return ""


def build_market_lob_filter(lobs: Optional[List[str]]) -> str:
    """
    Build LOB filter for market query.
    
    Args:
        lobs: List of LOB values to filter
    
    Returns:
        SQL filter string or empty string
    """
    if lobs and len(lobs) > 0:
        lobs_str = "', '".join(lobs)
        return f"AND LOB IN ('{lobs_str}')"
    return ""


# =============================================================================
# Manager List API
# =============================================================================

@router.post(
    "/managers",
    response_model=WorkforceIQManagerListResponse,
    summary="Get List of Managers for Workforce IQ View",
    description="""
Returns distinct Managers from database for Workforce IQ.
Shows managers who had frontline associates reporting to them, optionally filtered by LOB and staffing category.
If logged-in user has PYACCESSGROUP='COB:OffFrontLineManager', only shows managers with same access group.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format
- **lobs** (optional): List of LOB values to filter managers (from LOB list API)
- **category_value** (optional): List of staffing categories to filter managers (from staffing-categories-subcategories API)

**Response:**
- **managers**: List of manager objects with name and ID

**Data Sources:**
- COB_AI_USER_PROFILE (frontline users and manager access groups)
- COB_AI_INVNTRY_PROFILE (manager data with LOB filtering)
- COB_AI_STAFFING_CATEGORY_XWALK (staffing category filtering)

**Filtering Logic:**
- Returns managers who have work items in the specified LOBs (if provided)
- Filters by staffing categories through work type mapping (if provided)
- Access group filtering applies based on logged-in user's permissions
""",
)
async def get_workforce_iq_managers(request: WorkforceIQManagerRequest) -> WorkforceIQManagerListResponse:
    """Get Manager list for Workforce IQ from database with Redis caching, filtered by LOB and category."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        engine = connection_manager.get_engine()
        
        # Get user's access group to determine filtering
        user_access_group = await get_user_access_group(request.user_id, engine)
        access_group_filter = build_access_group_filter(user_access_group)
        
        # Build LOB and category filters
        lob_filter = build_lob_filter(request.lobs)
        category_filter = build_category_filter(request.category_value)
        
        # Build cache key that includes all filter parameters
        lob_key_part = "|".join(sorted(request.lobs)) if request.lobs else "all"
        category_key_part = "|".join(sorted(request.category_value)) if request.category_value else "all"
        cache_key = f"workforce_iq:filters:managers:{user_access_group}:lob={lob_key_part}:cat={category_key_part}"
        
        # Check cache first
        if config.REDIS_ENABLED:
            cached_data = await cache_manager.get(cache_key)
            if cached_data:
                logger.info(f"[WORKFORCE_IQ_MANAGERS] Cache hit - returning {len(cached_data)} managers from cache")
                return WorkforceIQManagerListResponse(
                    status="success",
                    managers=cached_data,
                    message="Workforce IQ Managers retrieved successfully (cached)",
                    service="idiscovery-cob-dashboard-service"
                )
        
        logger.info(f"[WORKFORCE_IQ_MANAGERS] Cache miss - fetching managers from database (user={request.user_id}, access_group={user_access_group}, lobs={request.lobs}, categories={request.category_value})")
        
        # Build SQL query based on user's provided structure
        query = f"""
        WITH frontline AS (
            SELECT DISTINCT
                USERID,
                PYREPORTTO,
                REPORTTOUSERNAME
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
            WHERE PYACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
        ),
        manager AS (
            SELECT DISTINCT
                REPORTTOMANAGERID,
                REPORTTOMANAGERNAME, 
                REPORTTOMANAGERACCESSGROUP,
                LOB,
                INTAKESOURCESYSTEM
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
            WHERE PXUPDATEDATETIME >= DATEADD(month, -18, CURRENT_DATE())
        )
        SELECT DISTINCT
            manager.REPORTTOMANAGERID AS MANAGER_ID,
            manager.REPORTTOMANAGERNAME AS MANAGER_NAME
        FROM frontline
        INNER JOIN manager 
            ON frontline.PYREPORTTO = manager.REPORTTOMANAGERID
        INNER JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK x 
            ON manager.INTAKESOURCESYSTEM = x.INTAKE_SOURCE_SYSTEM       
        WHERE manager.REPORTTOMANAGERID IS NOT NULL
            AND manager.REPORTTOMANAGERNAME IS NOT NULL
            {lob_filter}
            {category_filter}
            {access_group_filter}
        ORDER BY manager.REPORTTOMANAGERNAME
        """
        
        results = await engine.execute_query_async(query, limit=1000)
        
        # Convert to ManagerItem format
        managers = [{"manager_id": row['MANAGER_ID'], "manager_name": row['MANAGER_NAME']} for row in results if row.get('MANAGER_ID')]
        
        # Add "None" option for records with NULL REPORTTOMANAGERID
        managers.insert(0, {"manager_id": "None", "manager_name": "Unassigned"})

        # Sort managers alphabetically by manager_name
        managers.sort(key=lambda x: x['manager_name'])
        
        logger.info(f"[WORKFORCE_IQ_MANAGERS] Retrieved {len(managers)} Managers from database (including None option)")
        
        # Cache the result
        if config.REDIS_ENABLED:
            await cache_manager.set(cache_key, managers, ttl=config.METRIC_CACHE_TTL)
            logger.info(f"[WORKFORCE_IQ_MANAGERS] Cached {len(managers)} managers with TTL={config.METRIC_CACHE_TTL}s")
        
        return WorkforceIQManagerListResponse(
            status="success",
            managers=managers,
            message="Workforce IQ Managers retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
    except Exception as e:
        logger.error(f"Failed to retrieve Workforce IQ Managers: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve Workforce IQ Managers: {str(e)}")


# =============================================================================
# Staffing Category List API
# =============================================================================

@router.post(
    "/staffing-categories",
    response_model=WorkforceIQStaffingCategoryListResponse,
    summary="Get List of Staffing Categories for Workforce IQ View",
    description="""
Returns hardcoded Staffing Categories for Workforce IQ.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format

**Response:**
- **staffing_categories**: List of hardcoded staffing category objects with name and ID
""",
)
async def get_workforce_iq_staffing_categories(request: WorkforceIQSimpleRequest) -> WorkforceIQStaffingCategoryListResponse:
    """Get Staffing Category list from crosswalk table for Workforce IQ."""
    try:
        # Check cache first
        cache_key = "workforce_iq:filters:staffing_categories"
        if config.REDIS_ENABLED:
            cached_data = await cache_manager.get(cache_key)
            if cached_data:
                logger.info(f"[WORKFORCE_IQ_STAFFING_CATEGORIES] Cache hit - returning {len(cached_data)} categories from cache")
                return WorkforceIQStaffingCategoryListResponse(
                    status="success",
                    staffing_categories=cached_data,
                    message="Workforce IQ Staffing Categories retrieved successfully (cached)",
                    service="idiscovery-cob-dashboard-service"
                )
        
        logger.info(f"[WORKFORCE_IQ_STAFFING_CATEGORIES] Cache miss - fetching staffing categories from crosswalk table")
        
        # Build SQL query to fetch from crosswalk table
        query = f"""
        SELECT DISTINCT COALESCE(STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
        ORDER BY STAFFING_CATEGORY
        """
        
        # Execute query
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000)
        
        # Transform results to expected format
        categories = []
        for row in results:
            category_name = row.get('STAFFING_CATEGORY', 'None')
            categories.append({
                "category_id": category_name,
                "category_name": category_name
            })
        
        logger.info(f"[WORKFORCE_IQ_STAFFING_CATEGORIES] Retrieved {len(categories)} categories from crosswalk table")
        
        # Cache the results
        if config.REDIS_ENABLED:
            await cache_manager.set(cache_key, categories, ttl=config.METRIC_CACHE_TTL)
            logger.info(f"[WORKFORCE_IQ_STAFFING_CATEGORIES] Cached {len(categories)} categories with TTL={config.METRIC_CACHE_TTL}s")
        
        return WorkforceIQStaffingCategoryListResponse(
            status="success",
            staffing_categories=categories,
            message="Workforce IQ Staffing Categories retrieved successfully from crosswalk table",
            service="idiscovery-cob-dashboard-service"
        )
    except Exception as e:
        logger.error(f"Failed to retrieve Staffing Categories: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve Staffing Categories: {str(e)}")


# =============================================================================
# Staffing Category with Subcategories List API
# =============================================================================

@router.post(
    "/staffing-categories-subcategories",
    response_model=WorkforceIQStaffingCategorySubcategoriesResponse,
    summary="Get Staffing Categories with Subcategories for Workforce IQ View",
    description="""
Returns Staffing Categories grouped by category type with subcategories for Workforce IQ.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format

**Response:**
- **staffing_categories**: Dictionary where keys are category type values and values contain:
  - **flag**: Boolean indicating if this category type has sub-categories
  - **category_value**: List of subcategory values for this type

**Data Source:** COB_AI_STAFFING_CATEGORY_XWALK table

**Example Response:**
```json
{
  "status": "success",
  "staffing_categories": {
    "CB - E/I": {
      "flag": true,
      "category_value": ["CB-Claim Edits", "CB-Inquiries", "F"]
    },
    "CB Newborn": {
      "flag": true,
      "category_value": ["CB Newborn-Claim Edits", "CB Newborn-Inquiries", "CB Newborn-eCAQH (Prevention)"]
    }
  }
}
```
""",
)
async def get_workforce_iq_staffing_categories_subcategories(request: WorkforceIQSimpleRequest) -> WorkforceIQStaffingCategorySubcategoriesResponse:
    """Get Staffing Category list with subcategories from crosswalk table for Workforce IQ."""
    try:
        # Check cache first
        cache_key = "workforce_iq:filters:staffing_categories_subcategories"
        if config.REDIS_ENABLED:
            cached_data = await cache_manager.get(cache_key)
            if cached_data:
                logger.info(f"[WORKFORCE_IQ_STAFFING_CATEGORIES_SUBCATEGORIES] Cache hit - returning {len(cached_data)} category types from cache")
                return WorkforceIQStaffingCategorySubcategoriesResponse(
                    status="success",
                    staffing_categories=cached_data,
                    message="Workforce IQ Staffing Categories with Subcategories retrieved successfully (cached)",
                    service="idiscovery-cob-dashboard-service"
                )
        
        logger.info(f"[WORKFORCE_IQ_STAFFING_CATEGORIES_SUBCATEGORIES] Cache miss - fetching from crosswalk table")
        
        # Build SQL query to fetch from crosswalk table with grouping
        query = f"""
        SELECT DISTINCT
            STAFFING_CATEGORY_TYPE as category_type_value,
            STAFFING_CATEGORY as category_value,
            CASE 
                WHEN COUNT(DISTINCT STAFFING_CATEGORY) OVER (PARTITION BY STAFFING_CATEGORY_TYPE) >= 1 
                THEN 'True' 
                ELSE 'False' 
            END as has_categories_flag
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
        WHERE STAFFING_CATEGORY_TYPE IS NOT NULL
          AND STAFFING_CATEGORY IS NOT NULL
        ORDER BY 
            STAFFING_CATEGORY_TYPE,
            STAFFING_CATEGORY
        """
        
        # Execute query
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000)
        
        # Transform results to dictionary format grouped by category_type_value
        categories_dict = {}
        for row in results:
            category_type = row.get('CATEGORY_TYPE_VALUE')
            category_value = row.get('CATEGORY_VALUE')
            has_flag = row.get('HAS_CATEGORIES_FLAG', 'False')
            
            # Convert string 'True'/'False' to boolean
            flag_bool = has_flag == 'True'
            
            if category_type not in categories_dict:
                categories_dict[category_type] = {
                    "flag": flag_bool,
                    "category_value": []
                }
            
            # Add category value to the list
            if category_value:
                categories_dict[category_type]["category_value"].append(category_value)
        
        logger.info(f"[WORKFORCE_IQ_STAFFING_CATEGORIES_SUBCATEGORIES] Retrieved {len(categories_dict)} category types from crosswalk table")
        
        # Cache the results
        if config.REDIS_ENABLED:
            await cache_manager.set(cache_key, categories_dict, ttl=config.METRIC_CACHE_TTL)
            logger.info(f"[WORKFORCE_IQ_STAFFING_CATEGORIES_SUBCATEGORIES] Cached {len(categories_dict)} category types with TTL={config.METRIC_CACHE_TTL}s")
        
        return WorkforceIQStaffingCategorySubcategoriesResponse(
            status="success",
            staffing_categories=categories_dict,
            message="Workforce IQ Staffing Categories with Subcategories retrieved successfully from crosswalk table",
            service="idiscovery-cob-dashboard-service"
        )
    except Exception as e:
        logger.error(f"Failed to retrieve Staffing Categories with Subcategories: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve Staffing Categories with Subcategories: {str(e)}")


# =============================================================================
# Work Type List API
# =============================================================================

@router.post(
    "/work-types",
    response_model=WorkforceIQWorkTypeListResponse,
    summary="Get List of Work Types for Workforce IQ View",
    description="""
Returns distinct Work Types from database for Workforce IQ, optionally filtered by Staffing Category.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format
- **category_value** (optional): List of staffing categories to filter work types (from staffing-categories-subcategories API)

**Response:**
- **work_types**: List of work type objects with name and ID

**Data Source:**
- COB_AI_INVNTRY_PROFILE (Work types)
- COB_AI_STAFFING_CATEGORY_XWALK (Category mapping)

**Filtering Logic:**
- If category_value is provided, returns only work types (INTAKE_SOURCE_SYSTEM) that belong to the selected staffing categories
- If category_value is empty or null, returns all work types
""",
)
async def get_workforce_iq_work_types(request: WorkforceIQWorkTypeRequest) -> WorkforceIQWorkTypeListResponse:
    """Get Work Type list for Workforce IQ from database with Redis caching."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
 
    try:
        # Build category filter
        category_filter = ""
        
        if request.category_value and len(request.category_value) > 0:
            # Create comma-separated list of categories for SQL IN clause
            categories_str = "', '".join(request.category_value)
            category_filter = f"AND x.STAFFING_CATEGORY IN ('{categories_str}')"
            category_key_part = "|".join(sorted(request.category_value))
            logger.info(f"[WORKFORCE_IQ_WORK_TYPES] Filtering by {len(request.category_value)} categories: {request.category_value}")
        else:
            category_key_part = "all"
            logger.info(f"[WORKFORCE_IQ_WORK_TYPES] No category filter - returning all work types")
        
        # Check cache first (include category filter in cache key)
        cache_key = f"workforce_iq:filters:work_types:{category_key_part}"
        if config.REDIS_ENABLED:
            cached_data = await cache_manager.get(cache_key)
            if cached_data:
                logger.info(f"[WORKFORCE_IQ_WORK_TYPES] Cache hit")
                return WorkforceIQWorkTypeListResponse(
                    status="success",
                    work_types=cached_data,
                    message="Workforce IQ Work Types retrieved successfully (cached)",
                    service="idiscovery-cob-dashboard-service"
                )
        
        logger.info(f"[WORKFORCE_IQ_WORK_TYPES] Cache miss - fetching from database")
        
        
        query = f"""
        SELECT DISTINCT COALESCE(x.INTAKE_SOURCE_SYSTEM, 'None') AS WORKTYPE
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK x
        WHERE 1=1
            {category_filter}
        ORDER BY WORKTYPE
        """
 
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000)
 
        work_types = [{"work_type_id": row['WORKTYPE'], "work_type_name": row['WORKTYPE']} for row in results if row.get('WORKTYPE')]
 
        logger.info(f"[WORKFORCE_IQ_WORK_TYPES] Retrieved {len(work_types)} work types from XWALK")
 
        if config.REDIS_ENABLED:
            await cache_manager.set(cache_key, work_types, ttl=config.METRIC_CACHE_TTL)
 
        return WorkforceIQWorkTypeListResponse(
            status="success",
            work_types=work_types,
            message="Workforce IQ Work Types retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
    except Exception as e:
        logger.error(f"Failed to retrieve Work Types: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve Work Types: {str(e)}")


# =============================================================================
# Market List API
# =============================================================================

@router.post(
    "/markets",
    response_model=WorkforceIQMarketListResponse,
    summary="Get List of Markets for Workforce IQ View",
    description="""
Returns distinct Markets from database for Workforce IQ, optionally filtered by LOB.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format
- **lobs** (optional): List of LOB values to filter markets (from LOB list API)

**Response:**
- **markets**: List of market objects with name and ID

**Data Source:**
- COB_AI_INVNTRY_PROFILE (filtered to last 18 months)

**Filtering Logic:**
- If lobs provided, returns only markets that have work items in the specified LOBs
- If no lobs provided, returns all markets
""",
)
async def get_workforce_iq_markets(request: WorkforceIQMarketRequest) -> WorkforceIQMarketListResponse:
    """Get Market list for Workforce IQ from database with Redis caching, optionally filtered by LOB."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Build LOB filter
        lob_filter = build_market_lob_filter(request.lobs)
        
        # Build cache key that includes LOB filter
        lob_key_part = "|".join(sorted(request.lobs)) if request.lobs else "all"
        cache_key = f"workforce_iq:filters:markets:lob={lob_key_part}"
        
        # Check cache first
        if config.REDIS_ENABLED:
            cached_data = await cache_manager.get(cache_key)
            if cached_data:
                logger.info(f"[WORKFORCE_IQ_MARKETS] Cache hit - returning {len(cached_data)} markets from cache")
                return WorkforceIQMarketListResponse(
                    status="success",
                    markets=cached_data,
                    message="Workforce IQ Markets retrieved successfully (cached)",
                    service="idiscovery-cob-dashboard-service"
                )
        
        logger.info(f"[WORKFORCE_IQ_MARKETS] Cache miss - fetching from database (lobs={request.lobs})")
        
        query = f"""
        SELECT DISTINCT COALESCE(MARKET, 'None') AS MARKET
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        WHERE PXUPDATEDATETIME >= DATEADD(month, -18, CURRENT_DATE())
            {lob_filter}
        ORDER BY MARKET
        """
        
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000)
        
        markets = [{"market_id": row['MARKET'], "market_name": row['MARKET']} for row in results if row.get('MARKET')]
        
        # Sort markets alphabetically by market_name
        markets.sort(key=lambda x: x['market_name'])
        
        logger.info(f"[WORKFORCE_IQ_MARKETS] Retrieved {len(markets)} markets from database")
        
        # Cache the result
        if config.REDIS_ENABLED:
            await cache_manager.set(cache_key, markets, ttl=config.METRIC_CACHE_TTL)
            logger.info(f"[WORKFORCE_IQ_MARKETS] Cached {len(markets)} markets with TTL={config.METRIC_CACHE_TTL}s")
        
        return WorkforceIQMarketListResponse(
            status="success",
            markets=markets,
            message="Workforce IQ Markets retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
    except Exception as e:
        logger.error(f"Failed to retrieve Markets: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve Markets: {str(e)}")


# =============================================================================
# Funding Model List API
# =============================================================================

@router.post(
    "/funding-models",
    response_model=WorkforceIQFundingModelListResponse,
    summary="Get List of Funding Models for Workforce IQ View",
    description="""
Returns distinct Funding Models from database for Workforce IQ based on date range.

**Input Parameters:**
- **user_id** (required): Logged-in user ID
- **start_date** (required): Start date in YYYY-MM-DD format
- **end_date** (required): End date in YYYY-MM-DD format

**Response:**
- **funding_models**: List of funding model objects with name and ID
""",
)
async def get_workforce_iq_funding_models(request: WorkforceIQSimpleRequest) -> WorkforceIQFundingModelListResponse:
    """Get Funding Model list for Workforce IQ from database with Redis caching."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Check cache first
        cache_key = "workforce_iq:filters:funding_models"
        if config.REDIS_ENABLED:
            cached_data = await cache_manager.get(cache_key)
            if cached_data:
                logger.info(f"[WORKFORCE_IQ_FUNDING_MODELS] Cache hit - returning {len(cached_data)} funding models from cache")
                return WorkforceIQFundingModelListResponse(
                    status="success",
                    funding_models=cached_data,
                    message="Workforce IQ Funding Models retrieved successfully (cached)",
                    service="idiscovery-cob-dashboard-service"
                )
        
        logger.info(f"[WORKFORCE_IQ_FUNDING_MODELS] Cache miss - fetching from database")
        
        query = f"""
        SELECT DISTINCT COALESCE(FUNDINGMODEL, 'None') AS FUNDINGMODEL
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        WHERE PXUPDATEDATETIME >= DATEADD(month, -18, CURRENT_DATE())
        ORDER BY FUNDINGMODEL
        """
        
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1000)
        
        funding_models = [{"funding_model_id": row['FUNDINGMODEL'], "funding_model_name": row['FUNDINGMODEL']} for row in results if row.get('FUNDINGMODEL')]
        
        logger.info(f"[WORKFORCE_IQ_FUNDING_MODELS] Retrieved {len(funding_models)} funding models from database")
        
        # Cache the result
        if config.REDIS_ENABLED:
            await cache_manager.set(cache_key, funding_models, ttl=config.METRIC_CACHE_TTL)
            logger.info(f"[WORKFORCE_IQ_FUNDING_MODELS] Cached {len(funding_models)} funding models with TTL={config.METRIC_CACHE_TTL}s")
        
        return WorkforceIQFundingModelListResponse(
            status="success",
            funding_models=funding_models,
            message="Workforce IQ Funding Models retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
    except Exception as e:
        logger.error(f"Failed to retrieve Funding Models: {type(e).__name__}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve Funding Models: {str(e)}")
