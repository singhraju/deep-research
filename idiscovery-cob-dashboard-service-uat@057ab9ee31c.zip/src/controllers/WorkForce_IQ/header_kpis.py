import asyncio
import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import WorkforceIQHeaderKPIsRequest, WorkforceIQHeaderKPIsResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, MEMBERSHIP_LOB_MAP
import config

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()


# =============================================================================
# SQL Queries
# =============================================================================

REQ_FTE_QUERY = f"""
WITH date_range_config AS (
    SELECT '{{start_date}}'::DATE AS period_start, '{{end_date}}'::DATE AS period_end
),
date_spine AS (
    SELECT DATEADD(DAY, SEQ4(), (SELECT period_start FROM date_range_config)) AS spine_date
    FROM TABLE(GENERATOR(ROWCOUNT => 10000))
    WHERE DATEADD(DAY, SEQ4(), (SELECT period_start FROM date_range_config)) <= (SELECT period_end FROM date_range_config)
),
date_periods AS (
    SELECT DISTINCT spine_date AS period_date
    FROM date_spine
),
period_grid AS (
    SELECT
        dp.period_date,
        CASE
            WHEN dp.period_date < CURRENT_DATE() THEN 'PAST'
            WHEN dp.period_date = CURRENT_DATE() THEN 'CURRENT'
            ELSE 'FUTURE'
        END AS date_category
    FROM date_periods dp
),
productive_hrs AS (
    SELECT ROUND(AVG(
        SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT +
        SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0 +
        SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
    ), 2) AS avg_productive_hrs_per_day
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
    WHERE UPPER(u.PYACCESSGROUP) LIKE '%FRONTLINE%'
      AND u.PRODUCTIVETIME IS NOT NULL
      AND CASE
          WHEN (SELECT period_end FROM date_range_config) < CURRENT_DATE() THEN
              u.LOGINDATE >= DATEADD(DAY, -90, (SELECT period_end FROM date_range_config))
              AND u.LOGINDATE <= (SELECT period_end FROM date_range_config)
          ELSE
              u.LOGINDATE >= DATEADD(DAY, -90, CURRENT_DATE())
              AND u.LOGINDATE <= CURRENT_DATE()
      END
),
cy_deduped AS (
    SELECT
        inv.PYID,
        inv.INTAKESOURCESYSTEM,
        inv.CYCLE_TIME,
        inv.PYSTATUSWORK,
        inv.PXCREATEDATETIME,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        inv.LOB AS LOB,
        PXCOMMITDATETIME,
        insrt_dt_time,
        REPORTTOMANAGERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
py_deduped AS (
    SELECT
        inv.PYID,
        inv.INTAKESOURCESYSTEM,
        inv.CYCLE_TIME,
        inv.PYSTATUSWORK,
        inv.PXCREATEDATETIME,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        inv.LOB AS LOB,
        PXCOMMITDATETIME,
        insrt_dt_time,
        REPORTTOMANAGERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY inv.PYID
        ORDER BY inv.PXCOMMITDATETIME DESC NULLS LAST, inv.insrt_dt_time DESC
    ) = 1
),
avg_cycle_time_last90 AS (
    SELECT
        COALESCE(inv.INTAKESOURCESYSTEM, 'None') AS intakesourcesystem,
        ROUND(AVG(inv.CYCLE_TIME) / 60.0, 2) AS avg_cycle_time_min
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.CYCLE_TIME IS NOT NULL
      AND inv.PYSTATUSWORK IN ('Resolved-Completed')
      AND CASE
          WHEN (SELECT period_end FROM date_range_config) < CURRENT_DATE() THEN
              inv.PYRESOLVEDTIMESTAMP >= DATEADD(DAY, -90,(SELECT period_end FROM date_range_config))
              AND inv.PYRESOLVEDTIMESTAMP < DATEADD(DAY, 1, (SELECT period_end FROM date_range_config))
          ELSE
              inv.PYRESOLVEDTIMESTAMP >= DATEADD(DAY, -90, CURRENT_DATE())
              AND inv.PYRESOLVEDTIMESTAMP < DATEADD(DAY, 1, CURRENT_DATE())
      END
      {{lob_filter}}
      {{intake_source_filter}}
    GROUP BY COALESCE(inv.INTAKESOURCESYSTEM, 'None')
),
cy_aggregated AS (
    SELECT
        cy.create_date AS period_date,
        COUNT(DISTINCT cy.PYID) AS current_year_actual_receipts
    FROM cy_deduped cy
    WHERE cy.PXCREATEDATETIME >= (SELECT period_start FROM date_range_config)
      AND cy.PXCREATEDATETIME < DATEADD(DAY, 1, (SELECT period_end FROM date_range_config))
      AND DATE(cy.PXCREATEDATETIME) <= (SELECT period_end FROM date_range_config)
      AND cy.PYSTATUSWORK IN (
          'Resolved-Completed',
          'Resolved-DupClose',
          'Resolved-BulkAutoClose',
          'New',
          'Pend-Decision',
          'Resolved-AutoCloseLink',
          'Open-ReviewIntake',
          'Pend',
          'Open-AuditReview',
          'Open-CAQHPortal'
      )
      {{lob_filter}}
      {{intake_source_filter}}
      {{manager_filter_cy}}
    GROUP BY cy.create_date
),
py_aggregated AS (
    SELECT
        CASE
            WHEN (MOD(YEAR(py.create_date), 4) = 0 AND (MOD(YEAR(py.create_date), 100) != 0 OR MOD(YEAR(py.create_date), 400) = 0))
                 OR (MOD(YEAR(py.create_date) + 1, 4) = 0 AND (MOD(YEAR(py.create_date) + 1, 100) != 0 OR MOD(YEAR(py.create_date) + 1, 400) = 0))
            THEN DATEADD(DAY, -2, DATEADD(YEAR, 1, py.create_date))
            ELSE DATEADD(DAY, -1, DATEADD(YEAR, 1, py.create_date))
        END AS period_date,
        COUNT(DISTINCT py.PYID) AS prior_year_actual_receipts
    FROM py_deduped py
    WHERE py.PXCREATEDATETIME >= DATEADD(DAY, 1, DATEADD(YEAR, -1, (SELECT period_start FROM date_range_config)))
      AND py.PXCREATEDATETIME < DATEADD(DAY, 2, DATEADD(YEAR, -1, (SELECT period_end FROM date_range_config)))
      AND py.PYSTATUSWORK IN (
          'Resolved-Completed',
          'Resolved-DupClose',
          'Resolved-BulkAutoClose',
          'New',
          'Pend-Decision',
          'Resolved-AutoCloseLink',
          'Open-ReviewIntake',
          'Pend',
          'Open-AuditReview',
          'Open-CAQHPortal'
      )
      {{lob_filter}}
      {{intake_source_filter}}
      {{manager_filter_py}}
    GROUP BY 1
),
month_mapping AS (
    SELECT 'January' AS month_name, 1 AS month_num UNION ALL
    SELECT 'February', 2 UNION ALL
    SELECT 'March', 3 UNION ALL
    SELECT 'April', 4 UNION ALL
    SELECT 'May', 5 UNION ALL
    SELECT 'June', 6 UNION ALL
    SELECT 'July', 7 UNION ALL
    SELECT 'August', 8 UNION ALL
    SELECT 'September', 9 UNION ALL
    SELECT 'October', 10 UNION ALL
    SELECT 'November', 11 UNION ALL
    SELECT 'December', 12
),
membership_data AS (
    SELECT
        md.YEAR AS membership_year,
        mm.month_num AS membership_month,
        CASE UPPER(TRIM(md.LOB))
            WHEN 'GB CAID' THEN 'MEDICAID'
            WHEN 'GB CARE' THEN 'MEDICARE'
            WHEN 'CSBD' THEN 'COMMERCIAL'
            ELSE 'GBD'
        END AS LOB,
        md.PROJECTED_MEMBERSHIP,
        md.ACTUAL_MEMBERSHIP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA md
    INNER JOIN month_mapping mm
        ON md.MONTH = mm.month_name
    WHERE md.YEAR IS NOT NULL
      AND md.MONTH IS NOT NULL
      {{lob_filter_membership}}
),
prior_year_membership AS (
    SELECT
        md.LOB,
        md.ACTUAL_MEMBERSHIP,
        DATE_FROM_PARTS(md.membership_year, md.membership_month, 1) AS month_start_date
    FROM membership_data md
    WHERE md.membership_year BETWEEN YEAR(DATEADD(YEAR, -1, (SELECT period_start FROM date_range_config)))
        AND YEAR(DATEADD(YEAR, -1, (SELECT period_end FROM date_range_config)))
),
py_membership_agg AS (
    SELECT
        pm.month_start_date,
        SUM(pm.ACTUAL_MEMBERSHIP) AS prior_year_actual_membership
    FROM prior_year_membership pm
    GROUP BY pm.month_start_date
),
current_year_membership AS (
    SELECT
        md.LOB,
        md.PROJECTED_MEMBERSHIP,
        DATE_FROM_PARTS(md.membership_year, md.membership_month, 1) AS month_start_date
    FROM membership_data md
    WHERE md.membership_year BETWEEN YEAR((SELECT period_start FROM date_range_config))
        AND YEAR((SELECT period_end FROM date_range_config))
),
cy_membership_agg AS (
    SELECT
        cm.month_start_date,
        SUM(cm.PROJECTED_MEMBERSHIP) AS current_year_projected_membership
    FROM current_year_membership cm
    GROUP BY cm.month_start_date
),
all_periods AS (
    SELECT DISTINCT
        g.period_date,
        g.date_category
    FROM period_grid g
),
projected_receipts_calc AS (
    SELECT
        ap.period_date,
        ap.date_category,
        ROUND(
            COALESCE(py.prior_year_actual_receipts, 0) /
            NULLIF(pm_monthly.prior_year_actual_membership, 0) *
            COALESCE(cm_monthly.current_year_projected_membership, 0)
        , 0) AS projected_receipts
    FROM all_periods ap
    LEFT JOIN py_aggregated py
        ON ap.period_date = py.period_date
    LEFT JOIN py_membership_agg pm_monthly
        ON DATE_TRUNC('MONTH', DATEADD(YEAR, -1, ap.period_date)) = pm_monthly.month_start_date
    LEFT JOIN cy_membership_agg cm_monthly
        ON DATE_TRUNC('MONTH', ap.period_date) = cm_monthly.month_start_date
),
avg_cycle_time_overall AS (
    SELECT COALESCE(ROUND(AVG(avg_cycle_time_min), 2), 0) AS overall_avg_cycle_time_min
    FROM avg_cycle_time_last90
),
fte_calculation AS (
    SELECT
        prc.period_date,
        prc.projected_receipts,
        COALESCE(ct.overall_avg_cycle_time_min, 0) AS cycle_time_in_min,
        prc.projected_receipts * COALESCE(ct.overall_avg_cycle_time_min, 0) AS total_minutes
    FROM projected_receipts_calc prc
    CROSS JOIN avg_cycle_time_overall ct
),
fte_summary AS (
    SELECT
        period_date,
        CEIL(
            SUM(total_minutes) / 60.0 / NULLIF(
                (SELECT avg_productive_hrs_per_day FROM productive_hrs),
                0
            )
        ) AS required_fte
    FROM fte_calculation
    GROUP BY period_date
)
SELECT ROUND(AVG(required_fte), 2) AS REQUIRED_FTE
FROM fte_summary
"""


ACTUAL_FTE_QUERY = f"""
WITH config AS (
    SELECT
        '{{start_date}}'::DATE AS date_from,
        '{{end_date}}'::DATE AS date_to
),
effective_range AS (
    SELECT
        date_from,
        LEAST(date_to, CURRENT_DATE()) AS date_to,
        CASE WHEN date_from > CURRENT_DATE() THEN TRUE ELSE FALSE END AS is_future
    FROM config
),
user_staffing_cat AS (
    SELECT
        up.USERID,
        xw.STAFFING_CATEGORY AS STAFFING_CATEGORY,
        up.logindate
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE up
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xw
        ON TRIM(up.STAFFINGCATEGORY) = TRIM(xw.STAFFING_CATEGORY)
    WHERE up.USERID IS NOT NULL
),
total_head AS (
    SELECT
        snapshot_date,
        userid,
        manager_id,
        STAFFING_CATEGORY
    FROM (
        SELECT
            TRY_CAST(w.ASOFTODAY AS DATE) AS snapshot_date,
            w.EMPLOYEE_DOMAIN_ID AS userid,
            w.MANAGER_DOMAIN_ID AS manager_id,
            COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY,
            ROW_NUMBER() OVER (
                PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.ASOFTODAY AS DATE)
                ORDER BY usc.logindate DESC NULLS LAST
            ) AS rn_sc
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
        LEFT JOIN user_staffing_cat usc
            ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID)
            AND usc.logindate <= TRY_CAST(w.ASOFTODAY AS DATE)
        WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
          AND (SELECT is_future FROM effective_range) = FALSE
          AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
          AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT date_from FROM effective_range) AND (SELECT date_to FROM effective_range)
          AND DAYOFWEEK(TRY_CAST(w.ASOFTODAY AS DATE)) NOT IN (0, 6)
          
    )
    WHERE rn_sc = 1
    {{manager_filter}}
    {{staffing_category_filter}}
),
time_off AS (
    SELECT userid, time_off_date, hours_off, STAFFING_CATEGORY, manager_id
    FROM (
        SELECT
            w.EMPLOYEE_DOMAIN_ID AS userid,
            w.MANAGER_DOMAIN_ID AS manager_id,
            TRY_CAST(w.TIME_OFF_DATE AS DATE) AS time_off_date,
            TRY_CAST(w.HOURS AS FLOAT) AS hours_off,
            COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY,
            ROW_NUMBER() OVER (
                PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.TIME_OFF_DATE AS DATE), w.TIME_OFF_TYPE, w.TIME_OFF_ENTRY_UNIQUE_KEY
                ORDER BY w.ASOFTODAY DESC, usc.logindate DESC NULLS LAST
            ) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
        LEFT JOIN user_staffing_cat usc
            ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID)
            AND usc.logindate <= TRY_CAST(w.TIME_OFF_DATE AS DATE)
        WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
          AND w.STATUS IN ('Approved', 'Submitted')
          AND w.TIME_OFF_TYPE IN (
              'Paid Time Off - Approved/Scheduled',
              'Paid Time Off',
              'Paid Time Off - Supplemental',
              'Paid Time Off - Unapproved/Unscheduled',
              'Sick Time',
              'Sick Time - Approved',
              'Sick Time - Unapproved',
              'Sick Time - Supplemental',
              'Sick Time - Intermittent LOA',
              'Wellness Days Off',
              'Paid Time Off - Kin Care/CA Sick',
              'Critical Care Leave',
              'Paid Parental Leave',
              'Other Paid Time - New Parent Transition',
              'Other Paid Time - Bereavement',
              'Other Paid Time - Jury Duty',
              'Other Paid Time - Voting',
              'Other Paid Time - Voluntary Time Off/Community Service',
              'Other Paid Time - Business Disruption/Sent Home/Lack of Work',
              'Paid Time Off - Intermittent LOA',
              'Other Paid Time - Intermittent LOA',
              'Non Paid Time - Intermittent LOA',
              'Non Paid Time - Approved/Voluntary',
              'Non Paid Time - Worker''s Compensation',
              'Non Paid Time - Victims of Domestic Violence & Crimes',
              'Non Paid Time - Unapproved'
          )
          AND (SELECT is_future FROM effective_range) = FALSE
          AND TRY_CAST(w.TIME_OFF_DATE AS DATE) IS NOT NULL
          AND TRY_CAST(w.TIME_OFF_DATE AS DATE) BETWEEN (SELECT date_from FROM effective_range) AND (SELECT date_to FROM effective_range)
          
    ) WHERE rn = 1
    {{manager_filter}}
    {{staffing_category_filter}}
),
grouped_head AS (
    SELECT
        snapshot_date AS period_date,
        COUNT(DISTINCT userid) AS total_head_count
    FROM total_head
    WHERE snapshot_date <= CURRENT_DATE()
    GROUP BY 1
),
holidays AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),
time_off_with_periods AS (
    SELECT
        t.time_off_date AS period_date,
        t.hours_off
    FROM time_off t
    WHERE EXISTS (
        SELECT 1 FROM total_head th
        WHERE UPPER(th.userid) = UPPER(t.userid)
          AND th.snapshot_date = t.time_off_date
    )
),
adjusted_time_off AS (
    SELECT
        t.period_date,
        ROUND(SUM(t.hours_off) / 8.0, 2) AS adjusted_fte_off
    FROM time_off_with_periods t
    INNER JOIN grouped_head g ON t.period_date = g.period_date
    GROUP BY t.period_date
)
SELECT ROUND(AVG(
    CASE
        WHEN EXISTS (SELECT 1 FROM holidays h WHERE h.holiday_date = g.period_date) THEN NULL
        ELSE GREATEST(CEIL(g.total_head_count - COALESCE(at.adjusted_fte_off, 0)), 0)
    END
), 2) AS ACTUAL_FTE
FROM grouped_head g
LEFT JOIN adjusted_time_off at ON g.period_date = at.period_date
"""


STAFF_UTILIZATION_PCT_QUERY = f"""
WITH manager_users AS (
    SELECT DISTINCT
        PYRESOLVEDUSERID AS USERID
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
      {{manager_filter}}
      AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
),
user_activity_today AS (
    SELECT 
        ua.DOMAINID AS USERID,
        SUM(
            DATEDIFF(second, 
                ua.LOGINTIME, 
                COALESCE(ua.LOGOUTTIME, CURRENT_TIMESTAMP)
            )
        ) AS TOTAL_ACTIVITY_TIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_ACTIVITY ua
    WHERE DATE(ua.LOGINTIME) = CURRENT_DATE
    GROUP BY ua.DOMAINID
)
SELECT 
    ROUND(
        SUM(
            CASE 
                WHEN up.PRODUCTIVETIME IS NOT NULL AND up.PRODUCTIVETIME != '' THEN
                    (SPLIT_PART(up.PRODUCTIVETIME, ':', 1)::INTEGER * 3600 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 2)::INTEGER * 60 + 
                     SPLIT_PART(up.PRODUCTIVETIME, ':', 3)::INTEGER)
                ELSE 0
            END
        ) * 100.0 / NULLIF(
            (SUM(
                CASE 
                    WHEN up.LOGINDATE = CURRENT_DATE AND uat.TOTAL_ACTIVITY_TIME IS NOT NULL
                    THEN uat.TOTAL_ACTIVITY_TIME
                    ELSE up.TOTALSYSTEMTIME
                END
            ) - SUM(COALESCE(up.FUSE_NON_PRODUCTIVE_TIME, 0))),
            0
        ),
    2) AS STAFF_UTILIZATION_PCT
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE up  
INNER JOIN manager_users mu
    ON up.USERID = mu.USERID  
LEFT JOIN user_activity_today uat
    ON up.USERID = uat.USERID
WHERE up.TOTALSYSTEMTIME IS NOT NULL
  AND up.FUSE_NON_PRODUCTIVE_TIME IS NOT NULL
  AND up.PRODUCTIVETIME IS NOT NULL
  AND up.LOGINDATE >= '{{start_date}}'
  AND up.LOGINDATE < DATEADD(day, 1, '{{end_date}}'::DATE)
"""


CYCLE_TIME_PER_FTE_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        CYCLE_TIME,
        PYRESOLVEDUSERID,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        LOB,
        MARKET,
        INTAKESOURCESYSTEM,
        FUNDINGMODEL,
        PXCOMMITDATETIME,
        insrt_dt_time,
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID,
        CYCLE_TIME,
        PYRESOLVEDUSERID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND CYCLE_TIME IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{intake_source_filter}}
      {{market_filter}}
      {{funding_model_filter}}
      {{manager_filter}}
),
per_fte AS (
    SELECT
        PYRESOLVEDUSERID,
        COUNT(DISTINCT PYID) AS items_resolved,
        ROUND(AVG(CYCLE_TIME), 2) AS avg_cycle_time_seconds
    FROM filtered_inventory
    GROUP BY PYRESOLVEDUSERID
)
SELECT
    COUNT(DISTINCT PYRESOLVEDUSERID) AS total_ftes,
    ROUND(AVG(avg_cycle_time_seconds), 2) AS avg_cycle_time_per_fte_seconds,
    ROUND(AVG(avg_cycle_time_seconds) / 60, 2) AS avg_cycle_time_per_fte_minutes
FROM per_fte
"""

CAPACITY_PER_FTE_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYRESOLVEDUSERID,
        RESOLVEDUSERNAME,
        PYSTATUSWORK,
        CYCLE_TIME,
        DATE(PYRESOLVEDTIMESTAMP) AS RESOLVED_DATE,
        REPORTTOMANAGERID,
        ASSOCIATEACCESSGROUP,
        LOB,
        MARKET,
        FUNDINGMODEL,
        INTAKESOURCESYSTEM
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID, 
        RESOLVED_DATE,
        PYRESOLVEDUSERID,
        RESOLVEDUSERNAME
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed')
      AND RESOLVED_DATE IS NOT NULL
      AND RESOLVED_DATE >= '{{start_date}}'::DATE
      AND RESOLVED_DATE < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND ASSOCIATEACCESSGROUP IN ('COB:FrontLineUser', 'COB:OffFrontlineUser', 'CLMSCCU:FrontLine')
      {{lob_filter}}
      {{manager_filter}}
),
grouped_count AS (
    SELECT 
        RESOLVED_DATE, 
        PYRESOLVEDUSERID, 
        COUNT(DISTINCT PYID) AS resolved_count 
    FROM filtered_inventory 
    GROUP BY RESOLVED_DATE, PYRESOLVEDUSERID
)
SELECT 
    ROUND(AVG(resolved_count), 2) AS capacity_per_fte
FROM grouped_count
"""

BACKLOG_VOLUME_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        LOB,
        MARKET,
        INTAKESOURCESYSTEM,
        PXCREATEOPNAME,
        FUNDINGMODEL,
        PXCOMMITDATETIME,
        insrt_dt_time,
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
)
SELECT
    COUNT(DISTINCT PYID) AS TOTAL_BACKLOG_VOLUME
FROM latest_inventory
WHERE 1=1
  {{lob_filter}}
  {{intake_source_filter}}
  {{market_filter}}
  {{funding_model_filter}}
  AND PXCREATEDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
  AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{{end_date}}'::DATE))
"""


DAYS_WORK_ON_HAND_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        LOB,
        MARKET,
        INTAKESOURCESYSTEM,
        PXCREATEOPNAME,
        FUNDINGMODEL,
        PXCOMMITDATETIME,
        insrt_dt_time,
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
backlog_filtered_inventory AS (
    SELECT *
    FROM latest_inventory
    WHERE 1=1
      {{lob_filter}}
      {{market_filter}}
      {{funding_model_filter}}
      {{backlog_intake_source_filter}}
),
regular_filtered_inventory AS (
    SELECT *
    FROM latest_inventory
    WHERE 1=1
      {{lob_filter}}
      {{market_filter}}
      {{funding_model_filter}}
      {{intake_source_filter}}
),
backlog_volume AS (
    SELECT COUNT(DISTINCT PYID) AS backlog_count
    FROM backlog_filtered_inventory
    WHERE PXCREATEDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{{end_date}}'::DATE))
),
new_inventory AS (
    SELECT COUNT(DISTINCT PYID) AS new_inventory_count
    FROM regular_filtered_inventory
    WHERE PXCREATEDATETIME >= '{{start_date}}'
      AND PXCREATEDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND (PYSTATUSWORK LIKE 'Open%' OR PYSTATUSWORK LIKE 'New%')
),
resolved_items AS (
    SELECT
        PYID,
        PYRESOLVEDTIMESTAMP
    FROM regular_filtered_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND PYRESOLVEDTIMESTAMP >= DATEADD(day, -90, '{{end_date}}'::DATE)
      AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
),
total_resolved AS (
    SELECT COUNT(DISTINCT PYID) AS total_resolved_cases
    FROM resolved_items
),
date_range AS (
    SELECT
        DATEADD(day, SEQ4(), DATEADD(day, -90, '{{end_date}}'::DATE)) AS calendar_date
    FROM TABLE(GENERATOR(ROWCOUNT => 91))
),
holidays AS (
    SELECT DISTINCT DATE
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA
    WHERE DATE >= DATEADD(day, -90, '{{end_date}}'::DATE)
      AND DATE <= '{{end_date}}'::DATE
),
working_days AS (
    SELECT COUNT(*) AS total_working_days
    FROM date_range dr
    LEFT JOIN holidays h ON dr.calendar_date = h.DATE
    WHERE DAYOFWEEK(dr.calendar_date) NOT IN (0, 6)
      AND h.DATE IS NULL
),
avg_resolved AS (
    SELECT
        ROUND(tr.total_resolved_cases::FLOAT / NULLIF(wd.total_working_days, 0), 2) AS avg_resolved_per_day
    FROM total_resolved tr
    CROSS JOIN working_days wd
)
SELECT
    bv.backlog_count,
    ni.new_inventory_count,
    ar.avg_resolved_per_day,
    ROUND((bv.backlog_count + ni.new_inventory_count)::FLOAT / NULLIF(ar.avg_resolved_per_day, 0), 2) AS days_work_on_hand
FROM backlog_volume bv
CROSS JOIN new_inventory ni
CROSS JOIN avg_resolved ar
"""

AVG_RESOLVED_PER_DAY_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PYRESOLVEDTIMESTAMP,
        REPORTTOMANAGERID,
        LOB,
        INTAKESOURCESYSTEM,
        PXCOMMITDATETIME,
        insrt_dt_time,
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
filtered_inventory AS (
    SELECT
        PYID
    FROM latest_inventory
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
      {{intake_source_filter}}
      {{manager_filter}}
),
total_resolved AS (
    SELECT COUNT(DISTINCT PYID) AS total_resolved_cases
    FROM filtered_inventory
),
date_range AS (
    SELECT
        DATEADD(day, SEQ4(), '{{start_date}}'::DATE) AS calendar_date
    FROM TABLE(GENERATOR(ROWCOUNT => 600))
    WHERE DATEADD(day, SEQ4(), '{{start_date}}'::DATE) <= '{{end_date}}'::DATE
),
holidays AS (
    SELECT DISTINCT DATE
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA
    WHERE DATE BETWEEN '{{start_date}}'::DATE AND '{{end_date}}'::DATE
),
working_days AS (
    SELECT COUNT(*) AS total_working_days
    FROM date_range dr
    LEFT JOIN holidays h ON dr.calendar_date = h.DATE
    WHERE DAYOFWEEK(dr.calendar_date) NOT IN (0, 6)
      AND h.DATE IS NULL
)
SELECT
    tr.total_resolved_cases,
    wd.total_working_days,
    ROUND(tr.total_resolved_cases::FLOAT / NULLIF(wd.total_working_days, 0), 2) AS avg_resolved_per_day
FROM total_resolved tr
CROSS JOIN working_days wd
"""

NET_INVENTORY_CHANGE_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        LOB,
        MARKET,
        INTAKESOURCESYSTEM,
        PXCREATEOPNAME,
        FUNDINGMODEL,
        PXCOMMITDATETIME,
        insrt_dt_time,
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC
    ) = 1
),
backlog_filtered_inventory AS (
    SELECT *
    FROM latest_inventory
    WHERE 1=1
      {{lob_filter}}
      {{market_filter}}
      {{backlog_intake_source_filter}}
),
regular_filtered_inventory AS (
    SELECT *
    FROM latest_inventory
    WHERE 1=1
      {{lob_filter}}
      {{market_filter}}
      {{intake_source_filter}}
),
backlog_counts AS (
    SELECT
        COUNT(DISTINCT CASE
            WHEN PXCREATEDATETIME < '{{start_date}}'::DATE
                 AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= '{{start_date}}'::DATE)
                 AND PYID IS NOT NULL
            THEN PYID
        END) AS backlog_count
    FROM backlog_filtered_inventory
),
regular_counts AS (
    SELECT
        COUNT(DISTINCT CASE
            WHEN PYSTATUSWORK IS NOT NULL
                 AND PXCREATEDATETIME >= '{{start_date}}'
                 AND PXCREATEDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
                 AND (PYSTATUSWORK LIKE 'Open%' OR PYSTATUSWORK LIKE 'New%')
                 AND PYID IS NOT NULL
            THEN PYID
        END) AS added_count,
        COUNT(DISTINCT CASE
            WHEN PYSTATUSWORK IS NOT NULL
                 AND PYSTATUSWORK LIKE 'Resolved%'
                 AND PYRESOLVEDTIMESTAMP >= '{{start_date}}'
                 AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{{end_date}}'::DATE)
                 AND PYID IS NOT NULL
            THEN PYID
        END) AS resolved_count
    FROM regular_filtered_inventory
)
SELECT
    COALESCE(b.backlog_count, 0) AS backlog_count,
    COALESCE(r.added_count, 0) AS added_count,
    COALESCE(r.resolved_count, 0) AS resolved_count,
    COALESCE(b.backlog_count, 0) + COALESCE(r.added_count, 0) - COALESCE(r.resolved_count, 0) AS end_of_the_day_backlog,
    end_of_the_day_backlog - backlog_count AS net_inventory_change
FROM backlog_counts b
CROSS JOIN regular_counts r
"""


SLA_RISK_PCT_QUERY = f"""
WITH latest_inventory AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        EXTERNALDUEDATE,
        LOB,
        MARKET,
        INTAKESOURCESYSTEM,
        PXCREATEOPNAME,
        FUNDINGMODEL,
        PXCOMMITDATETIME,
        insrt_dt_time,
        DATEDIFF('hour', CURRENT_TIMESTAMP, EXTERNALDUEDATE) AS hours_until_sla_breach
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY PYID
        ORDER BY PXCOMMITDATETIME DESC,insrt_dt_time DESC, EXTERNALDUEDATE NULLS LAST
    ) = 1
),
filtered_inventory AS (
    SELECT *
    FROM latest_inventory
    WHERE 1=1
      {{lob_filter}}
      {{market_filter}}
      {{backlog_intake_source_filter}}
      AND PXCREATEDATETIME < DATEADD(day, 1, '{{end_date}}'::DATE)
      AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{{end_date}}'::DATE))
      AND EXTERNALDUEDATE IS NOT NULL
)
SELECT
    COUNT(*) AS total_backlog_items,
    SUM(CASE WHEN hours_until_sla_breach <= 72 AND hours_until_sla_breach > 0 THEN 1 ELSE 0 END) AS items_at_sla_risk,
    ROUND(
        (SUM(CASE WHEN hours_until_sla_breach <= 72 AND hours_until_sla_breach > 0 THEN 1 ELSE 0 END) * 100.0) /
        NULLIF(COUNT(*), 0),
        2
    ) AS sla_risk_pct
FROM filtered_inventory
"""


# =============================================================================
# Filter Building Functions
# =============================================================================


def build_workday_lob_filter(lob: Optional[List[str]] = None) -> str:
    if not lob or len(lob) == 0:
        return ""
    lob_values = "', '".join(lob)
    return f"AND UPPER(TRIM(ul.LOB)) IN ('{lob_values}')"

def build_workday_manager_filter(manager: Optional[List[str]] = None) -> str:
    if not manager or len(manager) == 0:
        return ""
    manager_values = "', '".join(manager)
    return f"AND COALESCE(TRIM(w.MANAGER_DOMAIN_ID), 'None') IN ('{manager_values}')"

def build_actual_fte_manager_filter(manager: Optional[List[str]] = None) -> str:
    """Build manager filter for ACTUAL_FTE_QUERY outer query (uses manager_id alias)."""
    if not manager or len(manager) == 0:
        return ""

    null_requested = "None" in manager
    non_null_managers = [m for m in manager if m != "None"]

    if null_requested and non_null_managers:
        manager_values = "', '".join(non_null_managers)
        return f"AND (COALESCE(TRIM(manager_id), 'None') IN ('{manager_values}') OR manager_id IS NULL)"
    elif null_requested:
        return "AND (COALESCE(TRIM(manager_id), 'None') = 'None' OR manager_id IS NULL)"
    else:
        manager_values = "', '".join(non_null_managers)
        return f"AND COALESCE(TRIM(manager_id), 'None') IN ('{manager_values}')"

def build_manager_filter(manager: Optional[List[str]] = None) -> str:
    """Build manager filter for REPORTTOMANAGERID column."""
    if not manager or len(manager) == 0:
        return ""
    manager_values = "', '".join(manager)
    return f"AND COALESCE(REPORTTOMANAGERID, 'None') IN ('{manager_values}')"

def build_manager_filter_user_profile(manager: Optional[List[str]] = None) -> str:
    """Build manager filter for USER_PROFILE table (PYREPORTTO column)."""
    if not manager or len(manager) == 0:
        return ""
    manager_values = "', '".join(manager)
    return f"AND PYREPORTTO IN ('{manager_values}')"

def build_user_date_filter(start_date: str, end_date: str) -> str:
    """Build date filter for user profile table (LOGINDATE column)."""
    return f"AND up.LOGINDATE >= '{start_date}' AND up.LOGINDATE < DATEADD(day, 1, '{end_date}'::DATE)"

def build_created_date_filter(end_date: str) -> str:
    """Build created date filter for backlog (before end_date + 1 day)."""
    return f"AND PXCREATEDATETIME < DATEADD(day, 1, '{end_date}'::DATE)"

def build_resolved_date_filter(end_date: str) -> str:
    """Build resolved date filter for backlog (NULL or after end_date)."""
    return f"AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= DATEADD(day, 1, '{end_date}'::DATE))"


def build_intake_source_filter(work_type: Optional[List[str]] = None) -> str:
    """Build intake source filter (INTAKESOURCESYSTEM column)."""
    if not work_type or len(work_type) == 0:
        return ""
    work_type_values = "', '".join(work_type)
    return f"AND INTAKESOURCESYSTEM IN ('{work_type_values}')"


def build_req_fte_intake_filter(work_type: Optional[List[str]] = None) -> str:
    """Build intake source filter for Required FTE calculation.
    
    Always excludes 'Facets Pend' and 'CCERT' from Required FTE calculations
    as these intake sources should not be included in FTE requirements.
    
    Args:
        work_type: Optional list of work types (intake source systems) to filter
        
    Returns:
        SQL filter string for INTAKESOURCESYSTEM column with exclusions
    """
    # Define sources to always exclude from Required FTE calculations
    excluded_sources = ['Facets Pend', 'CCERT']
    
    if not work_type or len(work_type) == 0:
        # No user filter - just exclude unwanted sources
        excluded_list = "', '".join(excluded_sources)
        return f"AND COALESCE(INTAKESOURCESYSTEM, 'None') NOT IN ('{excluded_list}')"
    
    # Filter out excluded sources from user selections
    valid_types = [wt for wt in work_type if wt not in excluded_sources]
    
    if not valid_types:
        # User only selected excluded sources - return filter that excludes them
        excluded_list = "', '".join(excluded_sources)
        return f"AND COALESCE(INTAKESOURCESYSTEM, 'None') NOT IN ('{excluded_list}')"
    
    # Build filter with valid types AND exclusion of unwanted sources
    work_type_values = "', '".join(valid_types)
    excluded_list = "', '".join(excluded_sources)
    return f"AND INTAKESOURCESYSTEM IN ('{work_type_values}') AND COALESCE(INTAKESOURCESYSTEM, 'None') NOT IN ('{excluded_list}')"


def build_market_filter(market: Optional[List[str]] = None) -> str:
    if not market or len(market) == 0:
        return ""
    null_requested = "None" in market
    non_null_markets = [m for m in market if m != "None"]
    if null_requested and non_null_markets:
        market_values = "', '".join(non_null_markets)
        return f"AND (MARKET IN ('{market_values}') OR MARKET IS NULL)"
    elif null_requested:
        return "AND MARKET IS NULL"
    else:
        market_values = "', '".join(non_null_markets)
        return f"AND MARKET IN ('{market_values}')"


def build_funding_model_filter(funding_model: Optional[List[str]] = None) -> str:
    if not funding_model or len(funding_model) == 0:
        return ""
    null_requested = "None" in funding_model
    non_null_models = [f for f in funding_model if f != "None"]
    if null_requested and non_null_models:
        funding_model_values = "', '".join(non_null_models)
        return f"AND (FUNDINGMODEL IN ('{funding_model_values}') OR FUNDINGMODEL IS NULL)"
    elif null_requested:
        return "AND FUNDINGMODEL IS NULL"
    else:
        funding_model_values = "', '".join(non_null_models)
        return f"AND FUNDINGMODEL IN ('{funding_model_values}')"


def build_date_filter(start_date: str, end_date: str) -> str:
    """Build date filter for PYRESOLVEDTIMESTAMP column."""
    return f"AND PYRESOLVEDTIMESTAMP >= '{start_date}' AND PYRESOLVEDTIMESTAMP < DATEADD(day, 1, '{end_date}'::DATE)"


def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter supporting NULL values."""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (LOB IN ('{lob_values}') OR LOB IS NULL)"
    elif null_requested:
        return "AND LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND LOB IN ('{lob_values}')"



def build_backlog_intake_source_filter(work_type: Optional[List[str]] = None) -> str:
    """Build backlog-only INTAKESOURCESYSTEM filter excluding *-Dup except Solution Central-Dup.
    
    Solution Central-Dup records are included but only where Pxcreateopname = 'EFUSE-SYSTEM'.
    """
    if not work_type or len(work_type) == 0:
        return ""

    regular_types = []
    include_solution_central_dup = False
    for wt in work_type:
        if not wt:
            continue

        upper_wt = wt.upper()
        if upper_wt == "SOLUTION CENTRAL-DUP":
            include_solution_central_dup = True
        elif "-DUP" not in upper_wt:
            regular_types.append(wt)

    if not regular_types and not include_solution_central_dup:
        return "AND INTAKESOURCESYSTEM = ''"

    conditions = []
    if regular_types:
        work_type_values = "', '".join(regular_types)
        conditions.append(f"INTAKESOURCESYSTEM IN ('{work_type_values}')")
    if include_solution_central_dup:
        conditions.append("(INTAKESOURCESYSTEM IN ('Solution Central-Dup') AND Pxcreateopname = 'EFUSE-SYSTEM')")

    return f"AND ({' OR '.join(conditions)})"


def build_staffing_category_filter(staffing_category: Optional[List[str]] = None) -> str:
    """Build staffing category filter for ACTUAL_FTE_QUERY outer query (uses STAFFING_CATEGORY alias)."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    null_requested = "None" in staffing_category
    non_null_categories = [c for c in staffing_category if c != "None"]
    
    if null_requested and non_null_categories:
        category_values = "', '".join(non_null_categories)
        return f"AND (COALESCE(STAFFING_CATEGORY, 'None') IN ('{category_values}') OR STAFFING_CATEGORY IS NULL)"
    elif null_requested:
        return "AND (COALESCE(STAFFING_CATEGORY, 'None') = 'None' OR STAFFING_CATEGORY IS NULL)"
    else:
        category_values = "', '".join(non_null_categories)
        return f"AND COALESCE(STAFFING_CATEGORY, 'None') IN ('{category_values}')"


# =============================================================================
# API Endpoint
# =============================================================================

@router.post(
    "/header-kpis",
    response_model=WorkforceIQHeaderKPIsResponse,
    summary="Get Workforce IQ Header KPIs",
    description="""Returns key performance indicators for Workforce IQ dashboard:
- Required FTE: Required full-time equivalent count
- Actual FTE: Actual full-time equivalent count
- Staff Utilization %: Staff utilization percentage
- Cycle Time per FTE: Average cycle time per FTE
- Capacity per FTE: Capacity per FTE
- Backlog Volume: Current backlog volume
- Days Work on Hand: Days of work on hand
- Avg Resolved per Day: Average items resolved per day
- Net Inventory Change: Net inventory change
- SLA Risk %: SLA risk percentage"""
)
async def get_workforce_iq_header_kpis(request: WorkforceIQHeaderKPIsRequest) -> WorkforceIQHeaderKPIsResponse:
    """Workforce IQ Header KPIs endpoint with parallel query execution."""
    return await execute_header_kpis_query(request)


async def execute_header_kpis_query(request: WorkforceIQHeaderKPIsRequest) -> WorkforceIQHeaderKPIsResponse:
    """Execute header KPIs query logic with parallel query execution."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        engine = connection_manager.get_engine()

        # Build filters
        manager_filter = build_manager_filter(request.manager)
        user_date_filter = build_user_date_filter(request.start_date, request.end_date)
        intake_source_filter = build_intake_source_filter(request.work_type)
        req_fte_intake_filter = build_req_fte_intake_filter(request.work_type)  # Dedicated filter for Required FTE (excludes Facets Pend & CCERT)
        backlog_intake_source_filter = build_backlog_intake_source_filter(request.work_type)
        market_filter = build_market_filter(request.market)
        funding_model_filter = build_funding_model_filter(request.funding_model)
        date_filter = build_date_filter(request.start_date, request.end_date)
        lob_filter = build_lob_filter(request.lob)
        #staffing_category_filter = build_staffing_category_filter(request.staffing_category)
        workday_lob_filter = build_workday_lob_filter(request.lob)
        workday_manager_filter = build_workday_manager_filter(request.manager)

        lob_list = request.lob if request.lob else []

        if lob_list:
            lob_values = ", ".join([f"'{l.upper()}'" if l != "None" else "'NONE'" for l in lob_list])
        else:
            lob_values = "'CROSSOVER','GRS','MMP','MEDSUPP','SUP','NONE','MEDICARE','COMMERCIAL','INT','MEDICAID','KCP','EGR'"

        if request.lob:
            mapped = list(set([MEMBERSHIP_LOB_MAP.get(l, l.upper()) for l in request.lob if l != "None"]))
            quoted = "', '".join(mapped)
            lob_filter_membership = f"AND UPPER(TRIM(md.LOB)) IN ('{quoted}')"
        else:
            lob_filter_membership = ""

        manager_filter_cy = manager_filter.replace('inv.', 'cy.') if manager_filter else ''
        manager_filter_py = manager_filter.replace('inv.', 'py.') if manager_filter else ''

        req_fte_query = REQ_FTE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            intake_source_filter=req_fte_intake_filter,  # Use dedicated filter that excludes Facets Pend & CCERT
            lob_filter_membership=lob_filter_membership,
            manager_filter_cy=manager_filter_cy,
            manager_filter_py=manager_filter_py
        )

        staffing_category_filter = build_staffing_category_filter(request.staffing_category)
        actual_fte_manager_filter = build_actual_fte_manager_filter(request.manager)
        
        actual_fte_query = ACTUAL_FTE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            staffing_category_filter=staffing_category_filter,
            manager_filter=actual_fte_manager_filter
        )

        # Format queries
        staff_util_query = STAFF_UTILIZATION_PCT_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            manager_filter=manager_filter
        )
        #print(staff_util_query)
        cycle_time_query = CYCLE_TIME_PER_FTE_QUERY.format(
            date_filter=date_filter,
            lob_filter=lob_filter,
            intake_source_filter=intake_source_filter,
            market_filter=market_filter,
            funding_model_filter=funding_model_filter,
            manager_filter=manager_filter
        )

        capacity_query = CAPACITY_PER_FTE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            manager_filter=manager_filter
        )
        #print(capacity_query)
        backlog_query = BACKLOG_VOLUME_QUERY.format(
            end_date=request.end_date,
            lob_filter=lob_filter,
            intake_source_filter=backlog_intake_source_filter,
            market_filter=market_filter,
            funding_model_filter=funding_model_filter
        )
        #print(backlog_query)
        avg_resolved_query = AVG_RESOLVED_PER_DAY_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            date_filter=date_filter,
            lob_filter=lob_filter,
            intake_source_filter=intake_source_filter,
            manager_filter=manager_filter
        )

        dwoh_query = DAYS_WORK_ON_HAND_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            intake_source_filter=intake_source_filter,
            backlog_intake_source_filter=backlog_intake_source_filter,
            market_filter=market_filter,
            funding_model_filter=funding_model_filter
        )
        
        net_inventory_query = NET_INVENTORY_CHANGE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            market_filter=market_filter,
            intake_source_filter=intake_source_filter,
            backlog_intake_source_filter=backlog_intake_source_filter
        )
        
        sla_risk_query = SLA_RISK_PCT_QUERY.format(
            end_date=request.end_date,
            lob_filter=lob_filter,
            backlog_intake_source_filter=backlog_intake_source_filter,
            market_filter=market_filter
        )
        
        # Define async fetch functions for each metric
        async def fetch_req_fte():
            return await engine.execute_query_async(req_fte_query, limit=1)

        async def fetch_actual_fte():
            return await engine.execute_query_async(actual_fte_query, limit=1)

        async def fetch_staff_utilization():
            return await engine.execute_query_async(staff_util_query, limit=1)
        
        async def fetch_backlog_volume():
            return await engine.execute_query_async(backlog_query, limit=1)
        
        async def fetch_cycle_time():
            return await engine.execute_query_async(cycle_time_query, limit=1)
        
        async def fetch_capacity():
            return await engine.execute_query_async(capacity_query, limit=1)
        
        async def fetch_avg_resolved():
            return await engine.execute_query_async(avg_resolved_query, limit=1)
        
        async def fetch_dwoh():
            return await engine.execute_query_async(dwoh_query, limit=1)
        
        async def fetch_net_inventory():
            return await engine.execute_query_async(net_inventory_query, limit=1)
        
        async def fetch_sla_risk():
            return await engine.execute_query_async(sla_risk_query, limit=1)
        
        # Execute all queries in parallel
        logger.info("Executing Workforce IQ header KPI queries in parallel")
        (
            req_fte_records,
            actual_fte_records,
            staff_util_records,
            backlog_records,
            cycle_time_records,
            capacity_records,
            avg_resolved_records,
            dwoh_records,
            net_inventory_records,
            sla_risk_records
        ) = await asyncio.gather(
            fetch_req_fte(),
            fetch_actual_fte(),
            fetch_staff_utilization(),
            fetch_backlog_volume(),
            fetch_cycle_time(),
            fetch_capacity(),
            fetch_avg_resolved(),
            fetch_dwoh(),
            fetch_net_inventory(),
            fetch_sla_risk(),
            return_exceptions=False
        )
        logger.info("Parallel query execution completed")
        
        # Check if date range is in the future
        from datetime import datetime
        current_date = datetime.now().date()
        start_date_obj = datetime.strptime(request.start_date, "%Y-%m-%d").date()
        is_future_date_range = start_date_obj > current_date
        
        # Extract values
        required_fte = "-"
        if req_fte_records and req_fte_records[0].get("REQUIRED_FTE") is not None:
            required_fte = str(round(float(req_fte_records[0]["REQUIRED_FTE"]), 2))

        actual_fte = "-"
        if actual_fte_records and actual_fte_records[0].get("ACTUAL_FTE") is not None:
            actual_fte = str(round(float(actual_fte_records[0]["ACTUAL_FTE"]), 2))

        staff_utilization_pct = "-"
        if staff_util_records and staff_util_records[0].get("STAFF_UTILIZATION_PCT") is not None:
            staff_utilization_pct = f"{round(float(staff_util_records[0]['STAFF_UTILIZATION_PCT']), 2)}%"
        
        # Backlog metrics: Return 0 if date range is in the future
        backlog_volume = "-"
        if is_future_date_range:
            backlog_volume = "-"
        elif backlog_records and backlog_records[0].get("TOTAL_BACKLOG_VOLUME") is not None:
            backlog_volume = str(int(backlog_records[0]["TOTAL_BACKLOG_VOLUME"]))
        
        cycle_time_per_fte = "-"
        if cycle_time_records and cycle_time_records[0].get("AVG_CYCLE_TIME_PER_FTE_MINUTES") is not None:
            cycle_time_per_fte = f"{round(float(cycle_time_records[0]['AVG_CYCLE_TIME_PER_FTE_MINUTES']), 2)} mins."
        
        capacity_per_fte = "-"
        if capacity_records and capacity_records[0].get("CAPACITY_PER_FTE") is not None:
            capacity_per_fte = f"{round(float(capacity_records[0]['CAPACITY_PER_FTE']), 2)} cases"
        
        avg_resolved_per_day = "-"
        if avg_resolved_records and avg_resolved_records[0].get("AVG_RESOLVED_PER_DAY") is not None:
            avg_resolved_per_day = f"{round(float(avg_resolved_records[0]['AVG_RESOLVED_PER_DAY']), 2)} cases"
        
        days_work_on_hand = "-"
        if dwoh_records and dwoh_records[0].get("DAYS_WORK_ON_HAND") is not None:
            days_work_on_hand = str(round(float(dwoh_records[0]["DAYS_WORK_ON_HAND"]), 2))
        
        net_inventory_change = "-"
        if net_inventory_records and net_inventory_records[0].get("NET_INVENTORY_CHANGE") is not None:
            value = int(net_inventory_records[0]["NET_INVENTORY_CHANGE"])
            sign = "+" if value > 0 else ""
            net_inventory_change = f"{sign}{value} cases"
        
        sla_risk_pct = "-"
        if is_future_date_range:
            sla_risk_pct = "-"
        elif sla_risk_records and sla_risk_records[0].get("SLA_RISK_PCT") is not None:
            sla_risk_pct = f"{round(float(sla_risk_records[0]['SLA_RISK_PCT']), 2)}%"

        return WorkforceIQHeaderKPIsResponse(
            status="success",
            required_fte=required_fte,
            actual_fte=actual_fte,
            staff_utilization_pct=staff_utilization_pct,
            cycle_time_per_fte=cycle_time_per_fte,
            capacity_per_fte=capacity_per_fte,
            backlog_volume=backlog_volume,
            days_work_on_hand=days_work_on_hand,
            avg_resolved_per_day=avg_resolved_per_day,
            net_inventory_change=net_inventory_change,
            sla_risk_pct=sla_risk_pct,
            message="Workforce IQ Header KPIs retrieved successfully"
        )

    except Exception as e:
        logger.error(f"Workforce IQ Header KPIs error: {type(e).__name__}: {str(e)}")

        return WorkforceIQHeaderKPIsResponse(
            status="error",
            required_fte="-",
            actual_fte="-",
            staff_utilization_pct="-",
            cycle_time_per_fte="-",
            capacity_per_fte="-",
            backlog_volume="-",
            days_work_on_hand="-",
            avg_resolved_per_day="-",
            net_inventory_change="-",
            sla_risk_pct="-",
            message=f"Failed to retrieve Workforce IQ Header KPIs: {str(e)}"
        )
