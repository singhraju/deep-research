import logging
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Union
from datetime import datetime, date, timedelta
from schema.workforce_iq_models import IRPProjectionDataPoint, IRPProjectionResponse, IRPProjectionRequest
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, MEMBERSHIP_LOB_MAP

# PROJECTED_RECEIPTS query grouped by LOB and work_type
PROJECTED_RECEIPTS_QUERY_DAILY = """
WITH date_range_calc AS (
    SELECT
        '{start_date}'::DATE AS start_date,
        '{end_date}'::DATE AS end_date,
        DATEADD(YEAR, -1, '{start_date}'::DATE) AS py_start,
        DATEADD(YEAR, -1, '{end_date}'::DATE) AS py_end,
        '{grouping_level}' AS grouping_level
),
cy_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        COALESCE(UPPER(TRIM(inv.LOB)), 'NONE') AS LOB,
        COALESCE(UPPER(TRIM(inv.INTAKESOURCESYSTEM)), 'NONE') AS WORK_TYPE,
        inv.MARKET,
        inv.FUNDINGMODEL,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        DATE_TRUNC('WEEK', inv.PXCREATEDATETIME) AS week_start,
        DATE_TRUNC('MONTH', inv.PXCREATEDATETIME) AS month_start,
        DATE_TRUNC('QUARTER', inv.PXCREATEDATETIME) AS quarter_start,
        DATE_TRUNC('YEAR', inv.PXCREATEDATETIME) AS year_start,
        xwalk.STAFFING_CATEGORY AS derived_staffing_category,
        ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
        ON TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(inv.INTAKESOURCESYSTEM))
    WHERE inv.PXCREATEDATETIME >= (SELECT start_date FROM date_range_calc)
      AND inv.PXCREATEDATETIME < DATEADD(DAY, 1, (SELECT end_date FROM date_range_calc))
      AND DATE(inv.PXCREATEDATETIME) <= (SELECT end_date FROM date_range_calc)
),
py_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        COALESCE(UPPER(TRIM(inv.LOB)), 'NONE') AS LOB,
        COALESCE(UPPER(TRIM(inv.INTAKESOURCESYSTEM)), 'NONE') AS WORK_TYPE,
        inv.MARKET,
        inv.FUNDINGMODEL,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        DATE_TRUNC('WEEK', inv.PXCREATEDATETIME) AS week_start,
        DATE_TRUNC('MONTH', inv.PXCREATEDATETIME) AS month_start,
        DATE_TRUNC('QUARTER', inv.PXCREATEDATETIME) AS quarter_start,
        DATE_TRUNC('YEAR', inv.PXCREATEDATETIME) AS year_start,
        xwalk.STAFFING_CATEGORY AS derived_staffing_category,
        ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
        ON TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(inv.INTAKESOURCESYSTEM))
    WHERE inv.PXCREATEDATETIME >= DATEADD(DAY, 1, (SELECT py_start FROM date_range_calc))
      AND inv.PXCREATEDATETIME < DATEADD(DAY, 2, (SELECT py_end FROM date_range_calc))
),
date_spine AS (
    SELECT
        drc.grouping_level,
        CASE
            WHEN drc.grouping_level = 'daily' THEN DATEADD(DAY, seq.seq, drc.start_date)
            WHEN drc.grouping_level = 'weekly' THEN DATEADD(WEEK, seq.seq, DATE_TRUNC('WEEK', drc.start_date))
            WHEN drc.grouping_level = 'monthly' THEN DATEADD(MONTH, seq.seq, DATE_TRUNC('MONTH', drc.start_date))
            WHEN drc.grouping_level = 'quarterly' THEN DATEADD(QUARTER, seq.seq, DATE_TRUNC('QUARTER', drc.start_date))
            WHEN drc.grouping_level = 'yearly' THEN DATEADD(YEAR, seq.seq, DATE_TRUNC('YEAR', drc.start_date))
        END AS period_date
    FROM date_range_calc drc
    CROSS JOIN (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq FROM TABLE(GENERATOR(ROWCOUNT => 3660))) seq
    WHERE CASE
            WHEN drc.grouping_level = 'daily' THEN DATEADD(DAY, seq.seq, drc.start_date)
            WHEN drc.grouping_level = 'weekly' THEN DATEADD(WEEK, seq.seq, DATE_TRUNC('WEEK', drc.start_date))
            WHEN drc.grouping_level = 'monthly' THEN DATEADD(MONTH, seq.seq, DATE_TRUNC('MONTH', drc.start_date))
            WHEN drc.grouping_level = 'quarterly' THEN DATEADD(QUARTER, seq.seq, DATE_TRUNC('QUARTER', drc.start_date))
            WHEN drc.grouping_level = 'yearly' THEN DATEADD(YEAR, seq.seq, DATE_TRUNC('YEAR', drc.start_date))
        END <= drc.end_date
),
all_periods AS (
    SELECT
        ds.grouping_level,
        ds.period_date,
        CASE
            WHEN ds.grouping_level = 'daily' THEN TO_CHAR(ds.period_date, 'YYYY-MM-DD')
            WHEN ds.grouping_level = 'weekly' THEN TO_CHAR(ds.period_date, 'YYYY-MM-DD')
            WHEN ds.grouping_level = 'monthly' THEN LTRIM(TO_CHAR(ds.period_date, 'MM/YYYY'), '0')
            WHEN ds.grouping_level = 'quarterly' THEN CONCAT(TO_CHAR(ds.period_date, 'YYYY'), '-Q', QUARTER(ds.period_date))
            WHEN ds.grouping_level = 'yearly' THEN TO_CHAR(ds.period_date, 'YYYY')
        END AS period_label
    FROM date_spine ds
),
cy_aggregated AS (
    SELECT
        drc.grouping_level,
        cy.LOB,
        cy.WORK_TYPE,
        CASE
            WHEN drc.grouping_level = 'daily' THEN cy.create_date
            WHEN drc.grouping_level = 'weekly' THEN cy.week_start
            WHEN drc.grouping_level = 'monthly' THEN cy.month_start
            WHEN drc.grouping_level = 'quarterly' THEN cy.quarter_start
            WHEN drc.grouping_level = 'yearly' THEN cy.year_start
        END AS period_date,
        COUNT(cy.PYID) AS current_year_actual_receipts
    FROM cy_deduped cy
    CROSS JOIN date_range_calc drc
    WHERE cy.rn = 1
      AND (cy.PYSTATUSWORK IN ('Resolved-Completed','Resolved-DupClose','Resolved-BulkAutoClose','New','Pend-Decision','Resolved-AutoCloseLink','Open-ReviewIntake','Pend','Open-AuditReview','Open-CAQHPortal') OR cy.PYSTATUSWORK IS NULL)
      {lob_filter_cy}
      {work_type_filter_cy}
      {market_filter_cy}
      {funding_model_filter_cy}
      {staffing_filter_cy}
    GROUP BY 1, 2, 3, 4
),
py_aggregated AS (
    SELECT
        drc.grouping_level,
        py.LOB,
        py.WORK_TYPE,
        CASE
            WHEN drc.grouping_level = 'daily' THEN 
                DATEADD(DAY, -1, DATEADD(YEAR, 1, py.create_date))
            WHEN drc.grouping_level = 'weekly' THEN DATE_TRUNC('WEEK', DATEADD(YEAR, 1, py.create_date))
            WHEN drc.grouping_level = 'monthly' THEN DATEADD(YEAR, 1, py.month_start)
            WHEN drc.grouping_level = 'quarterly' THEN DATEADD(YEAR, 1, py.quarter_start)
            WHEN drc.grouping_level = 'yearly' THEN DATEADD(YEAR, 1, py.year_start)
        END AS period_date,
        COUNT(py.PYID) AS prior_year_actual_receipts
    FROM py_deduped py
    CROSS JOIN date_range_calc drc
    WHERE py.rn = 1
      AND (py.PYSTATUSWORK IN ('Resolved-Completed','Resolved-DupClose','Resolved-BulkAutoClose','New','Pend-Decision','Resolved-AutoCloseLink','Open-ReviewIntake','Pend','Open-AuditReview','Open-CAQHPortal') OR py.PYSTATUSWORK IS NULL)
      {lob_filter_py}
      {work_type_filter_py}
      {market_filter_py}
      {funding_model_filter_py}
      {staffing_filter_py}
    GROUP BY 1, 2, 3, 4
),
prior_year_membership AS (
    SELECT
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        DATE_FROM_PARTS(m.YEAR, 
            CASE m.MONTH
                WHEN 'January' THEN 1 WHEN 'February' THEN 2 WHEN 'March' THEN 3
                WHEN 'April' THEN 4 WHEN 'May' THEN 5 WHEN 'June' THEN 6
                WHEN 'July' THEN 7 WHEN 'August' THEN 8 WHEN 'September' THEN 9
                WHEN 'October' THEN 10 WHEN 'November' THEN 11 WHEN 'December' THEN 12
            END, 1) AS month_start_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    WHERE m.YEAR BETWEEN YEAR((SELECT py_start FROM date_range_calc)) AND YEAR((SELECT py_end FROM date_range_calc))
        {lob_filter_membership}
),
py_membership_agg AS (
    SELECT
        pm.month_start_date,
        SUM(pm.ACTUAL_MEMBERSHIP) AS prior_year_actual_membership
    FROM prior_year_membership pm
    GROUP BY pm.month_start_date
),
current_year_membership AS (
    SELECT
        m.LOB,
        m.PROJECTED_MEMBERSHIP,
        DATE_FROM_PARTS(m.YEAR, 
            CASE m.MONTH
                WHEN 'January' THEN 1 WHEN 'February' THEN 2 WHEN 'March' THEN 3
                WHEN 'April' THEN 4 WHEN 'May' THEN 5 WHEN 'June' THEN 6
                WHEN 'July' THEN 7 WHEN 'August' THEN 8 WHEN 'September' THEN 9
                WHEN 'October' THEN 10 WHEN 'November' THEN 11 WHEN 'December' THEN 12
            END, 1) AS month_start_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    WHERE m.YEAR BETWEEN YEAR((SELECT start_date FROM date_range_calc)) AND YEAR((SELECT end_date FROM date_range_calc))
        {lob_filter_membership}
),
cy_membership_agg AS (
    SELECT
        cm.month_start_date,
        SUM(cm.PROJECTED_MEMBERSHIP) AS current_year_projected_membership
    FROM current_year_membership cm
    GROUP BY cm.month_start_date
),
lob_work_type_combinations AS (
    SELECT DISTINCT LOB, WORK_TYPE FROM cy_deduped
    UNION
    SELECT DISTINCT LOB, WORK_TYPE FROM py_deduped
)
SELECT
    ap.grouping_level AS GROUPING_LEVEL,
    ap.period_date,
    ap.period_label,
    lwt.LOB,
    lwt.WORK_TYPE,
    COALESCE(cy.current_year_actual_receipts, 0) AS ACTUAL_RECEIPTS,
    COALESCE(py.prior_year_actual_receipts, 0) AS prior_year_actual_receipts,
    CASE
        WHEN COALESCE(py.prior_year_actual_receipts, 0) = 0 THEN NULL
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 3
            FROM py_membership_agg pma
            WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
              AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 12
            FROM py_membership_agg pma
            WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
        )
    END AS prior_year_actual_membership,
    CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN cm_monthly.current_year_projected_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 3
            FROM cy_membership_agg cma
            WHERE cma.month_start_date >= DATE_TRUNC('QUARTER', ap.period_date)
              AND cma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', ap.period_date))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 12
            FROM cy_membership_agg cma
            WHERE YEAR(cma.month_start_date) = YEAR(ap.period_date)
        )
    END AS current_year_projected_membership,
    COALESCE(py.prior_year_actual_receipts, 0) / 
    NULLIF(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 3
            FROM py_membership_agg pma
            WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
              AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 12
            FROM py_membership_agg pma
            WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
        )
    END, 0) AS utilization_rate,
    ROUND(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN cm_monthly.current_year_projected_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 3
            FROM cy_membership_agg cma
            WHERE cma.month_start_date >= DATE_TRUNC('QUARTER', ap.period_date)
              AND cma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', ap.period_date))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(cma.current_year_projected_membership) / 12
            FROM cy_membership_agg cma
            WHERE YEAR(cma.month_start_date) = YEAR(ap.period_date)
        )
    END *
    (COALESCE(py.prior_year_actual_receipts, 0) / 
    NULLIF(CASE
        WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
        WHEN ap.grouping_level = 'quarterly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 3
            FROM py_membership_agg pma
            WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
              AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
        )
        WHEN ap.grouping_level = 'yearly' THEN (
            SELECT SUM(pma.prior_year_actual_membership) / 12
            FROM py_membership_agg pma
            WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
        )
    END, 0)), 0) AS PROJECTED_RECEIPTS,
    CASE
        WHEN ap.period_date < CURRENT_DATE() THEN 'PAST'
        WHEN ap.period_date = CURRENT_DATE() THEN 'CURRENT'
        ELSE 'FUTURE'
    END AS date_category
FROM all_periods ap
CROSS JOIN lob_work_type_combinations lwt
LEFT JOIN cy_aggregated cy ON ap.period_date = cy.period_date AND ap.grouping_level = cy.grouping_level AND lwt.LOB = cy.LOB AND lwt.WORK_TYPE = cy.WORK_TYPE
LEFT JOIN py_aggregated py ON ap.period_date = py.period_date AND ap.grouping_level = py.grouping_level AND lwt.LOB = py.LOB AND lwt.WORK_TYPE = py.WORK_TYPE
LEFT JOIN py_membership_agg pm_monthly ON DATE_TRUNC('MONTH', DATEADD(YEAR, -1, ap.period_date)) = pm_monthly.month_start_date
    AND ap.grouping_level IN ('daily', 'weekly', 'monthly')
LEFT JOIN cy_membership_agg cm_monthly ON DATE_TRUNC('MONTH', ap.period_date) = cm_monthly.month_start_date
    AND ap.grouping_level IN ('daily', 'weekly', 'monthly')
ORDER BY ap.period_date, lwt.LOB, lwt.WORK_TYPE
"""

# Custom PROJECTED_RESOLVED query grouped by LOB and work_type
PROJECTED_RESOLVED_QUERY_DAILY = """
-- Projected Resolved = Working Days x (Productive mins/day x Projected FTE) / Avg Cycle Time mins
-- Modified to calculate per LOB and INTAKESOURCESYSTEM with their specific cycle times

WITH config AS (
    SELECT
        '{start_date}'::DATE AS start_date,
        '{end_date}'::DATE AS end_date,
        '{grouping_level}' AS grouping_level,
        NULL AS filter_market
),

date_spine AS (
    SELECT DATEADD(DAY, seq.seq, dr.start_date) AS period_date
    FROM config dr
    CROSS JOIN (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq FROM TABLE(GENERATOR(ROWCOUNT => 100000))) seq
    WHERE DATEADD(DAY, seq.seq, dr.start_date) <= dr.end_date
        AND ((SELECT grouping_level FROM config) != 'daily' OR DAYOFWEEK(DATEADD(DAY, seq.seq, dr.start_date)) NOT IN (0, 6))
),

working_days_lookup AS (
    SELECT 1 AS month_num, 21 AS working_days UNION ALL
    SELECT 2, 20 UNION ALL
    SELECT 3, 21 UNION ALL
    SELECT 4, 22 UNION ALL
    SELECT 5, 20 UNION ALL
    SELECT 6, 20 UNION ALL
    SELECT 7, 22 UNION ALL
    SELECT 8, 21 UNION ALL
    SELECT 9, 21 UNION ALL
    SELECT 10, 23 UNION ALL
    SELECT 11, 19 UNION ALL
    SELECT 12, 22
),

holidays AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),

working_days_per_period AS (
    SELECT DISTINCT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ds.period_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', ds.period_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', ds.period_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', ds.period_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', ds.period_date)
        END AS period_date,
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN 1
            WHEN 'weekly' THEN (
                5 - COALESCE((
                    SELECT COUNT(*) FROM holidays h
                    WHERE h.holiday_date >= DATE_TRUNC('WEEK', ds.period_date)
                      AND h.holiday_date < DATEADD(DAY, 7, DATE_TRUNC('WEEK', ds.period_date))
                      AND DAYOFWEEK(h.holiday_date) NOT IN (0, 6)
                ), 0)
            )
            WHEN 'monthly' THEN wl.working_days
            WHEN 'quarterly' THEN (
                SELECT SUM(w2.working_days) FROM working_days_lookup w2
                WHERE w2.month_num BETWEEN EXTRACT(MONTH FROM DATE_TRUNC('QUARTER', ds.period_date))
                    AND EXTRACT(MONTH FROM DATE_TRUNC('QUARTER', ds.period_date)) + 2
            )
            WHEN 'yearly' THEN (SELECT SUM(w2.working_days) FROM working_days_lookup w2)
        END AS working_days
    FROM date_spine ds
    LEFT JOIN working_days_lookup wl ON wl.month_num = EXTRACT(MONTH FROM ds.period_date)
),

productive_time AS (
    SELECT
        ROUND(AVG(
            SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT * 60.0 +
            SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT +
            SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 60.0
        ), 2) AS avg_productive_mins_per_day
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE u
    WHERE UPPER(u.PYACCESSGROUP) LIKE '%FRONTLINE%'
        AND u.PRODUCTIVETIME IS NOT NULL
        AND u.LOGINDATE BETWEEN DATEADD(DAY, -90, CURRENT_DATE()) AND CURRENT_DATE()
),

historical_avail AS (
    SELECT DISTINCT
        w.EMPLOYEE_DOMAIN_ID AS userid,
        w.MANAGER_DOMAIN_ID AS manager_id,
        TRY_CAST(w.ASOFTODAY AS DATE) AS snapshot_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
        AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
        AND TRY_CAST(w.ASOFTODAY AS DATE) <= CURRENT_DATE()
        AND DAYOFWEEK(TRY_CAST(w.ASOFTODAY AS DATE)) NOT IN (0, 6)
        {manager_filter}
),

historical_avg AS (
    SELECT (
        SELECT avail_count FROM (
            SELECT snapshot_date, COUNT(DISTINCT userid) AS avail_count
            FROM historical_avail
            WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
            GROUP BY snapshot_date
            ORDER BY snapshot_date DESC 
            LIMIT 1  -- Most recent business day (matching staffing_core.py logic)
        )
    ) AS avg_historical_fte
),

onboard_data AS (
    SELECT
        TRY_CAST(op.FUTURE_START_DATE AS DATE) AS start_date,
        op.ONBOARDING_COUNT
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_OPEN_POSITIONS op
    WHERE TRY_CAST(op.FUTURE_START_DATE AS DATE) IS NOT NULL
),

onboard_by_period AS (
    SELECT
        start_date AS onboard_complete_date,
        SUM(ONBOARDING_COUNT) AS onboard_fte
    FROM onboard_data
    WHERE start_date >= DATEADD(DAY, -15, (SELECT MAX(snapshot_date) FROM historical_avail WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)))
    GROUP BY start_date
),

historical_grouped_base AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN snapshot_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', snapshot_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', snapshot_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', snapshot_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', snapshot_date)
        END AS period_date,
        COUNT(DISTINCT userid) AS base_fte_count
    FROM historical_avail
    WHERE snapshot_date BETWEEN (SELECT start_date FROM config) AND LEAST((SELECT end_date FROM config), CURRENT_DATE())
        AND CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN snapshot_date < CURRENT_DATE()
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', snapshot_date) < DATE_TRUNC('WEEK', CURRENT_DATE())
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', snapshot_date) < DATE_TRUNC('MONTH', CURRENT_DATE())
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', snapshot_date) < DATE_TRUNC('QUARTER', CURRENT_DATE())
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', snapshot_date) < DATE_TRUNC('YEAR', CURRENT_DATE())
        END
    GROUP BY period_date
),

historical_grouped AS (
    SELECT
        hgb.period_date,
        hgb.base_fte_count + COALESCE((SELECT SUM(onboard_fte) FROM onboard_by_period WHERE onboard_complete_date <= hgb.period_date), 0) AS avail_fte_count
    FROM historical_grouped_base hgb
),

future_grouped_avail AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ds.period_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', ds.period_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', ds.period_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', ds.period_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', ds.period_date)
        END AS period_date,
        CASE
            -- Set NULL for weekends in daily grouping
            WHEN (SELECT grouping_level FROM config) = 'daily' AND DAYOFWEEK(ds.period_date) IN (0, 6) THEN NULL
            -- Fallback: Use historical average + cumulative onboarding
            -- Note: Actual future FTE now comes from separate FUTURE_AVAIL_FTE_QUERY
            ELSE COALESCE((SELECT avg_historical_fte FROM historical_avg), 0)
                + COALESCE((SELECT SUM(onboard_fte) FROM onboard_by_period WHERE onboard_complete_date <= ds.period_date), 0)
        END AS avail_fte_count
    FROM date_spine ds
    WHERE ds.period_date >= CURRENT_DATE()
    GROUP BY period_date
),

available_fte AS (
    SELECT period_date, avail_fte_count FROM historical_grouped
    UNION ALL
    SELECT period_date, avail_fte_count FROM future_grouped_avail
),

time_off_raw AS (
    SELECT
        w.EMPLOYEE_DOMAIN_ID AS userid,
        w.MANAGER_DOMAIN_ID AS manager_id,
        TRY_CAST(w.TIME_OFF_DATE AS DATE) AS time_off_date,
        TRY_CAST(w.HOURS AS FLOAT) AS hours_off,
        ROW_NUMBER() OVER (
            PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.TIME_OFF_DATE AS DATE), w.TIME_OFF_TYPE, w.HOURS
            ORDER BY w.EMPLOYEE_DOMAIN_ID
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
        AND w.STATUS IN ('Approved', 'Submitted')
        AND w.TIME_OFF_TYPE IN (
            'Paid Time Off - Approved/Scheduled', 'Paid Time Off', 'Paid Time Off - Supplemental',
            'Paid Time Off - Unapproved/Unscheduled', 'Sick Time', 'Sick Time - Approved',
            'Sick Time - Unapproved', 'Sick Time - Supplemental', 'Sick Time - Intermittent LOA',
            'Wellness Days Off', 'Paid Time Off - Kin Care/CA Sick', 'Critical Care Leave',
            'Paid Parental Leave', 'Other Paid Time - New Parent Transition',
            'Other Paid Time - Bereavement', 'Other Paid Time - Jury Duty', 'Other Paid Time - Voting',
            'Other Paid Time - Voluntary Time Off/Community Service',
            'Other Paid Time - Business Disruption/Sent Home/Lack of Work',
            'Paid Time Off - Intermittent LOA', 'Other Paid Time - Intermittent LOA',
            'Non Paid Time - Intermittent LOA', 'Non Paid Time - Approved/Voluntary',
            'Non Paid Time - Worker''s Compensation',
            'Non Paid Time - Victims of Domestic Violence & Crimes', 'Non Paid Time - Unapproved'
        )
        AND TRY_CAST(w.TIME_OFF_DATE AS DATE) IS NOT NULL
        AND TRY_CAST(w.TIME_OFF_DATE AS DATE) BETWEEN (SELECT start_date FROM config) AND (SELECT end_date FROM config)
        {manager_filter}
),

time_off AS (
    SELECT userid, manager_id, time_off_date, hours_off
    FROM time_off_raw
    WHERE rn = 1
),

holidays_resolved AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),

holiday_count_per_period_resolved AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN h.holiday_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', h.holiday_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', h.holiday_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', h.holiday_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', h.holiday_date)
        END AS period_date,
        COUNT(*) AS holiday_count
    FROM holidays_resolved h
    WHERE DAYOFWEEK(h.holiday_date) NOT IN (0, 6)
    GROUP BY 1
),

time_off_with_periods_resolved AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN time_off_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', time_off_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', time_off_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', time_off_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', time_off_date)
        END AS period_date,
        hours_off
    FROM time_off
),

actual_pto AS (
    SELECT
        t.period_date,
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ROUND(SUM(t.hours_off) / 8.0, 2)
            WHEN 'weekly' THEN 
                CASE WHEN (5 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (5 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'monthly' THEN 
                CASE WHEN (22 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (22 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'quarterly' THEN 
                CASE WHEN (65 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (65 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'yearly' THEN 
                CASE WHEN (260 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (260 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
        END AS pto_headcount
    FROM time_off_with_periods_resolved t
    LEFT JOIN holiday_count_per_period_resolved hc ON t.period_date = hc.period_date
    GROUP BY t.period_date, hc.holiday_count
),

static_pto AS (
    SELECT
        MONTH,
        REPLACE(CB_PTO_PERCENT, '%', '')::FLOAT / 100 AS cb_pto_pct,
        REPLACE(GB_PTO_PERCENT, '%', '')::FLOAT / 100 AS gb_pto_pct
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_PROJECTED_STATIC_PTO
),

projected_fte_calc AS (
    SELECT
        af.period_date,
        af.avail_fte_count AS available_fte,
        CASE
            WHEN af.period_date <= DATEADD(DAY, 14, CURRENT_DATE())
            THEN COALESCE(ap.pto_headcount, 0)
            ELSE ROUND(af.avail_fte_count * COALESCE((sp.cb_pto_pct + sp.gb_pto_pct) / 2, 0), 1)
        END AS uto_pto_count,
        CEIL(af.avail_fte_count -
            CASE
                WHEN af.period_date <= DATEADD(DAY, 14, CURRENT_DATE())
                THEN COALESCE(ap.pto_headcount, 0)
                ELSE ROUND(af.avail_fte_count * COALESCE((sp.cb_pto_pct + sp.gb_pto_pct) / 2, 0), 1)
            END
        ) AS projected_fte
    FROM available_fte af
    LEFT JOIN actual_pto ap ON af.period_date = ap.period_date
    LEFT JOIN static_pto sp ON UPPER(LEFT(TO_CHAR(af.period_date, 'MON'), 3)) = UPPER(LEFT(sp.MONTH, 3))
),

-- Modified: Calculate avg_cycle_time grouped by LOB and INTAKESOURCESYSTEM
avg_cycle_time_by_lob_work_type AS (
    SELECT
        COALESCE(UPPER(TRIM(inv.LOB)), 'NONE') AS LOB,
        COALESCE(UPPER(TRIM(inv.INTAKESOURCESYSTEM)), 'NONE') AS WORK_TYPE,
        ROUND(AVG(inv.CYCLE_TIME) / 60.0, 2) AS avg_cycle_time_min
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.CYCLE_TIME IS NOT NULL
        AND inv.PYRESOLVEDTIMESTAMP >= DATEADD(DAY, -90, CURRENT_DATE())
        AND inv.PYRESOLVEDTIMESTAMP < DATEADD(DAY, 1, CURRENT_DATE())
        AND inv.PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND inv.PYRESOLVEDTIMESTAMP IS NOT NULL
        {lob_filter_cycle}
        {work_type_filter}
        {market_filter}
    GROUP BY inv.LOB, inv.INTAKESOURCESYSTEM
),

-- Modified: Calculate projected_resolved per LOB and work_type
projected_resolved AS (
    SELECT
        pf.period_date,
        act.LOB,
        act.WORK_TYPE,
        pf.projected_fte,
        wd.working_days,
        (SELECT avg_productive_mins_per_day FROM productive_time) AS productive_mins_per_day,
        act.avg_cycle_time_min,
        CASE
            WHEN act.avg_cycle_time_min IS NULL OR act.avg_cycle_time_min = 0 THEN 0
            ELSE ROUND(
                wd.working_days * ((SELECT avg_productive_mins_per_day FROM productive_time) * pf.projected_fte) / act.avg_cycle_time_min,
                0
            )
        END AS projected_resolved_count
    FROM projected_fte_calc pf
    INNER JOIN working_days_per_period wd ON pf.period_date = wd.period_date
    CROSS JOIN avg_cycle_time_by_lob_work_type act
    WHERE pf.projected_fte IS NOT NULL
)
SELECT
    (SELECT grouping_level FROM config) AS GROUPING_LEVEL,
    pr.period_date AS PERIOD_DATE,
    pr.LOB,
    pr.WORK_TYPE,
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN TO_CHAR(pr.period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_CHAR(pr.period_date, 'YYYY-MM-DD')
        WHEN 'monthly' THEN TO_CHAR(pr.period_date, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_CHAR(pr.period_date, 'YYYY') || '-Q' || QUARTER(pr.period_date)
        WHEN 'yearly' THEN TO_CHAR(pr.period_date, 'YYYY')
    END AS PERIOD_LABEL,
    CASE 
        WHEN (SELECT grouping_level FROM config) = 'daily' AND EXISTS (SELECT 1 FROM holidays h WHERE h.holiday_date = pr.period_date) THEN NULL
        ELSE pr.projected_fte
    END AS PROJECTED_FTE,
    pr.working_days AS WORKING_DAYS,
    pr.productive_mins_per_day AS PRODUCTIVE_MINS_PER_DAY,
    pr.avg_cycle_time_min AS AVG_CYCLE_TIME_MIN,
    CASE 
        WHEN (SELECT grouping_level FROM config) = 'daily' AND EXISTS (SELECT 1 FROM holidays h WHERE h.holiday_date = pr.period_date) THEN NULL
        ELSE pr.projected_resolved_count
    END AS PROJECTED_RESOLVED
FROM projected_resolved pr
ORDER BY pr.period_date, pr.LOB, pr.WORK_TYPE
"""

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()


# =============================================================================
# Filter Builder Functions
# =============================================================================

def build_lob_filter(lob: Optional[List[str]]) -> str:
    """Build LOB filter for SQL query."""
    if not lob:
        return ""
    lob_list = "', '".join(lob)
    return f"AND lob IN ('{lob_list}')"


def build_work_type_filter(work_type: Optional[List[str]]) -> str:
    """Build work type filter for SQL query."""
    if not work_type:
        return ""
    work_type_list = "', '".join(work_type)
    return f"AND work_type IN ('{work_type_list}')"


# =============================================================================
# Projection Queries and Helper Functions
# =============================================================================

# SLA Due Forecasting Query - Weighted 50-50 approach (50% last week + 50% last month)
PROJECTED_SLA_DUE_QUERY = """
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.EXTERNALDUEDATE,
        COALESCE(UPPER(TRIM(inv.LOB)), 'NONE') AS LOB,
        COALESCE(UPPER(TRIM(inv.INTAKESOURCESYSTEM)), 'NONE') AS WORK_TYPE,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.PXUPDATEDATETIME < DATEADD(day, 1, CURRENT_DATE())
),
-- Historical daily counts for last 30 days
daily_counts AS (
    SELECT
        CAST(inv.EXTERNALDUEDATE AS DATE) AS due_date,
        DAYOFWEEK(inv.EXTERNALDUEDATE) AS day_of_week,
        inv.LOB,
        inv.WORK_TYPE,
        COUNT(DISTINCT inv.PYID) AS sla_due_count
    FROM invntry_deduped inv
    WHERE inv.rn = 1 
        AND inv.EXTERNALDUEDATE IS NOT NULL
        AND inv.EXTERNALDUEDATE >= DATEADD(day, -30, CURRENT_DATE())
        AND inv.EXTERNALDUEDATE < CURRENT_DATE()
        {lob_filter}
        {work_type_filter}
    GROUP BY 
        CAST(inv.EXTERNALDUEDATE AS DATE),
        DAYOFWEEK(inv.EXTERNALDUEDATE),
        inv.LOB,
        inv.WORK_TYPE
),
-- Last 1 Week Average (by day of week, LOB, and work type)
last_1_week_avg AS (
    SELECT
        day_of_week,
        LOB,
        WORK_TYPE,
        AVG(sla_due_count) AS avg_1_week
    FROM daily_counts
    WHERE due_date >= DATEADD(day, -7, CURRENT_DATE())
    GROUP BY day_of_week, LOB, WORK_TYPE
),
-- Last 1 Month Average (by day of week, LOB, and work type)
last_1_month_avg AS (
    SELECT
        day_of_week,
        LOB,
        WORK_TYPE,
        AVG(sla_due_count) AS avg_1_month
    FROM daily_counts
    WHERE due_date >= DATEADD(day, -30, CURRENT_DATE())
    GROUP BY day_of_week, LOB, WORK_TYPE
),
-- Generate dates for the requested range
date_spine AS (
    SELECT 
        DATEADD(DAY, seq.seq, '{start_date}'::DATE) AS future_date,
        DAYOFWEEK(DATEADD(DAY, seq.seq, '{start_date}'::DATE)) AS day_of_week
    FROM (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq 
          FROM TABLE(GENERATOR(ROWCOUNT => 100))) seq
    WHERE DATEADD(DAY, seq.seq, '{start_date}'::DATE) <= '{end_date}'::DATE
),
-- Get all LOB and work type combinations
lob_work_type_combinations AS (
    SELECT DISTINCT LOB, WORK_TYPE 
    FROM daily_counts
)
-- Calculate forecast for future dates
SELECT
    ds.future_date AS PERIOD_DATE,
    lwt.LOB,
    lwt.WORK_TYPE,
    ROUND(COALESCE(
        (w1.avg_1_week * 0.5 + m1.avg_1_month * 0.5), 
        0
    ), 2) AS PROJECTED_SLA_DUE
FROM date_spine ds
CROSS JOIN lob_work_type_combinations lwt
LEFT JOIN last_1_week_avg w1
    ON ds.day_of_week = w1.day_of_week
    AND lwt.LOB = w1.LOB
    AND lwt.WORK_TYPE = w1.WORK_TYPE
LEFT JOIN last_1_month_avg m1
    ON ds.day_of_week = m1.day_of_week
    AND lwt.LOB = m1.LOB
    AND lwt.WORK_TYPE = m1.WORK_TYPE
ORDER BY ds.future_date, lwt.LOB, lwt.WORK_TYPE
"""

LAST_AVAILABLE_DATE_QUERY = f"""
SELECT MAX(date) AS last_date
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.irp_projection
WHERE date <= CURRENT_DATE()
"""

LAST_DAY_METRICS_QUERY = f"""
SELECT
    lob,
    work_type,
    date,
    total_work,
    total_production,
    backlog_count,
    req_fte,
    avail_fte,
    avg_daily_resolved,
    avg_cycle_time_hrs,
    avg_productive_hrs_per_day
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.irp_projection
WHERE date = :last_date
  {{lob_filter}}
  {{work_type_filter}}
"""

# Future Available FTE Query - Latest eCOB Specialist count + onboarding
FUTURE_AVAIL_FTE_QUERY = """
WITH date_spine AS (
    SELECT 
        DATEADD(DAY, seq.seq, '{start_date}'::DATE) AS period_date
    FROM (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq 
          FROM TABLE(GENERATOR(ROWCOUNT => 600))) seq
    WHERE DATEADD(DAY, seq.seq, '{start_date}'::DATE) <= '{end_date}'::DATE
        AND DAYOFWEEK(DATEADD(DAY, seq.seq, '{start_date}'::DATE)) NOT IN (0, 6)  -- Exclude weekends
),
-- Latest eCOB Specialist count from Workday using 1 day before current date
base_fte AS (
    SELECT COUNT(DISTINCT w.EMPLOYEE_DOMAIN_ID) AS base_future_fte
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    WHERE w.JOB_PROFILE_NAME LIKE '%eCOB Specialist%'
        AND TRY_CAST(w.ASOFTODAY AS DATE) = (
            SELECT MAX(TRY_CAST(ASOFTODAY AS DATE)) 
            FROM COB_AI_WORKDAY_HIST
        )        
),
-- Onboarding data
onboard_data AS (
    SELECT
        TRY_CAST(op.FUTURE_START_DATE AS DATE) AS start_date,
        op.ONBOARDING_COUNT
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_OPEN_POSITIONS op
    WHERE TRY_CAST(op.FUTURE_START_DATE AS DATE) IS NOT NULL
),
-- Calculate future FTE for each date
future_fte AS (
    SELECT
        ds.period_date,
        COALESCE((SELECT base_future_fte FROM base_fte), 0) + 
        COALESCE((SELECT SUM(onboard.ONBOARDING_COUNT) 
                  FROM onboard_data onboard 
                  WHERE onboard.start_date >= CURRENT_DATE() 
                    AND onboard.start_date <= ds.period_date), 0) AS avail_fte
    FROM date_spine ds
)
SELECT 
    period_date,
    avail_fte
FROM future_fte
ORDER BY period_date
"""


async def get_last_available_date(engine) -> Optional[date]:
    """Get the last available date from irp_projection table."""
    try:
        results = await engine.execute_query_async(LAST_AVAILABLE_DATE_QUERY, limit=1)
        if results and len(results) > 0:
            last_date = results[0].get('LAST_DATE')
            if last_date:
                if hasattr(last_date, 'date'):
                    return last_date.date()
                return last_date
        return None
    except Exception as e:
        logger.error(f"Error getting last available date: {str(e)}")
        return None


async def query_projection_data(
    engine,
    start_date: date,
    end_date: date,
    last_available_date: date,
    lob_values: Optional[List[str]] = None,
    work_type_values: Optional[List[str]] = None
) -> tuple[Dict[tuple, Dict[date, float]], Dict[tuple, Dict[date, float]], Dict[tuple, Dict[date, float]], Dict[tuple, Dict[date, float]], Dict[date, int]]:
    """
    Query projection data from projection queries.
    
    NOTE: Both PROJECTED_RECEIPTS_QUERY and PROJECTED_RESOLVED_QUERY now return per-LOB/work_type data
    with cycle times and utilization rates specific to each combination.
    
    Returns: (projected_receipts, projected_resolved, projected_fte, projected_sla_due, future_avail_fte)
    - projected_receipts: Dict[(lob, work_type), Dict[date, float]] (per LOB/work_type)
    - projected_resolved: Dict[(lob, work_type), Dict[date, float]] (per LOB/work_type)
    - projected_fte: Dict[(lob, work_type), Dict[date, float]] (per LOB/work_type)
    - projected_sla_due: Dict[(lob, work_type), Dict[date, float]] (per LOB/work_type)
    - future_avail_fte: Dict[date, int] (single value per date from eCOB Specialist role + onboarding)
    """
    try:
        # Build filters for the projection queries
        # These queries need multiple variants of filters for different CTEs
        
        # Build base LOB filter
        lob_filter = ""
        lob_filter_cy = ""
        lob_filter_py = ""
        lob_filter_membership = ""
        lob_filter_coalesce = ""
        lob_filter_onboard = ""
        lob_filter_cycle_time = ""
        
        if lob_values:
            lob_list = [l.upper() if l != "None" else "NONE" for l in lob_values]
            quoted_lobs = "', '".join(lob_list)
            
            # For inventory table (inv.)
            lob_filter = f"AND UPPER(TRIM(inv.LOB)) IN ('{quoted_lobs}')"
            # For current year CTE (cy.) - LOB is already aliased to WORK_TYPE
            lob_filter_cy = f"AND cy.LOB IN ('{quoted_lobs}')"
            # For prior year CTE (py.) - LOB is already aliased
            lob_filter_py = f"AND py.LOB IN ('{quoted_lobs}')"
            # For membership table - use MEMBERSHIP_LOB_MAP to map payload LOB values to membership table LOB values
            mapped_lobs_membership = list(set([MEMBERSHIP_LOB_MAP.get(l, l.upper() if l != "None" else "NONE") for l in lob_values]))
            quoted_lobs_membership = "', '".join(mapped_lobs_membership)
            lob_filter_membership = f"AND UPPER(TRIM(m.LOB)) IN ('{quoted_lobs_membership}')"
            # For user LOB (ul.) with COALESCE
            lob_filter_coalesce = f"AND COALESCE(ul.LOB, 'NONE') IN ('{quoted_lobs}')"
            # For onboard (op.) with COALESCE
            lob_filter_onboard = f"AND COALESCE(op.LOB, 'NONE') IN ('{quoted_lobs}')"
            # For cycle time (keeps inv. prefix)
            lob_filter_cycle_time = lob_filter
        
        # Build work type filters
        work_type_filter = ""
        work_type_filter_cy = ""
        work_type_filter_py = ""
        work_type_filter_no_prefix = ""
        
        if work_type_values:
            non_null_types = [wt.upper() for wt in work_type_values if wt and wt.upper() != "NONE"]
            if non_null_types:
                work_type_values_str = "', '".join(non_null_types)
                work_type_filter = f"AND UPPER(inv.INTAKESOURCESYSTEM) IN ('{work_type_values_str}')"
                work_type_filter_cy = f"AND cy.WORK_TYPE IN ('{work_type_values_str}')"
                work_type_filter_py = f"AND py.WORK_TYPE IN ('{work_type_values_str}')"
                work_type_filter_no_prefix = f"AND UPPER(INTAKESOURCESYSTEM) IN ('{work_type_values_str}')"
        
        # Query PROJECTED_RECEIPTS
        receipts_query = PROJECTED_RECEIPTS_QUERY_DAILY.format(
            start_date=start_date.strftime('%Y-%m-%d'),
            end_date=end_date.strftime('%Y-%m-%d'),
            grouping_level='daily',
            lob_filter=lob_filter if lob_filter else '',
            lob_filter_membership=lob_filter_membership if lob_filter_membership else '',
            lob_filter_cy=lob_filter_cy if lob_filter_cy else '',
            lob_filter_py=lob_filter_py if lob_filter_py else '',
            work_type_filter=work_type_filter if work_type_filter else '',
            work_type_filter_cy=work_type_filter_cy if work_type_filter_cy else '',
            work_type_filter_py=work_type_filter_py if work_type_filter_py else '',
            manager_filter='',  # Not filtering by manager
            market_filter='',
            market_filter_cy='',
            market_filter_py='',
            funding_model_filter='',
            funding_model_filter_cy='',
            funding_model_filter_py='',
            staffing_filter='',  # Not filtering by staffing category
            staffing_filter_cy='',
            staffing_filter_py='',
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )
        
        receipts_results = await engine.execute_query_async(receipts_query, limit=100000)
        
        # Query PROJECTED_RESOLVED and PROJECTED_FTE
        resolved_query = PROJECTED_RESOLVED_QUERY_DAILY.format(
            start_date=start_date.strftime('%Y-%m-%d'),
            end_date=end_date.strftime('%Y-%m-%d'),
            grouping_level='daily',
            lob_filter_historical=lob_filter_coalesce if lob_filter_coalesce else '',
            lob_filter_onboard=lob_filter_onboard if lob_filter_onboard else '',
            lob_filter_timeoff=lob_filter_coalesce if lob_filter_coalesce else '',
            lob_filter_cycle=lob_filter_cycle_time if lob_filter_cycle_time else '',
            staffing_filter='',  # Not filtering by staffing category
            work_type_filter=work_type_filter_no_prefix if work_type_filter_no_prefix else '',
            market_filter='',
            manager_filter='',
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )
        
        resolved_results = await engine.execute_query_async(resolved_query, limit=100000)
        
        # Query PROJECTED_SLA_DUE
        # Build filters for SLA due query - use aliased column names
        sla_lob_filter = ""
        sla_work_type_filter = ""
        if lob_values:
            lob_list = [l.upper() if l != "None" else "NONE" for l in lob_values]
            quoted_lobs = "', '".join(lob_list)
            sla_lob_filter = f"AND inv.LOB IN ('{quoted_lobs}')"
        
        if work_type_values:
            non_null_types = [wt.upper() for wt in work_type_values if wt and wt.upper() != "NONE"]
            if non_null_types:
                work_type_values_str = "', '".join(non_null_types)
                sla_work_type_filter = f"AND inv.WORK_TYPE IN ('{work_type_values_str}')"
        
        sla_due_query = PROJECTED_SLA_DUE_QUERY.format(
            start_date=start_date.strftime('%Y-%m-%d'),
            end_date=end_date.strftime('%Y-%m-%d'),
            lob_filter=sla_lob_filter if sla_lob_filter else '',
            work_type_filter=sla_work_type_filter if sla_work_type_filter else '',
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )
        
        sla_due_results = await engine.execute_query_async(sla_due_query, limit=100000)
        
        # Query FUTURE_AVAIL_FTE (separate query for future FTE based on eCOB Specialist role)
        # Note: Uses 1 day before current date for Workday data instead of last_available_date
        future_fte_query = FUTURE_AVAIL_FTE_QUERY.format(
            start_date=start_date.strftime('%Y-%m-%d'),
            end_date=end_date.strftime('%Y-%m-%d'),
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )
        logger.info(f"Executing FUTURE_AVAIL_FTE_QUERY with start_date={start_date}, end_date={end_date}")
        logger.debug(f"FUTURE_AVAIL_FTE_QUERY: {future_fte_query[:500]}...")  # Log first 500 chars
        
        future_fte_results = await engine.execute_query_async(future_fte_query, limit=100000)
        
        # Parse results into dictionaries
        # Note: All projections are now per LOB/work_type
        projected_receipts = {}  # Dict[(lob, work_type)][date] = value
        projected_resolved = {}  # Dict[(lob, work_type)][date] = value
        projected_fte = {}  # Dict[(lob, work_type)][date] = value
        projected_sla_due = {}  # Dict[(lob, work_type)][date] = value
        future_avail_fte = {}  # Dict[date] = value (not per LOB/work_type)
        
        # Parse receipts (per LOB/work_type)
        for row in receipts_results:
            period_date = row.get('PERIOD_DATE') or row.get('period_date')
            lob = row.get('LOB')
            work_type = row.get('WORK_TYPE')
            
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            elif isinstance(period_date, str):
                period_date = datetime.strptime(period_date, '%Y-%m-%d').date()
            
            # Create key for this LOB/work_type combination
            key = (lob, work_type)
            
            # Initialize dictionary for this key if needed
            if key not in projected_receipts:
                projected_receipts[key] = {}
            
            # Store per-LOB/work_type values
            projected_receipts[key][period_date] = float(row.get('PROJECTED_RECEIPTS', 0) or 0)
        
        # Parse resolved and FTE (per LOB/work_type)
        for row in resolved_results:
            period_date = row.get('PERIOD_DATE') or row.get('period_date')
            lob = row.get('LOB')
            work_type = row.get('WORK_TYPE')
            
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            elif isinstance(period_date, str):
                period_date = datetime.strptime(period_date, '%Y-%m-%d').date()
            
            # Create key for this LOB/work_type combination
            key = (lob, work_type)
            
            # Initialize dictionaries for this key if needed
            if key not in projected_resolved:
                projected_resolved[key] = {}
            if key not in projected_fte:
                projected_fte[key] = {}
            
            # Store per-LOB/work_type values
            projected_resolved[key][period_date] = float(row.get('PROJECTED_RESOLVED', 0) or 0)
            projected_fte[key][period_date] = float(row.get('PROJECTED_FTE', 0) or 0)
        
        # Parse SLA due (per LOB/work_type)
        for row in sla_due_results:
            period_date = row.get('PERIOD_DATE') or row.get('period_date')
            lob = row.get('LOB')
            work_type = row.get('WORK_TYPE')
            
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            elif isinstance(period_date, str):
                period_date = datetime.strptime(period_date, '%Y-%m-%d').date()
            
            # Create key for this LOB/work_type combination
            key = (lob, work_type)
            
            # Initialize dictionary for this key if needed
            if key not in projected_sla_due:
                projected_sla_due[key] = {}
            
            # Store per-LOB/work_type values
            projected_sla_due[key][period_date] = float(row.get('PROJECTED_SLA_DUE', 0) or 0)
        
        # Parse future avail FTE (single value per date, not per LOB/work_type)
        for row in future_fte_results:
            period_date = row.get('PERIOD_DATE') or row.get('period_date')
            
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            elif isinstance(period_date, str):
                period_date = datetime.strptime(period_date, '%Y-%m-%d').date()
            
            # Store future FTE value for this date
            avail_fte_value = int(row.get('AVAIL_FTE', 0) or 0)
            future_avail_fte[period_date] = avail_fte_value
            logger.debug(f"Future FTE for {period_date}: {avail_fte_value}")
        
        logger.info(f"Queried projection data: {len(receipts_results)} receipts, {len(resolved_results)} resolved/FTE, {len(sla_due_results)} SLA due, {len(future_fte_results)} future FTE records")
        logger.info(f"Future avail FTE dates: {list(future_avail_fte.keys())[:5]} (showing first 5)")
        logger.info(f"Future avail FTE sample values: {list(future_avail_fte.values())[:5]} (showing first 5)")
        
        return projected_receipts, projected_resolved, projected_fte, projected_sla_due, future_avail_fte
        
    except Exception as e:
        logger.error(f"Error querying projection data: {str(e)}")
        return {}, {}, {}, {}, {}


async def get_last_day_metrics(engine, last_date: date, lob_filter: str, work_type_filter: str) -> Dict[tuple, Dict[str, Any]]:
    """Get metrics from the last available day for each LOB/work_type combination."""
    try:
        query = LAST_DAY_METRICS_QUERY.format(
            lob_filter=lob_filter,
            work_type_filter=work_type_filter
        ).replace(':last_date', f"'{last_date.strftime('%Y-%m-%d')}'")
        
        logger.info(f"Querying last day metrics for date: {last_date}")
        results = await engine.execute_query_async(query, limit=10000)
        
        # Log what columns are returned
        if results:
            logger.info(f"Last day metrics query returned {len(results)} rows with columns: {list(results[0].keys())}")
            logger.debug(f"First row sample: LOB={results[0].get('LOB')}, WORK_TYPE={results[0].get('WORK_TYPE')}, AVG_DAILY_RESOLVED={results[0].get('AVG_DAILY_RESOLVED')}")
        else:
            logger.warning(f"No last day metrics found for date {last_date}")
        
        # Create lookup dictionary keyed by (lob, work_type)
        metrics_lookup = {}
        for row in results:
            # Normalize LOB to uppercase to match projection query keys
            lob = row.get('LOB')
            if lob:
                lob = lob.upper()
            work_type = row.get('WORK_TYPE')
            key = (lob, work_type)
            
            total_work = float(row.get('TOTAL_WORK', 0) or 0)
            total_production = float(row.get('TOTAL_PRODUCTION', 0) or 0)
            req_fte = float(row.get('REQ_FTE', 0) or 0)
            avail_fte = float(row.get('AVAIL_FTE', 0) or 0)
            avg_daily_resolved = float(row.get('AVG_DAILY_RESOLVED', 0) or 0)
            
            # Read metrics directly from the irp_projection table (already calculated by ETL)
            avg_cycle_time_hrs = float(row.get('AVG_CYCLE_TIME_HRS', 0) or 0)
            avg_productive_hrs_per_day = float(row.get('AVG_PRODUCTIVE_HRS_PER_DAY', 0) or 0)
            
            # Fallback: If avg_cycle_time_hrs is 0 but req_fte exists, back-calculate it
            # Formula: req_fte = (total_work * avg_cycle_time_hrs) / avg_productive_hrs_per_day
            # Therefore: avg_cycle_time_hrs = (req_fte * avg_productive_hrs_per_day) / total_work
            if avg_cycle_time_hrs == 0 and req_fte > 0 and total_work > 0 and avg_productive_hrs_per_day > 0:
                avg_cycle_time_hrs = (req_fte * avg_productive_hrs_per_day) / total_work
                logger.info(f"Calculated fallback avg_cycle_time_hrs={avg_cycle_time_hrs:.4f}hrs for {key} from req_fte={req_fte}")
            
            # Alternative fallback: Use avg_daily_resolved if available
            elif avg_cycle_time_hrs == 0 and avg_daily_resolved > 0 and avg_productive_hrs_per_day > 0:
                # Approximate: avg_cycle_time_hrs ≈ productive_hrs / items_resolved_per_day
                avg_cycle_time_hrs = avg_productive_hrs_per_day / avg_daily_resolved
                logger.info(f"Calculated fallback avg_cycle_time_hrs={avg_cycle_time_hrs:.6f}hrs for {key} from avg_daily_resolved={avg_daily_resolved}")
            
            # Warn if still 0 after fallbacks
            if avg_cycle_time_hrs == 0:
                logger.warning(f"avg_cycle_time_hrs is still 0 for {key} after fallbacks! Future projections will have req_fte=0.")
            if avg_productive_hrs_per_day == 0:
                logger.warning(f"avg_productive_hrs_per_day is 0 for {key} in last day metrics! Future projections will have req_fte=0.")
            
            # Use avg_daily_resolved from table for avg_resolved_per_day
            avg_resolved_per_day = avg_daily_resolved if avg_daily_resolved > 0 else 0
            
            # Debug logging for avg_daily_resolved
            logger.debug(f"Metrics for {key}: total_work={total_work}, avg_daily_resolved={avg_daily_resolved}, avg_resolved_per_day={avg_resolved_per_day}")
            
            metrics_lookup[key] = {
                'total_work': total_work,
                'total_production': total_production,
                'backlog_count': float(row.get('BACKLOG_COUNT', 0) or 0),
                'avg_cycle_time_hrs': avg_cycle_time_hrs,
                'avg_productive_hrs_per_day': avg_productive_hrs_per_day,
                'avg_resolved_per_day': avg_resolved_per_day
            }
            
            logger.info(f"Last day metrics for {key}: req_fte={req_fte}, cycle_time={avg_cycle_time_hrs:.4f}hrs, productive_hrs={avg_productive_hrs_per_day}hrs, resolved_per_day={avg_resolved_per_day:.2f}")
        
        return metrics_lookup
    except Exception as e:
        logger.error(f"Error getting last day metrics: {str(e)}")
        return {}


def generate_daily_projections(
    start_date: date,
    end_date: date,
    last_day_metrics: Dict[tuple, Dict[str, Any]],
    projected_receipts: Dict[tuple, Dict[date, float]],
    projected_resolved: Dict[tuple, Dict[date, float]],
    projected_fte: Dict[tuple, Dict[date, float]],
    projected_sla_due: Dict[tuple, Dict[date, float]],
    future_avail_fte: Dict[date, int] = None
) -> List[Dict[str, Any]]:
    """
    Generate daily projections for future dates.
    
    Note: 
    - projected_receipts are now per-LOB/work_type with utilization-based calculations
    - projected_resolved and projected_fte are per-LOB/work_type with cycle-time-based calculations
    - projected_sla_due uses weighted 50-50 forecast (50% last week + 50% last month)
    - future_avail_fte is separate query result from ecobspecialist role + onboarding
    
    Iteratively calculates metrics for each day based on previous day's values.
    """
    projections = []
    
    # Get all LOB/work_type combinations
    all_keys = set(last_day_metrics.keys())
    
    # Sort dates to ensure sequential processing
    current_date = start_date
    previous_day_data = {}
    first_projection_log = True  # Flag to log only once for debugging
    
    while current_date <= end_date:
        for key in all_keys:
            lob, work_type = key
            
            # Get last known values from last_day_metrics or previous projection
            base_metrics = last_day_metrics.get(key, {})
            
            if current_date == start_date:
                prev_metrics = base_metrics
                prev_total_work = prev_metrics.get('total_work', 0)
                prev_production = prev_metrics.get('total_production', 0)
                avg_cycle_time_hrs = prev_metrics.get('avg_cycle_time_hrs', 0)
                avg_productive_hrs_per_day = prev_metrics.get('avg_productive_hrs_per_day', 0)
                avg_resolved_per_day = prev_metrics.get('avg_resolved_per_day', 0)
                
                # Log metrics source for first date
                if first_projection_log:
                    logger.info(f"First projection date {current_date} for ({lob}, {work_type}): avg_resolved_per_day={avg_resolved_per_day} from last_day_metrics")
            else:
                prev_key = (lob, work_type, current_date - timedelta(days=1))
                prev_metrics = previous_day_data.get(prev_key, {})
                prev_total_work = prev_metrics.get('total_work', 0)
                prev_production = prev_metrics.get('total_production', 0)
                avg_cycle_time_hrs = prev_metrics.get('avg_cycle_time_hrs', base_metrics.get('avg_cycle_time_hrs', 0))
                avg_productive_hrs_per_day = prev_metrics.get('avg_productive_hrs_per_day', base_metrics.get('avg_productive_hrs_per_day', 0))
                avg_resolved_per_day = prev_metrics.get('avg_resolved_per_day', base_metrics.get('avg_resolved_per_day', 0))
            
            # Get projected values for today - all are now per-LOB/work_type
            lob_work_type_key = (lob, work_type)
            new_items = projected_receipts.get(lob_work_type_key, {}).get(current_date, 0)
            total_production = projected_resolved.get(lob_work_type_key, {}).get(current_date, 0)
            
            # Use future_avail_fte from separate query if available, otherwise fall back to projected_fte
            if future_avail_fte and current_date in future_avail_fte:
                avail_fte = future_avail_fte[current_date]
                logger.debug(f"Using future_avail_fte for {current_date}: {avail_fte}")
            else:
                avail_fte = projected_fte.get(lob_work_type_key, {}).get(current_date, 0)
                if current_date >= datetime.now().date():
                    logger.warning(f"No future_avail_fte data for {current_date}, falling back to projected_fte: {avail_fte}")
            
            sla_due = projected_sla_due.get(lob_work_type_key, {}).get(current_date, 0)
            
            # Calculate backlog_count = prev_total_work - prev_production
            backlog_count = max(prev_total_work - prev_production, 0)
            
            # Calculate total_work = backlog_count + new_items
            total_work = backlog_count + new_items
            
            # Calculate req_fte = (sla_due * avg_cycle_time_hrs) / avg_productive_hrs_per_day
            req_fte = 0
            req_fte_sla = 0
            if avg_productive_hrs_per_day > 0 and avg_cycle_time_hrs > 0:
                req_fte = round((sla_due * avg_cycle_time_hrs) / avg_productive_hrs_per_day, 2)
                # Calculate required FTE based on SLA due (matching script approach)
                req_fte_sla = round((sla_due * avg_cycle_time_hrs) / avg_productive_hrs_per_day, 2)
            
            # Calculate fte_gap using SLA-based required FTE (matching script approach)
            fte_gap = round(req_fte_sla - avail_fte, 2)
            
            # Debug logging for FTE gap calculation (log first record and extreme values)
            if current_date == start_date and lob == list(all_keys)[0][0] and work_type == list(all_keys)[0][1]:
                logger.info(f"Sample FTE gap calculation for {current_date} ({lob}, {work_type}):")
                logger.info(f"  sla_due={sla_due}, avail_fte={avail_fte}, req_fte_sla={req_fte_sla}, fte_gap={fte_gap}")
                logger.info(f"  avg_cycle_time_hrs={avg_cycle_time_hrs:.6f}, avg_productive_hrs_per_day={avg_productive_hrs_per_day}")
            
            # Warn for extreme fte_gap values
            if abs(fte_gap) > 500:
                logger.warning(f"Large fte_gap for {current_date} ({lob}, {work_type}): gap={fte_gap}, req_fte_sla={req_fte_sla}, avail={avail_fte}, sla_due={sla_due}, cycle_time={avg_cycle_time_hrs:.6f}hrs")
            
            # Calculate overtime_estimate
            overtime_estimate = 0
            if fte_gap > 0 and avg_productive_hrs_per_day > 0:
                overtime_estimate = round(fte_gap * avg_productive_hrs_per_day, 2)
            
            # Calculate dwoh = total_work / avg_resolved_per_day
            dwoh = 0
            if avg_resolved_per_day > 0:
                dwoh = round(total_work / avg_resolved_per_day, 0)
            else:
                if first_projection_log:
                    logger.warning(f"DWOH is 0 because avg_resolved_per_day=0 for {current_date} ({lob}, {work_type}). total_work={total_work}")
            
            # Create projection record
            projection = {
                'date': current_date,
                'lob': lob,
                'work_type': work_type,
                'backlog_count': backlog_count,
                'new_items': new_items,
                'total_work': total_work,
                'sla_due': sla_due,  # Use forecasted SLA due (weighted 50-50 approach)
                'req_fte': req_fte,
                'avail_fte': avail_fte,
                'total_production': total_production,
                'prod_applied_to_sla': "N/A",  # N/A for future predictions
                'out_of_sla': "N/A",  # N/A for future predictions
                'fte_gap': fte_gap,
                'overtime_estimate': str(overtime_estimate),  # Convert to string
                'dwoh': dwoh,
                'avg_cycle_time_hrs': avg_cycle_time_hrs,
                'avg_productive_hrs_per_day': avg_productive_hrs_per_day,
                'avg_resolved_per_day': avg_resolved_per_day,
                'avg_daily_resolved': avg_resolved_per_day  # Same as avg_resolved_per_day, for aggregation consistency
            }
            
            projections.append(projection)
            
            # Store for next day's calculation
            previous_day_data[(lob, work_type, current_date)] = projection
        
        # After first iteration, disable detailed logging
        if first_projection_log:
            first_projection_log = False
        
        current_date += timedelta(days=1)
    
    return projections


def aggregate_by_grouping_type(
    daily_data: List[Dict[str, Any]],
    grouping_type: str
) -> List[Dict[str, Any]]:
    """
    Aggregate daily data by grouping type (daily, weekly, monthly, quarterly, yearly).
    Sums metrics across all LOB/work_type for each period.
    
    For non-daily groupings:
    - req_fte is divided by working days (Mon-Fri) to get average FTE needed per day
    - fte_gap and overtime_estimate are recalculated based on adjusted req_fte
    - total_work uses backlog from first day + sum of new_items to avoid double-counting
    """
    from datetime import datetime as dt
    
    if not daily_data:
        return []
    
    # Sort daily_data by date to ensure correct first date identification
    sorted_daily_data = sorted(daily_data, key=lambda x: x['date'] if not isinstance(x['date'], str) else dt.strptime(x['date'], '%Y-%m-%d').date())
    
    # Group data by period
    period_data = {}
    period_first_date = {}  # Track first date for each period
    
    for record in sorted_daily_data:
        record_date = record['date']
        if isinstance(record_date, str):
            record_date = dt.strptime(record_date, '%Y-%m-%d').date()
        
        # Determine period key and period end based on grouping type
        if grouping_type == 'daily':
            period_key = record_date
            period_end = record_date
            period_label = record_date.strftime('%Y-%m-%d')
        elif grouping_type == 'weekly':
            # Start of week (Monday)
            period_key = record_date - timedelta(days=record_date.weekday())
            period_end = period_key + timedelta(days=6)
            # Format as range
            period_label = f"{period_key.strftime('%m/%d/%Y')} - {period_end.strftime('%m/%d/%Y')}"
        elif grouping_type == 'monthly':
            period_key = record_date.replace(day=1)
            # Last day of month
            if record_date.month == 12:
                period_end = record_date.replace(day=31)
            else:
                period_end = record_date.replace(month=record_date.month + 1, day=1) - timedelta(days=1)
            period_label = record_date.strftime('%b %Y')
        elif grouping_type == 'quarterly':
            quarter = (record_date.month - 1) // 3 + 1
            period_key = record_date.replace(month=(quarter-1)*3 + 1, day=1)
            # Last day of quarter
            last_month = quarter * 3
            if last_month == 12:
                period_end = record_date.replace(month=12, day=31)
            else:
                period_end = record_date.replace(month=last_month + 1, day=1) - timedelta(days=1)
            period_label = f"{record_date.year}-Q{quarter}"
        elif grouping_type == 'yearly':
            period_key = record_date.replace(month=1, day=1)
            period_end = record_date.replace(month=12, day=31)
            period_label = str(record_date.year)
        else:
            period_key = record_date
            period_end = record_date
            period_label = record_date.strftime('%Y-%m-%d')
        
        # Initialize period if not exists and track the first date
        if period_key not in period_data:
            period_data[period_key] = {
                'date': period_label,
                'date_obj': period_key,  # Store period start for filtering
                'period_end': period_end,  # Store period end for filtering
                'total_work': 0,
                'backlog_count': 0,
                'new_items': 0,
                'sla_due': 0,
                'req_fte': 0,
                'avail_fte': 0,
                'total_production': 0,
                'prod_applied_to_sla': 0,
                'out_of_sla': 0,
                'fte_gap': 0,
                'overtime_estimate': 0,
                'dwoh': 0,
                'avg_daily_resolved': 0,  # Track for DWOH calculation
                'count': 0,
                'working_days': set(),  # Track unique working days (Mon-Fri)
                'all_days': set(),  # Track all unique days
                'avg_productive_hrs_per_day': 8.0,  # Default value, will be updated with most recent
                'has_na_prod_applied': False,  # Track if any N/A values present
                'has_na_out_of_sla': False  # Track if any N/A values present
            }
            period_first_date[period_key] = record_date
        
        # Check if this record's date is the first date in the period
        # This allows ALL records from the first date to contribute their backlog
        is_first_date = (record_date == period_first_date[period_key])
        
        # Track working days (Mon-Fri = weekday 0-4) and all days
        period_data[period_key]['all_days'].add(record_date)
        if record_date.weekday() < 5:  # Monday=0 to Friday=4
            period_data[period_key]['working_days'].add(record_date)
        
        # Aggregate metrics
        # For total_work: use backlog from first day only + sum of new_items
        if grouping_type == 'daily':
            # For daily, just sum total_work as-is
            period_data[period_key]['total_work'] += record.get('total_work', 0)
        else:
            # For non-daily: accumulate backlog from first day + all new_items
            if is_first_date:
                period_data[period_key]['backlog_count'] += record.get('backlog_count', 0)
            period_data[period_key]['new_items'] += record.get('new_items', 0)
        
        period_data[period_key]['sla_due'] += record.get('sla_due', 0)
        period_data[period_key]['req_fte'] += record.get('req_fte', 0)
        period_data[period_key]['avail_fte'] = max(period_data[period_key]['avail_fte'], record.get('avail_fte', 0))  # MAX for avail_fte
        period_data[period_key]['total_production'] += record.get('total_production', 0)
        # Convert string fields to float before adding (skip N/A values)
        prod_applied = record.get('prod_applied_to_sla', 0)
        if prod_applied != "N/A":
            period_data[period_key]['prod_applied_to_sla'] += float(prod_applied) if isinstance(prod_applied, str) else prod_applied
        else:
            period_data[period_key]['has_na_prod_applied'] = True
        
        out_of_sla = record.get('out_of_sla', 0)
        if out_of_sla != "N/A":
            period_data[period_key]['out_of_sla'] += float(out_of_sla) if isinstance(out_of_sla, str) else out_of_sla
        else:
            period_data[period_key]['has_na_out_of_sla'] = True
        
        # DON'T sum fte_gap - calculate it after aggregation from req_fte and avail_fte
        # period_data[period_key]['fte_gap'] += record.get('fte_gap', 0)  # INCORRECT: sums per-LOB gaps
        overtime = record.get('overtime_estimate', 0)
        period_data[period_key]['overtime_estimate'] += float(overtime) if isinstance(overtime, str) else overtime
        
        # Track avg_daily_resolved (it's the same for all LOB/work_type on a given date)
        # Take the maximum value to handle cases where some records might have 0
        if 'avg_daily_resolved' in record:
            current_avg = record.get('avg_daily_resolved', 0)
            if current_avg > 0:
                period_data[period_key]['avg_daily_resolved'] = max(period_data[period_key]['avg_daily_resolved'], current_avg)
        
        period_data[period_key]['count'] += 1
        
        # Store req_fte_sla separately for proper fte_gap calculation
        if 'req_fte_sla' not in period_data[period_key]:
            period_data[period_key]['req_fte_sla'] = 0
        # Calculate req_fte_sla from the formula: req_fte_sla = (sla_due * cycle_time) / productive_hrs
        # We can back-calculate it from individual fte_gap: req_fte_sla = fte_gap + avail_fte
        individual_req_fte_sla = record.get('fte_gap', 0) + record.get('avail_fte', 0)
        period_data[period_key]['req_fte_sla'] += individual_req_fte_sla
        
        # Keep most recent avg_productive_hrs_per_day (records are sorted by date)
        if 'avg_productive_hrs_per_day' in record and record['avg_productive_hrs_per_day']:
            period_data[period_key]['avg_productive_hrs_per_day'] = record['avg_productive_hrs_per_day']
    
    # Convert to list and calculate averages where needed
    aggregated = []
    for period_key in sorted(period_data.keys()):
        data = period_data[period_key].copy()
        
        # Get working days count
        working_days_count = len(data['working_days'])
        
        # For non-daily groupings, calculate total_work = backlog_count + new_items
        if grouping_type != 'daily':
            data['total_work'] = data['backlog_count'] + data['new_items']
        
        # Calculate fte_gap AFTER aggregation: req_fte_sla_total - avail_fte
        # This is correct because avail_fte is the total staff, not per-LOB
        data['fte_gap'] = round(data.get('req_fte_sla', 0) - data['avail_fte'], 0)
        
        # Calculate req_fte: For non-daily groupings, divide by working days
        # This represents average FTE needed per day across the period
        if grouping_type != 'daily' and working_days_count > 0:
            data['req_fte'] = round(data['req_fte'] / working_days_count, 0)
            
            # For non-daily groupings, also adjust fte_gap calculation
            # Use average req_fte_sla per day instead of total
            data['req_fte_sla'] = round(data.get('req_fte_sla', 0) / working_days_count, 0)
            data['fte_gap'] = round(data['req_fte_sla'] - data['avail_fte'], 0)
            
            # Recalculate overtime_estimate based on adjusted fte_gap
            # Use most recent avg_productive_hrs_per_day instead of hardcoded value
            avg_productive_hrs = data.get('avg_productive_hrs_per_day', 8.0)
            if data['fte_gap'] > 0:
                data['overtime_estimate'] = str(round(data['fte_gap'] * avg_productive_hrs * working_days_count, 0))
            else:
                data['overtime_estimate'] = "0"
        
        # Calculate DWOH dynamically: total_work / avg_daily_resolved
        avg_daily_resolved = data.get('avg_daily_resolved', 0)
        if avg_daily_resolved > 0:
            data['dwoh'] = round(data['total_work'] / avg_daily_resolved, 0)
            logger.debug(f"Calculated DWOH for period {data['date']}: total_work={data['total_work']} / avg_daily_resolved={avg_daily_resolved} = {data['dwoh']}")
        else:
            data['dwoh'] = 0
            logger.warning(f"DWOH is 0 for period {data['date']} because avg_daily_resolved={avg_daily_resolved}. total_work={data['total_work']}")
        
        # Convert numeric aggregated values to strings for string fields
        # If any N/A values were present, output N/A
        if data.get('has_na_prod_applied', False):
            data['prod_applied_to_sla'] = "N/A"
        else:
            data['prod_applied_to_sla'] = str(int(data['prod_applied_to_sla']))
        
        if data.get('has_na_out_of_sla', False):
            data['out_of_sla'] = "N/A"
        else:
            data['out_of_sla'] = str(int(data['out_of_sla']))
        
        if not isinstance(data['overtime_estimate'], str):
            data['overtime_estimate'] = str(int(data['overtime_estimate']))
        
        # Clean up temporary fields
        del data['count']
        del data['working_days']
        del data['all_days']
        if 'has_na_prod_applied' in data:
            del data['has_na_prod_applied']
        if 'has_na_out_of_sla' in data:
            del data['has_na_out_of_sla']
        if 'avg_daily_resolved' in data:
            del data['avg_daily_resolved']
        if 'backlog_count' in data:
            del data['backlog_count']
        if 'new_items' in data:
            del data['new_items']
        if 'avg_productive_hrs_per_day' in data:
            del data['avg_productive_hrs_per_day']
        if 'req_fte_sla' in data:
            del data['req_fte_sla']  # Remove temporary field used for fte_gap calculation
        
        # Keep date_obj for filtering but will be removed before final output
        aggregated.append(data)
    
    return aggregated


# =============================================================================
# SQL Query
# =============================================================================

IRP_PROJECTION_QUERY = """
-- =====================================================================
-- IRP PROJECTION QUERY - Reading from irp_projection table
-- Returns daily data grouped by LOB and work_type
-- =====================================================================

WITH date_range_config AS (
    SELECT
        '{start_date}'::DATE AS period_start,
        '{end_date}'::DATE AS period_end,
        '{grouping_type}' AS grouping_type
),
raw_data AS (
    SELECT
        date,
        lob,
        work_type,
        CASE (SELECT grouping_type FROM date_range_config)
            WHEN 'daily' THEN date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', date)
        END AS period_date,
        backlog_count,
        new_items,
        total_work,
        sla_due,
        req_fte,
        avail_fte,
        total_production,
        prod_applied_to_sla,
        out_of_sla,
        fte_gap,
        overtime_estimate,
        avg_daily_resolved
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.irp_projection
    WHERE date BETWEEN (SELECT period_start FROM date_range_config) 
                   AND (SELECT period_end FROM date_range_config)
      {lob_filter}
      {work_type_filter}
),
raw_data_with_first_flag AS (
    SELECT
        *,
        CASE WHEN date = MIN(date) OVER (PARTITION BY period_date, lob, work_type) 
             THEN 1 ELSE 0 END AS is_first_date
    FROM raw_data
),
aggregated_data AS (
    SELECT
        period_date,
        lob,
        work_type,
        MIN(date) AS first_date,
        MAX(date) AS last_date,
        -- Backlog count from first day only
        SUM(CASE WHEN is_first_date = 1 THEN backlog_count ELSE 0 END) AS backlog_count,
        -- Sum of new items across all days
        SUM(new_items) AS new_items,
        -- For daily: use total_work as-is
        -- For non-daily: backlog from first day + sum of new items across period
        CASE (SELECT grouping_type FROM date_range_config)
            WHEN 'daily' THEN SUM(total_work)
            ELSE SUM(CASE WHEN is_first_date = 1 THEN backlog_count ELSE 0 END) + SUM(new_items)
        END AS total_work,
        SUM(sla_due) AS sla_due,
        ROUND(AVG(req_fte), 0) AS req_fte,
        ROUND(AVG(avail_fte), 0) AS avail_fte,
        SUM(total_production) AS total_production,
        SUM(prod_applied_to_sla) AS prod_applied_to_sla,
        SUM(out_of_sla) AS out_of_sla,
        ROUND(AVG(fte_gap), 0) AS fte_gap,
        SUM(overtime_estimate) AS overtime_estimate,
        -- avg_daily_resolved is the same value repeated for all LOB/work_type on each date
        -- Take AVG across dates in the period to get the average daily resolution rate for that period
        ROUND(AVG(avg_daily_resolved), 2) AS AVG_DAILY_RESOLVED
    FROM raw_data_with_first_flag
    GROUP BY period_date, lob, work_type
)
SELECT
    CASE (SELECT grouping_type FROM date_range_config)
        WHEN 'daily' THEN TO_VARCHAR(period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_VARCHAR(first_date, 'MM/DD/YYYY') || ' - ' || TO_VARCHAR(last_date, 'MM/DD/YYYY')
        WHEN 'monthly' THEN TO_VARCHAR(period_date, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_VARCHAR(period_date, 'YYYY') || '-Q' || QUARTER(period_date)
        WHEN 'yearly' THEN TO_VARCHAR(period_date, 'YYYY')
    END AS date,
    lob,
    work_type,
    backlog_count,
    new_items,
    total_work,
    sla_due,
    req_fte,
    avail_fte,
    total_production,
    prod_applied_to_sla,
    out_of_sla,
    fte_gap,
    overtime_estimate,
    AVG_DAILY_RESOLVED,
    period_date AS sort_date
FROM aggregated_data
ORDER BY period_date, lob, work_type
"""


# =============================================================================
# API Endpoint
# =============================================================================

@router.post(
    "/irp-projection",
    response_model=IRPProjectionResponse,
    summary="Get IRP Projection Data",
    description="""
    Retrieve IRP (Inventory Resource Planning) projection data for workforce planning.
    
    This endpoint reads pre-calculated daily IRP metrics from the irp_projection table and 
    aggregates them by the specified grouping type (daily, weekly, monthly, quarterly, yearly).
    
    Input Parameters:
    - **start_date** (required): Start date in YYYY-MM-DD format
    - **end_date** (required): End date in YYYY-MM-DD format
    - **grouping_type** (optional): Grouping type - daily, weekly, monthly, quarterly, yearly (default: daily)
    - **lob** (optional): List of Line of Business values to filter (e.g., ['Commercial', 'Medicare'])
    - **staffing_category** (optional): List of staffing categories to filter (not currently used)
    - **work_type** (optional): List of work types/intake source systems to filter
    
    Returned Metrics (aggregated across LOB and work_type):
    - **Total Work**: Sum of backlog + new receipts
    - **SLA Due**: Sum of items with SLA due date in period
    - **Req FTE**: Sum of required FTE based on work volume and cycle time
    - **Avail FTE**: Maximum available FTE (same across all LOB/work_type)
    - **Total Production**: Sum of resolved items
    - **Prod Applied to SLA**: Sum of resolved items with SLA due date
    - **Out of SLA**: Sum of items resolved after SLA due date
    - **FTE Gap**: Sum of (Required FTE - Available FTE)
    - **Overtime Estimate**: Sum of overtime hours needed
    - **DWOH**: Average Days Work On Hand
    
    Data Source:
    - **irp_projection**: Pre-calculated daily IRP metrics by date, LOB, and work_type
    
    Features:
    - Aggregates daily data by grouping period (week, month, quarter, year)
    - Sums metrics across all LOB and work_type combinations
    - Supports filtering by LOB and work_type
    - Fast performance using pre-calculated table data
    """,
)
async def get_irp_projection(request: IRPProjectionRequest):
    """
    Get IRP projection data for workforce planning.
    Reads actual data from irp_projection table and generates projections for future dates.
    """
    try:
        logger.info(f"IRP Projection request received: {request.dict()}")
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        
        logger.info(f"Filters applied - LOB: {len(request.lob or [])} values, Work Type: {len(request.work_type or [])} values")
        
        # Get engine
        engine = connection_manager.get_engine()
        
        # Convert request dates to date objects
        if isinstance(request.start_date, str):
            start_date = datetime.strptime(request.start_date, '%Y-%m-%d').date()
        elif hasattr(request.start_date, 'date'):
            start_date = request.start_date.date()
        else:
            start_date = request.start_date
            
        if isinstance(request.end_date, str):
            end_date = datetime.strptime(request.end_date, '%Y-%m-%d').date()
        elif hasattr(request.end_date, 'date'):
            end_date = request.end_date.date()
        else:
            end_date = request.end_date
        
        # Get last available date in irp_projection table
        last_available_date = await get_last_available_date(engine)
        logger.info(f"Last available date in irp_projection table: {last_available_date}")
        
        # Determine if we need projections
        need_projections = last_available_date and end_date > last_available_date
        
        # Initialize combined daily data
        all_daily_data = []
        
        # Query actual data (if start_date <= last_available_date)
        if not last_available_date or start_date <= last_available_date:
            actual_end_date = min(end_date, last_available_date) if last_available_date else end_date
            
            logger.info(f"Querying actual data from {start_date} to {actual_end_date}")
            
            # Query actual data using IRP_PROJECTION_QUERY with daily grouping
            # Note: Always retrieve as daily data to match projected data format,
            # then aggregate to requested grouping_type at the end
            actual_query = IRP_PROJECTION_QUERY.format(
                start_date=start_date.strftime('%Y-%m-%d'),
                end_date=actual_end_date.strftime('%Y-%m-%d'),
                grouping_type='daily',
                lob_filter=lob_filter,
                work_type_filter=work_type_filter,
                SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
                SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
            )
            
            # Log a snippet of the query to verify avg_daily_resolved is selected
            logger.debug(f"Executing IRP_PROJECTION_QUERY for date range {start_date} to {actual_end_date}")
            logger.debug(f"Query SELECT clause (first 500 chars): {actual_query[actual_query.find('SELECT'):actual_query.find('SELECT')+500]}")
            
            actual_results = await engine.execute_query_async(actual_query, limit=100000)
            
            # Log query result metadata
            if actual_results:
                logger.info(f"Query returned {len(actual_results)} rows")
                logger.info(f"Columns in result: {list(actual_results[0].keys())}")
            else:
                logger.warning("Query returned no results")
            
            # Convert actual results to daily data format
            # Note: IRP_PROJECTION_QUERY returns data grouped by LOB and work_type
            for idx, row in enumerate(actual_results):
                # Parse the date from the formatted string returned by the query
                date_str = row.get('DATE')
                if date_str:
                    row_date = datetime.strptime(date_str, '%Y-%m-%d').date()
                else:
                    # Fallback to sort_date if date string parsing fails
                    row_date = row.get('SORT_DATE')
                    if hasattr(row_date, 'date'):
                        row_date = row_date.date()
                
                # Extract values for DWOH calculation
                total_work = float(row.get('TOTAL_WORK', 0) or 0)
                avg_daily_resolved = float(row.get('AVG_DAILY_RESOLVED', 0) or 0)
                
                # Calculate DWOH
                if avg_daily_resolved > 0:
                    dwoh = round(total_work / avg_daily_resolved, 2)
                else:
                    dwoh = 0.0
                
                # Debug logging for first 3 records
                if idx < 3:
                    logger.debug(f"Row {idx}: DATE={date_str}, LOB={row.get('LOB')}, WORK_TYPE={row.get('WORK_TYPE')}")
                    logger.debug(f"  TOTAL_WORK={total_work}, AVG_DAILY_RESOLVED={avg_daily_resolved}, CALCULATED_DWOH={dwoh}")
                    logger.debug(f"  Raw row data keys: {list(row.keys())}")
                
                all_daily_data.append({
                    'date': row_date,
                    'lob': row.get('LOB'),
                    'work_type': row.get('WORK_TYPE'),
                    'backlog_count': float(row.get('BACKLOG_COUNT', 0) or 0),
                    'new_items': float(row.get('NEW_ITEMS', 0) or 0),
                    'total_work': total_work,
                    'sla_due': float(row.get('SLA_DUE', 0) or 0),
                    'req_fte': float(row.get('REQ_FTE', 0) or 0),
                    'avail_fte': float(row.get('AVAIL_FTE', 0) or 0),
                    'total_production': float(row.get('TOTAL_PRODUCTION', 0) or 0),
                    'prod_applied_to_sla': str(int(float(row.get('PROD_APPLIED_TO_SLA', 0) or 0))),
                    'out_of_sla': str(int(float(row.get('OUT_OF_SLA', 0) or 0))),
                    'fte_gap': float(row.get('FTE_GAP', 0) or 0),
                    'overtime_estimate': str(int(float(row.get('OVERTIME_ESTIMATE', 0) or 0))),
                    'dwoh': dwoh,
                    'avg_daily_resolved': avg_daily_resolved  # Pass to aggregation function for DWOH calculation
                })
            
            logger.info(f"Retrieved {len(actual_results)} actual data records")
            if actual_results:
                logger.info(f"Sample AVG_DAILY_RESOLVED values from first 3 rows: {[float(r.get('AVG_DAILY_RESOLVED', 0) or 0) for r in actual_results[:3]]}")
        
        # Generate projections for future dates if needed
        if need_projections:
            projection_start = last_available_date + timedelta(days=1)
            logger.info(f"Generating projections from {projection_start} to {end_date}")
            
            # Get last day metrics for all LOB/work_type combinations
            last_day_metrics = await get_last_day_metrics(engine, last_available_date, lob_filter, work_type_filter)
            logger.info(f"Retrieved last day metrics for {len(last_day_metrics)} LOB/work_type combinations")
            
            # Query projection data from demand_inventory.py queries
            logger.info(f"Querying projection data for {projection_start} to {end_date}")
            projected_receipts, projected_resolved, projected_fte, projected_sla_due, future_avail_fte = await query_projection_data(
                engine=engine,
                start_date=projection_start,
                end_date=end_date,
                last_available_date=last_available_date,
                lob_values=request.lob,
                work_type_values=request.work_type
            )
            
            # Generate daily projections
            if last_day_metrics:
                projected_data = generate_daily_projections(
                    start_date=projection_start,
                    end_date=end_date,
                    last_day_metrics=last_day_metrics,
                    projected_receipts=projected_receipts,
                    projected_resolved=projected_resolved,
                    projected_fte=projected_fte,
                    projected_sla_due=projected_sla_due,
                    future_avail_fte=future_avail_fte
                )
                
                all_daily_data.extend(projected_data)
                logger.info(f"Generated {len(projected_data)} projected data records")
                # Log sample projection to verify avg_daily_resolved is present
                if projected_data:
                    sample = projected_data[0]
                    logger.debug(f"Sample projection: date={sample.get('date')}, total_work={sample.get('total_work')}, avg_daily_resolved={sample.get('avg_daily_resolved')}, dwoh={sample.get('dwoh')}")
            else:
                logger.warning("No last day metrics found - cannot generate projections")
        
        logger.info(f"Total daily data records: {len(all_daily_data)}")
        
        # Aggregate daily data by grouping type
        grouping_type = request.grouping_type or 'daily'
        aggregated_data = aggregate_by_grouping_type(all_daily_data, grouping_type)
        
        logger.info(f"Aggregated to {len(aggregated_data)} periods using {grouping_type} grouping")
        
        # Log sample DWOH values after aggregation
        if aggregated_data:
            sample_dwoh_values = [f"{d.get('date')}: {d.get('dwoh')}" for d in aggregated_data[:3]]
            logger.info(f"Sample DWOH values after aggregation: {sample_dwoh_values}")
        
        # Filter aggregated data to only include periods that overlap with requested range
        # A period overlaps if: period_start <= end_date AND period_end >= start_date
        filtered_data = []
        for row in aggregated_data:
            period_start = row.get('date_obj')
            period_end = row.get('period_end')
            # Check if period overlaps with requested date range
            if period_start and period_end and period_start <= end_date and period_end >= start_date:
                # Remove temporary fields before adding to filtered data
                row_copy = row.copy()
                del row_copy['date_obj']
                del row_copy['period_end']
                filtered_data.append(row_copy)
        
        logger.info(f"Filtered to {len(filtered_data)} periods within requested date range")
        
        # Convert aggregated data to data points
        data_points = []
        for row in filtered_data:
            data_points.append(IRPProjectionDataPoint(
                date=row.get('date'),
                total_work=int(row.get('total_work', 0)),
                sla_due=int(row.get('sla_due', 0)),
                req_fte=int(row.get('req_fte', 0)),
                avail_fte=int(row.get('avail_fte', 0)),
                total_production=int(row.get('total_production', 0)),
                prod_applied_to_sla=str(row.get('prod_applied_to_sla', "0")),
                out_of_sla=str(row.get('out_of_sla', "0")),
                fte_gap=int(row.get('fte_gap', 0)),
                overtime_estimate=str(row.get('overtime_estimate', "0")) + " Hours",
                dwoh=int(row.get('dwoh', 0))
            ))
        
        logger.info(f"Successfully processed {len(data_points)} IRP projection records (actual + projected)")
        
        return IRPProjectionResponse(
            status="success",
            data=data_points,
            record_count=len(data_points),
            message=f"Successfully retrieved IRP projection data for {len(data_points)} periods",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in IRP projection endpoint: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve IRP projection data: {str(e)}"
        )
