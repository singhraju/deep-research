import asyncio
import logging
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import WorkforceIQMembershipKPIsRequest, WorkforceIQMembershipKPIsResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, MEMBERSHIP_LOB_MAP
import config
from controllers.WorkForce_IQ.header_kpis import build_intake_source_filter, build_market_filter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()


# =============================================================================
# SQL Queries
# =============================================================================

ACTUAL_MEMBERSHIP_QUERY = f"""
WITH date_params AS (
    SELECT 
        YEAR('{{start_date}}'::DATE) AS from_year,
        MONTH('{{start_date}}'::DATE) AS from_month,
        YEAR('{{end_date}}'::DATE) AS to_year,
        MONTH('{{end_date}}'::DATE) AS to_month,
        YEAR(CURRENT_DATE) AS current_year,
        MONTH(CURRENT_DATE) AS current_month,
        (YEAR('{{start_date}}'::DATE) * 100 + MONTH('{{start_date}}'::DATE)) AS from_year_month,
        (YEAR('{{end_date}}'::DATE) * 100 + MONTH('{{end_date}}'::DATE)) AS to_year_month,
        (YEAR(CURRENT_DATE) * 100 + MONTH(CURRENT_DATE)) AS current_year_month
),
membership_data AS (
    SELECT 
        m.YEAR,
        m.MONTH,
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        CASE 
            WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
            WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
            WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
            WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
            WHEN UPPER(m.MONTH) = 'MAY' THEN 5
            WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
            WHEN UPPER(m.MONTH) = 'JULY' THEN 7
            WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
            WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
            WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
            WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
            WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            ELSE NULL
        END AS month_num,
        (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) AS year_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    CROSS JOIN date_params dp
    WHERE 1=1
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) BETWEEN dp.from_year_month AND dp.to_year_month
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) < dp.current_year_month
        {{lob_filter}}
),
monthly_totals AS (
    SELECT 
        YEAR,
        MONTH,
        month_num,
        year_month,
        SUM(ACTUAL_MEMBERSHIP) AS monthly_membership_total
    FROM membership_data
    GROUP BY YEAR, MONTH, month_num, year_month
)
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN NULL
        ELSE ROUND(AVG(monthly_membership_total), 2)
    END AS ACTUAL_MEMBERSHIP_COUNT
FROM monthly_totals
"""

PROJECTED_MEMBERSHIP_QUERY = f"""
WITH date_params AS (
    SELECT 
        YEAR('{{start_date}}'::DATE) AS from_year,
        MONTH('{{start_date}}'::DATE) AS from_month,
        YEAR('{{end_date}}'::DATE) AS to_year,
        MONTH('{{end_date}}'::DATE) AS to_month,
        (YEAR('{{start_date}}'::DATE) * 100 + MONTH('{{start_date}}'::DATE)) AS from_year_month,
        (YEAR('{{end_date}}'::DATE) * 100 + MONTH('{{end_date}}'::DATE)) AS to_year_month
),
membership_data AS (
    SELECT 
        m.YEAR,
        m.MONTH,
        m.LOB,
        m.PROJECTED_MEMBERSHIP,
        CASE 
            WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
            WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
            WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
            WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
            WHEN UPPER(m.MONTH) = 'MAY' THEN 5
            WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
            WHEN UPPER(m.MONTH) = 'JULY' THEN 7
            WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
            WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
            WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
            WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
            WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            ELSE NULL
        END AS month_num,
        (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) AS year_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    CROSS JOIN date_params dp
    WHERE 1=1
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) BETWEEN dp.from_year_month AND dp.to_year_month
        {{lob_filter}}
        AND m.PROJECTED_MEMBERSHIP IS NOT NULL
),
monthly_totals AS (
    SELECT 
        YEAR,
        MONTH,
        month_num,
        year_month,
        SUM(PROJECTED_MEMBERSHIP) AS monthly_membership_total
    FROM membership_data
    GROUP BY YEAR, MONTH, month_num, year_month
)
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN NULL
        ELSE ROUND(AVG(monthly_membership_total), 2)
    END AS PROJECTED_MEMBERSHIP_COUNT
FROM monthly_totals
"""

VARIANCE_QUERY = f"""
WITH date_params AS (
    SELECT 
        YEAR('{{start_date}}'::DATE) AS from_year,
        MONTH('{{start_date}}'::DATE) AS from_month,
        YEAR('{{end_date}}'::DATE) AS to_year,
        MONTH('{{end_date}}'::DATE) AS to_month,
        YEAR(CURRENT_DATE) AS current_year,
        MONTH(CURRENT_DATE) AS current_month,
        (YEAR('{{start_date}}'::DATE) * 100 + MONTH('{{start_date}}'::DATE)) AS from_year_month,
        (YEAR('{{end_date}}'::DATE) * 100 + MONTH('{{end_date}}'::DATE)) AS to_year_month,
        (YEAR(CURRENT_DATE) * 100 + MONTH(CURRENT_DATE)) AS current_year_month
),
membership_data AS (
    SELECT 
        m.YEAR,
        m.MONTH,
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        m.PROJECTED_MEMBERSHIP,
        CASE 
            WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
            WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
            WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
            WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
            WHEN UPPER(m.MONTH) = 'MAY' THEN 5
            WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
            WHEN UPPER(m.MONTH) = 'JULY' THEN 7
            WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
            WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
            WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
            WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
            WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            ELSE NULL
        END AS month_num,
        (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) AS year_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    CROSS JOIN date_params dp
    WHERE 1=1
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) BETWEEN dp.from_year_month AND dp.to_year_month
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) < dp.current_year_month
        {{lob_filter}}
        AND m.ACTUAL_MEMBERSHIP IS NOT NULL
        AND m.PROJECTED_MEMBERSHIP IS NOT NULL
),
monthly_variance AS (
    SELECT 
        YEAR,
        MONTH,
        month_num,
        year_month,
        SUM(ACTUAL_MEMBERSHIP) AS monthly_actual_total,
        SUM(PROJECTED_MEMBERSHIP) AS monthly_projected_total,
        SUM(ACTUAL_MEMBERSHIP) - SUM(PROJECTED_MEMBERSHIP) AS monthly_variance
    FROM membership_data
    GROUP BY YEAR, MONTH, month_num, year_month
)
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN NULL
        ELSE ROUND(AVG(monthly_variance), 2)
    END AS VARIANCE_COUNT,
    
    CASE 
        WHEN COUNT(*) = 0 THEN NULL
        WHEN AVG(monthly_projected_total) = 0 THEN NULL
        ELSE ROUND((AVG(monthly_variance) / AVG(monthly_projected_total)) * 100, 2)
    END AS VARIANCE_PERCENTAGE
FROM monthly_variance
"""

DEMAND_UTILIZATION_QUERY = f"""
WITH input_params AS (
    SELECT 
        '{{start_date}}'::DATE AS from_date,
        '{{end_date}}'::DATE AS to_date
),
date_params AS (
    SELECT 
        YEAR(ip.from_date) AS from_year,
        MONTH(ip.from_date) AS from_month,
        YEAR(ip.to_date) AS to_year,
        MONTH(ip.to_date) AS to_month,
        YEAR(CURRENT_DATE) AS current_year,
        MONTH(CURRENT_DATE) AS current_month,
        (YEAR(ip.from_date) * 100 + MONTH(ip.from_date)) AS from_year_month,
        (YEAR(ip.to_date) * 100 + MONTH(ip.to_date)) AS to_year_month,
        (YEAR(CURRENT_DATE) * 100 + MONTH(CURRENT_DATE)) AS current_year_month,
        ip.from_date,
        ip.to_date
    FROM input_params ip
),
membership_data AS (
    SELECT 
        m.YEAR,
        m.MONTH,
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        CASE 
            WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
            WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
            WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
            WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
            WHEN UPPER(m.MONTH) = 'MAY' THEN 5
            WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
            WHEN UPPER(m.MONTH) = 'JULY' THEN 7
            WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
            WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
            WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
            WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
            WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            ELSE NULL
        END AS month_num,
        (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) AS year_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    CROSS JOIN date_params dp
    WHERE 1=1
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) BETWEEN dp.from_year_month AND dp.to_year_month
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                ELSE NULL
            END
        ) < dp.current_year_month
        {{lob_filter}}
),
monthly_membership_totals AS (
    SELECT 
        SUM(ACTUAL_MEMBERSHIP) AS total_membership
    FROM membership_data
),
work_items AS (
    SELECT 
        COUNT(DISTINCT inv.PYID) AS actual_receipts
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    CROSS JOIN date_params dp
    WHERE 1=1
        AND inv.PXCREATEDATETIME >= dp.from_date
        AND inv.PXCREATEDATETIME < DATEADD(day, 1, dp.to_date)
        {{lob_filter_inv}}
        {{intake_source_filter}}
)
SELECT 
    CASE 
        WHEN (SELECT total_membership FROM monthly_membership_totals) IS NULL THEN NULL
        WHEN (SELECT total_membership FROM monthly_membership_totals) = 0 THEN NULL
        ELSE ROUND(
            ((SELECT actual_receipts FROM work_items) / 
             (SELECT total_membership FROM monthly_membership_totals)) * 100, 
            2
        )
    END AS DEMAND_UTILIZATION_PERCENTAGE
"""


UTILIZATION_VARIANCE_QUERY = f"""
WITH input_params AS (
    SELECT 
        '{{start_date}}'::DATE AS from_date,
        '{{end_date}}'::DATE AS to_date
),
date_params AS (
    SELECT 
        YEAR(ip.from_date) AS current_year,
        MONTH(ip.from_date) AS from_month,
        YEAR(ip.to_date) AS to_year,
        MONTH(ip.to_date) AS to_month,
        YEAR(CURRENT_DATE) AS today_year,
        MONTH(CURRENT_DATE) AS today_month,
        (YEAR(ip.from_date) * 100 + MONTH(ip.from_date)) AS from_year_month,
        (YEAR(ip.to_date) * 100 + MONTH(ip.to_date)) AS to_year_month,
        (YEAR(CURRENT_DATE) * 100 + MONTH(CURRENT_DATE)) AS current_year_month,
        ip.from_date,
        ip.to_date,
        DATEADD(year, -1, ip.from_date) AS prior_from_date,
        DATEADD(year, -1, ip.to_date) AS prior_to_date,
        (YEAR(DATEADD(year, -1, ip.from_date)) * 100 + MONTH(DATEADD(year, -1, ip.from_date))) AS prior_from_year_month,
        (YEAR(DATEADD(year, -1, ip.to_date)) * 100 + MONTH(DATEADD(year, -1, ip.to_date))) AS prior_to_year_month
    FROM input_params ip
),
current_membership_data AS (
    SELECT 
        m.YEAR,
        m.MONTH,
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            END
        ) AS year_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    CROSS JOIN date_params dp
    WHERE 1=1
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            END
        ) BETWEEN dp.from_year_month AND dp.to_year_month
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            END
        ) < dp.current_year_month
        {{lob_filter}}
),
current_total_membership AS (
    SELECT SUM(ACTUAL_MEMBERSHIP) AS total_membership
    FROM current_membership_data
),
current_work_items AS (
    SELECT 
        COUNT(DISTINCT inv.PYID) AS actual_receipts
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    CROSS JOIN date_params dp
    WHERE 1=1
        AND inv.PXCREATEDATETIME >= dp.from_date
        AND inv.PXCREATEDATETIME < DATEADD(day, 1, dp.to_date)
        {{lob_filter_inv}}
        {{intake_source_filter}}
        {{market_filter}}
),
prior_membership_data AS (
    SELECT 
        m.YEAR,
        m.MONTH,
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            END
        ) AS year_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    CROSS JOIN date_params dp
    WHERE 1=1
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            END
        ) BETWEEN dp.prior_from_year_month AND dp.prior_to_year_month
        {{lob_filter}}
),
prior_total_membership AS (
    SELECT SUM(ACTUAL_MEMBERSHIP) AS total_membership
    FROM prior_membership_data
),
prior_work_items AS (
    SELECT 
        COUNT(DISTINCT inv.PYID) AS actual_receipts
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    CROSS JOIN date_params dp
    WHERE 1=1
        AND inv.PXCREATEDATETIME >= dp.prior_from_date
        AND inv.PXCREATEDATETIME < DATEADD(day, 1, dp.prior_to_date)
        {{lob_filter_inv}}
        {{intake_source_filter}}
        {{market_filter}}
),
utilization_metrics AS (
    SELECT 
        CASE 
            WHEN (SELECT total_membership FROM current_total_membership) IS NULL THEN NULL
            WHEN (SELECT total_membership FROM current_total_membership) = 0 THEN NULL
            ELSE ROUND(
                ((SELECT actual_receipts FROM current_work_items) / 
                 (SELECT total_membership FROM current_total_membership)) * 100, 
                4
            )
        END AS current_utilization,
        CASE 
            WHEN (SELECT total_membership FROM prior_total_membership) IS NULL THEN NULL
            WHEN (SELECT total_membership FROM prior_total_membership) = 0 THEN NULL
            ELSE ROUND(
                ((SELECT actual_receipts FROM prior_work_items) / 
                 (SELECT total_membership FROM prior_total_membership)) * 100, 
                4
            )
        END AS prior_utilization
)
SELECT 
    CASE 
        WHEN current_utilization IS NULL OR prior_utilization IS NULL THEN NULL
        ELSE ROUND(current_utilization - prior_utilization, 2)
    END AS UTILIZATION_VARIANCE_PERCENTAGE_POINTS
FROM utilization_metrics
"""


# =============================================================================
# Filter Building Functions
# =============================================================================

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for membership queries, mapping payload LOB values to membership table values."""
    if not lob or len(lob) == 0:
        return ""
    mapped = set()
    for l in lob:
        if l in MEMBERSHIP_LOB_MAP:
            mapped.add(MEMBERSHIP_LOB_MAP[l])
    if not mapped:
        return ""
    lob_values = "', '".join(mapped)
    return f"AND m.LOB IN ('{lob_values}')"


def build_lob_filter_inv(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for inventory table queries."""
    if not lob or len(lob) == 0:
        return ""
    null_requested = "None" in lob
    non_null_lobs = [l for l in lob if l != "None"]
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (inv.LOB IN ('{lob_values}') OR inv.LOB IS NULL)"
    elif null_requested:
        return "AND inv.LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND inv.LOB IN ('{lob_values}')"


@router.post("/membership", response_model=WorkforceIQMembershipKPIsResponse)
async def get_workforce_iq_membership(request: WorkforceIQMembershipKPIsRequest):
    """
    Get Workforce IQ Membership metrics with parallel query execution.
    
    Returns membership metrics including actual, projected, variance, and utilization.
    """
    return await execute_membership_query(request)


async def execute_membership_query(request: WorkforceIQMembershipKPIsRequest) -> WorkforceIQMembershipKPIsResponse:
    """Execute membership query logic with parallel query execution."""
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        logger.info(f"Workforce IQ Membership request: {request.model_dump()}")

        engine = connection_manager.get_engine()
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        lob_filter_inv = build_lob_filter_inv(request.lob)
        market_filter = build_market_filter(request.market)
        intake_source_filter = build_intake_source_filter(request.work_type)
        
        # Format queries
        actual_membership_query = ACTUAL_MEMBERSHIP_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter
        )
        
        projected_membership_query = PROJECTED_MEMBERSHIP_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter
        )
        
        variance_query = VARIANCE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter
        )
        
        demand_utilization_query = DEMAND_UTILIZATION_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            lob_filter_inv=lob_filter_inv,
            intake_source_filter=intake_source_filter
        )
        
        utilization_variance_query = UTILIZATION_VARIANCE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            lob_filter=lob_filter,
            lob_filter_inv=lob_filter_inv,
            intake_source_filter=intake_source_filter,
            market_filter=market_filter
        )
        
        # Define async fetch functions
        async def fetch_actual_membership():
            return await engine.execute_query_async(actual_membership_query, limit=1)
        
        async def fetch_projected_membership():
            return await engine.execute_query_async(projected_membership_query, limit=1)
        
        async def fetch_variance():
            return await engine.execute_query_async(variance_query, limit=1)
        
        async def fetch_demand_utilization():
            return await engine.execute_query_async(demand_utilization_query, limit=1)
        
        async def fetch_utilization_variance():
            return await engine.execute_query_async(utilization_variance_query, limit=1)
        
        # Execute all 5 queries in parallel
        logger.info("Executing 5 membership queries in parallel")
        (
            actual_membership_records,
            projected_membership_records,
            variance_records,
            demand_utilization_records,
            utilization_variance_records
        ) = await asyncio.gather(
            fetch_actual_membership(),
            fetch_projected_membership(),
            fetch_variance(),
            fetch_demand_utilization(),
            fetch_utilization_variance(),
            return_exceptions=False
        )
        logger.info("Parallel query execution completed")
        
        # Extract values
        actual_membership = "-"
        if actual_membership_records and actual_membership_records[0].get("ACTUAL_MEMBERSHIP_COUNT") is not None:
            value = float(actual_membership_records[0]["ACTUAL_MEMBERSHIP_COUNT"])
            # Format as millions with 1 decimal place
            actual_membership = f"{round(value / 1000000, 1)}M"
        
        projected_membership = "-"
        if projected_membership_records and projected_membership_records[0].get("PROJECTED_MEMBERSHIP_COUNT") is not None:
            value = float(projected_membership_records[0]["PROJECTED_MEMBERSHIP_COUNT"])
            # Format as millions with 1 decimal place
            projected_membership = f"{round(value / 1000000, 1)}M"
        
        variance_count = "-"
        if variance_records and variance_records[0].get("VARIANCE_COUNT") is not None:
            value = float(variance_records[0]["VARIANCE_COUNT"])
            sign = "+" if value > 0 else ""
            abs_value = abs(value)
            if abs_value >= 1_000_000:
                # Format as millions with 1 decimal place
                formatted = f"{round(value / 1_000_000, 1)}M"
            elif abs_value >= 1_000:
                # Format as thousands with 1 decimal place
                formatted = f"{round(value / 1_000, 1)}K"
            else:
                formatted = str(round(value, 1))
            variance_count = f"{sign}{formatted}" if value > 0 else formatted
        
        variance_pct = "-"
        if variance_records and variance_records[0].get("VARIANCE_PERCENTAGE") is not None:
            value = float(variance_records[0]["VARIANCE_PERCENTAGE"])
            # Format as percentage with sign
            sign = "+" if value > 0 else ""
            variance_pct = f"{sign}{round(value, 2)}%"
        
        demand_utilization = "-"
        if demand_utilization_records and demand_utilization_records[0].get("DEMAND_UTILIZATION_PERCENTAGE") is not None:
            value = float(demand_utilization_records[0]["DEMAND_UTILIZATION_PERCENTAGE"])
            # Format as percentage
            demand_utilization = f"{round(value, 2)}%"
        
        utilization_variance = "-"
        if utilization_variance_records and utilization_variance_records[0].get("UTILIZATION_VARIANCE_PERCENTAGE_POINTS") is not None:
            value = float(utilization_variance_records[0]["UTILIZATION_VARIANCE_PERCENTAGE_POINTS"])
            # Format as percentage points with sign
            sign = "+" if value > 0 else ""
            utilization_variance = f"{sign}{round(value, 2)}%"
        
        # Return response with all 6 membership metrics
        return WorkforceIQMembershipKPIsResponse(
            status="success",
            actual_membership=actual_membership,
            projected_membership=projected_membership,
            variance_count=variance_count,
            variance_pct=variance_pct,
            demand_utilization=demand_utilization,
            utilization_variance=utilization_variance,
            message="Workforce IQ Membership retrieved successfully"
        )

    except Exception as e:
        logger.error(f"Workforce IQ Membership KPIs error: {type(e).__name__}: {str(e)}")

        return WorkforceIQMembershipKPIsResponse(
            status="error",
            actual_membership="N/A",
            projected_membership="N/A",
            variance_count="N/A",
            variance_pct="N/A",
            demand_utilization="N/A",
            utilization_variance="N/A",
            message=f"Failed to retrieve Workforce IQ Membership: {str(e)}"
        )
