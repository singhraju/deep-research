import logging
import asyncio
import calendar
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
from dateutil.relativedelta import relativedelta
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from schema import (
    OutOfSLADrilldownRequest,
    OutOfSLADrilldownResponse,
    OutOfSLADrilldownRecord,
)
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])
connection_manager = SnowflakeConnectionManager()


# =============================================================================
# SQL Query Templates
# =============================================================================

OUT_OF_SLA_PAGINATED_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PRIORITY,
        inv.INTAKESOURCESYSTEM,
        inv.PXCREATEDATETIME,
        inv.COMPANYRECEIVEDDATE,
        inv.ASSIGNED_BY,
        inv.PYSTATUSWORK,
        inv.PYRESOLVEDTIMESTAMP,
        inv.EXTERNALDUEDATE,
        inv.INTERNALDUEDATE,
        COALESCE(inv.LOB, 'Unknown') as lob,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.pxupdatedatetime < DATEADD(day, 1, :period_end::DATE)
    {{lob_filter}}
    {{work_type_filter}}
)
SELECT
    inv.PYID AS work_item,
    COALESCE(inv.PRIORITY, 'N/A') AS priority,
    COALESCE(inv.INTAKESOURCESYSTEM, 'N/A') AS intake_source,
    TO_CHAR(inv.PXCREATEDATETIME, 'MM/DD/YYYY HH12:MI AM') AS create_date_time,
    TO_CHAR(inv.COMPANYRECEIVEDDATE, 'MM/DD/YYYY') AS elevance_created_date,
    COALESCE(inv.ASSIGNED_BY, 'N/A') AS assigned_by,
    COALESCE(inv.PYSTATUSWORK, 'N/A') AS pystatuswork
FROM invntry_deduped inv
WHERE inv.rn = 1
    AND (inv.PYRESOLVEDTIMESTAMP IS NULL OR inv.PYRESOLVEDTIMESTAMP > inv.EXTERNALDUEDATE)
    AND inv.EXTERNALDUEDATE IS NOT NULL
    AND inv.EXTERNALDUEDATE >= :period_start::DATE
    AND inv.EXTERNALDUEDATE < DATEADD(day, 1, :period_end::DATE)
ORDER BY inv.EXTERNALDUEDATE DESC
LIMIT {{page_size}} OFFSET {{offset}}
"""

OUT_OF_SLA_COUNT_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        inv.PYID,
        inv.PYSTATUSWORK,
        inv.PYRESOLVEDTIMESTAMP,
        inv.EXTERNALDUEDATE,
        inv.PXCREATEDATETIME,
        COALESCE(inv.LOB, 'Unknown') as lob,
        COALESCE(inv.INTAKESOURCESYSTEM, 'Unknown') AS work_type,
        ROW_NUMBER() OVER (
            PARTITION BY inv.PYID 
            ORDER BY inv.PXUPDATEDATETIME DESC NULLS LAST
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE inv.pxupdatedatetime < DATEADD(day, 1, :period_end::DATE)
        {{lob_filter}}
        {{work_type_filter}}
)
SELECT
    COUNT(DISTINCT inv.PYID) AS total_count
FROM invntry_deduped inv
WHERE inv.rn = 1
    AND (inv.PYRESOLVEDTIMESTAMP IS NULL OR inv.PYRESOLVEDTIMESTAMP > inv.EXTERNALDUEDATE)
    AND inv.EXTERNALDUEDATE IS NOT NULL
    AND inv.EXTERNALDUEDATE >= :period_start::DATE
    AND inv.EXTERNALDUEDATE < DATEADD(day, 1, :period_end::DATE)
"""


# =============================================================================
# Filter Functions
# =============================================================================

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for SQL queries."""
    if not lob or len(lob) == 0:
        return ""
    
    null_requested = "None" in lob or "Unknown" in lob
    non_null_lobs = [l for l in lob if l not in ["None", "Unknown"]]
    
    if null_requested and non_null_lobs:
        lob_values = "', '".join(non_null_lobs)
        return f"AND (inv.LOB IN ('{lob_values}') OR inv.LOB IS NULL)"
    elif null_requested:
        return "AND inv.LOB IS NULL"
    else:
        lob_values = "', '".join(non_null_lobs)
        return f"AND inv.LOB IN ('{lob_values}')"


def build_work_type_filter(work_type: Optional[List[str]] = None) -> str:
    """Build work type filter for SQL queries."""
    if not work_type or len(work_type) == 0:
        return ""
    
    null_requested = "None" in work_type or "Unknown" in work_type
    non_null_types = [wt for wt in work_type if wt not in ["None", "Unknown"]]
    
    if null_requested and non_null_types:
        work_type_values = "', '".join(non_null_types)
        return f"AND (inv.INTAKESOURCESYSTEM IN ('{work_type_values}') OR inv.INTAKESOURCESYSTEM IS NULL)"
    elif null_requested:
        return "AND inv.INTAKESOURCESYSTEM IS NULL"
    else:
        work_type_values = "', '".join(non_null_types)
        return f"AND inv.INTAKESOURCESYSTEM IN ('{work_type_values}')"


def parse_selected_date(selected_date: str, grouping_type: str = "daily") -> tuple:
    """
    Parse selected_date based on grouping_type and return (period_start, period_end) dates.
    
    Format patterns:
    - daily: 'YYYY-MM-DD' or 'M/D/YYYY' -> returns (date, date)
    - weekly: 'MM/DD/YYYY - MM/DD/YYYY' -> returns (start_date, end_date)
    - monthly: 'Mon YYYY' (e.g., 'May 2026') -> returns (first_day, last_day)
    - quarterly: 'YYYY-Q#' (e.g., '2026-Q2') -> returns (quarter_start, quarter_end)
    - yearly: 'YYYY' -> returns (jan_1, dec_31)
    """
    try:
        if grouping_type == "daily":
            # Handle both 'YYYY-MM-DD' and 'M/D/YYYY' formats
            if '-' in selected_date and selected_date.count('-') == 2:
                date_obj = datetime.strptime(selected_date, '%Y-%m-%d')
            else:
                date_obj = datetime.strptime(selected_date, '%m/%d/%Y')
            return (date_obj.strftime('%Y-%m-%d'), date_obj.strftime('%Y-%m-%d'))
        
        elif grouping_type == "weekly":
            # Format: 'MM/DD/YYYY - MM/DD/YYYY'
            if ' - ' in selected_date:
                start_str, end_str = selected_date.split(' - ')
                start_date = datetime.strptime(start_str.strip(), '%m/%d/%Y')
                end_date = datetime.strptime(end_str.strip(), '%m/%d/%Y')
                return (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
            else:
                raise ValueError(f"Invalid weekly date format: {selected_date}")
        
        elif grouping_type == "monthly":
            # Format: 'Mon YYYY' (e.g., 'May 2026')
            date_obj = datetime.strptime(selected_date, '%b %Y')
            last_day = calendar.monthrange(date_obj.year, date_obj.month)[1]
            start_date = date_obj.replace(day=1)
            end_date = date_obj.replace(day=last_day)
            return (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        elif grouping_type == "quarterly":
            # Format: 'YYYY-Q#' (e.g., '2026-Q2')
            year_str, quarter_str = selected_date.split('-Q')
            year = int(year_str)
            quarter = int(quarter_str)
            
            # Calculate quarter start and end
            start_month = (quarter - 1) * 3 + 1
            start_date = datetime(year, start_month, 1)
            end_date = start_date + relativedelta(months=3) - relativedelta(days=1)
            return (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        elif grouping_type == "yearly":
            # Format: 'YYYY'
            year = int(selected_date)
            start_date = datetime(year, 1, 1)
            end_date = datetime(year, 12, 31)
            return (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        else:
            # Default to daily if unknown grouping type
            logger.warning(f"Unknown grouping_type: {grouping_type}, defaulting to daily")
            date_obj = datetime.strptime(selected_date, '%Y-%m-%d')
            return (date_obj.strftime('%Y-%m-%d'), date_obj.strftime('%Y-%m-%d'))
    
    except Exception as e:
        logger.error(f"Error parsing selected_date '{selected_date}' with grouping_type '{grouping_type}': {str(e)}")
        raise ValueError(f"Invalid date format for selected_date: {selected_date} (grouping_type: {grouping_type})")


def format_query(query_template: str, period_start: str, period_end: str, lob_filter: str = "", work_type_filter: str = "", page_size: int = 50, offset: int = 0) -> str:
    """Format query template with filters and parameters."""
    # Format the query with filters
    query = query_template.format(
        lob_filter=lob_filter,
        work_type_filter=work_type_filter,
        page_size=page_size,
        offset=offset
    )
    # Replace parameter placeholders
    query = query.replace(":period_start", f"'{period_start}'")
    query = query.replace(":period_end", f"'{period_end}'")
    return query


@router.post(
    "/out-of-sla-drilldown",
    response_model=OutOfSLADrilldownResponse,
    summary="Get Out of SLA Drilldown",
    description="""
    Get detailed breakdown of Out of SLA work items for a specific date/period from IRP Projection table.
    
    This drilldown shows individual work items that were completed out of SLA (resolved AFTER their due date) during the selected period.
    
    **Input Parameters:**
    - **user_id** (optional): Logged-in user ID
    - **selected_date** (required): Date/period selected from IRP table. Format varies by grouping_type:
        - daily: 'YYYY-MM-DD' or 'M/D/YYYY' (e.g., '2026-05-01' or '5/1/2026')
        - weekly: 'MM/DD/YYYY - MM/DD/YYYY' (e.g., '06/01/2026 - 06/07/2026')
        - monthly: 'Mon YYYY' (e.g., 'May 2026')
        - quarterly: 'YYYY-Q#' (e.g., '2026-Q2')
        - yearly: 'YYYY' (e.g., '2026')
    - **start_date** (optional): Overall filter start date (YYYY-MM-DD) - for reference only
    - **end_date** (optional): Overall filter end date (YYYY-MM-DD) - for reference only
    - **grouping_type** (optional): Grouping type from parent table - daily, weekly, monthly, quarterly, yearly (default: daily)
    - **lob** (optional): List of Line of Business values to filter
    - **staffing_category** (optional): List of staffing categories to filter
    - **work_type** (optional): List of work types to filter
    - **page** (required): Page number for pagination (default: 1)
    - **page_size** (required): Number of records per page (default: 50, max: 1000)
    
    **Returns (Individual Work Item Records):**
    - **work_item**: Work item ID/number (PYID)
    - **priority**: Priority level (Instant, Immediate, Urgent, High, Medium, Low)
    - **intake_source**: Intake source system (INTAKESOURCESYSTEM)
    - **create_date_time**: Date and time when work item was created (PXCREATEDATETIME)
    - **elevance_created_date**: Elevance created date (COMPANYRECEIVEDDATE)
    - **assigned_by**: User currently assigned to the work item (ASSIGNED_BY)
    - **pystatuswork**: Current status of the work item
    
    **Data Source:**
    - COB_AI_INVNTRY_PROFILE table with deduplication by PYID
    
    **Note:** Returns items where PYRESOLVEDTIMESTAMP > EXTERNALDUEDATE (resolved after the due date, i.e., completed late)
    
    **Includes:**
    - Pagination information with total counts
    - Sortable and filterable columns
    """,
)
async def get_out_of_sla_drilldown(request: OutOfSLADrilldownRequest):
    """
    Get Out of SLA drilldown data with pagination.
    Queries COB_AI_INVNTRY_PROFILE for items past their due date.
    """
    try:
        logger.info(f"Out of SLA Drilldown request received: {request.dict()}")
        
        # Validate connection
        if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
        # Parse selected_date based on grouping_type
        try:
            period_start, period_end = parse_selected_date(request.selected_date, request.grouping_type or "daily")
            logger.info(f"Parsed date range from selected_date '{request.selected_date}' (grouping: {request.grouping_type}): {period_start} to {period_end}")
        except ValueError as ve:
            raise HTTPException(status_code=400, detail=str(ve))
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        
        # Get database engine
        engine = connection_manager.get_engine()
        
        # Calculate pagination offset
        offset = (request.page - 1) * request.page_size
        
        # Format queries
        data_query = format_query(
            OUT_OF_SLA_PAGINATED_QUERY, 
            period_start, 
            period_end, 
            lob_filter, 
            work_type_filter,
            request.page_size,
            offset
        )
        count_query = format_query(
            OUT_OF_SLA_COUNT_QUERY, 
            period_start, 
            period_end, 
            lob_filter, 
            work_type_filter
        )
        
        # Define async fetch functions
        async def fetch_data():
            return await engine.execute_query_async(data_query, limit=10000)
        
        async def fetch_count():
            return await engine.execute_query_async(count_query, limit=1)
        
        # Execute both queries in parallel
        logger.info("Executing Out of SLA data and count queries in parallel")
        (
            data_records,
            count_result
        ) = await asyncio.gather(
            fetch_data(),
            fetch_count(),
            return_exceptions=False
        )
        logger.info("Parallel query execution completed")
        
        # Get total count
        total_count = int(count_result[0]['TOTAL_COUNT']) if count_result and len(count_result) > 0 else 0
        
        # Convert to response records
        data_points = [OutOfSLADrilldownRecord(**{
            "work_item": str(record['WORK_ITEM']),
            "priority": str(record['PRIORITY']),
            "intake_source": str(record['INTAKE_SOURCE']),
            "create_date_time": str(record['CREATE_DATE_TIME']) if record['CREATE_DATE_TIME'] else 'N/A',
            "elevance_created_date": str(record['ELEVANCE_CREATED_DATE']) if record['ELEVANCE_CREATED_DATE'] else 'N/A',
            "assigned_by": str(record['ASSIGNED_BY']),
            "pystatuswork": str(record['PYSTATUSWORK'])
        }) for record in data_records]
        
        # Calculate pagination info
        total_pages = (total_count + request.page_size - 1) // request.page_size if total_count > 0 else 1
        
        page_info = {
            "page": request.page,
            "page_size": request.page_size,
            "total_pages": total_pages,
            "total_records": total_count,
            "has_next": request.page < total_pages,
            "has_previous": request.page > 1
        }
        
        logger.info(f"Returning {len(data_points)} Out of SLA drilldown records (page {request.page}/{total_pages})")
        
        return OutOfSLADrilldownResponse(
            status="success",
            data=data_points,
            page_info=page_info,
            total_count=total_count,
            message=f"Successfully retrieved Out of SLA drilldown for {request.selected_date}",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in Out of SLA drilldown endpoint: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve Out of SLA drilldown data: {str(e)}"
        )


@router.post(
    "/out-of-sla-drilldown/download-excel",
    summary="Download Out of SLA Drilldown as Excel",
    description="""
    Download complete Out of SLA drilldown data as an Excel file.
    
    **Input Parameters:**
    - Same as the main drilldown endpoint (without pagination parameters)
    
    **Returns:** Excel file (.xlsx) with all Out of SLA drilldown records
    """,
)
async def download_out_of_sla_drilldown_excel(request: OutOfSLADrilldownRequest) -> StreamingResponse:
    """
    Download Out of SLA drilldown data as Excel file.
    Returns all records without pagination.
    """
    try:
        logger.info(f"Out of SLA Drilldown Excel download request received: {request.dict()}")
        
        # Validate connection
        if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
        # Parse selected_date based on grouping_type
        try:
            period_start, period_end = parse_selected_date(request.selected_date, request.grouping_type or "daily")
            logger.info(f"Parsed date range from selected_date '{request.selected_date}' (grouping: {request.grouping_type}): {period_start} to {period_end}")
        except ValueError as ve:
            raise HTTPException(status_code=400, detail=str(ve))
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        
        # Get database engine
        engine = connection_manager.get_engine()
        
        # Format query (get all records without pagination)
        data_query = format_query(
            OUT_OF_SLA_PAGINATED_QUERY.replace("LIMIT {{page_size}} OFFSET {{offset}}", ""), 
            period_start, 
            period_end, 
            lob_filter, 
            work_type_filter,
            10000,  # Large limit for Excel
            0
        )
        
        # Execute query
        logger.info("Executing Out of SLA data query for Excel export")
        data_records = await engine.execute_query_async(data_query, limit=10000)
        logger.info("Query execution completed")
        
        # Convert to list of dicts
        all_records = [{
            "work_item": str(record['WORK_ITEM']),
            "priority": str(record['PRIORITY']),
            "intake_source": str(record['INTAKE_SOURCE']),
            "create_date_time": str(record['CREATE_DATE_TIME']) if record['CREATE_DATE_TIME'] else 'N/A',
            "elevance_created_date": str(record['ELEVANCE_CREATED_DATE']) if record['ELEVANCE_CREATED_DATE'] else 'N/A',
            "assigned_by": str(record['ASSIGNED_BY']),
            "pystatuswork": str(record['PYSTATUSWORK'])
        } for record in data_records]
        
        # Create Excel workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Out of SLA Drilldown"
        
        # Style for header
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        # Headers
        headers = [
            "Work Item",
            "Priority",
            "Intake Source",
            "Create Date Time",
            "Elevance Created Date",
            "Assigned By",
            "PYSTATUSWORK"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        for row_num, record in enumerate(all_records, start=2):
            ws.cell(row=row_num, column=1, value=str(record["work_item"]))
            ws.cell(row=row_num, column=2, value=str(record["priority"]))
            ws.cell(row=row_num, column=3, value=str(record["intake_source"]))
            ws.cell(row=row_num, column=4, value=str(record["create_date_time"]))
            ws.cell(row=row_num, column=5, value=str(record["elevance_created_date"]))
            ws.cell(row=row_num, column=6, value=str(record["assigned_by"]))
            ws.cell(row=row_num, column=7, value=str(record["pystatuswork"]))
        
        # Auto-adjust column widths
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # Save to BytesIO
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        # Generate filename
        filename = f"out_of_sla_drilldown_{request.selected_date.replace('/', '-')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        
        logger.info(f"Generated Out of SLA drilldown Excel file: {filename}")
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except Exception as e:
        logger.error(f"Error generating Out of SLA drilldown Excel: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate Excel file: {str(e)}"
        )
