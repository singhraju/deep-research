"""
Staffing Core API Endpoints for Workforce IQ
Provides FTE metrics and staffing analysis
"""

from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any
import logging
import asyncio

from schema.workforce_iq_models import (
    StaffingCoreRequest,
    StaffingCoreResponse,
    StaffingCoreDataPoint
)
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
import config

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()


# =============================================================================
# SQL QUERY PLACEHOLDERS
# =============================================================================

REQ_FTE_QUERY = f"""
WITH grouping_config AS (
    SELECT '{{grouping_level}}' AS grouping_level
),
date_range_config AS (
    SELECT '{{start_date}}'::DATE AS period_start, '{{end_date}}'::DATE AS period_end
),
date_spine AS (
    SELECT DATEADD(DAY, SEQ4(), (SELECT period_start FROM date_range_config)) AS spine_date
    FROM TABLE(GENERATOR(ROWCOUNT => 10000))
    WHERE DATEADD(DAY, SEQ4(), (SELECT period_start FROM date_range_config)) <= (SELECT period_end FROM date_range_config)
),
holidays AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),
all_dates_in_range AS (
    SELECT DATEADD(DAY, seq.seq, (SELECT period_start FROM date_range_config)) AS calendar_date
    FROM (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq FROM TABLE(GENERATOR(ROWCOUNT => 10000))) seq
    WHERE DATEADD(DAY, seq.seq, (SELECT period_start FROM date_range_config)) <= (SELECT period_end FROM date_range_config)
),
date_periods AS (
    SELECT DISTINCT
        CASE (SELECT grouping_level FROM grouping_config)
            WHEN 'daily' THEN spine_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', spine_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', spine_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', spine_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', spine_date)
        END AS period_date,
        EXTRACT(YEAR FROM spine_date) AS period_year,
        EXTRACT(MONTH FROM spine_date) AS period_month
    FROM date_spine
),
working_days_per_period AS (
    SELECT DISTINCT
        CASE (SELECT grouping_level FROM grouping_config)
            WHEN 'daily' THEN ad.calendar_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', ad.calendar_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', ad.calendar_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', ad.calendar_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', ad.calendar_date)
        END AS period_date,
        CASE (SELECT grouping_level FROM grouping_config)
            WHEN 'daily' THEN 1
            ELSE (
                SELECT COUNT(DISTINCT ad2.calendar_date)
                FROM all_dates_in_range ad2
                LEFT JOIN holidays h ON h.holiday_date = ad2.calendar_date
                WHERE DAYOFWEEK(ad2.calendar_date) NOT IN (0, 6)
                  AND h.holiday_date IS NULL
                  AND CASE (SELECT grouping_level FROM grouping_config)
                      WHEN 'weekly' THEN DATE_TRUNC('WEEK', ad2.calendar_date) = DATE_TRUNC('WEEK', ad.calendar_date)
                      WHEN 'monthly' THEN DATE_TRUNC('MONTH', ad2.calendar_date) = DATE_TRUNC('MONTH', ad.calendar_date)
                      WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', ad2.calendar_date) = DATE_TRUNC('QUARTER', ad.calendar_date)
                      WHEN 'yearly' THEN DATE_TRUNC('YEAR', ad2.calendar_date) = DATE_TRUNC('YEAR', ad.calendar_date)
                  END
            )
        END AS working_days
    FROM all_dates_in_range ad
),
period_grid AS (
    SELECT dp.period_date, dp.period_year, dp.period_month,
        CASE WHEN dp.period_date < CURRENT_DATE() THEN 'PAST'
             WHEN dp.period_date = CURRENT_DATE() THEN 'CURRENT'
             ELSE 'FUTURE' END AS date_category
    FROM date_periods dp
),
productive_hrs AS (
    SELECT ROUND(AVG(
        SPLIT_PART(u.PRODUCTIVETIME, ':', 1)::FLOAT + SPLIT_PART(u.PRODUCTIVETIME, ':', 2)::FLOAT / 60.0 + SPLIT_PART(u.PRODUCTIVETIME, ':', 3)::FLOAT / 3600.0
    ), 2) AS avg_productive_hrs_per_day
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_USER_PROFILE u
    WHERE UPPER(u.PYACCESSGROUP) LIKE '%FRONTLINE%' AND u.PRODUCTIVETIME IS NOT NULL
      AND CASE
          WHEN (SELECT period_end FROM date_range_config) < CURRENT_DATE() THEN
              u.LOGINDATE >= DATEADD(DAY, -90, (SELECT period_end FROM date_range_config))
              AND u.LOGINDATE <= (SELECT period_end FROM date_range_config)
          ELSE
              u.LOGINDATE >= DATEADD(DAY, -90, CURRENT_DATE())
              AND u.LOGINDATE <= CURRENT_DATE()
      END
),
cy_deduped AS (
    SELECT inv.PYID, inv.INTAKESOURCESYSTEM, inv.CYCLE_TIME, inv.PYSTATUSWORK,
        inv.MARKET, inv.FUNDINGMODEL, inv.PXCREATEDATETIME,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        DATE_TRUNC('WEEK', inv.PXCREATEDATETIME) AS week_start,
        DATE_TRUNC('MONTH', inv.PXCREATEDATETIME) AS month_start,
        DATE_TRUNC('QUARTER', inv.PXCREATEDATETIME) AS quarter_start,
        DATE_TRUNC('YEAR', inv.PXCREATEDATETIME) AS year_start,
        EXTRACT(YEAR FROM inv.PXCREATEDATETIME) AS receipt_year,
        EXTRACT(MONTH FROM inv.PXCREATEDATETIME) AS receipt_month,
        UPPER(TRIM(inv.LOB)) AS LOB,
        inv.REPORTTOMANAGERID
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY PXCOMMITDATETIME DESC NULLS LAST, insrt_dt_time DESC) = 1
),
py_deduped AS (
    SELECT inv.PYID, inv.INTAKESOURCESYSTEM, inv.CYCLE_TIME, inv.PYSTATUSWORK,
        inv.MARKET, inv.FUNDINGMODEL, inv.PXCREATEDATETIME,
        DATE(inv.PXCREATEDATETIME) AS create_date,
        DATE_TRUNC('WEEK', inv.PXCREATEDATETIME) AS week_start,
        DATE_TRUNC('MONTH', inv.PXCREATEDATETIME) AS month_start,
        DATE_TRUNC('QUARTER', inv.PXCREATEDATETIME) AS quarter_start,
        DATE_TRUNC('YEAR', inv.PXCREATEDATETIME) AS year_start,
        UPPER(TRIM(inv.LOB)) AS LOB,
        inv.REPORTTOMANAGERID
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_INVNTRY_PROFILE inv
    QUALIFY ROW_NUMBER() OVER (PARTITION BY inv.PYID ORDER BY inv.PXCOMMITDATETIME DESC NULLS LAST, inv.insrt_dt_time DESC) = 1
),
avg_cycle_time_actual AS (
    SELECT COALESCE(INTAKESOURCESYSTEM, 'None') AS intakesourcesystem,
        ROUND(AVG(CYCLE_TIME) / 60.0, 2) AS avg_cycle_time_min
    FROM cy_deduped WHERE CYCLE_TIME IS NOT NULL
    GROUP BY COALESCE(INTAKESOURCESYSTEM, 'None')
),
avg_cycle_time_last90 AS (
    SELECT COALESCE(inv.INTAKESOURCESYSTEM, 'None') AS intakesourcesystem,
        ROUND(AVG(inv.CYCLE_TIME) / 60.0, 2) AS avg_cycle_time_min
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_INVNTRY_PROFILE inv
    LEFT JOIN {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
        ON TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(inv.INTAKESOURCESYSTEM))
    WHERE inv.CYCLE_TIME IS NOT NULL
      AND inv.PYSTATUSWORK in ('Resolved-Completed')
      AND CASE
          WHEN (SELECT period_end FROM date_range_config) < CURRENT_DATE() THEN
              inv.PYRESOLVEDTIMESTAMP >= DATEADD(DAY, -90, (SELECT period_end FROM date_range_config))
              AND inv.PYRESOLVEDTIMESTAMP < DATEADD(DAY, 1, (SELECT period_end FROM date_range_config))
          ELSE
              inv.PYRESOLVEDTIMESTAMP >= DATEADD(DAY, -90, CURRENT_DATE())
              AND inv.PYRESOLVEDTIMESTAMP < DATEADD(DAY, 1, CURRENT_DATE())
      END
      {{lob_filter}} {{staffing_filter_xwalk}} {{work_type_filter}}
    GROUP BY COALESCE(inv.INTAKESOURCESYSTEM, 'None')
),
cy_aggregated AS (
    SELECT
        (SELECT grouping_level FROM grouping_config) AS grouping_level,
        CASE
            WHEN (SELECT grouping_level FROM grouping_config) = 'daily' THEN cy.create_date
            WHEN (SELECT grouping_level FROM grouping_config) = 'weekly' THEN cy.week_start
            WHEN (SELECT grouping_level FROM grouping_config) = 'monthly' THEN cy.month_start
            WHEN (SELECT grouping_level FROM grouping_config) = 'quarterly' THEN cy.quarter_start
            WHEN (SELECT grouping_level FROM grouping_config) = 'yearly' THEN cy.year_start
        END AS period_date,
        COUNT(DISTINCT cy.PYID) AS current_year_actual_receipts
    FROM cy_deduped cy
    WHERE cy.PXCREATEDATETIME >= (SELECT period_start FROM date_range_config)
      AND cy.PXCREATEDATETIME < DATEADD(DAY, 1, (SELECT period_end FROM date_range_config))
      AND DATE(cy.PXCREATEDATETIME) <= (SELECT period_end FROM date_range_config)
      AND (cy.PYSTATUSWORK IN ('Resolved-Completed','Resolved-DupClose','Resolved-BulkAutoClose','New','Pend-Decision','Resolved-AutoCloseLink','Open-ReviewIntake','Pend','Open-AuditReview','Open-CAQHPortal'))
      {{lob_filter_cy}}
      {{work_type_filter_cy}}
     {{manager_filter_cy}}
      {{market_filter_cy}}
    --   {{funding_model_filter_cy}}
      {{staffing_filter_cy_exists}}
    GROUP BY 1, 2
),
py_aggregated AS (
    SELECT
        (SELECT grouping_level FROM grouping_config) AS grouping_level,
        CASE
            WHEN (SELECT grouping_level FROM grouping_config) = 'daily' THEN 
                -- Map to next day (same weekday) in current year, accounting for leap years
                -- If previous year (py year) is leap year OR current year (py+1) is leap year, go back 2 days
                -- Otherwise go back 1 day (standard 364 days back)
                CASE
                    WHEN (MOD(YEAR(py.create_date), 4) = 0 AND (MOD(YEAR(py.create_date), 100) != 0 OR MOD(YEAR(py.create_date), 400) = 0))
                         OR (MOD(YEAR(py.create_date) + 1, 4) = 0 AND (MOD(YEAR(py.create_date) + 1, 100) != 0 OR MOD(YEAR(py.create_date) + 1, 400) = 0))
                    THEN DATEADD(DAY, -2, DATEADD(YEAR, 1, py.create_date))
                    ELSE DATEADD(DAY, -1, DATEADD(YEAR, 1, py.create_date))
                END
            WHEN (SELECT grouping_level FROM grouping_config) = 'weekly' THEN DATE_TRUNC('WEEK', DATEADD(YEAR, 1, py.create_date))
            WHEN (SELECT grouping_level FROM grouping_config) = 'monthly' THEN DATEADD(YEAR, 1, py.month_start)
            WHEN (SELECT grouping_level FROM grouping_config) = 'quarterly' THEN DATEADD(YEAR, 1, py.quarter_start)
            WHEN (SELECT grouping_level FROM grouping_config) = 'yearly' THEN DATEADD(YEAR, 1, py.year_start)
        END AS period_date,
        COUNT(DISTINCT py.PYID) AS prior_year_actual_receipts
    FROM py_deduped py
    WHERE py.PXCREATEDATETIME >= DATEADD(DAY, 1, DATEADD(YEAR, -1, (SELECT period_start FROM date_range_config)))
      AND py.PXCREATEDATETIME < DATEADD(DAY, 2, DATEADD(YEAR, -1, (SELECT period_end FROM date_range_config)))
      AND (py.PYSTATUSWORK IN ('Resolved-Completed','Resolved-DupClose','Resolved-BulkAutoClose','New','Pend-Decision','Resolved-AutoCloseLink','Open-ReviewIntake','Pend','Open-AuditReview','Open-CAQHPortal'))
      {{lob_filter_py}}
      {{work_type_filter_py}}
      {{manager_filter_py}}
      {{market_filter_py}}
    --   {{funding_model_filter_py}}
      {{staffing_filter_py_exists}}
    GROUP BY 1, 2
),
month_mapping AS (
    SELECT 'January' AS month_name, 1 AS month_num UNION ALL SELECT 'February', 2 UNION ALL
    SELECT 'March', 3 UNION ALL SELECT 'April', 4 UNION ALL SELECT 'May', 5 UNION ALL
    SELECT 'June', 6 UNION ALL SELECT 'July', 7 UNION ALL SELECT 'August', 8 UNION ALL
    SELECT 'September', 9 UNION ALL SELECT 'October', 10 UNION ALL SELECT 'November', 11 UNION ALL
    SELECT 'December', 12
),
membership_data AS (
    SELECT md.YEAR AS membership_year, mm.month_num AS membership_month,
        CASE UPPER(TRIM(md.LOB))
            WHEN 'GB CAID' THEN 'MEDICAID' WHEN 'GB CARE' THEN 'MEDICARE'
            WHEN 'CSBD' THEN 'COMMERCIAL' ELSE 'GBD' END AS LOB,
        md.PROJECTED_MEMBERSHIP, md.ACTUAL_MEMBERSHIP
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_MEMBERSHIP_DATA md
    INNER JOIN month_mapping mm ON md.MONTH = mm.month_name
    WHERE md.YEAR IS NOT NULL AND md.MONTH IS NOT NULL
        {{lob_filter_membership}}
),
prior_year_membership AS (
    SELECT
        md.LOB,
        md.ACTUAL_MEMBERSHIP,
        DATE_FROM_PARTS(md.membership_year, md.membership_month, 1) AS month_start_date
    FROM membership_data md
    WHERE md.membership_year BETWEEN YEAR(DATEADD(YEAR, -1, (SELECT period_start FROM date_range_config))) 
        AND YEAR(DATEADD(YEAR, -1, (SELECT period_end FROM date_range_config)))
),
py_membership_agg AS (
    SELECT
        pm.month_start_date,
        SUM(pm.ACTUAL_MEMBERSHIP) AS prior_year_actual_membership
    FROM prior_year_membership pm
    GROUP BY pm.month_start_date
),
current_year_membership AS (
    SELECT
        md.LOB,
        md.PROJECTED_MEMBERSHIP,
        DATE_FROM_PARTS(md.membership_year, md.membership_month, 1) AS month_start_date
    FROM membership_data md
    WHERE md.membership_year BETWEEN YEAR((SELECT period_start FROM date_range_config)) 
        AND YEAR((SELECT period_end FROM date_range_config))
),
cy_membership_agg AS (
    SELECT
        cm.month_start_date,
        SUM(cm.PROJECTED_MEMBERSHIP) AS current_year_projected_membership
    FROM current_year_membership cm
    GROUP BY cm.month_start_date
),
all_periods AS (
    SELECT DISTINCT
        (SELECT grouping_level FROM grouping_config) AS grouping_level,
        g.period_date,
        g.date_category
    FROM period_grid g
),
projected_receipts_calc AS (
    SELECT
        ap.period_date,
        ap.date_category,
        ROUND(
            COALESCE(py.prior_year_actual_receipts, 0) / 
            NULLIF(CASE
                WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN pm_monthly.prior_year_actual_membership
                WHEN ap.grouping_level = 'quarterly' THEN (
                    SELECT SUM(pma.prior_year_actual_membership) / 3
                    FROM py_membership_agg pma
                    WHERE pma.month_start_date >= DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date))
                      AND pma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', DATEADD(YEAR, -1, ap.period_date)))
                )
                WHEN ap.grouping_level = 'yearly' THEN (
                    SELECT SUM(pma.prior_year_actual_membership) / 12
                    FROM py_membership_agg pma
                    WHERE YEAR(pma.month_start_date) = YEAR(ap.period_date) - 1
                )
            END, 0) *
            CASE
                WHEN ap.grouping_level IN ('daily', 'weekly', 'monthly') THEN cm_monthly.current_year_projected_membership
                WHEN ap.grouping_level = 'quarterly' THEN (
                    SELECT SUM(cma.current_year_projected_membership) / 3
                    FROM cy_membership_agg cma
                    WHERE cma.month_start_date >= DATE_TRUNC('QUARTER', ap.period_date)
                      AND cma.month_start_date < DATEADD(MONTH, 3, DATE_TRUNC('QUARTER', ap.period_date))
                )
                WHEN ap.grouping_level = 'yearly' THEN (
                    SELECT SUM(cma.current_year_projected_membership) / 12
                    FROM cy_membership_agg cma
                    WHERE YEAR(cma.month_start_date) = YEAR(ap.period_date)
                )
            END
        , 0) AS projected_receipts
    FROM all_periods ap
    LEFT JOIN cy_aggregated cy ON ap.period_date = cy.period_date
    LEFT JOIN py_aggregated py ON ap.period_date = py.period_date
    LEFT JOIN py_membership_agg pm_monthly ON DATE_TRUNC('MONTH', DATEADD(YEAR, -1, ap.period_date)) = pm_monthly.month_start_date
    LEFT JOIN cy_membership_agg cm_monthly ON DATE_TRUNC('MONTH', ap.period_date) = cm_monthly.month_start_date
),
avg_cycle_time_overall AS (
    SELECT COALESCE(ROUND(AVG(avg_cycle_time_min), 2), 0) AS overall_avg_cycle_time_min
    FROM avg_cycle_time_last90
),
fte_calculation AS (
    SELECT 
        prc.period_date,
        prc.projected_receipts,
        COALESCE(ct.overall_avg_cycle_time_min, 0) AS cycle_time_in_min,
        prc.projected_receipts * COALESCE(ct.overall_avg_cycle_time_min, 0) AS total_minutes
    FROM projected_receipts_calc prc
    CROSS JOIN avg_cycle_time_overall ct
),
fte_summary AS (
    SELECT 
        fc.period_date, 
        SUM(fc.projected_receipts) AS total_projected_receipts,
        MAX(fc.cycle_time_in_min) AS avg_cycle_time_min,
        ROUND(SUM(fc.total_minutes) / 60.0, 2) AS total_work_hr_required,
        (SELECT avg_productive_hrs_per_day FROM productive_hrs) AS daily_productive_hrs,
        COALESCE(wd.working_days, 1) AS working_days,
        CEIL(SUM(fc.total_minutes) / 60.0 / NULLIF(
            (SELECT avg_productive_hrs_per_day FROM productive_hrs) * COALESCE(wd.working_days, 1)
        , 0)) AS required_fte
    FROM fte_calculation fc
    LEFT JOIN working_days_per_period wd ON fc.period_date = wd.period_date
    GROUP BY fc.period_date, wd.working_days
)
SELECT '{{grouping_level}}' AS GROUPING_LEVEL,
    s.period_date AS PERIOD_DATE,
    CASE (SELECT grouping_level FROM grouping_config)
        WHEN 'daily' THEN TO_CHAR(s.period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_CHAR(s.period_date, 'YYYY-MM-DD')
        WHEN 'monthly' THEN TO_CHAR(s.period_date, 'MM/YYYY')
        WHEN 'quarterly' THEN TO_CHAR(s.period_date, 'YYYY') || '-Q' || QUARTER(s.period_date)
        WHEN 'yearly' THEN TO_CHAR(s.period_date, 'YYYY')
    END AS PERIOD_LABEL,
    CASE 
        WHEN (SELECT grouping_level FROM grouping_config) = 'daily' AND DAYOFWEEK(s.period_date) IN (0, 6) THEN 0
        ELSE s.total_projected_receipts
    END AS PROJECTED_RECEIPTS,
    s.avg_cycle_time_min AS AVG_CYCLE_TIME_MIN,
    CASE 
        WHEN (SELECT grouping_level FROM grouping_config) = 'daily' AND DAYOFWEEK(s.period_date) IN (0, 6) THEN 0
        ELSE s.total_work_hr_required
    END AS TOTAL_WORK_HOURS_REQUIRED,
    s.daily_productive_hrs AS DAILY_PRODUCTIVE_HOURS,
    CASE 
        WHEN (SELECT grouping_level FROM grouping_config) = 'daily' AND DAYOFWEEK(s.period_date) IN (0, 6) THEN 0
        ELSE s.required_fte
    END AS REQ_FTE
FROM fte_summary s
ORDER BY s.period_date
"""

AVAIL_FTE_QUERY = f"""
WITH config AS (
    SELECT '{{start_date}}'::DATE AS date_from, '{{end_date}}'::DATE AS date_to, '{{grouping_level}}' AS grouping_level
),
date_range AS (
    SELECT
        date_from,
        date_to,
        grouping_level,
        CASE WHEN date_from > CURRENT_DATE() THEN TRUE ELSE FALSE END AS is_future_only
    FROM config
),
user_staffing_cat AS (
    SELECT
        up.USERID,
        xw.STAFFING_CATEGORY AS STAFFING_CATEGORY,
        ROW_NUMBER() OVER (PARTITION BY up.USERID ORDER BY up.logindate DESC NULLS LAST) AS rn
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_USER_PROFILE up
    LEFT JOIN {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_STAFFING_CATEGORY_XWALK xw
        ON TRIM(up.STAFFINGCATEGORY) = TRIM(xw.STAFFING_CATEGORY)
    WHERE up.USERID IS NOT NULL
),
-- Historical available FTE (past and current)
historical_avail AS (
    SELECT DISTINCT w.EMPLOYEE_DOMAIN_ID AS userid, w.MANAGER_DOMAIN_ID AS manager_id,
        TRY_CAST(w.ASOFTODAY AS DATE) AS snapshot_date,
        DATE_TRUNC('WEEK', TRY_CAST(w.ASOFTODAY AS DATE)) AS week_start,
        DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE)) AS month_start,
        DATE_TRUNC('QUARTER', TRY_CAST(w.ASOFTODAY AS DATE)) AS quarter_start,
        DATE_TRUNC('YEAR', TRY_CAST(w.ASOFTODAY AS DATE)) AS year_start,
        COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_WORKDAY_HIST w
    LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) <= CURRENT_DATE()
      AND DAYOFWEEK(TRY_CAST(w.ASOFTODAY AS DATE)) NOT IN (0, 6)
      {{manager_filter}}
      {{staffing_category_filter}}
),
-- Historical average calculation based on grouping level
historical_avg AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN (
                SELECT avail_count FROM (
                    SELECT snapshot_date, COUNT(DISTINCT userid) AS avail_count
                    FROM historical_avail
                    WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
                    GROUP BY snapshot_date
                    ORDER BY snapshot_date DESC
                    LIMIT 1
                )
            )
            WHEN 'weekly' THEN (
                -- Use last working day's actual FTE instead of last week's average
                SELECT avail_count FROM (
                    SELECT snapshot_date, COUNT(DISTINCT userid) AS avail_count
                    FROM historical_avail
                    WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
                    GROUP BY snapshot_date
                    ORDER BY snapshot_date DESC
                    LIMIT 1
                )
            )
            WHEN 'monthly' THEN (
                -- Use last working day's actual FTE instead of last month's average
                SELECT avail_count FROM (
                    SELECT snapshot_date, COUNT(DISTINCT userid) AS avail_count
                    FROM historical_avail
                    WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
                    GROUP BY snapshot_date
                    ORDER BY snapshot_date DESC
                    LIMIT 1
                )
            )
            WHEN 'quarterly' THEN (
                -- Use last working day's actual FTE instead of last quarter's average
                SELECT avail_count FROM (
                    SELECT snapshot_date, COUNT(DISTINCT userid) AS avail_count
                    FROM historical_avail
                    WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
                    GROUP BY snapshot_date
                    ORDER BY snapshot_date DESC
                    LIMIT 1
                )
            )
            WHEN 'yearly' THEN (
                -- Use last working day's actual FTE instead of last year's average
                SELECT avail_count FROM (
                    SELECT snapshot_date, COUNT(DISTINCT userid) AS avail_count
                    FROM historical_avail
                    WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
                    GROUP BY snapshot_date
                    ORDER BY snapshot_date DESC
                    LIMIT 1
                )
            )
        END AS avg_historical_fte
),
-- Onboard count from open positions table
onboard_data AS (
    SELECT
        TRY_CAST(op.FUTURE_START_DATE AS DATE) AS start_date,
        DATE_TRUNC('WEEK', TRY_CAST(op.FUTURE_START_DATE AS DATE)) AS week_start,
        DATE_TRUNC('MONTH', TRY_CAST(op.FUTURE_START_DATE AS DATE)) AS month_start,
        DATE_TRUNC('QUARTER', TRY_CAST(op.FUTURE_START_DATE AS DATE)) AS quarter_start,
        DATE_TRUNC('YEAR', TRY_CAST(op.FUTURE_START_DATE AS DATE)) AS year_start,
        op.ONBOARDING_COUNT,
        COALESCE(UPPER(TRIM(op.LOB)), 'NONE') AS LOB
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_OPEN_POSITIONS op
    WHERE TRY_CAST(op.FUTURE_START_DATE AS DATE) IS NOT NULL
        {{lob_filter_onboard}}
),
onboard_by_period AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN start_date
            WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start
            WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start
        END AS period_date,
        start_date AS onboard_complete_date,
        SUM(ONBOARDING_COUNT) AS onboard_fte
    FROM onboard_data
    WHERE start_date >= CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN DATEADD(DAY, -15, (SELECT MAX(snapshot_date) FROM historical_avail WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)))
        WHEN 'weekly' THEN DATEADD(WEEK, -1, DATE_TRUNC('WEEK', CURRENT_DATE()))
        WHEN 'monthly' THEN DATEADD(MONTH, -1, DATE_TRUNC('MONTH', CURRENT_DATE()))
        WHEN 'quarterly' THEN DATEADD(QUARTER, -1, DATE_TRUNC('QUARTER', CURRENT_DATE()))
        WHEN 'yearly' THEN DATEADD(YEAR, -1, DATE_TRUNC('YEAR', CURRENT_DATE()))
    END
    GROUP BY period_date, start_date
),
-- Group historical data
historical_grouped AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN snapshot_date WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start END AS period_date,
        COUNT(DISTINCT userid) AS AVAIL_FTE
    FROM historical_avail
    WHERE snapshot_date BETWEEN (SELECT date_from FROM date_range) AND LEAST((SELECT date_to FROM date_range), CURRENT_DATE())
      AND CASE (SELECT grouping_level FROM config)
          WHEN 'daily' THEN snapshot_date < CURRENT_DATE()
          WHEN 'weekly' THEN week_start < DATE_TRUNC('WEEK', CURRENT_DATE())
          WHEN 'monthly' THEN month_start < DATE_TRUNC('MONTH', CURRENT_DATE())
          WHEN 'quarterly' THEN quarter_start < DATE_TRUNC('QUARTER', CURRENT_DATE())
          WHEN 'yearly' THEN year_start < DATE_TRUNC('YEAR', CURRENT_DATE())
      END
    GROUP BY period_date
),
-- Generate future periods
future_periods AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN DATEADD(DAY, SEQ4(), GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', DATEADD(WEEK, SEQ4(), DATE_TRUNC('WEEK', GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))))
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', DATEADD(MONTH, SEQ4(), DATE_TRUNC('MONTH', GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))))
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', DATEADD(QUARTER, SEQ4(), DATE_TRUNC('QUARTER', GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))))
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', DATEADD(YEAR, SEQ4(), DATE_TRUNC('YEAR', GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))))
        END AS period_date
    FROM TABLE(GENERATOR(ROWCOUNT => 1000000))
    WHERE period_date <= (SELECT date_to FROM date_range)
      AND period_date >= CASE (SELECT grouping_level FROM config)
          WHEN 'daily' THEN GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range))
          WHEN 'weekly' THEN DATE_TRUNC('WEEK', GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))
          WHEN 'monthly' THEN DATE_TRUNC('MONTH', GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))
          WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))
          WHEN 'yearly' THEN DATE_TRUNC('YEAR', GREATEST(CURRENT_DATE(), (SELECT date_from FROM date_range)))
      END
),
-- Future FTE = historical average + onboard count for that period (NULL for weekends in daily grouping)
-- Only include onboarding that happens AFTER current date to avoid double-counting
future_grouped AS (
    SELECT
        fp.period_date,
        CASE
            WHEN (SELECT grouping_level FROM config) = 'daily' AND DAYOFWEEK(fp.period_date) IN (0, 6) THEN NULL
            ELSE ROUND(COALESCE((SELECT avg_historical_fte FROM historical_avg), 0)
                 + COALESCE((SELECT SUM(onboard_fte) FROM onboard_by_period 
                     WHERE onboard_complete_date > CURRENT_DATE()
                     AND onboard_complete_date <=
                     CASE (SELECT grouping_level FROM config)
                         WHEN 'daily' THEN fp.period_date
                         WHEN 'weekly' THEN DATEADD(DAY, 6, fp.period_date)
                         WHEN 'monthly' THEN DATEADD(DAY, -1, DATEADD(MONTH, 1, fp.period_date))
                         WHEN 'quarterly' THEN DATEADD(DAY, -1, DATEADD(QUARTER, 1, fp.period_date))
                         WHEN 'yearly' THEN DATEADD(DAY, -1, DATEADD(YEAR, 1, fp.period_date))
                     END
                 ), 0), 0)
        END AS AVAIL_FTE
    FROM future_periods fp
),
-- Combine historical and future
combined AS (
    SELECT period_date, AVAIL_FTE FROM historical_grouped
    UNION ALL
    SELECT period_date, AVAIL_FTE FROM future_grouped
)
SELECT '{{grouping_level}}' AS GROUPING_LEVEL,
    period_date AS PERIOD_DATE,
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN TO_CHAR(period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_CHAR(period_date, 'YYYY-MM-DD')
        WHEN 'monthly' THEN TO_CHAR(period_date, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_CHAR(period_date, 'YYYY') || '-Q' || QUARTER(period_date)
        WHEN 'yearly' THEN TO_CHAR(period_date, 'YYYY')
    END AS PERIOD_LABEL,
    AVAIL_FTE
FROM combined
ORDER BY period_date
"""

ACTUAL_FTE_QUERY = f"""
WITH config AS (
    SELECT
        '{{start_date}}'::DATE AS date_from,
        '{{end_date}}'::DATE AS date_to,
        '{{grouping_level}}' AS grouping_level
),
effective_range AS (
    SELECT
        date_from,
        LEAST(date_to, CURRENT_DATE()) AS date_to,
        grouping_level,
        CASE WHEN date_from > CURRENT_DATE() THEN TRUE ELSE FALSE END AS is_future
    FROM config
),
user_staffing_cat AS (
    SELECT
        up.USERID,
        xw.STAFFING_CATEGORY AS STAFFING_CATEGORY,
        ROW_NUMBER() OVER (PARTITION BY up.USERID ORDER BY up.logindate DESC NULLS LAST) AS rn
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_USER_PROFILE up
    LEFT JOIN {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_STAFFING_CATEGORY_XWALK xw
        ON TRIM(up.STAFFINGCATEGORY) = TRIM(xw.STAFFING_CATEGORY)
    WHERE up.USERID IS NOT NULL
),
total_head AS (
    SELECT DISTINCT
        TRY_CAST(w.ASOFTODAY AS DATE) AS snapshot_date,
        DATE_TRUNC('WEEK', TRY_CAST(w.ASOFTODAY AS DATE)) AS week_start,
        DATE_TRUNC('MONTH', TRY_CAST(w.ASOFTODAY AS DATE)) AS month_start,
        DATE_TRUNC('QUARTER', TRY_CAST(w.ASOFTODAY AS DATE)) AS quarter_start,
        DATE_TRUNC('YEAR', TRY_CAST(w.ASOFTODAY AS DATE)) AS year_start,
        w.EMPLOYEE_DOMAIN_ID AS userid,
        w.MANAGER_DOMAIN_ID AS manager_id,
        COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_WORKDAY_HIST w
    LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
      AND (SELECT is_future FROM effective_range) = FALSE
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) BETWEEN (SELECT date_from FROM effective_range) AND (SELECT date_to FROM effective_range)
      AND DAYOFWEEK(TRY_CAST(w.ASOFTODAY AS DATE)) NOT IN (0, 6)
      {{manager_filter}}
      {{staffing_category_filter}}
),
time_off AS (
    SELECT userid, manager_id, time_off_date, week_start, month_start, quarter_start, year_start, hours_off, STAFFING_CATEGORY
    FROM (
        SELECT
            w.EMPLOYEE_DOMAIN_ID AS userid,
            w.MANAGER_DOMAIN_ID AS manager_id,
            TRY_CAST(w.TIME_OFF_DATE AS DATE) AS time_off_date,
            DATE_TRUNC('WEEK', TRY_CAST(w.TIME_OFF_DATE AS DATE)) AS week_start,
            DATE_TRUNC('MONTH', TRY_CAST(w.TIME_OFF_DATE AS DATE)) AS month_start,
            DATE_TRUNC('QUARTER', TRY_CAST(w.TIME_OFF_DATE AS DATE)) AS quarter_start,
            DATE_TRUNC('YEAR', TRY_CAST(w.TIME_OFF_DATE AS DATE)) AS year_start,
            TRY_CAST(w.HOURS AS FLOAT) AS hours_off,
            COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY,
            ROW_NUMBER() OVER (
                PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.TIME_OFF_DATE AS DATE), w.TIME_OFF_TYPE, w.HOURS
                ORDER BY w.EMPLOYEE_DOMAIN_ID
            ) AS rn
        FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_WORKDAY_HIST w
        LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
        WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
          AND w.STATUS IN ('Approved', 'Submitted')
          AND w.TIME_OFF_TYPE IN (
              -- Scheduled PTO
              'Paid Time Off - Approved/Scheduled',
              'Paid Time Off',
              'Paid Time Off - Supplemental',
              
              -- Unscheduled PTO
              'Paid Time Off - Unapproved/Unscheduled',
              
              -- Sick Time (all types that reduce available capacity)
              'Sick Time',
              'Sick Time - Approved',
              'Sick Time - Unapproved',
              'Sick Time - Supplemental',
              'Sick Time - Intermittent LOA',
              
              -- Wellness and Care Leave
              'Wellness Days Off',
              'Paid Time Off - Kin Care/CA Sick',
              'Critical Care Leave',
              
              -- Parental Leave
              'Paid Parental Leave',
              'Other Paid Time - New Parent Transition',
              
              -- Other Paid Time Off
              'Other Paid Time - Bereavement',
              'Other Paid Time - Jury Duty',
              'Other Paid Time - Voting',
              'Other Paid Time - Voluntary Time Off/Community Service',
              'Other Paid Time - Business Disruption/Sent Home/Lack of Work',
              
              -- Intermittent LOA (affects daily capacity)
              'Paid Time Off - Intermittent LOA',
              'Other Paid Time - Intermittent LOA',
              'Non Paid Time - Intermittent LOA',
              
              -- Approved Unpaid Time
              'Non Paid Time - Approved/Voluntary',
              
              -- Workers Comp and Special Cases
              'Non Paid Time - Worker''s Compensation',
              'Non Paid Time - Victims of Domestic Violence & Crimes',
              'Non Paid Time - Unapproved'
          )
          AND (SELECT is_future FROM effective_range) = FALSE
          AND TRY_CAST(w.TIME_OFF_DATE AS DATE) IS NOT NULL
          AND TRY_CAST(w.TIME_OFF_DATE AS DATE) BETWEEN (SELECT date_from FROM effective_range) AND (SELECT date_to FROM effective_range)
          {{manager_filter}}
          {{staffing_category_filter}}
    ) WHERE rn = 1
),
grouped_head AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN snapshot_date
            WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start
            WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start
        END AS period_date,
        COUNT(DISTINCT userid) AS total_head_count
    FROM total_head
    WHERE CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN snapshot_date < CURRENT_DATE()
        WHEN 'weekly' THEN week_start < DATE_TRUNC('WEEK', CURRENT_DATE())
        WHEN 'monthly' THEN month_start < DATE_TRUNC('MONTH', CURRENT_DATE())
        WHEN 'quarterly' THEN quarter_start < DATE_TRUNC('QUARTER', CURRENT_DATE())
        WHEN 'yearly' THEN year_start < DATE_TRUNC('YEAR', CURRENT_DATE())
    END
    GROUP BY 1
),
grouped_time_off AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN time_off_date
            WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start
            WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start
        END AS period_date,
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ROUND(SUM(hours_off) / 8.0, 2)
            WHEN 'weekly' THEN ROUND((SUM(hours_off) / 8.0) / 5.0, 2)
            WHEN 'monthly' THEN ROUND((SUM(hours_off) / 8.0) / 22.0, 2)
            WHEN 'quarterly' THEN ROUND((SUM(hours_off) / 8.0) / 65.0, 2)
            WHEN 'yearly' THEN ROUND((SUM(hours_off) / 8.0) / 260.0, 2)
        END AS fte_off
    FROM time_off
    GROUP BY 1
),
holidays AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),
holiday_count_per_period AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN h.holiday_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', h.holiday_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', h.holiday_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', h.holiday_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', h.holiday_date)
        END AS period_date,
        COUNT(*) AS holiday_count
    FROM holidays h
    WHERE DAYOFWEEK(h.holiday_date) NOT IN (0, 6)
    GROUP BY 1
),
time_off_with_periods AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN time_off_date
            WHEN 'weekly' THEN week_start
            WHEN 'monthly' THEN month_start
            WHEN 'quarterly' THEN quarter_start
            WHEN 'yearly' THEN year_start
        END AS period_date,
        hours_off
    FROM time_off
),
adjusted_time_off AS (
    SELECT
        t.period_date,
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ROUND(SUM(t.hours_off) / 8.0, 2)
            WHEN 'weekly' THEN 
                CASE WHEN (5 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (5 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'monthly' THEN 
                CASE WHEN (22 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (22 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'quarterly' THEN 
                CASE WHEN (65 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (65 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'yearly' THEN 
                CASE WHEN (260 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (260 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
        END AS adjusted_fte_off
    FROM time_off_with_periods t
    LEFT JOIN holiday_count_per_period hc ON t.period_date = hc.period_date
    GROUP BY t.period_date, hc.holiday_count
)
SELECT
    '{{grouping_level}}' AS GROUPING_LEVEL,
    g.period_date AS PERIOD_DATE,
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN TO_CHAR(g.period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_CHAR(g.period_date, 'YYYY-MM-DD')
        WHEN 'monthly' THEN TO_CHAR(g.period_date, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_CHAR(g.period_date, 'YYYY') || '-Q' || QUARTER(g.period_date)
        WHEN 'yearly' THEN TO_CHAR(g.period_date, 'YYYY')
    END AS PERIOD_LABEL,
    CASE 
        WHEN (SELECT grouping_level FROM config) = 'daily' AND EXISTS (SELECT 1 FROM holidays h WHERE h.holiday_date = g.period_date) THEN NULL
        ELSE GREATEST(CEIL(g.total_head_count - COALESCE(at.adjusted_fte_off, 0)), 0)
    END AS ACTUAL_FTE
FROM grouped_head g
LEFT JOIN adjusted_time_off at ON g.period_date = at.period_date
ORDER BY g.period_date
"""

LOAN_FTE_QUERY = f"""
WITH config AS (
    SELECT
        '{{start_date}}'::DATE AS date_from,
        '{{end_date}}'::DATE AS date_to,
        '{{grouping_level}}' AS grouping_level
),
effective_range AS (
    SELECT
        CASE WHEN date_from > CURRENT_DATE() THEN NULL ELSE date_from END AS date_from,
        CASE WHEN date_from > CURRENT_DATE() THEN NULL ELSE LEAST(date_to, CURRENT_DATE()) END AS date_to,
        grouping_level
    FROM config
),
user_staffing_cat AS (
    SELECT
        up.USERID,
        xw.STAFFING_CATEGORY AS STAFFING_CATEGORY,
        ROW_NUMBER() OVER (PARTITION BY up.USERID ORDER BY up.logindate DESC NULLS LAST) AS rn
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_USER_PROFILE up
    LEFT JOIN {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_STAFFING_CATEGORY_XWALK xw
        ON TRIM(up.STAFFINGCATEGORY) = TRIM(xw.STAFFING_CATEGORY)
    WHERE up.USERID IS NOT NULL
),
loan_staff AS (
    SELECT
        usr.USERID,
        COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY,
        usr.ONLOAN,
        usr.STAFFCATUPDATEDATETIME::DATE AS effective_date,
        DATE_TRUNC('WEEK', usr.STAFFCATUPDATEDATETIME) AS week_start,
        DATE_TRUNC('MONTH', usr.STAFFCATUPDATEDATETIME) AS month_start,
        DATE_TRUNC('QUARTER', usr.STAFFCATUPDATEDATETIME) AS quarter_start,
        DATE_TRUNC('YEAR', usr.STAFFCATUPDATEDATETIME) AS year_start,
        usr.PYREPORTTO AS manager_id
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_USER_PROFILE usr
    LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(usr.USERID) AND usc.rn = 1
    WHERE usr.ONLOAN = 'Yes'
      AND usr.STAFFCATUPDATEDATETIME::DATE <= (SELECT date_to FROM effective_range)
      AND usr.STAFFCATUPDATEDATETIME::DATE >= (SELECT date_from FROM effective_range)
      {{manager_filter}}
      {{staffing_category_filter}}
)
SELECT
    '{{grouping_level}}' AS GROUPING_LEVEL,
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN effective_date
        WHEN 'weekly' THEN week_start::DATE
        WHEN 'monthly' THEN month_start::DATE
        WHEN 'quarterly' THEN quarter_start::DATE
        WHEN 'yearly' THEN year_start::DATE
    END AS PERIOD_DATE,
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN TO_CHAR(effective_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_CHAR(week_start, 'YYYY-MM-DD')
        WHEN 'monthly' THEN TO_CHAR(month_start, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_CHAR(quarter_start, 'YYYY') || '-Q' || QUARTER(quarter_start)
        WHEN 'yearly' THEN TO_CHAR(year_start, 'YYYY')
    END AS PERIOD_LABEL,
    COUNT(DISTINCT USERID) AS LOAN_FTE
FROM loan_staff
GROUP BY 
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN effective_date
        WHEN 'weekly' THEN week_start::DATE
        WHEN 'monthly' THEN month_start::DATE
        WHEN 'quarterly' THEN quarter_start::DATE
        WHEN 'yearly' THEN year_start::DATE
    END,
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN TO_CHAR(effective_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_CHAR(week_start, 'YYYY-MM-DD')
        WHEN 'monthly' THEN TO_CHAR(month_start, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_CHAR(quarter_start, 'YYYY') || '-Q' || QUARTER(quarter_start)
        WHEN 'yearly' THEN TO_CHAR(year_start, 'YYYY')
    END
ORDER BY PERIOD_DATE
"""

PROJECTED_FTE_QUERY = f"""
WITH config AS (
    SELECT
        '{{start_date}}'::DATE AS start_date,
        '{{end_date}}'::DATE AS end_date,
        '{{grouping_level}}' AS grouping_level
),
date_spine AS (
    SELECT DATEADD(DAY, seq.seq, dr.start_date) AS period_date
    FROM config dr
    CROSS JOIN (SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS seq FROM TABLE(GENERATOR(ROWCOUNT => 100000))) seq
    WHERE DATEADD(DAY, seq.seq, dr.start_date) <= dr.end_date
      AND (
          (SELECT grouping_level FROM config) != 'daily'
          OR DAYOFWEEK(DATEADD(DAY, seq.seq, dr.start_date)) NOT IN (0, 6)
      )
),
user_staffing_cat AS (
    SELECT
        up.USERID,
        xw.STAFFING_CATEGORY AS STAFFING_CATEGORY,
        ROW_NUMBER() OVER (PARTITION BY up.USERID ORDER BY up.logindate DESC NULLS LAST) AS rn
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_USER_PROFILE up
    LEFT JOIN {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_STAFFING_CATEGORY_XWALK xw
        ON TRIM(up.STAFFINGCATEGORY) = TRIM(xw.STAFFING_CATEGORY)
    WHERE up.USERID IS NOT NULL
),
historical_avail AS (
    SELECT DISTINCT w.EMPLOYEE_DOMAIN_ID AS userid, w.MANAGER_DOMAIN_ID AS manager_id,
        TRY_CAST(w.ASOFTODAY AS DATE) AS snapshot_date,
        COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_WORKDAY_HIST w
    LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
      AND TRY_CAST(w.ASOFTODAY AS DATE) IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) <= CURRENT_DATE()
      AND DAYOFWEEK(TRY_CAST(w.ASOFTODAY AS DATE)) NOT IN (0, 6)
      {{manager_filter}}
      {{staffing_category_filter}}
),
historical_avg AS (
    SELECT
        (
            SELECT avail_count FROM (
                SELECT snapshot_date, COUNT(DISTINCT userid) AS avail_count
                FROM historical_avail
                WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)
                GROUP BY snapshot_date
                ORDER BY snapshot_date DESC
                LIMIT 1
            )
        ) AS avg_historical_fte
),
onboard_data AS (
    SELECT
        TRY_CAST(op.FUTURE_START_DATE AS DATE) AS start_date,
        op.ONBOARDING_COUNT,
        COALESCE(UPPER(TRIM(op.LOB)), 'NONE') AS LOB
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_OPEN_POSITIONS op
    WHERE TRY_CAST(op.FUTURE_START_DATE AS DATE) IS NOT NULL
        {{lob_filter_onboard}}
),
onboard_by_period AS (
    SELECT
        start_date AS onboard_complete_date,
        SUM(ONBOARDING_COUNT) AS onboard_fte
    FROM onboard_data
    WHERE start_date >= DATEADD(DAY, -15, (SELECT MAX(snapshot_date) FROM historical_avail WHERE DAYOFWEEK(snapshot_date) NOT IN (0, 6)))
    GROUP BY start_date
),
historical_grouped_base AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN snapshot_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', snapshot_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', snapshot_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', snapshot_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', snapshot_date)
        END AS period_date,
        COUNT(DISTINCT userid) AS base_fte_count
    FROM historical_avail
    WHERE snapshot_date BETWEEN (SELECT start_date FROM config) AND (SELECT end_date FROM config)
      AND CASE (SELECT grouping_level FROM config)
          WHEN 'daily' THEN snapshot_date < CURRENT_DATE()
          WHEN 'weekly' THEN DATE_TRUNC('WEEK', snapshot_date) < DATE_TRUNC('WEEK', CURRENT_DATE())
          WHEN 'monthly' THEN DATE_TRUNC('MONTH', snapshot_date) < DATE_TRUNC('MONTH', CURRENT_DATE())
          WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', snapshot_date) < DATE_TRUNC('QUARTER', CURRENT_DATE())
          WHEN 'yearly' THEN DATE_TRUNC('YEAR', snapshot_date) < DATE_TRUNC('YEAR', CURRENT_DATE())
      END
    GROUP BY period_date
),
historical_grouped AS (
    SELECT
        hgb.period_date,
        hgb.base_fte_count + COALESCE((
            SELECT SUM(onboard_fte) FROM onboard_by_period 
            WHERE onboard_complete_date > CURRENT_DATE()
              AND onboard_complete_date <= hgb.period_date
        ), 0) AS avail_fte_count
    FROM historical_grouped_base hgb
),
future_grouped_avail AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ds.period_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', ds.period_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', ds.period_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', ds.period_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', ds.period_date)
        END AS period_date,
        COALESCE((SELECT avg_historical_fte FROM historical_avg), 0)
        + COALESCE((
            SELECT SUM(onboard_fte) FROM onboard_by_period 
            WHERE onboard_complete_date > CURRENT_DATE()
              AND onboard_complete_date <= ds.period_date
        ), 0) AS avail_fte_count
    FROM date_spine ds
    WHERE ds.period_date >= CURRENT_DATE()
    GROUP BY period_date
),
available_fte AS (
    SELECT period_date, avail_fte_count FROM historical_grouped
    UNION ALL
    SELECT period_date, avail_fte_count FROM future_grouped_avail
),
time_off_raw AS (
    SELECT
        w.EMPLOYEE_DOMAIN_ID AS userid,
        w.MANAGER_DOMAIN_ID AS manager_id,
        TRY_CAST(w.TIME_OFF_DATE AS DATE) AS time_off_date,
        TRY_CAST(w.HOURS AS FLOAT) AS hours_off,
        COALESCE(usc.STAFFING_CATEGORY, 'None') AS STAFFING_CATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.TIME_OFF_DATE AS DATE), w.TIME_OFF_TYPE, w.HOURS
            ORDER BY w.EMPLOYEE_DOMAIN_ID
        ) AS rn
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_WORKDAY_HIST w
    LEFT JOIN user_staffing_cat usc ON UPPER(usc.USERID) = UPPER(w.EMPLOYEE_DOMAIN_ID) AND usc.rn = 1
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
      AND w.STATUS IN ('Approved', 'Submitted')
      AND w.TIME_OFF_TYPE IN (
        -- Scheduled PTO
        'Paid Time Off - Approved/Scheduled',
        'Paid Time Off',
        'Paid Time Off - Supplemental',
        
        -- Unscheduled PTO
        'Paid Time Off - Unapproved/Unscheduled',
        
        -- Sick Time (all types that reduce available capacity)
        'Sick Time',
        'Sick Time - Approved',
        'Sick Time - Unapproved',
        'Sick Time - Supplemental',
        'Sick Time - Intermittent LOA',
        
        -- Wellness and Care Leave
        'Wellness Days Off',
        'Paid Time Off - Kin Care/CA Sick',
        'Critical Care Leave',
        
        -- Parental Leave
        'Paid Parental Leave',
        'Other Paid Time - New Parent Transition',
        
        -- Other Paid Time Off
        'Other Paid Time - Bereavement',
        'Other Paid Time - Jury Duty',
        'Other Paid Time - Voting',
        'Other Paid Time - Voluntary Time Off/Community Service',
        'Other Paid Time - Business Disruption/Sent Home/Lack of Work',
        
        -- Intermittent LOA (affects daily capacity)
        'Paid Time Off - Intermittent LOA',
        'Other Paid Time - Intermittent LOA',
        'Non Paid Time - Intermittent LOA',
        
        -- Approved Unpaid Time
        'Non Paid Time - Approved/Voluntary',
        
        -- Workers Comp and Special Cases
        'Non Paid Time - Worker''s Compensation',
        'Non Paid Time - Victims of Domestic Violence & Crimes',
        'Non Paid Time - Unapproved'
      )
      AND TRY_CAST(w.TIME_OFF_DATE AS DATE) IS NOT NULL
      AND TRY_CAST(w.TIME_OFF_DATE AS DATE) BETWEEN (SELECT start_date FROM config) AND (SELECT end_date FROM config)
      {{manager_filter}}
      {{staffing_category_filter}}
),
time_off AS (
    SELECT userid, manager_id, time_off_date, hours_off, STAFFING_CATEGORY
    FROM time_off_raw
    WHERE rn = 1
),
holidays_projected AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
),
holiday_count_per_period_projected AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN h.holiday_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', h.holiday_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', h.holiday_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', h.holiday_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', h.holiday_date)
        END AS period_date,
        COUNT(*) AS holiday_count
    FROM holidays_projected h
    WHERE DAYOFWEEK(h.holiday_date) NOT IN (0, 6)
    GROUP BY 1
),
time_off_with_periods_projected AS (
    SELECT
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN time_off_date
            WHEN 'weekly' THEN DATE_TRUNC('WEEK', time_off_date)
            WHEN 'monthly' THEN DATE_TRUNC('MONTH', time_off_date)
            WHEN 'quarterly' THEN DATE_TRUNC('QUARTER', time_off_date)
            WHEN 'yearly' THEN DATE_TRUNC('YEAR', time_off_date)
        END AS period_date,
        hours_off
    FROM time_off
),
actual_pto AS (
    SELECT
        t.period_date,
        CASE (SELECT grouping_level FROM config)
            WHEN 'daily' THEN ROUND(SUM(t.hours_off) / 8.0, 2)
            WHEN 'weekly' THEN 
                CASE WHEN (5 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (5 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'monthly' THEN 
                CASE WHEN (22 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (22 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'quarterly' THEN 
                CASE WHEN (65 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (65 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
            WHEN 'yearly' THEN 
                CASE WHEN (260 - COALESCE(hc.holiday_count, 0)) > 0 
                     THEN ROUND((SUM(t.hours_off) / 8.0) / (260 - COALESCE(hc.holiday_count, 0)), 2)
                     ELSE 0 
                END
        END AS pto_headcount
    FROM time_off_with_periods_projected t
    LEFT JOIN holiday_count_per_period_projected hc ON t.period_date = hc.period_date
    GROUP BY t.period_date, hc.holiday_count
),
static_pto AS (
    SELECT
        MONTH,
        REPLACE(CB_PTO_PERCENT, '%', '')::FLOAT / 100 AS cb_pto_pct,
        REPLACE(GB_PTO_PERCENT, '%', '')::FLOAT / 100 AS gb_pto_pct
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_PROJECTED_STATIC_PTO
),
staffing_category_pto_mapping AS (
    SELECT
        af.period_date,
        SUM(CASE 
            WHEN ha.STAFFING_CATEGORY IN ('CB - E/I', 'CB-Claim Edits', 'CB-Inquiries') THEN 1
            ELSE 0
        END) AS cb_count,
        SUM(CASE 
            WHEN ha.STAFFING_CATEGORY NOT IN ('CB - E/I', 'CB-Claim Edits', 'CB-Inquiries') OR ha.STAFFING_CATEGORY IS NULL THEN 1
            ELSE 0
        END) AS gb_count,
        COUNT(*) AS total_count
    FROM available_fte af
    LEFT JOIN historical_avail ha ON 1=1
    GROUP BY af.period_date
),
projected_fte_calc AS (
    SELECT
        af.period_date,
        af.avail_fte_count AS available_fte,
        CASE
            WHEN af.period_date <= DATEADD(DAY, 14, CURRENT_DATE()) THEN
                COALESCE(ap.pto_headcount, 0)
            ELSE
                ROUND(af.avail_fte_count * COALESCE(
                    (scpm.cb_count * sp.cb_pto_pct + scpm.gb_count * sp.gb_pto_pct) / NULLIF(scpm.total_count, 0),
                    (sp.cb_pto_pct + sp.gb_pto_pct) / 2
                ), 1)
        END AS uto_pto_count,
        CEIL(af.avail_fte_count - CASE
            WHEN af.period_date <= DATEADD(DAY, 14, CURRENT_DATE()) THEN
                COALESCE(ap.pto_headcount, 0)
            ELSE
                ROUND(af.avail_fte_count * COALESCE(
                    (scpm.cb_count * sp.cb_pto_pct + scpm.gb_count * sp.gb_pto_pct) / NULLIF(scpm.total_count, 0),
                    (sp.cb_pto_pct + sp.gb_pto_pct) / 2
                ), 1)
        END) AS projected_fte
    FROM available_fte af
    LEFT JOIN actual_pto ap ON af.period_date = ap.period_date
    LEFT JOIN static_pto sp ON UPPER(LEFT(TO_CHAR(af.period_date, 'MON'), 3)) = UPPER(LEFT(sp.MONTH, 3))
    LEFT JOIN staffing_category_pto_mapping scpm ON af.period_date = scpm.period_date
),
holidays AS (
    SELECT DISTINCT TRY_CAST(DATE AS DATE) AS holiday_date
    FROM {{SNOWFLAKE_DATABASE}}.{{SNOWFLAKE_SCHEMA}}.COB_AI_HOLIDAY_DATA
    WHERE TRY_CAST(DATE AS DATE) IS NOT NULL
)
SELECT
    '{{grouping_level}}' AS GROUPING_LEVEL,
    period_date AS PERIOD_DATE,
    CASE (SELECT grouping_level FROM config)
        WHEN 'daily' THEN TO_CHAR(period_date, 'YYYY-MM-DD')
        WHEN 'weekly' THEN TO_CHAR(period_date, 'YYYY-MM-DD')
        WHEN 'monthly' THEN TO_CHAR(period_date, 'Mon YYYY')
        WHEN 'quarterly' THEN TO_CHAR(period_date, 'YYYY') || '-Q' || QUARTER(period_date)
        WHEN 'yearly' THEN TO_CHAR(period_date, 'YYYY')
    END AS PERIOD_LABEL,
    CASE 
        WHEN (SELECT grouping_level FROM config) = 'daily' AND EXISTS (SELECT 1 FROM holidays h WHERE h.holiday_date = period_date) THEN NULL
        ELSE projected_fte
    END AS PROJECTED_FTE
FROM projected_fte_calc
ORDER BY period_date
"""



# =============================================================================
# FILTER BUILDER FUNCTIONS
# =============================================================================

def build_lob_filter(lob_list: List[str] = None, table_alias: str = "inv") -> str:
    """Build LOB filter for SQL queries.
    
    Handles 'None' string to match NULL values in database.
    """
    if not lob_list:
        return ""
    
    null_requested = "None" in lob_list
    non_null_lobs = [lob.upper() for lob in lob_list if lob != "None"]
    
    if null_requested and non_null_lobs:
        lob_in_clause = "', '".join(non_null_lobs)
        return f"AND (UPPER(TRIM({table_alias}.LOB)) IN ('{lob_in_clause}') OR {table_alias}.LOB IS NULL)"
    elif null_requested:
        return f"AND {table_alias}.LOB IS NULL"
    else:
        lob_in_clause = "', '".join(non_null_lobs)
        return f"AND UPPER(TRIM({table_alias}.LOB)) IN ('{lob_in_clause}')"


def build_staffing_category_filter(staffing_list: List[str] = None, table_alias: str = "usr", use_derived: bool = False) -> str:
    """Build staffing category filter for SQL queries.
    
    Args:
        staffing_list: List of staffing categories to filter
        table_alias: Table alias for STAFFINGCATEGORY column (default: usr)
        use_derived: If True, uses derived_staffing_category from crosswalk join (default: False)
    
    Returns:
        SQL filter string
    """
    if not staffing_list:
        return ""
    
    quoted_categories = [f"'{cat.upper()}'" for cat in staffing_list]
    category_in_clause = ", ".join(quoted_categories)
    
    if use_derived:
        return f"AND UPPER(TRIM(derived_staffing_category)) IN ({category_in_clause})"
    else:
        return f"AND UPPER(TRIM({table_alias}.STAFFINGCATEGORY)) IN ({category_in_clause})"


def build_work_type_filter(work_type_list: List[str] = None, table_alias: str = "inv") -> str:
    """Build work type filter for SQL queries.
    
    Handles 'None' string to match NULL values in database.
    Applies UPPER() to column to handle mixed-case data.
    """
    if not work_type_list:
        return ""
    
    null_requested = "None" in work_type_list
    non_null_types = [wt.upper() for wt in work_type_list if wt != "None"]
    
    if null_requested and non_null_types:
        type_in_clause = "', '".join(non_null_types)
        return f"AND (UPPER({table_alias}.INTAKESOURCESYSTEM) IN ('{type_in_clause}') OR {table_alias}.INTAKESOURCESYSTEM IS NULL)"
    elif null_requested:
        return f"AND {table_alias}.INTAKESOURCESYSTEM IS NULL"
    else:
        type_in_clause = "', '".join(non_null_types)
        return f"AND UPPER({table_alias}.INTAKESOURCESYSTEM) IN ('{type_in_clause}')"


def build_req_fte_work_type_filter(work_type_list: List[str] = None, table_alias: str = "inv") -> str:
    """Build work type filter for Required FTE calculation in Staffing Core.
    
    Always excludes 'Facets Pend' and 'CCERT' from Required FTE calculations
    as these intake sources should not be included in FTE requirements.
    
    Args:
        work_type_list: Optional list of work types (INTAKESOURCESYSTEM) to filter
        table_alias: Table alias to use (default: 'inv')
        
    Returns:
        SQL filter string for INTAKESOURCESYSTEM column with exclusions
    """
    # Define sources to always exclude from Required FTE calculations
    excluded_sources = ['FACETS PEND', 'CCERT']
    
    if not work_type_list:
        # No user filter - just exclude unwanted sources
        excluded_list = "', '".join(excluded_sources)
        return f"AND COALESCE(UPPER({table_alias}.INTAKESOURCESYSTEM), 'None') NOT IN ('{excluded_list}')"
    
    # Filter out excluded sources from user selections
    null_requested = "None" in work_type_list
    non_null_types = [wt.upper() for wt in work_type_list if wt != "None" and wt.upper() not in excluded_sources]
    
    if not non_null_types and not null_requested:
        # User only selected excluded sources - return filter that excludes them
        excluded_list = "', '".join(excluded_sources)
        return f"AND COALESCE(UPPER({table_alias}.INTAKESOURCESYSTEM), 'None') NOT IN ('{excluded_list}')"
    
    # Build filter with valid types AND exclusion of unwanted sources
    excluded_list = "', '".join(excluded_sources)
    
    if null_requested and non_null_types:
        type_in_clause = "', '".join(non_null_types)
        return f"AND (UPPER({table_alias}.INTAKESOURCESYSTEM) IN ('{type_in_clause}') OR {table_alias}.INTAKESOURCESYSTEM IS NULL) AND COALESCE(UPPER({table_alias}.INTAKESOURCESYSTEM), 'None') NOT IN ('{excluded_list}')"
    elif null_requested:
        return f"AND {table_alias}.INTAKESOURCESYSTEM IS NULL AND COALESCE(UPPER({table_alias}.INTAKESOURCESYSTEM), 'None') NOT IN ('{excluded_list}')"
    else:
        type_in_clause = "', '".join(non_null_types)
        return f"AND UPPER({table_alias}.INTAKESOURCESYSTEM) IN ('{type_in_clause}') AND COALESCE(UPPER({table_alias}.INTAKESOURCESYSTEM), 'None') NOT IN ('{excluded_list}')"


def build_manager_filter(manager_list: List[str] = None, table_alias: str = "usr") -> str:
    """Build manager filter for SQL queries.
    
    Handles 'None' string to match NULL manager IDs in database.
    """
    if not manager_list or len(manager_list) == 0:
        return ""
    
    null_requested = "None" in manager_list
    non_null_managers = [m for m in manager_list if m != "None"]
    
    if null_requested and non_null_managers:
        quoted_managers = [f"'{mgr.upper()}'" for mgr in non_null_managers]
        manager_in_clause = ", ".join(quoted_managers)
        return f"AND (UPPER(TRIM({table_alias}.MANAGERID)) IN ({manager_in_clause}) OR {table_alias}.MANAGERID IS NULL)"
    elif null_requested:
        return f"AND {table_alias}.MANAGERID IS NULL"
    else:
        quoted_managers = [f"'{mgr.upper()}'" for mgr in manager_list]
        manager_in_clause = ", ".join(quoted_managers)
        return f"AND UPPER(TRIM({table_alias}.MANAGERID)) IN ({manager_in_clause})"


def build_market_filter(market_list: List[str] = None, table_alias: str = "inv") -> str:
    """Build market filter for SQL queries.
    
    Handles 'None' string to match NULL values in database.
    Applies UPPER() to column to handle mixed-case data.
    """
    if not market_list:
        return ""
    
    null_requested = "None" in market_list
    non_null_markets = [mkt.upper() for mkt in market_list if mkt != "None"]
    
    if null_requested and non_null_markets:
        market_in_clause = "', '".join(non_null_markets)
        return f"AND (UPPER({table_alias}.MARKET) IN ('{market_in_clause}') OR {table_alias}.MARKET IS NULL)"
    elif null_requested:
        return f"AND {table_alias}.MARKET IS NULL"
    else:
        market_in_clause = "', '".join(non_null_markets)
        return f"AND UPPER({table_alias}.MARKET) IN ('{market_in_clause}')"


def build_funding_model_filter(funding_list: List[str] = None, table_alias: str = "inv") -> str:
    """Build funding model filter for SQL queries.
    
    Handles 'None' string to match NULL values in database.
    Applies UPPER() to column to handle mixed-case data.
    """
    if not funding_list:
        return ""
    
    null_requested = "None" in funding_list
    non_null_models = [fm.upper() for fm in funding_list if fm != "None"]
    
    if null_requested and non_null_models:
        funding_in_clause = "', '".join(non_null_models)
        return f"AND (UPPER({table_alias}.FUNDINGMODEL) IN ('{funding_in_clause}') OR {table_alias}.FUNDINGMODEL IS NULL)"
    elif null_requested:
        return f"AND {table_alias}.FUNDINGMODEL IS NULL"
    else:
        funding_in_clause = "', '".join(non_null_models)
        return f"AND UPPER({table_alias}.FUNDINGMODEL) IN ('{funding_in_clause}')"


# =============================================================================
# API ENDPOINTS
# =============================================================================

@router.post("/staffing-core", response_model=StaffingCoreResponse, summary="Get Staffing Core FTE Metrics")
async def get_staffing_core(request: StaffingCoreRequest):
    """
    Get staffing core FTE metrics including Required, Available, Actual, Loon, and Projected FTE.
    
    **Metrics:**
    - **Req FTE**: Required FTE based on workload
    - **Avail FTE**: Available FTE from staffing data
    - **Actual FTE**: Actual FTE utilized
    - **Loon FTE**: Loon FTE metric
    - **Projected FTE**: Projected FTE forecast
    
    **Comparisons:**
    - **Actual vs. Projection**: Variance between Actual and Projected FTE
    - **Required vs. Projection**: Variance between Required and Projected FTE
    
    **Input Parameters:**
    - **start_date** (required): Start date in YYYY-MM-DD format
    - **end_date** (required): End date in YYYY-MM-DD format
    - **grouping_level** (optional): Aggregation level (daily, weekly, monthly, quarterly, yearly)
    - **lob** (optional): Filter by Line of Business
    - **staffing_category** (optional): Filter by staffing category
    - **work_type** (optional): Filter by work type
    - **manager** (optional): Filter by manager ID
    - **market** (optional): Filter by market
    - **funding_model** (optional): Filter by funding model
    
    **Returns:** Staffing FTE trend data with variance calculations
    """
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
    
    try:
        # Build filters for REQ_FTE_QUERY (uses inv, usr aliases)
        lob_filter = build_lob_filter(request.lob)
        staffing_filter = build_staffing_category_filter(request.staffing_category, use_derived=True)
        # Build staffing filter for xwalk table (references xwalk.STAFFING_CATEGORY directly)
        if request.staffing_category:
            quoted_categories = [f"'{cat.upper()}'" for cat in request.staffing_category]
            category_in_clause = ", ".join(quoted_categories)
            staffing_filter_xwalk = f"AND UPPER(TRIM(xwalk.STAFFING_CATEGORY)) IN ({category_in_clause})"
        else:
            staffing_filter_xwalk = ""
        work_type_filter = build_work_type_filter(request.work_type)
        req_fte_work_type_filter = build_req_fte_work_type_filter(request.work_type)  # Dedicated filter for Required FTE (excludes Facets Pend & CCERT)
        manager_filter = build_manager_filter(getattr(request, 'manager', None))
        market_filter = build_market_filter(getattr(request, 'market', None))
        funding_model_filter = build_funding_model_filter(getattr(request, 'funding_model', None))
        
        # Build Required FTE-specific filters with cy./py. prefix (excludes Facets Pend & CCERT)
        req_fte_work_type_filter_cy = build_req_fte_work_type_filter(request.work_type, table_alias='cy')
        req_fte_work_type_filter_py = build_req_fte_work_type_filter(request.work_type, table_alias='py')
        
        # Build filter versions with cy./py. prefix for aggregation CTEs (after deduplication)
        lob_filter_cy = lob_filter.replace('inv.', 'cy.') if lob_filter else ''
        work_type_filter_cy = work_type_filter.replace('inv.', 'cy.') if work_type_filter else ''
        market_filter_cy = market_filter.replace('inv.', 'cy.') if market_filter else ''
        funding_model_filter_cy = funding_model_filter.replace('inv.', 'cy.') if funding_model_filter else ''
        staffing_filter_xwalk_cy = staffing_filter.replace('derived_staffing_category', 'xwalk.STAFFING_CATEGORY') if staffing_filter else ''

        # Build manager filter for cy/py aggregated CTEs (uses REPORTTOMANAGERID with cy./py. alias)
        manager_list_req = getattr(request, 'manager', None)
        if manager_list_req:
            null_requested_mgr = "None" in manager_list_req
            non_null_mgrs = [m for m in manager_list_req if m != "None"]
            if null_requested_mgr and non_null_mgrs:
                mgr_in = ", ".join([f"'{m.upper()}'" for m in non_null_mgrs])
                manager_filter_cy = f"AND (UPPER(TRIM(cy.REPORTTOMANAGERID)) IN ({mgr_in}) OR cy.REPORTTOMANAGERID IS NULL)"
                manager_filter_py = f"AND (UPPER(TRIM(py.REPORTTOMANAGERID)) IN ({mgr_in}) OR py.REPORTTOMANAGERID IS NULL)"
            elif null_requested_mgr:
                manager_filter_cy = "AND cy.REPORTTOMANAGERID IS NULL"
                manager_filter_py = "AND py.REPORTTOMANAGERID IS NULL"
            else:
                mgr_in = ", ".join([f"'{m.upper()}'" for m in non_null_mgrs])
                manager_filter_cy = f"AND UPPER(TRIM(cy.REPORTTOMANAGERID)) IN ({mgr_in})"
                manager_filter_py = f"AND UPPER(TRIM(py.REPORTTOMANAGERID)) IN ({mgr_in})"
        else:
            manager_filter_cy = ""
            manager_filter_py = ""

        lob_filter_py = lob_filter.replace('inv.', 'py.') if lob_filter else ''
        work_type_filter_py = work_type_filter.replace('inv.', 'py.') if work_type_filter else ''
        market_filter_py = market_filter.replace('inv.', 'py.') if market_filter else ''
        funding_model_filter_py = funding_model_filter.replace('inv.', 'py.') if funding_model_filter else ''
        staffing_filter_xwalk_py = staffing_filter.replace('derived_staffing_category', 'xwalk.STAFFING_CATEGORY') if staffing_filter else ''
        
        # Build conditional EXISTS clauses for staffing filters
        if staffing_filter_xwalk_cy:
            staffing_filter_cy_exists = f"""AND EXISTS (
          SELECT 1
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
          WHERE TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(cy.INTAKESOURCESYSTEM))
            {staffing_filter_xwalk_cy}
      )"""
        else:
            staffing_filter_cy_exists = ""
        
        if staffing_filter_xwalk_py:
            staffing_filter_py_exists = f"""AND EXISTS (
          SELECT 1
          FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK xwalk
          WHERE TRIM(UPPER(xwalk.INTAKE_SOURCE_SYSTEM)) = TRIM(UPPER(py.INTAKESOURCESYSTEM))
            {staffing_filter_xwalk_py}
      )"""
        else:
            staffing_filter_py_exists = ""
        
        # Build staffing category filter for AVAIL_FTE_QUERY, ACTUAL_FTE_QUERY, and PROJECTED_FTE_QUERY
        staffing_category_list = request.staffing_category if request.staffing_category else []
        if staffing_category_list:
            null_requested = "None" in staffing_category_list
            non_null_categories = [c for c in staffing_category_list if c != "None"]
            
            if null_requested and non_null_categories:
                category_values = "', '".join(non_null_categories)
                staffing_category_filter_avail = f"AND (COALESCE(usc.STAFFING_CATEGORY, 'None') IN ('{category_values}') OR usc.STAFFING_CATEGORY IS NULL)"
            elif null_requested:
                staffing_category_filter_avail = "AND (COALESCE(usc.STAFFING_CATEGORY, 'None') = 'None' OR usc.STAFFING_CATEGORY IS NULL)"
            else:
                category_values = "', '".join(non_null_categories)
                staffing_category_filter_avail = f"AND COALESCE(usc.STAFFING_CATEGORY, 'None') IN ('{category_values}')"
        else:
            # No staffing category filter specified
            staffing_category_filter_avail = ""
        
        # Build LOB filter for OPEN_POSITIONS table (uses LOB column, not STAFFING_CATEGORY)
        lob_list = request.lob if request.lob else []
        if lob_list:
            # Map LOB values to OPEN_POSITIONS table values using OPEN_POSITIONS_LOB_MAP
            mapped_lobs_onboard = list(set([config.OPEN_POSITIONS_LOB_MAP.get(lob, lob.upper() if lob != "None" else "NONE").upper() for lob in lob_list]))
            quoted_lobs_onboard = "', '".join(mapped_lobs_onboard)
            lob_filter_onboard = f"AND COALESCE(UPPER(TRIM(op.LOB)), 'NONE') IN ('{quoted_lobs_onboard}')"
            # Map LOB values to MEMBERSHIP_DATA table values using MEMBERSHIP_LOB_MAP
            mapped_lobs_membership = list(set([config.MEMBERSHIP_LOB_MAP.get(lob, lob.upper()) for lob in lob_list]))
            quoted_lobs_membership = [f"'{lob.upper()}'" for lob in mapped_lobs_membership]
            lob_filter_membership = f"AND UPPER(TRIM(md.LOB)) IN ({', '.join(quoted_lobs_membership)})"
        else:
            lob_filter_onboard = ""
            lob_filter_membership = ""
        
        onboard_lob_filter = build_lob_filter(request.lob, table_alias="op")
        
        # Custom manager filter for workday history (uses MANAGER_DOMAIN_ID column)
        manager_list_avail = getattr(request, 'manager', None)
        if manager_list_avail:
            quoted_managers = [f"'{mgr.upper()}'" for mgr in manager_list_avail]
            manager_in_clause = ", ".join(quoted_managers)
            manager_filter_avail = f"AND UPPER(TRIM(w.MANAGER_DOMAIN_ID)) IN ({manager_in_clause})"
        else:
            manager_filter_avail = ""
        
        # Get grouping level (default to 'monthly' if not provided)
        grouping_level = getattr(request, 'grouping_level', 'monthly')
        
        engine = connection_manager.get_engine()
        
        # Build queries with filters
        req_fte_query = REQ_FTE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            lob_filter=lob_filter,
            lob_filter_membership=lob_filter_membership,
            lob_filter_cy=lob_filter_cy,
            lob_filter_py=lob_filter_py,
            staffing_filter=staffing_filter,
            staffing_filter_xwalk=staffing_filter_xwalk,
            staffing_filter_cy_exists=staffing_filter_cy_exists,
            staffing_filter_py_exists=staffing_filter_py_exists,
            work_type_filter=req_fte_work_type_filter,  # Use Required FTE filter (excludes Facets Pend & CCERT)
            work_type_filter_cy=req_fte_work_type_filter_cy,  # Use Required FTE filter (excludes Facets Pend & CCERT)
            work_type_filter_py=req_fte_work_type_filter_py,  # Use Required FTE filter (excludes Facets Pend & CCERT)
            manager_filter=manager_filter,
            manager_filter_cy=manager_filter_cy,
            manager_filter_py=manager_filter_py,
            market_filter=market_filter,
            market_filter_cy=market_filter_cy,
            market_filter_py=market_filter_py,
            funding_model_filter=funding_model_filter,
            funding_model_filter_cy=funding_model_filter_cy,
            funding_model_filter_py=funding_model_filter_py,
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )

        
        avail_fte_query = AVAIL_FTE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            staffing_category_filter=staffing_category_filter_avail,
            lob_filter_onboard=lob_filter_onboard,
            manager_filter=manager_filter_avail,
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )
        
        
        actual_fte_query = ACTUAL_FTE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            staffing_category_filter=staffing_category_filter_avail,
            manager_filter=manager_filter_avail,
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )


        # Build filters for LOAN_FTE_QUERY (uses staffing category filter)
        manager_list_loon = getattr(request, 'manager', None)
        if manager_list_loon:
            quoted_managers_loon = [f"'{mgr.upper()}'" for mgr in manager_list_loon]
            manager_in_clause_loon = ", ".join(quoted_managers_loon)
            manager_filter_loon = f"AND UPPER(TRIM(usr.PYREPORTTO)) IN ({manager_in_clause_loon})"
        else:
            manager_filter_loon = ""
        
        loan_fte_query = LOAN_FTE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            staffing_category_filter=staffing_category_filter_avail,
            manager_filter=manager_filter_loon,
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )
     
        
        
        # Build filters for PROJECTED_FTE_QUERY (uses ul alias for LOB, w for manager)
        manager_list_projected = getattr(request, 'manager', None)
        if manager_list_projected:
            quoted_managers_projected = [f"'{mgr.upper()}'" for mgr in manager_list_projected]
            manager_in_clause_projected = ", ".join(quoted_managers_projected)
            manager_filter_projected = f"AND UPPER(TRIM(w.MANAGER_DOMAIN_ID)) IN ({manager_in_clause_projected})"
        else:
            manager_filter_projected = ""
        
        projected_fte_query = PROJECTED_FTE_QUERY.format(
            start_date=request.start_date,
            end_date=request.end_date,
            grouping_level=grouping_level,
            staffing_category_filter=staffing_category_filter_avail,
            lob_filter_onboard=lob_filter_onboard,
            manager_filter=manager_filter_projected,
            SNOWFLAKE_DATABASE=SNOWFLAKE_DATABASE,
            SNOWFLAKE_SCHEMA=SNOWFLAKE_SCHEMA
        )

        # Execute all five queries in parallel using asyncio.gather for better performance
        req_fte_results, avail_fte_results, actual_fte_results, loan_fte_results, projected_fte_results = await asyncio.gather(
            engine.execute_query_async(req_fte_query, 1000),
            engine.execute_query_async(avail_fte_query, 1000),
            engine.execute_query_async(actual_fte_query, 1000),
            engine.execute_query_async(loan_fte_query, 1000),
            engine.execute_query_async(projected_fte_query, 1000)
        )
        
        # Convert PERIOD_DATE to date type to avoid datetime/date comparison issues
        req_fte_data = {}
        for row in req_fte_results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            req_fte_data[period_date] = dict(row)
        
        avail_fte_data = {}
        for row in avail_fte_results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            avail_fte_data[period_date] = dict(row)
        
        actual_fte_data = {}
        for row in actual_fte_results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            actual_fte_data[period_date] = dict(row)
        
        loan_fte_data = {}
        for row in loan_fte_results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            loan_fte_data[period_date] = dict(row)
        
        projected_fte_data = {}
        for row in projected_fte_results:
            period_date = row['PERIOD_DATE']
            if hasattr(period_date, 'date'):
                period_date = period_date.date()
            projected_fte_data[period_date] = dict(row)
        
        # Merge all data sources
        combined_data = []
        all_periods = set(req_fte_data.keys()) | set(avail_fte_data.keys()) | set(actual_fte_data.keys()) | set(loan_fte_data.keys()) | set(projected_fte_data.keys())
        
        actual_vs_projection_variances = []
        required_vs_projection_variances = []
        
        for period_date in sorted(all_periods):
            req_fte_row = req_fte_data.get(period_date, {})
            avail_fte_row = avail_fte_data.get(period_date, {})
            actual_fte_row = actual_fte_data.get(period_date, {})
            loan_fte_row = loan_fte_data.get(period_date, {})
            projected_fte_row = projected_fte_data.get(period_date, {})
            
            req_fte = float(req_fte_row.get('REQ_FTE', 0) or 0)
            avail_fte = float(avail_fte_row.get('AVAIL_FTE', 0) or 0)
            actual_fte = float(actual_fte_row.get('ACTUAL_FTE', 0) or 0)
            loan_fte = float(loan_fte_row.get('LOAN_FTE', 0) or 0)
            projected_fte = float(projected_fte_row.get('PROJECTED_FTE', 0) or 0)
            
            # Determine if period is past or future
            from datetime import date as date_type
            current_date = date_type.today()
            is_past_or_current = period_date <= current_date
            is_future = period_date > current_date
            
            # Calculate variances based on time period
            actual_vs_projection_variance = None
            if is_past_or_current and actual_fte > 0 and projected_fte > 0:
                actual_vs_projection_variance = round(actual_fte - projected_fte, 2)
                actual_vs_projection_variances.append(actual_vs_projection_variance)
            
            required_vs_projection_variance = None
            if is_future and req_fte > 0 and projected_fte > 0:
                required_vs_projection_variance = round(req_fte - projected_fte, 2)
                required_vs_projection_variances.append(required_vs_projection_variance)
            
            combined_row = {
                'GROUPING_LEVEL': req_fte_row.get('GROUPING_LEVEL') or avail_fte_row.get('GROUPING_LEVEL') or actual_fte_row.get('GROUPING_LEVEL') or loan_fte_row.get('GROUPING_LEVEL') or projected_fte_row.get('GROUPING_LEVEL'),
                'PERIOD_DATE': period_date,
                'PERIOD_LABEL': req_fte_row.get('PERIOD_LABEL') or avail_fte_row.get('PERIOD_LABEL') or actual_fte_row.get('PERIOD_LABEL') or loan_fte_row.get('PERIOD_LABEL') or projected_fte_row.get('PERIOD_LABEL'),
                'REQ_FTE': round(req_fte, 2) if req_fte else None,
                'AVAIL_FTE': round(avail_fte, 2) if avail_fte else None,
                'ACTUAL_FTE': round(actual_fte, 2) if actual_fte else None,
                'LOAN_FTE': round(loan_fte, 2) if loan_fte else None,
                'PROJECTED_FTE': round(projected_fte, 2) if projected_fte else None,
                'ACTUAL_VS_PROJECTION_VARIANCE': actual_vs_projection_variance if actual_vs_projection_variance is not None else 0.0,
                'REQUIRED_VS_PROJECTION_VARIANCE': required_vs_projection_variance if required_vs_projection_variance is not None else 0.0
            }
            combined_data.append(combined_row)
        
        # Calculate average variances
        actual_vs_projection_avg = None
        if actual_vs_projection_variances:
            actual_vs_projection_avg = round(sum(actual_vs_projection_variances) / len(actual_vs_projection_variances))
        
        required_vs_projection_avg = None
        if required_vs_projection_variances:
            required_vs_projection_avg = round(sum(required_vs_projection_variances) / len(required_vs_projection_variances))
        
        return StaffingCoreResponse(
            status="success",
            data=combined_data,
            period_count=len(combined_data),
            actual_vs_projection_avg=actual_vs_projection_avg,
            required_vs_projection_avg=required_vs_projection_avg,
            message="Staffing core FTE data retrieved successfully",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in get_staffing_core: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
