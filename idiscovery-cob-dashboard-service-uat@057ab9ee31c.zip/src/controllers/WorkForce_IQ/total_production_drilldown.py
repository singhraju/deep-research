import logging
import asyncio
import calendar
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from schema import (
    TotalProductionDrilldownRequest,
    TotalProductionDrilldownResponse,
    TotalProductionDrilldownRecord,
)
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

# Import projection functions from irp_projection module
from controllers.WorkForce_IQ.irp_projection import (
    get_last_day_metrics,
    query_projection_data,
    generate_daily_projections
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])
connection_manager = SnowflakeConnectionManager()


# =============================================================================
# Helper Query for Last Available Date
# =============================================================================

LAST_AVAILABLE_DATE_QUERY = f"""
SELECT MAX(date) AS last_date
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.irp_projection
"""


# =============================================================================
# SQL Query Templates (reading from irp_projection table)
# =============================================================================

TOTAL_PRODUCTION_DRILLDOWN_QUERY = f"""
SELECT
    work_type,
    SUM(total_production) AS production_count,
    SUM(prod_applied_to_sla) AS prod_applied_sla_count
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.irp_projection
WHERE date >= :period_start::DATE
  AND date <= :period_end::DATE
  {{lob_filter}}
  {{work_type_filter}}
GROUP BY work_type
ORDER BY work_type
"""


# =============================================================================
# Filter Functions
# =============================================================================

def build_lob_filter(lob: Optional[List[str]] = None) -> str:
    """Build LOB filter for SQL queries."""
    if not lob or len(lob) == 0:
        return ""
    lob_values = "', '".join(lob)
    return f"AND lob IN ('{lob_values}')"


def build_work_type_filter(work_type: Optional[List[str]] = None) -> str:
    """Build work type filter for SQL queries."""
    if not work_type or len(work_type) == 0:
        return ""
    work_type_values = "', '".join(work_type)
    return f"AND work_type IN ('{work_type_values}')"


async def get_last_available_date(engine) -> Optional[date]:
    """Get the last available date from irp_projection table."""
    try:
        results = await engine.execute_query_async(LAST_AVAILABLE_DATE_QUERY, limit=1)
        if results and len(results) > 0:
            last_date = results[0].get('LAST_DATE')
            if last_date:
                if hasattr(last_date, 'date'):
                    return last_date.date()
                elif isinstance(last_date, str):
                    return datetime.strptime(last_date, '%Y-%m-%d').date()
                return last_date
        return None
    except Exception as e:
        logger.error(f"Error getting last available date: {str(e)}")
        return None


def parse_selected_date(selected_date: str, grouping_type: str = "daily") -> tuple:
    """
    Parse selected_date based on grouping_type and return (period_start, period_end) dates.
    
    Format patterns:
    - daily: 'YYYY-MM-DD' or 'M/D/YYYY' -> returns (date, date)
    - weekly: 'MM/DD/YYYY - MM/DD/YYYY' -> returns (start_date, end_date)
    - monthly: 'Mon YYYY' (e.g., 'May 2026') -> returns (first_day, last_day)
    - quarterly: 'YYYY-Q#' (e.g., '2026-Q2') -> returns (quarter_start, quarter_end)
    - yearly: 'YYYY' -> returns (jan_1, dec_31)
    """
    try:
        if grouping_type == "daily":
            # Handle both 'YYYY-MM-DD' and 'M/D/YYYY' formats
            if '-' in selected_date and selected_date.count('-') == 2:
                date_obj = datetime.strptime(selected_date, '%Y-%m-%d')
            else:
                date_obj = datetime.strptime(selected_date, '%m/%d/%Y')
            return (date_obj.strftime('%Y-%m-%d'), date_obj.strftime('%Y-%m-%d'))
        
        elif grouping_type == "weekly":
            # Format: 'MM/DD/YYYY - MM/DD/YYYY'
            if ' - ' in selected_date:
                start_str, end_str = selected_date.split(' - ')
                start_date = datetime.strptime(start_str.strip(), '%m/%d/%Y')
                end_date = datetime.strptime(end_str.strip(), '%m/%d/%Y')
                return (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
            else:
                raise ValueError(f"Invalid weekly date format: {selected_date}")
        
        elif grouping_type == "monthly":
            # Format: 'Mon YYYY' (e.g., 'May 2026')
            date_obj = datetime.strptime(selected_date, '%b %Y')
            last_day = calendar.monthrange(date_obj.year, date_obj.month)[1]
            start_date = date_obj.replace(day=1)
            end_date = date_obj.replace(day=last_day)
            return (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        elif grouping_type == "quarterly":
            # Format: 'YYYY-Q#' (e.g., '2026-Q2')
            year_str, quarter_str = selected_date.split('-Q')
            year = int(year_str)
            quarter = int(quarter_str)
            
            # Calculate quarter start and end
            start_month = (quarter - 1) * 3 + 1
            start_date = datetime(year, start_month, 1)
            end_date = start_date + relativedelta(months=3) - relativedelta(days=1)
            return (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        elif grouping_type == "yearly":
            # Format: 'YYYY'
            year = int(selected_date)
            start_date = datetime(year, 1, 1)
            end_date = datetime(year, 12, 31)
            return (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        else:
            # Default to daily if unknown grouping type
            logger.warning(f"Unknown grouping_type: {grouping_type}, defaulting to daily")
            date_obj = datetime.strptime(selected_date, '%Y-%m-%d')
            return (date_obj.strftime('%Y-%m-%d'), date_obj.strftime('%Y-%m-%d'))
    
    except Exception as e:
        logger.error(f"Error parsing selected_date '{selected_date}' with grouping_type '{grouping_type}': {str(e)}")
        raise ValueError(f"Invalid date format for selected_date: {selected_date} (grouping_type: {grouping_type})")


def format_query(query_template: str, period_start: str, period_end: str, lob_filter: str = "", work_type_filter: str = "") -> str:
    """Format query template with filters and date parameters."""
    # Format the query with filters
    query = query_template.format(
        lob_filter=lob_filter,
        work_type_filter=work_type_filter
    )
    # Replace parameter placeholders
    query = query.replace(":period_start", f"'{period_start}'")
    query = query.replace(":period_end", f"'{period_end}'")
    return query


@router.post(
    "/total-production-drilldown",
    response_model=TotalProductionDrilldownResponse,
    summary="Get Total Production Drilldown",
    description="""
    Get detailed breakdown of Total Production for a specific date/period from IRP Projection table.
    
    This drilldown shows work items with their total completed items and production applied to SLA.
    
    **Input Parameters:**
    - **user_id** (optional): Logged-in user ID
    - **selected_date** (required): Date/period selected from IRP table. Format varies by grouping_type:
        - daily: 'YYYY-MM-DD' or 'M/D/YYYY' (e.g., '2026-05-01' or '5/1/2026')
        - weekly: 'MM/DD/YYYY - MM/DD/YYYY' (e.g., '06/01/2026 - 06/07/2026')
        - monthly: 'Mon YYYY' (e.g., 'May 2026')
        - quarterly: 'YYYY-Q#' (e.g., '2026-Q2')
        - yearly: 'YYYY' (e.g., '2026')
    - **start_date** (optional): Overall filter start date (YYYY-MM-DD) - for reference only
    - **end_date** (optional): Overall filter end date (YYYY-MM-DD) - for reference only
    - **grouping_type** (optional): Grouping type from parent table - daily, weekly, monthly, quarterly, yearly (default: daily)
    - **lob** (optional): List of Line of Business values to filter
    - **staffing_category** (optional): List of staffing categories to filter
    - **work_type** (optional): List of work types to filter
    - **page** (required): Page number for pagination (default: 1)
    - **page_size** (required): Number of records per page (default: 50, max: 1000)
    
    **Returns:**
    - **work_item**: Work type (aggregated across all LOBs)
    - **total_completed**: Total items completed/resolved during period
    - **prod_applied_to_sla**: Production count applied to SLA (items with EXTERNALDUEDATE in period)
    
    **Data Source:**
    - irp_projection table (pre-aggregated daily data)
    
    **Note:** Results are grouped by work_type only (not by LOB), showing totals across all Lines of Business
    
    **Includes:**
    - Pagination information with total counts
    - Totals row for aggregated metrics
    """,
)
async def get_total_production_drilldown(request: TotalProductionDrilldownRequest):
    """
    Get Total Production drilldown data with pagination.
    Queries irp_projection table for production metrics.
    """
    try:
        logger.info(f"Total Production Drilldown request received: {request.dict()}")
        
        # Validate connection
        if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
        # Parse selected_date based on grouping_type
        try:
            period_start, period_end = parse_selected_date(request.selected_date, request.grouping_type or "daily")
            logger.info(f"Parsed date range from selected_date '{request.selected_date}' (grouping: {request.grouping_type}): {period_start} to {period_end}")
        except ValueError as ve:
            raise HTTPException(status_code=400, detail=str(ve))
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        
        # Get database engine
        engine = connection_manager.get_engine()
        
        # Convert date strings to date objects
        period_start_date = datetime.strptime(period_start, '%Y-%m-%d').date()
        period_end_date = datetime.strptime(period_end, '%Y-%m-%d').date()
        
        # Check if we need projections
        last_available_date = await get_last_available_date(engine)
        need_projections = last_available_date and period_end_date > last_available_date
        
        # Collect all daily data (actual + projected if needed)
        all_daily_data = []
        
        # Query actual data if period overlaps with available data
        if last_available_date and period_start_date <= last_available_date:
            actual_end = min(period_end_date, last_available_date)
            query = format_query(TOTAL_PRODUCTION_DRILLDOWN_QUERY, period_start, actual_end.strftime('%Y-%m-%d'), lob_filter, work_type_filter)
            logger.info(f"Querying actual data from {period_start} to {actual_end}")
            actual_results = await engine.execute_query_async(query, limit=10000)
            logger.info(f"Retrieved {len(actual_results)} actual work_type records")
            
            # Store actual data by work_type
            for row in actual_results:
                all_daily_data.append({
                    'work_type': row['WORK_TYPE'],
                    'production_count': int(row['PRODUCTION_COUNT']) if row['PRODUCTION_COUNT'] is not None else 0,
                    'prod_applied_sla': int(row['PROD_APPLIED_SLA_COUNT']) if row['PROD_APPLIED_SLA_COUNT'] is not None else 0
                })
        
        # Generate projections if needed
        if need_projections:
            projection_start = last_available_date + timedelta(days=1)
            logger.info(f"Generating projections from {projection_start} to {period_end_date}")
            
            # Get last day metrics
            last_day_metrics = await get_last_day_metrics(engine, last_available_date, lob_filter, work_type_filter)
            logger.info(f"Retrieved last day metrics for {len(last_day_metrics)} LOB/work_type combinations")
            
            # Query projection data
            projected_receipts, projected_resolved, projected_fte, projected_sla_due, future_avail_fte = await query_projection_data(
                engine=engine,
                start_date=projection_start,
                end_date=period_end_date,
                last_available_date=last_available_date,
                lob_values=request.lob,
                work_type_values=request.work_type
            )
            
            # Generate daily projections
            if last_day_metrics:
                projected_data = generate_daily_projections(
                    start_date=projection_start,
                    end_date=period_end_date,
                    last_day_metrics=last_day_metrics,
                    projected_receipts=projected_receipts,
                    projected_resolved=projected_resolved,
                    projected_fte=projected_fte,
                    projected_sla_due=projected_sla_due,
                    future_avail_fte=future_avail_fte
                )
                logger.info(f"Generated {len(projected_data)} projected daily records")
                
                # Filter projected data to period range and aggregate by work_type
                projected_by_work_type = {}
                for proj in projected_data:
                    proj_date = proj['date']
                    if period_start_date <= proj_date <= period_end_date:
                        work_type = proj['work_type']
                        if work_type not in projected_by_work_type:
                            projected_by_work_type[work_type] = {
                                'production_count': 0,
                                'prod_applied_sla': 0
                            }
                        # Note: prod_applied_to_sla is "N/A" string for projections - convert to 0
                        production = proj.get('total_production', 0)
                        prod_applied = proj.get('prod_applied_to_sla', 0)
                        
                        # Convert string "N/A" or other strings to 0
                        if isinstance(prod_applied, str):
                            prod_applied = 0
                        
                        projected_by_work_type[work_type]['production_count'] += production
                        projected_by_work_type[work_type]['prod_applied_sla'] += prod_applied
                
                # Add projected data to all_daily_data
                for work_type, metrics in projected_by_work_type.items():
                    all_daily_data.append({
                        'work_type': work_type,
                        'production_count': metrics['production_count'],
                        'prod_applied_sla': metrics['prod_applied_sla']
                    })
        
        # Aggregate by work_type (combine actual and projected)
        aggregated_by_work_type = {}
        for item in all_daily_data:
            work_type = item['work_type']
            if work_type not in aggregated_by_work_type:
                aggregated_by_work_type[work_type] = {
                    'production_count': 0,
                    'prod_applied_sla': 0
                }
            # Ensure numeric values for aggregation (handle any string values)
            production_count = item['production_count']
            prod_applied_sla = item['prod_applied_sla']
            
            if isinstance(production_count, str):
                production_count = 0
            if isinstance(prod_applied_sla, str):
                prod_applied_sla = 0
            
            aggregated_by_work_type[work_type]['production_count'] += production_count
            aggregated_by_work_type[work_type]['prod_applied_sla'] += prod_applied_sla
        
        logger.info(f"Aggregated to {len(aggregated_by_work_type)} work_type records")
        
        # Build result records from aggregated data
        all_records = []
        for work_type, metrics in aggregated_by_work_type.items():
            total_completed = metrics['production_count']
            prod_applied_to_sla = metrics['prod_applied_sla']
            
            all_records.append({
                "work_item": work_type,
                "total_completed": total_completed,
                "prod_applied_to_sla": prod_applied_to_sla
            })
        
        # Sort records by work_item name
        all_records.sort(key=lambda x: x["work_item"])
        
        # Apply pagination
        total_count = len(all_records)
        start_idx = (request.page - 1) * request.page_size
        end_idx = start_idx + request.page_size
        paginated_records = all_records[start_idx:end_idx]
        
        # Convert to data models
        data_points = [TotalProductionDrilldownRecord(**record) for record in paginated_records]
        
        # Calculate pagination info
        total_pages = (total_count + request.page_size - 1) // request.page_size
        
        page_info = {
            "page": request.page,
            "page_size": request.page_size,
            "total_pages": total_pages,
            "total_records": total_count,
            "has_next": request.page < total_pages,
            "has_previous": request.page > 1
        }
        
        logger.info(f"Returning {len(data_points)} Total Production drilldown records (page {request.page}/{total_pages})")
        
        return TotalProductionDrilldownResponse(
            status="success",
            data=data_points,
            page_info=page_info,
            total_count=total_count,
            message=f"Successfully retrieved Total Production drilldown for {request.selected_date}",
            service="idiscovery-cob-dashboard-service"
        )
        
    except Exception as e:
        logger.error(f"Error in Total Production drilldown endpoint: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve Total Production drilldown data: {str(e)}"
        )


@router.post(
    "/total-production-drilldown/download-excel",
    summary="Download Total Production Drilldown as Excel",
    description="""
    Download complete Total Production drilldown data as an Excel file.
    
    **Input Parameters:**
    - Same as the main drilldown endpoint (without pagination parameters)
    
    **Returns:** Excel file (.xlsx) with all Total Production drilldown records
    """,
)
async def download_total_production_drilldown_excel(request: TotalProductionDrilldownRequest) -> StreamingResponse:
    """
    Download Total Production drilldown data as Excel file.
    Returns all records without pagination.
    """
    try:
        logger.info(f"Total Production Drilldown Excel download request received: {request.dict()}")
        
        # Validate connection
        if not connection_manager.validate_config():
            raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")
        
        # Parse selected_date based on grouping_type
        try:
            period_start, period_end = parse_selected_date(request.selected_date, request.grouping_type or "daily")
            logger.info(f"Parsed date range from selected_date '{request.selected_date}' (grouping: {request.grouping_type}): {period_start} to {period_end}")
        except ValueError as ve:
            raise HTTPException(status_code=400, detail=str(ve))
        
        # Build filters
        lob_filter = build_lob_filter(request.lob)
        work_type_filter = build_work_type_filter(request.work_type)
        
        # Get database engine
        engine = connection_manager.get_engine()
        
        # Format query with date range
        query = format_query(TOTAL_PRODUCTION_DRILLDOWN_QUERY, period_start, period_end, lob_filter, work_type_filter)
        
        # Execute query
        logger.info("Executing Total Production drilldown query from irp_projection table for Excel export")
        results = await engine.execute_query_async(query, limit=10000)
        logger.info(f"Query execution completed, found {len(results)} work_type records")
        
        # Build result records
        all_records = []
        for row in results:
            work_type = row['WORK_TYPE']
            total_completed = int(row['PRODUCTION_COUNT']) if row['PRODUCTION_COUNT'] is not None else 0
            prod_applied_to_sla = int(row['PROD_APPLIED_SLA_COUNT']) if row['PROD_APPLIED_SLA_COUNT'] is not None else 0
            
            all_records.append({
                "work_item": work_type,
                "total_completed": total_completed,
                "prod_applied_to_sla": prod_applied_to_sla
            })
        
        # Calculate totals
        totals = {
            "work_item": "Totals",
            "total_completed": sum(r["total_completed"] for r in all_records),
            "prod_applied_to_sla": sum(r["prod_applied_to_sla"] for r in all_records)
        }
        all_records.append(totals)
        
        # Create Excel workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Total Production Drilldown"
        
        # Style for header
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        # Headers
        headers = [
            "Work Item",
            "Total Completed",
            "Prod Applied to SLA"
        ]
        
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
        
        # Add data rows
        bold_font = Font(bold=True)
        for row_num, record in enumerate(all_records, start=2):
            is_totals_row = record["work_item"] == "Totals"
            
            ws.cell(row=row_num, column=1, value=str(record["work_item"]))
            ws.cell(row=row_num, column=2, value=record["total_completed"])
            ws.cell(row=row_num, column=3, value=record["prod_applied_to_sla"])
            
            # Apply bold to totals row
            if is_totals_row:
                for col in range(1, 4):
                    ws.cell(row=row_num, column=col).font = bold_font
        
        # Auto-adjust column widths
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # Save to BytesIO
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        # Generate filename
        filename = f"total_production_drilldown_{request.selected_date.replace('/', '-')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        
        logger.info(f"Generated Total Production drilldown Excel file: {filename}")
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except Exception as e:
        logger.error(f"Error generating Total Production drilldown Excel: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate Excel file: {str(e)}"
        )
