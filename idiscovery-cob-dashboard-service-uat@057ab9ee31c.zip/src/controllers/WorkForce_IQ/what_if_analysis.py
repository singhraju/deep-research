import logging
import asyncio
from typing import Optional, List
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema.workforce_iq_models import WhatIfAnalysisRequest, WhatIfAnalysisResponse
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])

connection_manager = SnowflakeConnectionManager()

# SQL QUERIES

TOTAL_MEMBERSHIP_QUERY = f"""
WITH month_mapping AS (
    SELECT 
        m.YEAR,
        m.MONTH,
        m.LOB,
        m.ACTUAL_MEMBERSHIP,
        (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            END
        ) AS year_month
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    WHERE m.ACTUAL_MEMBERSHIP IS NOT NULL
),
ranked_data AS (
    SELECT 
        *,
        ROW_NUMBER() OVER (
            PARTITION BY LOB 
            ORDER BY year_month DESC
        ) AS rn
    FROM month_mapping
    WHERE year_month < (YEAR(CURRENT_DATE) * 100 + MONTH(CURRENT_DATE))
)
SELECT 
    SUM(ACTUAL_MEMBERSHIP) AS TOTAL_MEMBERSHIP
FROM ranked_data
WHERE rn = 1
"""

DEMAND_UTILIZATION_QUERY = f"""
WITH staffing_mapping AS (
    SELECT DISTINCT 
        INTAKE_SOURCE_SYSTEM,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
    WHERE {{staffing_category_filter}}
),
latest_membership AS (
    SELECT 
        ROW_NUMBER() OVER (
            PARTITION BY m.LOB 
            ORDER BY (m.YEAR * 100 + 
                CASE 
                    WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                    WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                    WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                    WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                    WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                    WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                    WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                    WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                    WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                    WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                    WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                    WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
                END
            ) DESC
        ) AS rn,
        m.ACTUAL_MEMBERSHIP
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_MEMBERSHIP_DATA m
    WHERE m.ACTUAL_MEMBERSHIP IS NOT NULL
        AND (m.YEAR * 100 + 
            CASE 
                WHEN UPPER(m.MONTH) = 'JANUARY' THEN 1
                WHEN UPPER(m.MONTH) = 'FEBRUARY' THEN 2
                WHEN UPPER(m.MONTH) = 'MARCH' THEN 3
                WHEN UPPER(m.MONTH) = 'APRIL' THEN 4
                WHEN UPPER(m.MONTH) = 'MAY' THEN 5
                WHEN UPPER(m.MONTH) = 'JUNE' THEN 6
                WHEN UPPER(m.MONTH) = 'JULY' THEN 7
                WHEN UPPER(m.MONTH) = 'AUGUST' THEN 8
                WHEN UPPER(m.MONTH) = 'SEPTEMBER' THEN 9
                WHEN UPPER(m.MONTH) = 'OCTOBER' THEN 10
                WHEN UPPER(m.MONTH) = 'NOVEMBER' THEN 11
                WHEN UPPER(m.MONTH) = 'DECEMBER' THEN 12
            END
        ) < (YEAR(CURRENT_DATE) * 100 + MONTH(CURRENT_DATE))
),
total_membership AS (
    SELECT SUM(ACTUAL_MEMBERSHIP) AS total_membership
    FROM latest_membership
    WHERE rn = 1
),
recent_receipts AS (
    SELECT COUNT(DISTINCT inv.PYID) AS actual_receipts
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE DATE(inv.PXCREATEDATETIME) = DATEADD(day, -1, CURRENT_DATE)
      AND EXISTS (
          SELECT 1 
          FROM staffing_mapping sm
          WHERE sm.INTAKE_SOURCE_SYSTEM = inv.INTAKESOURCESYSTEM
            AND sm.LOB = inv.LOB
      )
)
SELECT 
    CASE 
        WHEN (SELECT total_membership FROM total_membership) IS NULL THEN NULL
        WHEN (SELECT total_membership FROM total_membership) = 0 THEN NULL
        ELSE ROUND(
            ((SELECT actual_receipts FROM recent_receipts) / 
             (SELECT total_membership FROM total_membership)) * 100, 
            2
        )
    END AS DEMAND_UTILIZATION_PERCENTAGE
"""

CASES_PER_HOUR_QUERY = f"""
WITH staffing_mapping AS (
    SELECT DISTINCT 
        INTAKE_SOURCE_SYSTEM,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
    WHERE {{staffing_category_filter}}
),
completed_work_items AS (
    SELECT 
        inv.PYID,
        inv.CYCLE_TIME
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE DATE(inv.PYRESOLVEDTIMESTAMP) = DATEADD(day, -1, CURRENT_DATE)
        AND inv.PYRESOLVEDTIMESTAMP IS NOT NULL
        AND inv.CYCLE_TIME IS NOT NULL
        AND inv.CYCLE_TIME > 0
        AND EXISTS (
            SELECT 1 
            FROM staffing_mapping sm
            WHERE sm.INTAKE_SOURCE_SYSTEM = inv.INTAKESOURCESYSTEM
              AND sm.LOB = inv.LOB
        )
),
productivity_metrics AS (
    SELECT 
        COUNT(DISTINCT PYID) AS total_completed_cases,
        SUM(CYCLE_TIME) AS total_cycle_time_seconds,
        CASE 
            WHEN SUM(CYCLE_TIME) = 0 OR SUM(CYCLE_TIME) IS NULL THEN NULL
            ELSE ROUND((3600.0 * COUNT(DISTINCT PYID)) / SUM(CYCLE_TIME), 2)
        END AS cases_per_hour
    FROM completed_work_items
)
SELECT 
    cases_per_hour AS CASES_PER_HOUR
FROM productivity_metrics
"""

INVENTORY_VOLUME_QUERY = f"""
WITH staffing_mapping AS (
    SELECT DISTINCT 
        INTAKE_SOURCE_SYSTEM,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
    WHERE {{staffing_category_filter}}
),
deduped_inventory AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE PXCREATEDATETIME < CURRENT_DATE
        AND (PYRESOLVEDTIMESTAMP IS NULL OR PYRESOLVEDTIMESTAMP >= CURRENT_DATE)
        AND EXISTS (
            SELECT 1 
            FROM staffing_mapping sm
            WHERE sm.INTAKE_SOURCE_SYSTEM = inv.INTAKESOURCESYSTEM
              AND sm.LOB = inv.LOB
        )
)
SELECT
    COUNT(DISTINCT PYID) AS INVENTORY_VOLUME
FROM deduped_inventory
WHERE rn = 1
    AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake',
                         'Open-ReviewIntake', 'Pend', 'Pend-Decision')
"""

AVAILABLE_FTE_QUERY = f"""
SELECT
    (
        SELECT MAX(TRY_CAST(ASOFTODAY AS DATE))
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST
        WHERE TRY_CAST(ASOFTODAY AS DATE) <= DATEADD(day, -1, CURRENT_DATE())
          AND DAYOFWEEK(TRY_CAST(ASOFTODAY AS DATE)) NOT IN (0, 6)
    ) AS SNAPSHOT_DATE,
    COUNT(DISTINCT w.EMPLOYEE_DOMAIN_ID) AS AVAIL_FTE
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
  AND w.EMPLOYEE_DOMAIN_ID IS NOT NULL
  AND TRY_CAST(w.ASOFTODAY AS DATE) = (
        SELECT MAX(TRY_CAST(ASOFTODAY AS DATE))
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST
        WHERE TRY_CAST(ASOFTODAY AS DATE) <= DATEADD(day, -1, CURRENT_DATE())
          AND DAYOFWEEK(TRY_CAST(ASOFTODAY AS DATE)) NOT IN (0, 6)
  )
"""

LOAN_FTE_QUERY = f"""
WITH staffing_mapping AS (
    SELECT DISTINCT 
        INTAKE_SOURCE_SYSTEM,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
    WHERE {{staffing_category_filter}}
),
latest_user_status AS (
    SELECT 
        usr.USERID,
        usr.ONLOAN,
        inv.LOB,
        inv.INTAKESOURCESYSTEM,
        ROW_NUMBER() OVER (PARTITION BY usr.USERID ORDER BY usr.STAFFCATUPDATEDATETIME DESC NULLS LAST) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE usr
    LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
        ON inv.ASSIGNEDTO = usr.USERID
    WHERE usr.ONLOAN IS NOT NULL
)
SELECT 
    COUNT(DISTINCT lus.USERID) AS LOAN_FTE
FROM latest_user_status lus
WHERE lus.ONLOAN = 'Yes'
  AND lus.rn = 1
  AND EXISTS (
      SELECT 1 
      FROM staffing_mapping sm
      WHERE sm.INTAKE_SOURCE_SYSTEM = lus.INTAKESOURCESYSTEM
        AND sm.LOB = lus.LOB
  )
"""

AVG_CYCLE_TIME_QUERY = f"""
WITH staffing_mapping AS (
    SELECT DISTINCT 
        INTAKE_SOURCE_SYSTEM,
        LOB
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
    WHERE {{staffing_category_filter}}
),
invntry_deduped AS (
    SELECT
        PYID,
        CYCLE_TIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE inv
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
        AND PYRESOLVEDTIMESTAMP IS NOT NULL
        AND CYCLE_TIME IS NOT NULL
        AND CYCLE_TIME > 0
        AND PYRESOLVEDTIMESTAMP >= DATEADD(day, -90, CURRENT_DATE)
        AND PYRESOLVEDTIMESTAMP < CURRENT_DATE
        AND EXISTS (
            SELECT 1 
            FROM staffing_mapping sm
            WHERE sm.INTAKE_SOURCE_SYSTEM = inv.INTAKESOURCESYSTEM
              AND sm.LOB = inv.LOB
        )
)
SELECT
    COALESCE(ROUND(AVG(CYCLE_TIME), 2), 0) AS AVG_CYCLE_TIME_SECONDS,
    COALESCE(ROUND(AVG(CYCLE_TIME) / 60, 2), 0) AS AVG_CYCLE_TIME_MINUTES
FROM invntry_deduped
WHERE rn = 1
"""

SHRINKAGE_QUERY = f"""
WITH latest_snapshot AS (
    SELECT MAX(TRY_CAST(ASOFTODAY AS DATE)) AS target_date
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST
    WHERE TRY_CAST(ASOFTODAY AS DATE) <= DATEADD(day, -1, CURRENT_DATE())
      AND DAYOFWEEK(TRY_CAST(ASOFTODAY AS DATE)) NOT IN (0, 6)
),
avail_fte AS (
    SELECT COUNT(DISTINCT w.EMPLOYEE_DOMAIN_ID) AS available_fte
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
    CROSS JOIN latest_snapshot ls
    WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
      AND w.EMPLOYEE_DOMAIN_ID IS NOT NULL
      AND TRY_CAST(w.ASOFTODAY AS DATE) = ls.target_date
),
time_off AS (
    SELECT
        COALESCE(SUM(TRY_CAST(HOURS AS FLOAT)), 0) AS total_hours_off
    FROM (
        SELECT
            w.EMPLOYEE_DOMAIN_ID,
            w.TIME_OFF_DATE,
            w.TIME_OFF_TYPE,
            w.HOURS,
            ROW_NUMBER() OVER (
                PARTITION BY w.EMPLOYEE_DOMAIN_ID, TRY_CAST(w.TIME_OFF_DATE AS DATE), w.TIME_OFF_TYPE, w.HOURS
                ORDER BY w.EMPLOYEE_DOMAIN_ID
            ) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_WORKDAY_HIST w
        CROSS JOIN latest_snapshot ls
        WHERE w.JOB_PROFILE_NAME LIKE 'eCOB%'
          AND w.STATUS IN ('Approved', 'Submitted')
          AND w.TIME_OFF_TYPE IN (
              'Paid Time Off - Approved/Scheduled',
              'Paid Time Off - Unapproved/Unscheduled',
              'Paid Time Off - Intermittent LOA',
              'Non Paid Time - Approved/Voluntary',
              'Non Paid Time - Intermittent LOA',
              'Non Paid Time - Worker''s Compensation'
          )
          AND TRY_CAST(w.TIME_OFF_DATE AS DATE) = ls.target_date
    ) deduped
    WHERE rn = 1
),
metrics AS (
    SELECT
        ls.target_date AS snapshot_date,
        a.available_fte,
        COALESCE(ROUND(t.total_hours_off / 8.0, 2), 0) AS fte_off,
        GREATEST(a.available_fte - COALESCE(ROUND(t.total_hours_off / 8.0, 2), 0), 0) AS actual_fte
    FROM latest_snapshot ls
    CROSS JOIN avail_fte a
    CROSS JOIN time_off t
)
SELECT
    snapshot_date AS SNAPSHOT_DATE,
    CASE 
        WHEN available_fte = 0 THEN 0
        WHEN available_fte IS NULL THEN 0
        ELSE ROUND(((available_fte - actual_fte) / available_fte) * 100, 2)
    END AS CURRENT_SHRINKAGE_PERCENT
FROM metrics
"""

OUT_OF_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        EXTERNALDUEDATE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
        AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                             'Open-ReviewIntake', 'Pend', 'Pend-Decision')
        {{staffing_category_filter}}
)
SELECT 
    COUNT(*) AS total_open_items,
    SUM(CASE WHEN CURRENT_DATE > EXTERNALDUEDATE THEN 1 ELSE 0 END) AS out_of_sla_count,
    ROUND(
        (SUM(CASE WHEN CURRENT_DATE > EXTERNALDUEDATE THEN 1 ELSE 0 END) * 100.0) / 
        NULLIF(COUNT(*), 0), 
        2
    ) AS out_of_sla_pct
FROM invntry_deduped
WHERE rn = 1
    AND EXTERNALDUEDATE IS NOT NULL
"""


def build_crosswalk_where_clause(staffing_category: Optional[List[str]]) -> str:
    """Build WHERE clause for crosswalk table staffing category filter."""
    if not staffing_category or len(staffing_category) == 0:
        return "1=1"
    
    category_values = "', '".join([str(c).strip() for c in staffing_category])
    return f"STAFFING_CATEGORY IN ('{category_values}')"


def build_staffing_category_filter(staffing_category: Optional[List[str]]) -> str:
    """Build staffing category filter using crosswalk table to map to INTAKESOURCESYSTEM."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    # Map staffing categories to work types via crosswalk table
    category_values = "', '".join(staffing_category)
    return f"""AND INTAKESOURCESYSTEM IN (
        SELECT DISTINCT INTAKE_SOURCE_SYSTEM 
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
        WHERE STAFFING_CATEGORY IN ('{category_values}')
    )"""


def build_staffing_category_lob_filter(staffing_category: Optional[List[str]]) -> str:
    """Build LOB filter using staffing category crosswalk."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    category_values = "', '".join([str(c).strip() for c in staffing_category])
    return f"""AND LOB IN (
        SELECT DISTINCT LOB 
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
        WHERE STAFFING_CATEGORY IN ('{category_values}')
    )"""


def build_staffing_category_filter_for_crosswalk(staffing_category: Optional[List[str]]) -> str:
    """Build LOB filter using subquery on crosswalk table. Returns AND clause with LOB IN subquery."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    # Build IN clause with proper escaping
    category_values = "', '".join(staffing_category)
    return f"""AND inv.LOB IN (
        SELECT DISTINCT LOB 
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
        WHERE STAFFING_CATEGORY IN ('{category_values}')
    )"""


def build_staffing_category_type_filter(staffing_category: Optional[List[str]]) -> str:
    """Build staffing category type filter for loan FTE query (for STAFFING_CATEGORY_TYPE column in crosswalk)."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    category_values = "', '".join(staffing_category)
    return f"\n  AND UPPER(TRIM(xwalk.STAFFING_CATEGORY_TYPE)) IN ('{category_values}')"


def build_market_filter(market: Optional[List[str]]) -> str:
    """Build market filter for SQL query."""
    if not market or len(market) == 0:
        return ""
    
    market_values = "', '".join(market)
    return f"AND MARKET IN ('{market_values}')"


def build_funding_model_filter(funding_model: Optional[List[str]]) -> str:
    """Build funding model filter for SQL query."""
    if not funding_model or len(funding_model) == 0:
        return ""
    
    funding_model_values = "', '".join(funding_model)
    return f"AND FUNDINGMODEL IN ('{funding_model_values}')"


@router.post(
    "/what-if-analysis",
    response_model=WhatIfAnalysisResponse,
    summary="Get What-If Analysis Data",
    description="""
Retrieve what-if analysis data including latest membership and current demand utilization.

**Input Parameters:**
- **user_id** (optional): Logged-in user ID
- **staffing_category** (optional): List of staffing categories (used for other queries in this endpoint)

**Response Fields:**
- **total_membership**: Sum of actual membership from latest available month across all LOBs
- **demand_utilization_percentage**: Current demand utilization (yesterday's receipts / latest membership * 100) - filtered by staffing category via crosswalk LOB mapping
- **standard_cases_per_hour**: Productivity metric - cases completed per hour (yesterday's completed work items, filtered by staffing category via crosswalk LOB mapping)
- **inventory_volume**: Yesterday's backlog count - open work items at end of yesterday (filtered by staffing category via crosswalk LOB mapping)
- **avg_cycle_time_minutes**: Average cycle time in minutes for yesterday's resolved items (filtered by staffing category via crosswalk LOB mapping)
- **available_fte**: Yesterday's available FTE count - unique employees with eCOB job profile from Workday history
- **loan_fte**: Current loan FTE count - employees marked as on loan, filtered by staffing category type via crosswalk
- **shrinkage**: Shrinkage metric (placeholder - returns 'N/A' until query is implemented)

**Data Sources:** 
- COB_AI_MEMBERSHIP_DATA (membership data)
- COB_AI_INVNTRY_PROFILE (work items/receipts, completed cases with cycle time, backlog, and resolved items)
- COB_AI_STAFFING_CATEGORY_XWALK (crosswalk table mapping staffing categories to LOBs)
- COB_AI_WORKDAY_HIST (available FTE from Workday)
- COB_AI_USER_PROFILE (loan FTE from user profiles)

**Note:** Membership data returns ALL LOBs (no filtering). All other metrics (demand utilization, cases per hour, inventory volume, avg cycle time, loan FTE) filter by staffing category via crosswalk LOB mapping.
""",
)
async def get_what_if_analysis(request: WhatIfAnalysisRequest):
    """
    Get what-if analysis data including latest membership information.
    
    This endpoint retrieves the most recent membership data available
    (excluding current month) for all LOBs and provides aggregated totals.
    """
    try:
        logger.info(f"[WHAT_IF_ANALYSIS] Request received for user: {request.user_id}")
        
        engine = connection_manager.get_engine()
        
        # Build crosswalk WHERE clause for staffing category filter
        crosswalk_where_clause = build_crosswalk_where_clause(request.staffing_category)
        
        # Format demand utilization query with crosswalk filter
        demand_utilization_query = DEMAND_UTILIZATION_QUERY.format(
            staffing_category_filter=crosswalk_where_clause
        )
        
        # Format cases per hour query with crosswalk filter
        cases_per_hour_query = CASES_PER_HOUR_QUERY.format(
            staffing_category_filter=crosswalk_where_clause
        )
        
        # Format inventory volume query with crosswalk filter
        inventory_volume_query = INVENTORY_VOLUME_QUERY.format(
            staffing_category_filter=crosswalk_where_clause
        )
        
        # Format average cycle time query with crosswalk filter
        avg_cycle_time_query = AVG_CYCLE_TIME_QUERY.format(
            staffing_category_filter=crosswalk_where_clause
        )
        
        # Format loan FTE query with crosswalk filter
        loan_fte_query = LOAN_FTE_QUERY.format(
            staffing_category_filter=crosswalk_where_clause
        )
        
        # Format out-of-SLA query with staffing category LOB filter
        lob_filter_for_sla = build_staffing_category_lob_filter(request.staffing_category)
        out_of_sla_query = OUT_OF_SLA_QUERY.format(
            staffing_category_filter=lob_filter_for_sla
        )
        
        # Execute queries in parallel
        logger.info("[WHAT_IF_ANALYSIS] Executing all queries in parallel")
        total_records, demand_util_records, cases_per_hour_records, inventory_volume_records, cycle_time_records, avail_fte_records, loan_fte_records, shrinkage_records, out_of_sla_records = await asyncio.gather(
            engine.execute_query_async(TOTAL_MEMBERSHIP_QUERY, limit=1),
            engine.execute_query_async(demand_utilization_query, limit=1),
            engine.execute_query_async(cases_per_hour_query, limit=1),
            engine.execute_query_async(inventory_volume_query, limit=1),
            engine.execute_query_async(avg_cycle_time_query, limit=1),
            engine.execute_query_async(AVAILABLE_FTE_QUERY, limit=1),
            engine.execute_query_async(loan_fte_query, limit=1),
            engine.execute_query_async(SHRINKAGE_QUERY, limit=1),
            engine.execute_query_async(out_of_sla_query, limit=1)
        )
        
        # Extract total membership
        total_membership = 0
        if total_records and len(total_records) > 0:
            total_membership = total_records[0].get("TOTAL_MEMBERSHIP", 0) or 0
        
        # Extract demand utilization percentage
        demand_utilization_percentage = None
        if demand_util_records and len(demand_util_records) > 0:
            demand_utilization_percentage = demand_util_records[0].get("DEMAND_UTILIZATION_PERCENTAGE")
        
        # Extract cases per hour
        cases_per_hour = None
        if cases_per_hour_records and len(cases_per_hour_records) > 0:
            cases_per_hour = cases_per_hour_records[0].get("CASES_PER_HOUR")
        
        # Extract inventory volume
        inventory_volume = None
        if inventory_volume_records and len(inventory_volume_records) > 0:
            inventory_volume = inventory_volume_records[0].get("INVENTORY_VOLUME")
        
        # Extract average cycle time
        avg_cycle_time_minutes = None
        if cycle_time_records and len(cycle_time_records) > 0:
            avg_cycle_time_minutes = cycle_time_records[0].get("AVG_CYCLE_TIME_MINUTES")
        
        # Extract available FTE
        available_fte = None
        if avail_fte_records and len(avail_fte_records) > 0:
            available_fte = avail_fte_records[0].get("AVAIL_FTE")
        
        # Extract loan FTE
        loan_fte = None
        if loan_fte_records and len(loan_fte_records) > 0:
            loan_fte = loan_fte_records[0].get("LOAN_FTE")
        
        # Extract shrinkage percentage
        shrinkage_percent = None
        if shrinkage_records and len(shrinkage_records) > 0:
            shrinkage_percent = shrinkage_records[0].get("CURRENT_SHRINKAGE_PERCENT")
        
        # Extract out-of-SLA metrics
        out_of_sla_count = None
        out_of_sla_pct = None
        if out_of_sla_records and len(out_of_sla_records) > 0:
            out_of_sla_count = out_of_sla_records[0].get("OUT_OF_SLA_COUNT")
            out_of_sla_pct = out_of_sla_records[0].get("OUT_OF_SLA_PCT")
        
        # Format cycle time as "X min Y sec"
        avg_cycle_time_formatted = None
        if avg_cycle_time_minutes is not None:
            total_seconds = int(avg_cycle_time_minutes * 60)
            minutes = total_seconds // 60
            seconds = total_seconds % 60
            avg_cycle_time_formatted = f"{minutes} min {seconds} sec"
        
        # Format all values as strings
        total_membership_str = str(total_membership) if total_membership is not None else "N/A"
        demand_util_str = f"{demand_utilization_percentage}" if demand_utilization_percentage is not None else "N/A"
        cases_per_hour_str = str(cases_per_hour) if cases_per_hour is not None else "N/A"
        inventory_volume_str = str(inventory_volume) if inventory_volume is not None else "N/A"
        available_fte_str = str(available_fte) if available_fte is not None else "N/A"
        loan_fte_str = str(loan_fte) if loan_fte is not None else "N/A"
        shrinkage_str = f"{shrinkage_percent}" if shrinkage_percent is not None else "N/A"
        out_of_sla_count_str = str(out_of_sla_count) if out_of_sla_count is not None else "N/A"
        out_of_sla_pct_str = f"{out_of_sla_pct}%" if out_of_sla_pct is not None else "N/A"
        
        logger.info(f"[WHAT_IF_ANALYSIS] Total membership: {total_membership_str}, Demand Util: {demand_util_str}, Cases/Hour: {cases_per_hour_str}, Inventory: {inventory_volume_str}, Avg Cycle Time: {avg_cycle_time_formatted}, Available FTE: {available_fte_str}, Loan FTE: {loan_fte_str}, Shrinkage: {shrinkage_str}, Out of SLA: {out_of_sla_count_str} ({out_of_sla_pct_str})")
        
        return WhatIfAnalysisResponse(
            status="success",
            total_membership=total_membership_str,
            demand_utilization_percentage=demand_util_str,
            standard_cases_per_hour=cases_per_hour_str,
            inventory_volume=inventory_volume_str,
            avg_cycle_time=avg_cycle_time_formatted if avg_cycle_time_formatted else "N/A",
            available_fte=available_fte_str,
            loan_fte=loan_fte_str,
            current_shrinkage_percent=shrinkage_str,
            out_of_sla_count=out_of_sla_count_str,
            out_of_sla_pct=out_of_sla_pct_str,
            message="Workforce IQ What-If Analysis data retrieved successfully"
        )
        
    except Exception as e:
        logger.error(f"[WHAT_IF_ANALYSIS] Error: {type(e).__name__}: {str(e)}", exc_info=True)
        
        # Return N/A values for all metrics in case of failure (best practice)
        return WhatIfAnalysisResponse(
            status="error",
            total_membership="N/A",
            demand_utilization_percentage="N/A",
            standard_cases_per_hour="N/A",
            inventory_volume="N/A",
            avg_cycle_time="N/A",
            available_fte="N/A",
            loan_fte="N/A",
            current_shrinkage_percent="N/A",
            out_of_sla_count="N/A",
            out_of_sla_pct="N/A",
            message=f"Failed to retrieve Workforce IQ What-If Analysis data: {str(e)}"
        )
