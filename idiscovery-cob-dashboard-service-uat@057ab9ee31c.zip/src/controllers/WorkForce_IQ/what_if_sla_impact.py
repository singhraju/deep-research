"""
What-If SLA Impact API for Workforce IQ.

This module provides the API endpoint for calculating current SLA metrics
and projecting the impact of scenario changes (FTE, cycle time, shrinkage).
"""

import logging
import asyncio
import hashlib
import json
import re
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse

import config
from db import SnowflakeConnectionManager
from schema import (
    WhatIfSLAImpactRequest,
    WhatIfSLAImpactResponse,
    WhatIfPreviousScenarioComparison,
    CurrentSLAMetrics,
    ProjectedSLAMetrics,
    SLAImpactAnalysis,
    WhatIfCurrentState,
)
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from services.openai_service import (
    get_openai_service,
    extract_completion_text,
    get_auth_token,
    call_openai_direct,
    build_openai_request_options,
)
from utils import cache_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workforce-iq", tags=["WorkForce_IQ"])
connection_manager = SnowflakeConnectionManager()

# Constants
DEFAULT_PRODUCTIVE_HOURS_PER_DAY = 6.5
SLA_RISK_THRESHOLD_HOURS = 72
FORBIDDEN_RECOMMENDATION_PATTERNS = (
    r"\bthroughput\b",
    r"\breceipts?\b",
    r"\bsla risk\b",
    r"\bout[- ]of[- ]sla\b",
    r"\bweekly capacity\b",
    r"\bbucket counts?\b",
    r"\beffective productive fte\b",
    r"\bcases? per hour\b",
    r"\bnet throughput\b",
    r"\bdaily throughput\b",
)
# Commentary fields (updated_scenario, projected_results_commentary) describe operational outcomes
# to executives and legitimately reference SLA exposure. Only exclude raw metric/backend terms.
FORBIDDEN_COMMENTARY_PATTERNS = (
    r"\bthroughput\b",
    r"\breceipts?\b",
    r"\bout[- ]of[- ]sla\b",
    r"\bweekly capacity\b",
    r"\bbucket counts?\b",
    r"\beffective productive fte\b",
    r"\bcases? per hour\b",
    r"\bnet throughput\b",
    r"\bdaily throughput\b",
)


# =============================================================================
# SQL QUERIES
# =============================================================================

WORKFORCE_INVENTORY_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PYSTATUSWORK,
        PXCREATEDATETIME,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
        AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake',
                             'Open-ReviewIntake', 'Pend', 'Pend-Decision')
        {{staffing_category_lob_filter}}
)
SELECT 
    COUNT(DISTINCT PYID) AS total_inventory_volume
FROM invntry_deduped
WHERE rn = 1
"""

WORKFORCE_SLA_RISK_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        EXTERNALDUEDATE,
        DATEDIFF('hour', CURRENT_TIMESTAMP, EXTERNALDUEDATE) AS hours_until_sla_breach,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
        AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                             'Open-ReviewIntake', 'Pend', 'Pend-Decision')
        {{staffing_category_lob_filter}}
)
SELECT 
    COUNT(*) AS total_backlog_items,
    SUM(CASE WHEN hours_until_sla_breach <= 72 AND hours_until_sla_breach > 0 THEN 1 ELSE 0 END) AS items_at_sla_risk,
    ROUND(
        (SUM(CASE WHEN hours_until_sla_breach <= 72 AND hours_until_sla_breach > 0 THEN 1 ELSE 0 END) * 100.0) / 
        NULLIF(COUNT(*), 0), 
        2
    ) AS sla_risk_pct
FROM invntry_deduped
WHERE rn = 1
    AND EXTERNALDUEDATE IS NOT NULL
"""

WORKFORCE_OUT_OF_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        EXTERNALDUEDATE,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
        AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                             'Open-ReviewIntake', 'Pend', 'Pend-Decision')
        {{staffing_category_lob_filter}}
)
SELECT 
    COUNT(*) AS total_open_items,
    SUM(CASE WHEN CURRENT_DATE > EXTERNALDUEDATE THEN 1 ELSE 0 END) AS elv_out_of_sla_count,
    ROUND(
        (SUM(CASE WHEN CURRENT_DATE > EXTERNALDUEDATE THEN 1 ELSE 0 END) * 100.0) / 
        NULLIF(COUNT(*), 0), 
        2
    ) AS elv_out_of_sla_pct
FROM invntry_deduped
WHERE rn = 1
    AND EXTERNALDUEDATE IS NOT NULL
"""

WORKFORCE_COUNT_BY_SLA_QUERY = f"""
WITH invntry_deduped AS (
    SELECT
        PYID,
        PXCREATEDATETIME,
        EXTERNALDUEDATE,
        DATEDIFF('second', CURRENT_TIMESTAMP(), EXTERNALDUEDATE) / 86400.0 AS days_until_breach,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY RETIME DESC NULLS LAST, PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYRESOLVEDTIMESTAMP IS NULL
        AND PYSTATUSWORK IN ('Assigned', 'New', 'Open-CAQHPortal', 'Open-CaptureIntake', 
                             'Open-ReviewIntake', 'Pend', 'Pend-Decision')
        {{staffing_category_lob_filter}}
),
sla_buckets AS (
    SELECT 'Out of SLA' AS sla_bucket, 0 AS sort_order
    UNION ALL SELECT '00-02', 1
    UNION ALL SELECT '03-05', 2
    UNION ALL SELECT '06-10', 3
    UNION ALL SELECT '11-15', 4
    UNION ALL SELECT '16-21', 5
    UNION ALL SELECT '22-30', 6
    UNION ALL SELECT '30+', 7
),
item_counts AS (
    SELECT 
        CASE 
            WHEN days_until_breach < 0 THEN 'Out of SLA'
            WHEN days_until_breach >= 0 AND days_until_breach < 3 THEN '00-02'
            WHEN days_until_breach >= 3 AND days_until_breach < 6 THEN '03-05'
            WHEN days_until_breach >= 6 AND days_until_breach < 11 THEN '06-10'
            WHEN days_until_breach >= 11 AND days_until_breach < 16 THEN '11-15'
            WHEN days_until_breach >= 16 AND days_until_breach < 22 THEN '16-21'
            WHEN days_until_breach >= 22 AND days_until_breach <= 30 THEN '22-30'
            WHEN days_until_breach > 30 THEN '30+'
            ELSE 'Unknown'
        END AS sla_bucket,
        COUNT(*) AS work_items
    FROM invntry_deduped
    WHERE rn = 1
        AND EXTERNALDUEDATE IS NOT NULL
    GROUP BY 
        CASE 
            WHEN days_until_breach < 0 THEN 'Out of SLA'
            WHEN days_until_breach >= 0 AND days_until_breach < 3 THEN '00-02'
            WHEN days_until_breach >= 3 AND days_until_breach < 6 THEN '03-05'
            WHEN days_until_breach >= 6 AND days_until_breach < 11 THEN '06-10'
            WHEN days_until_breach >= 11 AND days_until_breach < 16 THEN '11-15'
            WHEN days_until_breach >= 16 AND days_until_breach < 22 THEN '16-21'
            WHEN days_until_breach >= 22 AND days_until_breach <= 30 THEN '22-30'
            WHEN days_until_breach > 30 THEN '30+'
            ELSE 'Unknown'
        END
)
SELECT 
    b.sla_bucket,
    b.sort_order,
    COALESCE(c.work_items, 0) AS work_items
FROM sla_buckets b
LEFT JOIN item_counts c ON b.sla_bucket = c.sla_bucket
ORDER BY b.sort_order
"""

WORKFORCE_PRODUCTIVE_HOURS_QUERY = f"""
WITH productive_time_data AS (
    SELECT
        USERID,
        LOGINDATE,
        TOTALSYSTEMTIME,
        CASE
            WHEN REGEXP_LIKE(TRIM(PRODUCTIVETIME), '^[0-9]{1,2}:[0-9]{2}:[0-9]{2}$') THEN
                TRY_TO_NUMBER(SPLIT_PART(PRODUCTIVETIME, ':', 1)) * 3600 +
                TRY_TO_NUMBER(SPLIT_PART(PRODUCTIVETIME, ':', 2)) * 60 +
                TRY_TO_NUMBER(SPLIT_PART(PRODUCTIVETIME, ':', 3))
            ELSE NULL
        END AS productive_time_seconds
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    WHERE LOGINDATE >= DATEADD(day, -90, CURRENT_DATE)
        AND LOGINDATE < CURRENT_DATE
        AND PYACCESSGROUP LIKE '%FrontLine%'
        {{staffing_category_filter}}
)
SELECT 
    AVG(productive_time_seconds) / 3600.0 AS avg_productive_hours_per_day,
    COUNT(DISTINCT USERID) AS fte_count,
    COUNT(*) AS total_login_days
FROM productive_time_data
WHERE productive_time_seconds > 0
    AND TOTALSYSTEMTIME > 0
"""

WORKFORCE_DAILY_RECEIPTS_QUERY = f"""
SELECT 
    AVG(daily_receipts) AS avg_daily_receipts
FROM (
    SELECT 
        DATE(PXCREATEDATETIME) AS receipt_date,
        COUNT(DISTINCT PYID) AS daily_receipts
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PXCREATEDATETIME >= DATEADD(day, -7, CURRENT_DATE)
        AND PXCREATEDATETIME < CURRENT_DATE
        {{staffing_category_lob_filter}}
    GROUP BY DATE(PXCREATEDATETIME)
) daily_counts
"""


# =============================================================================
# FILTER HELPER FUNCTIONS
# =============================================================================

def build_staffing_category_lob_filter(staffing_category: Optional[List[str]] = None) -> str:
    """Build LOB filter using staffing category crosswalk."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    category_values = "', '".join([str(c).strip() for c in staffing_category])
    return f"""AND LOB IN (
        SELECT DISTINCT LOB 
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_STAFFING_CATEGORY_XWALK
        WHERE STAFFING_CATEGORY IN ('{category_values}')
    )"""


def build_staffing_category_filter_for_user_profile(staffing_category: Optional[List[str]] = None) -> str:
    """Build staffing category filter for COB_AI_USER_PROFILE table."""
    if not staffing_category or len(staffing_category) == 0:
        return ""
    
    category_values = "', '".join([str(c).strip() for c in staffing_category])
    return f"AND STAFFINGCATEGORY IN ('{category_values}')"


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

async def get_productive_hours(
    staffing_category: Optional[List[str]] = None
) -> float:
    """
    Get average productive hours per FTE per day from Fuse data (90-day average).
    
    Args:
        staffing_category: Optional filter by staffing category
        
    Returns:
        Average productive hours per day (default: 6.5 if query fails)
    """
    try:
        staffing_filter = build_staffing_category_filter_for_user_profile(staffing_category)
        query = WORKFORCE_PRODUCTIVE_HOURS_QUERY.replace("{staffing_category_filter}", staffing_filter)
        
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1)
        
        if results and len(results) > 0 and results[0].get('AVG_PRODUCTIVE_HOURS_PER_DAY'):
            productive_hours = float(results[0]['AVG_PRODUCTIVE_HOURS_PER_DAY'])
            logger.info(f"Productive hours from Fuse data: {productive_hours:.2f} hours/day")
            return round(productive_hours, 2)
        else:
            logger.warning(f"No productive hours data found, using default {DEFAULT_PRODUCTIVE_HOURS_PER_DAY} hours")
            return DEFAULT_PRODUCTIVE_HOURS_PER_DAY
            
    except Exception as e:
        logger.error(f"Error fetching productive hours: {str(e)}")
        return DEFAULT_PRODUCTIVE_HOURS_PER_DAY


async def get_daily_receipts(
    staffing_category: Optional[List[str]] = None
) -> float:
    """
    Get average daily receipts (7-day average).
    
    Args:
        staffing_category: Optional filter by staffing category
        
    Returns:
        Average daily receipts
    """
    try:
        lob_filter = build_staffing_category_lob_filter(staffing_category)
        query = WORKFORCE_DAILY_RECEIPTS_QUERY.replace("{staffing_category_lob_filter}", lob_filter)
        
        engine = connection_manager.get_engine()
        results = await engine.execute_query_async(query, limit=1)
        
        if results and len(results) > 0 and results[0].get('AVG_DAILY_RECEIPTS'):
            daily_receipts = float(results[0]['AVG_DAILY_RECEIPTS'])
            logger.info(f"Average daily receipts (7-day): {daily_receipts:.2f}")
            return round(daily_receipts, 2)
        else:
            logger.warning("No daily receipts data found, using 0")
            return 0.0
            
    except Exception as e:
        logger.error(f"Error fetching daily receipts: {str(e)}")
        return 0.0


def calculate_effective_fte(
    available_fte: float,
    loan_fte: float,
    shrinkage_percent: float
) -> float:
    """
    Calculate effective productive FTE.
    
    Formula: max(0, available_fte - loan_fte - (available_fte Ã— shrinkage / 100))
    Floored at 0 to prevent negative values flowing into throughput calculations.
    """
    effective_fte = available_fte - loan_fte - (available_fte * shrinkage_percent / 100)
    return round(max(0.0, effective_fte), 2)


def calculate_cases_per_hour(cycle_time_minutes: float) -> float:
    """
    Calculate cases per hour from cycle time.
    
    Formula: 60 / cycle_time_minutes
    """
    if cycle_time_minutes <= 0:
        return 0.0
    return round(60 / cycle_time_minutes, 2)


def calculate_daily_throughput(
    effective_fte: float,
    productive_hours_per_day: float,
    cycle_time_minutes: float
) -> int:
    """
    Calculate daily processing throughput.
    
    Formula: (effective_fte Ã— productive_minutes_per_day) / cycle_time_minutes
    """
    if cycle_time_minutes <= 0:
        return 0
    
    productive_minutes_per_day = productive_hours_per_day * 60
    throughput = (effective_fte * productive_minutes_per_day) / cycle_time_minutes
    return int(throughput)


def calculate_days_to_clear(
    inventory_volume: int,
    net_throughput: float
) -> Optional[float]:
    """
    Calculate days to clear backlog.
    
    Returns None if net throughput is <= 0 (backlog growing).
    """
    if net_throughput <= 0:
        return None
    
    return round(inventory_volume / net_throughput, 1)


def generate_cache_key(staffing_category: List[str], current_state: WhatIfCurrentState) -> str:
    """Generate cache key for current SLA metrics.

    Includes inventory_volume so that two users with different backlog sizes
    but identical FTE/shrinkage/cycle-time don't share a stale cache entry.
    """
    cache_inputs = {
        "staffing_category": sorted(staffing_category),
        "available_fte": round(float(current_state.available_fte), 4),
        "loan_fte": round(float(current_state.loan_fte), 4),
        "avg_cycle_time_minutes": round(float(current_state.avg_cycle_time_minutes), 4),
        "current_shrinkage_percent": round(float(current_state.current_shrinkage_percent), 4),
        "inventory_volume": int(current_state.inventory_volume),
    }
    hash_str = hashlib.md5(json.dumps(cache_inputs, sort_keys=True).encode()).hexdigest()[:12]
    return f"workforce_sla:{hash_str}"


def generate_previous_run_cache_key(user_id: str, staffing_category: List[str]) -> str:
    """Generate cache key for previous What-If scenario run per user+staffing scope."""
    category_str = ",".join(sorted(staffing_category))
    hash_str = hashlib.md5(f"{user_id}:{category_str}".encode()).hexdigest()[:8]
    return f"workforce_whatif_prev:{hash_str}"


# =============================================================================
# CURRENT SLA CALCULATION
# =============================================================================

async def calculate_current_sla(
    staffing_category: List[str],
    current_state: WhatIfCurrentState,
    productive_hours_per_day: float,
    daily_receipts: float
) -> tuple[CurrentSLAMetrics, bool]:
    """
    Calculate current SLA metrics from database.

    Executes queries in parallel for performance.

    Returns:
        Tuple of (CurrentSLAMetrics, is_complete) where is_complete=False
        means one or more DB queries failed and defaults were used.
        Callers must NOT cache a degraded result.
    """
    logger.info(f"Calculating current SLA for staffing categories: {staffing_category}")

    lob_filter = build_staffing_category_lob_filter(staffing_category)

    inventory_query = WORKFORCE_INVENTORY_QUERY.replace("{staffing_category_lob_filter}", lob_filter)
    sla_risk_query = WORKFORCE_SLA_RISK_QUERY.replace("{staffing_category_lob_filter}", lob_filter)
    out_of_sla_query = WORKFORCE_OUT_OF_SLA_QUERY.replace("{staffing_category_lob_filter}", lob_filter)
    count_by_sla_query = WORKFORCE_COUNT_BY_SLA_QUERY.replace("{staffing_category_lob_filter}", lob_filter)

    engine = connection_manager.get_engine()
    try:
        results = await asyncio.gather(
            engine.execute_query_async(inventory_query, limit=1),
            engine.execute_query_async(sla_risk_query, limit=1),
            engine.execute_query_async(out_of_sla_query, limit=1),
            engine.execute_query_async(count_by_sla_query, limit=100),
            return_exceptions=True
        )

        inventory_result, sla_risk_result, out_of_sla_result, count_by_sla_result = results

        query_names = ["inventory", "sla_risk", "out_of_sla", "count_by_sla"]
        failed_queries = [i for i, r in enumerate(results) if isinstance(r, Exception)]
        for i in failed_queries:
            logger.error("SLA query '%s' failed: %s", query_names[i], str(results[i]))

        # is_complete=False signals the caller not to cache this result
        is_complete = len(failed_queries) == 0

        # Parse results — failed queries default to 0 so the response can still be returned
        # but callers must treat is_complete=False as non-cacheable
        db_inventory_volume = (
            int(inventory_result[0].get('TOTAL_INVENTORY_VOLUME', 0))
            if not isinstance(inventory_result, Exception) and inventory_result
            else 0
        )
        inventory_volume = int(current_state.inventory_volume)
        if db_inventory_volume != inventory_volume:
            logger.info(
                "Normalizing What-If inventory volume to request value for UI consistency: request=%d, db=%d",
                inventory_volume,
                db_inventory_volume,
            )

        sla_risk_inventory = (
            int(sla_risk_result[0].get('ITEMS_AT_SLA_RISK', 0))
            if not isinstance(sla_risk_result, Exception) and sla_risk_result
            else 0
        )

        out_of_sla_inventory = (
            int(out_of_sla_result[0].get('ELV_OUT_OF_SLA_COUNT', 0))
            if not isinstance(out_of_sla_result, Exception) and out_of_sla_result
            else 0
        )

        if inventory_volume <= 0:
            sla_risk_inventory = 0
            out_of_sla_inventory = 0
        else:
            if sla_risk_inventory > inventory_volume:
                logger.warning(
                    "Clamping SLA risk inventory to visible inventory volume for What-If output consistency: risk=%d, inventory=%d",
                    sla_risk_inventory,
                    inventory_volume,
                )
            if out_of_sla_inventory > inventory_volume:
                logger.warning(
                    "Clamping out-of-SLA inventory to visible inventory volume for What-If output consistency: out_of_sla=%d, inventory=%d",
                    out_of_sla_inventory,
                    inventory_volume,
                )
            sla_risk_inventory = min(sla_risk_inventory, inventory_volume)
            out_of_sla_inventory = min(out_of_sla_inventory, inventory_volume)

        sla_risk_pct = (
            (sla_risk_inventory / inventory_volume * 100)
            if inventory_volume > 0 else 0.0
        )
        out_of_sla_pct = (
            (out_of_sla_inventory / inventory_volume * 100)
            if inventory_volume > 0 else 0.0
        )

        counts_by_sla = (
            [
                {
                    "sla_bucket": row.get('SLA_BUCKET', 'Unknown'),
                    "work_items": int(row.get('WORK_ITEMS', 0))
                }
                for row in count_by_sla_result
            ]
            if not isinstance(count_by_sla_result, Exception) and count_by_sla_result
            else []
        )

        effective_fte = calculate_effective_fte(
            current_state.available_fte,
            current_state.loan_fte,
            current_state.current_shrinkage_percent
        )

        cases_per_hour = calculate_cases_per_hour(current_state.avg_cycle_time_minutes)

        daily_throughput = calculate_daily_throughput(
            effective_fte,
            productive_hours_per_day,
            current_state.avg_cycle_time_minutes
        )

        net_throughput = daily_throughput - daily_receipts

        days_to_clear = calculate_days_to_clear(inventory_volume, net_throughput)

        logger.info(
            "Current SLA calculated: inventory=%d, risk=%.2f%%, throughput=%d, complete=%s",
            inventory_volume, sla_risk_pct, daily_throughput, is_complete,
        )

        return CurrentSLAMetrics(
            inventory_volume=inventory_volume,
            effective_fte=effective_fte,
            productive_hours_per_day=productive_hours_per_day,
            cases_per_hour=cases_per_hour,
            daily_throughput=daily_throughput,
            daily_receipts=daily_receipts,
            net_throughput=round(net_throughput, 2),
            days_to_clear=days_to_clear,
            sla_risk_inventory=sla_risk_inventory,
            sla_risk_pct=round(sla_risk_pct, 2),
            out_of_sla_inventory=out_of_sla_inventory,
            out_of_sla_pct=round(out_of_sla_pct, 2),
            counts_by_sla=counts_by_sla
        ), is_complete

    except Exception as e:
        logger.error("Error calculating current SLA: %s", str(e))
        raise HTTPException(status_code=500, detail=f"Failed to calculate current SLA: {str(e)}")


# =============================================================================
# PROJECTION LOGIC
# =============================================================================

def calculate_projected_sla(
    current_sla: CurrentSLAMetrics,
    current_state: WhatIfCurrentState,
    scenario_changes: Any
) -> tuple[ProjectedSLAMetrics, SLAImpactAnalysis]:
    """
    Calculate projected SLA metrics and impact analysis.
    
    Returns:
        Tuple of (projected_sla, impact_analysis)
    """
    logger.info("Calculating projected SLA with scenario changes")
    
    # Apply scenario changes
    projected_membership = current_state.total_membership + scenario_changes.membership_change
    new_available_fte = current_state.available_fte + scenario_changes.fte_change
    new_loan_fte = current_state.loan_fte + scenario_changes.loan_fte_change
    new_inventory_volume = current_state.inventory_volume + scenario_changes.inventory_volume_change
    new_cycle_time = current_state.avg_cycle_time_minutes + scenario_changes.cycle_time_change
    new_shrinkage = current_state.current_shrinkage_percent + scenario_changes.shrinkage_change
    
    # Calculate projected metrics
    projected_effective_fte = calculate_effective_fte(
        new_available_fte,
        new_loan_fte,
        new_shrinkage
    )
    
    projected_cases_per_hour = calculate_cases_per_hour(new_cycle_time)
    
    projected_daily_throughput = calculate_daily_throughput(
        projected_effective_fte,
        current_sla.productive_hours_per_day,
        new_cycle_time
    )
    
    projected_daily_receipts = current_sla.daily_receipts
    if current_state.total_membership > 0:
        projected_daily_receipts = round(
            current_sla.daily_receipts * (projected_membership / current_state.total_membership),
            2,
        )

    projected_net_throughput = projected_daily_throughput - projected_daily_receipts
    
    projected_days_to_clear = calculate_days_to_clear(
        new_inventory_volume,
        projected_net_throughput
    )
    
    # Calculate throughput improvement
    throughput_increase = projected_daily_throughput - current_sla.daily_throughput
    throughput_increase_pct = (
        (throughput_increase / current_sla.daily_throughput * 100)
        if current_sla.daily_throughput > 0 else 0.0
    )
    
    # Project SLA risk reduction (average of two methods, each symmetrically clamped to [-0.5, 0.5])
    # Method 1: Based on throughput improvement — negative when throughput decreases
    raw_m1 = throughput_increase_pct / 100 if current_sla.daily_throughput > 0 else 0.0
    improvement_factor_method1 = max(-0.50, min(0.50, raw_m1))

    # Method 2: Based on days-to-clear improvement — negative when scenario worsens clearance
    improvement_factor_method2 = 0.0
    if current_sla.days_to_clear and projected_days_to_clear:
        raw_m2 = (current_sla.days_to_clear - projected_days_to_clear) / current_sla.days_to_clear
        improvement_factor_method2 = max(-0.50, min(0.50, raw_m2))

    # Use method1 alone when method2 has no data (e.g. backlog growing / zero inventory);
    # averaging with 0.0 would silently halve the signal from method1.
    if improvement_factor_method2 == 0.0:
        improvement_factor = improvement_factor_method1
    else:
        improvement_factor = (improvement_factor_method1 + improvement_factor_method2) / 2

    # Project SLA risk — allow values above current to represent genuine worsening scenarios
    # Floor at 0 only (no ceiling) so the UI receives truthful directional data
    projected_sla_risk_inventory = min(
        new_inventory_volume,
        max(0, int(current_sla.sla_risk_inventory * (1 - improvement_factor)))
    )
    # NOTE: The baseline SQL filters sla_risk_inventory over items WHERE EXTERNALDUEDATE IS NOT NULL,
    # while inventory_volume counts all open items. The projected percentage below uses the projected
    # visible inventory volume so the UI reflects the scenario-adjusted backlog, but the denominator
    # is still wider than the SLA-eligible population. Fixing this requires a SQL-level change to
    # return a due-date-filtered total alongside the risk count.
    projected_sla_risk_pct = (
        (projected_sla_risk_inventory / new_inventory_volume * 100)
        if new_inventory_volume > 0 else 0.0
    )

    # Project out of SLA — same: allow above-current values, floor at 0
    projected_out_of_sla_inventory = min(
        new_inventory_volume,
        max(0, int(current_sla.out_of_sla_inventory * (1 - improvement_factor)))
    )
    projected_out_of_sla_pct = (
        (projected_out_of_sla_inventory / new_inventory_volume * 100)
        if new_inventory_volume > 0 else 0.0
    )

    # Impact fields: negative means worsening — callers and UI must handle both signs
    items_saved_from_risk = current_sla.sla_risk_inventory - projected_sla_risk_inventory
    sla_risk_reduction_pct = current_sla.sla_risk_pct - projected_sla_risk_pct
    time_saved_days = (
        (current_sla.days_to_clear - projected_days_to_clear)
        if current_sla.days_to_clear and projected_days_to_clear else None
    )
    out_of_sla_reduction = current_sla.out_of_sla_inventory - projected_out_of_sla_inventory
    
    logger.info(f"Projected SLA: throughput increase={throughput_increase_pct:.1f}%, items saved={items_saved_from_risk}")
    
    projected_sla = ProjectedSLAMetrics(
        inventory_volume=new_inventory_volume,
        effective_fte=projected_effective_fte,
        productive_hours_per_day=current_sla.productive_hours_per_day,
        cases_per_hour=projected_cases_per_hour,
        daily_throughput=projected_daily_throughput,
        daily_receipts=projected_daily_receipts,
        net_throughput=round(projected_net_throughput, 2),
        days_to_clear=projected_days_to_clear,
        sla_risk_inventory=projected_sla_risk_inventory,
        sla_risk_pct=round(projected_sla_risk_pct, 2),
        out_of_sla_inventory=projected_out_of_sla_inventory,
        out_of_sla_pct=round(projected_out_of_sla_pct, 2)
    )
    
    impact = SLAImpactAnalysis(
        throughput_increase=throughput_increase,
        throughput_increase_pct=round(throughput_increase_pct, 2),
        items_saved_from_risk=items_saved_from_risk,
        sla_risk_reduction_pct=round(sla_risk_reduction_pct, 2),
        time_saved_days=round(time_saved_days, 1) if time_saved_days is not None else None,
        out_of_sla_reduction=out_of_sla_reduction
    )
    
    return projected_sla, impact


def generate_fallback_summary(
    current_state: WhatIfCurrentState,
    current_sla: CurrentSLAMetrics,
    projected_sla: ProjectedSLAMetrics,
    impact: SLAImpactAnalysis,
    scenario_changes: Any
) -> str:
    return build_suggestions_text(
        current_state,
        current_sla,
        projected_sla,
        impact,
        scenario_changes,
        None,
    )[0]


def _build_backlog_clearance_message(
    current_sla: CurrentSLAMetrics,
    projected_sla: ProjectedSLAMetrics,
    impact: SLAImpactAnalysis,
) -> Optional[str]:
    current_growing = current_sla.days_to_clear is None
    projected_growing = projected_sla.days_to_clear is None

    if current_growing and projected_growing:
        return "Backlog clearance time remains undefined because backlog is currently growing and would continue to grow under this scenario."
    if current_growing:
        return "Backlog clearance time is undefined today, but this scenario brings processing capacity above incoming volume and restores a measurable clearance path."
    if projected_growing:
        return "Backlog clearance time becomes undefined under this scenario because projected processing capacity falls below incoming volume."
    if impact.time_saved_days is not None and impact.time_saved_days > 0:
        return f"Backlog clearance improves by an estimated {impact.time_saved_days:.1f} days."
    if impact.time_saved_days is not None and impact.time_saved_days < 0:
        return f"Backlog clearance worsens by an estimated {abs(impact.time_saved_days):.1f} days under this scenario."
    if impact.time_saved_days == 0:
        return "Backlog clearance time is effectively unchanged under this scenario."
    return None


def _sanitize_recommendation_line(line: Any) -> Optional[str]:
    if line is None:
        return None
    cleaned = str(line).strip()
    cleaned = cleaned.replace("**", "")
    return cleaned or None


def _contains_forbidden_recommendation_content(line: str) -> bool:
    lowered = line.strip().lower()
    return any(re.search(pattern, lowered) for pattern in FORBIDDEN_RECOMMENDATION_PATTERNS)


def _extract_recommendation_sections_from_llm(content: str) -> Optional[Dict[str, str]]:
    payload_text = content.strip()
    if payload_text.startswith("```"):
        start_idx = payload_text.find("{")
        end_idx = payload_text.rfind("}")
        if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
            payload_text = payload_text[start_idx:end_idx + 1]

    try:
        parsed = json.loads(payload_text)
        if isinstance(parsed, dict):
            updated_scenario = _sanitize_recommendation_line(parsed.get("updated_scenario"))
            projected_results_commentary = _sanitize_recommendation_line(parsed.get("projected_results_commentary"))
            if updated_scenario and any(re.search(p, updated_scenario.strip().lower()) for p in FORBIDDEN_COMMENTARY_PATTERNS):
                logger.warning("Discarding What-If updated_scenario containing forbidden content: %s", updated_scenario)
                updated_scenario = None
            if projected_results_commentary and any(re.search(p, projected_results_commentary.strip().lower()) for p in FORBIDDEN_COMMENTARY_PATTERNS):
                logger.warning(
                    "Discarding What-If projected_results_commentary containing forbidden content: %s",
                    projected_results_commentary,
                )
                projected_results_commentary = None
            if updated_scenario or projected_results_commentary:
                return {
                    "updated_scenario": updated_scenario or "",
                    "projected_results_commentary": projected_results_commentary or "",
                }
    except json.JSONDecodeError:
        sanitized_text = _sanitize_recommendation_line(payload_text)
        if sanitized_text:
            return {
                "updated_scenario": sanitized_text,
                "projected_results_commentary": "",
            }
    return None


def _format_metric_value(value: float) -> str:
    return f"{value:g}"


def _format_cycle_time_minutes(value: float) -> str:
    total_seconds = max(0, int(round(value * 60)))
    minutes = total_seconds // 60
    seconds = total_seconds % 60
    return f"{minutes} min {seconds:02d} sec"


def _format_count(value: float) -> str:
    return f"{int(round(value)):,}"


def _join_with_and(parts: List[str]) -> str:
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    if len(parts) == 2:
        return f"{parts[0]} and {parts[1]}"
    return ", ".join(parts[:-1]) + f", and {parts[-1]}"


def _build_updated_scenario_fallback(
    current_state: WhatIfCurrentState,
    impact: SLAImpactAnalysis,
    scenario_changes: Any,
) -> str:
    projected_available_fte = current_state.available_fte + scenario_changes.fte_change
    projected_loan_fte = current_state.loan_fte + scenario_changes.loan_fte_change
    projected_membership = current_state.total_membership + scenario_changes.membership_change
    projected_inventory = current_state.inventory_volume + scenario_changes.inventory_volume_change
    projected_cycle_time = current_state.avg_cycle_time_minutes + scenario_changes.cycle_time_change
    projected_shrinkage = current_state.current_shrinkage_percent + scenario_changes.shrinkage_change

    changes: List[str] = []
    if scenario_changes.fte_change != 0:
        changes.append(
            f"Available FTE {'increases' if scenario_changes.fte_change > 0 else 'decreases'} by {_format_metric_value(abs(scenario_changes.fte_change))} to {_format_metric_value(projected_available_fte)}."
        )
    if scenario_changes.loan_fte_change != 0:
        changes.append(
            f"Loan FTE {'increases' if scenario_changes.loan_fte_change > 0 else 'decreases'} by {_format_metric_value(abs(scenario_changes.loan_fte_change))} to {_format_metric_value(projected_loan_fte)}."
        )
    if scenario_changes.membership_change != 0:
        changes.append(
            f"Membership {'increases' if scenario_changes.membership_change > 0 else 'decreases'} by {_format_count(abs(scenario_changes.membership_change))} to {_format_count(projected_membership)}."
        )
    if scenario_changes.inventory_volume_change != 0:
        changes.append(
            f"Inventory volume {'increases' if scenario_changes.inventory_volume_change > 0 else 'decreases'} by {_format_count(abs(scenario_changes.inventory_volume_change))} to {_format_count(projected_inventory)} items."
        )
    if scenario_changes.cycle_time_change != 0:
        changes.append(
            f"Cycle time {'improves' if scenario_changes.cycle_time_change < 0 else 'worsens'} by {_format_metric_value(abs(scenario_changes.cycle_time_change))} minutes to {_format_cycle_time_minutes(projected_cycle_time)}."
        )
    if scenario_changes.shrinkage_change != 0:
        changes.append(
            f"Shrinkage {'improves' if scenario_changes.shrinkage_change < 0 else 'increases'} by {_format_metric_value(abs(scenario_changes.shrinkage_change))} points to {_format_metric_value(projected_shrinkage)}%."
        )

    if changes:
        return "\n".join(changes)
    else:
        return "No scenario changes were applied."


def _build_projected_results_fallback(
    current_sla: CurrentSLAMetrics,
    projected_sla: ProjectedSLAMetrics,
    impact: SLAImpactAnalysis,
) -> str:
    if impact.throughput_increase > 0 and projected_sla.out_of_sla_inventory < current_sla.out_of_sla_inventory:
        return "Faster projected processing helps slow inventory aging and reduces the share of work drifting deeper into backlog."
    if impact.throughput_increase > 0:
        return "Projected processing conditions improve, which should help absorb incoming work more effectively than the current baseline."
    if impact.throughput_increase < 0:
        return "Projected processing conditions weaken, increasing the risk of further backlog aging under this scenario."
    return "Projected processing conditions remain close to the current baseline under this scenario."


def _build_impact_summary_line(
    current_sla: CurrentSLAMetrics,
    projected_sla: ProjectedSLAMetrics,
    impact: SLAImpactAnalysis,
) -> str:
    if projected_sla.sla_risk_inventory < current_sla.sla_risk_inventory:
        risk_direction = (
            f"projected SLA Risk Inventory decreases from {_format_count(current_sla.sla_risk_inventory)} "
            f"to approximately {_format_count(projected_sla.sla_risk_inventory)} items"
        )
    elif projected_sla.sla_risk_inventory > current_sla.sla_risk_inventory:
        risk_direction = (
            f"projected SLA Risk Inventory increases from {_format_count(current_sla.sla_risk_inventory)} "
            f"to approximately {_format_count(projected_sla.sla_risk_inventory)} items"
        )
    else:
        risk_direction = (
            f"projected SLA Risk Inventory remains near {_format_count(projected_sla.sla_risk_inventory)} items"
        )

    if impact.items_saved_from_risk > 0:
        risk_delta = f"reducing at-risk volume by about {_format_count(impact.items_saved_from_risk)} items"
    elif impact.items_saved_from_risk < 0:
        risk_delta = f"increasing at-risk volume by about {_format_count(abs(impact.items_saved_from_risk))} items"
    else:
        risk_delta = "keeping at-risk volume broadly unchanged"

    if impact.sla_risk_reduction_pct > 0:
        risk_pct = f" and improving SLA risk by {impact.sla_risk_reduction_pct:g} percentage points"
    elif impact.sla_risk_reduction_pct < 0:
        risk_pct = f" and worsening SLA risk by {abs(impact.sla_risk_reduction_pct):g} percentage points"
    else:
        risk_pct = ""

    if impact.out_of_sla_reduction > 0:
        out_of_sla_phrase = f"Projected out-of-SLA inventory also decreases by {_format_count(impact.out_of_sla_reduction)} items."
    elif impact.out_of_sla_reduction < 0:
        out_of_sla_phrase = f"Projected out-of-SLA inventory increases by {_format_count(abs(impact.out_of_sla_reduction))} items."
    else:
        out_of_sla_phrase = "Projected out-of-SLA inventory remains broadly unchanged."

    return f"Impact: {risk_direction}, {risk_delta}{risk_pct}. {out_of_sla_phrase}"


def build_suggestions_text(
    current_state: WhatIfCurrentState,
    current_sla: CurrentSLAMetrics,
    projected_sla: ProjectedSLAMetrics,
    impact: SLAImpactAnalysis,
    scenario_changes: Any,
    recommendation_sections: Optional[Dict[str, str]],
) -> tuple[str, bool]:
    projected_results_commentary = None
    if recommendation_sections:
        projected_results_commentary = _sanitize_recommendation_line(recommendation_sections.get("projected_results_commentary"))

    updated_scenario_text = _build_updated_scenario_fallback(current_state, impact, scenario_changes)
    if not projected_results_commentary:
        projected_results_commentary = _build_projected_results_fallback(current_sla, projected_sla, impact)

    # Section 1 – current context (single line)
    current_inventory_context = (
        "## Current Inventory Context\n"
        f"Current inventory volume is {_format_count(current_state.inventory_volume)} items. "
        f"Historically, approximately {round(current_sla.sla_risk_pct, 1):g}% of inventory enters SLA risk status."
    )

    # Section 2 – Previous Scenario (labelled lines, no bullet prefix)
    previous_scenario_lines = [
        f"SLA Risk Inventory: {_format_count(current_sla.sla_risk_inventory)} items",
        f"Available FTE: {_format_metric_value(current_state.available_fte)}",
        f"Cycle Time: {_format_cycle_time_minutes(current_state.avg_cycle_time_minutes)}",
    ]
    previous_scenario_section = "## Previous Scenario\n" + "\n".join(previous_scenario_lines)

    # Section 3 – Updated Scenario (AI narrative or fallback sentence)
    updated_scenario_section = "## Updated Scenario\n" + updated_scenario_text

    # Section 4 – Projected Results (deterministic bullet lines + AI commentary)
    if projected_sla.sla_risk_inventory < current_sla.sla_risk_inventory:
        risk_line = (
            f"Estimated SLA Risk Inventory: reduced from {_format_count(current_sla.sla_risk_inventory)} "
            f"to approximately {_format_count(projected_sla.sla_risk_inventory)} items"
        )
    elif projected_sla.sla_risk_inventory > current_sla.sla_risk_inventory:
        risk_line = (
            f"Estimated SLA Risk Inventory: increased from {_format_count(current_sla.sla_risk_inventory)} "
            f"to approximately {_format_count(projected_sla.sla_risk_inventory)} items"
        )
    else:
        risk_line = f"Estimated SLA Risk Inventory: remains near {_format_count(projected_sla.sla_risk_inventory)} items"

    if impact.items_saved_from_risk > 0:
        delta_line = f"At-Risk Item Reduction: approximately {_format_count(impact.items_saved_from_risk)} items"
    elif impact.items_saved_from_risk < 0:
        delta_line = f"At-Risk Item Increase: approximately {_format_count(abs(impact.items_saved_from_risk))} items"
    else:
        delta_line = "At-Risk Item Count: remains broadly unchanged under this scenario"

    if projected_results_commentary:
        projected_results_commentary = re.sub(r"^\s*[-*]\s+", "", projected_results_commentary)

    projected_results_lines = [risk_line, delta_line, projected_results_commentary]
    clearance_line = _build_backlog_clearance_message(current_sla, projected_sla, impact)
    if clearance_line:
        projected_results_lines.append(f"Backlog Clearance: {clearance_line}")
    projected_results_section = "## Projected Results\n" + "\n".join(projected_results_lines)

    sections = [
        current_inventory_context,
        previous_scenario_section,
        updated_scenario_section,
        projected_results_section,
    ]
    return "\n\n".join(sections), bool(recommendation_sections)


def _model_payload(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump()
    return value


_LLM_STRIP_FIELDS = frozenset({
    "effective_fte",
    "cases_per_hour",
    "daily_throughput",
    "productive_hours_per_day",
    "daily_receipts",
    "net_throughput",
    "days_to_clear",
    "out_of_sla_inventory",
    "out_of_sla_pct",
})

_LLM_CURRENT_STATE_STRIP_FIELDS = frozenset({
    "demand_utilization_percentage",
    "standard_cases_per_hour",
})


def _sla_payload(value: Any) -> Any:
    """Like _model_payload but strips backend-only fields the LLM should not quote."""
    payload = _model_payload(value)
    if isinstance(payload, dict):
        return {k: v for k, v in payload.items() if k not in _LLM_STRIP_FIELDS}
    return payload


def _current_state_payload(value: Any) -> Any:
    """Like _model_payload but strips derived fields that are not scenario levers."""
    payload = _model_payload(value)
    if isinstance(payload, dict):
        return {k: v for k, v in payload.items() if k not in _LLM_CURRENT_STATE_STRIP_FIELDS}
    return payload


async def _generate_llm_recommendation_lines(
    current_state: WhatIfCurrentState,
    current_sla: CurrentSLAMetrics,
    projected_sla: ProjectedSLAMetrics,
    impact: SLAImpactAnalysis,
    scenario_changes: Any,
) -> Optional[Dict[str, str]]:
    if not config.is_ai_coach_enabled("workforce"):
        return None

    messages = [
        {
            "role": "system",
            "content": (
                "You are WorkforceIQ, an expert operational scenario analyst for payment integrity staffing decisions. "
                "Your task is to generate concise, reliable, business-readable commentary for a Workforce What-If SLA scenario. "
                "Your audience is staffing and operations leaders who want to understand what changed, whether SLA exposure improves or worsens, and what operational interpretation follows. "
                "Return valid JSON only with exactly this shape: "
                '{"updated_scenario":"markdown string","projected_results_commentary":"markdown string"}. '
                "Use plain text inside both JSON values — use \\n for line breaks between sentences. Do not use bullet points, bold formatting, code fences, or headings (#). No extra keys. "
                "Treat the application payload as the only source of truth. Use supplied values exactly as provided and prefer supplied comparison and impact values over re-deriving anything. "
                "Never invent calculations, estimates, thresholds, ranges, assumptions, business rules, or operational facts. Never infer hidden formulas, backend mechanics, or unsupported cause-and-effect. "
                "Never introduce a number that is not directly present in the payload. If the payload does not support a strong claim, keep the statement cautious and directional. "
                "You may describe only user-visible business concepts such as inventory volume, SLA risk inventory, SLA risk percentage, available FTE, loan FTE, cycle time, shrinkage, membership, and the scenario change values tied to those fields. "
                "Do not mention backend-derived, hidden, or intermediary metrics, including demand utilization, standard cases per hour, effective productive FTE, cases per hour, throughput, daily throughput, net throughput, daily receipts, productive hours per day, out-of-SLA counts, out-of-SLA percentages, weekly capacity, backlog formulas, hidden capacity calculations, or any internal derived metric not explicitly intended for frontend narrative use. "
                "When baseline and projected scenarios are both present, compare them directly and explain what changed and why conditions improved, worsened, or remained mixed. "
                "Prioritize the changes most likely to influence workload pressure and SLA exposure — focus on staffing, cycle time, shrinkage, inventory volume, and membership. "
                "Keep the tone executive-friendly, operational, clear, natural, concise, and recommendation-oriented. Avoid robotic field-by-field narration, generic filler, and repeated phrasing. "
                "Do not contradict the supplied current, projected, or impact values. Use comma-separated large counts where natural and avoid trailing .0 for whole-number staffing, inventory, cycle time, and membership values. "
                "updated_scenario must explain the most meaningful scenario changes between baseline and updated conditions and why those changes matter operationally, without merely listing every field. "
                "projected_results_commentary must explain whether projected SLA exposure and inventory pressure improve, worsen, or stay broadly similar, and state the operational interpretation of that result in decision-useful language. "
                "If signals are mixed, say so clearly instead of forcing a fully positive or negative conclusion. Your response must be a single valid JSON object and nothing else."
            ),
        },
        {
            "role": "user",
            "content": json.dumps(
                {
                    "current_state": _current_state_payload(current_state),
                    "current_sla": _sla_payload(current_sla),
                    "projected_sla": _sla_payload(projected_sla),
                    "impact": _model_payload(impact),
                    "scenario_changes": _model_payload(scenario_changes),
                    "allowed_numeric_fields": [
                        "available_fte",
                        "avg_cycle_time_minutes",
                        "current_shrinkage_percent",
                        "inventory_volume",
                        "loan_fte",
                        "total_membership",
                        "fte_change",
                        "loan_fte_change",
                        "membership_change",
                        "inventory_volume_change",
                        "cycle_time_change",
                        "shrinkage_change",
                    ],
                    "visible_operational_concepts": [
                        "inventory volume",
                        "sla risk percentage",
                        "sla risk inventory",
                        "cycle time",
                        "shrinkage",
                        "available fte",
                        "loan fte",
                        "membership",
                    ],
                    "forbidden_mentions": [
                        "throughput",
                        "daily receipts",
                        "net throughput",
                        "daily throughput",
                        "out-of-SLA inventory",
                        "out-of-SLA percentage",
                        "weekly capacity",
                        "effective productive FTE",
                        "cases per hour",
                        "demand utilization",
                        "standard cases per hour",
                    ],
                    "instructions": {
                        "updated_scenario": "Write a short plain-text summary of the baseline-to-updated scenario change. Do not use bullet points or bold formatting. Mention only the most meaningful changes and explain why they matter operationally. Separate sentences with a space or newline.",
                        "projected_results_commentary": "Write a short plain-text commentary explaining whether SLA exposure and workload pressure improve or worsen. Do not use bullet points or bold formatting. Keep it recommendation-oriented, mention only the supplied metrics, and do not mention throughput, receipts, net throughput, or out-of-SLA metrics.",
                    },
                },
                default=str,
            ),
        },
    ]

    try:
        response = None

        if config.USE_FRAMEWORK_HORIZON_TOKEN:
            try:
                openai_service = get_openai_service()
                response = await openai_service.generate_completion(
                    messages=messages,
                    model=config.OPENAI_DEFAULT_MODEL,
                    **build_openai_request_options(config.OPENAI_DEFAULT_MODEL, include_framework_temperature=False),
                )
            except Exception as framework_error:
                logger.warning(
                    "Framework OpenAI call failed for What-If recommendations: %s. Attempting fallback...",
                    str(framework_error),
                )

        if response is None:
            loop = asyncio.get_running_loop()
            token = await loop.run_in_executor(
                None,
                get_auth_token,
                config.HORIZON_CLIENT_ID,
                config.HORIZON_CLIENT_SECRET,
            )

            if token:
                models_to_try = list(dict.fromkeys([config.OPENAI_DEFAULT_MODEL] + config.OPENAI_MODEL_FALLBACK))
                for model in models_to_try:
                    logger.info("Trying What-If recommendation model: %s", model)
                    response = await loop.run_in_executor(
                        None,
                        call_openai_direct,
                        token,
                        messages,
                        model,
                    )
                    if response:
                        logger.info("What-If recommendation model %s succeeded", model)
                        break
                    logger.warning("What-If recommendation model %s failed, trying next...", model)
            else:
                logger.warning("Unable to authenticate with Horizon API for What-If recommendation fallback")

        if response is None:
            return None

        completion_text = extract_completion_text(response)
        if not completion_text:
            return None
        return _extract_recommendation_sections_from_llm(completion_text)
    except Exception as exc:
        logger.warning(
            "What-If suggestion generation failed: %s",
            str(exc),
        )
        return None


async def generate_ai_summary(
    current_state: WhatIfCurrentState,
    current_sla: CurrentSLAMetrics,
    projected_sla: ProjectedSLAMetrics,
    impact: SLAImpactAnalysis,
    scenario_changes: Any,
) -> tuple[str, str]:
    recommendation_sections = await _generate_llm_recommendation_lines(
        current_state,
        current_sla,
        projected_sla,
        impact,
        scenario_changes,
    )
    if recommendation_sections is None:
        logger.info("Using rule-based fallback summary for What-If recommendations")
        return (
            generate_fallback_summary(
                current_state,
                current_sla,
                projected_sla,
                impact,
                scenario_changes,
            ),
            "rule_based_fallback",
        )
    suggestions_text, includes_rule_based_content = build_suggestions_text(
        current_state,
        current_sla,
        projected_sla,
        impact,
        scenario_changes,
        recommendation_sections,
    )
    if includes_rule_based_content:
        logger.info("Returning LLM What-If recommendations with deterministic augmentation")
    return (
        suggestions_text,
        "llm",
    )


# =============================================================================
# API ENDPOINT
# =============================================================================


@router.post(
    "/what-if-sla-impact",
    response_model=WhatIfSLAImpactResponse,
    summary="Calculate Workforce What-If SLA Impact",
    description="""
Calculate projected SLA impact for a Workforce IQ what-if scenario.

**Input behavior:**
- **staffing_category**: Filter only. It scopes the Snowflake queries used for the baseline metrics and receipts.
- **current_state**: Frontend-visible baseline metrics from the Workforce IQ What-If analysis flow.
- **scenario_changes**: Editable scenario inputs for FTE, loan FTE, membership, inventory volume, cycle time, and shrinkage. The API accepts delta fields (for example `loan_fte_change`) and absolute projected values (for example `loan_fte`) and normalizes absolute values against `current_state`.

**Projection behavior:**
- **membership_change** adjusts projected daily receipts proportionally to the membership change.
- **fte_change**, **loan_fte_change**, **cycle_time_change**, and **shrinkage_change** adjust projected capacity.
- **inventory_volume_change** adjusts projected backlog volume directly.

**Output includes:**
- current SLA baseline metrics
- projected SLA metrics
- a markdown-formatted scenario summary in `suggestions`
- recommendation metadata (`recommendation_source`, `previous_context_used`, `previous_scenario_comparison`)

**Suggestions format:**
1. `## Current Inventory Context` — short baseline context in plain text
2. `## Previous Scenario` — key baseline metrics as markdown bullet lines without bold
3. `## Updated Scenario` — deterministic markdown bullet lines showing the applied scenario changes and projected end values without bold
4. `## Projected Results` — deterministic result bullets followed by markdown commentary and backlog implication without bold

AI wording is used for the Projected Results commentary. All Updated Scenario metric values and section structure are assembled from the actual calculated scenario output.
""",
)
async def get_what_if_sla_impact(request: WhatIfSLAImpactRequest):
    """
    Calculate What-If SLA Impact based on scenario changes.
    
    This endpoint:
    1. Calculates current SLA metrics (with Redis caching)
    2. Projects SLA impact based on user-defined scenario changes
    3. Provides AI-generated insights and recommendations
    """
    try:
        logger.info(f"What-If SLA Impact request from user {request.user_id}")
        
        # Check Redis cache for current SLA
        cache_key = generate_cache_key(request.staffing_category, request.current_state)
        cached_sla = await cache_manager.get(cache_key)
        
        if cached_sla:
            logger.info(f"Using cached current SLA for key: {cache_key}")
            current_sla = CurrentSLAMetrics(**json.loads(cached_sla))
        else:
            # Get productive hours and daily receipts
            productive_hours_per_day, daily_receipts = await asyncio.gather(
                get_productive_hours(request.staffing_category),
                get_daily_receipts(request.staffing_category),
            )

            # Calculate current SLA
            current_sla, sla_is_complete = await calculate_current_sla(
                request.staffing_category,
                request.current_state,
                productive_hours_per_day,
                daily_receipts
            )

            # Only cache when all DB queries succeeded to prevent degraded results
            # poisoning future requests for up to 1 hour
            if sla_is_complete:
                await cache_manager.set(
                    cache_key,
                    json.dumps(current_sla.model_dump()),
                    ttl=3600
                )
                logger.info(f"Cached current SLA with key: {cache_key}")
            else:
                logger.warning(
                    "Skipping cache write for key %s — one or more SLA queries failed; "
                    "result contains defaulted zeros and must not be cached.",
                    cache_key,
                )
        
        # Calculate projected SLA and impact
        projected_sla, impact = calculate_projected_sla(
            current_sla,
            request.current_state,
            request.scenario_changes
        )
        
        # Load previous run from Redis for comparison context (TTL: 30 min)
        previous_run_key = generate_previous_run_cache_key(request.user_id, request.staffing_category)
        previous_context: Optional[Dict[str, Any]] = None
        cached_previous = await cache_manager.get(previous_run_key)
        if cached_previous:
            try:
                previous_context = json.loads(cached_previous)
                logger.info(f"Loaded previous What-If scenario context for user {request.user_id}")
            except (json.JSONDecodeError, TypeError):
                logger.warning(f"Failed to parse previous What-If context for user {request.user_id}, ignoring")
                previous_context = None

        # Generate AI summary with optional previous context for comparison
        ai_result, recommendation_source = await generate_ai_summary(
            request.current_state,
            current_sla,
            projected_sla,
            impact,
            request.scenario_changes,
        )

        # Store current run as the new previous context (TTL: 30 min)
        current_run_snapshot = {
            "scenario_changes": request.scenario_changes.model_dump(),
            "impact": impact.model_dump(),
            "suggestions": ai_result,
            "recommendation_source": recommendation_source,
        }
        await cache_manager.set(
            previous_run_key,
            json.dumps(current_run_snapshot),
            ttl=1800,
        )
        logger.info(f"Stored current What-If scenario as previous context for user {request.user_id}")

        comparison = None
        if previous_context:
            previous_impact = previous_context.get("impact", {})
            throughput_change_vs_previous = impact.throughput_increase - int(previous_impact.get("throughput_increase", 0))
            sla_risk_reduction_vs_previous = round(
                impact.sla_risk_reduction_pct - float(previous_impact.get("sla_risk_reduction_pct", 0.0)),
                2,
            )

            summary_parts = []
            if throughput_change_vs_previous > 0:
                summary_parts.append("improves throughput")
            elif throughput_change_vs_previous < 0:
                summary_parts.append("reduces throughput")

            if sla_risk_reduction_vs_previous > 0:
                summary_parts.append("reduces more at-risk cases")
            elif sla_risk_reduction_vs_previous < 0:
                summary_parts.append("increases at-risk exposure")

            comparison_summary = (
                f"Compared to the previous scenario, the current setup {' and '.join(summary_parts)}."
                if summary_parts else
                "Compared to the previous scenario, the current setup has similar impact."
            )

            # Guard 1: skip comparison if scenario inputs are identical to the cached run —
            # a repeated identical request within the 30-min window always reads its own snapshot.
            previous_scenario_changes = previous_context.get("scenario_changes", {})
            scenario_unchanged = previous_scenario_changes == request.scenario_changes.model_dump()

            # Guard 2: skip comparison when the current request is a zero-change baseline run.
            # Comparing a no-change baseline against a previous what-if scenario is misleading —
            # it merely reflects the baseline being better/worse than an earlier degraded scenario,
            # not a meaningful what-if comparison.
            current_changes = request.scenario_changes.model_dump()
            is_zero_change_scenario = all(v == 0 for v in current_changes.values())

            if scenario_unchanged:
                logger.info("Skipping previous scenario comparison — scenario inputs are identical to cached run.")
                comparison = None
            elif is_zero_change_scenario:
                logger.info("Skipping previous scenario comparison — current request is a zero-change baseline run.")
                comparison = None
            else:
                comparison = WhatIfPreviousScenarioComparison(
                    throughput_change_vs_previous=throughput_change_vs_previous,
                    sla_risk_reduction_pct_vs_previous=sla_risk_reduction_vs_previous,
                    summary=comparison_summary,
                )

        return WhatIfSLAImpactResponse(
            status="success",
            message="What-If SLA Impact calculated successfully.",
            suggestions=ai_result,
            recommendation_source=recommendation_source,
            previous_context_used=previous_context is not None,
            previous_scenario_comparison=comparison,
        )
        
    except HTTPException as exc:
        error_message = exc.detail if isinstance(exc.detail, str) else "Failed to calculate What-If SLA Impact."
        return JSONResponse(
            status_code=exc.status_code,
            content=WhatIfSLAImpactResponse(
                status="error",
                message=error_message,
                suggestions="",
                recommendation_source="rule_based_fallback",
                previous_context_used=False,
                previous_scenario_comparison=None,
            ).model_dump(),
        )
    except Exception as e:
        logger.error(f"Error in What-If SLA Impact: {str(e)}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content=WhatIfSLAImpactResponse(
                status="error",
                message=f"Failed to calculate What-If SLA Impact: {str(e)}",
                suggestions="",
                recommendation_source="rule_based_fallback",
                previous_context_used=False,
                previous_scenario_comparison=None,
            ).model_dump(),
        )
