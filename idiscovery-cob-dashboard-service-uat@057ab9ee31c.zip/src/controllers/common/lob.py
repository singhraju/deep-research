from fastapi import APIRouter, HTTPException
from typing import Optional
from schema.models import LOBRequest, LOBResponse
from utils import cache_manager
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL

router = APIRouter(prefix="/api/v1", tags=["LOB"])

connection_manager = SnowflakeConnectionManager()

LOB_QUERY = f"""
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
WHERE AUDIT_SUBJECT_ID = '{{user_id}}'
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
UNION
SELECT DISTINCT COALESCE(LOB, 'None') AS LOB
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
WHERE PYRESOLVEDUSERID = '{{user_id}}'
    AND PYRESOLVEDTIMESTAMP >= DATEADD(year, -1, CURRENT_DATE())
ORDER BY LOB
"""

@router.post(
    "/lobs",
    response_model=LOBResponse,
    summary="Get List of LOBs",
    description="Returns user-specific LOBs from audit and inventory tables. Cached with configurable TTL (default 1 hour)."
)
async def get_lobs(request: LOBRequest) -> LOBResponse:
    if not connection_manager.validate_config():
        raise HTTPException(status_code=500, detail="Snowflake credentials not configured.")

    cache_key = cache_manager.build_key(
        "lobs:user",
        user_id=request.user_id
    )

    async def fetch_lobs():
        try:
            query = LOB_QUERY.format(user_id=request.user_id)
            engine = connection_manager.get_engine()
            records = await engine.execute_query_async(query)
            lobs = [r.get("LOB") for r in records if r.get("LOB")]
            return {
                "status": "success",
                "lobs": lobs,
                "message": "LOBs retrieved successfully",
                "service": "idiscovery-cob-dashboard-service"
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to retrieve LOBs: {str(e)}")

    result = await cache_manager.get_or_fetch(cache_key, fetch_lobs, ttl=METRIC_CACHE_TTL)
    return LOBResponse(**result)