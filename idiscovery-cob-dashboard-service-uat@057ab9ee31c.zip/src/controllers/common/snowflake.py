import logging
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from schema import SnowflakeQueryRequest, SnowflakeQueryResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/snowflake", tags=["Common"])

# Initialize connection manager singleton
connection_manager = SnowflakeConnectionManager()


@router.get(
    "/status",
    summary="Check Snowflake Connection Status",
    description="""
Check if Snowflake credentials are properly configured.

**Input Parameters:** None

**Response Fields:**
- **status**: 'configured' or 'not_configured'
- **message**: Description of the configuration status
""",
)
async def snowflake_status():
    """
    Check if Snowflake credentials are configured.
    """
    is_configured = connection_manager.validate_config()
    return {
        "status": "configured" if is_configured else "not_configured",
        "message": "Snowflake credentials are configured" if is_configured else "Missing required Snowflake credentials",
        "service": "idiscovery-cob-dashboard-service"
    }


@router.post("/query", response_model=SnowflakeQueryResponse)
async def query_snowflake(request: SnowflakeQueryRequest):
    """
    Execute a SQL query against Snowflake database.
    Uses credentials from environment variables via SnowflakeConnectionManager.
    
    Args:
        request: SnowflakeQueryRequest containing query string and optional limit
        
    Returns:
        SnowflakeQueryResponse with query results or error message
    """
    try:
        if not connection_manager.validate_config():
            raise HTTPException(
                status_code=500,
                detail="Snowflake credentials not configured. Please set SNOWFLAKE_USER, SNOWFLAKE_PASSWORD, and SNOWFLAKE_ACCOUNT environment variables."
            )
        
        engine = connection_manager.get_engine()
        records = engine.execute_query(request.query, request.limit)
        
        return SnowflakeQueryResponse(
            status="success",
            message="Query executed successfully",
            record_count=len(records),
            records=records
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Snowflake query error: {type(e).__name__}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Query execution failed: {str(e)}"
        )


@router.post(
    "/close",
    summary="Close Snowflake Connection",
    description="""
Close the current Snowflake database connection.

**Input Parameters:** None

**Response Fields:**
- **status**: 'success' or 'error'
- **message**: Connection closure status

**Use Case:** Manually close connection for maintenance or troubleshooting token expiration issues.
""",
)
async def close_snowflake_connection():
    """
    Close the current Snowflake connection.
    """
    try:
        connection_manager.close_connection()
        return {
            "status": "success",
            "message": "Snowflake connection closed",
            "service": "idiscovery-cob-dashboard-service"
        }
    except Exception as e:
        logger.error(f"Error closing Snowflake connection: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to close connection: {str(e)}"
        )
