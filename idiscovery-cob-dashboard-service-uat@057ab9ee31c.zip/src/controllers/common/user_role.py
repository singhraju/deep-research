import logging
from fastapi import APIRouter, HTTPException

from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, METRIC_CACHE_TTL
from schema import UserRoleRequest, UserRoleResponse
from utils import cache_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="", tags=["Common"])

connection_manager = SnowflakeConnectionManager()


USER_ROLE_QUERY = f"""
SELECT 
    USERID,
    PYACCESSGROUP,
    USERID_PROFILE
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
WHERE USERID = '{{user_id}}' order by logindate desc
LIMIT 1
"""


def build_user_role_query(user_id: str) -> str:
    """
    Build SQL query to fetch user role for a user.

    Args:
        user_id: User ID to query

    Returns:
        Formatted SQL query string
    """
    return USER_ROLE_QUERY.format(user_id=user_id)


@router.post(
    "/user-role",
    response_model=UserRoleResponse,
    summary="Get User Role",
    description="""
Retrieve the fuse profile and user role for a given user ID.

**Input Parameters:**
- **user_id** (required): The unique identifier of the user (e.g., '1694MU', 'AF05867')

**Response Fields:**
- **fuse_profile**: The user's FUSE access group (e.g., 'COB:FrontLineUser', 'CLMSCCU:Admin')
- **user_role**: The mapped role category (e.g., 'Frontline', 'Manager', 'Director', 'FL_Auditor')

**Role Mappings:**
- Director: Admin roles
- Manager: Manager/OE roles  
- Frontline: FrontlineUser roles
- FL_Auditor: Auditor roles
- Auditor_Manager: Manager Auditor roles
- WFM: WorkForce Manager roles

**Caching:** Results cached for 4 hours (14,400s)
""",
)
async def get_user_role(request: UserRoleRequest) -> UserRoleResponse:
    """
    Get user role based on user ID from COB_AI_USER_PROFILE table.
    Uses Redis cache with 4-hour TTL.
    
    **Input:**
    - **user_id**: The user ID to query (e.g., '1694MU')
    
    **Output:**
    - **fuse_profile**: PYACCESSGROUP value from database
    - **user_role**: USERID_PROFILE value (mapped role category)
    """
    if not connection_manager.validate_config():
        raise HTTPException(
            status_code=500,
            detail="Snowflake credentials not configured. Please set SNOWFLAKE_USER, SNOWFLAKE_PASSWORD, and SNOWFLAKE_ACCOUNT environment variables."
        )
    
    # Explicit cache key — avoids build_key ambiguity for single-param lookups
    cache_key = f"user:role:{request.user_id}"

    # Step 1: Check cache first
    cached = await cache_manager.get(cache_key)
    if cached is not None:
        logger.info(f"Cache hit for user role: user_id={request.user_id}")
        return UserRoleResponse(**cached)

    # Step 2: Cache miss — fetch from Snowflake
    logger.info(f"Cache miss for user role: user_id={request.user_id}, querying DB")
    try:
        query = build_user_role_query(user_id=request.user_id)
        engine = connection_manager.get_engine()
        records = await engine.execute_query_async(query, limit=1)
    except Exception as e:
        logger.error(f"User role query error: {type(e).__name__}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve user role: {str(e)}"
        )

    if records:
        record = records[0]
        result = {
            "status": "success",
            "user_id": record.get("USERID"),
            "fuse_profile": record.get("PYACCESSGROUP"),
            "user_role": record.get("USERID_PROFILE"),
            "message": "User role retrieved successfully"
        }
        # Step 3a: Valid data — cache it
        try:
            await cache_manager.set(cache_key, result, ttl=METRIC_CACHE_TTL)
            logger.info(f"Cached user role for user_id={request.user_id} (TTL={METRIC_CACHE_TTL}s)")
        except Exception as e:
            logger.warning(f"Failed to cache user role for user_id={request.user_id}: {e}")
        return UserRoleResponse(**result)

    # Step 3b: No records found — do NOT cache, return empty response
    logger.warning(f"No records found in DB for user_id={request.user_id}, skipping cache")
    result = {
        "status": "success",
        "user_id": request.user_id,
        "fuse_profile": None,
        "user_role": None,
        "message": "No records found for user"
    }
    return UserRoleResponse(**result)
