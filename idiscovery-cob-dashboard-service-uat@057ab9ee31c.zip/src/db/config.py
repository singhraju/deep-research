import os
from dataclasses import dataclass
from typing import Optional, Dict, Any
from dotenv import load_dotenv

# Load credentials from Vault if available, otherwise from environment
VAULT_SECRETS_PATH = "/vault/secrets/creds"
if os.path.exists(VAULT_SECRETS_PATH):
    load_dotenv(VAULT_SECRETS_PATH)

load_dotenv()


@dataclass
class SnowflakeConnectionConfig:
    """Configuration class for Snowflake connection parameters."""
    user: str
    password: str
    account: str
    role: Optional[str] = None
    warehouse: Optional[str] = None
    database: Optional[str] = None
    schema: Optional[str] = None


# Vault-based Snowflake configurations for different environments
SNOWFLAKE_CONFIG_DV = {
    "connector_type": "pyspark",
    "service_id": "srcaifstmbrdd",
    "vault_role_name": "snowdb-tmbr-dev",
    "vault_namespace": "eda-snowflakedb",
    "vault_path": "eda_nonprod/static-creds/aedl_devops-srcaifstmbrdd",
    "vault_url": "https://vault.acr.awsdns.internal.das",
    "verify_ssl": False,
    "snowflake_warehouse": "D01_AIFS_TMBR_LOAD_WH_L",
    "snowflake_schema": "PR_TMBR",
    "sf_database": "D01_AIFS",
    "sf_account": "carelon-eda-nonprod.privatelink"
}

SNOWFLAKE_CONFIG_UAT = {
    "connector_type": "pyspark",
    "service_id": "srcdlaifstmbrap",
    "vault_role_name": "snowdb-idiscovery-gld",
    "vault_namespace": "eda-snowflakedb",
    "vault_path": "edaprod/static-creds/srcdlaifstmbrap",
    "vault_url": "https://vault.acr.awsdns.internal.das",
    "verify_ssl": False,
    "snowflake_warehouse": "DL_AIFS_TMBR_APP_WH_L",
    "snowflake_schema": "DL_DV_TMBR",
    "sf_database": "NON_CRTFD_AIFS",
    "sf_account": "carelon-edaprod1.privatelink"
}

SNOWFLAKE_CONFIG_PR = {
    "connector_type": "pyspark",
    "service_id": "srcdlaifstmbrap",
    "vault_role_name": "snowdb-idiscovery-prod",
    "vault_namespace": "eda-snowflakedb",
    "vault_path": "edaprod/static-creds/srcdlaifstmbrap",
    "vault_url": "https://vault.acr.awsdns.internal.das",
    "verify_ssl": False,
    "snowflake_warehouse": "DL_AIFS_TMBR_APP_WH_L",
    "snowflake_schema": "DL_PL_TMBR",
    "sf_database": "NON_CRTFD_AIFS",
    "sf_account": "carelon-edaprod1.privatelink"
}


def get_snowflake_config(env: str = "pr") -> Dict[str, Any]:
    """Get Snowflake configuration based on environment.
    
    Args:
        env: Environment name ('dv', 'uat', 'pr')
        
    Returns:
        Dictionary with Snowflake configuration for the specified environment
    """
    env = env.lower()
    if env == 'dv':
        return SNOWFLAKE_CONFIG_DV
    elif env == 'uat':
        return SNOWFLAKE_CONFIG_UAT
    elif env == 'pr':
        return SNOWFLAKE_CONFIG_PR
    else:
        return SNOWFLAKE_CONFIG_PR  # Default to PR


def get_snowflake_config_from_env() -> SnowflakeConnectionConfig:
    """Get Snowflake configuration from environment variables (for local development).
    
    Returns:
        SnowflakeConnectionConfig object with credentials from environment
    """
    return SnowflakeConnectionConfig(
        user=os.environ.get("SNOWFLAKE_USER", ""),
        password=os.environ.get("SNOWFLAKE_PASSWORD", ""),
        account=os.environ.get("SNOWFLAKE_ACCOUNT", "carelon-edaprod1.privatelink"),
        role=os.environ.get("SNOWFLAKE_ROLE"),
        warehouse=os.environ.get("SNOWFLAKE_WAREHOUSE", "DL_AIFS_TMBR_APP_WH_L"),
        database=os.environ.get("SNOWFLAKE_DATABASE", "NON_CRTFD_AIFS"),
        schema=os.environ.get("SNOWFLAKE_SCHEMA", "DL_DV_TMBR")
    )
