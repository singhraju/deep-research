import logging
import os
import asyncio
from contextlib import asynccontextmanager
from typing import Any, List, Optional, Dict

from .snowflake_engine import SnowparkSessionEngine
from .config import SnowflakeConnectionConfig
from .pool_config import PoolConfig, get_pool_config_from_env
from secret_handlers import SecretHandlerInterface, SecretHandlerFactory
from config import SNOWFLAKE_ACCOUNT, SNOWFLAKE_ROLE, SNOWFLAKE_WAREHOUSE, SNOWFLAKE_SCHEMA, SNOWFLAKE_DATABASE

logger = logging.getLogger(__name__)

# Initialize Secret Handler based on configuration
# Default to OS environment variables, set to "vault" for production to get creds from vault
SECRET_HANDLER_TYPE = os.getenv("SECRET_HANDLER_TYPE", "vault")


class AsyncSnowflakeConnectionAdapter:
    """Async adapter for SnowparkSessionEngine used by async service callers."""

    def __init__(self, engine: SnowparkSessionEngine):
        self._engine = engine

    @staticmethod
    def _to_sql_literal(value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int, float)):
            return str(value)
        return "'" + str(value).replace("'", "''") + "'"

    def _bind_query(self, query: str, values: Optional[List[Any]] = None) -> str:
        if not values:
            return query
        return query % tuple(self._to_sql_literal(value) for value in values)

    def _fetch_all_sync(self, query: str, values: Optional[List[Any]] = None):
        session = self._engine.connect()
        bound_query = self._bind_query(query, values)
        results = session.sql(bound_query).collect()
        return [row.as_dict() for row in results]

    async def fetch_all(self, query: str, values: Optional[List[Any]] = None):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._fetch_all_sync, query, values)


class SnowflakeConnectionManager:
    """
    Singleton manager for Snowflake connections with connection pooling.
    Handles connection lifecycle and configuration from secret handler (OS env or Vault).
    Uses connection pooling for improved concurrency and performance.
    """
    _instance: Optional["SnowflakeConnectionManager"] = None
    _engine: Optional[SnowparkSessionEngine] = None
    _secret_handler: Optional[SecretHandlerInterface] = None
    _pool_config: Optional[PoolConfig] = None
    
    def __new__(cls, secret_handler: Optional[SecretHandlerInterface] = None):
        if cls._instance is None:
            cls._instance = super(SnowflakeConnectionManager, cls).__new__(cls)
            cls._secret_handler = secret_handler or SecretHandlerFactory.get_handler(SECRET_HANDLER_TYPE)
            cls._pool_config = get_pool_config_from_env()
        return cls._instance
    
    def __init__(self, secret_handler: Optional[SecretHandlerInterface] = None):
        pass
    
    def _get_config(self) -> SnowflakeConnectionConfig:
        """Load Snowflake configuration using the secret handler."""
        user = self._secret_handler.get_secret("SNOWFLAKE_USER")
        password = self._secret_handler.get_secret("SNOWFLAKE_PASSWORD")
        
        return SnowflakeConnectionConfig(
            user=user,
            password=password,
            account=SNOWFLAKE_ACCOUNT,
            role=SNOWFLAKE_ROLE,
            warehouse=SNOWFLAKE_WAREHOUSE,
            database=SNOWFLAKE_DATABASE,
            schema=SNOWFLAKE_SCHEMA,
        )
    
    def validate_config(self) -> bool:
        """Check if all required Snowflake credentials are configured."""
        config = self._get_config()
        required_fields = [config.user, config.password, config.account]
        return all(required_fields)
    
    def get_engine(self) -> SnowparkSessionEngine:
        """
        Get or create a Snowpark session engine with connection pooling.
        
        Returns:
            SnowparkSessionEngine instance with connection pooling
            
        Raises:
            ValueError: If required credentials are not configured
        """
        if self._engine is None:
            if not self.validate_config():
                raise ValueError(
                    "Missing required Snowflake credentials. "
                    "Please set SNOWFLAKE_USER and SNOWFLAKE_PASSWORD via environment variables or Vault."
                )
            config = self._get_config()
            
            # Create engine with connection pooling
            self._engine = SnowparkSessionEngine(
                config=config,
                pool_config=self._pool_config
            )
            
            logger.info(f"Snowflake connection manager initialized with connection pooling")
            
            pool_stats = self._engine._pool.get_stats()
            logger.info(f"Connection pool created: min_size={pool_stats['min_size']}, "
                       f"max_size={pool_stats['max_size']}, "
                       f"current_size={pool_stats['current_size']}")
            
        return self._engine

    @asynccontextmanager
    async def get_connection(self):
        """Provide an async-compatible adapter for legacy async callers."""
        yield AsyncSnowflakeConnectionAdapter(self.get_engine())

    def close_connection(self) -> None:
        """Close the connection pool and all sessions."""
        if self._engine is not None:
            self._engine.close()
            self._engine = None
            logger.info(f"Snowflake connection pool closed")
    
    def get_pool_stats(self) -> Optional[Dict[str, Any]]:
        """
        Get connection pool statistics.
        
        Returns:
            Dictionary with pool statistics if engine is initialized, None otherwise
        """
        if self._engine is not None:
            return self._engine._pool.get_stats()
        return None
    
    def reset(self) -> None:
        """Reset the connection manager (useful for testing or reconnection)."""
        self.close_connection()
        SnowflakeConnectionManager._instance = None
        SnowflakeConnectionManager._engine = None
        SnowflakeConnectionManager._pool_config = None


# Singleton instance for easy import
connection_manager = SnowflakeConnectionManager()
