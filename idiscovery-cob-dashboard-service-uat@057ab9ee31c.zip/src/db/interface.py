from abc import ABC, abstractmethod
from typing import Any


class IEngine(ABC):
    """Abstract base class for database engines."""
    
    @abstractmethod
    def connect(self) -> Any:
        """Establish and return a database connection."""
        raise NotImplementedError
    
    @abstractmethod
    def close(self) -> None:
        """Close the database connection."""
        raise NotImplementedError
