"""
Connection pool configuration settings for Snowflake.

These settings control the behavior of the Snowpark session pool,
including size limits, timeouts, and session lifecycle management.
"""

import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class PoolConfig:
    """Configuration for Snowpark session pool."""
    
    # Pool size constraints
    min_size: int = 3              # Minimum number of sessions to maintain
    max_size: int = 50             # Maximum number of sessions allowed
    
    # Timeout settings (in seconds)
    acquisition_timeout: int = 30   # Max time to wait for session from pool
    creation_timeout: int = 60      # Max time to create new session
    
    # Session lifecycle
    max_session_age: int = 3600     # Max session lifetime in seconds (1 hour)
    max_queries_per_session: int = 1000  # Max queries before recycling session
    
    # Health checks
    pre_ping: bool = True           # Test session health before returning from pool
    ping_query: str = "SELECT 1"    # Query used for health checks
    
    # Pool behavior
    overflow: int = 10              # Allow temporary connections beyond max_size
    pool_recycle: int = 3600        # Force recycle all sessions after this time
    echo_pool: bool = False         # Log pool operations (useful for debugging)
    

def get_pool_config_from_env() -> PoolConfig:
    """
    Load pool configuration from environment variables.
    Falls back to defaults if not set.
    
    Environment Variables:
        SNOWFLAKE_POOL_MIN_SIZE: Minimum pool size (default: 3)
        SNOWFLAKE_POOL_MAX_SIZE: Maximum pool size (default: 50)
        SNOWFLAKE_POOL_TIMEOUT: Acquisition timeout in seconds (default: 30)
        SNOWFLAKE_POOL_RECYCLE_TIME: Session max age in seconds (default: 3600)
        SNOWFLAKE_POOL_PRE_PING: Enable health checks (default: true)
        SNOWFLAKE_POOL_MAX_QUERIES: Max queries per session (default: 1000)
        SNOWFLAKE_POOL_OVERFLOW: Overflow connections (default: 10)
        SNOWFLAKE_POOL_ECHO: Enable debug logging (default: false)
    
    Returns:
        PoolConfig object with settings from environment or defaults
    """
    return PoolConfig(
        min_size=int(os.environ.get("SNOWFLAKE_POOL_MIN_SIZE", "3")),
        max_size=int(os.environ.get("SNOWFLAKE_POOL_MAX_SIZE", "50")),
        acquisition_timeout=int(os.environ.get("SNOWFLAKE_POOL_TIMEOUT", "60")),
        max_session_age=int(os.environ.get("SNOWFLAKE_POOL_RECYCLE_TIME", "3600")),
        max_queries_per_session=int(os.environ.get("SNOWFLAKE_POOL_MAX_QUERIES", "1000")),
        pre_ping=os.environ.get("SNOWFLAKE_POOL_PRE_PING", "true").lower() == "true",
        overflow=int(os.environ.get("SNOWFLAKE_POOL_OVERFLOW", "10")),
        echo_pool=os.environ.get("SNOWFLAKE_POOL_ECHO", "false").lower() == "true"
    )



# Default pool configuration
default_pool_config = get_pool_config_from_env()
