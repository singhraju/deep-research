"""
Snowpark session pool implementation.

Provides connection pooling for Snowflake Snowpark sessions with:
- Configurable min/max pool sizes
- Session health checks and auto-recycling
- Thread-safe session acquisition and release
- Connection lifecycle management
"""

import asyncio
import logging
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from queue import Queue, Empty
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from snowflake.snowpark import Session

from .config import SnowflakeConnectionConfig
from .pool_config import PoolConfig

logger = logging.getLogger(__name__)


@dataclass
class SessionMetadata:
    """Metadata tracked for each pooled session."""
    session: Session
    created_at: float = field(default_factory=time.time)
    last_used: float = field(default_factory=time.time)
    query_count: int = 0
    is_healthy: bool = True
    
    def age(self) -> float:
        """Get session age in seconds."""
        return time.time() - self.created_at
    
    def idle_time(self) -> float:
        """Get time since last use in seconds."""
        return time.time() - self.last_used
    
    def should_recycle(self, max_age: int, max_queries: int) -> bool:
        """Check if session should be recycled."""
        return (
            self.age() >= max_age or
            self.query_count >= max_queries or
            not self.is_healthy
        )


class SnowparkSessionPool:
    """
    Thread-safe connection pool for Snowpark sessions.
    
    Manages a pool of Snowpark sessions with automatic health checks,
    session recycling, and configurable size limits.
    """
    
    def __init__(self, config: SnowflakeConnectionConfig, pool_config: PoolConfig):
        """
        Initialize the session pool.
        
        Args:
            config: Snowflake connection configuration
            pool_config: Pool behavior configuration
        """
        self.sf_config = config
        self.pool_config = pool_config
        
        # Pool state
        self._pool: Queue = Queue(maxsize=pool_config.max_size + pool_config.overflow)
        self._all_sessions: Dict[int, SessionMetadata] = {}  # Track all sessions by ID
        self._lock = threading.RLock()  # Thread-safe operations
        self._closed = False
        
        # Statistics
        self._stats = {
            "total_created": 0,
            "total_recycled": 0,
            "total_acquired": 0,
            "total_released": 0,
            "current_size": 0,
            "current_available": 0,
            "pool_exhausted_count": 0,
        }
        
        # Initialize minimum sessions
        self._initialize_pool()
        
        if pool_config.echo_pool:
            logger.info(f"SessionPool initialized: min={pool_config.min_size}, max={pool_config.max_size}")
    
    def _create_session(self) -> Session:
        """Create a new Snowpark session."""
        snowpark_config = {
            "account": self.sf_config.account,
            "user": self.sf_config.user,
            "password": self.sf_config.password,
            "client_session_keep_alive": True,
        }
        
        if self.sf_config.role:
            snowpark_config["role"] = self.sf_config.role
        if self.sf_config.warehouse:
            snowpark_config["warehouse"] = self.sf_config.warehouse
        if self.sf_config.database:
            snowpark_config["database"] = self.sf_config.database
        if self.sf_config.schema:
            snowpark_config["schema"] = self.sf_config.schema
        
        session = Session.builder.configs(snowpark_config).create()
        
        if self.pool_config.echo_pool:
            logger.debug(f"Created new Snowpark session: {id(session)}")
        
        return session
    
    def _initialize_pool(self):
        """Pre-populate pool with 3 of sessions ."""
        with self._lock:
            
            # Pre-create min_size sessions for immediate availability
            for _ in range(3):
                try:
                    session = self._create_session()
                    metadata = SessionMetadata(session=session)
                    self._all_sessions[id(session)] = metadata
                    self._pool.put(metadata, block=False)
                    self._stats["total_created"] += 1
                    self._stats["current_size"] += 1
                except Exception as e:
                    logger.error(f"Failed to initialize session in pool: {e}")
            
            self._stats["current_available"] = self._pool.qsize()
            logger.info(f"Pool initialized with 3 sessions")
    
    def _check_session_health(self, session: Session) -> bool:
        """
        Check if session is healthy by running a simple query.
        
        Args:
            session: Session to check
            
        Returns:
            True if healthy, False otherwise
        """
        if not self.pool_config.pre_ping:
            return True
        
        try:
            result = session.sql(self.pool_config.ping_query).collect()
            return len(result) > 0
        except Exception as e:
            logger.warning(f"Session health check failed: {e}")
            return False
    
    def _recycle_session(self, metadata: SessionMetadata):
        """
        Close and remove a session from tracking.
        
        Args:
            metadata: Session metadata to recycle
        """
        try:
            metadata.session.close()
            session_id = id(metadata.session)
            if session_id in self._all_sessions:
                del self._all_sessions[session_id]
            self._stats["total_recycled"] += 1
            self._stats["current_size"] -= 1
            
            if self.pool_config.echo_pool:
                logger.debug(f"Recycled session {session_id} (age={metadata.age():.1f}s, queries={metadata.query_count})")
        except Exception as e:
            logger.error(f"Error recycling session: {e}")
    
    def acquire(self, timeout: Optional[float] = None) -> Session:
        """
        Acquire a session from the pool.
        
        Args:
            timeout: Maximum time to wait for session (uses pool config default if None)
            
        Returns:
            Snowpark Session object
            
        Raises:
            TimeoutError: If no session available within timeout
            RuntimeError: If pool is closed
        """
        if self._closed:
            raise RuntimeError("Cannot acquire session from closed pool")
        
        if timeout is None:
            timeout = self.pool_config.acquisition_timeout
        
        start_time = time.time()
        
        while True:
            try:
                # Try to get session from pool
                with self._lock:
                    try:
                        metadata = self._pool.get(block=False)
                    except Empty:
                        # Pool is empty, try to create new session if under limit
                        if self._stats["current_size"] < (self.pool_config.max_size + self.pool_config.overflow):
                            session = self._create_session()
                            metadata = SessionMetadata(session=session)
                            self._all_sessions[id(session)] = metadata
                            self._stats["total_created"] += 1
                            self._stats["current_size"] += 1
                            
                            if self.pool_config.echo_pool:
                                logger.debug(f"Created overflow session (pool exhausted). Total: {self._stats['current_size']}")
                        else:
                            self._stats["pool_exhausted_count"] += 1
                            raise Empty("Pool exhausted")
                
                # Check if session should be recycled
                if metadata.should_recycle(self.pool_config.max_session_age, self.pool_config.max_queries_per_session):
                    if self.pool_config.echo_pool:
                        logger.debug(f"Session {id(metadata.session)} needs recycling")
                    self._recycle_session(metadata)
                    continue  # Try again
                
                # Health check
                if not self._check_session_health(metadata.session):
                    logger.warning(f"Session {id(metadata.session)} failed health check, recycling...")
                    metadata.is_healthy = False
                    self._recycle_session(metadata)
                    continue  # Try again
                
                # Session is good, return it
                metadata.last_used = time.time()
                self._stats["total_acquired"] += 1
                self._stats["current_available"] = self._pool.qsize()
                
                if self.pool_config.echo_pool:
                    logger.debug(f"Acquired session {id(metadata.session)} (available: {self._stats['current_available']})")
                
                return metadata.session
                
            except Empty:
                # Check timeout
                elapsed = time.time() - start_time
                if elapsed >= timeout:
                    raise TimeoutError(
                        f"Could not acquire session within {timeout}s. "
                        f"Pool size: {self._stats['current_size']}, "
                        f"Available: {self._pool.qsize()}"
                    )
                
                # Wait a bit before retrying
                time.sleep(0.1)
    
    def release(self, session: Session):
        """
        Return a session to the pool.
        
        Args:
            session: Session to return to pool
        """
        if self._closed:
            # Pool is closed, just close the session
            try:
                session.close()
            except:
                pass
            return
        
        session_id = id(session)
        
        with self._lock:
            if session_id not in self._all_sessions:
                logger.warning(f"Attempted to release unknown session {session_id}")
                return
            
            metadata = self._all_sessions[session_id]
            metadata.query_count += 1
            metadata.last_used = time.time()
            
            # Check if session should be recycled
            if metadata.should_recycle(self.pool_config.max_session_age, self.pool_config.max_queries_per_session):
                if self.pool_config.echo_pool:
                    logger.debug(f"Session {session_id} exceeded limits, recycling instead of returning to pool")
                self._recycle_session(metadata)
                
                # Create replacement if below min_size
                if self._stats["current_size"] < self.pool_config.min_size:
                    try:
                        new_session = self._create_session()
                        new_metadata = SessionMetadata(session=new_session)
                        self._all_sessions[id(new_session)] = new_metadata
                        self._pool.put(new_metadata, block=False)
                        self._stats["total_created"] += 1
                        self._stats["current_size"] += 1
                    except Exception as e:
                        logger.error(f"Failed to create replacement session: {e}")
            else:
                # Return to pool
                try:
                    self._pool.put(metadata, block=False)
                    self._stats["total_released"] += 1
                    self._stats["current_available"] = self._pool.qsize()
                    
                    if self.pool_config.echo_pool:
                        logger.debug(f"Released session {session_id} (available: {self._stats['current_available']})")
                except:
                    # Pool is full (shouldn't happen with proper accounting)
                    logger.warning(f"Pool full when releasing session {session_id}, recycling instead")
                    self._recycle_session(metadata)
    
    @asynccontextmanager
    async def get_session(self):
        """
        Async context manager for acquiring and releasing sessions.
        
        Usage:
            async with pool.get_session() as session:
                result = session.sql("SELECT 1").collect()
        """
        loop = asyncio.get_event_loop()
        session = await loop.run_in_executor(None, self.acquire)
        try:
            yield session
        finally:
            await loop.run_in_executor(None, self.release, session)
    
    def close(self):
        """Close all sessions in the pool concurrently for fast shutdown."""
        with self._lock:
            self._closed = True
            
            # Get all sessions to close
            sessions_to_close = list(self._all_sessions.values())
            session_count = len(sessions_to_close)
            
            if session_count == 0:
                logger.info("SessionPool closed (no sessions to close)")
                return
            
            # Close all sessions using ThreadPoolExecutor
            # Note: Due to Snowpark's internal locking, sessions close sequentially (~1.5s each)
            # ThreadPoolExecutor still helps prevent blocking the main thread during shutdown
            def close_session(metadata):
                """Close a single session."""
                try:
                    session_id = id(metadata.session)
                    if self.pool_config.echo_pool:
                        logger.debug(f"Closing session {session_id}...")
                    metadata.session.close()
                    if self.pool_config.echo_pool:
                        logger.debug(f"Closed session {session_id}")
                    return True
                except Exception as e:
                    logger.error(f"Error closing session during pool shutdown: {e}")
                    return False
            
            # Close sessions with thread pool
            # Even though Snowpark's close() is sequential, this prevents blocking
            start_time = time.time()
            logger.info(f"Closing {session_count} sessions...")
            with ThreadPoolExecutor(max_workers=min(session_count, 50)) as executor:
                futures = [executor.submit(close_session, metadata) for metadata in sessions_to_close]
                
                # Wait for all closures to complete
                closed_count = sum(future.result() for future in as_completed(futures))
            
            elapsed = time.time() - start_time
            
            # Clear tracking
            self._all_sessions.clear()
            
            # Empty the queue
            while not self._pool.empty():
                try:
                    self._pool.get(block=False)
                except Empty:
                    break
            
            self._stats["current_size"] = 0
            self._stats["current_available"] = 0
            
            logger.info(f"SessionPool closed: {closed_count}/{session_count} sessions in {elapsed:.2f}s")
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get pool statistics.
        
        Returns:
            Dictionary with pool metrics
        """
        with self._lock:
            return {
                **self._stats,
                "min_size": self.pool_config.min_size,
                "max_size": self.pool_config.max_size,
                "is_closed": self._closed,
            }
    
    def __del__(self):
        """Cleanup on deletion."""
        if not self._closed:
            self.close()
