import logging
import asyncio
from concurrent.futures import ThreadPoolExecutor
from snowflake.snowpark import Session
from typing import List, Dict, Any, Optional

from .config import SnowflakeConnectionConfig
from .interface import IEngine
from .vault_connector import get_snowflake_config_auto, use_vault_authentication
from .pool_config import PoolConfig
from .session_pool import SnowparkSessionPool

logger = logging.getLogger(__name__)

# Global thread pool for async query execution across all APIs
# Shared pool prevents creating too many threads under high load
_global_query_executor = ThreadPoolExecutor(max_workers=200, thread_name_prefix="snowflake-async")

class SnowparkSessionEngine(IEngine):
    """Snowflake Snowpark session engine with connection pooling for executing queries.
    
    Uses connection pooling to efficiently manage multiple concurrent database sessions.
    Supports both direct credential authentication and Vault-based authentication.
    """
    
    def __init__(self, config: Optional[SnowflakeConnectionConfig] = None, env: str = "pr", vault_config: Optional[Dict[str, Any]] = None, pool_config: Optional[PoolConfig] = None):
        """
        Initialize the Snowpark session engine with connection pooling.
        
        Args:
            config: SnowflakeConnectionConfig object. If None, will auto-detect based on SECRET_HANDLER_TYPE
            env: Environment name ('dv', 'uat', 'pr') - used when config is None
            vault_config: Optional Vault configuration dict - used when config is None and SECRET_HANDLER_TYPE='vault'
            pool_config: Optional PoolConfig for connection pooling. If None, uses defaults from environment
        """
        if config is None:
            # Auto-detect configuration based on SECRET_HANDLER_TYPE
            config = get_snowflake_config_auto(env=env, vault_config=vault_config)
            logger.info(f"Auto-configured Snowflake connection for environment: {env}")
        
        self.config = config
        self._using_vault = use_vault_authentication()
        
        # Initialize connection pool
        if pool_config is None:
            from .pool_config import default_pool_config
            pool_config = default_pool_config
        
        self._pool = SnowparkSessionPool(config, pool_config)
        logger.info(f"SnowparkSessionEngine initialized with connection pooling "
                   f"(min={pool_config.min_size}, max={pool_config.max_size})")
    
    def connect(self) -> Session:
        """
        Acquire a session from the connection pool.
        
        Make sure to call release() or use the execute_query methods which handle it automatically.
        
        Returns:
            Snowpark Session object from the pool
        """
        return self._pool.acquire()
    
    def release(self, session: Session) -> None:
        """
        Release a session back to the pool.
        
        Only needed when you manually acquire sessions via connect().
        The execute_query methods handle this automatically.
        
        Args:
            session: Session to release back to pool
        """
        self._pool.release(session)
    
    def close(self) -> None:
        """Close the connection pool and all sessions."""
        self._pool.close()
        logger.info("Snowpark session pool closed")
    
    def _is_auth_error(self, error: Exception) -> bool:
        """Check if the error is an authentication/token expiration error."""
        error_str = str(error).lower()
        auth_error_indicators = [
            "authentication token has expired",
            "390114",
            "08001",
            "authentication",
            "session has expired",
            "connection was closed",
        ]
        return any(indicator in error_str for indicator in auth_error_indicators)

    def execute_query(self, query: str, limit: int = 10, max_retries: int = 3) -> List[Dict[str, Any]]:
        """
        Execute a SQL query and return results as a list of dictionaries.
        Automatically acquires a session from pool, executes query, and releases it.
        Retries with a fresh session if authentication expires.
        
        Args:
            query: SQL query to execute
            limit: Maximum number of records to return
            max_retries: Maximum number of retry attempts for auth errors
            
        Returns:
            List of dictionaries containing query results
        """
        last_error = None
        
        for attempt in range(max_retries + 1):
            session = None
            try:
                session = self.connect()
                df = session.sql(query).limit(limit)
                results = df.collect()
                result_data = [row.as_dict() for row in results]
                
                # Release session back to pool
                self.release(session)
                session = None
                
                return result_data
                
            except Exception as e:
                last_error = e
                logger.error(f"Query execution failed (attempt {attempt + 1}/{max_retries + 1}): {type(e).__name__}: {e}")
                
                # Release failed session back to pool (will be recycled if stale)
                if session:
                    try:
                        self.release(session)
                        session = None
                    except:
                        pass
                
                if self._is_auth_error(e) and attempt < max_retries:
                    logger.info(f"Authentication error detected, will retry with fresh session from pool...")
                    # Next iteration will get a fresh session automatically
                else:
                    raise
            finally:
                # Ensure session is released even if an unexpected error occurs
                if session:
                    try:
                        self.release(session)
                    except:
                        pass
        
        raise last_error
    
    async def execute_query_async(self, query: str, limit: int = 10, max_retries: int = 3) -> List[Dict[str, Any]]:
        """
        Execute a SQL query asynchronously without blocking the event loop.
        Uses a global thread pool to run the synchronous execute_query in a background thread.
        
        This is a centralized async wrapper that can be used by all APIs.
        
        Args:
            query: SQL query to execute
            limit: Maximum number of records to return
            max_retries: Maximum number of retry attempts for auth errors
            
        Returns:
            List of dictionaries containing query results
            
        Example:
            # In your async endpoint:
            results = await engine.execute_query_async(query, limit=100)
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            _global_query_executor,
            self.execute_query,
            query,
            limit,
            max_retries
        )
