"""
Vault connector wrapper for Snowflake authentication.

This module provides a wrapper around the flexible_snowflake_connector package
to retrieve Snowflake credentials from HashiCorp Vault using AWS authentication.
"""

import logging
import os
from typing import Dict, Any, Optional
from .config import SnowflakeConnectionConfig

logger = logging.getLogger(__name__)


def get_snowflake_connection_from_vault(vault_config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get Snowflake connection configuration from Vault.
    
    This function uses the flexible_snowflake_connector to retrieve credentials
    from HashiCorp Vault using AWS IAM authentication.
    
    Args:
        vault_config: Dictionary containing Vault configuration:
            - service_id: Service identifier
            - vault_role_name: Vault role name
            - vault_namespace: Vault namespace
            - vault_path: Path to credentials in Vault
            - vault_url: Vault server URL
            - verify_ssl: Whether to verify SSL certificates
            - snowflake_warehouse: Snowflake warehouse name
            - snowflake_schema: Snowflake schema name
            - sf_database: Snowflake database name
            - sf_account: Snowflake account identifier
            - connector_type: Type of connector ('pyspark' or 'snowpark')
    
    Returns:
        Dictionary with Snowflake connection parameters including:
        - sfURL: Snowflake connection URL
        - sfUser: Snowflake username
        - sfWarehouse: Warehouse name
        - sfDatabase: Database name
        - sfSchema: Schema name
        - pem_private_key: Private key for authentication (if using key-pair auth)
    
    Raises:
        ImportError: If flexible_snowflake_connector is not installed
        Exception: If Vault authentication or credential retrieval fails
    """
    try:
        from flexible_snowflake_connector.connection import get_snowflake_connection
        
        logger.info(f"Retrieving Snowflake credentials from Vault for service: {vault_config.get('service_id')}")
        
        # Get connection configuration from Vault
        sf_connection = get_snowflake_connection(**vault_config)
        
        logger.info("Successfully retrieved Snowflake credentials from Vault")
        return sf_connection
        
    except ImportError as e:
        logger.error("flexible_snowflake_connector package not found. Install it from the wheel file.")
        raise ImportError(
            "flexible_snowflake_connector is required for Vault authentication. "
            "Install it using: pip install flexible_snowflake_connector-1.0.0-py3-none-any.whl"
        ) from e
    except Exception as e:
        logger.error(f"Failed to retrieve credentials from Vault: {str(e)}")
        raise


def create_snowflake_config_from_vault(vault_config: Dict[str, Any]) -> SnowflakeConnectionConfig:
    """
    Create a SnowflakeConnectionConfig from Vault credentials.
    
    This is a convenience function that retrieves credentials from Vault
    and converts them to a SnowflakeConnectionConfig object.
    
    Args:
        vault_config: Vault configuration dictionary
    
    Returns:
        SnowflakeConnectionConfig object with credentials from Vault
    """
    vault_creds = get_snowflake_connection_from_vault(vault_config)
    
    # Extract credentials from Vault response
    # The flexible_snowflake_connector returns different formats based on connector_type
    if isinstance(vault_creds, dict):
        # Extract user from sfUser or username field
        user = vault_creds.get('sfUser') or vault_creds.get('username', '')
        
        # For key-pair authentication, password might be empty
        # The pem_private_key is used instead
        password = vault_creds.get('sfPassword', vault_creds.get('password', ''))
        
        # Extract account from sfURL or account field
        account = vault_config.get('sf_account', '')
        
        return SnowflakeConnectionConfig(
            user=user,
            password=password,
            account=account,
            role=vault_creds.get('sfRole'),
            warehouse=vault_creds.get('sfWarehouse', vault_config.get('snowflake_warehouse')),
            database=vault_creds.get('sfDatabase', vault_config.get('sf_database')),
            schema=vault_creds.get('sfSchema', vault_config.get('snowflake_schema'))
        )
    else:
        raise ValueError(f"Unexpected credential format from Vault: {type(vault_creds)}")


def use_vault_authentication() -> bool:
    """
    Check if Vault authentication should be used.
    
    Returns:
        True if SECRET_HANDLER_TYPE is set to 'vault', False otherwise
    """
    handler_type = os.environ.get('SECRET_HANDLER_TYPE', 'os').lower()
    return handler_type == 'vault'


def get_snowflake_config_auto(env: str = "pr", vault_config: Optional[Dict[str, Any]] = None) -> SnowflakeConnectionConfig:
    """
    Automatically get Snowflake configuration based on SECRET_HANDLER_TYPE.
    
    If SECRET_HANDLER_TYPE='vault', uses Vault authentication.
    Otherwise, uses environment variables.
    
    Args:
        env: Environment name ('dv', 'uat', 'pr') - used for Vault mode
        vault_config: Optional Vault configuration. If not provided, uses config from config.py
    
    Returns:
        SnowflakeConnectionConfig object
    """
    from .config import get_snowflake_config, get_snowflake_config_from_env
    
    if use_vault_authentication():
        logger.info(f"Using Vault authentication for environment: {env}")
        if vault_config is None:
            vault_config = get_snowflake_config(env)
        return create_snowflake_config_from_vault(vault_config)
    else:
        logger.info("Using environment variable authentication")
        return get_snowflake_config_from_env()
