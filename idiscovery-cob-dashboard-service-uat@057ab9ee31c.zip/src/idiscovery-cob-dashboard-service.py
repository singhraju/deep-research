import logging
import os
import uvicorn
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse

import config as config
from utils import setup_json_logging, dedupe_runtime_loggers, APITimingMiddleware, APIAuthMiddleware, cache_manager
from controllers.Performance_IQ import user_time_router, user_metrics_router, user_activity_router, audit_score_gauge_router, workitems_drilldown_router, auditscore_drilldown_router, production_percentage_gauge_router, fusetime_drilldown_router, production_pct_drilldown_router, ai_coach_router, audit_error_drilldown_router
from controllers.Performance_IQ_Director import demand_inventory_router, operational_flow_router, quality_outcomes_router, header_kpis_router, associate_utilization_router, sla_health_router, managers_list_router, associates_list_router, director_list_router, escalation_count_drilldown_router, pended_items_drilldown_router, production_pct_achieved_drilldown_router, rebuttal_drilldown_router, audit_score_director_drilldown_router, fuse_time_director_drilldown_router, work_items_director_drilldown_router, ai_coach_router_director, capacity_insight_drilldown_router, sla_health_drilldown_router, audit_sample_pct_drilldown_router, watchlist_drilldown_router, cycle_takt_drilldown_router, rework_pct_drilldown_router, completed_audit_count_drilldown_router, audit_error_director_drilldown_router, staff_utilization_drilldown_router as director_staff_utilization_drilldown_router, director_lob_router, director_user_activity_router
from controllers.Performance_IQ_Manager import (
    header_kpis_router as manager_header_kpis_router,
    quality_outcomes_router as manager_quality_outcomes_router,
    associate_utilization_router as manager_associate_utilization_router,
    associates_list_router as manager_associates_list_router,
    pended_items_drilldown_router as manager_pended_items_drilldown_router,
    production_pct_achieved_drilldown_router as manager_production_pct_achieved_drilldown_router,
    rebuttal_drilldown_router as manager_rebuttal_drilldown_router,
    work_items_drilldown_router as manager_work_items_drilldown_router,
    audit_score_drilldown_router as manager_audit_score_drilldown_router,
    rework_drilldown_router as manager_rework_drilldown_router,
    fuse_time_drilldown_router as manager_fuse_time_drilldown_router,
    audit_errors_drilldown_router as manager_audit_errors_drilldown_router,
    complete_audit_count_drilldown_router as manager_complete_audit_count_drilldown_router,
    ai_coach_router_manager,
    user_activity_router as manager_user_activity_router,
    manager_list_router as manager_manager_list_router,
    manager_lob_router,
    manager_capacity_insight_drilldown_router,
    watchlist_manager_drilldown_router,
    staff_utilization_drilldown_router,
)
from controllers.Performance_IQ_Auditor_Manager import (
    header_kpis_router as auditor_manager_header_kpis_router,
    time_utilization_router as auditor_manager_time_utilization_router,
    ata_score_gauge_router as auditor_manager_ata_score_gauge_router,
    audit_cycle_time_gauge_router as auditor_manager_audit_cycle_time_gauge_router,
    rebuttals_router as auditor_manager_rebuttals_router,
    auditor_list_router as auditor_manager_auditor_list_router,
    manager_list_router as auditor_manager_manager_list_router,
    completed_audit_count_drilldown_router as auditor_manager_completed_audit_count_drilldown_router,
    audit_sample_pct_drilldown_router as auditor_manager_audit_sample_pct_drilldown_router,
    ata_score_drilldown_router as auditor_manager_ata_score_drilldown_router,
    rebuttal_drilldown_router as auditor_manager_rebuttal_drilldown_router,
    work_items_drilldown_router as auditor_manager_work_items_drilldown_router,
    fuse_time_drilldown_router as auditor_manager_fuse_time_drilldown_router,
    staff_utilization_drilldown_router as auditor_manager_staff_utilization_drilldown_router,
    auditor_manager_lob_router,
    ai_coach_router_auditor_manager,
    quality_outcomes_router as auditor_manager_quality_outcomes_router,
    ata_rebuttal_drilldown_router as auditor_manager_ata_rebuttal_drilldown_router,
    user_activity_router as auditor_manager_user_activity_router
)
from controllers.Performance_IQ_FL_Auditor import router as fl_auditor_router
from controllers.WorkForce_IQ import router as workforce_iq_router
from controllers.common import snowflake_router, user_role_router, lob_router

dedupe_runtime_loggers()

# Setup JSON logging for Splunk
api_timing_logger = setup_json_logging("api.timing", level=logging.INFO)
api_events_logger = setup_json_logging("api.events", level=logging.INFO)
logger = logging.getLogger(__name__)

def _get_api_auth_bool(name: str, default: str = "false") -> bool:
    configured_value = getattr(config, name, None)
    if isinstance(configured_value, bool):
        return configured_value

    raw_value = os.environ.get(name)
    if raw_value is None and configured_value is not None:
        raw_value = str(configured_value)

    return (raw_value or default).lower() == "true"

def _get_api_auth_paths(name: str, default: str) -> list[str]:
    raw_value = os.environ.get(name)
    if raw_value is None:
        configured_value = getattr(config, name, None)
        if isinstance(configured_value, (list, tuple, set)):
            return [str(path).strip() for path in configured_value if str(path).strip()]
        if configured_value is not None:
            raw_value = str(configured_value)

    source_value = raw_value if raw_value is not None else default
    return [path.strip() for path in source_value.split(",") if path.strip()]

# =============================================================================
# Lifespan Event Handler
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handle application lifespan events (startup and shutdown)."""
    dedupe_runtime_loggers()

    # Startup: Initialize Redis connection
    logger.info("Starting COB Dashboard Service...")
    await cache_manager.connect()
    logger.info(f"Redis caching: {'enabled' if cache_manager.enabled else 'disabled'}")
    
    yield
    
    # Shutdown: Close Redis connection
    logger.info("Shutting down COB Dashboard Service...")
    await cache_manager.disconnect()

app = FastAPI(
    title="idiscovery-cob-dashboard-service",
    description="COB Dashboard Service",
    version="0.0.1",
    lifespan=lifespan,
)


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    components = openapi_schema.setdefault("components", {})
    security_schemes = components.setdefault("securitySchemes", {})
    security_schemes["BearerAuth"] = {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT",
    }
    openapi_schema["security"] = [{"BearerAuth": []}]
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


@app.exception_handler(RequestValidationError)
async def custom_request_validation_exception_handler(request: Request, exc: RequestValidationError):
    if request.url.path == "/workforce-iq/what-if-sla-impact" and request.method.upper() == "POST":
        validation_errors = exc.errors()
        error_message = "Invalid What-If SLA Impact request."

        if validation_errors:
            first_error = validation_errors[0]
            error_message = first_error.get("msg") or error_message

        return JSONResponse(
            status_code=422,
            content={
                "status": "error",
                "message": error_message,
                "suggestions": "",
                "recommendation_source": "rule_based_fallback",
                "previous_context_used": False,
                "previous_scenario_comparison": None,
                "service": "idiscovery-cob-dashboard-service",
            },
        )

    return await request_validation_exception_handler(request, exc)

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Accept", "Content-Type", "Authorization"],
)

app.add_middleware(
    APIAuthMiddleware,
    enabled=_get_api_auth_bool("API_AUTH_ENABLED", "true"),
    protected_paths=_get_api_auth_paths("API_AUTH_PROTECTED_PATHS", "/user-role,/api/v1/lobs"),
    protect_all_routes=_get_api_auth_bool("API_AUTH_PROTECT_ALL_ROUTES", "true"),
    excluded_paths=_get_api_auth_paths("API_AUTH_EXCLUDED_PATHS", "/,/health,/docs,/openapi.json,/redoc,/docs/oauth2-redirect"),
)

# Add API timing middleware for Splunk logging
# Logs: event_type, api_name, api_path, api_group, method, duration_ms, status_code, request_id
app.add_middleware(APITimingMiddleware, logger=api_timing_logger)

# =============================================================================
# Include Routers
# =============================================================================
#app.include_router(fuse_time_router)
app.include_router(snowflake_router)
#app.include_router(work_items_router)
#app.include_router(audit_score_router)
#app.include_router(non_productive_time_router)
app.include_router(user_time_router)
app.include_router(user_metrics_router)
app.include_router(user_activity_router)
app.include_router(audit_score_gauge_router)
app.include_router(workitems_drilldown_router)
app.include_router(auditscore_drilldown_router)
app.include_router(production_percentage_gauge_router)
app.include_router(user_role_router)
app.include_router(lob_router)
app.include_router(fusetime_drilldown_router)
app.include_router(production_pct_drilldown_router)
app.include_router(ai_coach_router)
app.include_router(audit_error_drilldown_router)

# =============================================================================
# Performance IQ Director Routers
# =============================================================================
app.include_router(demand_inventory_router)
app.include_router(operational_flow_router)
app.include_router(quality_outcomes_router)
app.include_router(header_kpis_router)
app.include_router(associate_utilization_router)
app.include_router(sla_health_router)
app.include_router(managers_list_router)
app.include_router(associates_list_router)
app.include_router(director_list_router)
app.include_router(escalation_count_drilldown_router)
app.include_router(pended_items_drilldown_router)
app.include_router(production_pct_achieved_drilldown_router)
app.include_router(rebuttal_drilldown_router)
app.include_router(audit_score_director_drilldown_router)
app.include_router(fuse_time_director_drilldown_router)
app.include_router(work_items_director_drilldown_router)
app.include_router(ai_coach_router_director)
app.include_router(capacity_insight_drilldown_router)
app.include_router(sla_health_drilldown_router)
app.include_router(audit_sample_pct_drilldown_router)
app.include_router(watchlist_drilldown_router)
app.include_router(cycle_takt_drilldown_router)
app.include_router(rework_pct_drilldown_router)
app.include_router(completed_audit_count_drilldown_router)
app.include_router(audit_error_director_drilldown_router)
app.include_router(director_staff_utilization_drilldown_router)
app.include_router(director_lob_router)
app.include_router(director_user_activity_router)

# =============================================================================
# Performance IQ Manager Routers
# =============================================================================
app.include_router(manager_header_kpis_router)
app.include_router(manager_quality_outcomes_router)
app.include_router(manager_associate_utilization_router)
app.include_router(manager_associates_list_router)
app.include_router(manager_pended_items_drilldown_router)
app.include_router(manager_production_pct_achieved_drilldown_router)
app.include_router(manager_rebuttal_drilldown_router)
app.include_router(manager_work_items_drilldown_router)
app.include_router(manager_audit_score_drilldown_router)
app.include_router(manager_rework_drilldown_router)
app.include_router(manager_fuse_time_drilldown_router)
app.include_router(manager_audit_errors_drilldown_router)
app.include_router(manager_complete_audit_count_drilldown_router)
app.include_router(ai_coach_router_manager)
app.include_router(manager_user_activity_router)
app.include_router(manager_manager_list_router)
app.include_router(manager_lob_router)
app.include_router(manager_capacity_insight_drilldown_router)
app.include_router(watchlist_manager_drilldown_router)
app.include_router(staff_utilization_drilldown_router)

# =============================================================================
# Performance IQ Auditor Manager Routers
# =============================================================================
app.include_router(auditor_manager_header_kpis_router)
app.include_router(auditor_manager_time_utilization_router)
app.include_router(auditor_manager_ata_score_gauge_router)
app.include_router(auditor_manager_audit_cycle_time_gauge_router)
app.include_router(auditor_manager_rebuttals_router)
app.include_router(auditor_manager_auditor_list_router)
app.include_router(auditor_manager_manager_list_router)
app.include_router(auditor_manager_completed_audit_count_drilldown_router)
app.include_router(auditor_manager_audit_sample_pct_drilldown_router)
app.include_router(auditor_manager_ata_score_drilldown_router)
app.include_router(auditor_manager_rebuttal_drilldown_router)
app.include_router(auditor_manager_work_items_drilldown_router)
app.include_router(auditor_manager_fuse_time_drilldown_router)
app.include_router(auditor_manager_staff_utilization_drilldown_router)
app.include_router(auditor_manager_lob_router)
app.include_router(ai_coach_router_auditor_manager)
app.include_router(auditor_manager_quality_outcomes_router)
app.include_router(auditor_manager_ata_rebuttal_drilldown_router)
app.include_router(auditor_manager_user_activity_router)

# =============================================================================
# Performance IQ FL Auditor Routers
# =============================================================================
app.include_router(fl_auditor_router)

# =============================================================================
# WorkForce IQ Routers
# =============================================================================
app.include_router(workforce_iq_router)

# =============================================================================
# Health Check Endpoints
# =============================================================================

@app.get("/")
async def root():
    return {"message": "hello idiscovery-cob-dashboard-service", "version": "0.0.1"}


@app.get("/health")
async def health_check():
    return {"status": "ok", "service": "idiscovery-cob-dashboard-service"}


if __name__ == "__main__":
    uvicorn.run(
        "idiscovery-cob-dashboard-service:app",
        host=config.SERVICE_HOST,
        port=int(config.SERVICE_PORT),
        reload=config.RELOAD,
        workers=int(config.NUM_WORKERS),
    )
