from pydantic import BaseModel, Field, field_validator, model_validator
from typing import Dict, Any, Optional, List, Union


class DataRequest(BaseModel):
    """Generic data request model."""
    data: Dict[str, Any]


class SnowflakeQueryRequest(BaseModel):
    """Request model for generic Snowflake query."""
    query: str
    limit: Optional[int] = 10


class SnowflakeQueryResponse(BaseModel):
    """Response model for generic Snowflake query."""
    status: str
    message: str
    record_count: Optional[int] = None
    records: Optional[List[Dict[str, Any]]] = None
    service: str = "idiscovery-cob-dashboard-service"


class UserTimeRequest(BaseModel):
    """Request model for user time metrics API."""
    user_id: str = Field(..., description="User ID to query", examples=["1694MU"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "1694MU",
                "start_date": "2025-04-03",
                "end_date": "2025-04-05"
            }
        }


class UserTimeResponse(BaseModel):
    """Response model for user time metrics API."""
    status: str = Field(..., description="Status of the request (success/error)")
    fuse_time: Optional[str] = Field(None, description="Total fuse time formatted as 'X hrs Y mins'")
    fuse_non_productive_time: Optional[str] = Field(None, description="Fuse non-productive time formatted as 'X hrs Y mins'")
    ohi_non_productive_time: Optional[str] = Field(None, description="OHI non-productive time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class UserMetricsRequest(BaseModel):
    """Request model for user metrics API (work items + audit score)."""
    user_id: str = Field(..., description="User ID to query", examples=["AA99826"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for caching support")
    warm_ai_coach_context: Optional[bool] = Field(default=True, description="Internal flag controlling Frontline AI Coach dependency warmup")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "lob": ["Commercial"],
                "session_id": "session_1775821614_abc123def"
            }
        }


class UserMetricsResponse(BaseModel):
    """Response model for user metrics API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: Optional[str] = Field(None, description="User ID")
    work_items_completed: Optional[str] = Field(None, description="Number of work items completed")
    audit_score_percentage: Optional[str] = Field(None, description="Average audit score percentage")
    audit_score_bubble: Optional[str] = Field(None, description="Audit score bubble indicator (Excellent/Good/Poor)")
    cycle_time_avg: Optional[str] = Field(None, description="Average cycle time")
    cycle_time_bubble: Optional[str] = Field(None, description="Cycle time bubble indicator (N/A until data available)")
    audit_error_count: Optional[str] = Field(None, description="Audit error count")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



class UserActivityRequest(BaseModel):
    """Request model for user activity API (login/logout + skilled sources)."""
    user_id: str = Field(..., description="User ID to query")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AL48579",
                "start_date": "2025-01-01",
                "end_date": "2025-01-31",
                "lob": ["Commercial"]
            }
        }


class SessionRecord(BaseModel):
    """Individual login/logout session within a day."""
    login: Optional[str] = Field(None, description="Login time in HH:MM AM/PM ET format")
    logout: Optional[str] = Field(None, description="Logout time in HH:MM AM/PM ET format")


class LoginLogoutRecord(BaseModel):
    """Daily login/logout record with multiple sessions."""
    date: str = Field(default="", description="Login date")
    sessions: List[SessionRecord] = Field(default=[], description="List of login/logout sessions for the day")


class UserActivityData(BaseModel):
    """Data section for user activity response."""
    user_id: str
    login_logout_records: List[LoginLogoutRecord]
    skilled_sources: List[str]
    team_rank: str = Field(default="NA", description="Team Rank")
    department_rank: str = Field(default="NA", description="Department Rank")


class UserActivityResponse(BaseModel):
    """Response model for user activity API."""
    meta: Dict[str, str]
    data: Optional[UserActivityData] = None
    errors: Optional[List[Dict[str, Any]]] = None
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")

class AuditScoreGaugeRequest(BaseModel):
    """Request model for audit score gauge API."""
    user_id: str = Field(..., description="User ID to query", examples=["AA99826"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2025-04-30",
                "lob": ["Commercial"]
            }
        }

class AuditScoreTrend(BaseModel):
    """Audit score data point."""
    period: str = Field(..., description="Time period (format varies by range)")
    avg_audit_score: float = Field(..., description="Average audit score for the period")
    total_cases: int = Field(..., description="Total cases in the period")


class AuditScoreGaugeResponse(BaseModel):
    """Response model for audit score gauge API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: Optional[str] = Field(None, description="User ID")
    audit_score: float = Field(..., description="Average audit score with 2 decimal places")
    score_trend: List[AuditScoreTrend] = Field(default=[], description="Monthly audit score trend")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class DateRange(BaseModel):
    """Date range model for paginated requests."""
    from_date: str = Field(..., alias="from", description="Start date in YYYY-MM-DD format")
    to_date: str = Field(..., alias="to", description="End date in YYYY-MM-DD format")

    class Config:
        populate_by_name = True


class PaginatedQuery(BaseModel):
    """Query parameters for paginated requests."""
    user_id: str = Field(..., description="User ID to query")
    date_range: DateRange = Field(..., description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")


class DirectorPaginatedQuery(BaseModel):
    """Query parameters for director-level paginated requests with manager-associate relationships."""
    user_id: str = Field(..., description="User ID to query")
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter")


class PageRequest(BaseModel):
    """Pagination request parameters."""
    page_limit: int = Field(default=50, ge=1, le=500, description="Number of records per page")
    page: Optional[int] = Field(default=1, ge=1, description="Page number (1-indexed)")
    cursor: Optional[str] = Field(default=None, description="Cursor for cursor-based pagination")


class PageResponse(BaseModel):
    """Pagination response metadata."""
    page_limit: int = Field(..., description="Number of records per page")
    page: int = Field(..., description="Current page number")
    total_records: int = Field(..., description="Total number of records")
    total_pages: int = Field(..., description="Total number of pages")
    cursor: Optional[str] = Field(default=None, description="Cursor for next page")
    has_next: bool = Field(..., description="Whether there are more pages")
    has_previous: bool = Field(..., description="Whether there are previous pages")



class WorkItemsDrilldownRequest(BaseModel):
    """Request model for work items drilldown API."""
    user_id: str = Field(..., description="User ID to query", examples=["AF05867"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AF05867",
                "start_date": "2025-04-03",
                "end_date": "2025-06-05",
                "lob": ["Commercial"]
            }
        }


class WorkItemsDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for work items drilldown API."""
    screen_id: str = Field(default="work_items", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")
    session_id: Optional[str] = Field(None, description="Session ID for caching support")

    class Config:
        json_schema_extra = {
            "example": {
                "page": {
                    "page": 2,
                    "page_limit": 5
                },
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-06-05"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AF05867"
                },
                "screen_id": "work_items"
            }
        }



class WorkItemRecord(BaseModel):
    pyid: str = Field(default="", description="PYID")
    work_type: str = Field(default="", description="Work Type")
    case_cycle_time: str = Field(default="", description="Case Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    resolved_date: str = Field(default="", description="Resolved Date")
    domain_id: str = Field(default="", description="Associate Name")
    platform: str = Field(default="", description="Platform")
    inventory_type: str = Field(default="", description="Inventory Type")


class WorkItemsDrilldownResponse(BaseModel):
    """Response model for work items drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    record_count: int = Field(..., description="Number of records returned")
    records: List[WorkItemRecord] = Field(..., description="List of work items")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class WorkItemsDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for work items drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[WorkItemRecord] = Field(..., description="List of work items")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditScoreDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit score drilldown API."""
    screen_id: str = Field(default="audit_score", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "page": {
                    "page": 2,
                    "page_limit": 5
                },
                "query": {
                    "date_range": {
                        "from": "2025-02-01",
                        "to": "2026-02-07"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AA99826"
                },
                "screen_id": "audit_score"
            }
        }


class AuditScoreRecord(BaseModel):
    pyid: str = Field(default="", description="PYID")
    work_type: str = Field(default="", description="Work Type")
    audit_cycle_time: str = Field(default="", description="Audit Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    audit_resolved: str = Field(default="", description="Audit Resolved Date")
    platform: str = Field(default="", description="Platform")
    audit_score: str = Field(default="", description="Audit Score with %")
    targeted_audit_type: str = Field(default="N/A", description="Targeted Audit Type")
    rebuttal_status: str = Field(default="N/A", description="Rebuttal Status")
    inventory_type: str = Field(default="N/A", description="Inventory Type")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class AuditScoreDrilldownRequest(BaseModel):
    """Request model for audit score drilldown API."""
    user_id: str = Field(..., description="User ID to query", examples=["AA99826"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    page: int = Field(..., ge=1, description="Page number (starts from 1, required)")
    page_size: int = Field(..., ge=1, le=100, description="Number of records per page (required)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "lob": ["Commercial"],
                "page": 1,
                "page_size": 20
            }
        }


class AuditScoreDrilldownResponse(BaseModel):
    """Response model for audit score drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Records per page")
    total_records: int = Field(..., description="Total number of records")
    total_pages: int = Field(..., description="Total number of pages")
    records: List[AuditScoreRecord] = Field(..., description="List of audit scores")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditScoreDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit score drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditScoreRecord] = Field(..., description="List of audit scores")
    completed_audit_work_items: int = Field(default=0, description="Total count of completed audit work items")
    target_audit_count: int = Field(default=0, description="Number of targeted audits")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ProductionPercentageGaugeRequest(BaseModel):
    """Request model for production percentage gauge API."""
    user_id: str = Field(..., description="User ID to query", examples=["AL48579"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for caching support")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AL48579",
                "start_date": "2025-01-24",
                "end_date": "2025-02-24",
                "lob": ["Commercial"],
                "session_id": "session_1775821614_abc123def"
            }
        }

class ProductionPercentageTrend(BaseModel):
    """Production percentage trend data for a specific period."""
    period: str = Field(..., description="Time period (format varies by range)")
    production_percentage: float = Field(..., description="Production percentage for the period")
    total_tasks: int = Field(..., description="Total tasks completed in the period")


class ProductionPercentageGaugeResponse(BaseModel):
    """Response model for production percentage gauge API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    production_percentage_achieved: float = Field(..., description="Production percentage achieved with 2 decimal places")
    score_trend: List[ProductionPercentageTrend] = Field(..., description="Monthly production percentage trend data")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class UserRoleRequest(BaseModel):
    """Request model for user role API."""
    user_id: str = Field(..., description="User ID to query", examples=["1694MU"])

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "1694MU"
            }
        }


class UserRoleResponse(BaseModel):
    """Response model for user role API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    fuse_profile: Optional[str] = Field(None, description="Fuse Profile (PYACCESSGROUP)")
    user_role: Optional[str] = Field(None, description="User Role")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FuseTimeDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for fuse time drilldown API."""
    screen_id: str = Field(default="fuse_time", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "page": {
                    "page": 1,
                    "page_limit": 50
                },
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-04-05"
                    },
                    "user_id": "1694MU"
                },
                "screen_id": "fuse_time"
            }
        }


class FuseTimeRecord(BaseModel):
    user_id: str = Field(default="", description="User ID")
    date: str = Field(default="", description="Login Date (MM/DD/YYYY)")
    log_in: Optional[str] = Field(None, description="First Login Time")
    log_out: Optional[str] = Field(None, description="Last Logout Time")
    total_fuse_time: str = Field(default="", description="Total System Time")
    productive_time: str = Field(default="", description="Productive Time")
    non_productive_time: str = Field(default="", description="Fuse Non-Productive Time")
    other_time: str = Field(default="", description="Other Time (calculated as Total - (Productive + Non-Productive))")


class FuseTimeDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for fuse time drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FuseTimeRecord] = Field(..., description="List of fuse time records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditScoreDrilldownDownloadRequest(BaseModel):
    """Request model for audit score drilldown Excel download (no pagination)."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-02-01",
                        "to": "2026-02-07"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AA99826"
                }
            }
        }


class ProductionPctDrilldownDownloadRequest(BaseModel):
    """Request model for production percentage drilldown Excel download (no pagination)."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-02-01",
                        "to": "2026-02-07"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AL48579"
                }
            }
        }


class WorkItemsDrilldownDownloadRequest(BaseModel):
    """Request model for work items drilldown Excel download (no pagination)."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-06-05"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AF05867"
                }
            }
        }


class FuseTimeDrilldownDownloadRequest(BaseModel):
    """Request model for fuse time drilldown Excel download (no pagination)."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-04-05"
                    },
                    "user_id": "1694MU"
                }
            }
        }


# Director-specific drilldown request models
class AuditScoreDirectorDrilldownRequest(BaseModel):
    """Request model for audit score director drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "sort_by": "date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class FuseTimeDirectorDrilldownRequest(BaseModel):
    """Request model for fuse time director drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "sort_by": "date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class FuseTimeManagerDrilldownRequest(BaseModel):
    """Request model for fuse time manager drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs (not used for filtering in Manager APIs)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class WorkItemsDirectorDrilldownRequest(BaseModel):
    """Request model for work items director drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "sort_by": "resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class WorkItemsManagerDrilldownRequest(BaseModel):
    """Request model for work items manager drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class ManagerQualityOutcomesRequest(BaseModel):
    """Request model for manager quality outcomes API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs to filter associates (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for caching (auto-generated if not provided)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [{"month": "January", "year": 2026}, {"month": "February", "year": 2026}]
            }
        }


class ManagerAuditErrorDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit error drilldown API (Manager version)."""
    status: str = Field(..., description="Response status")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination information")
    records: List["AuditErrorRecord"] = Field(..., description="List of audit error records")
    message: str = Field(..., description="Response message")
    tooltips: dict = Field(default_factory=dict, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerBaseDownloadRequest(BaseModel):
    """Base request model for Manager download APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [{"month": "January", "year": 2026}, {"month": "February", "year": 2026}]
            }
        }


class ManagerAICoachRequest(BaseModel):
    """Request model for manager AI coach API."""
    user_id: Optional[str] = Field(None, description="User ID to query")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for Redis cache retrieval")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "user_id": "AD23980",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["AD23980"]
            }
        }


class ManagerAICoachResponse(BaseModel):
    """Response model for manager AI coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AICoachRequest(BaseModel):
    """Request model for AI coach API."""
    user_id: str = Field(..., description="User ID to query")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for Redis cache retrieval")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "lob": ["Commercial"]
            }
        }


class DirectorAICoachResponse(BaseModel):
    """Response model for AI coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class DirectorAICoachRequest(BaseModel):
    """Request model for AI coach API."""
    user_id: str = Field(..., description="User ID to query")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    director_ids: Optional[List[str]] = Field(None, alias="director_id", description="List of the User Id's of Director")
    manager_ids: Optional[List[str]] = Field(None, alias="manager_id", description="List of the selected Manager's ID")
    frontline_associate_ids: Optional[List[str]] = Field(None, alias="associates_id", description="List of the selected Associates's ID")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for Redis cache retrieval")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "director_ids": ["AD81285"],
                "manager_ids": ["LYKINDN"],
                "frontline_associate_ids": ["AH45556"],
                "lob": ["Commercial"]
            }
        }




# class AICoachResponse(BaseModel):
#     """Response model for AI coach API with enhanced structured output."""
#     # Core fields (required - backward compatible)
#     status: str = Field(..., description="Status of the request (success/error)")
#     user_id: str = Field(..., description="User ID")
#     performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
#     message: str = Field(..., description="Response message")
#     service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
#     
#     # Enhanced fields (optional - new in v2.0)
#     confidence: Optional[float] = Field(None, description="Confidence score 0.0-1.0 for AI analysis")
#     primary_issue: Optional[str] = Field(None, description="Primary performance issue identified")
#     primary_metric: Optional[str] = Field(None, description="Primary metric driving the issue")
#     secondary_issues: Optional[List[str]] = Field(None, description="Secondary issues identified")
#     data_gaps: Optional[List[str]] = Field(None, description="Missing data that limits analysis")
#     recommended_action: Optional[str] = Field(None, description="Specific recommended action")
#     severity: Optional[str] = Field(None, description="Issue severity: low, medium, high")
#     metadata: Optional[Dict[str, Any]] = Field(None, description="Analysis metadata (model, tokens, cost, etc.)")


# =============================================================================
# Performance IQ Director Models
# =============================================================================

class DirectorBaseRequest(BaseModel):
    """Base request model for director-level APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for synchronized caching across all Director APIs")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"]
            }
        }


class DirectorHeaderKPIsRequest(DirectorBaseRequest):
    """Request model for director header KPIs."""
    pass


class ManagerListRequestForDirector(BaseModel):
    """Request model for managers list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    search: Optional[str] = Field(None, description="Search term to filter managers")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    directors: List[str] = Field(default=[], description="List of directors ID's")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "search": None,
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "directors": ["SANTICH"]
            }
        }

class ManagerListRequest(BaseModel):
    """Request model for managers list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    search: Optional[str] = Field(None, description="Search term to filter managers")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "search": None,
                "start_date": "2025-01-01",
                "end_date": "2025-12-31"
            }
        }


class ManagerItem(BaseModel):
    """Individual manager item."""
    manager_id: str = Field(..., description="Manager ID")
    manager_name: str = Field(..., description="Manager name")


class ManagerListResponse(BaseModel):
    """Response model for managers list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    managers: List[ManagerItem] = Field(default=[], description="List of managers")
    total_count: int = Field(..., description="Total number of managers")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class DirectorListRequest(BaseModel):
    """Request model for directors list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    search: Optional[str] = Field(None, description="Search term to filter directors")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "search": None,
                "start_date": "2026-03-01",
                "end_date": "2026-03-31"
            }
        }


class DirectorItem(BaseModel):
    """Individual director item."""
    director_id: str = Field(..., description="Director ID")
    director_name: str = Field(..., description="Director name")


class DirectorListResponse(BaseModel):
    """Response model for directors list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    directors: List[DirectorItem] = Field(default=[], description="List of directors")
    total_count: int = Field(..., description="Total number of directors")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AssociateListRequest(BaseModel):
    """Request model for associates list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: list[Optional[str]] = Field(None, description="Filter by manager id")
    search: Optional[str] = Field(None, description="Search term to filter associates")
    limit: int = Field(default=10000, ge=1, le=10001, description="Maximum number of results")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "manager_ids": ["AD23980"],
                "search": None,
                "limit": 50
            }
        }


class AssociateItem(BaseModel):
    """Individual associate item."""
    associate_id: str = Field(..., description="Associate ID")
    associate_name: Optional[str] = Field(None, description="Associate name")
    manager_name: Optional[str] = Field(None, description="Manager name")
    experience_level: Optional[str] = Field(None, description="Experience level")


class AssociateListResponse(BaseModel):
    """Response model for associates list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    associates: List[AssociateItem] = Field(default=[], description="List of associates")
    total_count: int = Field(..., description="Total number of associates")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class BacklogByStatusItem(BaseModel):
    """Individual backlog status item."""
    status: str = Field(..., description="Work status")
    count: int = Field(..., description="Count of items")


class DemandInventoryResponse(BaseModel):
    """Response model for demand inventory metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    backlog_volume: int = Field(..., description="Total backlog volume")
    backlog_by_status: List[BacklogByStatusItem] = Field(default=[], description="Backlog breakdown by status")
    escalation_count: int = Field(..., description="Total escalation count")
    escalation_by_priority: List[Dict[str, Any]] = Field(default=[], description="Escalation breakdown by priority")
    pended_items_count: int = Field(..., description="Pended items count")
    watchlist_count: str = Field(default="N/A", description="Watchlist count (TBD)")
    work_items_completed: int = Field(..., description="Work items completed")
    non_value_add_pct: float = Field(..., description="Non-value add percentage")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AssignmentTypeItem(BaseModel):
    """Assignment type breakdown item."""
    assignment_type: str = Field(..., description="Assignment type (GNW Assigned or Manually Assigned)")
    percentage: float = Field(..., description="Percentage of total assignments for this type")
    reassigned_percentage: float = Field(..., description="Reassigned percentage for this assignment type")


class TaktTimeItem(BaseModel):
    """Takt time by SLA bucket item."""
    cob_sla_bucket: str = Field(..., description="COB SLA bucket (e.g., '4 hours', '2 days', '10 days', '30 days')")
    backlog: int = Field(..., description="Backlog count for this SLA bucket")
    available_hours: float = Field(..., description="Available hours for this SLA bucket")
    takt_time_hours: float = Field(..., description="Takt time in hours (Available Hours / Backlog)")
    takt_time_minutes: float = Field(..., description="Takt time in minutes")


class OperationalFlowResponse(BaseModel):
    """Response model for operational flow metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    lead_time_avg_days: float = Field(..., description="Average lead time in days")
    cycle_takt_gap: str = Field(default="N/A", description="Cycle-Takt gap (coming 2/20)")
    assignment_type_breakdown: List[AssignmentTypeItem] = Field(default=[], description="Assignment type breakdown")
    reassign_pct: float = Field(..., description="Reassignment percentage")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class QualityOutcomesResponse(BaseModel):
    """Response model for quality outcomes metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    audit_sample_pct: str = Field(default="N/A", description="Audit sample percentage (TBD)")
    audit_sample_count: str = Field(default="N/A", description="Audit sample count as fraction (e.g., '1.3K of 13K')")
    audit_cycle_time_avg: str = Field(default="N/A", description="Audit cycle time average (coming 2/20)")
    completed_audit_count: str = Field(default="N/A", description="Completed audit count")
    audit_error_count: str = Field(default="N/A", description="Average Error Count")
    rebuttal_count: str = Field(default="N/A", description="Rebuttal count")
    rebuttal_overturn_pct: str = Field(default="N/A", description="Rebuttal overturn percentage (coming 2/20)")
    rework_pct: str = Field(default="N/A", description="Rework percentage (TBD)")
    fuse_time: int = Field(default=0, description="Total FUSE time in hours")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    audit_cycle_time_avg_status: str = Field(default="N/A", description="Status for Audit Cycle Time Avg")
    rework_pct_status: str = Field(default="N/A", description="Status for Rework Percentage")

class ManagerQualityOutcomesSimpleResponse(BaseModel):
    """Response model for manager quality outcomes metrics (simplified)."""
    status: str = Field(..., description="Status of the request (success/error)")
    completed_audit_count: int = Field(..., description="Completed audit count")
    audit_error_count: str = Field(default="0", description="Average Error Count")
    rebuttal_count: int = Field(..., description="Rebuttal count")
    rebuttal_overturn_pct: str = Field(default="N/A", description="Rebuttal overturn percentage")
    rework_pct: str = Field(default="N/A", description="Rework percentage (TBD)")
    fuse_time: str = Field(default="N/A", description="Total FUSE time in HH.MM format")
    watchlist_count: int = Field(default=0, description="Watchlist count")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    session_id: Optional[str] = Field(default=None, description="Session identifier for cache reuse")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class CacheMetadata(BaseModel):
    """Metadata about cache status for session-based caching."""
    session_id: Optional[str] = Field(default=None, description="Session identifier")
    cache_hit: bool = Field(default=False, description="Whether data was retrieved from cache")
    cached_at: Optional[str] = Field(default=None, description="Timestamp when data was cached (ISO format)")
    expires_at: Optional[str] = Field(default=None, description="Timestamp when cache expires (ISO format)")
    apis_cached: Optional[List[str]] = Field(default=None, description="List of APIs included in this cache session")
    
    @field_validator('apis_cached', mode='before')
    @classmethod
    def convert_apis_cached(cls, v):
        """Convert legacy integer format to list."""
        if isinstance(v, int):
            # Legacy format - convert count to list with placeholder
            return [f"{v} APIs"] if v > 0 else []
        return v

class HeaderKPIsResponse(BaseModel):
    """Response model for director header KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    work_items_completed: int = Field(..., description="Work items completed")
    production_pct_achieved: float = Field(..., description="Production percentage achieved")
    audit_score_pct: float = Field(..., description="Audit score percentage")
    cycle_time_avg: str = Field(default="N/A", description="Cycle time average (coming 2/20)")
    takt_time: str = Field(default="N/A", description="Takt time")
    volume_forecast_accuracy: str = Field(default="N/A", description="Volume forecast accuracy (TBD)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    production_pct_achieved_status: str = Field(default="N/A", description="Status for Production percentage achieved")
    audit_score_pct_status: str = Field(default="N/A", description="Status for Audit score percentage")
    cycle_time_avg_status: str = Field(default="N/A", description="Status for Cycle time average")


class ExperienceLevelItem(BaseModel):
    """Experience level distribution item."""
    level: str = Field(..., description="Experience level")
    count: int = Field(..., description="Count of associates")
    percentage: float = Field(..., description="Percentage of total")


class CapacityInsightItem(BaseModel):
    """Individual capacity insight item for bar chart."""
    date_range: str = Field(..., description="Date range (e.g., '1/1/26-1/5/26')")
    required_fte: int = Field(..., description="Required FTE")
    available_fte: int = Field(..., description="Available FTE")


class AssociateUtilizationResponse(BaseModel):
    """Response model for associate utilization metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    staff_utilization_pct: str = Field(default="N/A", description="Staff utilization percentage (Workday TBD)")
    total_fuse_time_hours: float = Field(..., description="Total available hours (Total System Time - Non-Productive Time)")
    total_non_productive_hours: float = Field(..., description="Total non-productive time in hours")
    ohi_productive_time: float = Field(default=0.0, description="OHI productive time in hours from PRODUCTIVETIME column")
    other_time_hours: float = Field(default=0.0, description="Other time in hours (calculated as Total - Productive - Non-Productive)")
    productive_pct: float = Field(default=0.0, description="Productive time percentage")
    non_productive_pct: float = Field(default=0.0, description="Non-productive time percentage")
    other_pct: float = Field(default=0.0, description="Other time percentage")
    experience_level_distribution: List[ExperienceLevelItem] = Field(default=[], description="Experience level distribution")
    utilization_trend: List[AuditScoreTrend] = Field(default=[], description="Utilization trend over time (reusing AuditScoreTrend structure)")
    production_trend: List[ProductionPercentageTrend] = Field(default=[], description="Production percentage trend over time")
    capacity_insights: Dict[str, Dict[str, int]] = Field(default={}, description="Capacity insights with date range as key and required_fte/available_fte as values")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class LOBRequest(BaseModel):
    """Request model for LOB list API."""
    user_id: str = Field(..., description="User ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    director_id: Optional[List[str]] = Field(None, description="User Id of Director")
    manager_ids: Optional[List[str]] = Field(None, description="List of the selected Manager's ID")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of the selected Associates's ID")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-01-01",
                "end_date": "2025-12-31",
                "director_ids": ["AD81285"],
                "manager_ids": ["LYKINDN"],
                "associates_id": ["AH45556"]
            }
        }


class LOBResponse(BaseModel):
    """Response model for LOB list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(..., description="List of available LOBs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class DirectorLOBRequest(BaseModel):
    """Request model for Director LOB list API with manager-associate filtering."""
    user_id: str = Field(..., description="User ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"]
            }
        }


class DirectorLOBResponse(BaseModel):
    """Response model for Director LOB list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(..., description="List of available LOBs filtered by manager-associate relationships")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerLOBRequest(BaseModel):
    """Request model for Manager LOB list API with associate filtering."""
    user_id: str = Field(..., description="User ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs (not used for filtering in Manager APIs)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "frontline_associate_ids": ["AF18006"],
                "manager_ids": ["AD59226"],
            }
        }


class ManagerLOBResponse(BaseModel):
    """Response model for Manager LOB list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(..., description="List of available LOBs for manager's team")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class SLAHealthResponse(BaseModel):
    """Response model for SLA health metrics (placeholder)."""
    status: str = Field(..., description="Status of the request (success/error)")
    cob_sla_pct: str = Field(default="N/A", description="COB SLA percentage (awaiting SLA definition)")
    elv_sla_pct: str = Field(default="N/A", description="ELV SLA percentage (awaiting SLA definition)")
    completed_elv_sla: str = Field(default="N/A", description="ELV SLA Completed (awaiting SLA definition)")
    completed_cob_sla: str = Field(default="N/A", description="COB SLA Completed (awaiting SLA definition)")
    sla_risk_pct: str = Field(default="N/A", description="SLA risk percentage (awaiting SLA definition)")
    out_of_sla_pct: str = Field(default="N/A", description="Out of SLA percentage (awaiting SLA definition)")
    counts_by_sla: Dict[str, int] = Field(default_factory=dict, description="Counts by SLA brackets (bucket name -> count)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class EscalationCountQuery(BaseModel):
    """Query parameters for escalation count drilldown requests."""
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    priority: Optional[List[str]] = Field(None, description="List of priority values (Instant, Immediate, Urgent)")


class EscalationCountDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for escalation count drilldown API."""
    screen_id: str = Field(default="escalation_count", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter (default: all)")
    priority: Optional[List[str]] = Field(None, description="List of priority values (Instant, Immediate, Urgent)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(default=1, description="Page number (starts from 1)")
    page_size: int = Field(default=20, description="Records per page (max: 100)")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "escalation_count",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "priority": ["Instant", "Immediate"],
                "page": 1,
                "page_size": 20
            }
        }


class EscalationCountRecord(BaseModel):
    """Individual escalation count record."""
    work_item_id: str = Field(..., description="Work Item ID (PYID)")
    workitem_type: str = Field(..., description="Work Item Type")
    priority: str = Field(..., description="Priority Level")
    status: str = Field(..., description="Work Item Status")
    lob: Optional[str] = Field(None, description="Line of Business")
    platform: Optional[str] = Field(None, description="Platform")
    cob_sla: Optional[str] = Field(None, description="COB SLA")
    elv_due_date: Optional[str] = Field(None, description="ELV Due Date (MM/DD/YYYY)")


class EscalationCountDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for escalation count drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[EscalationCountRecord] = Field(..., description="List of escalation records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class PendedItemsQuery(BaseModel):
    """Query parameters for pended items drilldown requests."""
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    status: Optional[List[str]] = Field(None, description="List of status values (e.g., Pend, Pending)")


class PendedItemsDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for pended items drilldown API."""
    screen_id: str = Field(default="pended_items", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    status: Optional[List[str]] = Field(None, description="List of status values (e.g., ['Pend', 'Pending'])")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "pended_items",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "status": ["Pend", "Pending"],
                "page": 1,
                "page_size": 20
            }
        }


class PendedItemsRecord(BaseModel):
    """Individual pended items record."""
    work_item_id: str = Field(..., description="Work Item ID (PYID)")
    worktype_category: str = Field(..., description="Work Type Category")
    status: str = Field(..., description="Work Item Status")
    lob: Optional[str] = Field(None, description="Line of Business")
    days_pended: str = Field(..., description="Number of days pended")
    pend_date: Optional[str] = Field(None, description="Pend Date (MM/DD/YYYY)")
    due_date: Optional[str] = Field(None, description="Due Date (MM/DD/YYYY)")
    resolved_date: Optional[str] = Field(None, description="Resolved Date (MM/DD/YYYY)")
    associate_name: Optional[str] = Field(None, description="Associate Name")


class PendedItemsDrilldownResponse(BaseModel):
    """Response model for pended items drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Records per page")
    total_records: int = Field(..., description="Total number of records")
    total_pages: int = Field(..., description="Total number of pages")
    records: List[PendedItemsRecord] = Field(..., description="List of pended items records")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class PendedItemsDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for pended items drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[PendedItemsRecord] = Field(..., description="List of pended items records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ProductionPctAchievedQuery(BaseModel):
    """Query parameters for production percentage achieved drilldown requests."""
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    associate: Optional[str] = Field(None, description="Associate ID to filter by")


class ProductionPctAchievedRecord(BaseModel):
    """Individual production percentage achieved record."""
    work_item_id: str = Field(..., description="Work Item ID (PYID)")
    worktype: str = Field(..., description="Work Type")
    standard_time: str = Field(..., description="Standard Time in minutes")
    case_cycle_time: str = Field(..., description="Case Cycle Time")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: Optional[str] = Field(None, description="Line of Business")
    resolved_date: Optional[str] = Field(None, description="Resolved Date (MM/DD/YYYY)")
    associate: Optional[str] = Field(None, description="Associate Full Name")
    activity_code: str = Field(default="N/A", description="Activity Code")
    platform: str = Field(default="N/A", description="Platform")


class ProductionPctAchievedDrilldownPaginatedRequest(BaseModel):
    """Request model for production percentage achieved drilldown API."""
    screen_id: str = Field(default="production_pct_achieved", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "production_pct_achieved",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "page": 1,
                "page_size": 20
            }
        }


class FrontlineProductionPctDrilldownRequest(BaseModel):
    """Simple request model for frontline production percentage drilldown."""
    screen_id: str = Field(default="production_pct_achieved", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")
    session_id: Optional[str] = Field(None, description="Session ID for caching support")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "production_pct_achieved",
                "query": {
                    "user_id": "AA99826",
                    "date_range": {
                        "from": "2025-02-01",
                        "to": "2026-02-07"
                    },
                    "lob": ["Commercial"]
                },
                "page": {
                    "page": 1,
                    "page_limit": 20
                }
            }
        }


class ProductionPctAchievedDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for production percentage achieved drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[ProductionPctAchievedRecord] = Field(..., description="List of production records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    cache_metadata: Optional[CacheMetadata] = Field(default=None, description="Cache status metadata")


class RebuttalQuery(BaseModel):
    """Query parameters for rebuttal drilldown requests."""
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    domain_id: Optional[str] = Field(None, description="Domain ID to filter by")


class RebuttalRecord(BaseModel):
    """Individual rebuttal record."""
    work_item_id: str = Field(..., description="Work Item ID (PYID)")
    worktype_category: str = Field(..., description="Work Type Category")
    outcome_status: str = Field(..., description="Outcome Status")
    lob: Optional[str] = Field(None, description="Line of Business")
    resolved_date: Optional[str] = Field(None, description="Resolved Date (MM/DD/YYYY)")
    domain_id: Optional[str] = Field(None, description="Domain ID")
    platform_source_system: Optional[str] = Field(None, description="Platform Source System")
    error_category: Optional[str] = Field(default="N/A", description="Error Category")
    error_type: Optional[str] = Field(default="N/A", description="Error Type")
    rebuttal_outcome: Optional[str] = Field(default="N/A", description="Rebuttal Outcome")
    associate_name: Optional[str] = Field(default="N/A", description="Associate Name")
    audit_month: Optional[str] = Field(default="N/A", description="Audit Month")
    audit_year: Optional[str] = Field(default="N/A", description="Audit Year")


class RebuttalDrilldownResponse(BaseModel):
    """Response model for rebuttal drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Records per page")
    total_records: int = Field(..., description="Total number of records")
    total_pages: int = Field(..., description="Total number of pages")
    records: List[RebuttalRecord] = Field(..., description="List of rebuttal records")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class RebuttalDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for rebuttal drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[RebuttalRecord] = Field(..., description="List of rebuttal records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Performance IQ Manager Models
# =============================================================================

class AuditPeriod(BaseModel):
    """Audit period model for filtering by month and year."""
    year: str = Field(..., description="Audit year")
    month: str = Field(..., description="Audit month")


class ManagerBaseRequest(BaseModel):
    """Base request model for manager-level APIs."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs to filter associates (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for synchronized caching across all Manager APIs")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods (month/year) for audit score filtering")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [{"month": "January", "year": 2026}, {"month": "February", "year": 2026}]
            }
        }


class ManagerHeaderKPIsRequest(ManagerBaseRequest):
    """Request model for manager header KPIs."""
    pass


class ManagerHeaderKPIsResponse(BaseModel):
    """Response model for manager header KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    work_items_completed: int = Field(..., description="Work items completed by team")
    production_pct_achieved: float = Field(..., description="Production percentage achieved by team")
    audit_score_pct: float = Field(..., description="Audit score percentage for team")
    pended_items_count: int = Field(..., description="Pended items count")
    non_value_add_pct: float = Field(..., description="Non-value add percentage")
    cycle_time_avg: str = Field(default="N/A", description="Cycle time average")
    team_rank: Optional[int] = Field(None, description="Team rank among all teams")
    department_rank: Optional[int] = Field(None, description="Department rank")
    skilled_sources: Optional[List[str]] = Field(default=[], description="List of skilled sources")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    production_pct_achieved_status: str = Field(default="N/A", description="Status for Production percentage achieved")
    audit_score_pct_status: str = Field(default="N/A", description="Status for Audit score percentage")
    cycle_time_avg_status: str = Field(default="N/A", description="Status for Cycle time average")


class ManagerQualityOutcomesData(BaseModel):
    """Data model for quality outcomes metrics."""
    production_pct_achieved: float = Field(..., description="Production percentage achieved")
    production_goal: float = Field(default=100, description="Production goal percentage")
    audit_score_pct: float = Field(..., description="Audit score percentage")
    audit_score_goal: float = Field(default=98, description="Audit score goal percentage")
    fuse_time_productive_pct: float = Field(..., description="OHI productive time percentage")
    fuse_time_non_productive_pct: float = Field(..., description="Fuse non-productive time percentage")
    rebuttal_count: int = Field(..., description="Number of rebuttals")
    rebuttal_status: str = Field(default="Not Overturned", description="Rebuttal status")
    rework_pct: float = Field(..., description="Rework percentage")
    fuse_time_value: int = Field(..., description="Fuse time value")
    complete_audit_count: int = Field(..., description="Complete audit count")
    audit_errors: int = Field(..., description="Audit errors count")


class ManagerQualityOutcomesResponse(BaseModel):
    """Response model for manager quality outcomes."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: ManagerQualityOutcomesData = Field(..., description="Quality outcomes data")
    message: Optional[str] = Field(None, description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerTimeUtilizationResponse(BaseModel):
    """Response model for manager time utilization metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    staff_utilization_pct: str = Field(default="N/A", description="Staff utilization percentage (Workday TBD)")
    capacity_pct: str = Field(default="N/A", description="Capacity percentage (Workday TBD)")
    total_fuse_time_hours: float = Field(..., description="Total fuse time in hours")
    total_non_productive_hours: float = Field(..., description="Total non-productive time in hours")
    ohi_productive_time: float = Field(default=0.0, description="OHI productive time in hours from PRODUCTIVETIME column")
    other_time_hours: float = Field(default=0.0, description="Other time in hours (calculated as Total - Productive - Non-Productive)")
    productive_pct: float = Field(default=0.0, description="Productive time percentage")
    non_productive_pct: float = Field(default=0.0, description="Non-productive time percentage")
    other_pct: float = Field(default=0.0, description="Other time percentage")
    experience_level_distribution: List[ExperienceLevelItem] = Field(default=[], description="Experience level distribution")
    utilization_trend: List[AuditScoreTrend] = Field(default=[], description="Utilization trend over time (reusing AuditScoreTrend structure)")
    production_trend: List[ProductionPercentageTrend] = Field(default=[], description="Production percentage trend over time")
    capacity_insights: List[CapacityInsightItem] = Field(default=[], description="Capacity insights data for bar chart")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class CapacityInsightRecord(BaseModel):
    """Individual capacity insight record."""
    month_prior_year: str = Field(..., description="Month (Prior Year)")
    total_required_hours: str = Field(..., description="Total Required Hours")
    total_available_hours: str = Field(..., description="Total Available Hours")
    fte_gap: str = Field(..., description="FTE Gap")
    avg_available_hours_daily: str = Field(..., description="Avg Available Hours Daily")
    total_pto_hours: str = Field(..., description="Total PTO Hours")
    total_uto_hours: str = Field(..., description="Total UTO Hours")
    in_year_required_hours_prediction: str = Field(..., description="In Year Required Hours (Prediction)")
    in_year_available_hours: str = Field(..., description="In Year Available Hours")
    variance: str = Field(..., description="Variance")


class CapacityInsightDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for capacity insight drilldown API."""
    screen_id: str = Field(default="capacity_insights", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")


    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "capacity_insights",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class CapacityInsightDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for capacity insight drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CapacityInsightRecord] = Field(..., description="List of capacity insight records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerCapacityInsightDrilldownRequest(BaseModel):
    """Paginated request model for manager capacity insight drilldown API."""
    screen_id: str = Field(default="capacity_insights", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs (not used for filtering in Manager APIs)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "capacity_insights",
                "user_id": "AM42536",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["AM42536"],
                "frontline_associate_ids": ["AF18006"],
                "page": 1,
                "page_size": 20
            }
        }


class ManagerCapacityInsightDrilldownResponse(BaseModel):
    """Paginated response model for manager capacity insight drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CapacityInsightRecord] = Field(..., description="List of capacity insight records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class SlaHealthRecord(BaseModel):
    """Individual SLA health record."""
    work_item: str = Field(..., description="Work Item ID")
    work_type: str = Field(..., description="Work Type")
    associate: str = Field(..., description="Associate Name")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    platform: str = Field(..., description="Platform")
    manager_name: str = Field(..., description="Manager Name")
    assigned_date: str = Field(..., description="Assigned Date")
    cob: str = Field(..., description="COB")
    elv_due_date: str = Field(..., description="ELV Due Date")


class SlaHealthDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for SLA health drilldown API."""
    screen_id: str = Field(default="sla_health", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Director ID to filter (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "sla_health",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class SlaHealthDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for SLA health drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[SlaHealthRecord] = Field(..., description="List of SLA health records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class CompletedAtaCountsRecord(BaseModel):
    """Individual completed ATA counts record."""
    work_item: str = Field(..., description="Work Item ID")
    worktype_category: str = Field(..., description="Worktype Category")
    ata_cycle_time: str = Field(..., description="ATA Cycle Time")
    ata_resolved_status: str = Field(..., description="ATA Resolved Status")
    lob: str = Field(..., description="Line of Business")
    ata_resolved_date: str = Field(..., description="ATA Resolved Date")
    platform_source_system: str = Field(..., description="Platform - Source System")


class CompletedAtaCountsDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for completed ATA counts drilldown API."""
    screen_id: str = Field(default="completed_ata_counts", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "completed_ata_counts",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class CompletedAtaCountsDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for completed ATA counts drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CompletedAtaCountsRecord] = Field(..., description="List of completed ATA counts records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditSamplePctRecord(BaseModel):
    """Audit sample percentage summary record."""
    date_range: str = Field(..., description="Date Range (e.g., '1/1/2026 — 1/7/2026')")
    open_audits: int = Field(..., description="Number of Open Audits")
    closed_audits: int = Field(..., description="Number of Closed Audits")
    pending_audits: int = Field(..., description="Number of Pending Audits")
    total_cases_resolved: int = Field(..., description="Total cases resolved by FL associate during previous week")


class AuditSamplePctDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit sample percentage drilldown API."""
    screen_id: str = Field(default="audit_sample_pct", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    audit_status: Optional[str] = Field(None, description="Audit status filter (Open, Closed, Pending)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "audit_sample_pct",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_status": "Open",
                "page": 1,
                "page_size": 20
            }
        }


class AuditSamplePctDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit sample percentage drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditSamplePctRecord] = Field(..., description="List of audit sample percentage records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class WatchlistRecord(BaseModel):
    """Individual watchlist record."""
    work_item: str = Field(..., description="Work Item ID")
    work_type: str = Field(..., description="Work Type")
    associate: str = Field(..., description="Associate Name")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    platform: str = Field(..., description="Platform")
    elv_due_date: str = Field(..., description="ELV Due Date")


class WatchlistDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for watchlist drilldown API."""
    screen_id: str = Field(default="watchlist", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    resolved_status: Optional[str] = Field(None, description="Resolved status filter (Resolved, Open)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "watchlist",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "resolved_status": "Open",
                "page": 1,
                "page_size": 20
            }
        }


class WatchlistDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for watchlist drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[WatchlistRecord] = Field(..., description="List of watchlist records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerWatchlistDrilldownResponse(BaseModel):
    """Paginated response model for manager watchlist drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[WatchlistRecord] = Field(..., description="List of watchlist records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class CycleTaktRecord(BaseModel):
    """Individual cycle-takt gap record."""
    work_item: str = Field(..., description="Work Item ID")
    work_type: str = Field(..., description="Work Type")
    case_cycle_time: str = Field(..., description="Case Cycle Time")
    cycle_takt_gap: str = Field(..., description="Cycle-Takt Gap")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    resolved_date: str = Field(..., description="Resolved Date (MM/DD/YYYY)")
    associate: str = Field(..., description="Associate Name")
    member_source_system: str = Field(..., description="Memer Source System")


class CycleTaktDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for the cycle takt gap drilldown API."""
    screen_id: str = Field(default="cycle_takt_gap", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(
        None, description="Frontline associate ID to filter (default: all)"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "cycle_takt_gap",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20,
            }
        }


class CycleTaktDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for the cycle takt gap drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CycleTaktRecord] = Field(..., description="List of cycle-takt gap records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ReworkPctRecord(BaseModel):
    """Individual rework percentage record."""
    work_item: str = Field(..., description="Work Item ID")
    work_type: str = Field(..., description="Work Type")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    resolved_date: str = Field(..., description="Resolved Date")
    platform: str = Field(..., description="Platform")
    audit_score: str = Field(..., description="Audit Score")
    auditor_name: str = Field(..., description="Auditor Name")


class ReworkPctDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for rework percentage drilldown API."""
    screen_id: str = Field(default="rework_pct", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    resolved_status: Optional[str] = Field(None, description="Resolved status filter (Resolved, Resolved - Autoclosed)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "rework_pct",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "resolved_status": "Resolved",
                "page": 1,
                "page_size": 20
            }
        }


class ReworkPctDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for rework percentage drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[ReworkPctRecord] = Field(..., description="List of rework percentage records")

    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class ManagerUserActivityRequest(BaseModel):
    """Request model for manager user activity API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs (default: all)")
    associate_ids: Optional[List[str]] = Field(None, description="Associate IDs who report to the manager (default: all)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AD13460",
                "start_date": "2025-08-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial"],
                "manager_ids": ["AD13460"],
                "associate_ids": ["AH40730", "AI06493"]
            }
        }

class ManagerUserActivityData(BaseModel):
    """Data section for manager user activity response."""
    associate_id: str
    login_logout_records: List[LoginLogoutRecord]
    skilled_sources: List[str]
    team_rank: str = Field(default="NA", description="Team Rank")
    department_rank: str = Field(default="NA", description="Department Rank")
    ramp: str = Field(default="N/A", description="Experience level/ramp status")


class ManagerUserActivityResponse(BaseModel):
    """Response model for manager user activity API."""
    meta: Dict[str, str]
    data: Optional[ManagerUserActivityData] = None
    errors: Optional[List[Dict[str, Any]]] = None
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")


class CompletedAuditCountRecord(BaseModel):
    """Individual completed audit count record."""
    work_item: str = Field(..., description="Work Item ID")
    worktype_category: str = Field(..., description="Worktype Category")
    audit_cycle_time: str = Field(..., description="Audit Cycle Time")
    audit_resolved_status: str = Field(..., description="Audit Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    audit_resolved_date: str = Field(..., description="Audit Resolved Date")
    auditor_id: str = Field(..., description="Auditor ID")
    auditor_name: str = Field(..., description="Auditor Name")
    platform_source_system: str = Field(..., description="Platform - Source System")
    audit_month: Optional[str] = Field(default="N/A", description="Audit Month")
    audit_year: Optional[str] = Field(default="N/A", description="Audit Year")


class CompletedAuditCountDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for completed audit count drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CompletedAuditCountRecord] = Field(..., description="List of completed audit count records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditErrorRecord(BaseModel):
    work_item_id: str = Field(default="", description="Work Item ID")
    work_item: str = Field(default="", description="Work Item ID")
    work_type: str = Field(default="", description="Work Type")
    error_category: str = Field(default="", description="Error Category")
    associate_name: str = Field(default="", description="Associate Name")
    date_assessed: str = Field(default="", description="Date Assessed")
    inventory_type: str = Field(default="", description="Inventory Type")
    lob: str = Field(default="", description="LOB")
    platform: str = Field(default="", description="Platform")
    error_corrected: str = Field(default="", description="Error Corrected")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class AuditErrorDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit error drilldown API."""
    screen_id: str = Field(default="audit_error", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "page": {
                    "page": 1,
                    "page_limit": 50
                },
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-06-05"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AF05867"
                },
                "screen_id": "audit_error"
            }
        }


class AuditErrorDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit error drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditErrorRecord] = Field(..., description="List of audit error records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditErrorDrilldownDownloadRequest(BaseModel):
    """Download request model for audit error drilldown API."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-06-05"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AF05867"
                }
            }
        }


class AuditErrorDirectorDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit error drilldown API (Director version)."""
    screen_id: str = Field(default="audit_error_director", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "audit_error_director",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "page": 1,
                "page_size": 20
            }
        }


class AuditErrorDirectorDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit error drilldown API (Director version)."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditErrorRecord] = Field(..., description="List of audit error records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# Director Download Request Models
class DirectorBaseDownloadRequest(BaseModel):
    """Base download request model for Director drilldown APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse (enables instant Excel downloads from cached data)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"]
            }
        }


# Manager Drilldown Request Models
class AuditScoreManagerDrilldownRequest(BaseModel):
    """Request model for audit score manager drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods (month/year pairs) to filter by")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [],
                "sort_by": None,
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


# Manager Download Request Models
class ManagerBaseDownloadRequest(BaseModel):
    """Base download request model for Manager drilldown APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [{"month": "January", "year": 2026}, {"month": "February", "year": 2026}]
            }
        }


class DirectorUserActivityRequest(BaseModel):
    """Request model for director user activity API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    frontline_associate_id: str = Field(..., description="Frontline associate ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "frontline_associate_id": "AH40730",
                "start_date": "2025-08-01",
                "end_date": "2026-03-31"
            }
        }


class DirectorUserActivityData(BaseModel):
    """Data section for director user activity response."""
    team_rank: str = Field(default="NA", description="Team Rank")
    department_rank: str = Field(default="NA", description="Department Rank")
    ramp: str = Field(default="N/A", description="Experience level/ramp status")
    skilled_sources: List[str] = Field(default_factory=list, description="List of skilled source systems")


class DirectorUserActivityResponse(BaseModel):
    """Response model for director user activity API."""
    meta: Dict[str, str]
    data: Optional[DirectorUserActivityData] = None
    errors: Optional[List[Dict[str, Any]]] = None
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")


# =============================================================================
# Performance IQ Auditor Manager Models
# =============================================================================

class AuditorManagerBaseRequest(BaseModel):
    """Base request model for auditor manager-level APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit cycle time"
    )
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for Redis cache retrieval")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AM12345",
                "start_date": "2026-03-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"]
            }
        }


class AuditorManagerListRequest(BaseModel):
    """Request model for auditor manager's manager list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    search: Optional[str] = Field(None, description="Search term to filter managers by name or ID")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AM12345",
                "search": None,
                "start_date": "2026-01-01",
                "end_date": "2026-03-31"
            }
        }

class AuditorListRequest(BaseModel):
    """Request model for auditor manager's auditor list API."""
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    manager_ids: list[Optional[str]] = Field(None, description="Filter by manager id")
    search: Optional[str] = Field(None, description="Search term to filter auditors by ID or name")
    limit: int = Field(default=10000, ge=1, le=10001, description="Maximum number of results")

    class Config:
        json_schema_extra = {
            "example": {
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "manager_ids": ["AC95624", "AM67537"],
                "search": None,
                "limit": 50
            }
        }


class AuditorManagerLOBRequest(BaseModel):
    """Request model for Auditor Manager LOB list API with auditor filtering."""
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    auditor_ids: Optional[List[str]] = Field(None, description="List of auditor IDs to filter")
    
    class Config:
        json_schema_extra = {
            "example": {
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "auditor_ids": ["AF18133", "AD47521"],
                "manager_ids": ["AC95624"],
            }
        }


class AuditorManagerLOBResponse(BaseModel):
    """Response model for Auditor Manager LOB list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(..., description="List of available LOBs filtered by auditor relationships")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerHeaderKPIsResponse(BaseModel):
    """Response model for auditor manager header KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    complete_audit_count: str = Field(..., description="Total completed audits")
    audit_sample_percent: str = Field(..., description="Audit sample percentage")
    audit_sample_count: str = Field(default="N/A", description="Number of items audited")
    work_items_completed: str = Field(..., description="Work items completed")
    audit_cycle_time: str = Field(default="N/A", description="Average audit cycle time (coming soon)")
    audit_cycle_time_bubble: str = Field(default="N/A", description="Audit cycle time status bubble (coming soon)")
    ata_audit_score: str = Field(default="N/A", description="ATA audit score (coming soon)")
    ata_audit_score_bubble: str = Field(default="N/A", description="ATA audit score status bubble (coming soon)")
    ata_rebuttals: str = Field(default="N/A", description="ATA rebuttals count (coming soon)")
    ata_rebuttal_percent: str = Field(default="N/A", description="ATA audit rebuttal percentage (coming soon)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerTimeUtilizationResponse(BaseModel):
    """Response model for auditor manager time utilization metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    total_fuse_time_hours: float = Field(..., description="Total FUSE time in hours (2 decimal places)")
    ohi_productive_time: float = Field(..., description="OHI productive time in hours (2 decimal places)")
    total_non_productive_hours: float = Field(..., description="Total non-productive time in hours (2 decimal places)")
    other_time_hours: float = Field(..., description="Other time in hours (2 decimal places)")
    productive_pct: float = Field(..., description="Productive time percentage (2 decimal places)")
    non_productive_pct: float = Field(..., description="Non-productive time percentage (2 decimal places)")
    other_pct: float = Field(..., description="Other time percentage (2 decimal places)")
    staff_utilization_percent: float = Field(..., description="Staff utilization percentage (2 decimal places)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerAtaScoreGaugeResponse(BaseModel):
    """Response model for auditor manager ATA score gauge."""
    status: str = Field(..., description="Status of the request (success/error)")
    ata_score: float = Field(..., description="ATA audit score (2 decimal places)")
    trend: List[AuditScoreTrend] = Field(default=[], description="ATA score trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class AuditorManagerCycleTimeTrend(BaseModel):
    """Cycle time trend data point (Auditor Manager)."""
    period: str = Field(..., description="Time period (format varies by range)")
    avg_cycle_time_minutes: float = Field(..., description="Average cycle time in minutes")
    total_audits: int = Field(..., description="Total audits in the period")

class AuditorManagerAuditCycleTimeGaugeResponse(BaseModel):
    """Response model for auditor manager audit cycle time gauge."""
    status: str = Field(..., description="Status of the request (success/error)")
    audit_cycle_time: float = Field(..., description="Average audit cycle time in hours (2 decimal places)")
    audit_cycle_time_formatted: str = Field(..., description="Average audit cycle time formatted as 'X mins Y secs' or N/A")
    trend: List[AuditorManagerCycleTimeTrend] = Field(default=[], description="Audit cycle time trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class RebuttalCountTrend(BaseModel):
    """Rebuttal count trend data (Auditor Manager)."""
    rebuttals: Dict[str, int] = Field(default_factory=dict, description="Period -> rebuttal count")
    overturned: Dict[str, int] = Field(default_factory=dict, description="Period -> overturned count")
    upheld: Dict[str, int] = Field(default_factory=dict, description="Period -> upheld count")

class AuditorManagerRebuttalsResponse(BaseModel):
    """Response model for auditor manager rebuttals metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    rebuttals: str = Field(..., description="Total number of rebuttals")
    rebuttals_overturned: str = Field(..., description="Percentage of rebuttals overturned (2 decimal places)")
    rebuttals_count_trend: RebuttalCountTrend = Field(default_factory=RebuttalCountTrend, description="Rebuttals count trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerQualityOutcomesResponse(BaseModel):
    """Response model for auditor manager quality outcomes."""
    status: str = Field(..., description="Status of the request (success/error)")
    ata_score: float = Field(..., description="Average ATA audit score (2 decimal places)")
    ata_score_trend: List[AuditScoreTrend] = Field(default=[], description="ATA score trend over time")
    audit_cycle_time: float = Field(..., description="Average audit cycle time in minutes (2 decimal places)")
    cycle_time_trend: List[AuditorManagerCycleTimeTrend] = Field(default=[], description="Audit cycle time trend over time")
    rebuttal_count: str = Field(..., description="Total number of ATA rebuttals")
    rebuttals_overturned: str = Field(..., description="Percentage of rebuttals overturned")
    rebuttals_count_trend: Dict[str, Any] = Field(default_factory=dict, description="Rebuttals count trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

# =============================================================================
# Auditor Manager Drilldown Models (with auditor_ids instead of frontline_associate_ids)
# =============================================================================

class AuditorManagerCompletedAuditCountDrilldownRequest(BaseModel):
    """Paginated request model for Auditor Manager completed audit count drilldown API."""
    screen_id: str = Field(default="completed_audit_count", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "completed_audit_count",
                "user_id": "AM12345",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"],
                "sort_by": "audit_resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerAuditSamplePctDrilldownRecord(BaseModel):
    """Audit sample percentage summary record (Auditor Manager)."""
    date_range: str = Field(..., description="Date Range (e.g., '1/1/2026 — 1/7/2026')")
    open_audits: int = Field(..., description="Number of Open Audits")
    closed_audits: int = Field(..., description="Number of Closed Audits")
    pending_audits: int = Field(..., description="Number of Pending Audits")
    total_cases_resolved: int = Field(..., description="Total cases resolved by auditors")


class AuditorManagerAuditSamplePctDrilldownRequest(BaseModel):
    """Paginated request model for Auditor Manager audit sample percentage drilldown API."""
    screen_id: str = Field(default="audit_sample_pct", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "audit_sample_pct",
                "user_id": "AM12345",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"],
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerAuditSamplePctDrilldownResponse(BaseModel):
    """Paginated response model for Auditor Manager audit sample percentage drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditorManagerAuditSamplePctDrilldownRecord] = Field(..., description="List of audit sample percentage records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerAtaAuditScoreDrilldownRecord(BaseModel):
    """ATA Audit score record (Auditor Manager)."""
    pyid: str = Field(default="", description="Work Item")
    work_type: str = Field(default="", description="Work Type")
    audit_cycle_time: str = Field(default="", description="Audit Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    audit_resolved: str = Field(default="", description="Audit Resolved")
    auditor_domain_id: str = Field(default="", description="Auditor Name")
    platform: str = Field(default="", description="Platform")
    audit_score: str = Field(default="", description="Audit Score")
    targeted_audit_type: str = Field(default="N/A", description="Targeted Audit Type")
    inventory_type: str = Field(default="N/A", description="Inventory Type")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class AuditorManagerAtaAuditScoreDrilldownRequest(BaseModel):
    """Request model for Auditor Manager ATA audit score drilldown API."""
    screen_id: str = Field(default="ata_audit_score", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "ata_audit_score",
                "user_id": "AM12345",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"],
                "sort_by": "audit_resolved",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerAtaAuditScoreDrilldownResponse(BaseModel):
    """Paginated response model for Auditor Manager ATA audit score drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditorManagerAtaAuditScoreDrilldownRecord] = Field(..., description="List of ATA audit score records")
    completed_audit_work_items: int = Field(default=0, description="Total count of completed audit work items")
    target_audit_count: int = Field(default=0, description="Number of targeted audits")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerRebuttalDrilldownRequest(BaseModel):
    """Request model for Auditor Manager rebuttal drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "auditor_ids": ["AI06493", "AG20176"],
                "sort_by": "resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerWorkItemsDrilldownRequest(BaseModel):
    """Request model for Auditor Manager work items drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "auditor_ids": ["AI06493", "AG20176"],
                "sort_by": "resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerStaffUtilizationDrilldownRequest(BaseModel):
    """Request model for Auditor Manager staff utilization drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor IDs to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for synchronized caching across related APIs")
    view_type: str = Field("weekly", description="Aggregation level: daily, weekly, or monthly")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-04-01",
                "end_date": "2026-06-30",
                "view_type": "monthly",
                "lob": ["Commercial"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"],
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerAICoachResponse(BaseModel):
    """Response model for Auditor Manager AI Coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerFuseTimeDrilldownRequest(BaseModel):
    """Request model for Auditor Manager fuse time drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "auditor_ids": ["AI06493", "AG20176"],
                "sort_by": "date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }

class ATARebuttalRecord(BaseModel):
    """Individual ATA rebuttal drilldown record."""
    work_item_id: str = Field(..., description="Work Item ID")
    worktype_category: str = Field(..., description="Worktype Category")
    outcome_status: str = Field(..., description="Outcome Status")
    lob: Optional[str] = Field(None, description="LOB")
    resolved_date: Optional[str] = Field(None, description="Resolved Date")
    domain_id: Optional[str] = Field(None, description="Domain ID")
    associate_name: Optional[str] = Field(default="N/A", description="Associate Name")
    platform_source_system: Optional[str] = Field(None, description="Platform Source System")
    error_category: Optional[str] = Field(default="N/A", description="Error Category")
    error_type: Optional[str] = Field(default="N/A", description="Error Type")
    rebuttal_outcome: Optional[str] = Field(default="N/A", description="Rebuttal Outcome")
    inventory_type: Optional[str] = Field(default="N/A", description="Inventory Type")
    audit_month: Optional[str] = Field(default="N/A", description="Audit Month")
    audit_year: Optional[str] = Field(default="N/A", description="Audit Year")


class ATARebuttalDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for ATA rebuttal drilldown."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[ATARebuttalRecord] = Field(..., description="List of ATA rebuttal records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# ============================================================================
# FL Auditor Models
# ============================================================================

# FL Auditor Drilldown Models

class FLAuditorRebuttalRecord(BaseModel):
    """Individual rebuttal record for FL Auditor."""
    work_item_id: str = Field(default="N/A", description="Work Item ID")
    worktype_category: str = Field(default="N/A", description="Worktype Category")
    outcome_status: str = Field(default="N/A", description="Outcome Status")
    error_category: str = Field(default="N/A", description="Error Category")
    error_type: str = Field(default="N/A", description="Error Type")
    rebuttal_outcome: str = Field(default="N/A", description="Rebuttal Outcome")
    lob: str = Field(default="N/A", description="Line of Business")
    resolved_date: str = Field(default="N/A", description="Resolved Date")
    domain_id: str = Field(default="N/A", description="Domain ID")
    platform_source_system: str = Field(default="N/A", description="Platform Source System")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class FLAuditorRebuttalDrilldownRequest(BaseModel):
    """Request model for FL Auditor rebuttal drilldown."""
    screen_id: str = Field(default="rebuttal_count", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods for filtering")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "rebuttal_count",
                "user_id": "AF93939",
                "session_id": "abc123",
                "start_date": "2026-05-01",
                "end_date": "2026-06-30",
                "lob": ["Commercial", "Medicaid"],
                "audit_periods": [
                    {"month": "June", "year": "2026"},
                    {"month": "July", "year": "2026"}
                ],
                "sort_by": "resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }

class AuditorManagerAICoachRequest(BaseModel):
    """Request model for Auditor Manager AI coach API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    auditor_ids: Optional[List[str]] = Field(None, description="List of auditor IDs to filter")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AM12345",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"]
            }
        }


class FLAuditorRebuttalDrilldownResponse(BaseModel):
    """Response model for FL Auditor rebuttal drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FLAuditorRebuttalRecord] = Field(..., description="List of rebuttal records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[dict] = Field(None, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class FLAuditorAtaScoreRecord(BaseModel):
    """Individual ATA score record for FL Auditor."""
    pyid: str = Field(default="", description="PYID")
    work_type: str = Field(default="", description="Work Type")
    audit_cycle_time: str = Field(default="", description="Audit Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    audit_resolved: str = Field(default="", description="Audit Resolved Date")
    auditor_name: str = Field(default="", description="Auditor Name")
    platform: str = Field(default="", description="Platform")
    audit_score: str = Field(default="", description="Audit Score with %")
    targeted_audit_type: str = Field(default="N/A", description="Targeted Audit Type")
    inventory_type: str = Field(default="N/A", description="Inventory Type")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class FLAuditorAtaScoreDrilldownRequest(BaseModel):
    """Request model for FL Auditor ATA score drilldown."""
    screen_id: str = Field(default="ata_score", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods for filtering")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "ata_score",
                "user_id": "AF93939",
                "session_id": "abc123",
                "start_date": "2026-05-01",
                "end_date": "2026-06-30",
                "lob": ["Commercial", "Medicaid"],
                "audit_periods": [
                    {"month": "June", "year": "2026"},
                    {"month": "July", "year": "2026"}
                ],
                "sort_by": "audit_resolved",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class FLAuditorAtaScoreDrilldownResponse(BaseModel):
    """Response model for FL Auditor ATA score drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FLAuditorAtaScoreRecord] = Field(..., description="List of ATA score records")
    completed_audit_work_items: int = Field(..., description="Total completed audit work items")
    target_audit_count: int = Field(..., description="Count of targeted audits")
    message: str = Field(..., description="Response message")
    tooltips: Optional[dict] = Field(None, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorWorkItemRecord(BaseModel):
    """Individual work item record for FL Auditor."""
    pyid: str = Field(default="", description="PYID")
    work_type: str = Field(default="", description="Work Type")
    case_cycle_time: str = Field(default="", description="Case Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    resolved_date: str = Field(default="", description="Resolved Date")
    domain_id: str = Field(default="", description="Domain ID")
    associate_name: str = Field(default="", description="Associate Name")
    platform: str = Field(default="", description="Platform")
    inventory_type: str = Field(default="", description="Inventory Type")


class FLAuditorWorkItemsDrilldownRequest(BaseModel):
    """Request model for FL Auditor work items drilldown."""
    screen_id: str = Field(default="work_items", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "work_items",
                "user_id": "AI06493",
                "start_date": "2026-03-01",
                "end_date": "2026-03-31",
                "lob": ["Medicare","Commercial"],
                "page": 1,
                "page_size": 20
            }
        }


class FLAuditorWorkItemsDrilldownResponse(BaseModel):
    """Response model for FL Auditor work items drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FLAuditorWorkItemRecord] = Field(..., description="List of work item records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[dict] = Field(None, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# FL Auditor Quality Outcomes Models

class FLAuditorAtaScoreGaugeResponse(BaseModel):
    """Response model for FL Auditor ATA score gauge."""
    status: str = Field(..., description="Status of the request (success/error)")
    ata_score: str = Field(..., description="ATA audit score (2 decimal places or N/A)")
    trend: List[AuditScoreTrend] = Field(default=[], description="ATA score trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorCycleTimeTrend(BaseModel):
    """Cycle time trend data point for FL Auditor."""
    period: str = Field(..., description="Time period (format varies by range)")
    avg_cycle_time_minutes: float = Field(..., description="Average cycle time in minutes")
    total_audits: int = Field(..., description="Total audits in the period")


class FLAuditorAuditCycleTimeGaugeResponse(BaseModel):
    """Response model for FL Auditor audit cycle time gauge."""
    status: str = Field(..., description="Status of the request (success/error)")
    audit_cycle_time: str = Field(..., description="Average audit cycle time in minutes (2 decimal places or N/A)")
    trend: List[FLAuditorCycleTimeTrend] = Field(default=[], description="Audit cycle time trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class RebuttalTrend(BaseModel):
    """Trend data for rebuttals over time."""
    period: str = Field(..., description="Time period (e.g., '01/15', '2024-01', '2024-Q1')")
    rebuttals: int = Field(default=0, description="Total number of rebuttals in this period")
    overturned: int = Field(default=0, description="Number of rebuttals overturned in this period")
    upheld: int = Field(default=0, description="Number of rebuttals upheld in this period")


class FLAuditorRebuttalsResponse(BaseModel):
    """Response model for FL Auditor rebuttals metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    rebuttal_count: str = Field(..., description="Total number of rebuttals")
    rebuttals_overturned: str = Field(..., description="Percentage of rebuttals overturned (2 decimal places)")
    rebuttals_count_trend: Dict[str, Any] = Field(default_factory=dict, description="Rebuttals count trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# FL Auditor Time Utilization Models


class FLAuditorTimeUtilizationResponse(BaseModel):
    """Response model for FL Auditor time utilization metrics (Fuse time only)."""
    status: str = Field(..., description="Status of the request (success/error)")
    total_fuse_time_hours: str = Field(..., description="Total hours logged into FUSE system (2 decimal places or N/A)")
    ohi_productive_time: str = Field(..., description="OHI productive time in hours (2 decimal places or N/A)")
    total_non_productive_hours: str = Field(..., description="Total non-productive hours (2 decimal places or N/A)")
    other_time_hours: str = Field(..., description="Other time in hours (2 decimal places or N/A)")
    productive_pct: str = Field(..., description="Productive time percentage (2 decimal places or N/A)")
    non_productive_pct: str = Field(..., description="Non-productive time percentage (2 decimal places or N/A)")
    other_pct: str = Field(..., description="Other time percentage (2 decimal places or N/A)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



class FLAuditorFuseTimeDrilldownRequest(BaseModel):
    """Request model for FL Auditor fuse time drilldown."""
    screen_id: str = Field(default="fuse_time", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "fuse_time",
                "user_id": "AI06493",
                "start_date": "2026-03-01",
                "end_date": "2026-03-31",
                "lob": ["Medicare","Commercial"],
                "page": 1,
                "page_size": 20
            }
        }


class FLAuditorFuseTimeDrilldownResponse(BaseModel):
    """Response model for FL Auditor fuse time drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FuseTimeRecord] = Field(..., description="List of fuse time records")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



class FLAuditorLOBListResponse(BaseModel):
    """Response model for FL Auditor LOB list."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(default=[], description="List of Line of Business values")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorAICoachResponse(BaseModel):
    """Response model for FL Auditor AI Coach insights."""
    status: str = Field(..., description="Status of the request (success/error)")
    message_text: str = Field(..., description="AI Coach message text")
    performance_score: Optional[str] = Field(None, description="Performance score (e.g., '98.5%')")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorLoginLogoutSession(BaseModel):
    """Individual login/logout session for FL Auditor."""
    login_time: Optional[str] = Field(default="N/A", description="Login time (e.g., '8:15 AM ET')")
    logout_time: Optional[str] = Field(default="N/A", description="Logout time (e.g., '5:30 PM ET')")


class FLAuditorUserActivityResponse(BaseModel):
    """Response model for FL Auditor user activity (login/logout times and audit team rank)."""
    status: str = Field(..., description="Status of the request (success/error)")
    sessions: List[FLAuditorLoginLogoutSession] = Field(default_factory=list, description="List of all login/logout sessions from the most recent date")
    audit_team_rank: str = Field(..., description="Audit team rank position (e.g., '6' or 'N/A')")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining the metrics")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerLoginLogoutSession(BaseModel):
    """Individual login/logout session for Auditor Manager."""
    login_time: Optional[str] = Field(default="N/A", description="Login time (e.g., '8:15 AM ET')")
    logout_time: Optional[str] = Field(default="N/A", description="Logout time (e.g., '5:30 PM ET')")


class AuditorManagerUserActivityResponse(BaseModel):
    """Response model for Auditor Manager user activity (login/logout times and audit team rank)."""
    status: str = Field(..., description="Status of the request (success/error)")
    sessions: List[AuditorManagerLoginLogoutSession] = Field(default_factory=list, description="List of all login/logout sessions from the most recent date")
    audit_team_rank: str = Field(..., description="Audit team rank position (e.g., '6' or 'N/A')")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining the metrics")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerAICoachResponse(BaseModel):
    """Response model for Auditor Manager AI coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
from typing import Dict, Any, Optional, List, Union


class DataRequest(BaseModel):
    """Generic data request model."""
    data: Dict[str, Any]


class SnowflakeQueryRequest(BaseModel):
    """Request model for generic Snowflake query."""
    query: str
    limit: Optional[int] = 10


class SnowflakeQueryResponse(BaseModel):
    """Response model for generic Snowflake query."""
    status: str
    message: str
    record_count: Optional[int] = None
    records: Optional[List[Dict[str, Any]]] = None
    service: str = "idiscovery-cob-dashboard-service"


class UserTimeRequest(BaseModel):
    """Request model for user time metrics API."""
    user_id: str = Field(..., description="User ID to query", examples=["1694MU"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "1694MU",
                "start_date": "2025-04-03",
                "end_date": "2025-04-05"
            }
        }


class UserTimeResponse(BaseModel):
    """Response model for user time metrics API."""
    status: str = Field(..., description="Status of the request (success/error)")
    fuse_time: Optional[str] = Field(None, description="Total fuse time formatted as 'X hrs Y mins'")
    fuse_non_productive_time: Optional[str] = Field(None, description="Fuse non-productive time formatted as 'X hrs Y mins'")
    ohi_non_productive_time: Optional[str] = Field(None, description="OHI non-productive time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class UserMetricsRequest(BaseModel):
    """Request model for user metrics API (work items + audit score)."""
    user_id: str = Field(..., description="User ID to query", examples=["AA99826"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, audit score uses audit-side period filtering"
    )
    session_id: Optional[str] = Field(None, description="Session ID for caching support")
    warm_ai_coach_context: Optional[bool] = Field(default=True, description="Internal flag controlling Frontline AI Coach dependency warmup")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "lob": ["Commercial"],
                "audit_periods": [{"month": "June", "year": "2026"}],
                "session_id": "session_1775821614_abc123def"
            }
        }


class UserMetricsResponse(BaseModel):
    """Response model for user metrics API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: Optional[str] = Field(None, description="User ID")
    work_items_completed: Optional[str] = Field(None, description="Number of work items completed")
    audit_score_percentage: Optional[str] = Field(None, description="Average audit score percentage")
    audit_score_bubble: Optional[str] = Field(None, description="Audit score bubble indicator (Excellent/Good/Poor)")
    cycle_time_avg: Optional[str] = Field(None, description="Average cycle time")
    cycle_time_bubble: Optional[str] = Field(None, description="Cycle time bubble indicator (N/A until data available)")
    audit_error_count: Optional[str] = Field(None, description="Audit error count")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



class UserActivityRequest(BaseModel):
    """Request model for user activity API (login/logout + skilled sources)."""
    user_id: str = Field(..., description="User ID to query")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AL48579",
                "start_date": "2025-01-01",
                "end_date": "2025-01-31",
                "lob": ["Commercial"]
            }
        }


class SessionRecord(BaseModel):
    """Individual login/logout session within a day."""
    login: Optional[str] = Field(None, description="Login time in HH:MM AM/PM ET format")
    logout: Optional[str] = Field(None, description="Logout time in HH:MM AM/PM ET format")


class LoginLogoutRecord(BaseModel):
    """Daily login/logout record with multiple sessions."""
    date: str = Field(default="", description="Login date")
    sessions: List[SessionRecord] = Field(default=[], description="List of login/logout sessions for the day")


class UserActivityData(BaseModel):
    """Data section for user activity response."""
    user_id: str
    login_logout_records: List[LoginLogoutRecord]
    skilled_sources: List[str]
    team_rank: str = Field(default="NA", description="Team Rank")
    department_rank: str = Field(default="NA", description="Department Rank")


class UserActivityResponse(BaseModel):
    """Response model for user activity API."""
    meta: Dict[str, str]
    data: Optional[UserActivityData] = None
    errors: Optional[List[Dict[str, Any]]] = None
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")

class AuditScoreGaugeRequest(BaseModel):
    """Request model for audit score gauge API."""
    user_id: str = Field(..., description="User ID to query", examples=["AA99826"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2025-04-30",
                "lob": ["Commercial"],
                "audit_periods": [{"month": "June", "year": "2026"}]
            }
        }

class AuditScoreTrend(BaseModel):
    """Audit score data point."""
    period: str = Field(..., description="Time period (format varies by range)")
    avg_audit_score: float = Field(..., description="Average audit score for the period")
    total_cases: int = Field(..., description="Total cases in the period")


class AuditScoreGaugeResponse(BaseModel):
    """Response model for audit score gauge API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: Optional[str] = Field(None, description="User ID")
    audit_score: float = Field(..., description="Average audit score with 2 decimal places")
    score_trend: List[AuditScoreTrend] = Field(default=[], description="Monthly audit score trend")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class DateRange(BaseModel):
    """Date range model for paginated requests."""
    from_date: str = Field(..., alias="from", description="Start date in YYYY-MM-DD format")
    to_date: str = Field(..., alias="to", description="End date in YYYY-MM-DD format")

    class Config:
        populate_by_name = True


class PaginatedQuery(BaseModel):
    """Query parameters for paginated requests."""
    user_id: str = Field(..., description="User ID to query")
    date_range: DateRange = Field(..., description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides date_range for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")


class DirectorPaginatedQuery(BaseModel):
    """Query parameters for director-level paginated requests with manager-associate relationships."""
    user_id: str = Field(..., description="User ID to query")
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter")


class PageRequest(BaseModel):
    """Pagination request parameters."""
    page_limit: int = Field(default=50, ge=1, le=500, description="Number of records per page")
    page: Optional[int] = Field(default=1, ge=1, description="Page number (1-indexed)")
    cursor: Optional[str] = Field(default=None, description="Cursor for cursor-based pagination")


class PageResponse(BaseModel):
    """Pagination response metadata."""
    page_limit: int = Field(..., description="Number of records per page")
    page: int = Field(..., description="Current page number")
    total_records: int = Field(..., description="Total number of records")
    total_pages: int = Field(..., description="Total number of pages")
    cursor: Optional[str] = Field(default=None, description="Cursor for next page")
    has_next: bool = Field(..., description="Whether there are more pages")
    has_previous: bool = Field(..., description="Whether there are previous pages")



class WorkItemsDrilldownRequest(BaseModel):
    """Request model for work items drilldown API."""
    user_id: str = Field(..., description="User ID to query", examples=["AF05867"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AF05867",
                "start_date": "2025-04-03",
                "end_date": "2025-06-05",
                "lob": ["Commercial"]
            }
        }


class WorkItemsDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for work items drilldown API."""
    screen_id: str = Field(default="work_items", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")
    session_id: Optional[str] = Field(None, description="Session ID for caching support")

    class Config:
        json_schema_extra = {
            "example": {
                "page": {
                    "page": 2,
                    "page_limit": 5
                },
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-06-05"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AF05867"
                },
                "screen_id": "work_items"
            }
        }



class WorkItemRecord(BaseModel):
    pyid: str = Field(default="", description="PYID")
    work_type: str = Field(default="", description="Work Type")
    case_cycle_time: str = Field(default="", description="Case Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    resolved_date: str = Field(default="", description="Resolved Date")
    domain_id: str = Field(default="", description="Associate Name")
    platform: str = Field(default="", description="Platform")
    inventory_type: str = Field(default="", description="Inventory Type")


class WorkItemsDrilldownResponse(BaseModel):
    """Response model for work items drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    record_count: int = Field(..., description="Number of records returned")
    records: List[WorkItemRecord] = Field(..., description="List of work items")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class WorkItemsDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for work items drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[WorkItemRecord] = Field(..., description="List of work items")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditScoreDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit score drilldown API."""
    screen_id: str = Field(default="audit_score", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "page": {
                    "page": 2,
                    "page_limit": 5
                },
                "query": {
                    "date_range": {
                        "from": "2026-02-01",
                        "to": "2026-02-07"
                    },
                    "lob": ["Medicaid"],
                    "user_id": "AH40730",
                    "audit_periods": [{"year": "2026", "month": "June"}]
                },
                "screen_id": "audit_score"
            }
        }


class AuditScoreRecord(BaseModel):
    pyid: str = Field(default="", description="PYID")
    work_type: str = Field(default="", description="Work Type")
    audit_cycle_time: str = Field(default="", description="Audit Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    audit_resolved: str = Field(default="", description="Audit Resolved Date")
    platform: str = Field(default="", description="Platform")
    audit_score: str = Field(default="", description="Audit Score with %")
    targeted_audit_type: str = Field(default="N/A", description="Targeted Audit Type")
    rebuttal_status: str = Field(default="N/A", description="Rebuttal Status")
    inventory_type: str = Field(default="N/A", description="Inventory Type")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class AuditScoreDrilldownRequest(BaseModel):
    """Request model for audit score drilldown API."""
    user_id: str = Field(..., description="User ID to query", examples=["AA99826"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    page: int = Field(..., ge=1, description="Page number (starts from 1, required)")
    page_size: int = Field(..., ge=1, le=100, description="Number of records per page (required)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "lob": ["Commercial"],
                "page": 1,
                "page_size": 20
            }
        }


class AuditScoreDrilldownResponse(BaseModel):
    """Response model for audit score drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Records per page")
    total_records: int = Field(..., description="Total number of records")
    total_pages: int = Field(..., description="Total number of pages")
    records: List[AuditScoreRecord] = Field(..., description="List of audit scores")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditScoreDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit score drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditScoreRecord] = Field(..., description="List of audit scores")
    completed_audit_work_items: int = Field(default=0, description="Total count of completed audit work items")
    target_audit_count: int = Field(default=0, description="Number of targeted audits")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ProductionPercentageGaugeRequest(BaseModel):
    """Request model for production percentage gauge API."""
    user_id: str = Field(..., description="User ID to query", examples=["AL48579"])
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for caching support")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AL48579",
                "start_date": "2025-01-24",
                "end_date": "2025-02-24",
                "lob": ["Commercial"],
                "session_id": "session_1775821614_abc123def"
            }
        }

class ProductionPercentageTrend(BaseModel):
    """Production percentage trend data for a specific period."""
    period: str = Field(..., description="Time period (format varies by range)")
    production_percentage: float = Field(..., description="Production percentage for the period")
    total_tasks: int = Field(..., description="Total tasks completed in the period")


class ProductionPercentageGaugeResponse(BaseModel):
    """Response model for production percentage gauge API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    production_percentage_achieved: float = Field(..., description="Production percentage achieved with 2 decimal places")
    score_trend: List[ProductionPercentageTrend] = Field(..., description="Monthly production percentage trend data")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class UserRoleRequest(BaseModel):
    """Request model for user role API."""
    user_id: str = Field(..., description="User ID to query", examples=["1694MU"])

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "1694MU"
            }
        }


class UserRoleResponse(BaseModel):
    """Response model for user role API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    fuse_profile: Optional[str] = Field(None, description="Fuse Profile (PYACCESSGROUP)")
    user_role: Optional[str] = Field(None, description="User Role")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FuseTimeDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for fuse time drilldown API."""
    screen_id: str = Field(default="fuse_time", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "page": {
                    "page": 1,
                    "page_limit": 50
                },
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-04-05"
                    },
                    "user_id": "1694MU"
                },
                "screen_id": "fuse_time"
            }
        }


class FuseTimeRecord(BaseModel):
    user_id: str = Field(default="", description="User ID")
    date: str = Field(default="", description="Login Date (MM/DD/YYYY)")
    log_in: Optional[str] = Field(None, description="First Login Time")
    log_out: Optional[str] = Field(None, description="Last Logout Time")
    total_fuse_time: str = Field(default="", description="Total System Time")
    productive_time: str = Field(default="", description="Productive Time")
    non_productive_time: str = Field(default="", description="Fuse Non-Productive Time")
    other_time: str = Field(default="", description="Other Time (calculated as Total - (Productive + Non-Productive))")


class FuseTimeDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for fuse time drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FuseTimeRecord] = Field(..., description="List of fuse time records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditScoreDrilldownDownloadRequest(BaseModel):
    """Request model for audit score drilldown Excel download (no pagination)."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2026-02-01",
                        "to": "2026-02-07"
                    },
                    "lob": ["Medicaid"],
                    "user_id": "AH40730",
                    "audit_periods": [{"year": "2026", "month": "June"}]
                }
            }
        }


class ProductionPctDrilldownDownloadRequest(BaseModel):
    """Request model for production percentage drilldown Excel download (no pagination)."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-02-01",
                        "to": "2026-02-07"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AL48579"
                }
            }
        }


class WorkItemsDrilldownDownloadRequest(BaseModel):
    """Request model for work items drilldown Excel download (no pagination)."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-06-05"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AF05867"
                }
            }
        }


class FuseTimeDrilldownDownloadRequest(BaseModel):
    """Request model for fuse time drilldown Excel download (no pagination)."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-04-05"
                    },
                    "user_id": "1694MU"
                }
            }
        }


# Director-specific drilldown request models
class AuditScoreDirectorDrilldownRequest(BaseModel):
    """Request model for audit score director drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "page": 1,
                "page_size": 20
            }
        }


class FuseTimeDirectorDrilldownRequest(BaseModel):
    """Request model for fuse time director drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "sort_by": "date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class FuseTimeManagerDrilldownRequest(BaseModel):
    """Request model for fuse time manager drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs (not used for filtering in Manager APIs)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class WorkItemsDirectorDrilldownRequest(BaseModel):
    """Request model for work items director drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "sort_by": "resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class WorkItemsManagerDrilldownRequest(BaseModel):
    """Request model for work items manager drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class ManagerAssociateUtilizationRequest(BaseModel):
    """Request model for manager associate utilization API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs to filter associates (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods (month/year pairs) for filtering")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [{"month": "January", "year": 2026}, {"month": "February", "year": 2026}]
            }
        }

class ManagerAssociateUtilizationBreakdownRequest(ManagerBaseRequest):
    """Request model for manager associate utilization breakdown API."""
    view_type: str = Field("weekly", description="Aggregation level: daily, weekly, or monthly")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-07-01",
                "end_date": "2026-07-24",
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "view_type": "weekly"
            }
        }


class ManagerAssociateUtilizationBreakdownRow(BaseModel):
    """Flat row for manager associate utilization breakdown."""
    period_start: str = Field(..., description="Bucket start date in MM/DD/YYYY format")
    period_end: str = Field(..., description="Bucket end date in MM/DD/YYYY format")
    period_label: str = Field(..., description="Display label for the selected bucket")
    manager_id: str = Field(..., description="Manager user ID")
    manager_name: str = Field(..., description="Manager display name")
    associate_id: str = Field(..., description="Associate user ID or TEAM_TOTAL")
    associate_name: str = Field(..., description="Associate display name or Team Total")
    is_team_total: bool = Field(default=False, description="Whether this row is the team total")
    staff_utilization_pct: float = Field(default=0.0, description="Productive hours divided by available hours")
    available_hours: float = Field(default=0.0, description="Available hours")
    productive_hours: float = Field(default=0.0, description="Productive hours")
    total_system_hours: float = Field(default=0.0, description="Total system hours")
    non_productive_hours: float = Field(default=0.0, description="Non-productive hours")
    other_hours: float = Field(default=0.0, description="Other hours")
    productive_pct_of_total_system: float = Field(default=0.0, description="Productive hours as a percent of total system hours")


class ManagerAssociateUtilizationBreakdownResponse(BaseModel):
    """Response model for manager associate utilization breakdown API."""
    status: str = Field(..., description="Status of the request")
    view_type: str = Field(..., description="Aggregation level returned by the API")
    rows: List[ManagerAssociateUtilizationBreakdownRow] = Field(default=[], description="Breakdown rows")
    total_count: int = Field(default=0, description="Total number of rows returned")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    
class ManagerQualityOutcomesRequest(BaseModel):
    """Request model for manager quality outcomes API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side rebuttal filtering"
    )
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs to filter associates (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for caching (auto-generated if not provided)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "audit_periods": [{"month": "June", "year": "2026"}],
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"]
            }
        }


class ManagerAuditErrorDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit error drilldown API (Manager version)."""
    screen_id: str = Field(default="audit_error_manager", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs to filter associates (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit error drilldown filtering"
)
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "audit_error_manager",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class ManagerAuditErrorDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit error drilldown API (Manager version)."""
    status: str = Field(..., description="Response status")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination information")
    records: List["AuditErrorRecord"] = Field(..., description="List of audit error records")
    message: str = Field(..., description="Response message")
    tooltips: dict = Field(default_factory=dict, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerBaseDownloadRequest(BaseModel):
    """Base request model for Manager download APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [{"month": "January", "year": 2026}, {"month": "February", "year": 2026}]
            }
        }


class ManagerAICoachRequest(BaseModel):
    """Request model for manager AI coach API."""
    user_id: Optional[str] = Field(None, description="User ID to query")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for Redis cache retrieval")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "user_id": "AD23980",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["AD23980"]
            }
        }


class ManagerAICoachResponse(BaseModel):
    """Response model for manager AI coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AICoachRequest(BaseModel):
    """Request model for AI coach API."""
    user_id: str = Field(..., description="User ID to query")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for Redis cache retrieval")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "lob": ["Commercial"]
            }
        }


class DirectorAICoachResponse(BaseModel):
    """Response model for AI coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class DirectorAICoachRequest(BaseModel):
    """Request model for AI coach API."""
    user_id: str = Field(..., description="User ID to query")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    director_ids: Optional[List[str]] = Field(None, alias="director_id", description="List of the User Id's of Director")
    manager_ids: Optional[List[str]] = Field(None, alias="manager_id", description="List of the selected Manager's ID")
    frontline_associate_ids: Optional[List[str]] = Field(None, alias="associates_id", description="List of the selected Associates's ID")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    session_id: Optional[str] = Field(None, description="Session ID for Redis cache retrieval")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "director_ids": ["AD81285"],
                "manager_ids": ["LYKINDN"],
                "frontline_associate_ids": ["AH45556"],
                "lob": ["Commercial"]
            }
        }




# NOTE: Simple AICoachResponse (commented out - duplicate of enhanced version at line 897)
# Kept for reference in case basic version is needed later
class AICoachResponse(BaseModel):
    """Response model for AI coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Performance IQ Director Models
# =============================================================================

class DirectorBaseRequest(BaseModel):
    """Base request model for director-level APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for synchronized caching across all Director APIs")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"]
            }
        }


class DirectorHeaderKPIsRequest(DirectorBaseRequest):
    """Request model for director header KPIs."""
    pass


class ManagerListRequestForDirector(BaseModel):
    """Request model for managers list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    search: Optional[str] = Field(None, description="Search term to filter managers")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    directors: List[str] = Field(default=[], description="List of directors ID's")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "search": None,
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "directors": ["SANTICH"]
            }
        }

class ManagerListRequest(BaseModel):
    """Request model for managers list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    search: Optional[str] = Field(None, description="Search term to filter managers")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "search": None,
                "start_date": "2025-01-01",
                "end_date": "2025-12-31"
            }
        }


class ManagerItem(BaseModel):
    """Individual manager item."""
    manager_id: str = Field(..., description="Manager ID")
    manager_name: str = Field(..., description="Manager name")


class ManagerListResponse(BaseModel):
    """Response model for managers list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    managers: List[ManagerItem] = Field(default=[], description="List of managers")
    total_count: int = Field(..., description="Total number of managers")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class DirectorListRequest(BaseModel):
    """Request model for directors list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    search: Optional[str] = Field(None, description="Search term to filter directors")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "search": None,
                "start_date": "2026-03-01",
                "end_date": "2026-03-31"
            }
        }


class DirectorItem(BaseModel):
    """Individual director item."""
    director_id: str = Field(..., description="Director ID")
    director_name: str = Field(..., description="Director name")


class DirectorListResponse(BaseModel):
    """Response model for directors list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    directors: List[DirectorItem] = Field(default=[], description="List of directors")
    total_count: int = Field(..., description="Total number of directors")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AssociateListRequest(BaseModel):
    """Request model for associates list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: list[Optional[str]] = Field(None, description="Filter by manager id")
    search: Optional[str] = Field(None, description="Search term to filter associates")
    limit: int = Field(default=10000, ge=1, le=10001, description="Maximum number of results")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "manager_ids": ["AD23980"],
                "search": None,
                "limit": 50
            }
        }


class AssociateItem(BaseModel):
    """Individual associate item."""
    associate_id: str = Field(..., description="Associate ID")
    associate_name: Optional[str] = Field(None, description="Associate name")
    manager_name: Optional[str] = Field(None, description="Manager name")
    experience_level: Optional[str] = Field(None, description="Experience level")


class AssociateListResponse(BaseModel):
    """Response model for associates list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    associates: List[AssociateItem] = Field(default=[], description="List of associates")
    total_count: int = Field(..., description="Total number of associates")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class BacklogByStatusItem(BaseModel):
    """Individual backlog status item."""
    status: str = Field(..., description="Work status")
    count: int = Field(..., description="Count of items")


class DemandInventoryResponse(BaseModel):
    """Response model for demand inventory metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    backlog_volume: int = Field(..., description="Total backlog volume")
    backlog_by_status: List[BacklogByStatusItem] = Field(default=[], description="Backlog breakdown by status")
    escalation_count: int = Field(..., description="Total escalation count")
    escalation_by_priority: List[Dict[str, Any]] = Field(default=[], description="Escalation breakdown by priority")
    pended_items_count: int = Field(..., description="Pended items count")
    watchlist_count: str = Field(default="N/A", description="Watchlist count (TBD)")
    work_items_completed: int = Field(..., description="Work items completed")
    non_value_add_pct: float = Field(..., description="Non-value add percentage")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AssignmentTypeItem(BaseModel):
    """Assignment type breakdown item."""
    assignment_type: str = Field(..., description="Assignment type (GNW Assigned or Manually Assigned)")
    percentage: float = Field(..., description="Percentage of total assignments for this type")
    reassigned_percentage: float = Field(..., description="Reassigned percentage for this assignment type")


class TaktTimeItem(BaseModel):
    """Takt time by SLA bucket item."""
    cob_sla_bucket: str = Field(..., description="COB SLA bucket (e.g., '4 hours', '2 days', '10 days', '30 days')")
    backlog: int = Field(..., description="Backlog count for this SLA bucket")
    available_hours: float = Field(..., description="Available hours for this SLA bucket")
    takt_time_hours: float = Field(..., description="Takt time in hours (Available Hours / Backlog)")
    takt_time_minutes: float = Field(..., description="Takt time in minutes")


class OperationalFlowResponse(BaseModel):
    """Response model for operational flow metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    lead_time_avg_days: float = Field(..., description="Average lead time in days")
    cycle_takt_gap: str = Field(default="N/A", description="Cycle-Takt gap (coming 2/20)")
    assignment_type_breakdown: List[AssignmentTypeItem] = Field(default=[], description="Assignment type breakdown")
    reassign_pct: float = Field(..., description="Reassignment percentage")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class QualityOutcomesResponse(BaseModel):
    """Response model for quality outcomes metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    audit_sample_pct: str = Field(default="N/A", description="Audit sample percentage (TBD)")
    audit_sample_count: str = Field(default="N/A", description="Audit sample count as fraction (e.g., '1.3K of 13K')")
    audit_cycle_time_avg: str = Field(default="N/A", description="Audit cycle time average (coming 2/20)")
    completed_audit_count: str = Field(default="N/A", description="Completed audit count")
    audit_error_count: str = Field(default="N/A", description="Average Error Count")
    rebuttal_count: str = Field(default="N/A", description="Rebuttal count")
    rebuttal_overturn_pct: str = Field(default="N/A", description="Rebuttal overturn percentage (coming 2/20)")
    rework_pct: str = Field(default="N/A", description="Rework percentage (TBD)")
    fuse_time: int = Field(default=0, description="Total FUSE time in hours")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    audit_cycle_time_avg_status: str = Field(default="N/A", description="Status for Audit Cycle Time Avg")
    rework_pct_status: str = Field(default="N/A", description="Status for Rework Percentage")

class ManagerQualityOutcomesSimpleResponse(BaseModel):
    """Response model for manager quality outcomes metrics (simplified)."""
    status: str = Field(..., description="Status of the request (success/error)")
    completed_audit_count: int = Field(..., description="Completed audit count")
    audit_error_count: str = Field(default="0", description="Average Error Count")
    rebuttal_count: int = Field(..., description="Rebuttal count")
    rebuttal_overturn_pct: str = Field(default="N/A", description="Rebuttal overturn percentage")
    rework_pct: str = Field(default="N/A", description="Rework percentage (TBD)")
    fuse_time: str = Field(default="N/A", description="Total FUSE time in HH.MM format")
    watchlist_count: int = Field(default=0, description="Watchlist count")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    session_id: Optional[str] = Field(default=None, description="Session identifier for cache reuse")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class CacheMetadata(BaseModel):
    """Metadata about cache status for session-based caching."""
    session_id: Optional[str] = Field(default=None, description="Session identifier")
    cache_hit: bool = Field(default=False, description="Whether data was retrieved from cache")
    cached_at: Optional[str] = Field(default=None, description="Timestamp when data was cached (ISO format)")
    expires_at: Optional[str] = Field(default=None, description="Timestamp when cache expires (ISO format)")
    apis_cached: Optional[List[str]] = Field(default=None, description="List of APIs included in this cache session")
    
    @field_validator('apis_cached', mode='before')
    @classmethod
    def convert_apis_cached(cls, v):
        """Convert legacy integer format to list."""
        if isinstance(v, int):
            # Legacy format - convert count to list with placeholder
            return [f"{v} APIs"] if v > 0 else []
        return v

class HeaderKPIsResponse(BaseModel):
    """Response model for director header KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    work_items_completed: int = Field(..., description="Work items completed")
    production_pct_achieved: float = Field(..., description="Production percentage achieved")
    audit_score_pct: float = Field(..., description="Audit score percentage")
    cycle_time_avg: str = Field(default="N/A", description="Cycle time average (coming 2/20)")
    takt_time: str = Field(default="N/A", description="Takt time")
    volume_forecast_accuracy: str = Field(default="N/A", description="Volume forecast accuracy (TBD)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    production_pct_achieved_status: str = Field(default="N/A", description="Status for Production percentage achieved")
    audit_score_pct_status: str = Field(default="N/A", description="Status for Audit score percentage")
    cycle_time_avg_status: str = Field(default="N/A", description="Status for Cycle time average")


class ExperienceLevelItem(BaseModel):
    """Experience level distribution item."""
    level: str = Field(..., description="Experience level")
    count: int = Field(..., description="Count of associates")
    percentage: float = Field(..., description="Percentage of total")


class CapacityInsightItem(BaseModel):
    """Individual capacity insight item for bar chart."""
    date_range: str = Field(..., description="Date range (e.g., '1/1/26-1/5/26')")
    required_fte: int = Field(..., description="Required FTE")
    available_fte: int = Field(..., description="Available FTE")


class AssociateUtilizationResponse(BaseModel):
    """Response model for associate utilization metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    staff_utilization_pct: str = Field(default="N/A", description="Staff utilization percentage (Workday TBD)")
    total_fuse_time_hours: float = Field(..., description="Total available hours (Total System Time - Non-Productive Time)")
    total_non_productive_hours: float = Field(..., description="Total non-productive time in hours")
    ohi_productive_time: float = Field(default=0.0, description="OHI productive time in hours from PRODUCTIVETIME column")
    other_time_hours: float = Field(default=0.0, description="Other time in hours (calculated as Total - (Productive + Non-Productive))")
    productive_pct: float = Field(default=0.0, description="Productive time percentage")
    non_productive_pct: float = Field(default=0.0, description="Non-productive time percentage")
    other_pct: float = Field(default=0.0, description="Other time percentage")
    experience_level_distribution: List[ExperienceLevelItem] = Field(default=[], description="Experience level distribution")
    utilization_trend: List[AuditScoreTrend] = Field(default=[], description="Utilization trend over time (reusing AuditScoreTrend structure)")
    production_trend: List[ProductionPercentageTrend] = Field(default=[], description="Production percentage trend over time")
    capacity_insights: Dict[str, Dict[str, int]] = Field(default={}, description="Capacity insights with date range as key and required_fte/available_fte as values")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class LOBRequest(BaseModel):
    """Request model for LOB list API."""
    user_id: str = Field(..., description="User ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    director_id: Optional[List[str]] = Field(None, description="User Id of Director")
    manager_ids: Optional[List[str]] = Field(None, description="List of the selected Manager's ID")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of the selected Associates's ID")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2025-01-01",
                "end_date": "2025-12-31",
                "director_ids": ["AD81285"],
                "manager_ids": ["LYKINDN"],
                "associates_id": ["AH45556"]
            }
        }


class LOBResponse(BaseModel):
    """Response model for LOB list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(..., description="List of available LOBs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class DirectorLOBRequest(BaseModel):
    """Request model for Director LOB list API with manager-associate filtering."""
    user_id: str = Field(..., description="User ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"]
            }
        }


class DirectorLOBResponse(BaseModel):
    """Response model for Director LOB list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(..., description="List of available LOBs filtered by manager-associate relationships")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerLOBRequest(BaseModel):
    """Request model for Manager LOB list API with associate filtering."""
    user_id: str = Field(..., description="User ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs (not used for filtering in Manager APIs)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AA99826",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "frontline_associate_ids": ["AF18006"],
                "manager_ids": ["AD59226"],
            }
        }


class ManagerLOBResponse(BaseModel):
    """Response model for Manager LOB list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(..., description="List of available LOBs for manager's team")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class SLAHealthResponse(BaseModel):
    """Response model for SLA health metrics (placeholder)."""
    status: str = Field(..., description="Status of the request (success/error)")
    cob_sla_pct: str = Field(default="N/A", description="COB SLA percentage (awaiting SLA definition)")
    elv_sla_pct: str = Field(default="N/A", description="ELV SLA percentage (awaiting SLA definition)")
    completed_elv_sla: str = Field(default="N/A", description="ELV SLA Completed (awaiting SLA definition)")
    completed_cob_sla: str = Field(default="N/A", description="COB SLA Completed (awaiting SLA definition)")
    sla_risk_pct: str = Field(default="N/A", description="SLA risk percentage (awaiting SLA definition)")
    out_of_sla_pct: str = Field(default="N/A", description="Out of SLA percentage (awaiting SLA definition)")
    counts_by_sla: Dict[str, int] = Field(default_factory=dict, description="Counts by SLA brackets (bucket name -> count)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class EscalationCountQuery(BaseModel):
    """Query parameters for escalation count drilldown requests."""
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    priority: Optional[List[str]] = Field(None, description="List of priority values (Instant, Immediate, Urgent)")


class EscalationCountDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for escalation count drilldown API."""
    screen_id: str = Field(default="escalation_count", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="List of frontline associate IDs to filter (default: all)")
    priority: Optional[List[str]] = Field(None, description="List of priority values (Instant, Immediate, Urgent)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(default=1, description="Page number (starts from 1)")
    page_size: int = Field(default=20, description="Records per page (max: 100)")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "escalation_count",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "priority": ["Instant", "Immediate"],
                "page": 1,
                "page_size": 20
            }
        }


class EscalationCountRecord(BaseModel):
    """Individual escalation count record."""
    work_item_id: str = Field(..., description="Work Item ID (PYID)")
    workitem_type: str = Field(..., description="Work Item Type")
    priority: str = Field(..., description="Priority Level")
    status: str = Field(..., description="Work Item Status")
    lob: Optional[str] = Field(None, description="Line of Business")
    platform: Optional[str] = Field(None, description="Platform")
    cob_sla: Optional[str] = Field(None, description="COB SLA")
    elv_due_date: Optional[str] = Field(None, description="ELV Due Date (MM/DD/YYYY)")


class EscalationCountDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for escalation count drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[EscalationCountRecord] = Field(..., description="List of escalation records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class PendedItemsQuery(BaseModel):
    """Query parameters for pended items drilldown requests."""
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    status: Optional[List[str]] = Field(None, description="List of status values (e.g., Pend, Pending)")


class PendedItemsDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for pended items drilldown API."""
    screen_id: str = Field(default="pended_items", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    status: Optional[List[str]] = Field(None, description="List of status values (e.g., ['Pend', 'Pending'])")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "pended_items",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "status": ["Pend", "Pending"],
                "page": 1,
                "page_size": 20
            }
        }


class PendedItemsRecord(BaseModel):
    """Individual pended items record."""
    work_item_id: str = Field(..., description="Work Item ID (PYID)")
    worktype_category: str = Field(..., description="Work Type Category")
    status: str = Field(..., description="Work Item Status")
    lob: Optional[str] = Field(None, description="Line of Business")
    days_pended: str = Field(..., description="Number of days pended")
    pend_date: Optional[str] = Field(None, description="Pend Date (MM/DD/YYYY)")
    due_date: Optional[str] = Field(None, description="Due Date (MM/DD/YYYY)")
    resolved_date: Optional[str] = Field(None, description="Resolved Date (MM/DD/YYYY)")
    associate_name: Optional[str] = Field(None, description="Associate Name")


class PendedItemsDrilldownResponse(BaseModel):
    """Response model for pended items drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Records per page")
    total_records: int = Field(..., description="Total number of records")
    total_pages: int = Field(..., description="Total number of pages")
    records: List[PendedItemsRecord] = Field(..., description="List of pended items records")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class PendedItemsDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for pended items drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[PendedItemsRecord] = Field(..., description="List of pended items records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ProductionPctAchievedQuery(BaseModel):
    """Query parameters for production percentage achieved drilldown requests."""
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    associate: Optional[str] = Field(None, description="Associate ID to filter by")


class ProductionPctAchievedRecord(BaseModel):
    """Individual production percentage achieved record."""
    work_item_id: str = Field(..., description="Work Item ID (PYID)")
    worktype: str = Field(..., description="Work Type")
    standard_time: str = Field(..., description="Standard Time in minutes")
    case_cycle_time: str = Field(..., description="Case Cycle Time")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: Optional[str] = Field(None, description="Line of Business")
    resolved_date: Optional[str] = Field(None, description="Resolved Date (MM/DD/YYYY)")
    associate: Optional[str] = Field(None, description="Associate Full Name")
    activity_code: str = Field(default="N/A", description="Activity Code")
    platform: str = Field(default="N/A", description="Platform")

class ProductionPctAchievedDrilldownPaginatedRequest(BaseModel):
    """Request model for production percentage achieved drilldown API."""
    screen_id: str = Field(default="production_pct_achieved", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "production_pct_achieved",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "page": 1,
                "page_size": 20
            }
        }


class FrontlineProductionPctDrilldownRequest(BaseModel):
    """Simple request model for frontline production percentage drilldown."""
    screen_id: str = Field(default="production_pct_achieved", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")
    session_id: Optional[str] = Field(None, description="Session ID for caching support")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "production_pct_achieved",
                "query": {
                    "user_id": "AA99826",
                    "date_range": {
                        "from": "2025-02-01",
                        "to": "2026-02-07"
                    },
                    "lob": ["Commercial"]
                },
                "page": {
                    "page": 1,
                    "page_limit": 20
                }
            }
        }


class ProductionPctAchievedDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for production percentage achieved drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[ProductionPctAchievedRecord] = Field(..., description="List of production records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    cache_metadata: Optional[CacheMetadata] = Field(default=None, description="Cache status metadata")


class RebuttalQuery(BaseModel):
    """Query parameters for rebuttal drilldown requests."""
    date_range: Optional[DateRange] = Field(None, description="Date range for the query")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    domain_id: Optional[str] = Field(None, description="Domain ID to filter by")


class RebuttalRecord(BaseModel):
    """Individual rebuttal record."""
    work_item_id: str = Field(..., description="Work Item ID (PYID)")
    worktype_category: str = Field(..., description="Work Type Category")
    outcome_status: str = Field(..., description="Outcome Status")
    lob: Optional[str] = Field(None, description="Line of Business")
    resolved_date: Optional[str] = Field(None, description="Resolved Date (MM/DD/YYYY)")
    domain_id: Optional[str] = Field(None, description="Domain ID")
    platform_source_system: Optional[str] = Field(None, description="Platform Source System")
    error_category: Optional[str] = Field(default="N/A", description="Error Category")
    error_type: Optional[str] = Field(default="N/A", description="Error Type")
    rebuttal_outcome: Optional[str] = Field(default="N/A", description="Rebuttal Outcome")
    associate_name: Optional[str] = Field(default="N/A", description="Associate Name")
    audit_month: Optional[str] = Field(default="N/A", description="Audit Month")
    audit_year: Optional[str] = Field(default="N/A", description="Audit Year")


class RebuttalDrilldownPaginatedRequest(BaseModel):
    """Request model for rebuttal drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "audit_periods": [{"month": "June", "year": "2026"}],
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "page": 1,
                "page_size": 20
            }
        }


class RebuttalDrilldownResponse(BaseModel):
    """Response model for rebuttal drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Records per page")
    total_records: int = Field(..., description="Total number of records")
    total_pages: int = Field(..., description="Total number of pages")
    records: List[RebuttalRecord] = Field(..., description="List of rebuttal records")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class RebuttalDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for rebuttal drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[RebuttalRecord] = Field(..., description="List of rebuttal records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Performance IQ Manager Models
# =============================================================================

class AuditPeriod(BaseModel):
    """Audit period model for filtering by month and year."""
    year: str = Field(..., description="Audit year")
    month: str = Field(..., description="Audit month")


class ManagerBaseRequest(BaseModel):
    """Base request model for manager-level APIs."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs to filter associates (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for synchronized caching across all Manager APIs")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods (month/year) for audit score filtering")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [{"month": "January", "year": 2026}, {"month": "February", "year": 2026}]
            }
        }


class ManagerHeaderKPIsRequest(ManagerBaseRequest):
    """Request model for manager header KPIs."""
    pass


class ManagerHeaderKPIsResponse(BaseModel):
    """Response model for manager header KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    work_items_completed: int = Field(..., description="Work items completed by team")
    production_pct_achieved: float = Field(..., description="Production percentage achieved by team")
    audit_score_pct: float = Field(..., description="Audit score percentage for team")
    pended_items_count: int = Field(..., description="Pended items count")
    non_value_add_pct: float = Field(..., description="Non-value add percentage")
    cycle_time_avg: str = Field(default="N/A", description="Cycle time average")
    team_rank: Optional[int] = Field(None, description="Team rank among all teams")
    department_rank: Optional[int] = Field(None, description="Department rank")
    skilled_sources: Optional[List[str]] = Field(default=[], description="List of skilled sources")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    production_pct_achieved_status: str = Field(default="N/A", description="Status for Production percentage achieved")
    audit_score_pct_status: str = Field(default="N/A", description="Status for Audit score percentage")
    cycle_time_avg_status: str = Field(default="N/A", description="Status for Cycle time average")


class ManagerQualityOutcomesData(BaseModel):
    """Data model for quality outcomes metrics."""
    production_pct_achieved: float = Field(..., description="Production percentage achieved")
    production_goal: float = Field(default=100, description="Production goal percentage")
    audit_score_pct: float = Field(..., description="Audit score percentage")
    audit_score_goal: float = Field(default=98, description="Audit score goal percentage")
    fuse_time_productive_pct: float = Field(..., description="OHI productive time percentage")
    fuse_time_non_productive_pct: float = Field(..., description="Fuse non-productive time percentage")
    rebuttal_count: int = Field(..., description="Number of rebuttals")
    rebuttal_status: str = Field(default="Not Overturned", description="Rebuttal status")
    rework_pct: float = Field(..., description="Rework percentage")
    fuse_time_value: int = Field(..., description="Fuse time value")
    complete_audit_count: int = Field(..., description="Complete audit count")
    audit_errors: int = Field(..., description="Audit errors count")


class ManagerQualityOutcomesResponse(BaseModel):
    """Response model for manager quality outcomes."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: ManagerQualityOutcomesData = Field(..., description="Quality outcomes data")
    message: Optional[str] = Field(None, description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerTimeUtilizationResponse(BaseModel):
    """Response model for manager time utilization metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    staff_utilization_pct: str = Field(default="N/A", description="Staff utilization percentage (Workday TBD)")
    capacity_pct: str = Field(default="N/A", description="Capacity percentage (Workday TBD)")
    total_fuse_time_hours: float = Field(..., description="Total fuse time in hours")
    total_non_productive_hours: float = Field(..., description="Total non-productive time in hours")
    ohi_productive_time: float = Field(default=0.0, description="OHI productive time in hours from PRODUCTIVETIME column")
    other_time_hours: float = Field(default=0.0, description="Other time in hours (calculated as Total - Productive - Non-Productive)")
    productive_pct: float = Field(default=0.0, description="Productive time percentage")
    non_productive_pct: float = Field(default=0.0, description="Non-productive time percentage")
    other_pct: float = Field(default=0.0, description="Other time percentage")
    experience_level_distribution: List[ExperienceLevelItem] = Field(default=[], description="Experience level distribution")
    utilization_trend: List[AuditScoreTrend] = Field(default=[], description="Utilization trend over time (reusing AuditScoreTrend structure)")
    production_trend: List[ProductionPercentageTrend] = Field(default=[], description="Production percentage trend over time")
    capacity_insights: List[CapacityInsightItem] = Field(default=[], description="Capacity insights data for bar chart")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class CapacityInsightRecord(BaseModel):
    """Individual capacity insight record."""
    month_prior_year: str = Field(..., description="Month (Prior Year)")
    total_required_hours: str = Field(..., description="Total Required Hours")
    total_available_hours: str = Field(..., description="Total Available Hours")
    fte_gap: str = Field(..., description="FTE Gap")
    avg_available_hours_daily: str = Field(..., description="Avg Available Hours Daily")
    total_pto_hours: str = Field(..., description="Total PTO Hours")
    total_uto_hours: str = Field(..., description="Total UTO Hours")
    in_year_required_hours_prediction: str = Field(..., description="In Year Required Hours (Prediction)")
    in_year_available_hours: str = Field(..., description="In Year Available Hours")
    variance: str = Field(..., description="Variance")


class CapacityInsightDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for capacity insight drilldown API."""
    screen_id: str = Field(default="capacity_insights", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")


    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "capacity_insights",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class CapacityInsightDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for capacity insight drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CapacityInsightRecord] = Field(..., description="List of capacity insight records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerCapacityInsightDrilldownRequest(BaseModel):
    """Paginated request model for manager capacity insight drilldown API."""
    screen_id: str = Field(default="capacity_insights", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs (not used for filtering in Manager APIs)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "capacity_insights",
                "user_id": "AM42536",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["AM42536"],
                "frontline_associate_ids": ["AF18006"],
                "page": 1,
                "page_size": 20
            }
        }


class ManagerCapacityInsightDrilldownResponse(BaseModel):
    """Paginated response model for manager capacity insight drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CapacityInsightRecord] = Field(..., description="List of capacity insight records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class SlaHealthRecord(BaseModel):
    """Individual SLA health record."""
    work_item: str = Field(..., description="Work Item ID")
    work_type: str = Field(..., description="Work Type")
    associate: str = Field(..., description="Associate Name")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    platform: str = Field(..., description="Platform")
    manager_name: str = Field(..., description="Manager Name")
    assigned_date: str = Field(..., description="Assigned Date")
    cob: str = Field(..., description="COB")
    elv_due_date: str = Field(..., description="ELV Due Date")


class SlaHealthDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for SLA health drilldown API."""
    screen_id: str = Field(default="sla_health", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Director ID to filter (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "sla_health",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["SANTICH"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class SlaHealthDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for SLA health drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[SlaHealthRecord] = Field(..., description="List of SLA health records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class CompletedAtaCountsRecord(BaseModel):
    """Individual completed ATA counts record."""
    work_item: str = Field(..., description="Work Item ID")
    worktype_category: str = Field(..., description="Worktype Category")
    ata_cycle_time: str = Field(..., description="ATA Cycle Time")
    ata_resolved_status: str = Field(..., description="ATA Resolved Status")
    lob: str = Field(..., description="Line of Business")
    ata_resolved_date: str = Field(..., description="ATA Resolved Date")
    platform_source_system: str = Field(..., description="Platform - Source System")


class CompletedAtaCountsDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for completed ATA counts drilldown API."""
    screen_id: str = Field(default="completed_ata_counts", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "completed_ata_counts",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20
            }
        }


class CompletedAtaCountsDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for completed ATA counts drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CompletedAtaCountsRecord] = Field(..., description="List of completed ATA counts records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditSamplePctRecord(BaseModel):
    """Audit sample percentage summary record."""
    date_range: str = Field(..., description="Date Range (e.g., '1/1/2026 — 1/7/2026')")
    open_audits: int = Field(..., description="Number of Open Audits")
    closed_audits: int = Field(..., description="Number of Closed Audits")
    pending_audits: int = Field(..., description="Number of Pending Audits")
    total_cases_resolved: int = Field(..., description="Total cases resolved by FL associate during previous week")


class AuditSamplePctDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit sample percentage drilldown API."""
    screen_id: str = Field(default="audit_sample_pct", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    audit_status: Optional[str] = Field(None, description="Audit status filter (Open, Closed, Pending)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "audit_sample_pct",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_status": "Open",
                "page": 1,
                "page_size": 20
            }
        }


class AuditSamplePctDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit sample percentage drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditSamplePctRecord] = Field(..., description="List of audit sample percentage records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class WatchlistRecord(BaseModel):
    """Individual watchlist record."""
    work_item: str = Field(..., description="Work Item ID")
    work_type: str = Field(..., description="Work Type")
    associate: str = Field(..., description="Associate Name")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    platform: str = Field(..., description="Platform")
    elv_due_date: str = Field(..., description="ELV Due Date")


class WatchlistDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for watchlist drilldown API."""
    screen_id: str = Field(default="watchlist", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    resolved_status: Optional[str] = Field(None, description="Resolved status filter (Resolved, Open)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "watchlist",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "resolved_status": "Open",
                "page": 1,
                "page_size": 20
            }
        }


class WatchlistDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for watchlist drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[WatchlistRecord] = Field(..., description="List of watchlist records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerWatchlistDrilldownRequest(BaseModel):
    """Paginated request model for manager watchlist drilldown API."""
    screen_id: str = Field(default="watchlist", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs (not used for filtering in Manager APIs)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate IDs to filter (default: all)")
    resolved_status: Optional[str] = Field(None, description="Resolved status filter (Resolved, Open)")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "watchlist",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "resolved_status": "Open",
                "page": 1,
                "page_size": 20,
                "sort_by": "work_item",
                "sort_direction": "desc",
            }
        }


class ManagerWatchlistDrilldownResponse(BaseModel):
    """Paginated response model for manager watchlist drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[WatchlistRecord] = Field(..., description="List of watchlist records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class CycleTaktRecord(BaseModel):
    """Individual cycle-takt gap record."""
    work_item: str = Field(..., description="Work Item ID")
    work_type: str = Field(..., description="Work Type")
    case_cycle_time: str = Field(..., description="Case Cycle Time")
    cycle_takt_gap: str = Field(..., description="Cycle-Takt Gap")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    resolved_date: str = Field(..., description="Resolved Date (MM/DD/YYYY)")
    associate: str = Field(..., description="Associate Name")
    member_source_system: str = Field(..., description="Memer Source System")


class CycleTaktDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for the cycle takt gap drilldown API."""
    screen_id: str = Field(default="cycle_takt_gap", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(
        None, description="Frontline associate ID to filter (default: all)"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "cycle_takt_gap",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "page": 1,
                "page_size": 20,
            }
        }


class CycleTaktDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for the cycle takt gap drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CycleTaktRecord] = Field(..., description="List of cycle-takt gap records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ReworkPctRecord(BaseModel):
    """Individual rework percentage record."""
    work_item: str = Field(..., description="Work Item ID")
    work_type: str = Field(..., description="Work Type")
    resolved_status: str = Field(..., description="Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    resolved_date: str = Field(..., description="Resolved Date")
    platform: str = Field(..., description="Platform")
    audit_score: str = Field(..., description="Audit Score")
    auditor_name: str = Field(..., description="Auditor Name")


class ReworkPctDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for rework percentage drilldown API."""
    screen_id: str = Field(default="rework_pct", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    resolved_status: Optional[str] = Field(None, description="Resolved status filter (Resolved, Resolved - Autoclosed)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "rework_pct",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "resolved_status": "Resolved",
                "page": 1,
                "page_size": 20
            }
        }


class ReworkPctDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for rework percentage drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[ReworkPctRecord] = Field(..., description="List of rework percentage records")

    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class ManagerUserActivityRequest(BaseModel):
    """Request model for manager user activity API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    manager_ids: Optional[List[str]] = Field(None, description="Manager IDs (default: all)")
    associate_ids: Optional[List[str]] = Field(None, description="Associate IDs who report to the manager (default: all)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AD13460",
                "start_date": "2025-08-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial"],
                "manager_ids": ["AD13460"],
                "associate_ids": ["AH40730", "AI06493"]
            }
        }

class ManagerUserActivityData(BaseModel):
    """Data section for manager user activity response."""
    associate_id: str
    login_logout_records: List[LoginLogoutRecord]
    skilled_sources: List[str]
    team_rank: str = Field(default="NA", description="Team Rank")
    department_rank: str = Field(default="NA", description="Department Rank")
    ramp: str = Field(default="N/A", description="Experience level/ramp status")


class ManagerUserActivityResponse(BaseModel):
    """Response model for manager user activity API."""
    meta: Dict[str, str]
    data: Optional[ManagerUserActivityData] = None
    errors: Optional[List[Dict[str, Any]]] = None
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")


class CompletedAuditCountRecord(BaseModel):
    """Individual completed audit count record."""
    work_item: str = Field(..., description="Work Item ID")
    worktype_category: str = Field(..., description="Worktype Category")
    audit_cycle_time: str = Field(..., description="Audit Cycle Time")
    audit_resolved_status: str = Field(..., description="Audit Resolved Status")
    inventory_type: str = Field(..., description="Inventory Type")
    lob: str = Field(..., description="Line of Business")
    audit_resolved_date: str = Field(..., description="Audit Resolved Date")
    auditor_id: str = Field(..., description="Auditor ID")
    auditor_name: str = Field(..., description="Auditor Name")
    platform_source_system: str = Field(..., description="Platform - Source System")
    audit_month: Optional[str] = Field(default="N/A", description="Audit Month")
    audit_year: Optional[str] = Field(default="N/A", description="Audit Year")


class CompletedAuditCountDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for completed audit count drilldown API."""
    screen_id: str = Field(default="completed_audit_count", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")


class CompletedAuditCountDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for completed audit count drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[CompletedAuditCountRecord] = Field(..., description="List of completed audit count records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



class AuditErrorDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit error drilldown API."""
    screen_id: str = Field(default="audit_error", description="Screen identifier")
    query: PaginatedQuery = Field(..., description="Query parameters")
    page: PageRequest = Field(default_factory=PageRequest, description="Pagination parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "page": {
                    "page": 1,
                    "page_limit": 50
                },
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-06-05"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AF05867",
                    "audit_periods": [{"year": "2026", "month": "June"}],
                },
                "screen_id": "audit_error"
            }
        }


class AuditErrorDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit error drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditErrorRecord] = Field(..., description="List of audit error records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditErrorDrilldownDownloadRequest(BaseModel):
    """Download request model for audit error drilldown API."""
    query: PaginatedQuery = Field(..., description="Query parameters")

    class Config:
        json_schema_extra = {
            "example": {
                "query": {
                    "date_range": {
                        "from": "2025-04-03",
                        "to": "2025-06-05"
                    },
                    "lob": ["Commercial"],
                    "user_id": "AF05867"
                }
            }
        }


class AuditErrorDirectorDrilldownPaginatedRequest(BaseModel):
    """Paginated request model for audit error drilldown API (Director version)."""
    screen_id: str = Field(default="audit_error_director", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "audit_error_director",
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"],
                "page": 1,
                "page_size": 20
            }
        }


class AuditErrorDirectorDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for audit error drilldown API (Director version)."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditErrorRecord] = Field(..., description="List of audit error records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# Director Download Request Models
class DirectorBaseDownloadRequest(BaseModel):
    """Base download request model for Director drilldown APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse (enables instant Excel downloads from cached data)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "director_ids": ["AL50321"],
                "manager_ids": ["ROSETSC"],
                "frontline_associate_ids": ["HINERTR", "AH40730"]
            }
        }


# Manager Drilldown Request Models
class AuditScoreManagerDrilldownRequest(BaseModel):
    """Request model for audit score manager drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods (month/year pairs) to filter by")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"],
                "audit_periods": [],
                "sort_by": None,
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


# Manager Download Request Models
class ManagerBaseDownloadRequest(BaseModel):
    """Base download request model for Manager drilldown APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    frontline_associate_ids: Optional[List[str]] = Field(None, description="Frontline associate ID to filter (default: all)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2025-02-01",
                "end_date": "2026-02-07",
                "audit_periods": [{"month": "June", "year": "2026"}],
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "frontline_associate_ids": ["AI06493", "AG20176"]
            }
        }


class DirectorUserActivityRequest(BaseModel):
    """Request model for director user activity API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    director_ids: Optional[List[str]] = Field(None, description="Filter by Director id")
    frontline_associate_id: str = Field(..., description="Frontline associate ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "frontline_associate_id": "AH40730",
                "start_date": "2025-08-01",
                "end_date": "2026-03-31"
            }
        }


class DirectorUserActivityData(BaseModel):
    """Data section for director user activity response."""
    team_rank: str = Field(default="NA", description="Team Rank")
    department_rank: str = Field(default="NA", description="Department Rank")
    ramp: str = Field(default="N/A", description="Experience level/ramp status")
    skilled_sources: List[str] = Field(default_factory=list, description="List of skilled source systems")


class DirectorUserActivityResponse(BaseModel):
    """Response model for director user activity API."""
    meta: Dict[str, str]
    data: Optional[DirectorUserActivityData] = None
    errors: Optional[List[Dict[str, Any]]] = None
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")


# =============================================================================
# Performance IQ Auditor Manager Models
# =============================================================================

class AuditorManagerBaseRequest(BaseModel):
    """Base request model for auditor manager-level APIs."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit cycle time"
    )
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    session_id: Optional[str] = Field(None, description="Session ID for Redis cache retrieval")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AM12345",
                "start_date": "2026-03-01",
                "end_date": "2026-03-31",
                "audit_periods": [
                    {"year": "2026", "month": "April"},
                    {"year": "2026", "month": "May"},
                    {"year": "2026", "month": "June"}
                ],
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"]
            }
        }


class AuditorManagerListRequest(BaseModel):
    """Request model for auditor manager's manager list API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    search: Optional[str] = Field(None, description="Search term to filter managers by name or ID")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AM12345",
                "search": None,
                "start_date": "2026-01-01",
                "end_date": "2026-03-31"
            }
        }

class AuditorListRequest(BaseModel):
    """Request model for auditor manager's auditor list API."""
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    manager_ids: list[Optional[str]] = Field(None, description="Filter by manager id")
    search: Optional[str] = Field(None, description="Search term to filter auditors by ID or name")
    limit: int = Field(default=10000, ge=1, le=10001, description="Maximum number of results")

    class Config:
        json_schema_extra = {
            "example": {
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "manager_ids": ["AC95624", "AM67537"],
                "search": None,
                "limit": 50
            }
        }


class AuditorManagerLOBRequest(BaseModel):
    """Request model for Auditor Manager LOB list API with auditor filtering."""
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    auditor_ids: Optional[List[str]] = Field(None, description="List of auditor IDs to filter")
    
    class Config:
        json_schema_extra = {
            "example": {
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "auditor_ids": ["AF18133", "AD47521"],
                "manager_ids": ["AC95624"],
            }
        }


class AuditorManagerLOBResponse(BaseModel):
    """Response model for Auditor Manager LOB list API."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(..., description="List of available LOBs filtered by auditor relationships")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerHeaderKPIsResponse(BaseModel):
    """Response model for auditor manager header KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    complete_audit_count: str = Field(..., description="Total completed audits")
    audit_sample_percent: str = Field(..., description="Audit sample percentage")
    audit_sample_count: str = Field(default="N/A", description="Number of items audited")
    work_items_completed: str = Field(..., description="Work items completed")
    audit_cycle_time: str = Field(default="N/A", description="Average audit cycle time (coming soon)")
    audit_cycle_time_bubble: str = Field(default="N/A", description="Audit cycle time status bubble (coming soon)")
    ata_audit_score: str = Field(default="N/A", description="ATA audit score (coming soon)")
    ata_audit_score_bubble: str = Field(default="N/A", description="ATA audit score status bubble (coming soon)")
    ata_rebuttals: str = Field(default="N/A", description="ATA rebuttals count (coming soon)")
    ata_rebuttal_percent: str = Field(default="N/A", description="ATA audit rebuttal percentage (coming soon)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerTimeUtilizationResponse(BaseModel):
    """Response model for auditor manager time utilization metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    total_fuse_time_hours: float = Field(..., description="Total FUSE time in hours (2 decimal places)")
    ohi_productive_time: float = Field(..., description="OHI productive time in hours (2 decimal places)")
    total_non_productive_hours: float = Field(..., description="Total non-productive time in hours (2 decimal places)")
    other_time_hours: float = Field(..., description="Other time in hours (2 decimal places)")
    productive_pct: float = Field(..., description="Productive time percentage (2 decimal places)")
    non_productive_pct: float = Field(..., description="Non-productive time percentage (2 decimal places)")
    other_pct: float = Field(..., description="Other time percentage (2 decimal places)")
    staff_utilization_percent: float = Field(..., description="Staff utilization percentage (2 decimal places)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerAtaScoreGaugeResponse(BaseModel):
    """Response model for auditor manager ATA score gauge."""
    status: str = Field(..., description="Status of the request (success/error)")
    ata_score: float = Field(..., description="ATA audit score (2 decimal places)")
    trend: List[AuditScoreTrend] = Field(default=[], description="ATA score trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

class AuditorManagerCycleTimeTrend(BaseModel):
    """Cycle time trend data point (Auditor Manager)."""
    period: str = Field(..., description="Time period (format varies by range)")
    avg_cycle_time_minutes: float = Field(..., description="Average cycle time in minutes")
    avg_cycle_time_formatted: str = Field(..., description="Average cycle time formatted as 'X mins Y secs'")
    total_audits: int = Field(..., description="Total audits in the period")

class AuditorManagerAuditCycleTimeGaugeResponse(BaseModel):
    """Response model for auditor manager audit cycle time gauge."""
    status: str = Field(..., description="Status of the request (success/error)")
    audit_cycle_time: float = Field(..., description="Average audit cycle time in hours (2 decimal places)")
    audit_cycle_time_formatted: str = Field(..., description="Average audit cycle time formatted as 'X mins Y secs' or N/A")
    trend: List[AuditorManagerCycleTimeTrend] = Field(default=[], description="Audit cycle time trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class RebuttalCountTrend(BaseModel):
    """Rebuttal count trend data (Auditor Manager)."""
    rebuttals: Dict[str, int] = Field(default_factory=dict, description="Period -> rebuttal count")
    overturned: Dict[str, int] = Field(default_factory=dict, description="Period -> overturned count")
    upheld: Dict[str, int] = Field(default_factory=dict, description="Period -> upheld count")

class AuditorManagerRebuttalsResponse(BaseModel):
    """Response model for auditor manager rebuttals metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    rebuttals: str = Field(..., description="Total number of rebuttals")
    rebuttals_overturned: str = Field(..., description="Percentage of rebuttals overturned (2 decimal places)")
    rebuttals_count_trend: RebuttalCountTrend = Field(default_factory=RebuttalCountTrend, description="Rebuttals count trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerQualityOutcomesResponse(BaseModel):
    """Response model for auditor manager quality outcomes."""
    status: str = Field(..., description="Status of the request (success/error)")
    ata_score: float = Field(..., description="Average ATA audit score (2 decimal places)")
    ata_score_trend: List[AuditScoreTrend] = Field(default=[], description="ATA score trend over time")
    audit_cycle_time: float = Field(..., description="Average audit cycle time in minutes (2 decimal places)")
    cycle_time_trend: List[AuditorManagerCycleTimeTrend] = Field(default=[], description="Audit cycle time trend over time")
    rebuttal_count: str = Field(..., description="Total number of ATA rebuttals")
    rebuttals_overturned: str = Field(..., description="Percentage of rebuttals overturned")
    rebuttals_count_trend: Dict[str, Any] = Field(default_factory=dict, description="Rebuttals count trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

# =============================================================================
# Auditor Manager Drilldown Models (with auditor_ids instead of frontline_associate_ids)
# =============================================================================

class AuditorManagerCompletedAuditCountDrilldownRequest(BaseModel):
    """Paginated request model for Auditor Manager completed audit count drilldown API."""
    screen_id: str = Field(default="completed_audit_count", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "completed_audit_count",
                "user_id": "AM12345",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"],
                "audit_periods": [{"year": "2026", "month": "June"}],
                "sort_by": "audit_resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerAuditSamplePctDrilldownRecord(BaseModel):
    """Audit sample percentage summary record (Auditor Manager)."""
    date_range: str = Field(..., description="Date Range (e.g., '1/1/2026 — 1/7/2026')")
    open_audits: int = Field(..., description="Number of Open Audits")
    closed_audits: int = Field(..., description="Number of Closed Audits")
    pending_audits: int = Field(..., description="Number of Pending Audits")
    total_cases_resolved: int = Field(..., description="Total cases resolved by auditors")


class AuditorManagerAuditSamplePctDrilldownRequest(BaseModel):
    """Paginated request model for Auditor Manager audit sample percentage drilldown API."""
    screen_id: str = Field(default="audit_sample_pct", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "audit_sample_pct",
                "user_id": "AM12345",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"],
                "audit_periods": [{"year": "2026", "month": "June"}],
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerAuditSamplePctDrilldownResponse(BaseModel):
    """Paginated response model for Auditor Manager audit sample percentage drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditorManagerAuditSamplePctDrilldownRecord] = Field(..., description="List of audit sample percentage records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerAtaAuditScoreDrilldownRecord(BaseModel):
    """ATA Audit score record (Auditor Manager)."""
    pyid: str = Field(default="", description="Work Item")
    work_type: str = Field(default="", description="Work Type")
    audit_cycle_time: str = Field(default="", description="Audit Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    audit_resolved: str = Field(default="", description="Audit Resolved")
    auditor_domain_id: str = Field(default="", description="Auditor Name")
    platform: str = Field(default="", description="Platform")
    audit_score: str = Field(default="", description="Audit Score")
    targeted_audit_type: str = Field(default="N/A", description="Targeted Audit Type")
    inventory_type: str = Field(default="N/A", description="Inventory Type")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")

class AuditorManagerAtaAuditScoreDrilldownRequest(BaseModel):
    """Request model for Auditor Manager ATA audit score drilldown API."""
    screen_id: str = Field(default="ata_audit_score", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "ata_audit_score",
                "user_id": "AM12345",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"],
                "audit_periods": [{"year": "2026", "month": "June"}],
                "sort_by": "audit_resolved",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerAtaAuditScoreDrilldownResponse(BaseModel):
    """Paginated response model for Auditor Manager ATA audit score drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[AuditorManagerAtaAuditScoreDrilldownRecord] = Field(..., description="List of ATA audit score records")
    completed_audit_work_items: int = Field(default=0, description="Total count of completed audit work items")
    target_audit_count: int = Field(default=0, description="Number of targeted audits")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerRebuttalDrilldownRequest(BaseModel):
    """Request model for Auditor Manager rebuttal drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "auditor_ids": ["AI06493", "AG20176"],
                "audit_periods": [{"year": "2026", "month": "June"}],
                "sort_by": "resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerWorkItemsDrilldownRequest(BaseModel):
    """Request model for Auditor Manager work items drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "auditor_ids": ["AI06493", "AG20176"],
                "sort_by": "resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class AuditorManagerAICoachResponse(BaseModel):
    """Response model for Auditor Manager AI Coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class AuditorManagerFuseTimeDrilldownRequest(BaseModel):
    """Request model for Auditor Manager fuse time drilldown API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format (default: no filter)")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format (default: no filter)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values (default: all)")
    manager_ids: Optional[List[str]] = Field(None, description="Manager name to filter (default: all)")
    auditor_ids: Optional[List[str]] = Field(None, description="Auditor ID to filter (default: all)")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-03-01",
                "end_date": "2026-03-25",
                "lob": ["Commercial"],
                "manager_ids": ["LUCASCR"],
                "auditor_ids": ["AI06493", "AG20176"],
                "sort_by": "date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }

class ATARebuttalRecord(BaseModel):
    """Individual ATA rebuttal drilldown record."""
    work_item_id: str = Field(..., description="Work Item ID")
    worktype_category: str = Field(..., description="Worktype Category")
    outcome_status: str = Field(..., description="Outcome Status")
    lob: Optional[str] = Field(None, description="LOB")
    resolved_date: Optional[str] = Field(None, description="Resolved Date")
    domain_id: Optional[str] = Field(None, description="Domain ID")
    associate_name: Optional[str] = Field(default="N/A", description="Associate Name")
    platform_source_system: Optional[str] = Field(None, description="Platform Source System")
    error_category: Optional[str] = Field(default="N/A", description="Error Category")
    error_type: Optional[str] = Field(default="N/A", description="Error Type")
    rebuttal_outcome: Optional[str] = Field(default="N/A", description="Rebuttal Outcome")
    inventory_type: Optional[str] = Field(default="N/A", description="Inventory Type")
    audit_month: Optional[str] = Field(default="N/A", description="Audit Month")
    audit_year: Optional[str] = Field(default="N/A", description="Audit Year")  


class ATARebuttalDrilldownPaginatedResponse(BaseModel):
    """Paginated response model for ATA rebuttal drilldown."""
    status: str = Field(..., description="Status of the request (success/error)")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[ATARebuttalRecord] = Field(..., description="List of ATA rebuttal records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# ============================================================================
# FL Auditor Models
# ============================================================================

class FLAuditorBaseRequest(BaseModel):
    """Base request model for FL Auditor endpoints."""
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for synchronized caching across all FL Auditor APIs")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(default=None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AI06493",
                "start_date": "2026-03-01",
                "end_date": "2026-03-31",
                "lob": ["Medicare","Commercial"],
                "audit_periods": [{"year": "2026", "month": "May"}, {"year": "2026", "month": "June"}]
            }
        }


class FLAuditorHeaderKPIsResponse(BaseModel):
    """Response model for FL Auditor header KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    rebuttal_count: str = Field(..., description="Total rebuttal count")
    complete_audit_count: str = Field(..., description="Total completed audits")
    ata_audit_score: str = Field(..., description="ATA audit score percentage")
    ata_audit_score_bubble: str = Field(default="Good", description="ATA audit score status bubble")
    audit_cycle_time: str = Field(..., description="Average audit cycle time")
    work_items_completed: str = Field(..., description="Work items completed")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    cache_metadata: Optional[CacheMetadata] = Field(default=None, description="Cache status metadata")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "success",
                "rebuttal_count": "5",
                "complete_audit_count": "20",
                "ata_audit_score": "99.25%",
                "ata_audit_score_bubble": "Good",
                "audit_cycle_time": "18 min",
                "audit_cycle_time_bubble": "Good",
                "work_items_completed": "500",
                "message": "FL Auditor header KPIs retrieved successfully"
            }
        }


# FL Auditor Drilldown Models

class FLAuditorRebuttalRecord(BaseModel):
    """Individual rebuttal record for FL Auditor."""
    work_item_id: str = Field(default="N/A", description="Work Item ID")
    worktype_category: str = Field(default="N/A", description="Worktype Category")
    outcome_status: str = Field(default="N/A", description="Outcome Status")
    error_category: str = Field(default="N/A", description="Error Category")
    error_type: str = Field(default="N/A", description="Error Type")
    rebuttal_outcome: str = Field(default="N/A", description="Rebuttal Outcome")
    lob: str = Field(default="N/A", description="Line of Business")
    resolved_date: str = Field(default="N/A", description="Resolved Date")
    domain_id: str = Field(default="N/A", description="Domain ID")
    platform_source_system: str = Field(default="N/A", description="Platform Source System")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class FLAuditorRebuttalDrilldownRequest(BaseModel):
    """Request model for FL Auditor rebuttal drilldown."""
    screen_id: str = Field(default="rebuttal_count", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods for filtering")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "rebuttal_count",
                "user_id": "AF93939",
                "session_id": "abc123",
                "start_date": "2026-05-01",
                "end_date": "2026-06-30",
                "lob": ["Commercial", "Medicaid"],
                "audit_periods": [
                    {"month": "June", "year": "2026"},
                    {"month": "July", "year": "2026"}
                ],
                "sort_by": "resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }

class AuditorManagerAICoachRequest(BaseModel):
    """Request model for Auditor Manager AI coach API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format")
    manager_ids: Optional[List[str]] = Field(None, description="List of manager IDs to filter")
    auditor_ids: Optional[List[str]] = Field(None, description="List of auditor IDs to filter")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AM12345",
                "start_date": "2026-01-01",
                "end_date": "2026-03-31",
                "lob": ["Commercial", "Medicaid"],
                "manager_ids": ["AC95624"],
                "auditor_ids": ["AF18133", "AD47521"]
            }
        }


class FLAuditorRebuttalDrilldownResponse(BaseModel):
    """Response model for FL Auditor rebuttal drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FLAuditorRebuttalRecord] = Field(..., description="List of rebuttal records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[dict] = Field(None, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorCompleteAuditRecord(BaseModel):
    """Individual completed audit record for FL Auditor."""
    work_item: str = Field(default="N/A", description="Work Item ID")
    worktype_category: str = Field(default="N/A", description="Worktype Category")
    audit_cycle_time: str = Field(default="00:00:00", description="Audit Cycle Time")
    audit_resolved_status: str = Field(default="N/A", description="Audit Resolved Status")
    inventory_type: str = Field(default="N/A", description="Inventory Type")
    lob: str = Field(default="N/A", description="Line of Business")
    audit_resolved_date: str = Field(default="N/A", description="Audit Resolved Date")
    auditor_name: str = Field(default="N/A", description="Auditor Name")
    platform_source_system: str = Field(default="N/A", description="Platform - Source System")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class FLAuditorCompleteAuditDrilldownRequest(BaseModel):
    """Request model for FL Auditor complete audit drilldown."""
    screen_id: str = Field(default="complete_audit_count", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(
        None,
        description="If provided with one or more valid month/year pairs, overrides start_date/end_date for audit-side filtering"
    )
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "complete_audit_count",
                "user_id": "AF93939",
                "session_id": "abc123",
                "start_date": "2026-05-01",
                "end_date": "2026-06-30",
                "lob": ["Commercial", "Medicaid"],
                "audit_periods": [
                    {"month": "June", "year": "2026"},
                    {"month": "July", "year": "2026"}
                ],
                "sort_by": "audit_resolved_date",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class FLAuditorCompleteAuditDrilldownResponse(BaseModel):
    """Response model for FL Auditor complete audit drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FLAuditorCompleteAuditRecord] = Field(..., description="List of completed audit records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[dict] = Field(None, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorAtaScoreRecord(BaseModel):
    """Individual ATA score record for FL Auditor."""
    pyid: str = Field(default="", description="PYID")
    work_type: str = Field(default="", description="Work Type")
    audit_cycle_time: str = Field(default="", description="Audit Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    audit_resolved: str = Field(default="", description="Audit Resolved Date")
    auditor_name: str = Field(default="", description="Auditor Name")
    platform: str = Field(default="", description="Platform")
    audit_score: str = Field(default="", description="Audit Score with %")
    targeted_audit_type: str = Field(default="N/A", description="Targeted Audit Type")
    inventory_type: str = Field(default="N/A", description="Inventory Type")
    audit_month: str = Field(default="N/A", description="Audit Month")
    audit_year: str = Field(default="N/A", description="Audit Year")


class FLAuditorAtaScoreDrilldownRequest(BaseModel):
    """Request model for FL Auditor ATA score drilldown."""
    screen_id: str = Field(default="ata_score", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    audit_periods: Optional[List[AuditPeriod]] = Field(None, description="List of audit periods for filtering")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "ata_score",
                "user_id": "AF93939",
                "session_id": "abc123",
                "start_date": "2026-05-01",
                "end_date": "2026-06-30",
                "lob": ["Commercial", "Medicaid"],
                "audit_periods": [
                    {"month": "June", "year": "2026"},
                    {"month": "July", "year": "2026"}
                ],
                "sort_by": "audit_resolved",
                "sort_direction": "desc",
                "page": 1,
                "page_size": 20
            }
        }


class FLAuditorAtaScoreDrilldownResponse(BaseModel):
    """Response model for FL Auditor ATA score drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FLAuditorAtaScoreRecord] = Field(..., description="List of ATA score records")
    completed_audit_work_items: int = Field(..., description="Total completed audit work items")
    target_audit_count: int = Field(..., description="Count of targeted audits")
    message: str = Field(..., description="Response message")
    tooltips: Optional[dict] = Field(None, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorWorkItemRecord(BaseModel):
    """Individual work item record for FL Auditor."""
    pyid: str = Field(default="", description="PYID")
    work_type: str = Field(default="", description="Work Type")
    case_cycle_time: str = Field(default="", description="Case Cycle Time")
    resolved_status: str = Field(default="", description="Resolved Status")
    lob: str = Field(default="", description="LOB")
    resolved_date: str = Field(default="", description="Resolved Date")
    domain_id: str = Field(default="", description="Domain ID")
    associate_name: str = Field(default="", description="Associate Name")
    platform: str = Field(default="", description="Platform")
    inventory_type: str = Field(default="", description="Inventory Type")


class FLAuditorWorkItemsDrilldownRequest(BaseModel):
    """Request model for FL Auditor work items drilldown."""
    screen_id: str = Field(default="work_items", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "work_items",
                "user_id": "AI06493",
                "start_date": "2026-03-01",
                "end_date": "2026-03-31",
                "lob": ["Medicare","Commercial"],
                "page": 1,
                "page_size": 20
            }
        }


class FLAuditorWorkItemsDrilldownResponse(BaseModel):
    """Response model for FL Auditor work items drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    user_id: str = Field(..., description="User ID")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FLAuditorWorkItemRecord] = Field(..., description="List of work item records")
    message: str = Field(..., description="Response message")
    tooltips: Optional[dict] = Field(None, description="Field tooltips")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# FL Auditor Quality Outcomes Models

class FLAuditorAtaScoreGaugeResponse(BaseModel):
    """Response model for FL Auditor ATA score gauge."""
    status: str = Field(..., description="Status of the request (success/error)")
    ata_score: str = Field(..., description="ATA audit score (2 decimal places or N/A)")
    trend: List[AuditScoreTrend] = Field(default=[], description="ATA score trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorCycleTimeTrend(BaseModel):
    """Cycle time trend data point for FL Auditor."""
    period: str = Field(..., description="Time period (format varies by range)")
    avg_cycle_time_minutes: float = Field(..., description="Average cycle time in minutes")
    avg_cycle_time_formatted: str = Field(..., description="Average cycle time formatted as 'X mins Y secs'")
    total_audits: int = Field(..., description="Total audits in the period")


class FLAuditorAuditCycleTimeGaugeResponse(BaseModel):
    """Response model for FL Auditor audit cycle time gauge."""
    status: str = Field(..., description="Status of the request (success/error)")
    audit_cycle_time: str = Field(..., description="Average audit cycle time in minutes (2 decimal places or N/A)")
    audit_cycle_time_formatted: str = Field(..., description="Average audit cycle time formatted as 'X mins Y secs' or N/A")
    trend: List[FLAuditorCycleTimeTrend] = Field(default=[], description="Audit cycle time trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class RebuttalTrend(BaseModel):
    """Trend data for rebuttals over time."""
    period: str = Field(..., description="Time period (e.g., '01/15', '2024-01', '2024-Q1')")
    rebuttals: int = Field(default=0, description="Total number of rebuttals in this period")
    overturned: int = Field(default=0, description="Number of rebuttals overturned in this period")
    upheld: int = Field(default=0, description="Number of rebuttals upheld in this period")


class FLAuditorRebuttalsResponse(BaseModel):
    """Response model for FL Auditor rebuttals metrics."""
    status: str = Field(..., description="Status of the request (success/error)")
    rebuttal_count: str = Field(..., description="Total number of rebuttals")
    rebuttals_overturned: str = Field(..., description="Percentage of rebuttals overturned (2 decimal places)")
    rebuttals_count_trend: Dict[str, Any] = Field(default_factory=dict, description="Rebuttals count trend over time")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# FL Auditor Time Utilization Models


class FLAuditorTimeUtilizationResponse(BaseModel):
    """Response model for FL Auditor time utilization metrics (Fuse time only)."""
    status: str = Field(..., description="Status of the request (success/error)")
    total_fuse_time_hours: str = Field(..., description="Total hours logged into FUSE system (2 decimal places or N/A)")
    ohi_productive_time: str = Field(..., description="OHI productive time in hours (2 decimal places or N/A)")
    total_non_productive_hours: str = Field(..., description="Total non-productive hours (2 decimal places or N/A)")
    other_time_hours: str = Field(..., description="Other time in hours (2 decimal places or N/A)")
    productive_pct: str = Field(..., description="Productive time percentage (2 decimal places or N/A)")
    non_productive_pct: str = Field(..., description="Non-productive time percentage (2 decimal places or N/A)")
    other_pct: str = Field(..., description="Other time percentage (2 decimal places or N/A)")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining each metric")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



class FLAuditorFuseTimeDrilldownRequest(BaseModel):
    """Request model for FL Auditor fuse time drilldown."""
    screen_id: str = Field(default="fuse_time", description="Screen identifier")
    user_id: str = Field(..., description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    sort_by: Optional[str] = Field(None, description="Column to sort by")
    sort_direction: Optional[str] = Field("desc", description="Sort direction: asc or desc")
    page: int = Field(1, ge=1, description="Page number (starts from 1)")
    page_size: int = Field(20, ge=1, le=100, description="Number of records per page")

    class Config:
        json_schema_extra = {
            "example": {
                "screen_id": "fuse_time",
                "user_id": "AI06493",
                "start_date": "2026-03-01",
                "end_date": "2026-03-31",
                "lob": ["Medicare","Commercial"],
                "page": 1,
                "page_size": 20
            }
        }


class FLAuditorFuseTimeDrilldownResponse(BaseModel):
    """Response model for FL Auditor fuse time drilldown."""
    status: str = Field(..., description="Status of the request")
    screen_id: str = Field(..., description="Screen identifier")
    page: PageResponse = Field(..., description="Pagination metadata")
    records: List[FuseTimeRecord] = Field(..., description="List of fuse time records")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



class FLAuditorLOBListResponse(BaseModel):
    """Response model for FL Auditor LOB list."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(default=[], description="List of Line of Business values")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorAICoachResponse(BaseModel):
    """Response model for FL Auditor AI Coach insights."""
    status: str = Field(..., description="Status of the request (success/error)")
    message_text: str = Field(..., description="AI Coach message text")
    performance_score: Optional[str] = Field(None, description="Performance score (e.g., '98.5%')")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FLAuditorLoginLogoutSession(BaseModel):
    """Individual login/logout session for FL Auditor."""
    login_time: Optional[str] = Field(default="N/A", description="Login time (e.g., '8:15 AM ET')")
    logout_time: Optional[str] = Field(default="N/A", description="Logout time (e.g., '5:30 PM ET')")


class FLAuditorUserActivityResponse(BaseModel):
    """Response model for FL Auditor user activity (login/logout times and audit team rank)."""
    status: str = Field(..., description="Status of the request (success/error)")
    sessions: List[FLAuditorLoginLogoutSession] = Field(default_factory=list, description="List of all login/logout sessions from the most recent date")
    audit_team_rank: str = Field(..., description="Audit team rank position (e.g., '6' or 'N/A')")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining the metrics")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
class AuditorManagerAICoachResponse(BaseModel):
    """Response model for Auditor Manager AI coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    message: str = Field(..., description="Response message")
    tooltips: Optional[Dict[str, str]] = Field(default=None, description="Tooltips explaining the metrics")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
class AuditorManagerAICoachResponse(BaseModel):
    """Response model for Auditor Manager AI coach API."""
    status: str = Field(..., description="Status of the request (success/error)")
    user_id: str = Field(..., description="User ID")
    performance_summary: str = Field(..., description="AI-generated performance summary based on KPIs")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
