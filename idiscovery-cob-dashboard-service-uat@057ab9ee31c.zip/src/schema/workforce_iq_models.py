import re
from pydantic import BaseModel, Field, field_validator, model_validator
from typing import Optional, List, Union, Dict, Any
from datetime import datetime


# =============================================================================
# Combined API Request Models
# =============================================================================

class ReceiptsVsResolvedRequest(BaseModel):
    """Request model for combined receipts vs resolved API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    grouping_level: Optional[str] = Field("monthly", description="Aggregation level: daily, weekly, monthly, quarterly, yearly")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "grouping_level": "monthly",
                "lob": ["Commercial", "Medicare", "Medicaid"],
                "staffing_category": ["F", "CB Prevention-ESRD", "CB Prevention", "GBD MCARE-Disputes (NextGen)", "CB-Claim Edits", "GBD MCARE-DHP (Prevention E&I)", "GBD MCARE-Rx E/I (eCob Intakes)", "CB Newborn-Claim Edits", "GBD CAID-Disputes(NextGen)", "CB-Inquiries", "GBD MCARE-Inquiries", "CB Prevention-eCAQH", "CB Prevention-Prevention", "CB Newborn-eCAQH (Prevention)", "GBD CAID-Claim Edits", "GBD MCARE-Rx Prevention", "GBD CAID-Vendor", "GBD CAID-Inquiries", "CB Prevention-HEW", "CB Newborn-Inquiries"],
                "work_type": ["CIW", "eCAQH", "HEW"],
                "manager": ["ROSETSC", "SANTICH", "HARPEDN", "MEYERCH"],
                "market": ["GA", "FL", "TX", "NC"],
                "funding_model": ["ASO", "Fully Insured"]
            }
        }


class ReceiptsAgeRequest(BaseModel):
    """Request model for combined receipts age API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache coordination (prevents duplicate warming)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "session_id": "session_abc123",
                "lob": ["Commercial", "Medicare", "Medicaid"],
                "work_type": ["CIW", "eCAQH", "HEW"],
                "manager": ["ROSETSC", "SANTICH", "HARPEDN", "MEYERCH"],
                "market": ["GA", "FL", "TX", "NC"]
            }
        }


# =============================================================================
# Combined API Response Models
# =============================================================================

class ReceiptsVsResolvedDataPoint(BaseModel):
    """Individual data point for receipts vs resolved chart."""
    GROUPING_LEVEL: str = Field(..., description="Aggregation level used")
    PERIOD_DATE: Union[str, datetime] = Field(..., description="Period date")
    PERIOD_LABEL: str = Field(..., description="Formatted period label")
    PROJECTED_RECEIPTS: Optional[int] = Field(None, description="Projected receipts count")
    ACTUAL_RECEIPTS: Optional[int] = Field(None, description="Actual receipts count")
    PROJECTED_RESOLVED: Optional[int] = Field(None, description="Projected resolved count")
    ACTUAL_RESOLVED: Optional[int] = Field(None, description="Actual resolved count")
    RECEIPTS_VARIANCE_GAP_PCT: Optional[float] = Field(None, description="Receipts variance gap percentage")
    RESOLVED_VARIANCE_GAP_PCT: Optional[float] = Field(None, description="Resolved variance gap percentage")
    ACTUAL_RESOLVED_BREAKDOWN: Optional[List[dict]] = Field(None, description="Breakdown of resolved cases by status (Resolved-Completed, Resolved-AutoCloseLink)")

    @field_validator('PERIOD_DATE', mode='before')
    @classmethod
    def convert_datetime_to_string(cls, v):
        """Convert datetime objects to ISO format strings."""
        if isinstance(v, datetime):
            return v.isoformat()
        return v


class ReceiptsVsResolvedCombinedResponse(BaseModel):
    """Response model for combined receipts vs resolved API."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: List[ReceiptsVsResolvedDataPoint] = Field(default_factory=list, description="Combined receipts and resolved trend data")
    period_count: int = Field(..., description="Number of periods returned")
    forecast_accuracy_pct: Optional[float] = Field(None, description="Forecast accuracy percentage")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

    @property
    def receipts(self) -> Optional[int]:
        if not self.data:
            return None
        return getattr(self.data[-1], 'ACTUAL_RECEIPTS', None)

    @property
    def resolved(self) -> Optional[int]:
        if not self.data:
            return None
        return getattr(self.data[-1], 'ACTUAL_RESOLVED', None)

    @property
    def variance_gap(self) -> Optional[float]:
        if not self.data:
            return None
        return getattr(self.data[-1], 'VARIANCE_GAP_PCT', None)

    @property
    def forecast_accuracy(self) -> Optional[float]:
        return self.forecast_accuracy_pct


class AgeBucketItem(BaseModel):
    """Individual age bucket item."""
    AGE_BUCKET: str = Field(..., description="Age bucket label (e.g., '00-02', '03-05')")
    CASE_COUNT: int = Field(..., description="Number of cases in this bucket")


class ReceiptsAgeCombinedResponse(BaseModel):
    """Response model for combined receipts age API."""
    status: str = Field(..., description="Status of the request (success/error)")
    session_id: Optional[str] = Field(None, description="Session ID for cache coordination (use this in subsequent drilldown calls)")
    elevance_age: List[AgeBucketItem] = Field(default_factory=list, description="Age distribution based on COMPANYRECEIVEDDATE (Elevance Age)")
    cob_age: List[AgeBucketItem] = Field(default_factory=list, description="Age distribution based on PXCREATEDATETIME (COB Age)")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Age Drilldown Models
# =============================================================================

class AgeDrilldownRequest(BaseModel):
    """Request model for age drilldown APIs."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for cache reuse (enables instant drilldowns)")
    age_buckets: Optional[List[str]] = Field(None, description="List of age buckets to drill into (e.g., ['00-02', '31-60'])")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models")
    page: Optional[int] = Field(1, ge=1, description="Page number (1-indexed)")
    page_size: Optional[int] = Field(100, ge=1, le=1000, description="Number of records per page (max 1000)")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "session_id": "session_abc123",
                "age_buckets": ["00-02", "31-60"],
                "lob": ["Commercial", "Medicare", "Medicaid"],
                "work_type": ["CIW", "eCAQH", "HEW"],
                "manager": ["ROSETSC", "SANTICH", "HARPEDN", "MEYERCH"],
                "market": ["GA", "FL", "TX", "NC"],
                "funding_model": ["ASO", "Fully Insured"],
                "page": 1,
                "page_size": 100
            }
        }


class AgeDrilldownItem(BaseModel):
    """Individual age drilldown record."""
    DATA_AGED: Optional[int] = Field(None, description="Age in days")
    WORK_ITEM: Optional[str] = Field(None, description="Work item ID (PYID)")
    DRILLING: Optional[str] = Field(None, description="Age bucket")
    INTAKE_SOURCE: Optional[str] = Field(None, description="Intake source system")
    COB_CREATE_DATE: Optional[Union[str, datetime]] = Field(None, description="COB create date")
    ELEVANCE_RECEIVED_DATE: Optional[Union[str, datetime]] = Field(None, description="Elevance received date")
    ASSIGNED_TO: Optional[str] = Field(None, description="Assigned to user")
    STATUS: Optional[str] = Field(None, description="Work item status")
    LOB: Optional[str] = Field(None, description="Line of business")
    MARKET: Optional[str] = Field(None, description="Market")
    FUNDINGMODEL: Optional[str] = Field(None, description="Funding model")
    MANAGER_NAME: Optional[str] = Field(None, description="Manager name")
    
    @field_validator('COB_CREATE_DATE', 'ELEVANCE_RECEIVED_DATE', mode='before')
    @classmethod
    def convert_datetime_to_string(cls, v):
        """Convert datetime objects to ISO format strings."""
        if isinstance(v, datetime):
            return v.isoformat()
        return v


class AgeDrilldownResponse(BaseModel):
    """Response model for age drilldown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: List[AgeDrilldownItem] = Field(default_factory=list, description="Age drilldown detail data")
    total_count: int = Field(..., description="Total count of records")
    filtered_count: Optional[int] = Field(None, description="Real-time count of filtered records for pagination")
    age_bucket_counts: Optional[dict] = Field(default_factory=dict, description="Count of records per age bucket")
    age_buckets: Optional[List[str]] = Field(default_factory=list, description="Age buckets selected for drilldown")
    page: Optional[int] = Field(None, description="Current page number")
    page_size: Optional[int] = Field(None, description="Number of records per page")
    total_pages: Optional[int] = Field(None, description="Total number of pages")
    has_next: Optional[bool] = Field(None, description="Whether there is a next page")
    has_previous: Optional[bool] = Field(None, description="Whether there is a previous page")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Individual Endpoint Models
# =============================================================================

class SourceTypeBreakdownRequest(BaseModel):
    """Request model for source type breakdown API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types to display")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models")

class WorkforceIQSimpleRequest(BaseModel):
    """Simple request model for filter list APIs (LOB, Manager, Staffing Category, etc.)."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31"
            }
        }


class WorkforceIQWorkTypeRequest(BaseModel):
    """Request model specifically for work types API with staffing category filtering."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    category_value: Optional[List[str]] = Field(None, description="List of staffing categories to filter work types (optional)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "category_value": ["CB-Claim Edits", "CB-Inquiries"]
            }
        }


class WorkforceIQManagerRequest(BaseModel):
    """Request model for Workforce IQ Manager list with LOB and category filtering."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    lobs: Optional[List[str]] = Field(None, description="List of LOB values to filter managers (optional)")
    category_value: Optional[List[str]] = Field(None, description="List of staffing categories to filter managers (optional)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "lobs": ["Commercial", "Medicare"],
                "category_value": ["CB-Claim Edits", "CB-Inquiries"]
            }
        }


class WorkforceIQMarketRequest(BaseModel):
    """Request model for Workforce IQ Market list with LOB filtering."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    lobs: Optional[List[str]] = Field(None, description="List of LOB values to filter markets (optional)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "lobs": ["Commercial", "Medicare"]
            }
        }


class WorkTypeBreakdownItem(BaseModel):
    """Individual work type breakdown item."""
    SOURCE_TYPE: str = Field(..., description="Source type/work type name")
    CASE_COUNT: Optional[int] = Field(None, description="Number of cases")
    PERCENTAGE: Optional[float] = Field(None, description="Percentage of total")
    details: Optional[List[dict]] = Field(default_factory=list, description="Detailed breakdown for combined entries (e.g., CIW and CIW-DUP)")

    @property
    def work_type(self) -> str:
        return self.SOURCE_TYPE

    @property
    def count(self) -> Optional[int]:
        return self.CASE_COUNT

    @property
    def percentage(self) -> Optional[float]:
        return self.PERCENTAGE


class SourceTypeBreakdownResponse(BaseModel):
    """Response model for source type breakdown API."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: List[WorkTypeBreakdownItem] = Field(default_factory=list, description="Work type breakdown data")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class InventoryByMarketRequest(BaseModel):
    """Request model for inventory by market API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets to display")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "lob": ["Commercial", "Medicare", "Medicaid"],
                "staffing_category": ["F", "CB Prevention-ESRD", "CB Prevention", "GBD MCARE-Disputes (NextGen)", "CB-Claim Edits", "GBD MCARE-DHP (Prevention E&I)", "GBD MCARE-Rx E/I (eCob Intakes)", "CB Newborn-Claim Edits", "GBD CAID-Disputes(NextGen)", "CB-Inquiries", "GBD MCARE-Inquiries", "CB Prevention-eCAQH", "CB Prevention-Prevention", "CB Newborn-eCAQH (Prevention)", "GBD CAID-Claim Edits", "GBD MCARE-Rx Prevention", "GBD CAID-Vendor", "GBD CAID-Inquiries", "CB Prevention-HEW", "CB Newborn-Inquiries"],
                "work_type": ["CIW", "eCAQH", "HEW"],
                "manager": ["ROSETSC", "SANTICH", "HARPEDN", "MEYERCH"],
                "market": ["GA", "FL", "TX", "NC"],
                "funding_model": ["ASO", "Fully Insured"]
            }
        }


class MarketInventoryItem(BaseModel):
    """Individual market inventory item."""
    MARKET: str = Field(..., description="Market name")
    CASE_COUNT: int = Field(..., description="Number of cases")

    @property
    def market(self) -> str:
        return self.MARKET

    @property
    def inventory_count(self) -> int:
        return self.CASE_COUNT


class InventoryByMarketResponse(BaseModel):
    """Response model for inventory by market API."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: List[MarketInventoryItem] = Field(default_factory=list, description="Market inventory data")
    total_count: int = Field(..., description="Total count of all cases")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Trend Analysis Models
# =============================================================================

class TrendAnalysisRequest(BaseModel):
    """Request model for trend analysis API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "lob": ["Commercial", "Medicare", "Medicaid"],
                "staffing_category": ["F", "CB Prevention-ESRD", "CB Prevention", "GBD MCARE-Disputes (NextGen)", "CB-Claim Edits", "GBD MCARE-DHP (Prevention E&I)", "GBD MCARE-Rx E/I (eCob Intakes)", "CB Newborn-Claim Edits", "GBD CAID-Disputes(NextGen)", "CB-Inquiries", "GBD MCARE-Inquiries", "CB Prevention-eCAQH", "CB Prevention-Prevention", "CB Newborn-eCAQH (Prevention)", "GBD CAID-Claim Edits", "GBD MCARE-Rx Prevention", "GBD CAID-Vendor", "GBD CAID-Inquiries", "CB Prevention-HEW", "CB Newborn-Inquiries"],
                "work_type": ["CIW", "eCAQH", "HEW"]
            }
        }


class TrendAnalysisResponse(BaseModel):
    """Response model for trend analysis API."""
    status: str = Field(..., description="Status of the request (success/error)")
    summary: str = Field(..., description="Trend analysis summary")
    trend_direction: Optional[str] = Field(None, description="Overall trend direction")
    recommendation: Optional[str] = Field(None, description="Recommended system action")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Filter List API Models
# =============================================================================

class WorkforceIQLOBListResponse(BaseModel):
    """Response model for Workforce IQ LOB list."""
    status: str = Field(..., description="Status of the request (success/error)")
    lobs: List[str] = Field(default=[], description="List of Line of Business values")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ManagerItem(BaseModel):
    """Individual manager item."""
    manager_id: str = Field(..., description="Manager ID")
    manager_name: str = Field(..., description="Manager display name")


class WorkforceIQManagerListResponse(BaseModel):
    """Response model for Workforce IQ Manager list."""
    status: str = Field(..., description="Status of the request (success/error)")
    managers: List[ManagerItem] = Field(default=[], description="List of managers")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class StaffingCategoryItem(BaseModel):
    """Individual staffing category item."""
    category_id: str = Field(..., description="Staffing category ID")
    category_name: str = Field(..., description="Staffing category display name")


class WorkforceIQStaffingCategoryListResponse(BaseModel):
    """Response model for Workforce IQ Staffing Category list."""
    status: str = Field(..., description="Status of the request (success/error)")
    staffing_categories: List[StaffingCategoryItem] = Field(default=[], description="List of staffing categories")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class StaffingCategoryWithSubcategories(BaseModel):
    """Staffing category with subcategories structure."""
    flag: bool = Field(..., description="Indicates if this category type has sub-categories")
    category_value: List[str] = Field(default=[], description="List of subcategory values for this category type")


class WorkforceIQStaffingCategorySubcategoriesResponse(BaseModel):
    """Response model for Workforce IQ Staffing Category with subcategories."""
    status: str = Field(..., description="Status of the request (success/error)")
    staffing_categories: Dict[str, StaffingCategoryWithSubcategories] = Field(
        default={}, 
        description="Dictionary of staffing categories where key is category_type_value and value contains flag and subcategory list"
    )
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class WorkTypeItem(BaseModel):
    """Individual work type item."""
    work_type_id: str = Field(..., description="Work type ID")
    work_type_name: str = Field(..., description="Work type display name")


class WorkforceIQWorkTypeListResponse(BaseModel):
    """Response model for Workforce IQ Work Type list."""
    status: str = Field(..., description="Status of the request (success/error)")
    work_types: List[WorkTypeItem] = Field(default=[], description="List of work types")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class MarketItem(BaseModel):
    """Individual market item."""
    market_id: str = Field(..., description="Market ID")
    market_name: str = Field(..., description="Market display name")


class WorkforceIQMarketListResponse(BaseModel):
    """Response model for Workforce IQ Market list."""
    status: str = Field(..., description="Status of the request (success/error)")
    markets: List[MarketItem] = Field(default=[], description="List of markets")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class FundingModelItem(BaseModel):
    """Individual funding model item."""
    funding_model_id: str = Field(..., description="Funding model ID/code")
    funding_model_name: str = Field(..., description="Funding model display name")


class WorkforceIQFundingModelListResponse(BaseModel):
    """Response model for Workforce IQ Funding Model list."""
    status: str = Field(..., description="Status of the request (success/error)")
    funding_models: List[FundingModelItem] = Field(default=[], description="List of funding models")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")# =============================================================================
# Staffing Core Models
# =============================================================================

class StaffingCoreRequest(BaseModel):
    """Request model for Staffing Core API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    grouping_level: Optional[str] = Field("monthly", description="Aggregation level: daily, weekly, monthly, quarterly, yearly")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "start_date": "2026-01-01",
                "end_date": "2026-06-30",
                "grouping_level": "monthly",
                "lob": ["Commercial", "Medicare"],
                "staffing_category": ["F", "CB Prevention-ESRD", "CB Prevention", "GBD MCARE-Disputes (NextGen)", "CB-Claim Edits", "GBD MCARE-DHP (Prevention E&I)", "GBD MCARE-Rx E/I (eCob Intakes)", "CB Newborn-Claim Edits", "GBD CAID-Disputes(NextGen)", "CB-Inquiries", "GBD MCARE-Inquiries", "CB Prevention-eCAQH", "CB Prevention-Prevention", "CB Newborn-eCAQH (Prevention)", "GBD CAID-Claim Edits", "GBD MCARE-Rx Prevention", "GBD CAID-Vendor", "GBD CAID-Inquiries", "CB Prevention-HEW", "CB Newborn-Inquiries"],
                "work_type": ["CIW", "eCAQH"],
                "manager": ["ROSETSC", "SANTICH"],
                "market": ["GA", "FL"],
                "funding_model": ["ASO", "Fully Insured"]
            }
        }


class StaffingCoreDataPoint(BaseModel):
    """Individual staffing data point for a period."""
    GROUPING_LEVEL: str = Field(..., description="Aggregation level used")
    PERIOD_DATE: Union[str, datetime] = Field(..., description="Period date")
    PERIOD_LABEL: str = Field(..., description="Formatted period label")
    REQ_FTE: Optional[float] = Field(None, description="Required FTE count")
    AVAIL_FTE: Optional[float] = Field(None, description="Available FTE count")
    ACTUAL_FTE: Optional[float] = Field(None, description="Actual FTE count")
    LOAN_FTE: Optional[float] = Field(None, description="Loon FTE count")
    PROJECTED_FTE: Optional[float] = Field(None, description="Projected FTE count")
    ACTUAL_VS_PROJECTION_VARIANCE: Optional[float] = Field(None, description="Variance between Actual and Projected FTE")
    REQUIRED_VS_PROJECTION_VARIANCE: Optional[float] = Field(None, description="Variance between Required and Projected FTE")

    @field_validator('PERIOD_DATE', mode='before')
    @classmethod
    def convert_datetime_to_string(cls, v):
        """Convert datetime objects to ISO format strings."""
        if isinstance(v, datetime):
            return v.isoformat()
        return v

    @property
    def required_fte(self) -> Optional[float]:
        return self.REQ_FTE

    @property
    def available_fte(self) -> Optional[float]:
        return self.AVAIL_FTE

    @property
    def actual_fte(self) -> Optional[float]:
        return self.ACTUAL_FTE

    @property
    def loan_fte(self) -> Optional[float]:
        return self.LOAN_FTE

    @property
    def projected_fte(self) -> Optional[float]:
        return self.PROJECTED_FTE


class StaffingCoreResponse(BaseModel):
    """Response model for Staffing Core API."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: List[StaffingCoreDataPoint] = Field(default_factory=list, description="Staffing FTE trend data")
    period_count: int = Field(..., description="Number of periods returned")
    actual_vs_projection_avg: Optional[float] = Field(None, description="Average Actual vs Projection variance percentage")
    required_vs_projection_avg: Optional[float] = Field(None, description="Average Required vs Projection variance percentage")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



# =============================================================================
# Header KPIs Models
# =============================================================================

class WorkforceIQHeaderKPIsRequest(BaseModel):
    """Request model for Workforce IQ Header KPIs."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for caching (auto-generated if not provided)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "lob": ["Commercial", "Medicare"],
                "staffing_category": ["Other - COB"],
                "work_type": ["CIW", "eCAQH"],
                "manager": ["ROSETSC", "SANTICH"],
                "market": ["GA", "FL"],
                "funding_model": ["ASO"]
            }
        }


class WorkforceIQHeaderKPIsResponse(BaseModel):
    """Response model for Workforce IQ Header KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    required_fte: str = Field(default="-", description="Required FTE count")
    actual_fte: str = Field(default="-", description="Actual FTE count")
    staff_utilization_pct: str = Field(default="-", description="Staff utilization percentage")
    cycle_time_per_fte: str = Field(default="-", description="Average cycle time per FTE")
    capacity_per_fte: str = Field(default="-", description="Capacity per FTE")
    backlog_volume: str = Field(default="-", description="Current backlog volume")
    days_work_on_hand: str = Field(default="-", description="Days of work on hand")
    avg_resolved_per_day: str = Field(default="-", description="Average items resolved per day")
    net_inventory_change: str = Field(default="-", description="Net inventory change")
    sla_risk_pct: str = Field(default="-", description="SLA risk percentage")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Membership KPIs Models
# =============================================================================

class WorkforceIQMembershipKPIsRequest(BaseModel):
    """Request model for Workforce IQ Membership KPIs."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for caching (auto-generated if not provided)")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "lob": ["Commercial", "Medicare"],
                "staffing_category": ["Other - COB"],
                "work_type": ["CIW", "eCAQH"],
                "manager": ["ROSETSC", "SANTICH"],
                "market": ["GA", "FL"],
                "funding_model": ["ASO"]
            }
        }


class WorkforceIQMembershipKPIsResponse(BaseModel):
    """Response model for Workforce IQ Membership KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    actual_membership: str = Field(default="-", description="Actual membership count")
    projected_membership: str = Field(default="-", description="Projected membership count")
    variance_count: str = Field(default="-", description="Variance count")
    variance_pct: str = Field(default="-", description="Variance percentage")
    demand_utilization: str = Field(default="-", description="Demand utilization percentage")
    utilization_variance: str = Field(default="-", description="Utilization variance percentage")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Actual vs Projected Membership Models
# =============================================================================

class ActualVsProjectedMembershipRequest(BaseModel):
    """Request model for actual vs projected membership trend API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for Redis caching")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    grouping_level: Optional[str] = Field("monthly", description="Aggregation level: monthly, quarterly, yearly")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "session_id": "abc123xyz",
                "start_date": "2026-01-01",
                "end_date": "2026-06-30",
                "grouping_level": "monthly",
                "lob": ["Commercial", "Medicare"]
            }
        }


class ActualVsProjectedMembershipDataPoint(BaseModel):
    """Individual data point for actual vs projected membership chart."""
    GROUPING_LEVEL: str = Field(..., description="Aggregation level used")
    PERIOD_DATE: Union[str, datetime] = Field(..., description="Period date")
    PERIOD_LABEL: str = Field(..., description="Formatted period label (e.g., '2026-Q2', 'Jan 2026')")
    ACTUAL_MEMBERSHIP: Optional[float] = Field(None, description="Actual membership count")
    PROJECTED_MEMBERSHIP: Optional[float] = Field(None, description="Projected membership count")
    ACTUAL_MEMBERSHIP_FORMATTED: Optional[str] = Field(None, description="Actual membership formatted as millions (e.g., '27.0M')")
    PROJECTED_MEMBERSHIP_FORMATTED: Optional[str] = Field(None, description="Projected membership formatted as millions (e.g., '28.5M')")
    VARIANCE_GAP_PCT: Optional[float] = Field(None, description="Variance gap percentage")
    
    @field_validator('PERIOD_DATE', mode='before')
    @classmethod
    def convert_datetime_to_string(cls, v):
        """Convert datetime objects to ISO format strings."""
        if isinstance(v, datetime):
            return v.isoformat()
        return v


class ActualVsProjectedMembershipResponse(BaseModel):
    """Response model for actual vs projected membership trend API."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: List[ActualVsProjectedMembershipDataPoint] = Field(default_factory=list, description="Actual vs projected membership trend data")
    period_count: int = Field(..., description="Number of periods returned")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Capacity KPIs Models
# =============================================================================

class WorkforceIQCapacityKPIsRequest(BaseModel):
    """Request model for Workforce IQ Capacity KPIs."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    session_id: Optional[str] = Field(None, description="Session ID for Redis caching")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    manager: Optional[List[str]] = Field(None, description="List of manager IDs")
    market: Optional[List[str]] = Field(None, description="List of markets")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "persona": "director",
                "session_id": "abc123xyz",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "lob": ["Commercial", "Medicare"],
                "staffing_category": ["Other - COB"],
                "work_type": ["CIW", "eCAQH"],
                "manager": ["ROSETSC", "SANTICH"],
                "market": ["GA", "FL"],
                "funding_model": ["ASO"]
            }
        }


class WorkforceIQCapacityKPIsResponse(BaseModel):
    """Response model for Workforce IQ Capacity KPIs."""
    status: str = Field(..., description="Status of the request (success/error)")
    capacity_per_fte: str = Field(default="-", description="Capacity per FTE")
    cases_per_hour: str = Field(default="-", description="Cases per hour")
    avg_fte_hours: str = Field(default="-", description="Average FTE hours")
    shrinkage_pct: str = Field(default="-", description="Shrinkage percentage")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# What-If Analysis Models
# =============================================================================
class WhatIfAnalysisRequest(BaseModel):
    """Request model for what-if analysis API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "staffing_category": ["Category1", "Category2"]
            }
        }

class MembershipByLOB(BaseModel):
    """Individual LOB membership data."""
    lob: str = Field(..., description="Line of Business")
    year: int = Field(..., description="Year of the data")
    month: str = Field(..., description="Month name")
    actual_membership: int = Field(..., description="Actual membership count")
    year_month: int = Field(..., description="Year-month code (YYYYMM)")

class WhatIfAnalysisResponse(BaseModel):
    """Response model for what-if analysis API."""
    status: str = Field(..., description="Response status: 'success' or 'error'")
    total_membership: str = Field(..., description="Sum of actual membership from latest available month (formatted as string)")
    demand_utilization_percentage: Optional[str] = Field(None, description="Current demand utilization percentage with % suffix (yesterday's receipts / latest membership)")
    standard_cases_per_hour: Optional[str] = Field(None, description="Standard productivity metric - cases completed per hour (yesterday's data, filtered by staffing category via crosswalk LOB mapping)")
    inventory_volume: Optional[str] = Field(None, description="Yesterday's backlog count - open work items at end of yesterday (filtered by staffing category via crosswalk LOB mapping)")
    avg_cycle_time: Optional[str] = Field(None, description="Average cycle time for yesterday's resolved items in 'X min Y sec' format (filtered by staffing category via crosswalk LOB mapping)")
    available_fte: Optional[str] = Field(None, description="Yesterday's available FTE count - unique employees with eCOB job profile from Workday history")
    loan_fte: Optional[str] = Field(None, description="Current loan FTE count - employees marked as on loan, filtered by staffing category type via crosswalk")
    current_shrinkage_percent: Optional[str] = Field(None, description="Current workforce shrinkage percentage for yesterday with % suffix (no filters applied)")
    out_of_sla_count: Optional[str] = Field(None, description="Count of work items currently out of SLA (past due date, filtered by staffing category via crosswalk LOB mapping)")
    out_of_sla_pct: Optional[str] = Field(None, description="Percentage of work items currently out of SLA with % suffix (filtered by staffing category via crosswalk LOB mapping)")
    message: str = Field(..., description="Response message describing the result")


# =============================================================================
# AI Coach Models
# =============================================================================
class WorkforceIQAICoachRequest(BaseModel):
    """Request model for WorkforceIQ AI Coach endpoint."""
    user_id: str = Field(..., description="Logged-in user ID")
    start_date: str = Field(..., description="Start date for analysis (YYYY-MM-DD)")
    end_date: str = Field(..., description="End date for analysis (YYYY-MM-DD)")
    persona: Optional[str] = Field(None, description="Optional Workforce persona override (director, manager, auditor_manager)")
    session_id: Optional[str] = Field(None, description="Session ID for caching")
    lob: Optional[List[str]] = Field(None, description="List of LOBs to filter by")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories to filter by")
    work_type: Optional[List[str]] = Field(None, description="List of work types to filter by")
    manager: Optional[List[str]] = Field(None, description="List of managers to filter by")
    market: Optional[List[str]] = Field(None, description="List of markets to filter by")
    funding_model: Optional[List[str]] = Field(None, description="List of funding models to filter by")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "session_id": "abc123xyz",
                "start_date": "2026-01-01",
                "end_date": "2026-05-31",
                "lob": ["Commercial", "Medicare"],
                "staffing_category": ["Other - COB"],
                "work_type": ["CIW", "eCAQH"],
                "manager": ["ROSETSC", "SANTICH"],
                "market": ["GA", "FL"],
                "funding_model": ["ASO"]
            }
        }


# =============================================================================
# Change Tracking Metrics Models
# =============================================================================
class ChangeTrackingMetricsRequest(BaseModel):
    """Request model for change tracking metrics API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504"
            }
        }

class ChangeTrackingMetricsResponse(BaseModel):
    """Response model for change tracking metrics API."""
    status: str = Field(..., description="Response status: 'success' or 'error'")
    kpis: List[str] = Field(..., description="List of KPIs for dropdown (Cycle Time, Audit Score %, Flip Rate Manual, Flip Rate Touchless, Non-Value Add %, Lead Accuracy)")
    savings_types: List[str] = Field(..., description="List of savings types for dropdown (CoC, SVRO, PIAI, Self-Funded)")
    message: str = Field(..., description="Response message describing the result")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ChangeTrackingFetchRequest(BaseModel):
    """Request model for change tracking data fetch API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    status: Optional[str] = Field(None, description="Filter by status: ACTIVE, ARCHIVE, or ALL (default: ALL)")
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "status": "ACTIVE"
            }
        }

class ChangeTrackingFetchResponse(BaseModel):
    """Response model for change tracking data fetch API."""
    status: str = Field(..., description="Response status: 'success' or 'error'")
    data: List[dict] = Field(..., description="Change tracking data from COB_AI_CHANGE_TRACKING table")
    message: str = Field(..., description="Response message describing the result")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


class ChangeTrackingAddRequest(BaseModel):
    """Request model for adding change tracking data."""
    initiative_name: str = Field(..., description="Initiative name (required)")
    initiative_year: str = Field(..., description="Initiative year (required)")
    savings_type: List[str] = Field(..., description="Savings types (multiple values, e.g., ['Hard Savings', 'Soft Savings'])")
    work_type: List[str] = Field(..., description="Work types (multiple values, e.g., ['HEW', 'Audit'])")
    kpi_metric: List[str] = Field(..., description="KPI metrics (multiple values, e.g., ['Cycle Time', 'Audit Score %'])")
    lob: List[str] = Field(..., description="Line of Business (multiple values, e.g., ['Medicaid', 'Commercial'])")
    total_estimated_value: float = Field(..., description="Total estimated value (required)")
    tracking_start_month: str = Field(..., description="Tracking start month YYYY-MM-DD (required)")
    change_description: str = Field(..., description="Change description (required)")
    status: str = Field(default="ACTIVE", description="Status (ACTIVE or ARCHIVE)")
    created_by: str = Field(..., description="User ID who created the record (required)")
    class Config:
        json_schema_extra = {
            "example": {
                "initiative_name": "Microtrend Policy Framework",
                "initiative_year": "2026",
                "savings_type": ["Hard Savings", "Soft Savings"],
                "work_type": ["HEW", "Audit"],
                "kpi_metric": ["Cycle Time", "Audit Score %"],
                "lob": ["Medicaid", "Commercial"],
                "total_estimated_value": 500000.0,
                "tracking_start_month": "2026-01-01",
                "change_description": "Develop centralized framework to manage policy documents",
                "status": "ACTIVE",
                "created_by": "AB77504"
            }
        }


class ChangeTrackingAddResponse(BaseModel):
    """Response model for change tracking add API."""
    status: str = Field(..., description="Response status: 'success' or 'error'")
    message: str = Field(..., description="Response message describing the result")
    initiative_id: Optional[int] = Field(None, description="ID of the created initiative")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")



class ChangeTrackingEditRequest(BaseModel):
    """Request model for fetching change tracking initiative for edit."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    initiative_id: int = Field(..., description="Initiative ID to fetch for editing")
    
    class Config:
        json_schema_extra = {
            "examples": [{
                "user_id": "AB77504",
                "initiative_id": 1
            }]
        }


class ChangeTrackingEditData(BaseModel):
    """Change tracking initiative details for edit form prefill."""
    initiative_id: int = Field(..., description="Initiative ID")
    initiative_name: str = Field(..., description="Initiative name")
    initiative_year: str = Field(..., description="Initiative year")
    savings_type: List[str] = Field(..., description="Savings types")
    work_type: List[str] = Field(..., description="Work types")
    kpi_metric: List[str] = Field(..., description="KPI metrics")
    lob: List[str] = Field(..., description="Lines of business")
    total_estimated_value: float = Field(..., description="Total estimated value")
    tracking_start_month: str = Field(..., description="Tracking start month")
    change_description: str = Field(..., description="Change description")
    status: str = Field(..., description="Initiative status")
    created_by: Optional[str] = Field(None, description="Created by user ID")
    created_ts: Optional[str] = Field(None, description="Created timestamp")
    updated_by: Optional[str] = Field(None, description="Updated by user ID")
    updated_ts: Optional[str] = Field(None, description="Updated timestamp")


class ChangeTrackingEditResponse(BaseModel):
    """Response model for retrieving a single change tracking initiative for edit."""
    status: str = Field(..., description="Response status: 'success' or 'error'")
    data: ChangeTrackingEditData = Field(..., description="Change tracking initiative details")
    message: str = Field(..., description="Response message describing the result")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# Change Tracking Manage (Status Update/Delete) Models
# =============================================================================
class ChangeTrackingManageRequest(BaseModel):
    """
    Request model for managing change tracking initiative status.
    
    This endpoint allows users to set initiative status to ACTIVE, ARCHIVE, or DELETE
    the record permanently from the database based on initiative_id.
    """
    action: str = Field(
        ..., 
        description="Action to perform: 'active' (set status to ACTIVE), 'archive' (set status to ARCHIVE), or 'delete' (permanently delete record)"
    )
    initiative_id: int = Field(
        ..., 
        description="Initiative ID to manage (required)"
    )
    user_id: str = Field(
        ..., 
        description="User ID performing the action (required for audit trail)"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "action": "archive",
                "initiative_id": 203,
                "user_id": "AB77504"
            }
        }


class ChangeTrackingManageResponse(BaseModel):
    """
    Response model for change tracking manage API.
    
    Returns the status of the operation along with the initiative_id and action performed.
    """
    status: str = Field(
        ..., 
        description="Response status: 'success' or 'error'"
    )
    message: str = Field(
        ..., 
        description="Descriptive message about the operation result"
    )
    initiative_id: Optional[int] = Field(
        None, 
        description="ID of the initiative that was managed"
    )
    action: str = Field(
        ..., 
        description="Action that was performed: 'active', 'archive', or 'delete'"
    )
    service: str = Field(
        default="idiscovery-cob-dashboard-service", 
        description="Service name"
    )
    
    class Config:
        json_schema_extra = {
            "examples": [
                {
                    "description": "Success response for setting status to ACTIVE",
                    "value": {
                        "status": "success",
                        "message": "Initiative ID 1 set to ACTIVE successfully",
                        "initiative_id": 1,
                        "action": "active",
                        "service": "idiscovery-cob-dashboard-service"
                    }
                },
                {
                    "description": "Success response for archiving",
                    "value": {
                        "status": "success",
                        "message": "Initiative ID 201 archived successfully",
                        "initiative_id": 201,
                        "action": "archive",
                        "service": "idiscovery-cob-dashboard-service"
                    }
                },
                {
                    "description": "Success response for deletion",
                    "value": {
                        "status": "success",
                        "message": "Initiative ID 101 deleted successfully",
                        "initiative_id": 101,
                        "action": "delete",
                        "service": "idiscovery-cob-dashboard-service"
                    }
                },
                {
                    "description": "Error response - initiative not found",
                    "value": {
                        "status": "error",
                        "message": "Initiative ID 999 not found",
                        "initiative_id": 999,
                        "action": "active",
                        "service": "idiscovery-cob-dashboard-service"
                    }
                }
            ]
        }


# =============================================================================
# Change Tracking Metrics Detail (Before/After) Models
# =============================================================================
class ChangeTrackingMetricsDetailRequest(BaseModel):
    """Request model for fetching change tracking metrics with Before/After values."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    initiative_id: int = Field(..., description="Initiative ID to fetch metrics for")
    
    class Config:
        json_schema_extra = {
            "examples": [{
                "user_id": "AB77504",
                "initiative_id": 1
            }]
        }


class MetricDetail(BaseModel):
    """Model for individual metric with Before and After values."""
    kpi_name: str = Field(..., description="KPI/Metric name (e.g., 'Cycle Time', 'Audit Score %')")
    before_value: Optional[float] = Field(None, description="Before value (90 days before tracking start date)")
    after_value: Optional[float] = Field(None, description="After value (tracking start date to current date)")
    improvement_rate: Optional[float] = Field(None, description="Improvement rate percentage")
    unit: str = Field(..., description="Unit of measurement (e.g., 'minutes', '%')")


class ChangeTrackingMetricsDetailResponse(BaseModel):
    """Response model for change tracking metrics detail API."""
    status: str = Field(..., description="Response status: 'success' or 'error'")
    initiative_id: int = Field(..., description="Initiative ID")
    initiative_name: str = Field(..., description="Initiative name")
    tracking_start_date: str = Field(..., description="Tracking start date (YYYY-MM-DD)")
    work_type: List[str] = Field(..., description="Work types for this initiative")
    lob: List[str] = Field(..., description="Lines of Business for this initiative")
    metrics: List[MetricDetail] = Field(..., description="List of metrics with Before/After values")
    message: str = Field(..., description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
    
    class Config:
        json_schema_extra = {
            "examples": [{
                "status": "success",
                "initiative_id": 1,
                "initiative_name": "Microtrend Policy Framework",
                "tracking_start_date": "2026-01-01",
                "work_type": ["CIW", "HEW"],
                "lob": ["Commercial", "Medicaid"],
                "metrics": [
                    {
                        "kpi_name": "Cycle Time",
                        "before_value": 14.01,
                        "after_value": 11.00,
                        "improvement_rate": 21.4,
                        "unit": "minutes"
                    },
                    {
                        "kpi_name": "Audit Score %",
                        "before_value": 92.5,
                        "after_value": 95.0,
                        "improvement_rate": 2.7,
                        "unit": "%"
                    }
                ],
                "message": "Metrics retrieved successfully",
                "service": "idiscovery-cob-dashboard-service"
            }]
        }


# =============================================================================
# Change Tracking Update Models
# =============================================================================
class ChangeTrackingUpdateRequest(BaseModel):
    """Request model for updating a change tracking initiative."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    initiative_id: int = Field(..., description="Initiative ID to update")
    initiative_name: str = Field(..., description="Initiative name")
    initiative_year: str = Field(..., description="Initiative year")
    savings_type: List[str] = Field(..., description="List of savings types")
    work_type: List[str] = Field(..., description="List of work types")
    kpi_metric: List[str] = Field(..., description="List of KPI metrics")
    lob: List[str] = Field(..., description="List of LOBs")
    total_estimated_value: float = Field(..., description="Total estimated value")
    tracking_start_month: str = Field(..., description="Tracking start month (YYYY-MM-DD)")
    change_description: str = Field(..., description="Change description")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "initiative_id": 123,
                "initiative_name": "Updated Initiative Name",
                "initiative_year": "2025",
                "savings_type": ["Hard Savings"],
                "work_type": ["eCAQH", "HEW"],
                "kpi_metric": ["Cycle Time", "Audit Score %"],
                "lob": ["Commercial", "Medicare"],
                "total_estimated_value": 150000.0,
                "tracking_start_month": "2025-01-01",
                "change_description": "Updated description"
            }
        }


class ChangeTrackingUpdateResponse(BaseModel):
    """Response model for updating a change tracking initiative."""
    status: str = Field(..., description="Response status: 'success' or 'error'")
    initiative_id: int = Field(..., description="Updated initiative ID")
    recalculated_metrics: bool = Field(..., description="Whether metrics were recalculated")
    message: str = Field(..., description="Response message")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "success",
                "initiative_id": 123,
                "recalculated_metrics": True,
                "message": "Change tracking initiative updated successfully. Metrics recalculated due to KPI/Work Type/Date changes."
            }
        }


# =============================================================================
# Change Tracking Trend Line Models
# =============================================================================
class ChangeTrackingTrendRequest(BaseModel):
    """Request model for change tracking trend line API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: str = Field(..., description="Start date for trend analysis (YYYY-MM-DD)")
    end_date: str = Field(..., description="End date for trend analysis (YYYY-MM-DD)")
    work_type: List[str] = Field(..., description="List of work types to filter by")
    kpi_metrics: List[str] = Field(..., description="List of KPI metrics to calculate")
    time_period: str = Field(..., description="Time period granularity: 'monthly', 'weekly', or 'yearly'")
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2025-01-01",
                "end_date": "2025-12-31",
                "work_type": ["eCAQH", "HEW", "CIW"],
                "kpi_metrics": ["Cycle Time", "Audit Score %", "Non-Value Add %", "Lead Accuracy"],
                "time_period": "monthly"
            }
        }


class TrendDataPoint(BaseModel):
    """Individual data point in the trend line."""
    period: str = Field(..., description="Time period label (e.g., '2025-01', '2025-W01', '2025')")
    period_start: str = Field(..., description="Period start date (YYYY-MM-DD)")
    period_end: str = Field(..., description="Period end date (YYYY-MM-DD)")
    cycle_time: Optional[float] = Field(None, description="Average cycle time in minutes")
    audit_score_pct: Optional[float] = Field(None, description="Average audit score percentage")
    flip_rate_manual: Optional[float] = Field(None, description="Manual flip rate percentage")
    flip_rate_touchless: Optional[float] = Field(None, description="Touchless flip rate percentage")
    non_value_add_pct: Optional[float] = Field(None, description="Non-value add percentage")
    lead_accuracy_pct: Optional[float] = Field(None, description="Lead accuracy percentage")
    cycle_time_cases: int = Field(0, description="Number of cases for cycle time calculation")
    audit_cases: int = Field(0, description="Number of audit cases")
    flip_rate_manual_cases: int = Field(0, description="Number of manual cases for flip rate calculation")
    flip_rate_touchless_cases: int = Field(0, description="Number of touchless cases for flip rate calculation")
    non_value_add_cases: int = Field(0, description="Number of cases for non-value add calculation")
    lead_accuracy_cases: int = Field(0, description="Number of cases for lead accuracy calculation")


class ChangeTrackingTrendResponse(BaseModel):
    """Response model for change tracking trend line API."""
    status: str = Field(..., description="Response status: 'success' or 'error'")
    time_period: str = Field(..., description="Time period granularity used")
    start_date: str = Field(..., description="Start date of analysis")
    end_date: str = Field(..., description="End date of analysis")
    work_types: List[str] = Field(..., description="Work types included in analysis")
    kpi_metrics: List[str] = Field(..., description="KPI metrics calculated")
    data: List[TrendDataPoint] = Field(..., description="Trend data points")
    message: str = Field(..., description="Response message")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "success",
                "time_period": "monthly",
                "start_date": "2025-01-01",
                "end_date": "2025-12-31",
                "work_types": ["eCAQH", "HEW", "CIW"],
                "kpi_metrics": ["Cycle Time", "Audit Score %", "Non-Value Add %"],
                "data": [
                    {
                        "period": "2025-01",
                        "period_start": "2025-01-01",
                        "period_end": "2025-01-31",
                        "cycle_time": 9.8,
                        "audit_score_pct": 99.2,
                        "flip_rate_manual": None,
                        "flip_rate_touchless": None,
                        "non_value_add_pct": 54.5,
                        "lead_accuracy_pct": 78.2,
                        "cycle_time_cases": 3500,
                        "audit_cases": 350,
                        "flip_rate_manual_cases": 0,
                        "flip_rate_touchless_cases": 0,
                        "non_value_add_cases": 3500,
                        "lead_accuracy_cases": 3200
                    }
                ],
                "message": "Trend data retrieved successfully"
            }
        }


# =============================================================================
# IRP Projection Models
# =============================================================================

class IRPProjectionRequest(BaseModel):
    """Request model for IRP Projection API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    start_date: str = Field(..., description="Start date in YYYY-MM-DD format (required)")
    end_date: str = Field(..., description="End date in YYYY-MM-DD format (required)")
    grouping_type: Optional[str] = Field("daily", description="Grouping type: daily, weekly, monthly, quarterly, yearly")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "start_date": "2026-06-01",
                "end_date": "2026-06-23",
                "grouping_type": "daily",
                "lob": [
                    "Commercial",
                    "EGR",
                    "KCP",
                    "CrossOver",
                    "None",
                    "Medicaid",
                    "MMP",
                    "SUP",
                    "MedSupp",
                    "Medicare"
                ],
                "staffing_category": [
                    "CB-Claim Edits",
                    "CB-Inquiries",
                    "F",
                    "CB Newborn-Claim Edits",
                    "CB Newborn-Inquiries"
                ],
                "work_type": [
                    "eCAQH",
                    "HEW",
                    "CIW"
                ]
            }
        }


class IRPProjectionDataPoint(BaseModel):
    """Individual IRP projection data point for a period."""
    date: Union[str, datetime] = Field(..., description="Date of the projection")
    total_work: Optional[int] = Field(None, description="Total work items")
    sla_due: Optional[int] = Field(None, description="SLA due items")
    req_fte: Optional[int] = Field(None, description="Required FTE")
    avail_fte: Optional[int] = Field(None, description="Available FTE")
    total_production: Optional[int] = Field(None, description="Total production count")
    prod_applied_to_sla: Union[int, str, None] = Field(None, description="Production applied to SLA (int or 'N/A' for projections)")
    out_of_sla: Union[int, str, None] = Field(None, description="Out of SLA items (int or 'N/A' for projections)")
    fte_gap: Optional[int] = Field(None, description="FTE gap")
    overtime_estimate: Union[int, str, None] = Field(None, description="Overtime estimate (string representation)")
    dwoh: Optional[int] = Field(None, description="Days of work on hand (DWOH)")


class IRPProjectionResponse(BaseModel):
    """Response model for IRP Projection API."""
    status: str = Field(..., description="Status of the request (success/error)")
    data: List[IRPProjectionDataPoint] = Field(default_factory=list, description="IRP projection data")
    record_count: int = Field(..., description="Number of records returned")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# IRP Total Work Drilldown Models
# =============================================================================

class TotalWorkDrilldownRequest(BaseModel):
    """Request model for Total Work Drilldown API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    selected_date: str = Field(..., description="Selected date from IRP table (format depends on grouping_type)")
    start_date: Optional[str] = Field(None, description="Start date for drill-down period (YYYY-MM-DD)")
    end_date: Optional[str] = Field(None, description="End date for drill-down period (YYYY-MM-DD)")
    grouping_type: Optional[str] = Field("daily", description="Grouping type from parent table: daily, weekly, monthly, quarterly, yearly")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    page: int = Field(1, description="Page number for pagination", ge=1)
    page_size: int = Field(50, description="Number of records per page", ge=1, le=1000)

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "selected_date": "5/1/2026",
                "start_date": "2026-05-01",
                "end_date": "2026-05-01",
                "grouping_type": "daily",
                "lob": ["Commercial", "CrossOver", "MMP", "EGR", "MedSupp", "Medicare", "KCP", "Medicaid", "GRS", "None", "INT", "SUP"],
                "staffing_category": ["CB-Claim Edits", "CB-Inquiries", "F", "CB Newborn-Claim Edits", "CB Newborn-Inquiries", "GBD CAID-Claim Edits", "GBD CAID-Disputes(NextGen)", "GBD CAID-Inquiries", "GBD CAID-Vendor", "GBD MCARE-Disputes (NextGen)", "GBD MCARE-Inquiries", "GBD MCARE-Rx E/I (eCob Intakes)"],
                "work_type": ["-Dup", "CAQH WGS", "Adhoc Routine", "Adhoc Special-Dup", "CCERT", "ACES", "OHI Request", "Other", "ClaimsWorkstation", "WGS IQT-Dup", "Prevention", "Vendor", "eCAQH-Dup", "ProActive", "ASPEN", "Facets Pend", "Newborn", "Mailbox Request", "eCAQH", "HEW-Dup", "WGS IQT", "Compass", "Correspondence", "New Born", "CompassRx", "ASPEN-Dup", "SPECIAL PROJECT", "SharePoint Intake", "None", "eCAQH Validation", "DAVITA-Dup", "CAQH", "CCERT A2A", "Solution Central-Dup", "Facets", "Prevention-Dup", "MD Concierge", "Medisys", "ESRD", "CAQH GBD", "CIW", "eCAQH Validation-Dup", "Central Facets Intakes", "CIW-Dup", "WATCHLIST_FU_SM_COB", "MN Faxing File", "CIW GB Medicaid", "Adhoc Routine-Dup", "Adhoc Special", "NASCO Claim Edits", "eCOB Intake", "DHP Monthly", "BPM- GA Misroutes", "Solution Central", "Adhoc Letter", "IRU", "Audit Correction", "HEW", "LEGACY PROJECT", "BPM Filenet", "WGS Daily Inv", "HMSWGS FallOut", "NextGen", "eCOB Intake-Dup", "NASCO Inquiry", "DAVITA", "Member Portal", "ClaimsRequest", "Member Portal-Dup", "GBD RX FALLOUT REPORT", "Doc Triage"],
                "page": 1,
                "page_size": 50
            }
        }


# What-If SLA Impact Models
# =============================================================================

class WhatIfCurrentState(BaseModel):
    """Current state KPIs from What-If Analysis."""
    total_membership: float = Field(..., description="Total membership count")
    demand_utilization_percentage: float = Field(..., description="Demand utilization percentage")
    standard_cases_per_hour: float = Field(..., description="Standard cases per hour")
    inventory_volume: int = Field(..., description="Current inventory/backlog volume")
    avg_cycle_time_minutes: float = Field(
        ...,
        alias="avg_cycle_time",
        description="Average cycle time in minutes. Accepts a float or a string like '12 min 30 sec' / '12m 30s'."
    )
    available_fte: float = Field(..., description="Available FTE count")
    loan_fte: float = Field(..., description="Loan FTE count")
    current_shrinkage_percent: float = Field(..., description="Current shrinkage percentage")

    model_config = {"populate_by_name": True}

    @field_validator('avg_cycle_time_minutes', mode='before')
    @classmethod
    def parse_cycle_time(cls, v):
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            v = v.strip()
            # Plain numeric string e.g. "12.5"
            try:
                return float(v)
            except ValueError:
                pass
            # Formats: "12 min 30 sec", "12m 30s", "12 min", "30 sec", "1h 12m"
            minutes = 0.0
            hours_match = re.search(r'(\d+(?:\.\d+)?)\s*h(?:r|our)?s?', v, re.IGNORECASE)
            mins_match = re.search(r'(\d+(?:\.\d+)?)\s*m(?:in(?:ute)?s?)?(?!\S)', v, re.IGNORECASE)
            secs_match = re.search(r'(\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?', v, re.IGNORECASE)
            if hours_match:
                minutes += float(hours_match.group(1)) * 60
            if mins_match:
                minutes += float(mins_match.group(1))
            if secs_match:
                minutes += float(secs_match.group(1)) / 60
            if minutes > 0:
                return round(minutes, 4)
            raise ValueError(
                f"Cannot parse avg_cycle_time value '{v}'. "
                "Expected a number or a string like '12 min 30 sec', '12m 30s', or '12.5'."
            )
        raise ValueError(f"avg_cycle_time_minutes must be a number or time string, got {type(v).__name__}")

    @field_validator(
        'total_membership',
        'demand_utilization_percentage',
        'standard_cases_per_hour',
        'inventory_volume',
        'available_fte',
        'loan_fte'
    )
    @classmethod
    def validate_non_negative_metrics(cls, v):
        if v < 0:
            raise ValueError("What-If current state metrics must be non-negative")
        return v

    @field_validator('avg_cycle_time_minutes')
    @classmethod
    def validate_cycle_time(cls, v):
        if v <= 0:
            raise ValueError("avg_cycle_time must be greater than 0 minutes")
        return v

    @field_validator('current_shrinkage_percent')
    @classmethod
    def validate_shrinkage_percent(cls, v):
        if v < 0 or v > 100:
            raise ValueError("current_shrinkage_percent must be between 0 and 100")
        return v

    @model_validator(mode="after")
    def validate_fte_consistency(self):
        if self.loan_fte > self.available_fte:
            raise ValueError("loan_fte cannot exceed available_fte")
        return self


class WhatIfScenarioChanges(BaseModel):
    """User-defined editable scenario deltas for Workforce What-If Analysis."""
    fte_change: float = Field(0, ge=-500, le=500, description="FTE change (e.g., +3, -2)")
    loan_fte_change: float = Field(0, ge=-500, le=500, description="Loan FTE change (e.g., -2, +1)")
    membership_change: int = Field(0, ge=-100000000, le=100000000, description="Membership change (e.g., -250000, +500000)")
    inventory_volume_change: int = Field(0, ge=-10000000, le=10000000, description="Inventory volume change (e.g., -5000, +2000)")
    cycle_time_change: float = Field(0, ge=-480, le=480, description="Cycle time change in minutes (e.g., -3, +2)")
    shrinkage_change: float = Field(0, ge=-100, le=100, description="Shrinkage % change (e.g., +3, -2)")


class WhatIfSLAImpactRequest(BaseModel):
    """Request model for What-If SLA Impact API."""
    user_id: str = Field(..., description="Logged-in user ID (required)")
    staffing_category: List[str] = Field(..., description="Staffing categories to analyze. Filter only; not an editable scenario metric.")
    current_state: WhatIfCurrentState = Field(
        ...,
        description="Current frontend-visible KPIs from What-If Analysis used as the baseline state."
    )
    scenario_changes: WhatIfScenarioChanges = Field(
        ..., 
        description="User-defined editable scenario inputs for FTE, loan FTE, membership, inventory volume, cycle time, and shrinkage. Accepts delta fields (for example `loan_fte_change`) and absolute projected values (for example `loan_fte`) which are normalized against `current_state`."
    )
    session_id: Optional[str] = Field(None, description="Session ID for caching")

    @model_validator(mode="before")
    @classmethod
    def normalize_absolute_scenario_values(cls, data):
        if not isinstance(data, dict):
            return data

        current_state = data.get("current_state")
        scenario_changes = data.get("scenario_changes")
        if not isinstance(current_state, dict) or not isinstance(scenario_changes, dict):
            return data

        normalized_scenario_changes = dict(scenario_changes)

        for absolute_key, delta_key in (
            ("available_fte", "fte_change"),
            ("loan_fte", "loan_fte_change"),
            ("total_membership", "membership_change"),
            ("inventory_volume", "inventory_volume_change"),
            ("current_shrinkage_percent", "shrinkage_change"),
        ):
            if delta_key in normalized_scenario_changes or absolute_key not in normalized_scenario_changes:
                continue

            baseline_value = current_state.get(absolute_key)
            absolute_value = normalized_scenario_changes.get(absolute_key)
            if baseline_value is None or absolute_value is None:
                continue

            normalized_scenario_changes[delta_key] = absolute_value - baseline_value

        if "cycle_time_change" not in normalized_scenario_changes:
            cycle_absolute_key = None
            if "avg_cycle_time_minutes" in normalized_scenario_changes:
                cycle_absolute_key = "avg_cycle_time_minutes"
            elif "avg_cycle_time" in normalized_scenario_changes:
                cycle_absolute_key = "avg_cycle_time"

            if cycle_absolute_key:
                baseline_cycle = current_state.get("avg_cycle_time_minutes", current_state.get("avg_cycle_time"))
                absolute_cycle = normalized_scenario_changes.get(cycle_absolute_key)
                if baseline_cycle is not None and absolute_cycle is not None:
                    normalized_scenario_changes["cycle_time_change"] = (
                        WhatIfCurrentState.parse_cycle_time(absolute_cycle)
                        - WhatIfCurrentState.parse_cycle_time(baseline_cycle)
                    )

        normalized_data = dict(data)
        normalized_data["scenario_changes"] = normalized_scenario_changes
        return normalized_data

    @field_validator('staffing_category')
    @classmethod
    def validate_staffing_category(cls, v):
        cleaned_values = [str(item).strip() for item in v if str(item).strip()]
        if not cleaned_values:
            raise ValueError("staffing_category must contain at least one non-empty value")
        return cleaned_values

    @model_validator(mode="after")
    def validate_projected_state(self):
        projected_membership = self.current_state.total_membership + self.scenario_changes.membership_change
        projected_available_fte = self.current_state.available_fte + self.scenario_changes.fte_change
        projected_loan_fte = self.current_state.loan_fte + self.scenario_changes.loan_fte_change
        projected_inventory_volume = self.current_state.inventory_volume + self.scenario_changes.inventory_volume_change
        projected_cycle_time = self.current_state.avg_cycle_time_minutes + self.scenario_changes.cycle_time_change
        projected_shrinkage = self.current_state.current_shrinkage_percent + self.scenario_changes.shrinkage_change
        projected_effective_fte = projected_available_fte - projected_loan_fte - (
            projected_available_fte * projected_shrinkage / 100
        )

        if projected_membership < 0:
            raise ValueError("Scenario results in negative total_membership")
        if projected_available_fte < 0:
            raise ValueError("Scenario results in negative available_fte")
        if projected_loan_fte < 0:
            raise ValueError("Scenario results in negative loan_fte")
        if projected_loan_fte > projected_available_fte:
            raise ValueError("Scenario results in loan_fte exceeding available_fte")
        if projected_inventory_volume < 0:
            raise ValueError("Scenario results in negative inventory_volume")
        if projected_cycle_time <= 0:
            raise ValueError("Scenario results in avg_cycle_time_minutes less than or equal to 0")
        if projected_shrinkage < 0 or projected_shrinkage > 100:
            raise ValueError("Scenario results in current_shrinkage_percent outside 0 to 100")
        if projected_effective_fte < 0:
            raise ValueError("Scenario results in negative effective_fte")

        return self

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "staffing_category": ["CB Prevention", "GBD MCARE-Disputes"],
                "current_state": {
                    "total_membership": 42000000,
                    "demand_utilization_percentage": 3.0,
                    "standard_cases_per_hour": 6.0,
                    "inventory_volume": 30000,
                    "avg_cycle_time_minutes": 15.0,
                    "available_fte": 106.0,
                    "loan_fte": 3.0,
                    "current_shrinkage_percent": 12.0
                },
                "scenario_changes": {
                    "fte_change": 3,
                    "loan_fte_change": -1,
                    "membership_change": 500000,
                    "inventory_volume_change": -2500,
                    "cycle_time_change": -3,
                    "shrinkage_change": 3
                },
                "session_id": "session_1775821614_abc123def"
            }
        }


class TotalWorkDrilldownRecord(BaseModel):
    """Individual Total Work drilldown record."""
    work_item: str = Field(..., description="Work item name/category")
    start_backlog: int = Field(..., description="Open items at start of period")
    receipt: int = Field(..., description="New items received during period")
    production: int = Field(..., description="Items resolved during period")
    end_backlog: int = Field(..., description="Open items at end of period")
    increase_decrease: int = Field(..., description="Change in backlog (End - Start)")


class TotalWorkDrilldownResponse(BaseModel):
    """Response model for Total Work Drilldown API."""
    status: str = Field(..., description="Status of the request")
    data: List[TotalWorkDrilldownRecord] = Field(default_factory=list, description="Drilldown records")
    page_info: dict = Field(..., description="Pagination information")
    total_count: int = Field(..., description="Total number of records")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# IRP Total Production Drilldown Models
# =============================================================================

class TotalProductionDrilldownRequest(BaseModel):
    """Request model for Total Production Drilldown API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    selected_date: str = Field(..., description="Selected date from IRP table (format depends on grouping_type)")
    start_date: Optional[str] = Field(None, description="Start date for drill-down period (YYYY-MM-DD)")
    end_date: Optional[str] = Field(None, description="End date for drill-down period (YYYY-MM-DD)")
    grouping_type: Optional[str] = Field("daily", description="Grouping type from parent table: daily, weekly, monthly, quarterly, yearly")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    page: int = Field(1, description="Page number for pagination", ge=1)
    page_size: int = Field(50, description="Number of records per page", ge=1, le=1000)

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "selected_date": "5/1/2026",
                "start_date": "2026-05-01",
                "end_date": "2026-05-01",
                "grouping_type": "daily",
                "lob": ["Commercial", "CrossOver", "MMP", "EGR", "MedSupp", "Medicare", "KCP", "Medicaid", "GRS", "None", "INT", "SUP"],
                "staffing_category": ["CB-Claim Edits", "CB-Inquiries", "F", "CB Newborn-Claim Edits", "CB Newborn-Inquiries", "GBD CAID-Claim Edits", "GBD CAID-Disputes(NextGen)", "GBD CAID-Inquiries", "GBD CAID-Vendor", "GBD MCARE-Disputes (NextGen)", "GBD MCARE-Inquiries", "GBD MCARE-Rx E/I (eCob Intakes)"],
                "work_type": ["-Dup", "CAQH WGS", "Adhoc Routine", "Adhoc Special-Dup", "CCERT", "ACES", "OHI Request", "Other", "ClaimsWorkstation", "WGS IQT-Dup", "Prevention", "Vendor", "eCAQH-Dup", "ProActive", "ASPEN", "Facets Pend", "Newborn", "Mailbox Request", "eCAQH", "HEW-Dup", "WGS IQT", "Compass", "Correspondence", "New Born", "CompassRx", "ASPEN-Dup", "SPECIAL PROJECT", "SharePoint Intake", "None", "eCAQH Validation", "DAVITA-Dup", "CAQH", "CCERT A2A", "Solution Central-Dup", "Facets", "Prevention-Dup", "MD Concierge", "Medisys", "ESRD", "CAQH GBD", "CIW", "eCAQH Validation-Dup", "Central Facets Intakes", "CIW-Dup", "WATCHLIST_FU_SM_COB", "MN Faxing File", "CIW GB Medicaid", "Adhoc Routine-Dup", "Adhoc Special", "NASCO Claim Edits", "eCOB Intake", "DHP Monthly", "BPM- GA Misroutes", "Solution Central", "Adhoc Letter", "IRU", "Audit Correction", "HEW", "LEGACY PROJECT", "BPM Filenet", "WGS Daily Inv", "HMSWGS FallOut", "NextGen", "eCOB Intake-Dup", "NASCO Inquiry", "DAVITA", "Member Portal", "ClaimsRequest", "Member Portal-Dup", "GBD RX FALLOUT REPORT", "Doc Triage"],
                "page": 1,
                "page_size": 50
            }
        }


class TotalProductionDrilldownRecord(BaseModel):
    """Individual Total Production drilldown record."""
    work_item: str = Field(..., description="Work item name/category")
    total_completed: int = Field(..., description="Total items completed/resolved")
    prod_applied_to_sla: int = Field(..., description="Production count applied to SLA")


class TotalProductionDrilldownResponse(BaseModel):
    """Response model for Total Production Drilldown API."""
    status: str = Field(..., description="Status of the request")
    data: List[TotalProductionDrilldownRecord] = Field(default_factory=list, description="Drilldown records")
    page_info: dict = Field(..., description="Pagination information")
    total_count: int = Field(..., description="Total number of records")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")


# =============================================================================
# IRP Out of SLA Drilldown Models
# =============================================================================

class OutOfSLADrilldownRequest(BaseModel):
    """Request model for Out of SLA Drilldown API."""
    user_id: Optional[str] = Field(None, description="Logged-in user ID")
    selected_date: str = Field(..., description="Selected date from IRP table (format depends on grouping_type)")
    start_date: Optional[str] = Field(None, description="Start date for drill-down period (YYYY-MM-DD)")
    end_date: Optional[str] = Field(None, description="End date for drill-down period (YYYY-MM-DD)")
    grouping_type: Optional[str] = Field("daily", description="Grouping type from parent table: daily, weekly, monthly, quarterly, yearly")
    lob: Optional[List[str]] = Field(None, description="List of Line of Business values")
    staffing_category: Optional[List[str]] = Field(None, description="List of staffing categories")
    work_type: Optional[List[str]] = Field(None, description="List of work types")
    page: int = Field(1, description="Page number for pagination", ge=1)
    page_size: int = Field(50, description="Number of records per page", ge=1, le=1000)

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "AB77504",
                "selected_date": "2026-06-01",
                "start_date": "2026-05-03",
                "end_date": "2026-06-10",
                "grouping_type": "daily",
                "lob": ["Commercial", "CrossOver", "MMP", "EGR", "MedSupp", "Medicare", "KCP", "Medicaid", "GRS", "None", "INT", "SUP"],
                "staffing_category": ["CB-Claim Edits", "CB-Inquiries", "F", "CB Newborn-Claim Edits", "CB Newborn-Inquiries", "GBD CAID-Claim Edits", "GBD CAID-Disputes(NextGen)", "GBD CAID-Inquiries", "GBD CAID-Vendor", "GBD MCARE-Disputes (NextGen)", "GBD MCARE-Inquiries", "GBD MCARE-Rx E/I (eCob Intakes)"],
                "work_type": ["-Dup", "CAQH WGS", "Adhoc Routine", "Adhoc Special-Dup", "CCERT", "ACES", "OHI Request", "Other", "ClaimsWorkstation", "WGS IQT-Dup", "Prevention", "Vendor", "eCAQH-Dup", "ProActive", "ASPEN", "Facets Pend", "Newborn", "Mailbox Request", "eCAQH", "HEW-Dup", "WGS IQT", "Compass", "Correspondence", "New Born", "CompassRx", "ASPEN-Dup", "SPECIAL PROJECT", "SharePoint Intake", "None", "eCAQH Validation", "DAVITA-Dup", "CAQH", "CCERT A2A", "Solution Central-Dup", "Facets", "Prevention-Dup", "MD Concierge", "Medisys", "ESRD", "CAQH GBD", "CIW", "eCAQH Validation-Dup", "Central Facets Intakes", "CIW-Dup", "WATCHLIST_FU_SM_COB", "MN Faxing File", "CIW GB Medicaid", "Adhoc Routine-Dup", "Adhoc Special", "NASCO Claim Edits", "eCOB Intake", "DHP Monthly", "BPM- GA Misroutes", "Solution Central", "Adhoc Letter", "IRU", "Audit Correction", "HEW", "LEGACY PROJECT", "BPM Filenet", "WGS Daily Inv", "HMSWGS FallOut", "NextGen", "eCOB Intake-Dup", "NASCO Inquiry", "DAVITA", "Member Portal", "ClaimsRequest", "Member Portal-Dup", "GBD RX FALLOUT REPORT", "Doc Triage"],
                "page": 1,
                "page_size": 50
            }
        }


class OutOfSLADrilldownRecord(BaseModel):
    """Individual Out of SLA drilldown record."""
    work_item: str = Field(..., description="Work item ID/number")
    priority: str = Field(..., description="Priority level (Instant, Immediate, Urgent, High, Medium, Low)")
    intake_source: str = Field(..., description="Intake source system")
    create_date_time: str = Field(..., description="Date and time when work item was created")
    elevance_created_date: str = Field(..., description="Elevance created date")
    assigned_by: str = Field(..., description="User currently assigned to the work item")
    pystatuswork: str = Field(..., description="Current status of the work item")


class OutOfSLADrilldownResponse(BaseModel):
    """Response model for Out of SLA Drilldown API."""
    status: str = Field(..., description="Status of the request")
    data: List[OutOfSLADrilldownRecord] = Field(default_factory=list, description="Drilldown records")
    page_info: dict = Field(..., description="Pagination information")
    total_count: int = Field(..., description="Total number of records")
    message: Optional[str] = Field(None, description="Response message")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")
class CurrentSLAMetrics(BaseModel):
    """Current SLA baseline metrics."""
    inventory_volume: int = Field(..., description="Total backlog/inventory volume")
    effective_fte: float = Field(..., description="Effective productive FTE")
    productive_hours_per_day: float = Field(..., description="Average productive hours per FTE per day")
    cases_per_hour: float = Field(..., description="Cases processed per hour")
    daily_throughput: int = Field(..., description="Daily processing throughput")
    daily_receipts: float = Field(..., description="Average daily receipts")
    net_throughput: float = Field(..., description="Net throughput (throughput - receipts)")
    days_to_clear: Optional[float] = Field(None, description="Days to clear backlog")
    sla_risk_inventory: int = Field(..., description="Number of items at SLA risk")
    sla_risk_pct: float = Field(..., description="Percentage of items at SLA risk")
    out_of_sla_inventory: int = Field(..., description="Number of items already out of SLA")
    out_of_sla_pct: float = Field(..., description="Percentage of items out of SLA")
    counts_by_sla: Optional[List[Dict[str, Any]]] = Field(None, description="Distribution of items by SLA bucket")


class ProjectedSLAMetrics(BaseModel):
    """Projected SLA metrics after scenario changes."""
    inventory_volume: int = Field(..., ge=0, description="Projected backlog/inventory volume after scenario changes")
    effective_fte: float = Field(..., ge=0, description="Projected effective productive FTE")
    productive_hours_per_day: float = Field(..., ge=0, description="Productive hours per FTE per day (same as current)")
    cases_per_hour: float = Field(..., ge=0, description="Projected cases per hour")
    daily_throughput: int = Field(..., ge=0, description="Projected daily throughput")
    daily_receipts: float = Field(..., ge=0, description="Daily receipts (same as current)")
    net_throughput: float = Field(..., description="Projected net throughput")
    days_to_clear: Optional[float] = Field(None, ge=0, description="Projected days to clear backlog")
    sla_risk_inventory: int = Field(..., ge=0, description="Projected items at SLA risk (may exceed current in worsening scenarios)")
    sla_risk_pct: float = Field(..., ge=0, description="Projected SLA risk percentage (may exceed 100% in worsening scenarios)")
    out_of_sla_inventory: int = Field(..., ge=0, description="Projected items out of SLA (may exceed current in worsening scenarios)")
    out_of_sla_pct: float = Field(..., ge=0, description="Projected out-of-SLA percentage (may exceed 100% in worsening scenarios)")


class SLAImpactAnalysis(BaseModel):
    """Impact analysis comparing current vs projected.

    All fields support negative values to represent worsening scenarios.
    Positive = improvement, negative = degradation.
    """
    throughput_increase: int = Field(..., description="Change in daily throughput (negative = decrease)")
    throughput_increase_pct: float = Field(..., description="Percentage change in throughput (negative = decrease)")
    items_saved_from_risk: int = Field(..., description="Items moved out of SLA risk (negative = more items at risk)")
    sla_risk_reduction_pct: float = Field(..., description="Percentage change in SLA risk (negative = risk increased)")
    time_saved_days: Optional[float] = Field(None, description="Days saved in clearing backlog (negative = slower, null = backlog clearance time is undefined because current or projected net throughput is non-positive)")
    out_of_sla_reduction: int = Field(..., description="Change in out-of-SLA items (negative = more items breached, bounded by visible inventory volume for UI consistency)")

    class Config:
        json_schema_extra = {
            "example": {
                "throughput_increase": 160,
                "throughput_increase_pct": 25.48,
                "items_saved_from_risk": 1923,
                "sla_risk_reduction_pct": 4.7,
                "time_saved_days": None,
                "out_of_sla_reduction": 7644,
            }
        }


class SuggestedAction(BaseModel):
    """A single AI-suggested workforce action."""
    action: str = Field(..., description="Specific action to take")
    priority: str = Field(..., description="Priority level: high, medium, or low")
    expected_impact: str = Field(..., description="Expected impact if action is taken")
    lever: str = Field(..., description="Which lever this action targets: fte, cycle_time, shrinkage, or process")
    scenario_projection: Optional[str] = Field(None, description="Optional: what-if projection if this lever is reversed or removed")


class WhatIfProjectedMetrics(BaseModel):
    """Slim projected and impact metrics for UI display cards."""
    projected_daily_throughput: int = Field(..., description="Projected daily throughput after scenario changes")
    projected_days_to_clear: Optional[float] = Field(None, description="Projected days to clear backlog")
    projected_sla_risk_pct: float = Field(..., description="Projected SLA risk percentage")
    projected_out_of_sla_pct: float = Field(..., description="Projected out-of-SLA percentage")
    throughput_increase: int = Field(..., description="Increase in daily throughput vs current")
    throughput_increase_pct: float = Field(..., description="Percentage increase in throughput")
    items_saved_from_risk: int = Field(..., description="Items saved from SLA risk")
    out_of_sla_reduction: int = Field(..., description="Reduction in out-of-SLA items")
    time_saved_days: Optional[float] = Field(None, description="Days saved in clearing backlog (null = backlog clearance time is undefined)")


class WhatIfPreviousScenarioComparison(BaseModel):
    throughput_change_vs_previous: int = Field(..., description="Difference in throughput increase vs previous scenario")
    sla_risk_reduction_pct_vs_previous: float = Field(..., description="Difference in SLA risk reduction percentage vs previous scenario")
    summary: str = Field(..., description="Plain-language comparison between the previous and current scenarios")

class WhatIfSLAImpactResponse(BaseModel):
    """Response model for What-If SLA Impact API."""
    status: str = Field(..., description="Status of the request (success/error)")
    message: str = Field(..., description="Response message")
    suggestions: str = Field(default="", description="Markdown-formatted scenario summary with four sections: ## Current Inventory Context, ## Previous Scenario, ## Updated Scenario, and ## Projected Results. Uses markdown headings and bullet lines without bold formatting.")
    recommendation_source: str = Field(default="llm", description="Recommendation source: llm or rule_based_fallback")
    previous_context_used: bool = Field(default=False, description="Whether a previous scenario was used for AI comparison context")
    previous_scenario_comparison: Optional[WhatIfPreviousScenarioComparison] = Field(None, description="Comparison of the current scenario vs the previous cached scenario")
    service: str = Field(default="idiscovery-cob-dashboard-service", description="Service name")

    class Config:
        json_schema_extra = {
            "example": {
                "status": "success",
                "message": "",
                "suggestions": "## Current Inventory Context\nCurrent inventory volume is 30,000 items. Historically, approximately 30% of inventory enters SLA risk status.\n\n## Previous Scenario\n- SLA Risk Inventory: 9,000 items\n- Available FTE: 106\n- Cycle Time: 15 min\n\n## Updated Scenario\n- Adding 3 FTE and reducing loan FTE from 3 to 2 improves core staffing support.\n- Reducing cycle time from 15 to 12 minutes and lowering inventory volume from 30,000 to 27,500 eases inventory pressure.\n- Shrinkage rises from 12% to 15%, which offsets part of the benefit.\n\n## Projected Results\n- Estimated SLA Risk Inventory: reduced from 9,000 to approximately 6,840 items\n- At-Risk Item Reduction: approximately 2,160 items\n- Faster projected processing helps slow inventory aging and reduces the share of work drifting deeper into backlog.\n- Backlog Clearance: Backlog clearance time remains undefined because backlog is currently growing and would continue to grow under this scenario.",
                "recommendation_source": "llm",
                "previous_context_used": False,
                "previous_scenario_comparison": {
                    "throughput_change_vs_previous": 120,
                    "sla_risk_reduction_pct_vs_previous": 0.8,
                    "summary": "Compared to the previous scenario, the current setup reduces more SLA risk and improves overall inventory pressure."
                },
                "service": "idiscovery-cob-dashboard-service"
            }
        }
