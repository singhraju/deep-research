from .interface import SecretHandlerInterface
from .handlers.os_handler import OSSecretHandler
from .handlers.vault_handler import VaultSecretHandler


class SecretHandlerFactory:
    """Factory for creating SecretHandlerInterface instances."""

    @staticmethod
    def get_handler(handler_type: str) -> SecretHandlerInterface:
        """Returns an instance of the specified secret handler."""
        if handler_type.lower() == "os":
            return OSSecretHandler()
        elif handler_type.lower() == "vault":
            return VaultSecretHandler()
        else:
            raise ValueError(f"Unknown secret handler type: {handler_type}")
