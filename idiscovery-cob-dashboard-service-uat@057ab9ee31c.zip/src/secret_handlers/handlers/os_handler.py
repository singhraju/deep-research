import os
from typing import Optional
from ..interface import SecretHandlerInterface


class OSSecretHandler(SecretHandlerInterface):
    """Retrieves secrets from environment variables."""

    def get_secret(self, key: str) -> Optional[str]:
        """Fetches the secret value from environment variables."""
        return os.getenv(key)
