import configparser
from typing import Optional
from ..interface import SecretHandlerInterface


class VaultSecretHandler(SecretHandlerInterface):
    """Retrieves secrets from a Vault instance."""

    def __init__(self):
        self.client = configparser.ConfigParser()

    def get_secret(self, key: str) -> Optional[str]:
        """Fetches the secret value from Vault."""
        vault_path = "/vault/secrets/creds"
        self.client.read(vault_path)
        try:
            return self.client.get("default", key)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return None
