from abc import ABC, abstractmethod
from typing import Optional


class SecretHandlerInterface(ABC):
    """Abstract interface for retrieving secrets."""

    @abstractmethod
    def get_secret(self, key: str) -> Optional[str]:
        """Retrieves a secret by its key."""
        pass
