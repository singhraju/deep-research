import logging
from db import SnowflakeConnectionManager
from snowflake.snowpark import Session
from tools.sql import *

logger = logging.getLogger(__name__)
connection_manager = SnowflakeConnectionManager()

def get_total_fuse_time_data(user_id: str, start_date: str, end_date: str, lob: str = None):
    """
    Get total system time for a user within a date range
    
    Args:
        user_id: User ID to query
        start_date: Start date in YYYYMMDD format
        end_date: End date in YYYYMMDD format
    
    Returns:
        Total fuse time as formatted string
    """
    logger.info(f"Fetching fuse time for user_id={user_id}, start_date={start_date}, end_date={end_date}")
    
    try:
        logger.info("Getting Snowflake session from connection manager")
        engine = connection_manager.get_engine()
        session = engine.connect()

        query = get_fuse_time_query(user_id, start_date, end_date, lob)
        
        logger.info("Executing query")
        df = session.sql(query)
        
        rows = df.collect()
        if rows:
            total_seconds = sum(row['TOTALSYSTEMTIME'] for row in rows if row['TOTALSYSTEMTIME'])
            total_hours = total_seconds // 3600
            remaining_minutes = (total_seconds % 3600) // 60
            formatted_time = f"{total_hours} hrs. {remaining_minutes} mins."
        else:
            formatted_time = "0 hrs. 0 mins."
        
        logger.info(f"Successfully retrieved fuse time")
        return formatted_time
        
    except Exception as e:
        logger.error(f"Error fetching fuse time: {type(e).__name__}: {str(e)}")
        if 'session' in locals():
            session.close()
        return "0 hrs 0 mins"

def get_non_productive_time_data(user_id: str, start_date: str, end_date: str, lob: str = None):
    """
    Get total non-productive time for a user within a date range
    
    Args:
        user_id: User ID to query
        start_date: Start date in YYYYMMDD format
        end_date: End date in YYYYMMDD format
    
    Returns:
        Non-Productive time as formatted string
    """
    logger.info(f"Fetching non-productive time for user_id={user_id}, start_date={start_date}, end_date={end_date}")
    
    try:
        logger.info("Getting Snowflake session from connection manager")
        engine = connection_manager.get_engine()
        session = engine.connect()
        
        query = get_non_productive_time_query(user_id, start_date, end_date, lob)

        logger.info("Executing query")
        df = session.sql(query)
        rows = df.collect()
        if rows:
            total_seconds = sum(row['NON_PRODUCTIVE_TIME'] for row in rows if row['NON_PRODUCTIVE_TIME'])
            total_hours = total_seconds // 3600
            remaining_minutes = (total_seconds % 3600) // 60
            formatted_time = f"{total_hours} hrs. {remaining_minutes} mins."
        else:
            formatted_time = "0 hrs. 0 mins."
        
        logger.info(f"Successfully retrieved non-productive time")
        return formatted_time

    except Exception as e:
        logger.error(f"Error fetching non-productive time: {type(e).__name__}: {str(e)}")
        if 'session' in locals():
            session.close()
        return "0 hrs 0 mins"