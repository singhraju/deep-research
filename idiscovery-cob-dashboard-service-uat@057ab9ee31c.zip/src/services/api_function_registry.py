"""
API Function Registry for Direct Function Calls

Maps API names to their corresponding execute functions for session cache warming.
This avoids HTTP overhead and 404 errors from endpoint mismatches.

COMPREHENSIVE WARMING: Includes all 6 core APIs + 16 drilldown APIs
"""

from typing import Dict, Callable, Any, Optional, Tuple


class APIFunctionRegistry:
    """Registry mapping API names to their execute functions."""
    
    def __init__(self):
        self._functions: Dict[str, Tuple[Callable, str]] = {}  # (function, request_type)
        self._initialized = False
    
    def _ensure_initialized(self):
        """Lazy initialization to avoid circular imports."""
        if self._initialized:
            return
        
        # Import CORE API functions
        from controllers.Performance_IQ_Director.header_kpis import execute_header_kpis_query
        from controllers.Performance_IQ_Director.operational_flow import execute_operational_flow_query
        from controllers.Performance_IQ_Director.demand_inventory import execute_demand_inventory_query
        from controllers.Performance_IQ_Director.quality_outcomes import execute_quality_outcomes_query
        from controllers.Performance_IQ_Director.associate_utilization import execute_associate_utilization_query
        from controllers.Performance_IQ_Director.sla_health import execute_sla_health_query
        
        # Import DRILLDOWN API functions
        from controllers.Performance_IQ_Director.work_items_director_drilldown import execute_work_items_director_drilldown_query
        from controllers.Performance_IQ_Director.audit_score_director_drilldown import execute_audit_score_director_drilldown_query
        from controllers.Performance_IQ_Director.fuse_time_director_drilldown import execute_fuse_time_director_drilldown_query
        from controllers.Performance_IQ_Director.production_pct_achieved_drilldown import execute_production_pct_achieved_drilldown_query
        from controllers.Performance_IQ_Director.audit_error_director_drilldown import execute_audit_error_director_drilldown_query
        from controllers.Performance_IQ_Director.completed_audit_count_drilldown import execute_completed_audit_count_drilldown_query
        from controllers.Performance_IQ_Director.rebuttal_drilldown import execute_rebuttal_drilldown_query
        from controllers.Performance_IQ_Director.rework_pct_drilldown import execute_rework_pct_drilldown_query
        from controllers.Performance_IQ_Director.escalation_count_drilldown import execute_escalation_count_drilldown_query
        from controllers.Performance_IQ_Director.pended_items_counts_drilldown import execute_pended_items_drilldown_query
        from controllers.Performance_IQ_Director.watchlist_drilldown import execute_watchlist_drilldown_query
        from controllers.Performance_IQ_Director.capacity_insight_drilldown import execute_capacity_insight_drilldown_query
        from controllers.Performance_IQ_Director.sla_health_drilldown import execute_sla_health_drilldown_query
        from controllers.Performance_IQ_Director.audit_sample_pct_drilldown import execute_audit_sample_pct_drilldown_query
        from controllers.Performance_IQ_Director.cycle_takt_drilldown import execute_cycle_takt_drilldown_query
        
        # Format: "api-name": (execute_function, "request_type")
        # request_type: "director_base" for core APIs, "drilldown" for paginated drilldowns
        
        self._functions = {
            # === CORE DASHBOARD APIs (6) ===
            "header-kpis": (execute_header_kpis_query, "director_base"),
            "operational-flow": (execute_operational_flow_query, "director_base"),
            "demand-inventory": (execute_demand_inventory_query, "director_base"),
            "quality-outcomes": (execute_quality_outcomes_query, "director_base"),
            "associate-utilization": (execute_associate_utilization_query, "director_base"),
            "sla-health": (execute_sla_health_query, "director_base"),
            
            # === DRILLDOWN APIs (16) ===
            "work-items-director-drilldown": (execute_work_items_director_drilldown_query, "drilldown"),
            "audit-score-director-drilldown": (execute_audit_score_director_drilldown_query, "drilldown"),
            "fuse-time-director-drilldown": (execute_fuse_time_director_drilldown_query, "drilldown"),
            "production-pct-achieved-drilldown": (execute_production_pct_achieved_drilldown_query, "drilldown"),
            "audit-error-director-drilldown": (execute_audit_error_director_drilldown_query, "drilldown"),
            "completed-audit-count-drilldown": (execute_completed_audit_count_drilldown_query, "drilldown"),
            "rebuttal-drilldown": (execute_rebuttal_drilldown_query, "drilldown"),
            "rework-pct-drilldown": (execute_rework_pct_drilldown_query, "drilldown"),
            "escalation-count-drilldown": (execute_escalation_count_drilldown_query, "drilldown"),
            "pended-items-drilldown": (execute_pended_items_drilldown_query, "drilldown"),
            "watchlist-drilldown": (execute_watchlist_drilldown_query, "drilldown"),
            "capacity-insight-drilldown": (execute_capacity_insight_drilldown_query, "drilldown"),
            "sla-health-drilldown": (execute_sla_health_drilldown_query, "drilldown"),
            "audit-sample-pct-drilldown": (execute_audit_sample_pct_drilldown_query, "drilldown"),
            "cycle-takt-drilldown": (execute_cycle_takt_drilldown_query, "drilldown"),
        }
        self._initialized = True
    
    def get_function(self, api_name: str) -> Optional[Callable]:
        """Get execute function for an API.
        
        Args:
            api_name: Name of the API
            
        Returns:
            Execute function or None if not found
        """
        self._ensure_initialized()
        entry = self._functions.get(api_name)
        return entry[0] if entry else None
    
    def get_function_with_type(self, api_name: str) -> Optional[Tuple[Callable, str]]:
        """Get execute function and request type for an API.
        
        Args:
            api_name: Name of the API
            
        Returns:
            Tuple of (execute_function, request_type) or None if not found
        """
        self._ensure_initialized()
        return self._functions.get(api_name)
    
    def get_all_apis(self) -> list[str]:
        """Get list of all registered API names (22 total: 6 core + 16 drilldowns)."""
        self._ensure_initialized()
        return list(self._functions.keys())
    
    def get_core_apis(self) -> list[str]:
        """Get list of core dashboard API names only (6 APIs)."""
        self._ensure_initialized()
        return [name for name, (func, req_type) in self._functions.items() 
                if req_type == "director_base"]
    
    def get_drilldown_apis(self) -> list[str]:
        """Get list of drilldown API names only (16 APIs)."""
        self._ensure_initialized()
        return [name for name, (func, req_type) in self._functions.items() 
                if req_type == "drilldown"]
    
    def get_api_count(self) -> int:
        """Get total number of registered APIs (22)."""
        self._ensure_initialized()
        return len(self._functions)
    
    def is_core_api(self, api_name: str) -> bool:
        """Check if an API is a core dashboard API.
        
        Args:
            api_name: Name of the API
            
        Returns:
            True if core API, False otherwise
        """
        self._ensure_initialized()
        entry = self._functions.get(api_name)
        return entry[1] == "director_base" if entry else False


# Singleton instance
api_function_registry = APIFunctionRegistry()
