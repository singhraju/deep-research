"""
API Registry for Director APIs Session-Based Caching

This module maintains a centralized registry of all Director APIs that will be
included in session-based cache warming. Each API is registered with metadata
about its endpoint, handler function, and category.
"""

from typing import Dict, List, Any, Callable


class DirectorAPIRegistry:
    """Registry of all Director APIs for session-based caching."""
    
    # Core Dashboard APIs - Always warmed first
    CORE_APIS = [
        {
            "name": "header-kpis",
            "endpoint": "/director/header-kpis",
            "category": "core",
            "priority": 1
        },
        {
            "name": "operational-flow",
            "endpoint": "/director/operational-flow",
            "category": "core",
            "priority": 1
        },
        {
            "name": "demand-inventory",
            "endpoint": "/director/demand-inventory",
            "category": "core",
            "priority": 1
        },
        {
            "name": "quality-outcomes",
            "endpoint": "/director/quality-outcomes",
            "category": "core",
            "priority": 1
        },
        {
            "name": "associate-utilization",
            "endpoint": "/director/associate-utilization",
            "category": "core",
            "priority": 1
        },
        {
            "name": "sla-health",
            "endpoint": "/director/sla-health",
            "category": "core",
            "priority": 1
        }
    ]
    
    # Drilldown APIs - Count and paginated queries
    DRILLDOWN_APIS = [
        {
            "name": "work-items-drilldown",
            "endpoint": "/director/work-items-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "audit-score-drilldown",
            "endpoint": "/director/audit-score-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "fuse-time-drilldown",
            "endpoint": "/director/fuse-time-director-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "production-pct-drilldown",
            "endpoint": "/director/production-pct-achieved-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "audit-error-drilldown",
            "endpoint": "/director/audit-error-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "escalation-count-drilldown",
            "endpoint": "/director/escalation-count-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "pended-items-drilldown",
            "endpoint": "/director/pended-items-counts-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "rebuttal-drilldown",
            "endpoint": "/director/rebuttal-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "rework-pct-drilldown",
            "endpoint": "/director/rework-pct-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "completed-audit-count-drilldown",
            "endpoint": "/director/completed-audit-count-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "audit-sample-pct-drilldown",
            "endpoint": "/director/audit-sample-pct-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "completed-ata-counts-drilldown",
            "endpoint": "/director/completed-ata-counts-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "cycle-takt-drilldown",
            "endpoint": "/director/cycle-takt-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "watchlist-drilldown",
            "endpoint": "/director/watchlist-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "capacity-insight-drilldown",
            "endpoint": "/director/capacity-insight-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        },
        {
            "name": "sla-health-drilldown",
            "endpoint": "/director/sla-health-drilldown",
            "category": "drilldown",
            "priority": 2,
            "paginated": True
        }
    ]
    
    # Excel Download APIs
    EXCEL_APIS = [
        {
            "name": "work-items-excel",
            "endpoint": "/director/work-items-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "audit-score-excel",
            "endpoint": "/director/audit-score-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "fuse-time-excel",
            "endpoint": "/director/fuse-time-director-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "production-pct-excel",
            "endpoint": "/director/production-pct-achieved-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "audit-error-excel",
            "endpoint": "/director/audit-error-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "escalation-count-excel",
            "endpoint": "/director/escalation-count-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "pended-items-excel",
            "endpoint": "/director/pended-items-counts-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "rebuttal-excel",
            "endpoint": "/director/rebuttal-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "rework-pct-excel",
            "endpoint": "/director/rework-pct-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "completed-audit-count-excel",
            "endpoint": "/director/completed-audit-count-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "audit-sample-pct-excel",
            "endpoint": "/director/audit-sample-pct-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "completed-ata-counts-excel",
            "endpoint": "/director/completed-ata-counts-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "cycle-takt-excel",
            "endpoint": "/director/cycle-takt-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "watchlist-excel",
            "endpoint": "/director/watchlist-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "capacity-insight-excel",
            "endpoint": "/director/capacity-insight-drilldown/excel",
            "category": "excel",
            "priority": 3
        },
        {
            "name": "sla-health-excel",
            "endpoint": "/director/sla-health-drilldown/excel",
            "category": "excel",
            "priority": 3
        }
    ]
    
    @classmethod
    def get_all_apis(cls) -> List[Dict[str, Any]]:
        """Get all registered APIs."""
        return cls.CORE_APIS + cls.DRILLDOWN_APIS + cls.EXCEL_APIS
    
    @classmethod
    def get_core_apis(cls) -> List[Dict[str, Any]]:
        """Get only core dashboard APIs."""
        return cls.CORE_APIS
    
    @classmethod
    def get_drilldown_apis(cls) -> List[Dict[str, Any]]:
        """Get only drilldown APIs."""
        return cls.DRILLDOWN_APIS
    
    @classmethod
    def get_excel_apis(cls) -> List[Dict[str, Any]]:
        """Get only Excel download APIs."""
        return cls.EXCEL_APIS
    
    @classmethod
    def get_api_by_name(cls, name: str) -> Dict[str, Any]:
        """Get API configuration by name."""
        all_apis = cls.get_all_apis()
        for api in all_apis:
            if api["name"] == name:
                return api
        return None
    
    @classmethod
    def get_total_count(cls) -> int:
        """Get total number of APIs."""
        return len(cls.get_all_apis())


# Singleton instance
api_registry = DirectorAPIRegistry()
