"""
Baseline KPI Configuration for AI Coach Performance Analysis.

This module defines baseline targets, rating scales, and performance thresholds
used for contextual performance analysis and coaching recommendations.
Includes dynamic baseline calculation for manager-based team averages.
"""

from typing import Dict, Any, Optional, List
from enum import Enum
import logging
import re

logger = logging.getLogger(__name__)


class ProductionRating(Enum):
    """Production performance rating categories."""
    DOES_NOT_MEET = "Does Not Meet"
    PARTIAL_MEETS = "Partial Meets"
    MEETS = "Meets"
    EXCEEDS = "Exceeds"
    SIGNIFICANTLY_EXCEED = "Significantly Exceed"


class PerformanceLevel(Enum):
    """Performance level descriptors."""
    POOR = "Poor"
    APPROACHING = "Approaching"
    MEETS = "Meets"
    EXCEEDS = "Exceeds"
    EXCEPTIONAL = "Exceptional"


# Production Rating Scale Configuration
PRODUCTION_RATING_SCALE = {
    ProductionRating.DOES_NOT_MEET: {
        "range": "Below 95%",
        "min_pct": 0.0,
        "max_pct": 94.99,
        "performance_level": PerformanceLevel.POOR,
        "description": "Performance below expectations"
    },
    ProductionRating.PARTIAL_MEETS: {
        "range": "95%-99.99%",
        "min_pct": 95.0,
        "max_pct": 99.99,
        "performance_level": PerformanceLevel.APPROACHING,
        "description": "Performance approaching target"
    },
    ProductionRating.MEETS: {
        "range": "100%-114.99%",
        "min_pct": 100.0,
        "max_pct": 114.99,
        "performance_level": PerformanceLevel.MEETS,
        "description": "Performance meets expectations"
    },
    ProductionRating.EXCEEDS: {
        "range": "115%-119.99%",
        "min_pct": 115.0,
        "max_pct": 119.99,
        "performance_level": PerformanceLevel.EXCEEDS,
        "description": "Performance exceeds expectations"
    },
    ProductionRating.SIGNIFICANTLY_EXCEED: {
        "range": "120% and above",
        "min_pct": 120.0,
        "max_pct": float('inf'),
        "performance_level": PerformanceLevel.EXCEPTIONAL,
        "description": "Exceptional performance"
    }
}

# Baseline KPI Targets
BASELINE_KPI_TARGETS = {
    "frontline": {
        "audit_score": {
            "target": 98.0,
            "excellent": 100.0,
            "good": 98.0,
            "poor": 97.99,
            "unit": "%"
        },
        "production_pct": {
            "target": 100.0,
            "rating_scale": {
                "does_not_meet": {"range": "Below 95%", "description": "Performance below expectations"},
                "partial_meets": {"range": "95%-99.99%", "description": "Performance approaching target"},
                "meets": {"range": "100%-114.99%", "description": "Performance meets expectations"},
                "exceeds": {"range": "115%-119.99%", "description": "Performance exceeds expectations"},
                "significantly_exceed": {"range": "120% and above", "description": "Exceptional performance"}
            },
            "unit": "%"
        },
        "cycle_time": {
            "target_minutes": 15.0,
            "excellent": 12.0,
            "good": 15.0,
            "poor": 18.0,
            "unit": "minutes"
        },
        "work_items": {
            "target_daily": 20,
            "excellent": 25,
            "good": 20,
            "poor": 15,
            "unit": "items"
        }
    },
    "manager": {
        "team_audit_score": {
            "target": 98.0,
            "excellent": 99.0,
            "good": 98.0,
            "poor": 97.0,
            "unit": "%"
        },
        "team_production_pct": {
            "target": 100.0,
            "rating_scale": {
                "does_not_meet": {"range": "Below 95%", "description": "Performance below expectations"},
                "partial_meets": {"range": "95%-99.99%", "description": "Performance approaching target"},
                "meets": {"range": "100%-114.99%", "description": "Performance meets expectations"},
                "exceeds": {"range": "115%-119.99%", "description": "Performance exceeds expectations"},
                "significantly_exceed": {"range": "120% and above", "description": "Exceptional performance"}
            },
            "unit": "%"
        },
        "team_cycle_time": {
            "target_minutes": 15.0,
            "excellent": 12.0,
            "good": 15.0,
            "poor": 18.0,
            "unit": "minutes"
        }
    },
    "fl_auditor": {
        "ata_audit_score": {
            "target": 98.0,
            "excellent": 100.0,
            "good": 98.0,
            "poor": 95.0,
            "unit": "%"
        },
        "audit_cycle_time": {
            "target_minutes": 20.0,
            "excellent": 16.0,
            "good": 20.0,
            "poor": 24.0,
            "unit": "minutes",
            "comparison": "lower_is_better"
        },
        "complete_audit_count": {
            "target_daily": 18,
            "excellent": 21,
            "good": 18,
            "poor": 14,
            "unit": "audits/day"
        }
    },
    "auditor_manager": {
        "ata_audit_score": {
            "target": 98.0,
            "excellent": 100.0,
            "good": 98.0,
            "poor": 95.0,
            "unit": "%"
        },
        "audit_cycle_time": {
            "target_minutes": 20.0,
            "excellent": 16.0,
            "good": 20.0,
            "poor": 24.0,
            "unit": "minutes",
            "comparison": "lower_is_better"
        }
    },
    "director": {
        "organizational_audit_score": {
            "target": 98.0,
            "excellent": 99.0,
            "good": 98.0,
            "poor": 96.0,
            "unit": "%"
        },
        "organizational_production_pct": {
            "target": 100.0,
            "rating_scale": {
                "does_not_meet": {"range": "Below 95%", "description": "Performance below expectations"},
                "partial_meets": {"range": "95%-99.99%", "description": "Performance approaching target"},
                "meets": {"range": "100%-114.99%", "description": "Performance meets expectations"},
                "exceeds": {"range": "115%-119.99%", "description": "Performance exceeds expectations"},
                "significantly_exceed": {"range": "120% and above", "description": "Exceptional performance"}
            },
            "unit": "%"
        },
        "resource_utilization": {
            "target": 85.0,
            "excellent": 90.0,
            "good": 85.0,
            "poor": 80.0,
            "unit": "%"
        }
    }
}


def get_production_rating(production_pct: float) -> Dict[str, Any]:
    """
    Get production rating based on percentage value.
    
    Args:
        production_pct: Production percentage value
        
    Returns:
        Dict containing rating information
    """
    for rating, config in PRODUCTION_RATING_SCALE.items():
        if config["min_pct"] <= production_pct <= config["max_pct"]:
            return {
                "rating": rating.value,
                "performance_level": config["performance_level"].value,
                "range": config["range"],
                "description": config["description"]
            }
    
    # Fallback for edge cases
    return {
        "rating": ProductionRating.DOES_NOT_MEET.value,
        "performance_level": PerformanceLevel.POOR.value,
        "range": "Below 95%",
        "description": "Performance below expectations"
    }


def get_baseline_targets(role: str) -> Dict[str, Any]:
    """
    Get baseline KPI targets for a specific role.
    
    Args:
        role: User role (frontline, manager, director, etc.)
        
    Returns:
        Dict containing baseline targets for the role
    """
    return BASELINE_KPI_TARGETS.get(role, BASELINE_KPI_TARGETS["frontline"])


def _get_metric_mapping(role: str) -> Dict[str, str]:
    """
    Map metrics_data keys → BASELINE_KPI_TARGETS[role] keys.
    Both sides must match exactly for evaluate_metric_performance() to work.
    """
    if role == "auditor_manager":
        return {
            "ata_audit_score": "ata_audit_score",
            "audit_cycle_time": "audit_cycle_time"
        }
    if role == "director":
        # Metrics dict keys → BASELINE_KPI_TARGETS["director"] keys
        return {
            "audit_score": "organizational_audit_score",
            "production_pct": "organizational_production_pct",
        }
    if role == "manager":
        # Metrics dict keys → BASELINE_KPI_TARGETS["manager"] keys
        return {
            "audit_score": "team_audit_score",
            "production_pct": "team_production_pct",
            "cycle_time": "team_cycle_time",
        }
    if role == "fl_auditor":
        return {
            "ata_audit_score": "ata_audit_score",
            "audit_cycle_time": "audit_cycle_time",
            "complete_audit_count": "complete_audit_count"
        }
    # frontline (default)
    return {
        "audit_score": "audit_score",
        "production_pct": "production_pct",
        "cycle_time": "cycle_time",
        "work_items_completed": "work_items"
    }


def _parse_duration_to_minutes(value: str) -> Optional[float]:
    normalized_value = (value or "").strip().lower()
    if not normalized_value:
        return None

    minutes_match = re.search(r"(\d+(?:\.\d+)?)\s*min", normalized_value)
    seconds_match = re.search(r"(\d+(?:\.\d+)?)\s*sec", normalized_value)

    if not minutes_match and not seconds_match:
        return None

    minutes = float(minutes_match.group(1)) if minutes_match else 0.0
    seconds = float(seconds_match.group(1)) if seconds_match else 0.0
    return minutes + (seconds / 60.0)


def evaluate_metric_performance(metric_name: str, value: float, role: str) -> Dict[str, Any]:
    """
    Evaluate metric performance against baseline targets.
    
    Args:
        metric_name: Name of the metric to evaluate
        value: Current metric value
        role: User role for context
        
    Returns:
        Dict containing performance evaluation
    """
    targets = get_baseline_targets(role)
    
    if metric_name not in targets:
        return {"status": "unknown", "message": "No baseline defined for this metric"}
    
    target_config = targets[metric_name]
    
    # Special handling for production percentage with rating scale
    if "rating_scale" in target_config:
        return get_production_rating(value)

    # Standard threshold evaluation
    target = target_config.get("target", 0)
    excellent = target_config.get("excellent", target)
    good = target_config.get("good", target)
    poor = target_config.get("poor", target)
    
    if value >= excellent:
        status = "excellent"
        message = f"Exceeds target ({excellent}{target_config.get('unit', '')})"
    elif value >= good:
        status = "good"
        message = f"Meets target ({good}{target_config.get('unit', '')})"
    elif value >= poor:
        status = "approaching"
        message = f"Approaching target ({target}{target_config.get('unit', '')})"
    else:
        status = "poor"
        message = f"Below target ({target}{target_config.get('unit', '')})"
    
    return {
        "status": status,
        "message": message,
        "target": target,
        "current": value,
        "unit": target_config.get("unit", "")
    }


def generate_baseline_instruction(role: str, metrics_data: Dict[str, Any]) -> str:
    """
    Generate baseline handling instruction for LLM prompt.
    
    Args:
        role: User role
        metrics_data: Current metrics data
        
    Returns:
        Baseline instruction string
    """
    targets = get_baseline_targets(role)
    evaluations = []
    
    metric_mapping = _get_metric_mapping(role)
    
    for metric_key, baseline_key in metric_mapping.items():
        if metric_key in metrics_data:
            # Extract numeric value from metric
            value = metrics_data[metric_key]
            if isinstance(value, str):
                try:
                    if 'min' in value or 'sec' in value:
                        parsed_value = _parse_duration_to_minutes(value)
                        if parsed_value is None:
                            continue
                        value = parsed_value
                    else:
                        value = float(value.replace('%', '').replace(',', '').strip())
                except (ValueError, AttributeError):
                    continue
            
            evaluation = evaluate_metric_performance(baseline_key, value, role)
            if evaluation.get("status") != "unknown":
                evaluations.append(f"{metric_key}: {evaluation.get('message', 'N/A')}")
    
    if evaluations:
        return (
            f"Use these baseline targets for {role} performance evaluation:\n" +
            "\n".join(f"- {eval_text}" for eval_text in evaluations) +
            "\n\nProvide context-aware coaching based on how current performance compares to these targets."
        )
    
    return f"Evaluate performance using standard {role} expectations and industry best practices."


async def get_dynamic_baseline_targets(
    role: str, 
    user_id: str, 
    start_date: str, 
    end_date: str,
    lob: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Get baseline KPI targets with dynamic cycle time calculation for frontline associates.
    
    For frontline associates, cycle time target is calculated as the average of all
    frontline associates under the same manager. For other roles, uses static targets.
    
    Args:
        role: User role (frontline, manager, director, etc.)
        user_id: User identifier for dynamic calculations
        start_date: Start date for dynamic baseline calculation
        end_date: End date for dynamic baseline calculation
        lob: Optional list of LOBs to filter by
        
    Returns:
        Dict containing baseline targets with dynamic cycle time for frontline users
    """
    # Get static baseline targets as foundation
    baseline_targets = get_baseline_targets(role).copy()
    
    # Apply dynamic cycle time calculation for frontline associates
    if role == "frontline":
        try:
            from .dynamic_baseline_service import get_dynamic_baseline_for_associate
            
            # Get dynamic cycle time baseline based on manager's team average
            dynamic_cycle_time_minutes = await get_dynamic_baseline_for_associate(
                user_id, start_date, end_date, lob
            )
            
            if dynamic_cycle_time_minutes is not None:
                # Update cycle time target with dynamic value
                baseline_targets["cycle_time"] = {
                    "target_minutes": round(dynamic_cycle_time_minutes, 2),
                    "excellent": round(dynamic_cycle_time_minutes * 0.8, 2),  # 20% better than team avg
                    "good": round(dynamic_cycle_time_minutes, 2),  # Team average
                    "poor": round(dynamic_cycle_time_minutes * 1.2, 2),  # 20% worse than team avg
                    "unit": "minutes",
                    "calculation_method": "manager_team_average",
                    "baseline_period": f"{start_date} to {end_date}"
                }
                
                logger.info(
                    f"Applied dynamic cycle time baseline for {user_id}: "
                    f"{dynamic_cycle_time_minutes} minutes (manager team average)"
                )
            else:
                logger.warning(
                    f"Could not calculate dynamic cycle time for {user_id}, "
                    f"using static baseline"
                )
                
        except Exception as e:
            logger.error(f"Error calculating dynamic baseline for {user_id}: {str(e)}")
            logger.info("Falling back to static baseline targets")
    
    return baseline_targets


async def generate_dynamic_baseline_instruction(
    role: str, 
    user_id: str, 
    start_date: str, 
    end_date: str,
    metrics_data: Dict[str, Any],
    lob: Optional[List[str]] = None
) -> str:
    """
    Generate baseline handling instruction with dynamic targets for LLM prompt.
    
    Args:
        role: User role
        user_id: User identifier for dynamic calculations
        start_date: Start date for dynamic baseline calculation
        end_date: End date for dynamic baseline calculation
        metrics_data: Current metrics data
        lob: Optional list of LOBs to filter by
        
    Returns:
        Baseline instruction string with dynamic targets
    """
    # Get dynamic baseline targets
    targets = await get_dynamic_baseline_targets(role, user_id, start_date, end_date, lob)
    evaluations = []
    
    metric_mapping = _get_metric_mapping(role)
    
    for metric_key, baseline_key in metric_mapping.items():
        if metric_key in metrics_data:
            # Extract numeric value from metric
            value = metrics_data[metric_key]
            if isinstance(value, str):
                try:
                    if 'min' in value or 'sec' in value:
                        parsed_value = _parse_duration_to_minutes(value)
                        if parsed_value is None:
                            continue
                        value = parsed_value
                    else:
                        value = float(value.replace('%', '').replace(',', '').strip())
                except (ValueError, AttributeError):
                    continue
            
            evaluation = evaluate_metric_performance(baseline_key, value, role, targets)
            if evaluation.get("status") != "unknown":
                eval_text = f"{metric_key}: {evaluation.get('message', 'N/A')}"
                if baseline_key == "cycle_time" and targets.get("cycle_time", {}).get("calculation_method") == "manager_team_average":
                    eval_text += " (based on manager team average)"
                evaluations.append(eval_text)
    
    if evaluations:
        instruction = (
            f"Use these baseline targets for {role} performance evaluation:\n" +
            "\n".join(f"- {eval_text}" for eval_text in evaluations)
        )
        
        # Add dynamic baseline context
        if role == "frontline" and targets.get("cycle_time", {}).get("calculation_method") == "manager_team_average":
            instruction += f"\n\nNote: Cycle time target ({targets['cycle_time']['target_minutes']} min) is calculated as the average of all frontline associates under the same manager for the period {targets['cycle_time']['baseline_period']}."
        
        instruction += "\n\nProvide context-aware coaching based on how current performance compares to these targets."
        return instruction
    
    return f"Evaluate performance using standard {role} expectations and industry best practices."


def evaluate_metric_performance(metric_name: str, value: float, role: str, targets: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Evaluate metric performance against baseline targets (updated to accept custom targets).
    
    Args:
        metric_name: Name of the metric to evaluate
        value: Current metric value
        role: User role for context
        targets: Optional custom targets dict (for dynamic baselines)
        
    Returns:
        Dict containing performance evaluation
    """
    if targets is None:
        targets = get_baseline_targets(role)
    
    if metric_name not in targets:
        return {"status": "unknown", "message": "No baseline defined for this metric"}
    
    target_config = targets[metric_name]
    
    # Special handling for production percentage with rating scale
    if "rating_scale" in target_config:
        return get_production_rating(value)

    # Standard threshold evaluation
    target = target_config.get("target", target_config.get("target_minutes", target_config.get("target_daily", 0)))
    excellent = target_config.get("excellent", target)
    good = target_config.get("good", target)
    poor = target_config.get("poor", target)
    
    if target_config.get("comparison") == "lower_is_better":
        if value <= excellent:
            status = "excellent"
            message = f"Exceeds target ({excellent}{target_config.get('unit', '')} or less)"
        elif value <= good:
            status = "good"
            message = f"Meets target ({good}{target_config.get('unit', '')} or less)"
        elif value <= poor:
            status = "approaching"
            message = f"Approaching target ({target}{target_config.get('unit', '')})"
        else:
            status = "poor"
            message = f"Above target ({target}{target_config.get('unit', '')})"
    else:
        if value >= excellent:
            status = "excellent"
            message = f"Exceeds target ({excellent}{target_config.get('unit', '')})"
        elif value >= good:
            status = "good"
            message = f"Meets target ({good}{target_config.get('unit', '')})"
        elif value >= poor:
            status = "approaching"
            message = f"Approaching target ({target}{target_config.get('unit', '')})"
        else:
            status = "poor"
            message = f"Below target ({target}{target_config.get('unit', '')})"
    
    return {
        "status": status,
        "message": message,
        "target": target,
        "current": value,
        "unit": target_config.get("unit", "")
    }


# ============================================================================
# METRIC INTERPRETATION RULES (from AI Coach Design Document - April 2026)
# ============================================================================

# Metric Interpretation Guidelines for AI Coach
METRIC_INTERPRETATION_RULES = {
    "audit_score_pct": {
        "good": {"min": 98.0, "max": 100.0, "label": "Good"},
        "monitor": {"min": 95.0, "max": 97.99, "label": "Monitor"},
        "critical": {"min": 0.0, "max": 94.99, "label": "Critical"}
    },
    "production_pct": {
        "good": {"min": 90.0, "max": 110.0, "label": "Good"},
        "monitor": [
            {"min": 80.0, "max": 89.99, "label": "Monitor"},
            {"min": 110.01, "max": 130.0, "label": "Monitor"}
        ],
        "critical": [
            {"min": 0.0, "max": 79.99, "label": "Critical"},
            {"min": 150.01, "max": float('inf'), "label": "Critical"}
        ]
    },
    "utilization_pct": {
        "good": {"min": 70.0, "max": 85.0, "label": "Good"},
        "monitor": {"min": 60.0, "max": 69.99, "label": "Monitor"},
        "critical": [
            {"min": 0.0, "max": 59.99, "label": "Critical"},
            {"min": 90.01, "max": 100.0, "label": "Critical"}
        ]
    },
    "non_value_add_pct": {
        "good": {"min": 0.0, "max": 15.0, "label": "Good"},
        "monitor": {"min": 15.01, "max": 25.0, "label": "Monitor"},
        "critical": {"min": 25.01, "max": 100.0, "label": "Critical"}
    },
    "cycle_time_seconds": {
        "team_variance": {
            "good": {"min": -20.0, "max": 20.0, "label": "Within team average ±20%"},
            "monitor": [
                {"min": -40.0, "max": -20.01, "label": "Team avg -20-40%"},
                {"min": 20.01, "max": 40.0, "label": "Team avg +20-40%"}
            ],
            "critical": [
                {"min": -float('inf'), "max": -40.01, "label": ">40% faster than team"},
                {"min": 40.01, "max": float('inf'), "label": ">40% slower than team"}
            ]
        }
    },
    "lead_time_days": {
        "good": {"min": 0, "max": 30, "label": "Good"},
        "monitor": {"min": 31, "max": 60, "label": "Monitor"},
        "critical": {"min": 61, "max": float('inf'), "label": "Critical"}
    },
    "rebuttal_overturn_pct": {
        "good": {"min": 0.0, "max": 25.0, "label": "Good"},
        "monitor": {"min": 25.01, "max": 50.0, "label": "Monitor"},
        "critical": {"min": 50.01, "max": 100.0, "label": "Critical"}
    }
}

# Benchmarking heuristics from design doc
BENCHMARKING_RULES = {
    "team_average_variance": {
        "normal": {"min": -10.0, "max": 10.0, "description": "Within ±10% of team average"},
        "excellent": {"min": 20.01, "max": float('inf'), "description": ">20% better than team average"},
        "needs_improvement": {"min": -float('inf'), "max": -20.0, "description": ">20% worse than team average"}
    },
    "goal_variance": {
        "good": {"min": 0.0, "max": float('inf'), "description": "Meets or exceeds goal"},
        "monitor": {"min": -20.0, "max": -0.01, "description": "10-20% below goal"},
        "critical": {"min": -float('inf'), "max": -20.01, "description": ">20% below goal"}
    }
}


def get_metric_interpretation(metric_name: str, value: float, team_avg: Optional[float] = None) -> Dict[str, Any]:
    """
    Get interpretation for a metric value based on design doc rules.
    
    Args:
        metric_name: Name of the metric
        value: Current metric value
        team_avg: Optional team average for relative comparison
        
    Returns:
        Dict with interpretation (good/monitor/critical)
    """
    if metric_name not in METRIC_INTERPRETATION_RULES:
        return {"status": "unknown", "label": "Unknown", "message": "No interpretation rules defined"}
    
    rules = METRIC_INTERPRETATION_RULES[metric_name]
    
    # Special handling for cycle time (uses team variance)
    if metric_name == "cycle_time_seconds" and team_avg is not None:
        variance_pct = ((value - team_avg) / team_avg) * 100 if team_avg > 0 else 0
        variance_rules = rules.get("team_variance", {})
        
        # Check good range
        if "good" in variance_rules:
            good_rule = variance_rules["good"]
            if good_rule["min"] <= variance_pct <= good_rule["max"]:
                return {
                    "status": "good",
                    "label": "Good",
                    "message": f"{good_rule['label']} ({variance_pct:+.1f}% vs team)"
                }
        
        # Check monitor range
        if "monitor" in variance_rules:
            for monitor_rule in variance_rules["monitor"]:
                if monitor_rule["min"] <= variance_pct <= monitor_rule["max"]:
                    return {
                        "status": "monitor",
                        "label": "Monitor",
                        "message": f"{monitor_rule['label']} ({variance_pct:+.1f}% vs team)"
                    }
        
        # Check critical range
        if "critical" in variance_rules:
            for critical_rule in variance_rules["critical"]:
                if critical_rule["min"] <= variance_pct <= critical_rule["max"]:
                    return {
                        "status": "critical",
                        "label": "Critical",
                        "message": f"{critical_rule['label']} ({variance_pct:+.1f}% vs team)"
                    }
    
    # Standard absolute value interpretation
    # Check good range
    if "good" in rules:
        good_rule = rules["good"]
        if good_rule["min"] <= value <= good_rule["max"]:
            return {
                "status": "good",
                "label": "Good",
                "message": f"Within good range ({good_rule['min']}-{good_rule['max']})"
            }
    
    # Check monitor range
    if "monitor" in rules:
        monitor_rules = rules["monitor"] if isinstance(rules["monitor"], list) else [rules["monitor"]]
        for monitor_rule in monitor_rules:
            if monitor_rule["min"] <= value <= monitor_rule["max"]:
                return {
                    "status": "monitor",
                    "label": "Monitor",
                    "message": f"Within monitor range ({monitor_rule['min']}-{monitor_rule['max']})"
                }
    
    # Check critical range
    if "critical" in rules:
        critical_rules = rules["critical"] if isinstance(rules["critical"], list) else [rules["critical"]]
        for critical_rule in critical_rules:
            if critical_rule["min"] <= value <= critical_rule["max"]:
                return {
                    "status": "critical",
                    "label": "Critical",
                    "message": f"Within critical range ({critical_rule['min']}-{critical_rule['max']})"
                }
    
    return {"status": "unknown", "label": "Unknown", "message": "Value outside defined ranges"}


def evaluate_team_variance(value: float, team_avg: float, goal: Optional[float] = None) -> Dict[str, Any]:
    """
    Evaluate performance based on team average variance.
    
    Args:
        value: Current metric value
        team_avg: Team average value
        goal: Optional goal value
        
    Returns:
        Dict with variance evaluation
    """
    if team_avg == 0:
        return {"status": "unknown", "message": "Team average is zero, cannot calculate variance"}
    
    variance_pct = ((value - team_avg) / team_avg) * 100
    rules = BENCHMARKING_RULES["team_average_variance"]
    
    for status, rule in rules.items():
        if rule["min"] <= variance_pct <= rule["max"]:
            return {
                "status": status,
                "variance_pct": round(variance_pct, 1),
                "description": rule["description"],
                "message": f"{rule['description']}: {variance_pct:+.1f}%"
            }
    
    return {
        "status": "unknown",
        "variance_pct": round(variance_pct, 1),
        "message": f"Variance {variance_pct:+.1f}% outside defined ranges"
    }


def evaluate_goal_variance(value: float, goal: float) -> Dict[str, Any]:
    """
    Evaluate performance based on goal variance.
    
    Args:
        value: Current metric value
        goal: Goal value
        
    Returns:
        Dict with goal variance evaluation
    """
    if goal == 0:
        return {"status": "unknown", "message": "Goal is zero, cannot calculate variance"}
    
    variance_pct = ((value - goal) / goal) * 100
    rules = BENCHMARKING_RULES["goal_variance"]
    
    for status, rule in rules.items():
        if rule["min"] <= variance_pct <= rule["max"]:
            return {
                "status": status,
                "variance_pct": round(variance_pct, 1),
                "description": rule["description"],
                "message": f"{rule['description']}: {variance_pct:+.1f}% vs goal"
            }
    
    return {
        "status": "unknown",
        "variance_pct": round(variance_pct, 1),
        "message": f"Variance {variance_pct:+.1f}% outside defined ranges"
    }


# ============================================================================
# SHRINKAGE AND UTILIZATION HELPERS (from AI Coach Requirements - April 2026)
# ============================================================================

# Shrinkage constants
SHRINKAGE_HOURS_PER_DAY = 5.3  # Expected productive hours per day
SHRINKAGE_PERCENTAGE = 12.0    # 12% shrinkage
STANDARD_WORK_DAY_HOURS = 8.0  # Standard 8-hour work day


def calculate_expected_productive_hours(work_days: int) -> float:
    """
    Calculate expected productive hours considering shrinkage.
    
    Per requirements: "Assess in consideration of shrinkage (5.3 hours per day, or 12%)"
    
    Args:
        work_days: Number of work days in the period
        
    Returns:
        Expected productive hours
    """
    return work_days * SHRINKAGE_HOURS_PER_DAY


def evaluate_ohi_production_time(actual_hours: float, work_days: int) -> Dict[str, Any]:
    """
    Evaluate OHI Production Time against expected hours with shrinkage.
    
    Args:
        actual_hours: Actual OHI production time logged
        work_days: Number of work days in the period
        
    Returns:
        Dict with evaluation status and message
    """
    expected_hours = calculate_expected_productive_hours(work_days)
    
    if expected_hours == 0:
        return {
            "status": "unknown",
            "message": "Cannot evaluate - work days is zero"
        }
    
    achievement_pct = (actual_hours / expected_hours) * 100
    variance_hours = actual_hours - expected_hours
    
    # Evaluation thresholds
    if achievement_pct >= 95.0:
        status = "good"
        message = f"Meets expected productive hours ({actual_hours:.1f}h vs {expected_hours:.1f}h expected)"
    elif achievement_pct >= 85.0:
        status = "monitor"
        message = f"Below expected productive hours ({actual_hours:.1f}h vs {expected_hours:.1f}h expected, {variance_hours:+.1f}h gap)"
    else:
        status = "critical"
        message = f"Significantly below expected productive hours ({actual_hours:.1f}h vs {expected_hours:.1f}h expected, {variance_hours:+.1f}h gap)"
    
    return {
        "status": status,
        "message": message,
        "actual_hours": actual_hours,
        "expected_hours": expected_hours,
        "achievement_pct": round(achievement_pct, 1),
        "variance_hours": round(variance_hours, 1),
        "shrinkage_applied": f"{SHRINKAGE_HOURS_PER_DAY}h/day ({SHRINKAGE_PERCENTAGE}%)"
    }


def evaluate_non_productive_time(non_productive_hours: float, total_hours: float, work_days: int) -> Dict[str, Any]:
    """
    Evaluate Fuse Non-Productive Time considering shrinkage allowance.
    
    Per requirements: "Assess in consideration of shrinkage to advise if there is opportunity to reduce"
    
    Args:
        non_productive_hours: Non-productive time logged
        total_hours: Total hours logged
        work_days: Number of work days in the period
        
    Returns:
        Dict with evaluation status and message
    """
    if total_hours == 0:
        return {
            "status": "unknown",
            "message": "Cannot evaluate - total hours is zero"
        }
    
    non_productive_pct = (non_productive_hours / total_hours) * 100
    expected_shrinkage_hours = work_days * STANDARD_WORK_DAY_HOURS * (SHRINKAGE_PERCENTAGE / 100)
    excess_non_productive = max(0, non_productive_hours - expected_shrinkage_hours)
    
    # Evaluation thresholds
    if non_productive_pct <= SHRINKAGE_PERCENTAGE:
        status = "good"
        message = f"Non-productive time within shrinkage allowance ({non_productive_pct:.1f}% vs {SHRINKAGE_PERCENTAGE}% expected)"
    elif non_productive_pct <= SHRINKAGE_PERCENTAGE * 1.5:
        status = "monitor"
        message = f"Non-productive time elevated ({non_productive_pct:.1f}% vs {SHRINKAGE_PERCENTAGE}% expected, {excess_non_productive:.1f}h excess)"
    else:
        status = "critical"
        message = f"Non-productive time significantly elevated ({non_productive_pct:.1f}% vs {SHRINKAGE_PERCENTAGE}% expected, {excess_non_productive:.1f}h excess)"
    
    return {
        "status": status,
        "message": message,
        "non_productive_hours": non_productive_hours,
        "non_productive_pct": round(non_productive_pct, 1),
        "expected_shrinkage_pct": SHRINKAGE_PERCENTAGE,
        "excess_hours": round(excess_non_productive, 1)
    }


# Staff Utilization Baseline Thresholds
# Per requirements: "We do not have a threshold established. AI to assess and determine 
# reasonable threshold by comparing managers/auditors."
# These are tentative baselines for consistency until data-driven thresholds are established.

STAFF_UTILIZATION_THRESHOLDS = {
    "manager": {
        "excellent": {"min": 75.0, "max": 90.0, "label": "Excellent"},
        "good": {"min": 65.0, "max": 74.99, "label": "Good"},
        "monitor": {"min": 50.0, "max": 64.99, "label": "Monitor"},
        "critical": {"min": 0.0, "max": 49.99, "label": "Critical"}
    },
    "director": {
        "excellent": {"min": 75.0, "max": 90.0, "label": "Excellent"},
        "good": {"min": 65.0, "max": 74.99, "label": "Good"},
        "monitor": {"min": 50.0, "max": 64.99, "label": "Monitor"},
        "critical": {"min": 0.0, "max": 49.99, "label": "Critical"}
    },
    "auditor_manager": {
        "excellent": {"min": 70.0, "max": 85.0, "label": "Excellent"},
        "good": {"min": 55.0, "max": 69.99, "label": "Good"},
        "monitor": {"min": 40.0, "max": 54.99, "label": "Monitor"},
        "critical": {"min": 0.0, "max": 39.99, "label": "Critical"}
    }
}


def evaluate_staff_utilization(utilization_pct: float, role: str, peer_avg: Optional[float] = None) -> Dict[str, Any]:
    """
    Evaluate staff utilization with tentative thresholds and peer comparison.
    
    Per requirements: "AI to assess and determine the reasonable threshold by comparing managers/auditors"
    
    Args:
        utilization_pct: Staff utilization percentage
        role: Role context (manager, director, auditor_manager)
        peer_avg: Optional peer average for comparison
        
    Returns:
        Dict with evaluation status and message
    """
    thresholds = STAFF_UTILIZATION_THRESHOLDS.get(role, STAFF_UTILIZATION_THRESHOLDS["manager"])
    
    # Determine status based on thresholds
    status = "unknown"
    label = "Unknown"
    
    for threshold_status, threshold_config in thresholds.items():
        if threshold_config["min"] <= utilization_pct <= threshold_config["max"]:
            status = threshold_status
            label = threshold_config["label"]
            break
    
    # Build message
    message = f"Staff utilization at {utilization_pct:.1f}% ({label})"
    
    # Add peer comparison if available
    if peer_avg is not None and peer_avg > 0:
        variance_pct = ((utilization_pct - peer_avg) / peer_avg) * 100
        message += f" vs peer average {peer_avg:.1f}% ({variance_pct:+.1f}%)"
    
    return {
        "status": status,
        "label": label,
        "message": message,
        "utilization_pct": utilization_pct,
        "peer_avg": peer_avg,
        "note": "Tentative thresholds - subject to data-driven refinement"
    }


def compare_takt_vs_cycle_time(cycle_time_avg: float, takt_time: float) -> Dict[str, Any]:
    """
    Compare Takt Time vs Cycle Time Average for flow analysis.
    
    Per requirements: "If Takt time is less than Cycle time average this is something to note."
    
    Takt Time: How fast work needs to be completed to keep up with demand
    Cycle Time: How fast work is actually being completed
    
    Args:
        cycle_time_avg: Average cycle time (actual completion speed)
        takt_time: Takt time (required completion speed to meet demand)
        
    Returns:
        Dict with flow analysis
    """
    if takt_time == 0:
        return {
            "status": "unknown",
            "message": "Cannot compare - takt time is zero"
        }
    
    # Calculate the gap
    time_gap = cycle_time_avg - takt_time
    gap_pct = (time_gap / takt_time) * 100
    
    # Evaluate flow health
    if takt_time < cycle_time_avg:
        # CRITICAL: Work is being completed slower than demand requires
        status = "critical"
        message = (
            f"Flow constraint detected: Cycle time ({cycle_time_avg:.1f}) exceeds takt time ({takt_time:.1f}). "
            f"Work is being completed {gap_pct:.1f}% slower than demand requires, risking SLA misses and backlog growth."
        )
    elif cycle_time_avg <= takt_time * 0.9:
        # GOOD: Healthy buffer, completing work faster than demand
        status = "good"
        message = (
            f"Healthy flow: Cycle time ({cycle_time_avg:.1f}) is {abs(gap_pct):.1f}% faster than takt time ({takt_time:.1f}). "
            f"Capacity available to absorb demand spikes."
        )
    else:
        # MONITOR: Close to demand, limited buffer
        status = "monitor"
        message = (
            f"Tight flow: Cycle time ({cycle_time_avg:.1f}) is close to takt time ({takt_time:.1f}), "
            f"with only {abs(gap_pct):.1f}% buffer. Limited capacity for demand variation."
        )
    
    return {
        "status": status,
        "message": message,
        "cycle_time_avg": cycle_time_avg,
        "takt_time": takt_time,
        "time_gap": round(time_gap, 2),
        "gap_pct": round(gap_pct, 1),
        "flow_health": status
    }
