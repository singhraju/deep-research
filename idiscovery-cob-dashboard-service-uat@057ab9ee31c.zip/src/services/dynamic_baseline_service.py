"""
Dynamic Baseline Service for Manager-Based Team Averages.

This module provides functionality to calculate dynamic baseline targets
based on manager team performance, specifically for cycle time averaging
across all frontline associates under the same manager.
"""

import logging
from typing import Dict, Any, Optional, List
from db import SnowflakeConnectionManager
from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

logger = logging.getLogger(__name__)

connection_manager = SnowflakeConnectionManager()

# Query to get all frontline associates under a specific manager
GET_MANAGER_TEAM_QUERY = f"""
SELECT DISTINCT 
    PYRESOLVEDUSERID as associate_id,
    USERNAME as associate_name
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
WHERE REPORTTOMANAGERID = %s
    AND PYRESOLVEDUSERID IS NOT NULL
    AND USERNAME IS NOT NULL
"""

# Query to calculate team average cycle time for a manager's associates
MANAGER_TEAM_CYCLE_TIME_QUERY = f"""
WITH invntry_deduped AS (
    SELECT 
        PYID,
        PYRESOLVEDUSERID,
        CYCLE_TIME,
        REPORTTOMANAGERID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IN ('Resolved-Completed', 'Resolved-AutoCloseLink')
      AND PYRESOLVEDTIMESTAMP IS NOT NULL
      AND REPORTTOMANAGERID = %s
      AND CYCLE_TIME IS NOT NULL
      {{date_filter}}
      {{lob_filter}}
),
team_associates AS (
    SELECT DISTINCT PYRESOLVEDUSERID
    FROM invntry_deduped
    WHERE rn = 1
)
SELECT 
    COUNT(DISTINCT i.PYID) AS total_team_items,
    COUNT(DISTINCT i.PYRESOLVEDUSERID) AS team_size,
    ROUND(AVG(i.CYCLE_TIME), 2) AS avg_team_cycle_time_seconds,
    ROUND(AVG(i.CYCLE_TIME) / 60, 2) AS avg_team_cycle_time_minutes
FROM invntry_deduped i
WHERE i.rn = 1
"""

# Query to get manager ID for a frontline associate
GET_ASSOCIATE_MANAGER_QUERY = f"""
SELECT DISTINCT 
    REPORTTOMANAGERID as manager_id,
    REPORTTOMANAGERNAME as manager_name
FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
WHERE PYRESOLVEDUSERID = %s
    AND REPORTTOMANAGERID IS NOT NULL
    AND MANAGERNAME IS NOT NULL
LIMIT 1
"""


class DynamicBaselineService:
    """Service for calculating dynamic baseline targets based on team performance."""
    
    def __init__(self):
        self.connection_manager = connection_manager
    
    async def get_associate_manager(self, associate_id: str) -> Optional[Dict[str, str]]:
        """
        Get the manager information for a frontline associate.
        
        Args:
            associate_id: The frontline associate's user ID
            
        Returns:
            Dict with manager_id and manager_name, or None if not found
        """
        try:
            async with self.connection_manager.get_connection() as engine:
                result = await engine.fetch_all(
                    query=GET_ASSOCIATE_MANAGER_QUERY,
                    values=[associate_id]
                )
                
                if result:
                    return {
                        "manager_id": result[0]["manager_id"],
                        "manager_name": result[0]["manager_name"]
                    }
                return None
                
        except Exception as e:
            logger.error(f"Error getting manager for associate {associate_id}: {str(e)}")
            return None
    
    async def get_manager_team_members(self, manager_id: str) -> List[Dict[str, str]]:
        """
        Get all frontline associates under a specific manager.
        
        Args:
            manager_id: The manager's user ID
            
        Returns:
            List of dicts with associate_id and associate_name
        """
        try:
            async with self.connection_manager.get_connection() as engine:
                result = await engine.fetch_all(
                    query=GET_MANAGER_TEAM_QUERY,
                    values=[manager_id]
                )
                
                return [
                    {
                        "associate_id": row["associate_id"],
                        "associate_name": row["associate_name"]
                    }
                    for row in result
                ]
                
        except Exception as e:
            logger.error(f"Error getting team members for manager {manager_id}: {str(e)}")
            return []
    
    async def calculate_manager_team_cycle_time_average(
        self, 
        manager_id: str, 
        start_date: str, 
        end_date: str,
        lob: Optional[List[str]] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Calculate the average cycle time for all frontline associates under a manager.
        
        Args:
            manager_id: The manager's user ID
            start_date: Start date for the calculation period
            end_date: End date for the calculation period
            lob: Optional list of LOBs to filter by
            
        Returns:
            Dict with team cycle time statistics or None if calculation fails
        """
        try:
            # Build date filter
            date_filter = f"AND DATE(PYRESOLVEDTIMESTAMP) BETWEEN '{start_date}' AND '{end_date}'"
            
            # Build LOB filter
            lob_filter = ""
            if lob and lob != ["All"]:
                lob_list = "', '".join(lob)
                lob_filter = f"AND LOB IN ('{lob_list}')"
            
            # Format the query with filters
            query = MANAGER_TEAM_CYCLE_TIME_QUERY.format(
                date_filter=date_filter,
                lob_filter=lob_filter
            )
            
            async with self.connection_manager.get_connection() as engine:
                result = await engine.fetch_all(
                    query=query,
                    values=[manager_id]
                )
                
                if result and result[0]["total_team_items"] > 0:
                    row = result[0]
                    return {
                        "manager_id": manager_id,
                        "total_team_items": int(row["total_team_items"]),
                        "team_size": int(row["team_size"]),
                        "avg_cycle_time_seconds": float(row["avg_team_cycle_time_seconds"]),
                        "avg_cycle_time_minutes": float(row["avg_team_cycle_time_minutes"]),
                        "period": f"{start_date} to {end_date}",
                        "lob": lob or ["All"]
                    }
                
                logger.warning(f"No cycle time data found for manager {manager_id} team")
                return None
                
        except Exception as e:
            logger.error(f"Error calculating team cycle time average for manager {manager_id}: {str(e)}")
            return None
    
    async def get_dynamic_cycle_time_baseline(
        self, 
        associate_id: str, 
        start_date: str, 
        end_date: str,
        lob: Optional[List[str]] = None
    ) -> Optional[float]:
        """
        Get dynamic cycle time baseline for a frontline associate based on their manager's team average.
        
        Args:
            associate_id: The frontline associate's user ID
            start_date: Start date for baseline calculation
            end_date: End date for baseline calculation
            lob: Optional list of LOBs to filter by
            
        Returns:
            Average cycle time in minutes for the associate's manager's team, or None if not available
        """
        try:
            # Step 1: Get the associate's manager
            manager_info = await self.get_associate_manager(associate_id)
            if not manager_info:
                logger.warning(f"No manager found for associate {associate_id}")
                return None
            
            manager_id = manager_info["manager_id"]
            logger.info(f"Found manager {manager_id} for associate {associate_id}")
            
            # Step 2: Calculate team average cycle time
            team_stats = await self.calculate_manager_team_cycle_time_average(
                manager_id, start_date, end_date, lob
            )
            
            if team_stats:
                avg_minutes = team_stats["avg_cycle_time_minutes"]
                logger.info(
                    f"Dynamic baseline for {associate_id}: {avg_minutes} min "
                    f"(based on {team_stats['team_size']} team members, "
                    f"{team_stats['total_team_items']} items)"
                )
                return avg_minutes
            
            logger.warning(f"Could not calculate team average for manager {manager_id}")
            return None
            
        except Exception as e:
            logger.error(f"Error getting dynamic cycle time baseline for {associate_id}: {str(e)}")
            return None


# Global instance
dynamic_baseline_service = DynamicBaselineService()


async def get_dynamic_baseline_for_associate(
    associate_id: str, 
    start_date: str, 
    end_date: str,
    lob: Optional[List[str]] = None
) -> Optional[float]:
    """
    Convenience function to get dynamic cycle time baseline for an associate.
    
    Args:
        associate_id: The frontline associate's user ID
        start_date: Start date for baseline calculation
        end_date: End date for baseline calculation
        lob: Optional list of LOBs to filter by
        
    Returns:
        Average cycle time in minutes for the associate's manager's team
    """
    return await dynamic_baseline_service.get_dynamic_cycle_time_baseline(
        associate_id, start_date, end_date, lob
    )
