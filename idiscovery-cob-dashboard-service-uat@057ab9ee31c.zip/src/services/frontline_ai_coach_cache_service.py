import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import config
from services.metric_cache_service import metric_cache_service
from utils.cache_key_builder import build_filters_hash
from utils.redis_cache import cache_manager

logger = logging.getLogger(__name__)


class FrontlineAICoachCacheService:
    def __init__(self):
        self.cache_manager = cache_manager
        self.metric_cache_service = metric_cache_service
        self.enabled = config.REDIS_ENABLED and config.SESSION_CACHE_ENABLED
        self.ttl = config.SESSION_CACHE_TTL

    @staticmethod
    def build_filters(
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        return {
            "user_id": user_id,
            "start_date": start_date,
            "end_date": end_date,
            "lob": lob,
        }

    @staticmethod
    def _model_to_dict(value: Any) -> Any:
        if value is None:
            return None
        if hasattr(value, "model_dump"):
            return value.model_dump()
        if hasattr(value, "dict"):
            return value.dict()
        return value

    def get_filters_hash(
        self,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]] = None,
    ) -> str:
        return build_filters_hash(**self.build_filters(user_id, start_date, end_date, lob))

    def build_artifact_key(self, session_id: str, filters_hash: str, artifact_name: str) -> str:
        return f"session:{session_id}:{filters_hash}:{artifact_name}"

    async def get_artifact(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]],
        artifact_name: str,
    ) -> Optional[Any]:
        if not self.enabled or not session_id:
            return None

        filters_hash = self.get_filters_hash(user_id, start_date, end_date, lob)
        cache_key = self.build_artifact_key(session_id, filters_hash, artifact_name)
        return await self.cache_manager.get(cache_key)

    async def set_artifact(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]],
        artifact_name: str,
        value: Any,
    ) -> None:
        if not self.enabled or not session_id:
            return

        filters_hash = self.get_filters_hash(user_id, start_date, end_date, lob)
        cache_key = self.build_artifact_key(session_id, filters_hash, artifact_name)
        await self.cache_manager.set(cache_key, value, ttl=self.ttl)

    async def get_cached_frontline_ai_coach_context(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]] = None,
    ) -> Optional[Dict[str, Any]]:
        context = await self.get_artifact(
            session_id,
            user_id,
            start_date,
            end_date,
            lob,
            "frontline_ai_coach_context",
        )
        return context if isinstance(context, dict) else None

    async def get_cached_production_gauge_response(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]] = None,
    ) -> Optional[Dict[str, Any]]:
        response = await self.get_artifact(
            session_id,
            user_id,
            start_date,
            end_date,
            lob,
            "production_percentage_gauge",
        )
        return response if isinstance(response, dict) else None

    async def get_cached_production_pct(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]] = None,
    ) -> Optional[float]:
        if not self.enabled or not session_id:
            return None

        filters_hash = self.get_filters_hash(user_id, start_date, end_date, lob)
        value = await self.metric_cache_service.get_metric(session_id, "production_pct", filters_hash)
        if value is None:
            return None

        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    async def get_cached_manager_lookup(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]] = None,
    ) -> Optional[Dict[str, str]]:
        manager_info = await self.get_artifact(
            session_id,
            user_id,
            start_date,
            end_date,
            lob,
            "frontline_manager_lookup",
        )
        return manager_info if isinstance(manager_info, dict) else None

    async def get_cached_team_averages(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]] = None,
    ) -> Dict[str, float]:
        team_averages = await self.get_artifact(
            session_id,
            user_id,
            start_date,
            end_date,
            lob,
            "frontline_team_averages",
        )
        return team_averages if isinstance(team_averages, dict) else {}

    async def get_cached_baseline_goals(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        baseline_goals = await self.get_artifact(
            session_id,
            user_id,
            start_date,
            end_date,
            lob,
            "frontline_baseline_goals",
        )
        return baseline_goals if isinstance(baseline_goals, dict) else {}

    async def cache_production_gauge_response(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]],
        response: Any,
    ) -> None:
        if not self.enabled or not session_id:
            return

        response_dict = self._model_to_dict(response)
        if not isinstance(response_dict, dict):
            return

        await self.set_artifact(
            session_id,
            user_id,
            start_date,
            end_date,
            lob,
            "production_percentage_gauge",
            response_dict,
        )

        filters_hash = self.get_filters_hash(user_id, start_date, end_date, lob)
        production_pct = response_dict.get("production_percentage_achieved")
        if production_pct is not None:
            await self.metric_cache_service.set_metric(
                production_pct,
                session_id,
                "production_pct",
                filters_hash,
                ttl=self.ttl,
            )

    async def warm_user_metrics_dependencies(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]],
        user_metrics_response: Any,
    ) -> Dict[str, Any]:
        if not self.enabled or not session_id:
            return {}

        from services.baseline_kpi_config import get_baseline_targets
        from services.dynamic_baseline_service import dynamic_baseline_service
        from services.metrics_aggregator import calculate_team_averages

        manager_info = await self.get_cached_manager_lookup(session_id, user_id, start_date, end_date, lob)
        if manager_info is None:
            manager_info = await dynamic_baseline_service.get_associate_manager(user_id)
            if manager_info:
                await self.set_artifact(
                    session_id,
                    user_id,
                    start_date,
                    end_date,
                    lob,
                    "frontline_manager_lookup",
                    manager_info,
                )

        team_averages = await self.get_cached_team_averages(session_id, user_id, start_date, end_date, lob)
        if not team_averages and manager_info and manager_info.get("manager_id"):
            team_averages = await calculate_team_averages(
                manager_id=manager_info["manager_id"],
                start_date=start_date,
                end_date=end_date,
                lob=lob,
                session_id=session_id,
            )
            if team_averages:
                await self.set_artifact(
                    session_id,
                    user_id,
                    start_date,
                    end_date,
                    lob,
                    "frontline_team_averages",
                    team_averages,
                )

        baseline_goals = await self.get_cached_baseline_goals(session_id, user_id, start_date, end_date, lob)
        if not baseline_goals:
            baseline_goals = get_baseline_targets("frontline")
            if baseline_goals:
                await self.set_artifact(
                    session_id,
                    user_id,
                    start_date,
                    end_date,
                    lob,
                    "frontline_baseline_goals",
                    baseline_goals,
                )

        return await self.upsert_frontline_ai_coach_context(
            session_id=session_id,
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            lob=lob,
            user_metrics_response=user_metrics_response,
            manager_info=manager_info,
            team_averages=team_averages,
            baseline_goals=baseline_goals,
        )

    async def upsert_frontline_ai_coach_context(
        self,
        session_id: str,
        user_id: str,
        start_date: str,
        end_date: str,
        lob: Optional[List[str]],
        user_metrics_response: Any = None,
        production_gauge_response: Any = None,
        manager_info: Optional[Dict[str, str]] = None,
        team_averages: Optional[Dict[str, float]] = None,
        baseline_goals: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if not self.enabled or not session_id:
            return {}

        context = await self.get_cached_frontline_ai_coach_context(
            session_id,
            user_id,
            start_date,
            end_date,
            lob,
        ) or {
            "user_id": user_id,
            "start_date": start_date,
            "end_date": end_date,
            "lob": lob or ["ALL"],
            "data_gaps": [],
        }

        if user_metrics_response is not None:
            context["user_metrics"] = self._model_to_dict(user_metrics_response)

        if production_gauge_response is not None:
            response_dict = self._model_to_dict(production_gauge_response)
            if isinstance(response_dict, dict):
                context["production_percentage_gauge"] = response_dict
                context["production_pct"] = response_dict.get("production_percentage_achieved")
                await self.cache_production_gauge_response(
                    session_id,
                    user_id,
                    start_date,
                    end_date,
                    lob,
                    production_gauge_response,
                )

        if manager_info is not None:
            context["manager_info"] = manager_info
            await self.set_artifact(
                session_id,
                user_id,
                start_date,
                end_date,
                lob,
                "frontline_manager_lookup",
                manager_info,
            )

        if team_averages is not None:
            context["team_averages"] = team_averages
            await self.set_artifact(
                session_id,
                user_id,
                start_date,
                end_date,
                lob,
                "frontline_team_averages",
                team_averages,
            )

        if baseline_goals is not None:
            context["baseline_goals"] = baseline_goals
            await self.set_artifact(
                session_id,
                user_id,
                start_date,
                end_date,
                lob,
                "frontline_baseline_goals",
                baseline_goals,
            )

        now = datetime.now(timezone.utc)
        completeness = "full" if all(
            context.get(field)
            for field in (
                "user_metrics",
                "manager_info",
                "team_averages",
                "baseline_goals",
                "production_percentage_gauge",
            )
        ) else "partial"

        context["metadata"] = {
            "cached_at": now.isoformat(),
            "expires_at": (now + timedelta(seconds=self.ttl)).isoformat(),
            "bundle_completeness": completeness,
            "filters_hash": self.get_filters_hash(user_id, start_date, end_date, lob),
        }

        await self.set_artifact(
            session_id,
            user_id,
            start_date,
            end_date,
            lob,
            "frontline_ai_coach_context",
            context,
        )
        return context


frontline_ai_coach_cache_service = FrontlineAICoachCacheService()
