"""
Metric-Level Cache Service for Director Core APIs with Session Support

This service provides fine-grained caching at the SQL query/metric level within sessions.
Each individual metric (e.g., work_items_completed, audit_score, production_pct)
is cached separately with its own cache key scoped to a session_id and filters.

Only applies to the 6 core Director APIs:
- header-kpis
- operational-flow
- demand-inventory
- quality-outcomes
- associate-utilization
- sla-health

Cache Key Format: session:{session_id}:{filters_hash}:{metric_name}
"""

import logging
import asyncio
from typing import Any, Optional, Callable, List, Dict

from utils.redis_cache import cache_manager
from utils.cache_key_builder import build_filters_hash
import config

logger = logging.getLogger(__name__)


class MetricCacheService:
    """Manages session-based metric-level caching for Director core APIs."""
    
    def __init__(self):
        self.cache_manager = cache_manager
        self.enabled = config.REDIS_ENABLED
        self.ttl = config.METRIC_CACHE_TTL if hasattr(config, 'METRIC_CACHE_TTL') else 3600  # 1 hour default
        logger.info(f"Metric cache service initialized (enabled: {self.enabled}, TTL: {self.ttl}s)")
    
    def build_metric_key(
        self, 
        session_id: str, 
        metric_name: str,
        filters_hash: Optional[str] = None
    ) -> str:
        """Build cache key for a specific metric within a session.
        
        Args:
            session_id: Session identifier
            metric_name: Name of the metric (e.g., 'work_items_completed', 'audit_score')
            filters_hash: Optional hash of filter parameters for cache isolation
            
        Returns:
            Cache key in format: session:session_id:filters_hash:metric_name
            or session:session_id:metric_name (if no filters_hash provided)
        """
        if filters_hash:
            return f"session:{session_id}:{filters_hash}:{metric_name}"
        else:
            # Backward compatibility: no filters hash
            return f"session:{session_id}:{metric_name}"
    
    async def get_metric(
        self, 
        session_id: str, 
        metric_name: str,
        filters_hash: Optional[str] = None
    ) -> Optional[Any]:
        """Get cached metric value from session.
        
        Args:
            session_id: Session identifier
            metric_name: Name of the metric
            filters_hash: Optional hash of filter parameters
            
        Returns:
            Cached value or None if not found
        """
        if not self.enabled:
            return None
        
        try:
            cache_key = self.build_metric_key(session_id, metric_name, filters_hash)
            value = await self.cache_manager.get(cache_key)
            
            if value is not None:
                logger.debug(f"Metric cache hit: session={session_id}, filters={filters_hash}, {metric_name}")
            else:
                logger.debug(f"Metric cache miss: session={session_id}, filters={filters_hash}, {metric_name}")
            
            return value
        except Exception as e:
            logger.error(f"Error getting metric {metric_name} for session {session_id}: {e}")
            return None
    
    async def set_metric(
        self, 
        value: Any, 
        session_id: str, 
        metric_name: str, 
        filters_hash: Optional[str] = None,
        ttl: Optional[int] = None
    ) -> None:
        """Set metric value in cache for session.
        
        Args:
            value: Value to cache
            session_id: Session identifier
            metric_name: Name of the metric
            filters_hash: Optional hash of filter parameters
            ttl: Time-to-live in seconds (uses default if None)
        """
        if not self.enabled:
            return
        
        try:
            cache_key = self.build_metric_key(session_id, metric_name, filters_hash)
            cache_ttl = ttl if ttl is not None else self.ttl
            
            await self.cache_manager.set(cache_key, value, ttl=cache_ttl)
            logger.debug(f"Metric cached: session={session_id}, filters={filters_hash}, {metric_name} (TTL: {cache_ttl}s)")
        except Exception as e:
            logger.error(f"Error setting metric {metric_name} for session {session_id}: {e}")
    
    async def get_or_fetch_metric(
        self,
        fetch_func: Callable,
        session_id: str,
        metric_name: str,
        filters: Optional[Dict[str, Any]] = None,
        ttl: Optional[int] = None,
        max_retries: int = 3
    ) -> Any:
        """Cache-aside pattern for metrics with retry logic for resilience.
        
        ENHANCED: Adds retry logic for cache operations to handle transient failures
        under high concurrency. If cache operations fail, still returns data.
        Now supports filter-aware caching for proper cache isolation.
        
        Args:
            fetch_func: Function to fetch metric if not cached (can be sync or async)
            session_id: Session identifier
            metric_name: Name of the metric
            filters: Optional dictionary of filter parameters for cache isolation
            ttl: Time-to-live in seconds (uses default if None)
            max_retries: Maximum retry attempts for cache operations (default: 3)
            
        Returns:
            Metric value (from cache or fetched)
        """
        # Generate filters hash if filters provided
        filters_hash = None
        if filters:
            filters_hash = build_filters_hash(**filters)
            logger.debug(f"Generated filters hash: {filters_hash} for metric: {metric_name}")
        
        # Try cache first with retries
        for attempt in range(max_retries):
            try:
                cached = await self.get_metric(session_id, metric_name, filters_hash)
                if cached is not None:
                    return cached
                break  # Cache miss - proceed to fetch
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Cache get retry {attempt+1}/{max_retries} for {metric_name}: {e}")
                    await asyncio.sleep(0.1 * (attempt + 1))  # Exponential backoff
                else:
                    logger.error(f"Cache get failed after {max_retries} retries for {metric_name}: {e}")
                    # Continue to fetch data even if cache read fails
                    break
        
        # Cache miss or error - fetch data
        logger.debug(f"Fetching metric: session={session_id}, filters={filters_hash}, {metric_name}")
        
        # Support both sync and async fetch functions
        if asyncio.iscoroutinefunction(fetch_func):
            data = await fetch_func()
        else:
            data = fetch_func()
        
        # Store in cache with retries (best effort)
        for attempt in range(max_retries):
            try:
                await self.set_metric(data, session_id, metric_name, filters_hash, ttl=ttl)
                break  # Success - exit retry loop
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Cache set retry {attempt+1}/{max_retries} for {metric_name}: {e}")
                    await asyncio.sleep(0.1 * (attempt + 1))  # Exponential backoff
                else:
                    logger.error(f"Cache set failed after {max_retries} retries for {metric_name}: {e}")
                    # Don't fail the request - data is already fetched
                    logger.warning(f"Continuing without caching {metric_name} (data still returned)")
        
        return data
    
    async def set_multiple_metrics(
        self,
        metrics: dict,
        session_id: str,
        filters_hash: Optional[str] = None,
        ttl: Optional[int] = None
    ) -> None:
        """Bulk set multiple metrics for same session.
        
        Args:
            metrics: Dictionary mapping metric_name -> value
            session_id: Session identifier
            filters_hash: Optional hash of filter parameters
            ttl: Time-to-live in seconds (uses default if None)
        """
        if not self.enabled or not metrics:
            return
        
        try:
            cache_ttl = ttl if ttl is not None else self.ttl
            
            # Build all cache keys
            cache_items = {}
            for metric_name, value in metrics.items():
                cache_key = self.build_metric_key(session_id, metric_name, filters_hash)
                cache_items[cache_key] = value
            
            # Bulk set
            await self.cache_manager.set_many(cache_items, ttl=cache_ttl)
            logger.debug(f"Bulk cached {len(metrics)} metrics for session={session_id}, filters={filters_hash}")
        except Exception as e:
            logger.error(f"Error bulk setting metrics in session {session_id}: {e}")
    
    async def get_multiple_metrics(
        self,
        metric_names: List[str],
        session_id: str,
        filters_hash: Optional[str] = None
    ) -> dict:
        """Bulk get multiple metrics for same session.
        
        Args:
            metric_names: List of metric names to retrieve
            session_id: Session identifier
            filters_hash: Optional hash of filter parameters
            
        Returns:
            Dictionary mapping metric_name -> value (None for cache misses)
        """
        if not self.enabled or not metric_names:
            return dict.fromkeys(metric_names, None)
        
        try:
            # Build all cache keys
            cache_keys = []
            key_to_metric = {}
            for metric_name in metric_names:
                cache_key = self.build_metric_key(session_id, metric_name, filters_hash)
                cache_keys.append(cache_key)
                key_to_metric[cache_key] = metric_name
            
            # Bulk get
            cache_results = await self.cache_manager.get_many(cache_keys)
            
            # Map back to metric names
            results = {}
            for cache_key, value in cache_results.items():
                metric_name = key_to_metric[cache_key]
                results[metric_name] = value
            
            hit_count = sum(1 for v in results.values() if v is not None)
            logger.debug(f"Bulk get: {hit_count}/{len(metric_names)} metric hits for session={session_id}, filters={filters_hash}")
            
            return results
        except Exception as e:
            logger.error(f"Error bulk getting metrics in session {session_id}: {e}")
            return dict.fromkeys(metric_names, None)
    
    async def invalidate_metric(
        self, 
        session_id: str, 
        metric_name: str,
        filters_hash: Optional[str] = None
    ) -> None:
        """Invalidate specific metric in session.
        
        Args:
            session_id: Session identifier
            metric_name: Name of the metric
            filters_hash: Optional hash of filter parameters
        """
        if not self.enabled:
            return
        
        try:
            cache_key = self.build_metric_key(session_id, metric_name, filters_hash)
            await self.cache_manager.delete(cache_key)
            logger.info(f"Invalidated metric: session={session_id}, filters={filters_hash}, {metric_name}")
        except Exception as e:
            logger.error(f"Error invalidating metric {metric_name} in session {session_id}: {e}")
    
    async def invalidate_session_metrics(self, session_id: str) -> None:
        """Invalidate all metrics for a session.
        
        Args:
            session_id: Session identifier
        """
        if not self.enabled:
            return
        
        try:
            pattern = f"session:{session_id}:*"
            await self.cache_manager.invalidate_pattern(pattern)
            logger.info(f"Invalidated all metrics for session={session_id}")
        except Exception as e:
            logger.error(f"Error invalidating session metrics for {session_id}: {e}")
    
    async def invalidate_all_sessions(self) -> None:
        """Invalidate all cached metrics across all sessions."""
        if not self.enabled:
            return
        
        try:
            pattern = "session:*"
            await self.cache_manager.invalidate_pattern(pattern)
            logger.info("Invalidated all session metrics")
        except Exception as e:
            logger.error(f"Error invalidating all session metrics: {e}")


# Singleton instance
metric_cache_service = MetricCacheService()
