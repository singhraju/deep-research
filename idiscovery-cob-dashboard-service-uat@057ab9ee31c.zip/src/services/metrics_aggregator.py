import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
logger = logging.getLogger(__name__)


async def _lookup_associate_name(user_id: str) -> Optional[str]:
    """
    Look up a single associate's full name from COB_AI_USER_PROFILE.
    Returns None if not found or on any error, so callers can fall back to user_id.
    """
    try:
        from db import SnowflakeConnectionManager
        from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
        engine = SnowflakeConnectionManager().get_engine()
        query = (
            f"SELECT TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS full_name "
            f"FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE "
            f"WHERE USERID = '{user_id}' LIMIT 1"
        )
        result = await engine.execute_query_async(query, limit=1)
        if result:
            name = (result[0].get("FULL_NAME") or "").strip()
            return name if name else None
    except Exception:
        logger.debug(f"Name lookup failed for {user_id}, falling back to user ID")
    return None

def parse_cycle_time_to_seconds(value: Optional[str]) -> float:
    if not value or value == "N/A":
        return 0.0
    text = str(value).strip()
    try:
        if ":" in text and text.count(":") == 2:
            hours_str, minutes_str, seconds_str = text.split(":")
            return (int(hours_str) * 3600) + (int(minutes_str) * 60) + float(seconds_str)
        lowered = text.lower().replace(".", "")
        total_seconds = 0.0
        if "mins" in lowered or "min" in lowered:
            minutes_part = lowered.split("min")[0].strip().split()[-1]
            total_seconds += float(minutes_part) * 60
        if "secs" in lowered or "sec" in lowered:
            seconds_part = lowered.split("sec")[0].strip().split()[-1]
            total_seconds += float(seconds_part)
        return total_seconds
    except (TypeError, ValueError, IndexError):
        logger.warning(f"Unable to parse cycle time value: {value}")
        return 0.0

async def fetch_frontline_metrics(
    user_id: str,
    start_date: str,
    end_date: str,
    lob: Optional[List[str]] = None,
    session_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch and aggregate metrics for frontline associate with team averages and goals.
    Uses session_id to retrieve cached data from Redis.
    ENHANCED: Now includes team averages, goals, and nested structure for AI Coach v2.0
    Args:
        user_id: User identifier
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        lob: Optional list of LOBs
        session_id: Session ID for Redis cache retrieval
    Returns:
        Dict containing enriched metrics with team averages and goals:
        {
            "user_id": "AF12345",
            "date_range": "2026-03-01 to 2026-03-31",
            "lob": ["Commercial"],
            "metrics": {
                "audit_score_pct": {
                    "value": 97.5,
                    "goal": 98.0,
                    "team_avg": 99.52
                },
                ...
            },
            "data_gaps": ["audit_error_count"]
        }
    """
    try:
        from controllers.Performance_IQ.user_metrics import get_user_metrics
        from controllers.Performance_IQ.production_percentage_gauge import get_production_percentage_gauge
        from schema import UserMetricsRequest, ProductionPercentageGaugeRequest
        from services.baseline_kpi_config import get_baseline_targets
        from services.dynamic_baseline_service import dynamic_baseline_service
        from services.frontline_ai_coach_cache_service import frontline_ai_coach_cache_service
        cached_context = None
        if session_id:
            cached_context = await frontline_ai_coach_cache_service.get_cached_frontline_ai_coach_context(
                session_id=session_id,
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob=lob,
            )
            if cached_context and cached_context.get("metrics"):
                return cached_context
        # 1. Get base user metrics
        request = UserMetricsRequest(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            lob=lob,
            session_id=session_id,
            warm_ai_coach_context=not bool(session_id),
        )
        response = await get_user_metrics(request)
        if getattr(response, "status", None) != "success":
            raise ValueError(getattr(response, "message", "Failed to retrieve user metrics"))
        # 1b. Get production percentage from separate API
        production_pct = None
        prod_response = None
        if session_id:
            production_pct = await frontline_ai_coach_cache_service.get_cached_production_pct(
                session_id=session_id,
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob=lob,
            )
        if production_pct is None:
            prod_request = ProductionPercentageGaugeRequest(
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob=lob,
                session_id=session_id
            )
            try:
                prod_response = await get_production_percentage_gauge(prod_request)
                production_pct = (
                    prod_response.production_percentage_achieved
                    if prod_response and getattr(prod_response, "status", None) == "success"
                    else None
                )
            except Exception as e:
                logger.warning(f"Could not fetch production percentage for {user_id}: {str(e)}")
                production_pct = None
        # 2. Get manager info for team averages
        manager_info = None
        if session_id:
            manager_info = await frontline_ai_coach_cache_service.get_cached_manager_lookup(
                session_id=session_id,
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob=lob,
            )
        if manager_info is None:
            manager_info = await dynamic_baseline_service.get_associate_manager(user_id)
        # 3. Calculate team averages if manager found
        team_averages = {}
        if session_id:
            team_averages = await frontline_ai_coach_cache_service.get_cached_team_averages(
                session_id=session_id,
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob=lob,
            )
        if manager_info:
            if not team_averages:
                logger.info(f"Calculating team averages for user {user_id} under manager {manager_info['manager_id']}")
                team_averages = await calculate_team_averages(
                    manager_id=manager_info["manager_id"],
                    start_date=start_date,
                    end_date=end_date,
                    lob=lob,
                    session_id=session_id,
                )
        else:
            logger.warning(f"No manager found for user {user_id}, skipping team averages")
        # 4. Get baseline goals
        goals = {}
        if session_id:
            goals = await frontline_ai_coach_cache_service.get_cached_baseline_goals(
                session_id=session_id,
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob=lob,
            )
        if not goals:
            goals = get_baseline_targets("frontline")
        # 5. Build enriched structure
        enriched = {
            "user_id": user_id,
            "date_range": f"{start_date} to {end_date}",
            "lob": lob or ["ALL"],
            "metrics": {},
            "data_gaps": []
        }
        # Parse and enrich Audit Score
        if response.audit_score_percentage and response.audit_score_percentage != "N/A":
            try:
                audit_value = float(response.audit_score_percentage.rstrip('%'))
                enriched["metrics"]["audit_score_pct"] = {
                    "value": audit_value,
                    "goal": goals["audit_score"]["target"],
                    "team_avg": team_averages.get("audit_score")
                }
            except ValueError:
                enriched["data_gaps"].append("audit_score_pct")
        else:
            enriched["data_gaps"].append("audit_score_pct")
        # Parse and enrich Production % (fetched from separate API)
        if production_pct is not None:
            enriched["metrics"]["production_pct"] = {
                "value": production_pct,
                "goal": goals["production_pct"]["target"],
                "team_avg": team_averages.get("production_pct")
            }
        else:
            enriched["data_gaps"].append("production_pct")
        # Parse and enrich Cycle Time
        if response.cycle_time_avg and response.cycle_time_avg != "N/A":
            cycle_seconds = parse_cycle_time_to_seconds(response.cycle_time_avg)
            if cycle_seconds > 0:
                enriched["metrics"]["cycle_time_avg"] = {
                    "value": response.cycle_time_avg,
                    "value_seconds": cycle_seconds,
                    "goal_seconds": goals["cycle_time"]["target_minutes"] * 60,
                    "team_avg_seconds": team_averages.get("cycle_time_seconds")
                }
            else:
                enriched["data_gaps"].append("cycle_time_avg")
        else:
            enriched["data_gaps"].append("cycle_time_avg")
        # Parse and enrich Work Items
        if response.work_items_completed and response.work_items_completed != "N/A":
            try:
                items_value = int(response.work_items_completed)
                enriched["metrics"]["work_items_completed"] = {
                    "value": items_value,
                    "team_avg": team_averages.get("work_items_completed")
                }
            except ValueError:
                enriched["data_gaps"].append("work_items_completed")
        else:
            enriched["data_gaps"].append("work_items_completed")
        # Add audit errors if available
        if response.audit_error_count and response.audit_error_count != "N/A":
            enriched["metrics"]["audit_error_count"] = {
                "value": response.audit_error_count
            }
        else:
            enriched["data_gaps"].append("audit_error_count")
        if session_id:
            await frontline_ai_coach_cache_service.upsert_frontline_ai_coach_context(
                session_id=session_id,
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob=lob,
                user_metrics_response=response,
                production_gauge_response=prod_response,
                manager_info=manager_info,
                team_averages=team_averages,
                baseline_goals=goals,
            )
            await frontline_ai_coach_cache_service.set_artifact(
                session_id=session_id,
                user_id=user_id,
                start_date=start_date,
                end_date=end_date,
                lob=lob,
                artifact_name="frontline_ai_coach_context",
                value=enriched,
            )
        logger.info(f"Enriched metrics for {user_id}: {len(enriched['metrics'])} metrics, {len(enriched['data_gaps'])} gaps")
        return enriched
    except Exception as e:
        logger.error(f"Error fetching frontline metrics for {user_id}: {str(e)}")
        return {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "error": str(e),
            "data_gaps": ["all_metrics"]
        }

async def calculate_team_averages(
    manager_id: str,
    start_date: str,
    end_date: str,
    lob: Optional[List[str]] = None,
    session_id: Optional[str] = None,
) -> Dict[str, float]:
    """
    Calculate team averages for all metrics under a manager.
    Args:
        manager_id: Manager's user ID
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        lob: Optional list of LOBs to filter
        session_id: Session ID for Redis cache retrieval
    Returns:
        Dict with team averages:
        {
            "audit_score": 99.52,
            "production_pct": 122.32,
            "cycle_time_seconds": 582,
            "work_items_completed": 250
        }
    """
    try:
        from controllers.Performance_IQ.user_metrics import get_user_metrics
        from controllers.Performance_IQ.production_percentage_gauge import get_production_percentage_gauge
        from schema import UserMetricsRequest
        from schema import ProductionPercentageGaugeRequest
        from db import SnowflakeConnectionManager
        from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
        # Get all team members under this manager
        connection_manager = SnowflakeConnectionManager()
        query = f"""
        SELECT DISTINCT PYRESOLVEDUSERID as user_id
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        WHERE REPORTTOMANAGERID = %s
          AND PYRESOLVEDUSERID IS NOT NULL
        """
        async with connection_manager.get_connection() as engine:
            team_members = await engine.fetch_all(query=query, values=[manager_id])
        if not team_members:
            logger.warning(f"No team members found for manager {manager_id}")
            return {}
        # Collect metrics from all team members
        team_metrics = {
            "audit_scores": [],
            "production_pcts": [],
            "cycle_times": [],
            "work_items": []
        }
        for member in team_members:
            try:
                request = UserMetricsRequest(
                    user_id=member["user_id"],
                    start_date=start_date,
                    end_date=end_date,
                    lob=lob,
                    session_id=session_id,
                    warm_ai_coach_context=False,
                )
                response = await get_user_metrics(request)
                if getattr(response, "status", None) != "success":
                    continue
                prod_request = ProductionPercentageGaugeRequest(
                    user_id=member["user_id"],
                    start_date=start_date,
                    end_date=end_date,
                    lob=lob,
                    session_id=session_id,
                )
                prod_response = await get_production_percentage_gauge(prod_request)
                # Collect audit score
                if response.audit_score_percentage and response.audit_score_percentage != "N/A":
                    try:
                        audit_val = float(response.audit_score_percentage.rstrip('%'))
                        team_metrics["audit_scores"].append(audit_val)
                    except ValueError:
                        pass
                # Collect production %
                if prod_response and getattr(prod_response, "status", None) == "success":
                    try:
                        prod_val = float(prod_response.production_percentage_achieved)
                        team_metrics["production_pcts"].append(prod_val)
                    except (TypeError, ValueError):
                        pass
                # Collect cycle time
                if response.cycle_time_avg and response.cycle_time_avg != "N/A":
                    cycle_seconds = parse_cycle_time_to_seconds(response.cycle_time_avg)
                    if cycle_seconds > 0:
                        team_metrics["cycle_times"].append(cycle_seconds)
                # Collect work items
                if response.work_items_completed and response.work_items_completed != "N/A":
                    try:
                        items = int(response.work_items_completed)
                        team_metrics["work_items"].append(items)
                    except ValueError:
                        pass
            except Exception as e:
                logger.warning(f"Error fetching metrics for team member {member['user_id']}: {str(e)}")
                continue
        # Calculate averages
        averages = {}
        if team_metrics["audit_scores"]:
            averages["audit_score"] = round(sum(team_metrics["audit_scores"]) / len(team_metrics["audit_scores"]), 2)
        if team_metrics["production_pcts"]:
            averages["production_pct"] = round(sum(team_metrics["production_pcts"]) / len(team_metrics["production_pcts"]), 2)
        if team_metrics["cycle_times"]:
            averages["cycle_time_seconds"] = round(sum(team_metrics["cycle_times"]) / len(team_metrics["cycle_times"]), 2)
        if team_metrics["work_items"]:
            averages["work_items_completed"] = round(sum(team_metrics["work_items"]) / len(team_metrics["work_items"]), 2)
        logger.info(f"Calculated team averages for manager {manager_id}: {averages}")
        return averages
    except Exception as e:
        logger.error(f"Error calculating team averages for manager {manager_id}: {str(e)}")
        return {}

async def fetch_director_metrics(
    user_id: str,
    start_date: str,
    end_date: str,
    director_id: Optional[List[str]] = None,
    manager_id: Optional[List[str]] = None,
    associates_id: Optional[List[str]] = None,
    lob: Optional[List[str]] = None,
    session_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch and aggregate metrics for director.
    Uses session_id to retrieve cached data from Redis.
    Uses associate_utilization API for production_pct to match UI display.
    Args:
        user_id: User identifier
        start_date: Start date
        end_date: End date
        director_id: Optional director IDs
        manager_id: Optional manager IDs
        associates_id: Optional associate IDs
        lob: Optional LOBs
        session_id: Session ID for Redis cache retrieval
    Returns:
        Dict containing aggregated metrics
    """
    try:
        from controllers.Performance_IQ_Director.header_kpis import get_header_kpis
        from controllers.Performance_IQ_Director.associate_utilization import get_associate_utilization
        from schema import DirectorHeaderKPIsRequest, DirectorBaseRequest
        # Get header KPIs (work items, audit score, cycle time)
        header_request = DirectorHeaderKPIsRequest(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            director_ids=director_id,
            manager_ids=manager_id,
            frontline_associate_ids=associates_id,
            lob=lob,
            session_id=session_id
        )
        header_response = await get_header_kpis(header_request)
        # Log raw header response values
        logger.info(f"🔍 Director AI Coach - Header KPIs response: production_pct_achieved={header_response.production_pct_achieved}, "
                   f"audit_score_pct={header_response.audit_score_pct}, work_items={header_response.work_items_completed}")
        # Use Header KPIs values directly (they already provide correct aggregated values)
        production_pct = header_response.production_pct_achieved or 0.0
        audit_score = header_response.audit_score_pct or 0.0
        # Log final values being used
        logger.info(f"✅ Director AI Coach FINAL metrics: production_pct={production_pct}, audit_score={audit_score}, "
                   f"work_items={header_response.work_items_completed}, "
                   f"filters: directors={director_id}, managers={manager_id}, associates={associates_id}, "
                   f"lob={lob}, session_id={session_id}")
        metrics = {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "scope": {
                "directors": len(director_id) if director_id else "All",
                "managers": len(manager_id) if manager_id else "All",
                "associates": len(associates_id) if associates_id else "All",
                "lob": lob or ["All"]
            },
            "work_items_completed": header_response.work_items_completed or 0,
            "production_pct": f"{production_pct}%",
            "audit_score": f"{audit_score}%",
            "cycle_time": header_response.cycle_time_avg or "N/A",
            "takt_time": header_response.takt_time or "N/A",
            "volume_forecast_accuracy": header_response.volume_forecast_accuracy or "N/A"
        }
        return metrics
    except Exception as e:
        logger.error(f"Error fetching director metrics for {user_id}: {str(e)}")
        return {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "error": "Unable to fetch complete metrics"
        }

async def fetch_manager_metrics(
    user_id: str,
    start_date: str,
    end_date: str,
    manager_id: Optional[List[str]] = None,
    frontline_associate_ids: Optional[List[str]] = None,
    lob: Optional[List[str]] = None,
    session_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch and aggregate metrics for manager.
    Uses session_id to retrieve cached data from Redis.
    Uses associate_utilization API for production_pct to match UI display.
    Args:
        user_id: User identifier
        start_date: Start date
        end_date: End date
        manager_id: Optional manager IDs
        frontline_associate_ids: Optional associate IDs
        lob: Optional LOBs
        session_id: Session ID for Redis cache retrieval
    Returns:
        Dict containing aggregated metrics
    """
    try:
        from controllers.Performance_IQ_Manager.header_kpis import get_header_kpis
        from controllers.Performance_IQ_Manager.associate_utilization import get_associate_utilization
        from schema import ManagerHeaderKPIsRequest, ManagerBaseRequest, ManagerAssociateUtilizationRequest
        # Get header KPIs (work items, audit score, cycle time, pended items, non-value add)
        header_request = ManagerHeaderKPIsRequest(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            manager_ids=manager_id,
            frontline_associate_ids=frontline_associate_ids,
            lob=lob,
            session_id=session_id
        )
        header_response = await get_header_kpis(header_request)
        # Use Header KPIs values directly (they already provide correct aggregated values)
        production_pct = header_response.production_pct_achieved or 0.0
        audit_score = header_response.audit_score_pct or 0.0

        # For a single associate, resolve the human-readable name so the LLM
        # can reference it instead of an opaque user ID.
        associate_name: Optional[str] = None
        if frontline_associate_ids and len(frontline_associate_ids) == 1:
            associate_name = await _lookup_associate_name(frontline_associate_ids[0])

        # Log final values
        logger.info(f"Manager AI Coach final metrics: production_pct={production_pct}, audit_score={audit_score}, "
                   f"work_items={header_response.work_items_completed}, "
                   f"filters: managers={manager_id}, associates={frontline_associate_ids}, lob={lob}")
        metrics = {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "team_size": len(frontline_associate_ids) if frontline_associate_ids else "All associates",
            "lob": lob or ["All"],
            "work_items_completed": header_response.work_items_completed or 0,
            "production_pct": f"{production_pct}%",
            "audit_score": f"{audit_score}%",
            "cycle_time": header_response.cycle_time_avg or "N/A",
            "pended_items": header_response.pended_items_count or 0,
            "non_value_add_pct": f"{header_response.non_value_add_pct or 0}%"
        }
        # Attach name only when resolved — controller uses it to set subject
        if associate_name:
            metrics["associate_name"] = associate_name
        return metrics
    except Exception as e:
        logger.error(f"Error fetching manager metrics for {user_id}: {str(e)}")
        return {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "error": "Unable to fetch complete metrics"
        }

async def fetch_fl_auditor_metrics(
    user_id: str,
    start_date: str,
    end_date: str,
    lob: Optional[List[str]] = None,
    session_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch and aggregate metrics for FL auditor.
    Uses session_id to retrieve cached data from Redis.
    Args:
        user_id: User identifier
        start_date: Start date
        end_date: End date
        lob: Optional LOBs
        session_id: Session ID for Redis cache retrieval
    Returns:
        Dict containing aggregated metrics
    """
    try:
        from controllers.Performance_IQ_FL_Auditor.header_kpis import get_fl_auditor_header_kpis
        from schema import FLAuditorBaseRequest
        request = FLAuditorBaseRequest(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            lob=lob,
            session_id=session_id
        )
        response = await get_fl_auditor_header_kpis(request)
        metrics = {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "lob": lob or ["All"],
            "complete_audit_count": response.complete_audit_count or "0",
            "ata_audit_score": response.ata_audit_score or "0%",
            "audit_cycle_time": response.audit_cycle_time or "N/A",
            "work_items_completed": response.work_items_completed or "0",
            "rebuttal_count": response.rebuttal_count or "0"
        }
        return metrics
    except Exception as e:
        logger.error(f"Error fetching FL auditor metrics for {user_id}: {type(e).__name__}: {str(e)}")
        return {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "error": f"FL Auditor header KPIs API failed: {str(e)}"
        }

async def fetch_auditor_manager_metrics(
    user_id: str,
    start_date: str,
    end_date: str,
    lob: Optional[List[str]] = None,
    session_id: Optional[str] = None,
    manager_ids: Optional[List[str]] = None,
    auditor_ids: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Fetch and aggregate metrics for auditor manager.
    Uses session_id to retrieve cached data from Redis.
    Args:
        user_id: User identifier
        start_date: Start date
        end_date: End date
        lob: Optional LOBs
        session_id: Session ID for Redis cache retrieval
    Returns:
        Dict containing aggregated metrics
    """
    try:
        from controllers.Performance_IQ_Auditor_Manager.header_kpis import get_auditor_manager_header_kpis
        from schema import AuditorManagerBaseRequest
        request = AuditorManagerBaseRequest(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            lob=lob,
            session_id=session_id,
            manager_ids=manager_ids,
            auditor_ids=auditor_ids
        )
        response = await get_auditor_manager_header_kpis(request)

        # Reuses the existing parse_cycle_time_to_seconds() helper (returns total seconds).
        audit_cycle_time_str = response.audit_cycle_time or "N/A"
        audit_cycle_time_minutes: Optional[float] = None
        if audit_cycle_time_str != "N/A":
            total_seconds = parse_cycle_time_to_seconds(audit_cycle_time_str)
            if total_seconds > 0:
                audit_cycle_time_minutes = round(total_seconds / 60, 2)

        metrics = {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "lob": lob or ["All"],
            "complete_audit_count": response.complete_audit_count or "0",
            "audit_sample_percent": response.audit_sample_percent or "0%",
            "audit_sample_count": response.audit_sample_count or "0",
            "work_items_completed": response.work_items_completed or "0",
            "audit_cycle_time": audit_cycle_time_str,
            "audit_cycle_time_minutes": round(audit_cycle_time_minutes, 2) if audit_cycle_time_minutes is not None else "N/A",
            "audit_cycle_time_target_minutes": 20,
            "ata_audit_score": response.ata_audit_score or "N/A",
            "ata_rebuttals": response.ata_rebuttals or "0",
            "ata_rebuttal_percent": response.ata_rebuttal_percent or "0%"
        }
        return metrics
    except Exception as e:
        logger.error(f"Error fetching auditor manager metrics for {user_id}: {type(e).__name__}: {str(e)}")
        return {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "error": f"Auditor Manager header KPIs API failed: {str(e)}"
        }

def _has_metric_value(value: Any) -> bool:
    """Check if a metric has a meaningful value (not None, empty, or N/A)."""
    if value is None:
        return False
    normalized = str(value).strip()
    return normalized not in {"", "-", "N/A", "None"}

def _add_metric(
    metrics: Dict[str, Dict[str, Any]],
    data_gaps: List[str],
    metric_name: str,
    label: str,
    value: Any,
) -> None:
    """Add metric to dict if valid, otherwise silently skip (no data gap tracking)."""
    if _has_metric_value(value):
        metrics[metric_name] = {
            "label": label,
            "value": value,
        }
    # Silently skip missing metrics - do NOT add to data_gaps
    # User requirement: generate summary with available metrics only, no gaps mentioned

def _to_float_or_none(value: Any) -> Optional[float]:
    if not _has_metric_value(value):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        return None

async def fetch_workforce_metrics(
    user_id: str,
    start_date: str,
    end_date: str,
    lob: Optional[List[str]] = None,
    staffing_category: Optional[List[str]] = None,
    work_type: Optional[List[str]] = None,
    manager: Optional[List[str]] = None,
    market: Optional[List[str]] = None,
    funding_model: Optional[List[str]] = None,
    session_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Comprehensive WorkforceIQ metrics aggregator for AI Coach.
    Calls ALL WorkforceIQ APIs in parallel for maximum insight depth.
    """
    try:
        import asyncio
        from controllers.WorkForce_IQ.header_kpis import get_workforce_iq_header_kpis
        from controllers.WorkForce_IQ.membership import get_workforce_iq_membership
        from controllers.WorkForce_IQ.capacity import get_workforce_iq_capacity
        from controllers.WorkForce_IQ.staffing_core import get_staffing_core
        from controllers.WorkForce_IQ.actual_projected_membership import get_actual_vs_projected_membership
        from controllers.WorkForce_IQ.demand_inventory import (
            get_receipts_vs_resolved,
            get_source_type_breakdown,
            get_inventory_by_market,
            get_trend_analysis,
        )
        from schema import (
            WorkforceIQHeaderKPIsRequest,
            WorkforceIQMembershipKPIsRequest,
            WorkforceIQCapacityKPIsRequest,
            StaffingCoreRequest,
            ActualVsProjectedMembershipRequest,
            ReceiptsVsResolvedRequest,
            SourceTypeBreakdownRequest,
            InventoryByMarketRequest,
            TrendAnalysisRequest,
        )
        shared_filters = {
            "user_id": user_id,
            "start_date": start_date,
            "end_date": end_date,
            "session_id": session_id,
            "lob": lob,
            "staffing_category": staffing_category,
            "work_type": work_type,
            "manager": manager,
            "market": market,
            "funding_model": funding_model,
        }
        header_request = WorkforceIQHeaderKPIsRequest(**shared_filters)
        membership_request = WorkforceIQMembershipKPIsRequest(**shared_filters)
        capacity_request = WorkforceIQCapacityKPIsRequest(**shared_filters)
        staffing_request = StaffingCoreRequest(**shared_filters, grouping_level="monthly")
        membership_trend_request = ActualVsProjectedMembershipRequest(**shared_filters, grouping_level="monthly")
        receipts_resolved_request = ReceiptsVsResolvedRequest(**shared_filters, grouping_level="monthly")
        source_type_request = SourceTypeBreakdownRequest(**shared_filters)
        inventory_market_request = InventoryByMarketRequest(**shared_filters)
        trend_analysis_request = TrendAnalysisRequest(**shared_filters)
        logger.info(f"🚀 Workforce AI Coach - Calling 9 APIs in parallel for {user_id}")
        (
            header_response,
            membership_response,
            capacity_response,
            staffing_response,
            membership_trend_response,
            receipts_resolved_response,
            source_type_response,
            inventory_market_response,
            trend_analysis_response,
        ) = await asyncio.gather(
            get_workforce_iq_header_kpis(header_request),
            get_workforce_iq_membership(membership_request),
            get_workforce_iq_capacity(capacity_request),
            get_staffing_core(staffing_request),
            get_actual_vs_projected_membership(membership_trend_request),
            get_receipts_vs_resolved(receipts_resolved_request),
            get_source_type_breakdown(source_type_request),
            get_inventory_by_market(inventory_market_request),
            get_trend_analysis(trend_analysis_request),
            return_exceptions=True,
        )
        metrics: Dict[str, Dict[str, Any]] = {}
        data_gaps: List[str] = []
        source_status: Dict[str, Any] = {}
        if not isinstance(header_response, Exception) and getattr(header_response, "status", None) == "success":
            source_status["header_kpis"] = "success"
            _add_metric(metrics, data_gaps, "staff_utilization_pct", "Staff Utilization %", header_response.staff_utilization_pct)
            _add_metric(metrics, data_gaps, "cycle_time_per_fte", "Cycle Time per FTE", header_response.cycle_time_per_fte)
            _add_metric(metrics, data_gaps, "capacity_per_fte", "Capacity per FTE", header_response.capacity_per_fte)
            _add_metric(metrics, data_gaps, "backlog_volume", "Backlog Volume", header_response.backlog_volume)
            _add_metric(metrics, data_gaps, "days_work_on_hand", "Days Work on Hand", header_response.days_work_on_hand)
            _add_metric(metrics, data_gaps, "avg_resolved_per_day", "Average Resolved per Day", header_response.avg_resolved_per_day)
            _add_metric(metrics, data_gaps, "net_inventory_change", "Net Inventory Change", header_response.net_inventory_change)
            _add_metric(metrics, data_gaps, "sla_risk_pct", "SLA Risk %", header_response.sla_risk_pct)
            _add_metric(metrics, data_gaps, "required_fte", "Required FTE", header_response.required_fte)
            _add_metric(metrics, data_gaps, "actual_fte", "Actual FTE", header_response.actual_fte)
        else:
            source_status["header_kpis"] = str(header_response)
        # COMMENTED OUT: Membership metrics not in required 10
        # if not isinstance(membership_response, Exception) and getattr(membership_response, "status", None) == "success":
        #     source_status["membership"] = "success"
        #     _add_metric(metrics, data_gaps, "actual_membership", "Actual Membership", membership_response.actual_membership)
        #     _add_metric(metrics, data_gaps, "projected_membership", "Projected Membership", membership_response.projected_membership)
        #     _add_metric(metrics, data_gaps, "variance_count", "Membership Variance Count", membership_response.variance_count)
        #     _add_metric(metrics, data_gaps, "variance_pct", "Membership Variance %", membership_response.variance_pct)
        #     _add_metric(metrics, data_gaps, "demand_utilization", "Demand Utilization", membership_response.demand_utilization)
        #     _add_metric(metrics, data_gaps, "utilization_variance", "Utilization Variance", membership_response.utilization_variance)
        # else:
        #     source_status["membership"] = str(membership_response)
        # COMMENTED OUT: Capacity metrics not in required 10 (except capacity_per_fte which is already in header_kpis)
        # if not isinstance(capacity_response, Exception) and getattr(capacity_response, "status", None) == "success":
        #     source_status["capacity"] = "success"
        #     if "capacity_per_fte" not in metrics:
        #         _add_metric(metrics, data_gaps, "capacity_per_fte", "Capacity per FTE", capacity_response.capacity_per_fte)
        #     _add_metric(metrics, data_gaps, "cases_per_hour", "Cases per Hour", capacity_response.cases_per_hour)
        #     _add_metric(metrics, data_gaps, "avg_fte_hours", "Average FTE Hours", capacity_response.avg_fte_hours)
        #     _add_metric(metrics, data_gaps, "shrinkage_pct", "Shrinkage %", capacity_response.shrinkage_pct)
        # else:
        #     source_status["capacity"] = str(capacity_response)
        # COMMENTED OUT: Staffing core metrics not in required 10
        # if not isinstance(staffing_response, Exception) and getattr(staffing_response, "status", None) == "success":
        #     source_status["staffing_core"] = "success"
        #     if staffing_response.data and len(staffing_response.data) > 0:
        #         latest = staffing_response.data[-1]
        #         _add_metric(metrics, data_gaps, "required_fte_staffing", "Required FTE (Staffing)", latest.required_fte)
        #         _add_metric(metrics, data_gaps, "available_fte", "Available FTE", latest.available_fte)
        #         _add_metric(metrics, data_gaps, "actual_fte_staffing", "Actual FTE (Staffing)", latest.actual_fte)
        #         _add_metric(metrics, data_gaps, "loan_fte", "Loan FTE", latest.loan_fte)
        #         _add_metric(metrics, data_gaps, "projected_fte", "Projected FTE", latest.projected_fte)
        #         required_fte_value = _to_float_or_none(latest.required_fte)
        #         actual_fte_value = _to_float_or_none(latest.actual_fte)
        #         if required_fte_value is not None and actual_fte_value is not None:
        #             gap = actual_fte_value - required_fte_value
        #             _add_metric(metrics, data_gaps, "staffing_gap", "Staffing Gap (FTE)", f"{gap:+.1f}")
        # else:
        #     source_status["staffing_core"] = str(staffing_response)
        # COMMENTED OUT: Membership trend metrics not in required 10
        # if not isinstance(membership_trend_response, Exception) and getattr(membership_trend_response, "status", None) == "success":
        #     source_status["membership_trend"] = "success"
        #     if membership_trend_response.data and len(membership_trend_response.data) > 0:
        #         latest_trend = membership_trend_response.data[-1]
        #         _add_metric(metrics, data_gaps, "membership_trend_actual", "Membership Trend (Actual)", getattr(latest_trend, 'ACTUAL_MEMBERSHIP', None))
        #         _add_metric(metrics, data_gaps, "membership_trend_projected", "Membership Trend (Projected)", getattr(latest_trend, 'PROJECTED_MEMBERSHIP', None))
        #         _add_metric(metrics, data_gaps, "membership_trend_variance", "Membership Trend Variance", getattr(latest_trend, 'VARIANCE_GAP_PCT', None))
        #         if len(membership_trend_response.data) >= 2:
        #             prev = membership_trend_response.data[-2]
        #             curr = membership_trend_response.data[-1]
        #             try:
        #                 prev_val = _to_float_or_none(getattr(prev, 'ACTUAL_MEMBERSHIP', None)) or 0.0
        #                 curr_val = _to_float_or_none(getattr(curr, 'ACTUAL_MEMBERSHIP', None)) or 0.0
        #                 trend_direction = "increasing" if curr_val > prev_val else "decreasing" if curr_val < prev_val else "stable"
        #                 _add_metric(metrics, data_gaps, "membership_trend_direction", "Membership Trend Direction", trend_direction)
        #             except (ValueError, TypeError, AttributeError):
        #                 pass
        # else:
        #     source_status["membership_trend"] = str(membership_trend_response)
        # COMMENTED OUT: Receipts/resolved metrics not in required 10
        # if not isinstance(receipts_resolved_response, Exception) and getattr(receipts_resolved_response, "status", None) == "success":
        #     try:
        #         source_status["receipts_resolved"] = "success"
        #         _add_metric(metrics, data_gaps, "receipts_volume", "Receipts Volume", receipts_resolved_response.receipts)
        #         _add_metric(metrics, data_gaps, "resolved_volume", "Resolved Volume", receipts_resolved_response.resolved)
        #         receipts_val = _to_float_or_none(receipts_resolved_response.receipts)
        #         resolved_val = _to_float_or_none(receipts_resolved_response.resolved)
        #         variance_gap_value = receipts_resolved_response.variance_gap
        #         if variance_gap_value is None and receipts_val is not None and resolved_val is not None:
        #             variance_gap_value = receipts_val - resolved_val
        #             logger.info(f"Calculated variance_gap from receipts ({receipts_val}) - resolved ({resolved_val}) = {variance_gap_value}")
        #         _add_metric(metrics, data_gaps, "variance_gap", "Variance Gap (Receipts - Resolved)", variance_gap_value)
        #         _add_metric(metrics, data_gaps, "forecast_accuracy_pct", "Forecast Accuracy %", receipts_resolved_response.forecast_accuracy)
        #         if receipts_val is not None and resolved_val is not None:
        #             flow_balance = "positive" if receipts_val > resolved_val else "negative" if receipts_val < resolved_val else "balanced"
        #             _add_metric(metrics, data_gaps, "flow_balance", "Flow Balance", flow_balance)
        #     except (AttributeError, IndexError, TypeError) as e:
        #         logger.warning(f"Error extracting receipts_resolved metrics: {e}")
        #         source_status["receipts_resolved"] = f"partial_error: {str(e)}"
        # else:
        #     source_status["receipts_resolved"] = str(receipts_resolved_response)
        # COMMENTED OUT: Source type metrics not in required 10
        # if not isinstance(source_type_response, Exception) and getattr(source_type_response, "status", None) == "success":
        #     source_status["source_type"] = "success"
        #     if source_type_response.data and len(source_type_response.data) > 0:
        #         top_source = max(source_type_response.data, key=lambda x: x.count if x.count else 0)
        #         _add_metric(metrics, data_gaps, "top_work_type", "Top Work Type", top_source.work_type)
        #         _add_metric(metrics, data_gaps, "top_work_type_count", "Top Work Type Count", top_source.count)
        #         _add_metric(metrics, data_gaps, "top_work_type_pct", "Top Work Type %", top_source.percentage)
        # else:
        #     source_status["source_type"] = str(source_type_response)
        # COMMENTED OUT: Inventory market metrics not in required 10
        # if not isinstance(inventory_market_response, Exception) and getattr(inventory_market_response, "status", None) == "success":
        #     source_status["inventory_market"] = "success"
        #     if inventory_market_response.data and len(inventory_market_response.data) > 0:
        #         top_market = max(inventory_market_response.data, key=lambda x: x.inventory_count if x.inventory_count else 0)
        #         _add_metric(metrics, data_gaps, "top_market", "Top Market by Inventory", top_market.market)
        #         _add_metric(metrics, data_gaps, "top_market_inventory", "Top Market Inventory Count", top_market.inventory_count)
        # else:
        #     source_status["inventory_market"] = str(inventory_market_response)
        # COMMENTED OUT: Trend analysis metrics not in required 10
        # if not isinstance(trend_analysis_response, Exception) and getattr(trend_analysis_response, "status", None) == "success":
        #     source_status["trend_analysis"] = "success"
        #     _add_metric(metrics, data_gaps, "trend_direction", "Overall Trend Direction", trend_analysis_response.trend_direction)
        #     _add_metric(metrics, data_gaps, "system_recommendation", "System Recommendation", trend_analysis_response.recommendation)
        # else:
        #     source_status["trend_analysis"] = str(trend_analysis_response)
        if not metrics:
            return {
                "user_id": user_id,
                "period": f"{start_date} to {end_date}",
                "error": "Unable to fetch Workforce IQ metrics",
                "data_gaps": data_gaps,
                "source_status": source_status,
            }
        logger.info(f"✅ Workforce AI Coach - Aggregated {len(metrics)} core metrics (max 10) from header_kpis API")
        return {
            "user_id": user_id,
            "date_range": f"{start_date} to {end_date}",
            "filters": {
                "lob": lob or ["All"],
                "staffing_category": staffing_category or ["All"],
                "work_type": work_type or ["All"],
                "manager": manager or ["All"],
                "market": market or ["All"],
                "funding_model": funding_model or ["All"],
            },
            "metrics": metrics,
            "data_gaps": data_gaps,
            "source_status": source_status,
        }
    except Exception as e:
        logger.error(f"Error fetching workforce metrics for {user_id}: {type(e).__name__}: {str(e)}")
        return {
            "user_id": user_id,
            "period": f"{start_date} to {end_date}",
            "error": f"Unable to fetch Workforce IQ metrics: {str(e)}",
        }