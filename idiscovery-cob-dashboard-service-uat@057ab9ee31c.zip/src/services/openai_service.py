import logging
import os
from typing import Dict, Any, Optional, List
from fastapi import HTTPException
import config

def _uses_framework_default_temperature(model: Optional[str]) -> bool:
    return (model or "").strip().lower().startswith("gpt-5.4")

os.environ.setdefault("HORIZON_REQUEST_TIMEOUT", str(config.HORIZON_REQUEST_TIMEOUT))
if _uses_framework_default_temperature(config.OPENAI_DEFAULT_MODEL):
    os.environ["OPENAI_DEFAULT_TEMPERATURE"] = "1"

# Inject cacert.pem for httpx (used by idiscovery-framework) before import.
# httpx respects SSL_CERT_FILE; requests uses LLM_PEM directly.
_cert_path = os.environ.get("LLM_PEM", "cacert.pem")
if os.path.exists(_cert_path):
    os.environ.setdefault("SSL_CERT_FILE", _cert_path)
    os.environ.setdefault("REQUESTS_CA_BUNDLE", _cert_path)

from idiscovery_framework.llm.openai_service import OpenAIService
import requests
import warnings
import re
import time
import urllib3
import json
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

_openai_service_instance: Optional[OpenAIService] = None
OPENAI_JSON_OBJECT_RESPONSE_FORMAT = {"type": "json_object"}

# Token cache (in-memory + Redis)
_cached_token: Optional[str] = None
_token_expiry: Optional[datetime] = None
TOKEN_TTL_SECONDS = 3300  # 55 minutes (token valid for 1 hour, refresh 5 min early)


def _mask_secret_like_value(value: Optional[str], visible_chars: int = 4) -> Optional[str]:
    if not value:
        return None
    if len(value) <= visible_chars:
        return "*" * len(value)
    return f"{'*' * max(len(value) - visible_chars, 3)}{value[-visible_chars:]}"


def _build_horizon_debug_context(**overrides: Any) -> Dict[str, Any]:
    cert_path = os.environ.get("LLM_PEM", "cacert.pem")
    cert_exists = os.path.exists(cert_path)
    ssl_verify = cert_path if cert_exists else False
    context: Dict[str, Any] = {
        "openai_base_url": config.OPENAI_BASE_URL,
        "horizon_auth_url": config.HORIZON_AUTH_URL,
        "horizon_request_timeout": config.HORIZON_REQUEST_TIMEOUT,
        "ai_coach_timeout": config.AI_COACH_TIMEOUT,
        "use_framework_horizon_token": config.USE_FRAMEWORK_HORIZON_TOKEN,
        "client_id_present": bool(config.HORIZON_CLIENT_ID),
        "client_id_masked": _mask_secret_like_value(config.HORIZON_CLIENT_ID),
        "client_secret_present": bool(config.HORIZON_CLIENT_SECRET),
        "pem_path": cert_path,
        "pem_exists": cert_exists,
        "ssl_verify": ssl_verify if cert_exists else False,
    }
    context.update(overrides)
    return context


def _build_exception_debug_context(exc: BaseException) -> Dict[str, Any]:
    return {
        "exception_type": type(exc).__name__,
        "exception_repr": repr(exc),
        "cause_type": type(exc.__cause__).__name__ if exc.__cause__ else None,
        "cause_repr": repr(exc.__cause__) if exc.__cause__ else None,
        "context_type": type(exc.__context__).__name__ if exc.__context__ else None,
        "context_repr": repr(exc.__context__) if exc.__context__ else None,
    }


def get_cached_token() -> Optional[str]:
    """
    Get cached token from Redis or in-memory cache.
    
    Returns:
        str: Valid cached token or None if expired/not found
    """
    global _cached_token, _token_expiry
    
    # Check in-memory cache first
    if _cached_token and _token_expiry and datetime.now() < _token_expiry:
        logger.info(f"✅ Using in-memory cached token (expires in {(_token_expiry - datetime.now()).seconds}s)")
        return _cached_token
    
    # Try to get from Redis
    try:
        from utils.redis_cache import cache_manager
        if cache_manager and cache_manager.client:
            cached_token = cache_manager.get("horizon_oauth_token")
            if cached_token:
                logger.info("✅ Using Redis cached token")
                # Update in-memory cache
                _cached_token = cached_token
                _token_expiry = datetime.now() + timedelta(seconds=TOKEN_TTL_SECONDS)
                return cached_token
    except Exception as e:
        logger.warning(f"Could not retrieve token from Redis: {str(e)}")
    
    return None


def cache_token(token: str) -> None:
    """
    Cache token in both Redis and in-memory with TTL.
    
    Args:
        token: Token to cache
    """
    global _cached_token, _token_expiry
    
    # Cache in-memory
    _cached_token = token
    _token_expiry = datetime.now() + timedelta(seconds=TOKEN_TTL_SECONDS)
    
    # Cache in Redis
    try:
        from utils.redis_cache import cache_manager
        if cache_manager and cache_manager.client:
            cache_manager.set("horizon_oauth_token", token, ttl=TOKEN_TTL_SECONDS)
            logger.info(f"✅ Token cached for {TOKEN_TTL_SECONDS}s (55 minutes)")
    except Exception as e:
        logger.warning(f"Could not cache token in Redis: {str(e)}")


def get_auth_token(client_id: str, client_secret: str, force_refresh: bool = False) -> Optional[str]:
    """
    Get authentication token using client credentials with SSL verification disabled.
    Uses cached token if available and not expired (55-minute TTL).
    Fallback when Horizon OAuth API is unreachable.

    Args:
        client_id: Horizon client ID
        client_secret: Horizon client secret
        force_refresh: If True, skip cache and generate new token

    Returns:
        str: Access token or None if failed
    """
    request_timeout = 10
    request_context = _build_horizon_debug_context(
        token_source="direct_fallback",
        force_refresh=force_refresh,
        request_timeout=request_timeout,
        client_id_present=bool(client_id),
        client_id_masked=_mask_secret_like_value(client_id),
        client_secret_present=bool(client_secret),
    )

    try:
        if not force_refresh:
            cached = get_cached_token()
            if cached:
                logger.info(
                    "Using cached Horizon OAuth token | context=%s",
                    {**request_context, "cache_hit": True},
                )
                return cached

        logger.info("Generating new Horizon OAuth token (direct fallback) | context=%s", request_context)

        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        data = {
            'grant_type': 'client_credentials',
            'client_id': client_id,
            'client_secret': client_secret
        }

        token_url = config.HORIZON_AUTH_URL
        cert_path = os.environ.get("LLM_PEM", "cacert.pem")
        ssl_verify = cert_path if os.path.exists(cert_path) else False

        response = requests.post(token_url, headers=headers, data=data, verify=ssl_verify, timeout=request_timeout)
        response_context = {
            **request_context,
            "status_code": response.status_code,
        }

        if response.status_code == 200:
            token = response.json().get('access_token')
            logger.info(
                "Successfully generated new token via fallback method | context=%s",
                {**response_context, "access_token_present": bool(token)},
            )
            cache_token(token)
            return token

        logger.error(
            "Token generation failed | context=%s",
            {**response_context, "response_excerpt": response.text[:500]},
        )
        return None

    except Exception as e:
        logger.exception(
            "Error in fallback token generation | context=%s | exception=%s",
            request_context,
            _build_exception_debug_context(e),
        )
        return None


def build_openai_request_options(model: Optional[str] = None, include_framework_temperature: bool = False) -> Dict[str, Any]:
    options: Dict[str, Any] = {
        'response_format': OPENAI_JSON_OBJECT_RESPONSE_FORMAT,
        'reasoning_effort': config.OPENAI_REASONING_EFFORT
    }
    target_model = (model or config.OPENAI_DEFAULT_MODEL or '').strip().lower()
    if include_framework_temperature and target_model.startswith('gpt-5.4'):
        options['temperature'] = 1
    return options


def call_openai_direct(token: str, messages: list, model: str) -> Optional[Dict[str, Any]]:
    """
    Call OpenAI API directly with a token (bypass framework).

    Args:
        token: Bearer token for authentication
        messages: Chat messages
        model: Model name

    Returns:
        Dict: OpenAI response or None
    """
    payload = {
        'model': model,
        'messages': messages,
        'max_tokens': config.AI_COACH_MAX_TOKENS,
        **build_openai_request_options(model)
    }
    openai_url = f"{config.OPENAI_BASE_URL}chat/completions"
    payload_chars = len(json.dumps(payload, default=str))
    request_context = _build_horizon_debug_context(
        call_path="direct_openai",
        model=model,
        message_count=len(messages),
        payload_chars=payload_chars,
        max_tokens=config.AI_COACH_MAX_TOKENS,
        openai_url=openai_url,
        token_present=bool(token),
    )

    try:
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }

        logger.info("Calling OpenAI directly with fallback token | context=%s", request_context)
        cert_path = os.environ.get("LLM_PEM", "cacert.pem")
        ssl_verify = cert_path if os.path.exists(cert_path) else False

        max_retries = 3
        token_refresh_attempted = False

        for attempt in range(1, max_retries + 1):
            logger.info(
                "OpenAI direct call attempt started | context=%s",
                {**request_context, "attempt": attempt, "max_retries": max_retries},
            )
            response = requests.post(
                openai_url,
                headers=headers,
                json=payload,
                verify=ssl_verify,
                timeout=config.AI_COACH_TIMEOUT
            )

            if response.status_code == 200:
                response_json = response.json()
                logger.info(
                    "OpenAI direct call successful | context=%s",
                    {
                        **request_context,
                        "attempt": attempt,
                        "status_code": response.status_code,
                        "usage": extract_token_usage(response_json),
                    },
                )
                return response_json

            if response.status_code in (401, 403):
                logger.warning(
                    "OpenAI direct call authentication failure | context=%s",
                    {
                        **request_context,
                        "attempt": attempt,
                        "status_code": response.status_code,
                        "token_refresh_attempted": token_refresh_attempted,
                        "response_excerpt": response.text[:500],
                    },
                )

                if token_refresh_attempted:
                    logger.error(
                        "OpenAI direct call failed after token refresh | context=%s",
                        {
                            **request_context,
                            "attempt": attempt,
                            "status_code": response.status_code,
                            "response_excerpt": response.text[:500],
                        },
                    )
                    return None

                refreshed_token = get_auth_token(
                    config.HORIZON_CLIENT_ID,
                    config.HORIZON_CLIENT_SECRET,
                    force_refresh=True
                )

                if not refreshed_token:
                    logger.error(
                        "OpenAI direct call could not refresh Horizon token after authentication failure | context=%s",
                        {**request_context, "attempt": attempt},
                    )
                    return None

                headers['Authorization'] = f'Bearer {refreshed_token}'
                token_refresh_attempted = True
                continue

            if response.status_code == 429:
                wait_seconds = 1

                retry_after = response.headers.get("Retry-After")
                if retry_after and retry_after.isdigit():
                    wait_seconds = int(retry_after)
                else:
                    match = re.search(r"Try again in (\d+) second", response.text)
                    if match:
                        wait_seconds = int(match.group(1))

                logger.warning(
                    "OpenAI direct call rate limited | context=%s",
                    {
                        **request_context,
                        "attempt": attempt,
                        "max_retries": max_retries,
                        "wait_seconds": wait_seconds,
                        "response_excerpt": response.text[:500],
                    },
                )

                if attempt < max_retries:
                    time.sleep(wait_seconds)
                    continue

            logger.error(
                "OpenAI direct call failed | context=%s",
                {
                    **request_context,
                    "attempt": attempt,
                    "status_code": response.status_code,
                    "response_excerpt": response.text[:500],
                },
            )
            return None

        return None
    except Exception as e:
        logger.exception(
            "Error in direct OpenAI call | context=%s | exception=%s",
            request_context,
            _build_exception_debug_context(e),
        )
        return None


def get_openai_service() -> OpenAIService:
    """
    Get or create OpenAIService instance (singleton pattern).

    Returns:
        OpenAIService: Configured OpenAI service instance

    Raises:
        HTTPException: If service initialization fails
    """
    global _openai_service_instance

    if _openai_service_instance is None:
        init_context = _build_horizon_debug_context(
            operation="initialize_openai_service",
            service_class="OpenAIService",
        )
        try:
            if not config.HORIZON_CLIENT_ID or not config.HORIZON_CLIENT_SECRET:
                raise ValueError("HORIZON_CLIENT_ID and HORIZON_CLIENT_SECRET must be set")

            logger.info("Initializing OpenAI service | context=%s", init_context)
            _openai_service_instance = OpenAIService(
                client_id=config.HORIZON_CLIENT_ID,
                client_secret=config.HORIZON_CLIENT_SECRET
            )
            logger.info("OpenAI service initialized successfully | context=%s", init_context)
        except Exception as e:
            logger.exception(
                "Failed to initialize OpenAI service | context=%s | exception=%s",
                init_context,
                _build_exception_debug_context(e),
            )
            raise HTTPException(
                status_code=500,
                detail=f"Failed to initialize OpenAI service: {str(e)}"
            )

    return _openai_service_instance


def normalize_ai_summary(summary: str, include_legacy_key: bool = False) -> Dict[str, Any]:
    summary_text = summary
    parsed_payload: Dict[str, Any] = {}
    json_str = summary.strip()

    try:
        if json_str.startswith('```'):
            start_idx = json_str.find('{')
            end_idx = json_str.rfind('}')
            if start_idx != -1 and end_idx != -1:
                json_str = json_str[start_idx:end_idx + 1]

        if json_str.startswith('{'):
            parsed_payload = json.loads(json_str)
            summary_text = parsed_payload.get("performance_summary", summary)
            if include_legacy_key and summary_text == summary:
                summary_text = parsed_payload.get("ai_coach_response", summary)
    except json.JSONDecodeError as e:
        logger.warning(f"AI summary was not valid JSON: {str(e)}")

    return {
        "performance_summary": summary_text,
        "parsed_payload": parsed_payload
    }


def extract_completion_text(response: Dict[str, Any]) -> str:
    if response and "choices" in response and len(response["choices"]) > 0:
        return response["choices"][0]["message"]["content"].strip()
    return ""


def extract_token_usage(response: Dict[str, Any]) -> Dict[str, Any]:
    usage = response.get("usage", {}) if isinstance(response, dict) else {}
    if not isinstance(usage, dict):
        usage = {}

    return {
        "prompt_tokens": usage.get("prompt_tokens", "N/A"),
        "completion_tokens": usage.get("completion_tokens", "N/A"),
        "total_tokens": usage.get("total_tokens", "N/A"),
    }


async def generate_performance_summary(
    user_id: str,
    metrics_data: Dict[str, Any],
    role: str = "frontline",
    start_date: str = "",
    end_date: str = "",
    lob: Optional[List[str]] = None
) -> str:
    """
    Generate AI-powered performance summary using OpenAI with dynamic baselines.
    
    Args:
        user_id: User identifier
        metrics_data: Dictionary containing performance metrics
        role: User role (frontline, director, manager, fl_auditor, auditor_manager)
        start_date: Start date for analysis period
        end_date: End date for analysis period
        lob: Optional list of LOBs for dynamic baseline calculation
        
    Returns:
        str: AI-generated performance summary
        
    Raises:
        Exception: If OpenAI call fails
    """
    try:
        from services.ai_coach_prompts import build_prompt_messages

        messages = build_prompt_messages(
            role=role,
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            metrics_data=metrics_data,
            include_baseline=True,
            lob=lob
        )

        openai_service = get_openai_service()
        response = None

        if config.USE_FRAMEWORK_HORIZON_TOKEN:
            try:
                response = await openai_service.generate_completion(
                    messages=messages,
                    model=config.OPENAI_DEFAULT_MODEL,
                    **build_openai_request_options(config.OPENAI_DEFAULT_MODEL, include_framework_temperature=True)
                )
            except Exception as framework_error:
                logger.warning(f"Framework OpenAI call failed: {str(framework_error)}. Attempting fallback...")

        if response is None:
            import asyncio
            loop = asyncio.get_running_loop()

            token = await loop.run_in_executor(
                None, get_auth_token,
                config.HORIZON_CLIENT_ID, config.HORIZON_CLIENT_SECRET
            )

            if not token:
                raise Exception("Unable to authenticate with Horizon API")

            # Try primary model first, then fallbacks
            models_to_try = list(dict.fromkeys([config.OPENAI_DEFAULT_MODEL] + config.OPENAI_MODEL_FALLBACK))
            for model in models_to_try:
                logger.info(f"Trying model: {model}")
                response = await loop.run_in_executor(
                    None, call_openai_direct, token, messages, model
                )
                if response:
                    logger.info(f"✅ Model {model} succeeded")
                    break
                logger.warning(f"Model {model} failed, trying next...")

            if not response:
                logger.warning("All models failed. Generating simple summary...")
                return await generate_simple_summary(metrics_data, role)

        token_usage = extract_token_usage(response)
        logger.info(
            "AI summary token usage for %s: prompt_tokens=%s, completion_tokens=%s, total_tokens=%s",
            user_id, token_usage["prompt_tokens"],
            token_usage["completion_tokens"], token_usage["total_tokens"],
        )

        summary = extract_completion_text(response)
        if summary:
            return summary

        logger.warning(f"Empty response from OpenAI for {user_id}")
        return "Unable to generate performance summary. Please try again later."

    except Exception as e:
        logger.error(f"Error generating AI summary for {user_id}: {str(e)}")
        raise


async def generate_simple_summary(metrics_data: Dict[str, Any], role: str = "frontline") -> str:
    """
    Generate a simple template-based summary (fallback when OpenAI unavailable).
    
    Args:
        metrics_data: Dictionary containing performance metrics
        role: User role
        
    Returns:
        str: Template-based summary
    """
    try:
        # Extract metrics from nested structure
        metrics = metrics_data.get("metrics", {})
        
        # Helper function to get metric value
        def get_metric_value(metric_name: str, default: str = "N/A") -> str:
            metric_data = metrics.get(metric_name, {})
            if isinstance(metric_data, dict):
                return metric_data.get("value", default)
            return default
        
        if role == "frontline":
            work_items = get_metric_value("work_items_completed")
            audit_score = get_metric_value("audit_score_pct")
            cycle_time = get_metric_value("avg_cycle_time")
            production = get_metric_value("production_pct")
            
            return (
                f"Performance Summary: "
                f"Completed {work_items} work items "
                f"with {audit_score}% audit score and {production}% production rate. "
                f"Average cycle time: {cycle_time}. "
                f"Keep up the great work!"
            )
        elif role == "director":
            work_items = get_metric_value("total_work_items")
            audit_score = get_metric_value("team_audit_score")
            production = get_metric_value("team_production_pct")
            
            return (
                f"Team Overview: "
                f"Total work items: {work_items}. "
                f"Team audit score: {audit_score}%. "
                f"Production percentage: {production}%. "
                f"Monitor trends and support team performance."
            )
        elif role == "manager":
            work_items = get_metric_value("team_work_items")
            audit_score = get_metric_value("team_audit_score")
            
            return (
                f"Team Performance: "
                f"Associates completed {work_items} items. "
                f"Quality score: {audit_score}%. "
                f"Focus on coaching and development opportunities."
            )
        else:
            return (
                f"Performance metrics available. "
                f"AI-powered insights temporarily unavailable."
            )
    except Exception as e:
        logger.error(f"Error generating simple summary: {str(e)}")
        return "Performance data available. Please review your metrics dashboard."
