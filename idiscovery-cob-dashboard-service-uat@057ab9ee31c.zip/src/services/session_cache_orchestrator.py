"""
Session Cache Orchestrator for Director APIs

Manages session-based cache warming, coordination, and retrieval for all Director APIs.
Implements lock-based concurrency control to ensure synchronized data across the UI.
"""

import logging
import asyncio
import time
import uuid
from typing import Any, Dict, List, Optional, Callable
from datetime import datetime, timedelta

from utils.redis_cache import cache_manager
from services.api_function_registry import api_function_registry
from schema import DirectorBaseRequest, CacheMetadata
import config

# Import request models for drilldowns
from schema import (
    AuditScoreDirectorDrilldownRequest,
    FuseTimeDirectorDrilldownRequest,
    WorkItemsDirectorDrilldownRequest,
    AuditErrorDirectorDrilldownPaginatedRequest,
    CompletedAuditCountDrilldownPaginatedRequest,
    RebuttalDrilldownPaginatedRequest,
    ReworkPctDrilldownPaginatedRequest,
    EscalationCountDrilldownPaginatedRequest,
    PendedItemsDrilldownPaginatedRequest,
    WatchlistDrilldownPaginatedRequest,
    CapacityInsightDrilldownPaginatedRequest,
    SlaHealthDrilldownPaginatedRequest,
    AuditSamplePctDrilldownPaginatedRequest,
    CycleTaktDrilldownPaginatedRequest,
    ProductionPctAchievedDrilldownPaginatedRequest
)

logger = logging.getLogger(__name__)


def generate_session_id() -> str:
    """
    Generate a unique session ID.
    
    Format: session_{timestamp}_{random_hash}
    Example: session_1775821614_abc123def
    
    Returns:
        str: Unique session identifier
    """
    timestamp = int(time.time())
    random_hash = uuid.uuid4().hex[:10]
    return f"session_{timestamp}_{random_hash}"


class SessionCacheOrchestrator:
    """Orchestrates session-based caching for Director APIs."""
    
    def __init__(self):
        self.cache_manager = cache_manager
        self.api_function_registry = api_function_registry
        self.enabled = config.SESSION_CACHE_ENABLED
        self.ttl = config.SESSION_CACHE_TTL
        self.lock_ttl = config.SESSION_CACHE_LOCK_TTL
        self.wait_timeout = config.SESSION_CACHE_WAIT_TIMEOUT
        # Semaphore to throttle concurrent Redis operations
        self.redis_semaphore = asyncio.Semaphore(config.SESSION_CACHE_PARALLEL_WORKERS)
        logger.info(f"Session cache orchestrator initialized with {config.SESSION_CACHE_PARALLEL_WORKERS} parallel workers")
    
    def _build_session_key(self, session_id: str, api_name: str) -> str:
        """Build cache key for session-based caching."""
        return f"session:{session_id}:{api_name}"
    
    def _build_lock_key(self, session_id: str) -> str:
        """Build lock key for session coordination."""
        return f"session_lock:{session_id}"
    
    def _build_metadata_key(self, session_id: str) -> str:
        """Build metadata key for session information."""
        return f"session_meta:{session_id}"
    
    async def is_session_cached(self, session_id: str) -> bool:
        """Check if session has been cached.
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if session metadata exists in cache
        """
        if not self.enabled:
            return False
        
        meta_key = self._build_metadata_key(session_id)
        metadata = await self.cache_manager.get(meta_key)
        return metadata is not None
    
    async def is_warming_in_progress(self, session_id: str) -> bool:
        """Check if cache warming is currently in progress for session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if lock exists (warming in progress)
        """
        if not self.enabled:
            return False
        
        lock_key = self._build_lock_key(session_id)
        try:
            exists = await self.cache_manager.redis_handler.exists(lock_key)
            return bool(exists)
        except Exception as e:
            logger.error(f"Error checking warming status for session {session_id}: {e}")
            return False
    
    async def warm_session_cache(
        self,
        session_id: str,
        filters: DirectorBaseRequest
    ) -> Dict[str, Any]:
        """Warm cache for all APIs in parallel for a session.
        
        Args:
            session_id: Session identifier
            filters: Request filters to apply to all APIs
            
        Returns:
            Dictionary with warming results (success count, duration, etc.)
        """
        if not self.enabled:
            logger.info(f"Session cache disabled, skipping warming for {session_id}")
            return {"success": 0, "total": 0, "duration_ms": 0}
        
        lock_key = self._build_lock_key(session_id)
        start_time = time.time()
        
        logger.info(f"Starting cache warming for session {session_id}")
        
        try:
            # Acquire lock
            locked = await self.cache_manager.acquire_lock(lock_key, ttl=self.lock_ttl)
            if not locked:
                logger.warning(f"Failed to acquire lock for session {session_id} (already warming)")
                return {"success": 0, "total": 0, "duration_ms": 0, "error": "lock_acquisition_failed"}
            
            # Get all registered API names (22 total: 6 core + 16 drilldowns)
            all_api_names = self.api_function_registry.get_all_apis()
            total_apis = len(all_api_names)
            core_count = len(self.api_function_registry.get_core_apis())
            drilldown_count = len(self.api_function_registry.get_drilldown_apis())
            
            logger.info(f"Warming {total_apis} APIs for session {session_id} ({core_count} core + {drilldown_count} drilldowns)")
            
            # Create tasks for parallel execution (call functions directly)
            tasks = []
            for api_name in all_api_names:
                task = self._execute_and_cache_api_direct(
                    session_id=session_id,
                    api_name=api_name,
                    filters=filters
                )
                tasks.append(task)
            
            # Execute all APIs concurrently
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Collect successful API names
            cached_apis = []
            failed_apis = []
            for i, result in enumerate(results):
                api_name = all_api_names[i]
                if not isinstance(result, Exception) and result:
                    cached_apis.append(api_name)
                else:
                    failed_apis.append(api_name)
                    if isinstance(result, Exception):
                        logger.error(f"API {api_name} failed: {result}")
            
            success_count = len(cached_apis)
            failed_count = len(failed_apis)
            
            # Calculate duration
            duration_ms = int((time.time() - start_time) * 1000)
            
            # Store session metadata
            metadata = {
                "session_id": session_id,
                "cached_at": datetime.utcnow().isoformat(),
                "expires_at": (datetime.utcnow() + timedelta(seconds=self.ttl)).isoformat(),
                "apis_cached": cached_apis,  # List of successfully cached API names
                "failed_apis": failed_apis,
                "total_apis": total_apis,
                "failed_count": failed_count,
                "warming_duration_ms": duration_ms
            }
            
            meta_key = self._build_metadata_key(session_id)
            await self.cache_manager.set(meta_key, metadata, ttl=self.ttl)
            
            logger.info(
                f"Cache warming completed for session {session_id}: "
                f"{success_count}/{total_apis} APIs cached in {duration_ms}ms "
                f"(failed: {failed_apis})"
            )
            
            return {
                "success": success_count,
                "total": total_apis,
                "failed": failed_count,
                "duration_ms": duration_ms,
                "metadata": metadata
            }
            
        except Exception as e:
            logger.error(f"Cache warming error for session {session_id}: {e}", exc_info=True)
            return {
                "success": 0,
                "total": self.api_function_registry.get_api_count(),
                "duration_ms": int((time.time() - start_time) * 1000),
                "error": str(e)
            }
        finally:
            # Always release lock
            await self.cache_manager.release_lock(lock_key)
    
    def _build_drilldown_request(self, api_name: str, filters: DirectorBaseRequest):
        """Build appropriate request object for drilldown APIs.
        
        Args:
            api_name: Name of the drilldown API
            filters: Base filter parameters
            
        Returns:
            Appropriate request object for the API
        """
        # Common fields from DirectorBaseRequest
        common_fields = {
            "user_id": filters.user_id,
            "start_date": filters.start_date,
            "end_date": filters.end_date,
            "lob": filters.lob,
            "director_ids": filters.director_ids,
            "manager_ids": filters.manager_ids,
            "frontline_associate_ids": filters.frontline_associate_ids,
        }
        
        # Fetch full dataset for shared cache (drilldown + Excel)
        pagination_fields = {
            "page": 1,
            "page_size": config.CACHE_FULL_DATASET_LIMIT  # Full dataset for unified cache strategy
        }
        
        # Map API names to their request models
        request_model_map = {
            "audit-score-director-drilldown": AuditScoreDirectorDrilldownRequest,
            "fuse-time-director-drilldown": FuseTimeDirectorDrilldownRequest,
            "work-items-director-drilldown": WorkItemsDirectorDrilldownRequest,
            "audit-error-director-drilldown": AuditErrorDirectorDrilldownPaginatedRequest,
            "completed-audit-count-drilldown": CompletedAuditCountDrilldownPaginatedRequest,
            "rebuttal-drilldown": RebuttalDrilldownPaginatedRequest,
            "rework-pct-drilldown": ReworkPctDrilldownPaginatedRequest,
            "escalation-count-drilldown": EscalationCountDrilldownPaginatedRequest,
            "pended-items-drilldown": PendedItemsDrilldownPaginatedRequest,
            "watchlist-drilldown": WatchlistDrilldownPaginatedRequest,
            "capacity-insight-drilldown": CapacityInsightDrilldownPaginatedRequest,
            "sla-health-drilldown": SlaHealthDrilldownPaginatedRequest,
            "audit-sample-pct-drilldown": AuditSamplePctDrilldownPaginatedRequest,
            "cycle-takt-drilldown": CycleTaktDrilldownPaginatedRequest,
            "production-pct-achieved-drilldown": ProductionPctAchievedDrilldownPaginatedRequest,
        }
        
        request_model = request_model_map.get(api_name)
        if not request_model:
            return None
        
        # Combine fields
        request_fields = {**common_fields, **pagination_fields}
 
        if hasattr(request_model, "model_construct"):
            return request_model.model_construct(**request_fields)
        if hasattr(request_model, "construct"):
            return request_model.construct(**request_fields)
 
        return request_model(**request_fields)
    
    async def _execute_and_cache_api_direct(
        self,
        session_id: str,
        api_name: str,
        filters: DirectorBaseRequest
    ) -> bool:
        """Execute single API function directly and cache the result with semaphore throttling.
        
        Uses semaphore to limit concurrent Redis operations and prevent connection pool exhaustion.
        
        Args:
            session_id: Session identifier
            api_name: Name of the API
            filters: Request filters
            
        Returns:
            True if successful, False otherwise
        """
        # Use semaphore to throttle concurrent Redis operations
        async with self.redis_semaphore:
            try:
                # Get the execute function and type for this API
                func_entry = self.api_function_registry.get_function_with_type(api_name)
                
                if not func_entry:
                    logger.warning(f"No execute function found for API {api_name}")
                    return False
                
                execute_func, request_type = func_entry
                
                # Build appropriate request based on API type
                if request_type == "director_base":
                    # Core API - use filters directly
                    request_obj = filters
                else:
                    # Drilldown API - build paginated request
                    request_obj = self._build_drilldown_request(api_name, filters)
                    if not request_obj:
                        logger.warning(f"Failed to build request for drilldown API {api_name}")
                        return False
                
                # Call the function directly
                result = await execute_func(request_obj)
                
                # Convert response model to dict for caching
                if hasattr(result, 'dict'):
                    result_dict = result.dict()
                elif hasattr(result, 'model_dump'):
                    result_dict = result.model_dump()
                else:
                    result_dict = dict(result)
                
                # Cache the response using chunked storage for drilldowns
                cache_key = self._build_session_key(session_id, api_name)
                
                if request_type == "director_base":
                    # Core API - store as single object (small data)
                    await self.cache_manager.set(cache_key, result_dict, ttl=self.ttl)
                else:
                    # Drilldown API - use chunked storage (large datasets)
                    records = result_dict.get("records", [])
                    if records:
                        # Extract metadata (everything except records)
                        cache_metadata = {k: v for k, v in result_dict.items() if k != "records"}
                        
                        # Store records in chunks
                        await self.cache_manager.set_chunked(
                            base_key=cache_key,
                            records=records,
                            chunk_size=config.SESSION_CACHE_CHUNK_SIZE,
                            ttl=self.ttl,
                            metadata=cache_metadata
                        )
                    else:
                        # No records - store normally
                        await self.cache_manager.set(cache_key, result_dict, ttl=self.ttl)
                
                # Use minimal logging during warming for performance
                return True
                    
            except Exception as e:
                logger.error(f"Error executing API {api_name} for session {session_id}: {e}", exc_info=True)
                return False
    
    async def get_cached_api_result(
        self,
        session_id: str,
        api_name: str,
        filters: DirectorBaseRequest,
        fetch_func: Optional[Callable] = None
    ) -> Any:
        """Get API result from cache or trigger warming.
        
        Args:
            session_id: Session identifier
            api_name: Name of the API being requested
            filters: Request filters
            fetch_func: Function to fetch data if cache warming not used
            
        Returns:
            API response (from cache or direct execution)
        """
        if not self.enabled:
            # Cache disabled - execute directly
            if fetch_func:
                return await fetch_func()
            return None
        
        # Check if session is already cached
        is_cached = await self.is_session_cached(session_id)
        
        if is_cached:
            # Session exists - retrieve from cache
            cache_key = self._build_session_key(session_id, api_name)
            result = await self.cache_manager.get(cache_key)
            
            if result:
                # Add cache metadata
                meta_key = self._build_metadata_key(session_id)
                metadata = await self.cache_manager.get(meta_key)
                
                if metadata and isinstance(result, dict):
                    # Get list of cached API names
                    apis_cached_list = []
                    if isinstance(metadata.get("apis_cached"), int):
                        # Legacy format - just show count
                        count = metadata.get("apis_cached", 0)
                        apis_cached_list = [f"{count} APIs"]
                    elif isinstance(metadata.get("apis_cached"), list):
                        apis_cached_list = metadata.get("apis_cached", [])
                    
                    result["cache_metadata"] = {
                        "cache_hit": True,
                        "cache_warming": False,
                        "session_id": session_id,
                        "cached_at": metadata.get("cached_at"),
                        "expires_at": metadata.get("expires_at"),
                        "apis_cached": apis_cached_list
                    }
                
                logger.debug(f"Cache hit for session {session_id}, API {api_name}")
                return result
        
        # Check if warming is in progress
        is_warming = await self.is_warming_in_progress(session_id)
        
        if is_warming:
            # Wait for warming to complete
            logger.info(f"Cache warming in progress for session {session_id}, waiting...")
            lock_key = self._build_lock_key(session_id)
            released = await self.cache_manager.wait_for_lock_release(lock_key, timeout=self.wait_timeout)
            
            if released:
                # Warming completed - retrieve from cache
                cache_key = self._build_session_key(session_id, api_name)
                result = await self.cache_manager.get(cache_key)
                
                if result:
                    logger.info(f"Retrieved {api_name} from cache after warming for session {session_id}")
                    return result
            else:
                logger.warning(f"Timeout waiting for warming to complete for session {session_id}")
                # Fall through to direct execution
        
        # Not cached and not warming - trigger warming in background
        if fetch_func:
            # COMPREHENSIVE WARMING: ALL APIs trigger warming of all 22 APIs (6 core + 16 drilldowns)
            logger.info(f"Cache miss for session {session_id}, API {api_name} - executing directly and triggering COMPREHENSIVE warming (22 APIs)")
            
            # Build cache metadata for first call
            cache_meta = {
                "cache_hit": False,
                "cache_warming": True,  # Always true - all APIs trigger warming
                "session_id": session_id,
                "cached_at": None,
                "expires_at": None,
                "apis_cached": 0
            }
            
            # Execute directly for immediate response - pass cache_metadata
            import inspect
            sig = inspect.signature(fetch_func)
            if 'cache_metadata' in sig.parameters:
                result = await fetch_func(cache_metadata=cache_meta)
            else:
                result = await fetch_func()
            
            # TRIGGER COMPREHENSIVE WARMING: All 22 APIs (6 core + 16 drilldowns)
            # Every API call now triggers warming of the complete set
            asyncio.create_task(self._trigger_warming_background(session_id, filters))
            
            # If result is dict and doesn't have cache_metadata, add it
            if isinstance(result, dict) and "cache_metadata" not in result:
                result["cache_metadata"] = cache_meta
            
            return result
        
        return None
    
    async def _trigger_warming_background(self, session_id: str, filters: DirectorBaseRequest) -> None:
        """Trigger cache warming in background (fire and forget).
        
        Args:
            session_id: Session identifier
            filters: Request filters to apply to all APIs
        """
        try:
            logger.info(f"Starting background cache warming for session {session_id}")
            result = await self.warm_session_cache(session_id, filters)
            logger.info(
                f"Background warming completed for session {session_id}: "
                f"{result.get('success', 0)}/{result.get('total', 0)} APIs"
            )
        except Exception as e:
            logger.error(f"Background warming failed for session {session_id}: {e}", exc_info=True)
    
    async def invalidate_session(self, session_id: str) -> None:
        """Invalidate all cached data for a session.
        
        Args:
            session_id: Session identifier
        """
        if not self.enabled:
            return
        
        try:
            # Get all API names
            all_api_names = self.api_function_registry.get_all_apis()
            
            # Build all cache keys for this session
            keys_to_delete = [self._build_session_key(session_id, api_name) for api_name in all_api_names]
            keys_to_delete.append(self._build_metadata_key(session_id))
            
            # Delete all keys
            await self.cache_manager.delete(*keys_to_delete)
            
            logger.info(f"Invalidated cache for session {session_id}")
            
        except Exception as e:
            logger.error(f"Error invalidating session {session_id}: {e}")


# Singleton instance
session_orchestrator = SessionCacheOrchestrator()
