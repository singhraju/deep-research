"""
WorkForce IQ Session Cache Service

Manages session-based caching for WorkForce IQ age-related endpoints.
Implements lock-based concurrency control to prevent duplicate cache warming
when users rapidly change filters.

Similar to Director dashboard session cache, but tailored for WorkForce IQ:
- Receipts age bucket counts
- Elevance age drilldown (full dataset)
- COB age drilldown (full dataset)
"""

import logging
import asyncio
import time
import uuid
from typing import Any, Dict, Optional
from datetime import datetime, timedelta

from utils.redis_cache import cache_manager
from utils.cache_key_builder import build_filters_hash
import config

logger = logging.getLogger(__name__)


def generate_workforce_session_id() -> str:
    """
    Generate a unique session ID for WorkForce IQ.
    
    Format: workforce_session_{timestamp}_{random_hash}
    Example: workforce_session_1775821614_abc123def
    
    Returns:
        str: Unique session identifier
    """
    timestamp = int(time.time())
    random_hash = uuid.uuid4().hex[:10]
    return f"workforce_session_{timestamp}_{random_hash}"


class WorkForceSessionCacheService:
    """Orchestrates session-based caching for WorkForce IQ age endpoints."""
    
    def __init__(self):
        self.cache_manager = cache_manager
        self.enabled = config.REDIS_ENABLED
        self.ttl = config.SESSION_CACHE_TTL  # 8 hours
        self.lock_ttl = config.SESSION_CACHE_LOCK_TTL  # 2 minutes
        self.wait_timeout = config.SESSION_CACHE_WAIT_TIMEOUT  # 60 seconds
        logger.info("WorkForce IQ session cache service initialized")
    
    def _build_session_key(self, session_id: str, endpoint_name: str, filters_hash: Optional[str] = None) -> str:
        """Build cache key for session-based caching with filter isolation.
        
        Args:
            session_id: Session identifier
            endpoint_name: Name of the endpoint (e.g., 'receipts_age')
            filters_hash: Optional hash of filter parameters for cache isolation
            
        Returns:
            Cache key in format: workforce_session:session_id:filters_hash:endpoint_name
            or workforce_session:session_id:endpoint_name (if no filters_hash)
        """
        if filters_hash:
            return f"workforce_session:{session_id}:{filters_hash}:{endpoint_name}"
        else:
            return f"workforce_session:{session_id}:{endpoint_name}"
    
    def _build_lock_key(self, session_id: str) -> str:
        """Build lock key for session coordination."""
        return f"workforce_session_lock:{session_id}"
    
    def _build_metadata_key(self, session_id: str) -> str:
        """Build metadata key for session information."""
        return f"workforce_session_meta:{session_id}"
    
    async def is_session_cached(self, session_id: str) -> bool:
        """Check if session has been cached.
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if session metadata exists in cache
        """
        if not self.enabled:
            return False
        
        meta_key = self._build_metadata_key(session_id)
        metadata = await self.cache_manager.get(meta_key)
        return metadata is not None
    
    async def is_warming_in_progress(self, session_id: str) -> bool:
        """Check if cache warming is currently in progress for session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if lock exists (warming in progress)
        """
        if not self.enabled:
            return False
        
        lock_key = self._build_lock_key(session_id)
        try:
            exists = await self.cache_manager.redis_handler.exists(lock_key)
            return bool(exists)
        except Exception as e:
            logger.error(f"Error checking warming status for session {session_id}: {e}")
            return False
    
    async def warm_age_caches(
        self,
        session_id: str,
        warm_func: callable,
        request: Any,
        filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Warm all age-related caches for a session.
        
        Args:
            session_id: Session identifier
            warm_func: Function to execute cache warming (returns dict with age data)
            request: Request object with filter parameters
            filters: Optional dictionary of filter parameters for cache isolation
            
        Returns:
            Dictionary with warming results
        """
        if not self.enabled:
            logger.info(f"Session cache disabled, executing query directly")
            return await warm_func(request)
        
        # Generate filters hash BEFORE lock acquisition to ensure consistency
        filters_hash = None
        if filters:
            filters_hash = build_filters_hash(**filters)
            logger.debug(f"Generated filters hash for cache coordination: {filters_hash}")
        
        lock_key = self._build_lock_key(session_id)
        start_time = time.time()
        lock_acquired = False  # Track whether this execution acquired the lock
        
        logger.info(f"Starting cache warming for WorkForce IQ session {session_id}")
        
        try:
            # Acquire lock
            locked = await self.cache_manager.acquire_lock(lock_key, ttl=self.lock_ttl)
            
            # Mark lock acquisition status immediately to ensure proper cleanup
            lock_acquired = locked
            
            if not locked:
                logger.warning(f"Failed to acquire lock for session {session_id} (already warming)")
                # Wait for existing warming to complete
                released = await self.cache_manager.wait_for_lock_release(lock_key, timeout=self.wait_timeout)
                if released:
                    logger.info(f"Lock released, retrieving from cache for session {session_id}")
                    # Try to get from cache after waiting - use same filters_hash as writer
                    age_key = self._build_session_key(session_id, "receipts_age", filters_hash)
                    cached_result = await self.cache_manager.get(age_key)
                    if cached_result:
                        return cached_result
                
                # If still not cached, execute directly
                logger.warning(f"Timeout waiting for warming, executing directly for session {session_id}")
                return await warm_func(request)
            
            # Execute warming function (returns dict with age data)
            result = await warm_func(request)
            
            # Cache receipts_age result with filters hash (same key used by waiter path)
            age_key = self._build_session_key(session_id, "receipts_age", filters_hash)
            
            # Store in cache
            await self.cache_manager.set(age_key, result.get("age_response"), ttl=self.ttl)
            
            # Calculate duration
            duration_ms = int((time.time() - start_time) * 1000)
            
            # Store session metadata
            metadata = {
                "session_id": session_id,
                "cached_at": datetime.utcnow().isoformat(),
                "expires_at": (datetime.utcnow() + timedelta(seconds=self.ttl)).isoformat(),
                "endpoints_cached": ["receipts_age"],
                "warming_duration_ms": duration_ms
            }
            
            meta_key = self._build_metadata_key(session_id)
            await self.cache_manager.set(meta_key, metadata, ttl=self.ttl)
            
            logger.info(
                f"Cache warming completed for WorkForce IQ session {session_id}: "
                f"receipts_age cached in {duration_ms}ms"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Cache warming error for session {session_id}: {e}", exc_info=True)
            # Fall back to direct execution
            return await warm_func(request)
        finally:
            # Only release lock if this execution acquired it
            if lock_acquired:
                await self.cache_manager.release_lock(lock_key)
    
    async def get_cached_result(
        self,
        session_id: str,
        endpoint_name: str,
        execute_func: Optional[callable] = None,
        filters: Optional[Dict[str, Any]] = None
    ) -> Any:
        """Get result from cache or execute function.
        
        Args:
            session_id: Session identifier
            endpoint_name: Name of the endpoint (receipts_age, elevance_age_drilldown, cob_age_drilldown)
            execute_func: Function to execute if cache miss
            filters: Optional dictionary of filter parameters for cache isolation
            
        Returns:
            Cached result or executed result
        """
        if not self.enabled:
            if execute_func:
                return await execute_func()
            return None
        
        # Generate filters hash if filters provided
        filters_hash = None
        if filters:
            filters_hash = build_filters_hash(**filters)
            logger.debug(f"Generated filters hash: {filters_hash} for endpoint: {endpoint_name}")
        
        # Try to get from cache
        cache_key = self._build_session_key(session_id, endpoint_name, filters_hash)
        cached_result = await self.cache_manager.get(cache_key)
        
        if cached_result:
            logger.info(f"Cache hit for WorkForce IQ session {session_id}, endpoint {endpoint_name}")
            return cached_result
        
        # Cache miss - check if warming is in progress
        is_warming = await self.is_warming_in_progress(session_id)
        
        if is_warming:
            logger.info(f"Cache warming in progress for session {session_id}, waiting...")
            lock_key = self._build_lock_key(session_id)
            released = await self.cache_manager.wait_for_lock_release(lock_key, timeout=self.wait_timeout)
            
            if released:
                # Try to get from cache again
                cached_result = await self.cache_manager.get(cache_key)
                if cached_result:
                    logger.info(f"Retrieved {endpoint_name} from cache after warming for session {session_id}")
                    return cached_result
        
        # Not cached and not warming - execute directly
        if execute_func:
            logger.info(f"Cache miss for session {session_id}, endpoint {endpoint_name}, executing directly")
            return await execute_func()
        
        return None
    
    async def invalidate_session(self, session_id: str) -> None:
        """Invalidate all cached data for a session.
        
        Args:
            session_id: Session identifier
        """
        if not self.enabled:
            return
        
        try:
            # Build cache keys for this session
            keys_to_delete = [
                self._build_session_key(session_id, "receipts_age"),
                self._build_metadata_key(session_id)
            ]
            
            # Delete all keys
            await self.cache_manager.delete(*keys_to_delete)
            
            logger.info(f"Invalidated cache for WorkForce IQ session {session_id}")
            
        except Exception as e:
            logger.error(f"Error invalidating session {session_id}: {e}")


# Singleton instance
workforce_session_cache_service = WorkForceSessionCacheService()
