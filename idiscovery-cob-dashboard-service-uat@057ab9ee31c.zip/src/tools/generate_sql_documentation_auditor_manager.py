"""
Script to execute all Performance IQ Auditor Manager APIs and save SQL queries to documentation.
This script will extract SQL queries from each Auditor Manager API endpoint.
"""
import sys
import os
import csv
import logging
import asyncio
import json
import inspect
from datetime import datetime

# Add src directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from controllers.Performance_IQ_Auditor_Manager import (
    header_kpis,
    time_utilization,
    ata_score_gauge,
    audit_cycle_time_gauge,
    rebuttals,
    auditor_list,
    manager_list,
    completed_audit_count_drilldown,
    audit_sample_pct_drilldown,
    ata_score_drilldown,
    rebuttal_drilldown,
    work_items_drilldown,
    fuse_time_drilldown,
    auditor_manager_lob,
    ai_coach_auditor_manager,
    quality_outcomes,
    ata_rebuttal_drilldown,
    user_activity
)
# Import common build functions from header_kpis for use across all modules
from controllers.Performance_IQ_Auditor_Manager.header_kpis import (
    build_lob_filter as common_build_lob_filter,
    build_date_filter as common_build_date_filter,
    build_manager_filter as common_build_manager_filter,
    build_associate_filter as common_build_associate_filter,
    build_auditor_filter as common_build_auditor_filter,
    build_auditor_filter_resolved as common_build_auditor_filter_resolved,
    build_manager_filter_user as common_build_manager_filter_user,
    build_auditor_filter_user as common_build_auditor_filter_user,
    build_manager_filter_audit as common_build_manager_filter_audit,
    build_manager_filter_invntry as common_build_manager_filter_invntry,
    build_audit_subject_manager_filter as common_build_audit_subject_manager_filter,
    build_date_filter_created as common_build_date_filter_created,
    build_auditor_ids_list as common_build_auditor_ids_list,
    build_date_filter_between as common_build_date_filter_between,
    build_invntry_manager_filter as common_build_invntry_manager_filter,
    build_invntry_associate_filter as common_build_invntry_associate_filter,
    build_audit_sample_resolved_start_filter as common_build_audit_sample_resolved_start_filter,
    build_audit_sample_resolved_end_filter as common_build_audit_sample_resolved_end_filter,
    build_audit_sample_associate_filter as common_build_audit_sample_associate_filter,
    build_audit_sample_audit_start_filter as common_build_audit_sample_audit_start_filter,
    build_audit_sample_audit_end_filter as common_build_audit_sample_audit_end_filter,
    build_audit_sample_audit_associate_filter as common_build_audit_sample_audit_associate_filter,
    build_audit_period_filter as common_build_audit_period_filter,
)
# Import additional build functions from other modules
from controllers.Performance_IQ_Auditor_Manager.audit_sample_pct_drilldown import (
    build_audit_subject_filter as common_build_audit_subject_filter,
    build_date_filter_ata as common_build_date_filter_ata,
)
from controllers.Performance_IQ_Auditor_Manager.work_items_drilldown import (
    build_user_date_filter as common_build_user_date_filter,
)
from controllers.Performance_IQ_Auditor_Manager.auditor_manager_lob import (
    build_auditor_filter_invntry as common_build_auditor_filter_invntry,
    build_auditor_filter_audit as common_build_auditor_filter_audit,
)
from controllers.Performance_IQ_Auditor_Manager.fuse_time_drilldown import (
    build_associate_filter_invntry as common_build_associate_filter_invntry,
)
from schema import AuditorManagerBaseRequest, AuditPeriod
from pydantic import BaseModel
from typing import Any, Dict, List, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Test payload for non-drilldown APIs
PAYLOAD = {
    "user_id": "AM62084",
    "manager_ids": ["AC95624"],
    "auditor_ids": ["AG50550"],
    "start_date": "2026-07-01",
    "end_date": "2026-07-29",
    "audit_periods": [],
    "lob": ["Commercial"],
    "session_id": "session_1785331397538_6yx5jrghi",
}

AUDIT_PERIODS_SAMPLE = [
    {"year": "2026", "month": "May"},
    {"year": "2026", "month": "June"},
]

AUDIT_PERIOD_PAYLOAD = {
    **PAYLOAD,
    "audit_periods": AUDIT_PERIODS_SAMPLE,
}

# Pagination payload for drilldown APIs
PAGINATION_PAYLOAD = {
    "user_id": "AM62084",
    "manager_ids": ["AC95624"],
    "auditor_ids": ["AG50550"],
    "start_date": "2026-07-01",
    "end_date": "2026-07-29",
    "audit_periods": [],
    "lob": ["Commercial", "Medicaid", "Medicare"],
    "session_id": "session_1785331397538_6yx5jrghi",
    "page": 1,
    "page_size": 20
}

PAGINATION_AUDIT_PERIOD_PAYLOAD = {
    **PAGINATION_PAYLOAD,
    "audit_periods": AUDIT_PERIODS_SAMPLE,
}

# List of drilldown modules that need pagination
DRILLDOWN_MODULES = [
    'completed_audit_count_drilldown',
    'audit_sample_pct_drilldown',
    'ata_score_drilldown',
    'rebuttal_drilldown',
    'work_items_drilldown',
    'fuse_time_drilldown',
    'ata_rebuttal_drilldown'
]

AUDIT_PERIOD_MODULES = {
    'header_kpis',
    'ata_score_gauge',
    'audit_cycle_time_gauge',
    'rebuttals',
    'completed_audit_count_drilldown',
    'audit_sample_pct_drilldown',
    'ata_score_drilldown',
    'rebuttal_drilldown',
    'ata_rebuttal_drilldown',
    'user_activity',
}

MODULE_SORT_OVERRIDES = {
    'completed_audit_count_drilldown': {'sort_by': 'audit_resolved_date', 'sort_direction': 'desc'},
    'ata_score_drilldown': {'sort_by': 'audit_resolved', 'sort_direction': 'desc'},
    'rebuttal_drilldown': {'sort_by': 'resolved_date', 'sort_direction': 'desc'},
    'work_items_drilldown': {'sort_by': 'resolved_date', 'sort_direction': 'desc'},
    'fuse_time_drilldown': {'sort_by': 'date', 'sort_direction': 'desc'},
}

MODULE_MANAGER_FILTER_BUILDERS = {
    'header_kpis': common_build_manager_filter_audit,
    'audit_cycle_time_gauge': common_build_manager_filter_audit,
    'rebuttals': common_build_manager_filter_audit,
    'completed_audit_count_drilldown': common_build_manager_filter_audit,
    'rebuttal_drilldown': common_build_manager_filter_audit,
    'quality_outcomes': common_build_manager_filter_audit,
    'work_items_drilldown': common_build_manager_filter_invntry,
}

AUDIT_PERIOD_PLACEHOLDER_CONFIG = {
    ('header_kpis', 'COMPLETED_AUDIT_COUNT_QUERY', 'audit_period_filter'): 'completion_ts',
    ('header_kpis', 'AUDIT_SAMPLE_PCT_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('header_kpis', 'AUDIT_CYCLE_TIME_QUERY', 'audit_period_filter'): 'completion_ts',
    ('header_kpis', 'ATA_AUDIT_SCORE_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('header_kpis', 'ATA_REBUTTALS_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('header_kpis', 'ATA_REBUTTAL_PCT_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('ata_score_gauge', 'ATA_AUDIT_SCORE_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('ata_score_gauge', 'ATA_SCORE_TREND_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('audit_cycle_time_gauge', 'AUDIT_CYCLE_TIME_QUERY', 'audit_period_filter'): 'completion_ts',
    ('audit_cycle_time_gauge', 'AUDIT_CYCLE_TIME_TREND_QUERY', 'audit_period_filter'): 'completion_ts',
    ('rebuttals', 'REBUTTALS_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('rebuttals', 'REBUTTALS_OVERTURN_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('rebuttals', 'REBUTTALS_TREND_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('completed_audit_count_drilldown', 'COMPLETED_AUDIT_COUNT_QUERY', 'audit_period_filter'): 'completion_ts',
    ('completed_audit_count_drilldown', 'COMPLETED_AUDIT_COUNT_PAGINATED_QUERY', 'audit_period_filter'): 'completion_ts',
    ('audit_sample_pct_drilldown', 'AUDIT_SAMPLE_PCT_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('ata_score_drilldown', 'ATA_AUDIT_SCORE_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('ata_score_drilldown', 'ATA_AUDIT_SCORE_PAGINATED_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('rebuttal_drilldown', 'REBUTTALS_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('rebuttal_drilldown', 'REBUTTAL_PAGINATED_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('ata_rebuttal_drilldown', 'ATA_REBUTTALS_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('ata_rebuttal_drilldown', 'ATA_REBUTTAL_PAGINATED_QUERY', 'audit_period_filter'): 'PXCREATEDATETIME',
    ('user_activity', 'AUDIT_TEAM_RANK_QUERY', 'audit_period_filter'): 'completion_ts',
    ('user_activity', 'AUDIT_TEAM_RANK_QUERY', 'ata_audit_period_filter'): 'completion_timestamp',
}

async def call_api_and_get_response(module, request):
    """Call the API endpoint and capture the actual response data."""
    try:
        if hasattr(module, 'router'):
            router = module.router
            # Get the endpoint function from the router
            for route in router.routes:
                if hasattr(route, 'endpoint'):
                    endpoint_func = route.endpoint
                    # Call the async endpoint function
                    response = await endpoint_func(request)
                    
                    # Convert response to dict
                    if hasattr(response, 'dict'):
                        # Pydantic v1
                        response_dict = response.dict()
                    elif hasattr(response, 'model_dump'):
                        # Pydantic v2
                        response_dict = response.model_dump()
                    else:
                        response_dict = dict(response)
                    
                    # Convert to JSON string for storage
                    return json.dumps(response_dict, indent=2, default=str)
    except Exception as e:
        logger.warning(f"Could not call API for {module.__name__}: {e}")
        return f"Error: {str(e)}"
    
    return "N/A"

async def call_build_function(func, *args, **kwargs):
    """Helper to call a build function, handling both sync and async functions."""
    try:
        result = func(*args, **kwargs)
        # Check if result is a coroutine (async function was called)
        if inspect.iscoroutine(result):
            return await result
        return result
    except Exception as e:
        logger.warning(f"Error calling build function {func.__name__}: {e}")
        return ""

def clone_request_with_updates(request: BaseModel, **updates):
    if hasattr(request, 'model_copy'):
        return request.model_copy(update=updates)
    return request.copy(update=updates)


def request_to_payload(request: BaseModel) -> Dict[str, Any]:
    if hasattr(request, 'model_dump'):
        return request.model_dump(exclude_none=True)
    return request.dict(exclude_none=True)


def get_effective_request_for_module(module_name: str, request: BaseModel):
    if module_name not in MODULE_SORT_OVERRIDES or not hasattr(request, 'sort_by'):
        return request
    return clone_request_with_updates(request, **MODULE_SORT_OVERRIDES[module_name])


async def build_manager_filter_replacement(module_name: str, module, request: BaseModel) -> str:
    build_manager_fn = MODULE_MANAGER_FILTER_BUILDERS.get(module_name)
    if build_manager_fn is None:
        build_manager_fn = getattr(module, 'build_manager_filter', None) or common_build_manager_filter
    managers = request.manager_ids if hasattr(request, 'manager_ids') else None
    return await call_build_function(build_manager_fn, managers)


async def build_audit_period_placeholder_value(module_name: str, query_name: str, placeholder_name: str, request: BaseModel) -> str:
    timestamp_column = AUDIT_PERIOD_PLACEHOLDER_CONFIG.get((module_name, query_name, placeholder_name))
    if not timestamp_column:
        logger.warning(
            "No audit period placeholder mapping found for %s.%s (%s)",
            module_name,
            query_name,
            placeholder_name,
        )
        return ""

    start = request.start_date if hasattr(request, 'start_date') else None
    end = request.end_date if hasattr(request, 'end_date') else None
    audit_periods = request.audit_periods if hasattr(request, 'audit_periods') else None

    return await call_build_function(
        common_build_audit_period_filter,
        start,
        end,
        audit_periods,
        timestamp_column=timestamp_column,
        audit_month_column="AUDIT_MONTH",
        audit_year_column="AUDIT_YEAR",
    )


async def build_grouping_replacements(module, request: BaseModel, query_template: str) -> Dict[str, str]:
    replacements: Dict[str, str] = {}
    uses_grouping_type = '{{grouping_type}}' in query_template or '{grouping_type}' in query_template
    uses_audit_period_grouping = '{{use_audit_period_grouping}}' in query_template or '{use_audit_period_grouping}' in query_template

    if not uses_grouping_type and not uses_audit_period_grouping:
        return replacements

    start = request.start_date if hasattr(request, 'start_date') else None
    end = request.end_date if hasattr(request, 'end_date') else None
    audit_periods = request.audit_periods if hasattr(request, 'audit_periods') else None

    if uses_grouping_type:
        get_grouping_type_fn = getattr(module, 'get_trend_grouping_type', None)
        if get_grouping_type_fn:
            replacements['grouping_type'] = await call_build_function(
                get_grouping_type_fn,
                start,
                end,
                audit_periods,
            )
        else:
            replacements['grouping_type'] = 'monthly'

    if uses_audit_period_grouping:
        has_valid_audit_periods_fn = getattr(module, 'has_valid_audit_periods', None)
        if has_valid_audit_periods_fn:
            use_audit_period_grouping = await call_build_function(has_valid_audit_periods_fn, audit_periods)
        else:
            use_audit_period_grouping = bool(audit_periods)
        replacements['use_audit_period_grouping'] = str(bool(use_audit_period_grouping)).lower()

    return replacements


def get_query_sort_transformer(module):
    for attribute_name in dir(module):
        if attribute_name.startswith('apply_custom_sort_to_') and attribute_name.endswith('_query'):
            sort_transformer = getattr(module, attribute_name)
            if callable(sort_transformer):
                return sort_transformer
    return None


async def extract_sql_from_module(module, request, mode):
    """Extract SQL queries from a module by building filters and formatting queries."""
    sql_queries = []
    module_name = module.__name__.split('.')[-1]
    request = get_effective_request_for_module(module_name, request)
    query_sort_transformer = get_query_sort_transformer(module)

    # Get actual API response
    # Commented out to avoid server dependency - just extract SQL queries
    # logger.info(f"  Calling API for {module_name}...")
    # api_response = await call_api_and_get_response(module, request)
    api_response = "SQL Query Only (API call skipped)"

    try:
        # Build common filters using the appropriate request
        # Use module's own function if available, otherwise use common function from header_kpis
        lob_filter = ""
        date_filter = ""
        auditor_filter = ""
        manager_filter = ""

        # LOB filter
        build_lob_fn = getattr(module, 'build_lob_filter', None) or common_build_lob_filter
        lob_filter = await call_build_function(build_lob_fn, request.lob if hasattr(request, 'lob') else None)

        # Date filter
        build_date_fn = getattr(module, 'build_date_filter', None) or common_build_date_filter
        start = request.start_date if hasattr(request, 'start_date') else None
        end = request.end_date if hasattr(request, 'end_date') else None
        date_filter = await call_build_function(build_date_fn, start, end)

        # Auditor filter
        build_auditor_fn = getattr(module, 'build_auditor_filter', None) or common_build_auditor_filter
        auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
        auditor_filter = await call_build_function(build_auditor_fn, auditors)

        # Manager filter
        manager_filter = await build_manager_filter_replacement(module_name, module, request)

        # Find all SQL query constants in the module
        for attr_name in dir(module):
            if attr_name.endswith('_QUERY') and attr_name.isupper():
                query_template = getattr(module, attr_name)
                if isinstance(query_template, str) and 'SELECT' in query_template.upper():
                    try:
                        # Try to format the query with available filters
                        formatted_query = query_template

                        # Replace common placeholders - handle both {{}} and {} formats
                        replacements = {
                            'lob_filter': lob_filter,
                            'date_filter': date_filter,
                            'auditor_filter': auditor_filter,
                            'manager_filter': manager_filter,
                        }

                        for audit_period_placeholder in ('audit_period_filter', 'ata_audit_period_filter'):
                            if (
                                '{{' + audit_period_placeholder + '}}' in query_template
                                or '{' + audit_period_placeholder + '}' in query_template
                            ):
                                replacements[audit_period_placeholder] = await build_audit_period_placeholder_value(
                                    module_name,
                                    attr_name,
                                    audit_period_placeholder,
                                    request,
                                )

                        replacements.update(await build_grouping_replacements(module, request, query_template))

                        # Add module-specific filters (use common functions as fallback)
                        # auditor_filter_resolved
                        build_auditor_resolved_fn = getattr(module, 'build_auditor_filter_resolved', None) or common_build_auditor_filter_resolved
                        auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                        replacements['auditor_filter_resolved'] = await call_build_function(build_auditor_resolved_fn, auditors)

                        # manager_filter_user
                        build_manager_user_fn = getattr(module, 'build_manager_filter_user', None) or common_build_manager_filter_user
                        managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                        replacements['manager_filter_user'] = await call_build_function(build_manager_user_fn, managers)

                        # auditor_filter_user
                        build_auditor_user_fn = getattr(module, 'build_auditor_filter_user', None) or common_build_auditor_filter_user
                        auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                        replacements['auditor_filter_user'] = await call_build_function(build_auditor_user_fn, auditors)

                        # manager_filter_audit
                        build_manager_audit_fn = getattr(module, 'build_manager_filter_audit', None) or common_build_manager_filter_audit
                        managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                        replacements['manager_filter_audit'] = await call_build_function(build_manager_audit_fn, managers)

                        # manager_filter_invntry
                        build_manager_invntry_fn = getattr(module, 'build_manager_filter_invntry', None) or common_build_manager_filter_invntry
                        managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                        replacements['manager_filter_invntry'] = await call_build_function(build_manager_invntry_fn, managers)

                        # audit_subject_manager_filter
                        build_audit_subj_mgr_fn = getattr(module, 'build_audit_subject_manager_filter', None) or common_build_audit_subject_manager_filter
                        managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                        replacements['audit_subject_manager_filter'] = await call_build_function(build_audit_subj_mgr_fn, managers)

                        # date_filter_created
                        build_date_created_fn = getattr(module, 'build_date_filter_created', None) or common_build_date_filter_created
                        start = request.start_date if hasattr(request, 'start_date') else None
                        end = request.end_date if hasattr(request, 'end_date') else None
                        replacements['date_filter_created'] = await call_build_function(build_date_created_fn, start, end)

                        if hasattr(module, 'build_auditor_ids_list'):
                            auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                            replacements['auditor_ids_list'] = await call_build_function(module.build_auditor_ids_list, auditors)

                        if hasattr(module, 'build_date_filter_between'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['date_filter_between'] = await call_build_function(module.build_date_filter_between, start, end)

                        if hasattr(module, 'build_invntry_manager_filter'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['invntry_manager_filter'] = await call_build_function(module.build_invntry_manager_filter, managers)

                        if hasattr(module, 'build_invntry_associate_filter'):
                            auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                            replacements['invntry_associate_filter'] = await call_build_function(module.build_invntry_associate_filter, auditors)

                        if hasattr(module, 'build_audit_sample_resolved_start_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            replacements['audit_sample_resolved_start_filter'] = await call_build_function(module.build_audit_sample_resolved_start_filter, start)

                        if hasattr(module, 'build_audit_sample_resolved_end_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['audit_sample_resolved_end_filter'] = await call_build_function(module.build_audit_sample_resolved_end_filter, end)

                        if hasattr(module, 'build_audit_sample_associate_filter'):
                            auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                            replacements['audit_sample_associate_filter'] = await call_build_function(module.build_audit_sample_associate_filter, auditors)

                        if hasattr(module, 'build_audit_sample_audit_start_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            replacements['audit_sample_audit_start_filter'] = await call_build_function(module.build_audit_sample_audit_start_filter, start)

                        if hasattr(module, 'build_audit_sample_audit_end_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['audit_sample_audit_end_filter'] = await call_build_function(module.build_audit_sample_audit_end_filter, end)

                        if hasattr(module, 'build_audit_sample_audit_associate_filter'):
                            auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                            replacements['audit_sample_audit_associate_filter'] = await call_build_function(module.build_audit_sample_audit_associate_filter, auditors)

                        if hasattr(module, 'build_associate_filter'):
                            auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                            replacements['associate_filter'] = await call_build_function(module.build_associate_filter, auditors)

                        # MISSING FILTERS - Use common functions with fallback
                        # 1. build_audit_subject_filter - for ATA queries
                        build_audit_subj_fn = getattr(module, 'build_audit_subject_filter', None) or common_build_audit_subject_filter
                        auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                        replacements['audit_subject_filter'] = await call_build_function(build_audit_subj_fn, auditors)

                        # 2. build_date_filter_ata - for audit created date
                        build_date_ata_fn = getattr(module, 'build_date_filter_ata', None) or common_build_date_filter_ata
                        start = request.start_date if hasattr(request, 'start_date') else None
                        end = request.end_date if hasattr(request, 'end_date') else None
                        replacements['date_filter_ata'] = await call_build_function(build_date_ata_fn, start, end)

                        # 3. build_auditor_filter_invntry - for inventory table auditor filtering
                        build_auditor_invntry_fn = getattr(module, 'build_auditor_filter_invntry', None) or common_build_auditor_filter_invntry
                        auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                        replacements['auditor_filter_invntry'] = await call_build_function(build_auditor_invntry_fn, auditors)

                        # 4. build_auditor_filter_audit - for audit table auditor filtering
                        build_auditor_audit_fn = getattr(module, 'build_auditor_filter_audit', None) or common_build_auditor_filter_audit
                        auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                        replacements['auditor_filter_audit'] = await call_build_function(build_auditor_audit_fn, auditors)

                        # 5. build_user_date_filter - for user login date filtering
                        build_user_date_fn = getattr(module, 'build_user_date_filter', None) or common_build_user_date_filter
                        start = request.start_date if hasattr(request, 'start_date') else None
                        end = request.end_date if hasattr(request, 'end_date') else None
                        replacements['user_date_filter'] = await call_build_function(build_user_date_fn, start, end)

                        # 6. build_associate_filter_invntry - alias for auditor filter on inventory
                        build_assoc_invntry_fn = getattr(module, 'build_associate_filter_invntry', None) or common_build_associate_filter_invntry
                        auditors = request.auditor_ids if hasattr(request, 'auditor_ids') else None
                        replacements['associate_filter_invntry'] = await call_build_function(build_assoc_invntry_fn, auditors)

                        # 7. build_manager_filter_audit as auditor_manager_filter (rebuttal drilldown uses this)
                        if 'auditor_manager_filter' in query_template:
                            build_auditor_mgr_filter_fn = getattr(module, 'build_manager_filter_audit', None) or common_build_manager_filter_audit
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['auditor_manager_filter'] = await call_build_function(build_auditor_mgr_filter_fn, managers)

                        # 8. build_access_group_filter - for manager list
                        if hasattr(module, 'build_access_group_filter'):
                            # This function needs user_access_group parameter, but we'll call it with None for documentation
                            replacements['access_group_filter'] = ""

                        # Add user_id as direct replacement
                        replacements['user_id'] = request.user_id if hasattr(request, 'user_id') else ''

                        # Add start_date and end_date as direct replacements
                        replacements['start_date'] = request.start_date if hasattr(request, 'start_date') else ''
                        replacements['end_date'] = request.end_date if hasattr(request, 'end_date') else ''

                        # Config imports (SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA)
                        from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
                        replacements['SNOWFLAKE_DATABASE'] = SNOWFLAKE_DATABASE
                        replacements['SNOWFLAKE_SCHEMA'] = SNOWFLAKE_SCHEMA

                        # Add pagination placeholders
                        if hasattr(request, 'page') and hasattr(request, 'page_size'):
                            offset = (request.page - 1) * request.page_size
                            replacements['limit'] = str(request.page_size)
                            replacements['offset'] = str(offset)
                            replacements['page_size'] = str(request.page_size)
                        else:
                            replacements['limit'] = '20'
                            replacements['offset'] = '0'
                            replacements['page_size'] = '20'

                        # Handle both {{placeholder}} and {placeholder} formats
                        for key, value in replacements.items():
                            formatted_query = formatted_query.replace('{{' + key + '}}', str(value))
                            formatted_query = formatted_query.replace('{' + key + '}', str(value))

                        if query_sort_transformer and attr_name.endswith('PAGINATED_QUERY'):
                            sort_by = request.sort_by if hasattr(request, 'sort_by') else None
                            sort_direction = request.sort_direction if hasattr(request, 'sort_direction') else None
                            formatted_query = await call_build_function(
                                query_sort_transformer,
                                formatted_query,
                                sort_by,
                                sort_direction,
                            )

                        sql_queries.append({
                            'module': module_name,
                            'query_name': attr_name,
                            'mode': mode,
                            'payload': request_to_payload(request),
                            'sql': formatted_query.strip(),
                            'api_response': api_response
                        })

                    except KeyError as e:
                        logger.warning(f"Could not format query {attr_name} in {module_name}: missing placeholder {e}")
                    except Exception as e:
                        logger.warning(f"Could not format query {attr_name} in {module_name}: {e}")
    except Exception as e:
        logger.error(f"Error processing module {module_name}: {e}")

    return sql_queries

# Define Pydantic request models
class PaginationRequest(BaseModel):
    user_id: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    audit_periods: Optional[List[AuditPeriod]] = None
    lob: Optional[List[str]] = None
    manager_ids: Optional[List[str]] = None
    auditor_ids: Optional[List[str]] = None
    session_id: Optional[str] = None
    sort_by: Optional[str] = None
    sort_direction: Optional[str] = None
    page: int = 1
    page_size: int = 20

async def main():
    """Main function to extract SQL from all modules."""
    logger.info("Starting SQL extraction for Auditor Manager APIs...")
    
    # Create request objects
    date_range_base_request = AuditorManagerBaseRequest(**PAYLOAD)
    audit_period_base_request = AuditorManagerBaseRequest(**AUDIT_PERIOD_PAYLOAD)
    date_range_pagination_request = PaginationRequest(**PAGINATION_PAYLOAD)
    audit_period_pagination_request = PaginationRequest(**PAGINATION_AUDIT_PERIOD_PAYLOAD)
    
    # List of all modules to process
    modules = [
        header_kpis,
        time_utilization,
        ata_score_gauge,
        audit_cycle_time_gauge,
        rebuttals,
        auditor_list,
        manager_list,
        completed_audit_count_drilldown,
        audit_sample_pct_drilldown,
        ata_score_drilldown,
        rebuttal_drilldown,
        work_items_drilldown,
        fuse_time_drilldown,
        auditor_manager_lob,
        ai_coach_auditor_manager,
        quality_outcomes,
        ata_rebuttal_drilldown,
        user_activity
    ]
    
    all_sql_queries = []
    
    # Extract SQL from each module
    for module in modules:
        logger.info(f"Processing module: {module.__name__}")
        module_name = module.__name__.split('.')[-1]
        module_queries = []

        date_range_request = date_range_pagination_request if module_name in DRILLDOWN_MODULES else date_range_base_request
        module_queries.extend(await extract_sql_from_module(module, date_range_request, "date_range"))

        if module_name in AUDIT_PERIOD_MODULES:
            audit_period_request = audit_period_pagination_request if module_name in DRILLDOWN_MODULES else audit_period_base_request
            module_queries.extend(await extract_sql_from_module(module, audit_period_request, "audit_period"))

        all_sql_queries.extend(module_queries)
        logger.info(f"  Found {len(module_queries)} queries")
    
    # Write to README
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"AUDITOR_MANAGER_API_SQL_DOCUMENTATION.md"
    
    # Group queries by module
    from collections import defaultdict, Counter
    queries_by_module = defaultdict(list)
    for query in all_sql_queries:
        queries_by_module[query['module']].append(query)
    
    # Write comprehensive README
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# Performance IQ Auditor Manager API - SQL Documentation\n\n")
        f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"**Total APIs:** {len(modules)}\n")
        f.write(f"**Total SQL Queries:** {len(all_sql_queries)}\n\n")
        
        # Table of Contents
        f.write("## Table of Contents\n\n")
        for i, module_name in enumerate(sorted(queries_by_module.keys()), 1):
            query_count = len(queries_by_module[module_name])
            f.write(f"{i}. [{module_name}](#{module_name.replace('_', '-')}) ({query_count} queries)\n")
        f.write("\n---\n\n")
        
        # Detailed documentation for each module
        for module_name in sorted(queries_by_module.keys()):
            queries = queries_by_module[module_name]
            f.write(f"## {module_name}\n\n")
            f.write(f"**Number of Queries:** {len(queries)}\n\n")
            
            for i, query in enumerate(queries, 1):
                f.write(f"### {i}. {query['query_name']}\n\n")
                f.write(f"**Mode:** `{query['mode']}`\n\n")
                f.write("**Payload Used:**\n\n")
                f.write("```json\n")
                f.write(json.dumps(query['payload'], indent=2))
                f.write("\n```\n\n")
                f.write("**SQL Query:**\n\n")
                f.write("```sql\n")
                f.write(query['sql'])
                f.write("\n```\n\n")
                f.write("---\n\n")
    
    logger.info("\n" + "="*80)
    logger.info("SQL extraction complete!")
    logger.info(f"Total queries extracted: {len(all_sql_queries)}")
    logger.info(f"Output file: {output_file}")
    logger.info("="*80 + "\n")
    
    # Print summary by module
    logger.info("Queries per module:")
    for module_name in sorted(queries_by_module.keys()):
        logger.info(f"  {module_name}: {len(queries_by_module[module_name])}")

if __name__ == "__main__":
    asyncio.run(main())
