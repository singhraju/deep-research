"""
Script to execute all Performance IQ Director APIs and save SQL queries to CSV.
This script will call each endpoint with the provided payload and capture the generated SQL queries.
"""
import sys
import os
import csv
import logging
import asyncio
import json
import inspect
from datetime import datetime

# Add src directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from controllers.Performance_IQ_Director import (
    header_kpis,
    demand_inventory,
    operational_flow,
    quality_outcomes,
    associate_utilization,
    sla_health,
    escalation_count_drilldown,
    pended_items_counts_drilldown,
    production_pct_achieved_drilldown,
    rebuttal_drilldown,
    audit_score_director_drilldown,
    fuse_time_director_drilldown,
    work_items_director_drilldown,
    capacity_insight_drilldown,
    sla_health_drilldown,
    audit_sample_pct_drilldown,
    watchlist_drilldown,
    rework_pct_drilldown,
    completed_audit_count_drilldown,
    ai_coach_director,
    associates_list,
    audit_error_director_drilldown,
    cycle_takt_drilldown,
    director_list,
    director_lob,
    director_user_activity,
    managers_list
)
from schema import DirectorBaseRequest

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Test payload for non-drilldown APIs
PAYLOAD = {
    "user_id": "AB77504",
    "start_date": "2026-04-01",
    "end_date": "2026-04-14",
    "lob": ["Commercial", "EGR", "GRS", "Medicaid", "Medicare", "None"],
    "director_ids": ["SANTICH"],
    "manager_ids": ["AH79824", "HARPEDN", "AD23980", "AG54148", "AC85459", "AH89970", "AG66523", "MEYERCH", "AC85676", "VLGRIGG", "AC87144", "AD48374", "AC87000", "AL50205", "AM67537", "RCH0301", "AE08708", "LUCASCR", "LYONSML", "AL96141", "LYKINDN", "AB40695", "AA71486", "AL93492", "AL50321", "AB22155", "ROSETSC", "SANTICH", "AD59226", "AH48411", "AB32568", "AC55351", "AC85601", "AB42481", "WILLIHR", "AG40722"],
    "frontline_associate_ids": ["AL89026", "AL06130", "AH36147", "ABSHEMN", "AH93714", "AG69408", "AB86043", "AF41565", "AC80655", "AA37988", "AL06110", "AD28415", "AL71961", "AF87904", "AH51176", "AL87298", "AL72429", "AH49017", "AD66122", "AF81154", "AD92754", "AL06193", "AL25054", "AG38776", "AE09148", "AB80277", "AD07810", "AA76390", "AG32983", "AC93537", "AF04799", "AD49574", "AG11943", "AH45714", "AL06106", "AA74146", "AL52002", "AB26472", "AD60355", "AH89288", "AG07245", "AD93011", "AF03176", "AI05065", "AL42117", "AL77130", "AH49575", "AG67968", "MCCOWLS", "AD09821", "AC77516", "AF60339", "AG17296", "AH23177", "HILSOGW", "RCH0825", "AL06148", "AI06732", "SMITHLR", "AB73830", "AG03652", "AH29995", "AL41742", "AD37776", "GENIEBR", "AL67447", "AL25023", "AC87929", "AG34022", "AA56975", "AA74713", "BURNSLC", "AL25041", "AM26456", "AL19218", "AD07864", "AL87284", "AF17474", "CAMBIST", "AF96818", "AD27845", "AH71055", "AH46771", "AL87935", "AH47520", "CHADWLR", "AC62545", "TLCHAMB", "AG12941", "CHAPPLD", "AF43626", "AH86357", "AA75020", "AL87293", "AE03231", "1694MU", "AF77812", "AG37359", "CHOUIBR", "AL28448", "AM40200", "AB77920", "AB63059", "AB16441", "AG18167", "AD25827", "AL07185", "AD72098", "AG17454", "AC87258", "AG37977", "AG43921", "AH49003", "AH23172", "AD61670", "AC86407", "AL87805", "AL48579", "AL87296", "AG97528", "AG19761", "AB58771", "AF32607", "AH47515", "DEBORPM", "AL37336", "AA87228", "AD44668", "AC51885", "AM27147", "AH70026", "AC21803", "AL48587", "ZGCC228", "AB45725", "AL41838", "AF08727", "AH44962", "AH47516", "AL88207", "AB58018", "AA80476", "AG53083", "AM38857", "AD77978", "AC62520", "AD28236", "AB52397", "AG05468", "AB82886", "AG33021", "AF51518", "AM26455", "ZKFC185", "AH90413", "AH95976", "AL39738", "AL71522", "AB62163", "AG32969", "AG05470", "AB56908", "AA74749", "AD68878", "AF39225", "AG17203", "AD18280", "AH20934", "FREEMMC", "AD30755", "AD32137", "AG02412", "AL52004", "AH89285", "LNG7225", "AM39092", "AB25883", "GARLATN", "AD48198", "AF51400", "AG11951", "AM39094", "AF88900", "AM27266", "9431MU", "AA51379", "AH46800", "AH84706", "AG09915", "AG03422", "AC89038", "AD72744", "GRIDEDN", "AF56933", "ZGCC455", "AM27267", "AG01748", "AG17616", "AF67828", "AF64171", "AF16184", "AF04619", "AH03241", "AF05867", "AG07229", "AG39237", "HARTMCR", "AH60371", "AH64028", "HAYGODW", "AG07687", "AL52557", "AG37152", "AH50799", "AB73904", "AF13083", "AB56798", "AG05406", "HILLRT", "HINERTR", "AD98856", "AI02559", "AI06493", "AL07622", "AF09222", "AM12755", "AD76729", "AF26471", "AD59432", "AC86010", "AF30872", "AB60221", "AA29275", "AD24397", "AG49958", "JACOBBL", "AF42102", "AC03159", "AH46778", "AH45556", "AF13999", "AD43617", "AD44140", "AL04289", "AG91557", "AF19242", "AD05012", "AB80099", "AG20166", "AB75098", "AE02191", "AF08628", "KEENEMC", "KEMPEPM", "AF33136", "AG58037", "AB78267", "AD58252", "AD38413", "AA75452", "AF78570", "PENDLSS", "AA03452", "AF94568", "AF38247", "AA75814", "AH75368", "AM38763", "AD65927", "AF61806", "AH40730", "AH27747", "AC97216", "AG04945", "AL89132", "AH26686", "AD16347", "AL07630", "AL06156", "AG34261", "AC92626", "AB25633", "AL87807", "AD95234", "AL06132", "MANNTM", "AG52447", "AG19216", "AF19077", "AF78653", "AG57276", "AB68417", "MASCOGL", "AH91231", "ZKFCCKA", "AG71357", "AG11824", "AB70423", "AB59612", "AH90863", "AL06163", "AM40206", "AD32485", "AL28150", "AD63606", "AH71097", "AH95677", "AB32550", "AH48427", "AD40944", "AA68866", "AG57298", "AG36847", "AL49667", "AF92881", "AL03114", "AL87808", "AL73781", "AG32991", "AD21110", "AD27552", "AG33109", "AL89337", "AF32076", "AC95494", "AI06256", "AL09084", "AM23773", "AD76733", "AL30100", "AH68436", "AL87937", "AH47518", "AG31629", "AC17131", "AM03566", "AC74547", "AA73951", "PISCIPL", "AL87961", "AL55109", "AL48910", "POGOZTH", "AB93211", "ZMMII71", "AA76114", "AG55003", "AB44206", "AH32085", "AL06604", "AC39021", "AA75237", "AD54060", "AB32557", "AG11807", "AF76893", "AA75306", "AG86807", "AL87803", "AG44646", "AD35966", "RICHAPR", "AG07239", "AF46350", "AF18006", "AD37774", "AB68174", "AL88282", "AF06689", "AF24503", "AH23167", "AL52446", "AC49685", "AF91938", "AG33014", "AM39791", "AB80786", "ZULHAF8", "AM03563", "AH25264", "MCINTNT", "AG20176", "AF86909", "AA61463", "AB20279", "RULINKR", "AB25813", "AL29877", "AL14917", "SIMONRC", "AL28148", "AC27658", "AH95723", "AL06622", "AL06106", "AF84737", "AF35029", "AG01440", "SCHEFSS", "AA03588", "AD24171", "AD94224", "AC34295", "AC86001", "AD58516", "AG20178", "AA27556", "ZKFC099", "AM27149", "SINGLDL", "SIXJN", "AG44119", "SMITHMN", "AG20182", "AD10428", "AL88113", "SMOCKBR", "AL87279", "ZKFCCN5", "AL44616", "AG11837", "AH23214", "AF75736", "AF88081", "AB25531", "AM05316", "STAPLCN", "STEWARB", "AC03585", "RCH1676", "AD36149", "AC80766", "AC25592", "AH52369", "AA09707", "NICHOLZ", "AB43354", "AH37816", "AG11809", "AF22372", "AG63835", "AD21661", "AD34725", "AB01412", "AF96322", "TYREERG", "AA73988", "AA76583", "AA67917", "AL87962", "AF38812", "9441MU", "AM37430", "AF58540", "AA75523", "WALLAVC", "AH46825", "AD32392", "AF97971", "ZHHM040", "AB33087", "AB28985", "AB72656", "AH35466", "AB42916", "AL55963", "AG54997", "AG19645", "AL41962", "AF80411", "AB84189", "AF35865", "AF58129", "AG32696", "AB16029", "AF88885", "AG33154", "AM64331", "AH24135", "AG01684", "AF24098", "AF71102", "ZGCA054", "AD63251", "AD57512", "AD96409", "AL28418"]
}

# Pagination payload for drilldown APIs
PAGINATION_PAYLOAD = {
    "user_id": "AB77504",
    "start_date": "2026-04-01",
    "end_date": "2026-04-14",
    "lob": ["Commercial", "EGR", "GRS", "Medicaid", "Medicare", "None"],
    "director_ids": ["SANTICH"],
    "manager_ids": ["AH79824", "HARPEDN", "AD23980", "AG54148", "AC85459", "AH89970", "AG66523", "MEYERCH", "AC85676", "VLGRIGG", "AC87144", "AD48374", "AC87000", "AL50205", "AM67537", "RCH0301", "AE08708", "LUCASCR", "LYONSML", "AL96141", "LYKINDN", "AB40695", "AA71486", "AL93492", "AL50321", "AB22155", "ROSETSC", "SANTICH", "AD59226", "AH48411", "AB32568", "AC55351", "AC85601", "AB42481", "WILLIHR", "AG40722"],
    "frontline_associate_ids": ["AL89026", "AL06130", "AH36147", "ABSHEMN", "AH93714", "AG69408", "AB86043", "AF41565", "AC80655", "AA37988", "AL06110", "AD28415", "AL71961", "AF87904", "AH51176", "AL87298", "AL72429", "AH49017", "AD66122", "AF81154", "AD92754", "AL06193", "AL25054", "AG38776", "AE09148", "AB80277", "AD07810", "AA76390", "AG32983", "AC93537", "AF04799", "AD49574", "AG11943", "AH45714", "AL06106", "AA74146", "AL52002", "AB26472", "AD60355", "AH89288", "AG07245", "AD93011", "AF03176", "AI05065", "AL42117", "AL77130", "AH49575", "AG67968", "MCCOWLS", "AD09821", "AC77516", "AF60339", "AG17296", "AH23177", "HILSOGW", "RCH0825", "AL06148", "AI06732", "SMITHLR", "AB73830", "AG03652", "AH29995", "AL41742", "AD37776", "GENIEBR", "AL67447", "AL25023", "AC87929", "AG34022", "AA56975", "AA74713", "BURNSLC", "AL25041", "AM26456", "AL19218", "AD07864", "AL87284", "AF17474", "CAMBIST", "AF96818", "AD27845", "AH71055", "AH46771", "AL87935", "AH47520", "CHADWLR", "AC62545", "TLCHAMB", "AG12941", "CHAPPLD", "AF43626", "AH86357", "AA75020", "AL87293", "AE03231", "1694MU", "AF77812", "AG37359", "CHOUIBR", "AL28448", "AM40200", "AB77920", "AB63059", "AB16441", "AG18167", "AD25827", "AL07185", "AD72098", "AG17454", "AC87258", "AG37977", "AG43921", "AH49003", "AH23172", "AD61670", "AC86407", "AL87805", "AL48579", "AL87296", "AG97528", "AG19761", "AB58771", "AF32607", "AH47515", "DEBORPM", "AL37336", "AA87228", "AD44668", "AC51885", "AM27147", "AH70026", "AC21803", "AL48587", "ZGCC228", "AB45725", "AL41838", "AF08727", "AH44962", "AH47516", "AL88207", "AB58018", "AA80476", "AG53083", "AM38857", "AD77978", "AC62520", "AD28236", "AB52397", "AG05468", "AB82886", "AG33021", "AF51518", "AM26455", "ZKFC185", "AH90413", "AH95976", "AL39738", "AL71522", "AB62163", "AG32969", "AG05470", "AB56908", "AA74749", "AD68878", "AF39225", "AG17203", "AD18280", "AH20934", "FREEMMC", "AD30755", "AD32137", "AG02412", "AL52004", "AH89285", "LNG7225", "AM39092", "AB25883", "GARLATN", "AD48198", "AF51400", "AG11951", "AM39094", "AF88900", "AM27266", "9431MU", "AA51379", "AH46800", "AH84706", "AG09915", "AG03422", "AC89038", "AD72744", "GRIDEDN", "AF56933", "ZGCC455", "AM27267", "AG01748", "AG17616", "AF67828", "AF64171", "AF16184", "AF04619", "AH03241", "AF05867", "AG07229", "AG39237", "HARTMCR", "AH60371", "AH64028", "HAYGODW", "AG07687", "AL52557", "AG37152", "AH50799", "AB73904", "AF13083", "AB56798", "AG05406", "HILLRT", "HINERTR", "AD98856", "AI02559", "AI06493", "AL07622", "AF09222", "AM12755", "AD76729", "AF26471", "AD59432", "AC86010", "AF30872", "AB60221", "AA29275", "AD24397", "AG49958", "JACOBBL", "AF42102", "AC03159", "AH46778", "AH45556", "AF13999", "AD43617", "AD44140", "AL04289", "AG91557", "AF19242", "AD05012", "AB80099", "AG20166", "AB75098", "AE02191", "AF08628", "KEENEMC", "KEMPEPM", "AF33136", "AG58037", "AB78267", "AD58252", "AD38413", "AA75452", "AF78570", "PENDLSS", "AA03452", "AF94568", "AF38247", "AA75814", "AH75368", "AM38763", "AD65927", "AF61806", "AH40730", "AH27747", "AC97216", "AG04945", "AL89132", "AH26686", "AD16347", "AL07630", "AL06156", "AG34261", "AC92626", "AB25633", "AL87807", "AD95234", "AL06132", "MANNTM", "AG52447", "AG19216", "AF19077", "AF78653", "AG57276", "AB68417", "MASCOGL", "AH91231", "ZKFCCKA", "AG71357", "AG11824", "AB70423", "AB59612", "AH90863", "AL06163", "AM40206", "AD32485", "AL28150", "AD63606", "AH71097", "AH95677", "AB32550", "AH48427", "AD40944", "AA68866", "AG57298", "AG36847", "AL49667", "AF92881", "AL03114", "AL87808", "AL73781", "AG32991", "AD21110", "AD27552", "AG33109", "AL89337", "AF32076", "AC95494", "AI06256", "AL09084", "AM23773", "AD76733", "AL30100", "AH68436", "AL87937", "AH47518", "AG31629", "AC17131", "AM03566", "AC74547", "AA73951", "PISCIPL", "AL87961", "AL55109", "AL48910", "POGOZTH", "AB93211", "ZMMII71", "AA76114", "AG55003", "AB44206", "AH32085", "AL06604", "AC39021", "AA75237", "AD54060", "AB32557", "AG11807", "AF76893", "AA75306", "AG86807", "AL87803", "AG44646", "AD35966", "RICHAPR", "AG07239", "AF46350", "AF18006", "AD37774", "AB68174", "AL88282", "AF06689", "AF24503", "AH23167", "AL52446", "AC49685", "AF91938", "AG33014", "AM39791", "AB80786", "ZULHAF8", "AM03563", "AH25264", "MCINTNT", "AG20176", "AF86909", "AA61463", "AB20279", "RULINKR", "AB25813", "AL29877", "AL14917", "SIMONRC", "AL28148", "AC27658", "AH95723", "AL06622", "AL06106", "AF84737", "AF35029", "AG01440", "SCHEFSS", "AA03588", "AD24171", "AD94224", "AC34295", "AC86001", "AD58516", "AG20178", "AA27556", "ZKFC099", "AM27149", "SINGLDL", "SIXJN", "AG44119", "SMITHMN", "AG20182", "AD10428", "AL88113", "SMOCKBR", "AL87279", "ZKFCCN5", "AL44616", "AG11837", "AH23214", "AF75736", "AF88081", "AB25531", "AM05316", "STAPLCN", "STEWARB", "AC03585", "RCH1676", "AD36149", "AC80766", "AC25592", "AH52369", "AA09707", "NICHOLZ", "AB43354", "AH37816", "AG11809", "AF22372", "AG63835", "AD21661", "AD34725", "AB01412", "AF96322", "TYREERG", "AA73988", "AA76583", "AA67917", "AL87962", "AF38812", "9441MU", "AM37430", "AF58540", "AA75523", "WALLAVC", "AH46825", "AD32392", "AF97971", "ZHHM040", "AB33087", "AB28985", "AB72656", "AH35466", "AB42916", "AL55963", "AG54997", "AG19645", "AL41962", "AF80411", "AB84189", "AF35865", "AF58129", "AG32696", "AB16029", "AF88885", "AG33154", "AM64331", "AH24135", "AG01684", "AF24098", "AF71102", "ZGCA054", "AD63251", "AD57512", "AD96409", "AL28418"],
    "page": 1,
    "page_size": 20
}

# List of drilldown modules that need pagination
DRILLDOWN_MODULES = [
    'escalation_count_drilldown',
    'pended_items_counts_drilldown',
    'production_pct_achieved_drilldown',
    'rebuttal_drilldown',
    'audit_score_director_drilldown',
    'fuse_time_director_drilldown',
    'work_items_director_drilldown',
    'capacity_insight_drilldown',
    'sla_health_drilldown',
    'audit_sample_pct_drilldown',
    'watchlist_drilldown',
    'rework_pct_drilldown',
    'completed_audit_count_drilldown',
    'audit_error_director_drilldown',
    'cycle_takt_drilldown'
]

async def call_api_and_get_response(module, request: DirectorBaseRequest):
    """Call the API endpoint and capture the actual response data."""
    try:
        if hasattr(module, 'router'):
            router = module.router
            # Get the endpoint function from the router
            for route in router.routes:
                if hasattr(route, 'endpoint'):
                    endpoint_func = route.endpoint
                    # Call the async endpoint function
                    response = await endpoint_func(request)
                    
                    # Convert response to dict
                    if hasattr(response, 'dict'):
                        # Pydantic v1
                        response_dict = response.dict()
                    elif hasattr(response, 'model_dump'):
                        # Pydantic v2
                        response_dict = response.model_dump()
                    else:
                        response_dict = dict(response)
                    
                    # Convert to JSON string for storage
                    return json.dumps(response_dict, indent=2, default=str)
    except Exception as e:
        logger.warning(f"Could not call API for {module.__name__}: {e}")
        return f"Error: {str(e)}"
    
    return "N/A"

async def call_build_function(func, *args, **kwargs):
    """Helper to call a build function, handling both sync and async functions."""
    try:
        result = func(*args, **kwargs)
        # Check if result is a coroutine (async function was called)
        if inspect.iscoroutine(result):
            return await result
        return result
    except Exception as e:
        logger.warning(f"Error calling build function {func.__name__}: {e}")
        return ""

async def extract_sql_from_module(module, base_request, pagination_request=None):
    """Extract SQL queries from a module by building filters and formatting queries."""
    sql_queries = []
    module_name = module.__name__.split('.')[-1]
    
    # Determine which request to use
    request = pagination_request if module_name in DRILLDOWN_MODULES and pagination_request else base_request
    
    # Get actual API response
    # Commented out to avoid server dependency - just extract SQL queries
    # logger.info(f"  Calling API for {module_name}...")
    # api_response = await call_api_and_get_response(module, request)
    api_response = "SQL Query Only (API call skipped)"
    
    try:
        # Build common filters using the appropriate request
        lob_filter = ""
        date_filter = ""
        director_filter = ""
        manager_filter = ""
        associate_filter = ""
        
        if hasattr(module, 'build_lob_filter'):
            lob_filter = await call_build_function(module.build_lob_filter, request.lob if hasattr(request, 'lob') else None)
        
        if hasattr(module, 'build_date_filter'):
            start = request.start_date if hasattr(request, 'start_date') else None
            end = request.end_date if hasattr(request, 'end_date') else None
            date_filter = await call_build_function(module.build_date_filter, start, end)
        
        if hasattr(module, 'build_director_filter'):
            directors = request.director_ids if hasattr(request, 'director_ids') else None
            director_filter = await call_build_function(module.build_director_filter, directors)
        
        if hasattr(module, 'build_manager_filter'):
            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
            manager_filter = await call_build_function(module.build_manager_filter, managers)
        
        if hasattr(module, 'build_associate_filter'):
            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
            associate_filter = await call_build_function(module.build_associate_filter, associates)
        
        # Find all SQL query constants in the module
        for attr_name in dir(module):
            if attr_name.endswith('_QUERY') and attr_name.isupper():
                query_template = getattr(module, attr_name)
                if isinstance(query_template, str) and 'SELECT' in query_template.upper():
                    try:
                        # Try to format the query with available filters
                        formatted_query = query_template
                        
                        # Replace common placeholders - handle both {{}} and {} formats
                        replacements = {
                            'lob_filter': lob_filter,
                            'date_filter': date_filter,
                            'director_filter': director_filter,
                            'manager_filter': manager_filter,
                            'associate_filter': associate_filter,
                        }
                        
                        # Add module-specific filters
                        if hasattr(module, 'build_user_date_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['user_date_filter'] = await call_build_function(module.build_user_date_filter, start, end)
                        elif hasattr(module, 'build_date_filter') and 'user_date_filter' in query_template:
                            # Fallback: use build_date_filter with LOGINDATE column
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['user_date_filter'] = await call_build_function(module.build_date_filter, start, end, date_column="LOGINDATE")
                        
                        if hasattr(module, 'build_audit_manager_filter'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['audit_manager_filter'] = await call_build_function(module.build_audit_manager_filter, managers)
                        
                        if hasattr(module, 'build_audit_associate_filter'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['audit_associate_filter'] = await call_build_function(module.build_audit_associate_filter, associates)
                        
                        if hasattr(module, 'build_user_manager_filter'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['user_manager_filter'] = await call_build_function(module.build_user_manager_filter, managers)
                        
                        if hasattr(module, 'build_manager_filter_user'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['manager_filter_user'] = await call_build_function(module.build_manager_filter_user, managers)
                        
                        if hasattr(module, 'build_invntry_date_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['invntry_date_filter'] = await call_build_function(module.build_invntry_date_filter, start, end)
                        
                        if hasattr(module, 'build_invntry_lob_filter'):
                            lob = request.lob if hasattr(request, 'lob') else None
                            replacements['invntry_lob_filter'] = await call_build_function(module.build_invntry_lob_filter, lob)
                        
                        # Demand inventory specific filters
                        if hasattr(module, 'build_backlog_created_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['backlog_created_filter'] = await call_build_function(module.build_backlog_created_filter, end)
                        
                        if hasattr(module, 'build_backlog_resolved_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['backlog_resolved_filter'] = await call_build_function(module.build_backlog_resolved_filter, end)
                        
                        if hasattr(module, 'build_backlog_date_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['backlog_date_filter'] = await call_build_function(module.build_backlog_date_filter, start, end)
                        
                        if hasattr(module, 'build_manager_user_filter'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['manager_user_filter'] = await call_build_function(module.build_manager_user_filter, managers)
                        
                        if hasattr(module, 'build_pended_created_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['pended_created_filter'] = await call_build_function(module.build_pended_created_filter, end)
                        
                        if hasattr(module, 'build_pended_manager_user_filter'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['pended_manager_user_filter'] = await call_build_function(module.build_pended_manager_user_filter, managers)
                        
                        if hasattr(module, 'build_pended_associate_filter'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['pended_associate_filter'] = await call_build_function(module.build_pended_associate_filter, associates)
                        
                        if hasattr(module, 'build_pended_resolved_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['pended_resolved_filter'] = await call_build_function(module.build_pended_resolved_filter, end)
                        
                        if hasattr(module, 'build_escalation_created_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['escalation_created_filter'] = await call_build_function(module.build_escalation_created_filter, end)
                        
                        if hasattr(module, 'build_escalation_manager_user_filter'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['escalation_manager_user_filter'] = await call_build_function(module.build_escalation_manager_user_filter, managers)
                        
                        if hasattr(module, 'build_escalation_associate_filter'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['escalation_associate_filter'] = await call_build_function(module.build_escalation_associate_filter, associates)
                        
                        if hasattr(module, 'build_escalation_resolved_start_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            replacements['escalation_resolved_start_filter'] = await call_build_function(module.build_escalation_resolved_start_filter, start)
                        
                        if hasattr(module, 'build_escalation_resolved_end_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['escalation_resolved_end_filter'] = await call_build_function(module.build_escalation_resolved_end_filter, end)
                        
                        # Associates list specific filter (frontline_date_filter)
                        if 'frontline_date_filter' in query_template:
                            if hasattr(module, 'build_date_filter'):
                                start = request.start_date if hasattr(request, 'start_date') else None
                                end = request.end_date if hasattr(request, 'end_date') else None
                                replacements['frontline_date_filter'] = await call_build_function(module.build_date_filter, start, end)
                            else:
                                replacements['frontline_date_filter'] = ''
                        
                        # Director list specific filters (manager_date_filter, director_date_filter)
                        if 'manager_date_filter' in query_template:
                            if hasattr(module, 'build_date_filter'):
                                start = request.start_date if hasattr(request, 'start_date') else None
                                end = request.end_date if hasattr(request, 'end_date') else None
                                # Check if build_date_filter accepts filter_type parameter (director_list.py)
                                # or just start/end (managers_list.py)
                                import inspect
                                sig = inspect.signature(module.build_date_filter)
                                if 'filter_type' in sig.parameters:
                                    replacements['manager_date_filter'] = await call_build_function(module.build_date_filter, start, end, filter_type="manager")
                                else:
                                    replacements['manager_date_filter'] = await call_build_function(module.build_date_filter, start, end)
                            else:
                                replacements['manager_date_filter'] = ''
                        
                        if 'director_date_filter' in query_template:
                            if hasattr(module, 'build_date_filter'):
                                start = request.start_date if hasattr(request, 'start_date') else None
                                end = request.end_date if hasattr(request, 'end_date') else None
                                import inspect
                                sig = inspect.signature(module.build_date_filter)
                                if 'filter_type' in sig.parameters:
                                    replacements['director_date_filter'] = await call_build_function(module.build_date_filter, start, end, filter_type="director")
                                else:
                                    replacements['director_date_filter'] = await call_build_function(module.build_date_filter, start, end)
                            else:
                                replacements['director_date_filter'] = ''
                        
                        # Managers list specific filter (directors_filter)
                        if hasattr(module, 'build_directors_filter'):
                            directors = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['directors_filter'] = await call_build_function(module.build_directors_filter, directors)
                        
                        # Audit sample pct drilldown specific filters
                        if hasattr(module, 'build_audit_date_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['audit_date_filter'] = await call_build_function(module.build_audit_date_filter, start, end)
                        
                        # Rework date filter (for PXCREATEDATETIME in rework queries)
                        if 'rework_date_filter' in query_template:
                            if hasattr(module, 'build_date_filter'):
                                start = request.start_date if hasattr(request, 'start_date') else None
                                end = request.end_date if hasattr(request, 'end_date') else None
                                replacements['rework_date_filter'] = await call_build_function(module.build_date_filter, start, end, date_column="PXCREATEDATETIME")
                            else:
                                replacements['rework_date_filter'] = ''
                        
                        # User date filter (for LOGINDATE in COB_AI_USER_PROFILE)
                        # Note: This is a duplicate check, may have been set earlier
                        if hasattr(module, 'build_user_date_filter') and 'user_date_filter' not in replacements:
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['user_date_filter'] = await call_build_function(module.build_user_date_filter, start, end)
                        
                        if 'audit_lob_filter' in query_template:
                            # audit_lob_filter uses the same lob_filter
                            replacements['audit_lob_filter'] = lob_filter
                        
                        if hasattr(module, 'build_user_profile_associate_filter'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['user_profile_associate_filter'] = await call_build_function(module.build_user_profile_associate_filter, associates)
                        elif hasattr(module, 'build_associate_filter') and 'user_profile_associate_filter' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['user_profile_associate_filter'] = await call_build_function(module.build_associate_filter, associates, column="USERID")
                        
                        # Quality outcomes specific filters (duplicate checks - may have been set earlier)
                        # Skipping to avoid overwriting
                        
                        # Additional module-specific filters
                        if hasattr(module, 'build_associate_filter_invntry'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_invntry'] = await call_build_function(module.build_associate_filter_invntry, associates)
                        elif hasattr(module, 'build_associate_filter') and 'associate_filter_invntry' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_invntry'] = await call_build_function(module.build_associate_filter, associates, column="PYRESOLVEDUSERID")
                        
                        if hasattr(module, 'build_associate_filter_user'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_user'] = await call_build_function(module.build_associate_filter_user, associates)
                        elif hasattr(module, 'build_associate_filter') and 'associate_filter_user' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_user'] = await call_build_function(module.build_associate_filter, associates, column="USERID")
                        
                        if hasattr(module, 'build_associate_filter_audit'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_audit'] = await call_build_function(module.build_associate_filter_audit, associates)
                        elif hasattr(module, 'build_associate_filter') and 'associate_filter_audit' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_audit'] = await call_build_function(module.build_associate_filter, associates, column="AUDIT_SUBJECT_ID")
                        
                        if hasattr(module, 'build_associate_filter_assigned'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_assigned'] = await call_build_function(module.build_associate_filter_assigned, associates)
                        elif hasattr(module, 'build_associate_filter') and 'associate_filter_assigned' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_assigned'] = await call_build_function(module.build_associate_filter, associates, column="ASSIGNEDTO")
                        
                        # Note: manager_filter_user may have been set earlier (line 222)
                        if hasattr(module, 'build_manager_filter_user') and 'manager_filter_user' not in replacements:
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['manager_filter_user'] = await call_build_function(module.build_manager_filter_user, managers)
                        
                        if hasattr(module, 'build_manager_filter_subquery'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['manager_filter_subquery'] = await call_build_function(module.build_manager_filter_subquery, managers)
                        
                        if hasattr(module, 'build_manager_filter_cte'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['manager_filter_cte'] = await call_build_function(module.build_manager_filter_cte, managers)
                        
                        # director_filter is now handled at common level (lines 154-156)
                        # Removed duplicate handling here to avoid confusion
                        
                        if hasattr(module, 'build_director_filter_invntry'):
                            directors = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['director_filter_invntry'] = await call_build_function(module.build_director_filter_invntry, directors)
                        
                        if hasattr(module, 'build_manager_filter_invntry'):
                            managers = request.manager_ids if hasattr(request, 'manager_ids') else None
                            replacements['manager_filter_invntry'] = await call_build_function(module.build_manager_filter_invntry, managers)
                        
                        if hasattr(module, 'build_date_filter_where'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['date_filter_where'] = await call_build_function(module.build_date_filter_where, start, end)
                        
                        if hasattr(module, 'build_user_date_filter_where'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['user_date_filter_where'] = await call_build_function(module.build_user_date_filter_where, start, end)
                        
                        # Add start_date and end_date as direct replacements
                        replacements['start_date'] = request.start_date if hasattr(request, 'start_date') else ''
                        replacements['end_date'] = request.end_date if hasattr(request, 'end_date') else ''
                        
                        # MISSING FILTERS - Added based on comprehensive analysis
                        # 1. Direct parameter substitutions
                        replacements['associate_id'] = request.frontline_associate_id if hasattr(request, 'frontline_associate_id') else ''
                        replacements['end_date_param'] = request.end_date if hasattr(request, 'end_date') else ''
                        replacements['page_size'] = str(request.page_size) if hasattr(request, 'page_size') else '20'
                        
                        # 2. Build function handlers for missing filters
                        if hasattr(module, 'build_created_date_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['created_date_filter'] = await call_build_function(module.build_created_date_filter, end)
                        
                        if hasattr(module, 'build_open_associate_filter'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['open_associate_filter'] = await call_build_function(module.build_open_associate_filter, associates)
                        
                        if hasattr(module, 'build_resolved_date_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['resolved_date_filter'] = await call_build_function(module.build_resolved_date_filter, start, end)
                        
                        if hasattr(module, 'build_sla_created_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['sla_created_filter'] = await call_build_function(module.build_sla_created_filter, end)
                        
                        if hasattr(module, 'build_watchlist_created_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['watchlist_created_filter'] = await call_build_function(module.build_watchlist_created_filter, end)
                        
                        # 3. Special handling for async function - cannot call directly, use empty string
                        # build_backlog_associate_filter is async and cannot be called in sync context
                        # The actual SQL will show {{associate_filter_backlog}} placeholder
                        replacements['associate_filter_backlog'] = '/* ASYNC FILTER - Cannot be resolved in tool */'
                        
                        # Add pagination placeholders
                        if hasattr(request, 'page') and hasattr(request, 'page_size'):
                            offset = (request.page - 1) * request.page_size
                            replacements['limit'] = str(request.page_size)
                            replacements['offset'] = str(offset)
                        else:
                            replacements['limit'] = '20'
                            replacements['offset'] = '0'
                        
                        # Drilldown specific filters
                        if hasattr(module, 'build_sort_clause'):
                            replacements['sort_clause'] = ''
                        
                        # Replace all placeholders - handle both {{placeholder}} and {placeholder} formats
                        import re
                        for key, value in replacements.items():
                            # Replace {{placeholder}} format
                            formatted_query = formatted_query.replace('{{' + key + '}}', value if value else '')
                            # Replace {placeholder} format
                            formatted_query = formatted_query.replace('{' + key + '}', value if value else '')
                        
                        # Clean up any remaining unreplaced placeholders
                        remaining_placeholders = re.findall(r'\{\{?[^}]+\}?\}', formatted_query)
                        for placeholder in remaining_placeholders:
                            formatted_query = formatted_query.replace(placeholder, '')
                        
                        sql_queries.append({
                            'module': module_name,
                            'query_name': attr_name,
                            'api_response': api_response,
                            'sql': formatted_query.strip()
                        })
                    except Exception as e:
                        logger.warning(f"Could not format query {attr_name} in {module_name}: {e}")
    
    except Exception as e:
        logger.error(f"Error extracting SQL from {module_name}: {e}")
    
    return sql_queries

async def main():
    """Main execution function."""
    logger.info("Starting SQL extraction for Performance IQ Director APIs...")
    
    # Create request objects
    base_request = DirectorBaseRequest(**PAYLOAD)
    
    # Create pagination request object (using Pydantic BaseModel dynamically)
    from pydantic import BaseModel, Field
    from typing import Optional, List
    
    class PaginationRequest(BaseModel):
        end_date: Optional[str] = None
        frontline_associate_ids: Optional[List[str]] = None
        lob: Optional[List[str]] = None
        director_ids: Optional[List[str]] = None
        manager_ids: Optional[List[str]] = None
        start_date: Optional[str] = None
        user_id: str
        page: int = 1
        page_size: int = 20
    
    pagination_request = PaginationRequest(**PAGINATION_PAYLOAD)
    
    # List of all modules to process
    modules = [
        header_kpis,
        demand_inventory,
        operational_flow,
        quality_outcomes,
        associate_utilization,
        sla_health,
        escalation_count_drilldown,
        pended_items_counts_drilldown,
        production_pct_achieved_drilldown,
        rebuttal_drilldown,
        audit_score_director_drilldown,
        fuse_time_director_drilldown,
        work_items_director_drilldown,
        capacity_insight_drilldown,
        sla_health_drilldown,
        audit_sample_pct_drilldown,
        watchlist_drilldown,
        rework_pct_drilldown,
        completed_audit_count_drilldown,
        ai_coach_director,
        associates_list,
        audit_error_director_drilldown,
        cycle_takt_drilldown,
        director_list,
        director_lob,
        director_user_activity,
        managers_list
    ]
    
    all_sql_queries = []
    
    # Extract SQL from each module
    for module in modules:
        logger.info(f"Processing module: {module.__name__}")
        queries = await extract_sql_from_module(module, base_request, pagination_request)
        all_sql_queries.extend(queries)
        logger.info(f"  Found {len(queries)} queries")
    
    # Write to README
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"DIRECTOR_API_SQL_DOCUMENTATION.md"
    
    # Group queries by module
    from collections import defaultdict, Counter
    queries_by_module = defaultdict(list)
    for query in all_sql_queries:
        queries_by_module[query['module']].append(query)
    
    # Write comprehensive README
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# Performance IQ Director API - SQL Documentation\n\n")
        f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"**Total APIs:** {len(modules)}\n")
        f.write(f"**Total SQL Queries:** {len(all_sql_queries)}\n\n")
        
        # Table of Contents
        f.write("## Table of Contents\n\n")
        for i, module_name in enumerate(sorted(queries_by_module.keys()), 1):
            query_count = len(queries_by_module[module_name])
            f.write(f"{i}. [{module_name}](#{module_name.replace('_', '-')}) ({query_count} queries)\n")
        f.write("\n---\n\n")
        
        # Detailed documentation for each module
        for module_name in sorted(queries_by_module.keys()):
            queries = queries_by_module[module_name]
            f.write(f"## {module_name}\n\n")
            f.write(f"**Number of Queries:** {len(queries)}\n\n")
            
            for i, query in enumerate(queries, 1):
                f.write(f"### {i}. {query['query_name']}\n\n")
                f.write("**SQL Query:**\n\n")
                f.write("```sql\n")
                f.write(query['sql'])
                f.write("\n```\n\n")
                f.write("---\n\n")
        
        # Summary section
        f.write("## Summary\n\n")
        f.write("### Queries per Module\n\n")
        f.write("| Module | Query Count |\n")
        f.write("|--------|-------------|\n")
        module_counts = Counter(q['module'] for q in all_sql_queries)
        for module, count in sorted(module_counts.items()):
            f.write(f"| {module} | {count} |\n")
        
        f.write("\n### Test Payload Used\n\n")
        f.write("```json\n")
        f.write(json.dumps(PAYLOAD, indent=2))
        f.write("\n```\n\n")
        
        f.write("### Pagination Payload Used\n\n")
        f.write("```json\n")
        f.write(json.dumps(PAGINATION_PAYLOAD, indent=2))
        f.write("\n```\n")
    
    logger.info(f"\n{'='*80}")
    logger.info(f"SQL extraction complete!")
    logger.info(f"Total queries extracted: {len(all_sql_queries)}")
    logger.info(f"Output file: {output_file}")
    logger.info(f"{'='*80}\n")
    
    # Print summary by module
    module_counts = Counter(q['module'] for q in all_sql_queries)
    logger.info("Queries per module:")
    for module, count in sorted(module_counts.items()):
        logger.info(f"  {module}: {count}")

if __name__ == "__main__":
    asyncio.run(main())
