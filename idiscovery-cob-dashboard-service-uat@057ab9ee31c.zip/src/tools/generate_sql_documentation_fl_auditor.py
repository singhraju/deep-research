"""
Script to execute all Performance IQ FL (Front Line) Auditor APIs and save SQL queries to documentation.
This script will extract SQL queries from each FL Auditor API endpoint.
"""
import sys
import os
import csv
import logging
import asyncio
import json
import inspect
from datetime import datetime

# Add src directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from controllers.Performance_IQ_FL_Auditor import (
    header_kpis,
    rebuttal_count_drilldown,
    complete_audit_count_drilldown,
    ata_score_drilldown,
    work_items_drilldown,
    ata_score_gauge,
    audit_cycle_time_gauge,
    rebuttals,
    time_utilization,
    fuse_time_drilldown,
    lob_list,
    ai_coach,
    user_activity
)
# Import common build functions from header_kpis for use across all modules
from controllers.Performance_IQ_FL_Auditor.header_kpis import (
    build_lob_filter as common_build_lob_filter,
    build_date_filter as common_build_date_filter,
    build_date_filter_created as common_build_date_filter_created,
    build_rebuttal_date_filter as common_build_rebuttal_date_filter,
    build_user_filter as common_build_user_filter,
    build_user_filter_resolved as common_build_user_filter_resolved,
    build_user_filter_ata as common_build_user_filter_ata,
)
from schema import FLAuditorBaseRequest
from pydantic import BaseModel
from typing import Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Test payload for FL Auditor APIs
PAYLOAD = {
    "user_id": "AI06493",
    "start_date": "2026-03-01",
    "end_date": "2026-03-31",
    "lob": ["Commercial", "Medicaid", "Medicare"]
}

# Pagination payload for drilldown APIs
PAGINATION_PAYLOAD = {
    "user_id": "AI06493",
    "start_date": "2026-03-01",
    "end_date": "2026-03-31",
    "lob": ["Commercial", "Medicaid", "Medicare"],
    "page": 1,
    "page_size": 20
}

# List of drilldown modules that need pagination
DRILLDOWN_MODULES = [
    'rebuttal_count_drilldown',
    'complete_audit_count_drilldown',
    'ata_score_drilldown',
    'work_items_drilldown',
    'fuse_time_drilldown'
]

async def call_api_and_get_response(module, request):
    """Call the API endpoint and capture the actual response data."""
    try:
        if hasattr(module, 'router'):
            router = module.router
            # Get the endpoint function from the router
            for route in router.routes:
                if hasattr(route, 'endpoint'):
                    endpoint_func = route.endpoint
                    # Call the async endpoint function
                    response = await endpoint_func(request)
                    
                    # Convert response to dict
                    if hasattr(response, 'dict'):
                        # Pydantic v1
                        response_dict = response.dict()
                    elif hasattr(response, 'model_dump'):
                        # Pydantic v2
                        response_dict = response.model_dump()
                    else:
                        response_dict = dict(response)
                    
                    # Convert to JSON string for storage
                    return json.dumps(response_dict, indent=2, default=str)
    except Exception as e:
        logger.warning(f"Could not call API for {module.__name__}: {e}")
        return f"Error: {str(e)}"
    
    return "N/A"

async def call_build_function(func, *args, **kwargs):
    """Helper to call a build function, handling both sync and async functions."""
    try:
        result = func(*args, **kwargs)
        # Check if result is a coroutine (async function was called)
        if inspect.iscoroutine(result):
            return await result
        return result
    except Exception as e:
        logger.warning(f"Error calling build function {func.__name__}: {e}")
        return ""

async def extract_sql_from_module(module, base_request, pagination_request=None):
    """Extract SQL queries from a module by building filters and formatting queries."""
    sql_queries = []
    module_name = module.__name__.split('.')[-1]
    
    # Determine which request to use
    request = pagination_request if module_name in DRILLDOWN_MODULES and pagination_request else base_request
    
    # Get actual API response
    # Commented out to avoid server dependency - just extract SQL queries
    # logger.info(f"  Calling API for {module_name}...")
    # api_response = await call_api_and_get_response(module, request)
    api_response = "SQL Query Only (API call skipped)"
    
    try:
        # Build common filters using the appropriate request
        # Use module's own function if available, otherwise use common function from header_kpis
        lob_filter = ""
        date_filter = ""
        date_filter_created = ""
        user_filter = ""
        user_filter_resolved = ""
        user_filter_ata = ""
        
        # LOB filter
        build_lob_fn = getattr(module, 'build_lob_filter', None) or common_build_lob_filter
        lob_filter = await call_build_function(build_lob_fn, request.lob if hasattr(request, 'lob') else None)
        
        # Date filter
        build_date_fn = getattr(module, 'build_date_filter', None) or common_build_date_filter
        start = request.start_date if hasattr(request, 'start_date') else None
        end = request.end_date if hasattr(request, 'end_date') else None
        date_filter = await call_build_function(build_date_fn, start, end)
        
        # Date filter created (for ATA cases)
        build_date_created_fn = getattr(module, 'build_date_filter_created', None) or common_build_date_filter_created
        date_filter_created = await call_build_function(build_date_created_fn, start, end)
        
        # Rebuttal date filter (some modules use this)
        build_rebuttal_date_fn = getattr(module, 'build_rebuttal_date_filter', None) or common_build_rebuttal_date_filter
        rebuttal_date_filter = await call_build_function(build_rebuttal_date_fn, start, end)
        
        # User filters
        user_id = request.user_id if hasattr(request, 'user_id') else 'AI06493'
        
        build_user_fn = getattr(module, 'build_user_filter', None) or common_build_user_filter
        user_filter = await call_build_function(build_user_fn, user_id)
        
        build_user_resolved_fn = getattr(module, 'build_user_filter_resolved', None) or common_build_user_filter_resolved
        user_filter_resolved = await call_build_function(build_user_resolved_fn, user_id)
        
        build_user_ata_fn = getattr(module, 'build_user_filter_ata', None) or common_build_user_filter_ata
        user_filter_ata = await call_build_function(build_user_ata_fn, user_id)
        
        # Find all SQL query constants in the module
        for attr_name in dir(module):
            if attr_name.endswith('_QUERY') and attr_name.isupper():
                query_template = getattr(module, attr_name)
                if isinstance(query_template, str) and 'SELECT' in query_template.upper():
                    try:
                        # Try to format the query with available filters
                        formatted_query = query_template
                        
                        # Replace common placeholders - handle both {{}} and {} formats
                        replacements = {
                            'lob_filter': lob_filter,
                            'date_filter': date_filter,
                            'date_filter_created': date_filter_created,
                            'rebuttal_date_filter': rebuttal_date_filter,
                            'user_filter': user_filter,
                            'user_filter_resolved': user_filter_resolved,
                            'user_filter_ata': user_filter_ata,
                            'user_id': user_id,
                            'start_date': start or '',
                            'end_date': end or '',
                        }
                        
                        # Add auditor_filter (used in lob_list - same as user_filter)
                        replacements['auditor_filter'] = user_filter
                        
                        # Config imports (SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA)
                        from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
                        replacements['SNOWFLAKE_DATABASE'] = SNOWFLAKE_DATABASE
                        replacements['SNOWFLAKE_SCHEMA'] = SNOWFLAKE_SCHEMA
                        
                        # Add pagination placeholders
                        if hasattr(request, 'page') and hasattr(request, 'page_size'):
                            offset = (request.page - 1) * request.page_size
                            replacements['limit'] = str(request.page_size)
                            replacements['offset'] = str(offset)
                            replacements['page_size'] = str(request.page_size)
                        else:
                            replacements['limit'] = '20'
                            replacements['offset'] = '0'
                            replacements['page_size'] = '20'
                        
                        # Handle both {{placeholder}} and {placeholder} formats
                        for key, value in replacements.items():
                            # Replace {{key}} format
                            formatted_query = formatted_query.replace('{{' + key + '}}', str(value))
                            # Replace {key} format (if not part of SQL syntax)
                            if f'{{{key}}}' in formatted_query and '{{' not in formatted_query:
                                formatted_query = formatted_query.replace('{' + key + '}', str(value))
                        
                        sql_queries.append({
                            'module': module_name,
                            'query_name': attr_name,
                            'sql': formatted_query.strip(),
                            'api_response': api_response
                        })
                        
                    except KeyError as e:
                        logger.warning(f"Could not format query {attr_name} in {module_name}: missing placeholder {e}")
                    except Exception as e:
                        logger.warning(f"Could not format query {attr_name} in {module_name}: {e}")
    except Exception as e:
        logger.error(f"Error processing module {module_name}: {e}")
    
    return sql_queries

# Define Pydantic request models
class PaginationRequest(BaseModel):
    user_id: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    lob: Optional[list] = None
    page: int = 1
    page_size: int = 20

async def main():
    """Main function to extract SQL from all modules."""
    logger.info("Starting SQL extraction for FL Auditor APIs...")
    
    # Create request objects
    base_request = FLAuditorBaseRequest(**PAYLOAD)
    pagination_request = PaginationRequest(**PAGINATION_PAYLOAD)
    
    # List of all modules to process
    modules = [
        header_kpis,
        rebuttal_count_drilldown,
        complete_audit_count_drilldown,
        ata_score_drilldown,
        work_items_drilldown,
        ata_score_gauge,
        audit_cycle_time_gauge,
        rebuttals,
        time_utilization,
        fuse_time_drilldown,
        lob_list,
        ai_coach,
        user_activity
    ]
    
    all_sql_queries = []
    
    # Extract SQL from each module
    for module in modules:
        logger.info(f"Processing module: {module.__name__}")
        queries = await extract_sql_from_module(module, base_request, pagination_request)
        all_sql_queries.extend(queries)
        logger.info(f"  Found {len(queries)} queries")
    
    # Write to README
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"FL_AUDITOR_API_SQL_DOCUMENTATION.md"
    
    # Group queries by module
    from collections import defaultdict, Counter
    queries_by_module = defaultdict(list)
    for query in all_sql_queries:
        queries_by_module[query['module']].append(query)
    
    # Write comprehensive README
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# Performance IQ FL Auditor API - SQL Documentation\n\n")
        f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"**Total APIs:** {len(modules)}\n")
        f.write(f"**Total SQL Queries:** {len(all_sql_queries)}\n\n")
        
        # Table of Contents
        f.write("## Table of Contents\n\n")
        for i, module_name in enumerate(sorted(queries_by_module.keys()), 1):
            query_count = len(queries_by_module[module_name])
            f.write(f"{i}. [{module_name}](#{module_name.replace('_', '-')}) ({query_count} queries)\n")
        f.write("\n---\n\n")
        
        # Detailed documentation for each module
        for module_name in sorted(queries_by_module.keys()):
            queries = queries_by_module[module_name]
            f.write(f"## {module_name}\n\n")
            f.write(f"**Number of Queries:** {len(queries)}\n\n")
            
            for i, query in enumerate(queries, 1):
                f.write(f"### {i}. {query['query_name']}\n\n")
                f.write("**SQL Query:**\n\n")
                f.write("```sql\n")
                f.write(query['sql'])
                f.write("\n```\n\n")
                f.write("---\n\n")
    
    logger.info("\n" + "="*80)
    logger.info("SQL extraction complete!")
    logger.info(f"Total queries extracted: {len(all_sql_queries)}")
    logger.info(f"Output file: {output_file}")
    logger.info("="*80 + "\n")
    
    # Print summary by module
    logger.info("Queries per module:")
    for module_name in sorted(queries_by_module.keys()):
        logger.info(f"  {module_name}: {len(queries_by_module[module_name])}")

if __name__ == "__main__":
    asyncio.run(main())
