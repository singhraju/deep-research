"""
Script to execute all Performance IQ Frontline APIs and save SQL queries to documentation.
This script will extract SQL queries from each Frontline API endpoint.
"""
import sys
import os
import logging
import asyncio
import json
import inspect
import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

# Add src directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from controllers.Performance_IQ import (
    user_time,
    user_metrics,
    user_activity,
    audit_score_gauge,
    workitems_drilldown,
    auditscore_drilldown,
    production_percentage_gauge,
    fusetime_drilldown,
    production_pct_drilldown,
    ai_coach,
    audit_error_drilldown
)
from schema import AuditPeriod, DateRange, PageRequest

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Test payload for non-drilldown APIs
PAYLOAD = {
    "user_id": "AH40730",
    "start_date": "2026-06-17",
    "end_date": "2026-07-25",
    "audit_periods": [],
    "lob": ["Medicaid"]
}

AUDIT_PERIODS_SAMPLE = [
    {"year": "2026", "month": "May"},
    {"year": "2026", "month": "June"},
]

AUDIT_PERIOD_PAYLOAD = {
    **PAYLOAD,
    "audit_periods": AUDIT_PERIODS_SAMPLE,
}

# Pagination payload for drilldown APIs
PAGINATION_PAYLOAD = {
    "screen_id": "work_items",
    "query": {
        "user_id": "AG01440",
        "date_range": {
            "from": "2026-03-17",
            "to": "2026-03-23",
        },
        "lob": ["CSBD", "Commercial", "CrossOver", "EGR", "GRS", "Group Retiree Solutions", 
                "INT", "KCP", "MDR", "MMP", "MedSupp", "Medicaid", "Medicare", "PDP", "SUP", "Supplemental"],
        "audit_periods": [],
        "sort_by": None,
        "sort_direction": "desc"
    },
    "page": {
        "page_limit": 20,
        "page": 1
    }
}

PAGINATION_AUDIT_PERIOD_PAYLOAD = {
    **PAGINATION_PAYLOAD,
    "query": {
        **PAGINATION_PAYLOAD["query"],
        "audit_periods": AUDIT_PERIODS_SAMPLE,
    },
}

# List of drilldown modules that need pagination
DRILLDOWN_MODULES = [
    'workitems_drilldown',
    'auditscore_drilldown',
    'fusetime_drilldown',
    'production_pct_drilldown',
    'audit_error_drilldown'
]

AUDIT_PERIOD_MODULES = {
    'user_metrics',
    'audit_score_gauge',
    'auditscore_drilldown',
    'audit_error_drilldown',
}

MODULE_SORT_OVERRIDES = {
    'workitems_drilldown': {'sort_by': 'resolved_date', 'sort_direction': 'desc'},
    'auditscore_drilldown': {'sort_by': 'audit_resolved', 'sort_direction': 'desc'},
    'fusetime_drilldown': {'sort_by': 'date', 'sort_direction': 'desc'},
    'production_pct_drilldown': {'sort_by': 'resolved_date', 'sort_direction': 'desc'},
    'audit_error_drilldown': {'sort_by': 'date_assessed', 'sort_direction': 'desc'},
}

MODULE_SCREEN_IDS = {
    'workitems_drilldown': 'work_items',
    'auditscore_drilldown': 'audit_score',
    'fusetime_drilldown': 'fuse_time',
    'production_pct_drilldown': 'production_pct_achieved',
    'audit_error_drilldown': 'audit_error',
}


class FrontlineBaseRequest(BaseModel):
    user_id: str
    start_date: str
    end_date: str
    lob: Optional[List[str]] = None
    audit_periods: Optional[List[AuditPeriod]] = None
    session_id: Optional[str] = None
    warm_ai_coach_context: Optional[bool] = True


class PaginationQueryRequest(BaseModel):
    user_id: str
    date_range: DateRange
    lob: Optional[List[str]] = None
    audit_periods: Optional[List[AuditPeriod]] = None
    sort_by: Optional[str] = None
    sort_direction: Optional[str] = "desc"


class PaginationRequest(BaseModel):
    screen_id: str = "work_items"
    query: PaginationQueryRequest
    page: PageRequest = Field(default_factory=PageRequest)


async def call_build_function(func, *args, **kwargs):
    try:
        result = func(*args, **kwargs)
        if inspect.iscoroutine(result):
            return await result
        return result
    except Exception as e:
        logger.warning(f"Error calling build function {func.__name__}: {e}")
        return ""


def clone_request_with_updates(request: BaseModel, **updates):
    if hasattr(request, 'model_copy'):
        return request.model_copy(update=updates)
    return request.copy(update=updates)


def clone_query_request_with_updates(request: BaseModel, **query_updates):
    if hasattr(request.query, 'model_copy'):
        updated_query = request.query.model_copy(update=query_updates)
    else:
        updated_query = request.query.copy(update=query_updates)
    return clone_request_with_updates(request, query=updated_query)


def request_to_payload(request: BaseModel) -> Dict[str, Any]:
    if hasattr(request, 'model_dump'):
        return request.model_dump(exclude_none=True, by_alias=True)
    return request.dict(exclude_none=True, by_alias=True)


def get_effective_request_for_module(module_name: str, request: BaseModel):
    effective_request = request
    if hasattr(effective_request, 'screen_id') and module_name in MODULE_SCREEN_IDS:
        effective_request = clone_request_with_updates(
            effective_request,
            screen_id=MODULE_SCREEN_IDS[module_name],
        )
    if module_name in MODULE_SORT_OVERRIDES and hasattr(effective_request, 'query'):
        effective_request = clone_query_request_with_updates(
            effective_request,
            **MODULE_SORT_OVERRIDES[module_name],
        )
    return effective_request


def get_request_user_id(request: BaseModel) -> str:
    return request.query.user_id if hasattr(request, 'query') else request.user_id


def get_request_start_date(request: BaseModel) -> str:
    return request.query.date_range.from_date if hasattr(request, 'query') else request.start_date


def get_request_end_date(request: BaseModel) -> str:
    return request.query.date_range.to_date if hasattr(request, 'query') else request.end_date


def get_request_lob(request: BaseModel):
    return request.query.lob if hasattr(request, 'query') else request.lob


def get_request_audit_periods(request: BaseModel):
    return request.query.audit_periods if hasattr(request, 'query') else request.audit_periods


def get_request_page_limit(request: BaseModel) -> int:
    return request.page.page_limit if hasattr(request, 'page') else 20


def get_request_page(request: BaseModel) -> int:
    if not hasattr(request, 'page'):
        return 1
    return request.page.page or 1


def get_request_sort_by(request: BaseModel) -> Optional[str]:
    if not hasattr(request, 'query'):
        return None
    return request.query.sort_by


def get_request_sort_direction(request: BaseModel) -> Optional[str]:
    if not hasattr(request, 'query'):
        return None
    return request.query.sort_direction


def should_include_query(module_name: str, query_name: str, mode: str) -> bool:
    if module_name == 'user_metrics':
        if mode == 'audit_period':
            return query_name in {
                'WORK_ITEMS_QUERY',
                'CYCLE_TIME_QUERY',
                'AUDIT_SCORE_AUDIT_PERIOD_QUERY',
                'AUDIT_ERROR_COUNT_AUDIT_PERIOD_QUERY',
            }
        return query_name in {
            'WORK_ITEMS_QUERY',
            'CYCLE_TIME_QUERY',
            'AUDIT_SCORE_QUERY',
            'AUDIT_ERROR_COUNT_QUERY',
        }
    if module_name in AUDIT_PERIOD_MODULES:
        if mode == 'audit_period':
            return 'AUDIT_PERIOD' in query_name
        return 'AUDIT_PERIOD' not in query_name
    return True


def get_query_sort_transformer(module):
    for attribute_name in dir(module):
        if attribute_name.startswith('apply_custom_sort_to_') and attribute_name.endswith('_query'):
            sort_transformer = getattr(module, attribute_name)
            if callable(sort_transformer):
                return sort_transformer
    return None


async def build_lob_filter_replacement(module_name: str, module, query_name: str, request: BaseModel) -> str:
    lob = get_request_lob(request)
    build_lob_fn = getattr(module, 'build_lob_filter', None)
    if build_lob_fn is None:
        return ""
    if module_name == 'audit_error_drilldown':
        if query_name == 'AUDIT_ERROR_COUNT_QUERY':
            return await call_build_function(build_lob_fn, lob, column='LOB')
        if 'AUDIT_PERIOD' in query_name:
            return await call_build_function(build_lob_fn, lob, column='ap.LOB')
        return await call_build_function(build_lob_fn, lob, column='i.LOB')
    return await call_build_function(build_lob_fn, lob)


async def build_audit_period_filter_replacement(module, query_name: str, request: BaseModel) -> str:
    audit_periods = get_request_audit_periods(request)
    if not audit_periods:
        return ""
    build_audit_period_fn = getattr(module, 'build_audit_month_year_filter', None) or user_metrics.build_audit_month_year_filter
    audit_month_column, audit_year_column = (
        ('ap.AUDIT_MONTH', 'ap.AUDIT_YEAR') if 'AUDIT_ERROR' in query_name else ('a.AUDIT_MONTH', 'a.AUDIT_YEAR')
    )
    return await call_build_function(
        build_audit_period_fn,
        audit_periods=audit_periods,
        audit_month_column=audit_month_column,
        audit_year_column=audit_year_column,
    )


async def build_grouping_replacements(module, request: BaseModel, query_template: str) -> Dict[str, str]:
    replacements: Dict[str, str] = {}
    uses_grouping_type = '{{grouping_type}}' in query_template or '{grouping_type}' in query_template
    if not uses_grouping_type:
        return replacements
    if hasattr(module, 'get_valid_audit_periods') and hasattr(module, 'determine_audit_period_grouping'):
        valid_audit_periods = await call_build_function(module.get_valid_audit_periods, get_request_audit_periods(request))
        if valid_audit_periods:
            replacements['grouping_type'] = await call_build_function(
                module.determine_audit_period_grouping,
                valid_audit_periods,
            )
            return replacements
    replacements['grouping_type'] = 'monthly'
    return replacements


async def apply_sorting_to_query(module, formatted_query: str, request: BaseModel) -> str:
    sort_by = get_request_sort_by(request)
    sort_direction = get_request_sort_direction(request)
    query_sort_transformer = get_query_sort_transformer(module)
    if query_sort_transformer:
        formatted_query = await call_build_function(
            query_sort_transformer,
            formatted_query,
            sort_by,
            sort_direction,
        )
    if hasattr(module, 'build_sort_clause') and hasattr(module, 'PRODUCTION_PCT_FRONTLINE_DEFAULT_ORDER_BY'):
        sort_clause = await call_build_function(module.build_sort_clause, sort_by, sort_direction)
        formatted_query = formatted_query.replace(
            module.PRODUCTION_PCT_FRONTLINE_DEFAULT_ORDER_BY,
            sort_clause,
            1,
        )
    return formatted_query


async def extract_sql_from_module(module, request, mode):
    sql_queries = []
    module_name = module.__name__.split('.')[-1]
    request = get_effective_request_for_module(module_name, request)

    try:
        user_id = get_request_user_id(request)
        start_date = get_request_start_date(request)
        end_date = get_request_end_date(request)
        page_limit = get_request_page_limit(request)
        page = get_request_page(request)
        offset = (page - 1) * page_limit

        for attr_name in dir(module):
            if not attr_name.endswith('_QUERY') or not attr_name.isupper():
                continue
            if not should_include_query(module_name, attr_name, mode):
                continue
            query_template = getattr(module, attr_name)
            if not isinstance(query_template, str) or 'SELECT' not in query_template.upper():
                continue
            try:
                formatted_query = query_template
                replacements = {
                    'user_id': user_id,
                    'start_date': start_date,
                    'end_date': end_date,
                    'limit': str(page_limit),
                    'offset': str(offset),
                    'page_limit': str(page_limit),
                }

                if '{{lob_filter}}' in query_template or '{lob_filter}' in query_template:
                    replacements['lob_filter'] = await build_lob_filter_replacement(
                        module_name,
                        module,
                        attr_name,
                        request,
                    )

                if '{{audit_period_filter}}' in query_template or '{audit_period_filter}' in query_template:
                    replacements['audit_period_filter'] = await build_audit_period_filter_replacement(
                        module,
                        attr_name,
                        request,
                    )

                replacements.update(await build_grouping_replacements(module, request, query_template))

                for key, value in replacements.items():
                    formatted_query = formatted_query.replace('{{' + key + '}}', str(value) if value else '')
                    formatted_query = formatted_query.replace('{' + key + '}', str(value) if value else '')

                remaining_placeholders = re.findall(r'\{\{?[^}]+\}?\}', formatted_query)
                for placeholder in remaining_placeholders:
                    formatted_query = formatted_query.replace(placeholder, '')

                formatted_query = await apply_sorting_to_query(module, formatted_query, request)

                sql_queries.append({
                    'module': module_name,
                    'query_name': attr_name,
                    'mode': mode,
                    'payload': request_to_payload(request),
                    'sql': formatted_query.strip()
                })
            except Exception as e:
                logger.warning(f"Could not format query {attr_name} in {module_name}: {e}")

    except Exception as e:
        logger.error(f"Error extracting SQL from {module_name}: {e}")

    return sql_queries

async def main():
    """Main execution function."""
    logger.info("Starting SQL extraction for Performance IQ Frontline APIs...")
    
    date_range_base_request = FrontlineBaseRequest(**PAYLOAD)
    audit_period_base_request = FrontlineBaseRequest(**AUDIT_PERIOD_PAYLOAD)
    date_range_pagination_request = PaginationRequest(**PAGINATION_PAYLOAD)
    audit_period_pagination_request = PaginationRequest(**PAGINATION_AUDIT_PERIOD_PAYLOAD)
    
    # List of all modules to process
    modules = [
        user_time,
        user_metrics,
        user_activity,
        audit_score_gauge,
        workitems_drilldown,
        auditscore_drilldown,
        production_percentage_gauge,
        fusetime_drilldown,
        production_pct_drilldown,
        ai_coach,
        audit_error_drilldown
    ]
    
    all_sql_queries = []
    
    # Extract SQL from each module
    for module in modules:
        logger.info(f"Processing module: {module.__name__}")
        module_name = module.__name__.split('.')[-1]
        module_queries = []

        date_range_request = date_range_pagination_request if module_name in DRILLDOWN_MODULES else date_range_base_request
        module_queries.extend(await extract_sql_from_module(module, date_range_request, "date_range"))

        if module_name in AUDIT_PERIOD_MODULES:
            audit_period_request = audit_period_pagination_request if module_name in DRILLDOWN_MODULES else audit_period_base_request
            module_queries.extend(await extract_sql_from_module(module, audit_period_request, "audit_period"))

        all_sql_queries.extend(module_queries)
        logger.info(f"  Found {len(module_queries)} queries")
    
    # Write to README
    output_file = f"FRONTLINE_API_SQL_DOCUMENTATION.md"
    
    # Group queries by module
    from collections import defaultdict, Counter
    queries_by_module = defaultdict(list)
    for query in all_sql_queries:
        queries_by_module[query['module']].append(query)
    
    # Write comprehensive README
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# Performance IQ Frontline API - SQL Documentation\n\n")
        f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"**Total APIs:** {len(modules)}\n")
        f.write(f"**Total SQL Queries:** {len(all_sql_queries)}\n\n")
        
        # Table of Contents
        f.write("## Table of Contents\n\n")
        for i, module_name in enumerate(sorted(queries_by_module.keys()), 1):
            query_count = len(queries_by_module[module_name])
            f.write(f"{i}. [{module_name}](#{module_name.replace('_', '-')}) ({query_count} queries)\n")
        f.write("\n---\n\n")
        
        # Detailed documentation for each module
        for module_name in sorted(queries_by_module.keys()):
            queries = queries_by_module[module_name]
            f.write(f"## {module_name}\n\n")
            f.write(f"**Number of Queries:** {len(queries)}\n\n")
            
            for i, query in enumerate(queries, 1):
                f.write(f"### {i}. {query['query_name']}\n\n")
                f.write(f"**Mode:** `{query['mode']}`\n\n")
                f.write("**Payload Used:**\n\n")
                f.write("```json\n")
                f.write(json.dumps(query['payload'], indent=2))
                f.write("\n```\n\n")
                f.write("**SQL Query:**\n\n")
                f.write("```sql\n")
                f.write(query['sql'])
                f.write("\n```\n\n")
                f.write("---\n\n")
        
        # Summary section
        f.write("## Summary\n\n")
        f.write("### Queries per Module\n\n")
        f.write("| Module | Query Count |\n")
        f.write("|--------|-------------|\n")
        module_counts = Counter(q['module'] for q in all_sql_queries)
        for module, count in sorted(module_counts.items()):
            f.write(f"| {module} | {count} |\n")
        
        f.write("\n### Test Payload Used (Non-Drilldown APIs)\n\n")
        f.write("```json\n")
        f.write(json.dumps(PAYLOAD, indent=2))
        f.write("\n```\n\n")

        f.write("### Audit Period Payload Used (Non-Drilldown APIs)\n\n")
        f.write("```json\n")
        f.write(json.dumps(AUDIT_PERIOD_PAYLOAD, indent=2))
        f.write("\n```\n\n")
        
        f.write("### Pagination Payload Used (Drilldown APIs)\n\n")
        f.write("```json\n")
        f.write(json.dumps(PAGINATION_PAYLOAD, indent=2))
        f.write("\n```\n\n")

        f.write("### Audit Period Pagination Payload Used (Drilldown APIs)\n\n")
        f.write("```json\n")
        f.write(json.dumps(PAGINATION_AUDIT_PERIOD_PAYLOAD, indent=2))
        f.write("\n```\n")
    
    logger.info(f"\n{'='*80}")
    logger.info(f"SQL extraction complete!")
    logger.info(f"Total queries extracted: {len(all_sql_queries)}")
    logger.info(f"Output file: {output_file}")
    logger.info(f"{'='*80}\n")
    
    # Print summary by module
    module_counts = Counter(q['module'] for q in all_sql_queries)
    logger.info("Queries per module:")
    for module, count in sorted(module_counts.items()):
        logger.info(f"  {module}: {count}")

if __name__ == "__main__":
    asyncio.run(main())
