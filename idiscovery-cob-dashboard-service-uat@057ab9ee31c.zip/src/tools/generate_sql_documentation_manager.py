"""
Script to execute all Performance IQ Manager APIs and save SQL queries to documentation.
This script will extract SQL queries from each Manager API endpoint.
"""
import sys
import os
import csv
import logging
import asyncio
import json
import inspect
from datetime import datetime

# Add src directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from controllers.Performance_IQ_Manager import (
    header_kpis,
    quality_outcomes,
    associate_utilization,
    associates_list,
    pended_items_counts_drilldown,
    production_pct_achieved_drilldown,
    rebuttal_drilldown,
    work_items_drilldown,
    audit_score_drilldown,
    rework_drilldown,
    fuse_time_drilldown,
    audit_errors_drilldown,
    complete_audit_count_drilldown,
    ai_coach_manager,
    user_activity,
    manager_list,
    manager_lob,
    manager_capacity_insight_drilldown,
    watchlist_manager_drilldown
)
from schema import ManagerBaseRequest

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Test payload for non-drilldown APIs
PAYLOAD = {
    "user_id": "AD50398",
    "start_date": "2026-03-17",
    "end_date": "2026-03-23",
    "lob": ["Commercial"],
    "frontline_associate_ids": ["AG01440"]
}

# Pagination payload for drilldown APIs
PAGINATION_PAYLOAD = {
    "user_id": "AD50398",
    "start_date": "2026-03-17",
    "end_date": "2026-03-23",
    "lob": ["CSBD", "Commercial", "CrossOver", "EGR", "GRS", "Group Retiree Solutions", 
            "INT", "KCP", "MDR", "MMP", "MedSupp", "Medicaid", "Medicare", "PDP", "SUP", "Supplemental"],
    "frontline_associate_ids": ["AG01440"],
    "page": 1,
    "page_size": 20
}

# List of drilldown modules that need pagination
DRILLDOWN_MODULES = [
    'pended_items_counts_drilldown',
    'production_pct_achieved_drilldown',
    'rebuttal_drilldown',
    'work_items_drilldown',
    'audit_score_drilldown',
    'rework_drilldown',
    'fuse_time_drilldown',
    'audit_errors_drilldown',
    'complete_audit_count_drilldown',
    'manager_capacity_insight_drilldown',
    'watchlist_manager_drilldown'
]

async def call_api_and_get_response(module, request: ManagerBaseRequest):
    """Call the API endpoint and capture the actual response data."""
    try:
        if hasattr(module, 'router'):
            router = module.router
            # Get the endpoint function from the router
            for route in router.routes:
                if hasattr(route, 'endpoint'):
                    endpoint_func = route.endpoint
                    # Call the async endpoint function
                    response = await endpoint_func(request)
                    
                    # Convert response to dict
                    if hasattr(response, 'dict'):
                        # Pydantic v1
                        response_dict = response.dict()
                    elif hasattr(response, 'model_dump'):
                        # Pydantic v2
                        response_dict = response.model_dump()
                    else:
                        response_dict = dict(response)
                    
                    # Convert to JSON string for storage
                    return json.dumps(response_dict, indent=2, default=str)
    except Exception as e:
        logger.warning(f"Could not call API for {module.__name__}: {e}")
        return f"Error: {str(e)}"
    
    return "N/A"

async def call_build_function(func, *args, **kwargs):
    """Helper to call a build function, handling both sync and async functions."""
    try:
        result = func(*args, **kwargs)
        # Check if result is a coroutine (async function was called)
        if inspect.iscoroutine(result):
            return await result
        return result
    except Exception as e:
        logger.warning(f"Error calling build function {func.__name__}: {e}")
        return ""

async def extract_sql_from_module(module, base_request, pagination_request=None):
    """Extract SQL queries from a module by building filters and formatting queries."""
    sql_queries = []
    module_name = module.__name__.split('.')[-1]
    
    # Determine which request to use
    request = pagination_request if module_name in DRILLDOWN_MODULES and pagination_request else base_request
    
    # Get actual API response
    # Commented out to avoid server dependency - just extract SQL queries
    # logger.info(f"  Calling API for {module_name}...")
    # api_response = await call_api_and_get_response(module, request)
    api_response = "SQL Query Only (API call skipped)"
    
    try:
        # Build common filters using the appropriate request
        lob_filter = ""
        date_filter = ""
        associate_filter = ""
        
        if hasattr(module, 'build_lob_filter'):
            lob_filter = await call_build_function(module.build_lob_filter, request.lob if hasattr(request, 'lob') else None)
        
        if hasattr(module, 'build_date_filter'):
            start = request.start_date if hasattr(request, 'start_date') else None
            end = request.end_date if hasattr(request, 'end_date') else None
            date_filter = await call_build_function(module.build_date_filter, start, end)
        
        if hasattr(module, 'build_associate_filter'):
            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
            associate_filter = await call_build_function(module.build_associate_filter, associates)
        
        # Find all SQL query constants in the module
        for attr_name in dir(module):
            if attr_name.endswith('_QUERY') and attr_name.isupper():
                query_template = getattr(module, attr_name)
                if isinstance(query_template, str) and 'SELECT' in query_template.upper():
                    try:
                        # Try to format the query with available filters
                        formatted_query = query_template
                        
                        # Replace common placeholders - handle both {{}} and {} formats
                        replacements = {
                            'lob_filter': lob_filter,
                            'date_filter': date_filter,
                            'associate_filter': associate_filter,
                        }
                        
                        # Add module-specific filters
                        if hasattr(module, 'build_user_date_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['user_date_filter'] = await call_build_function(module.build_user_date_filter, start, end)
                        
                        if hasattr(module, 'build_audit_associate_filter'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['audit_associate_filter'] = await call_build_function(module.build_audit_associate_filter, associates)
                        
                        if hasattr(module, 'build_invntry_date_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['invntry_date_filter'] = await call_build_function(module.build_invntry_date_filter, start, end)
                        
                        if hasattr(module, 'build_invntry_lob_filter'):
                            lob = request.lob if hasattr(request, 'lob') else None
                            replacements['invntry_lob_filter'] = await call_build_function(module.build_invntry_lob_filter, lob)
                        
                        # User profile specific filters
                        if hasattr(module, 'build_user_profile_associate_filter'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['user_profile_associate_filter'] = await call_build_function(module.build_user_profile_associate_filter, associates)
                        elif hasattr(module, 'build_associate_filter') and 'user_profile_associate_filter' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['user_profile_associate_filter'] = await call_build_function(module.build_associate_filter, associates, column="USERID")
                        
                        # Quality outcomes specific filters
                        if hasattr(module, 'build_audit_manager_filter'):
                            replacements['audit_manager_filter'] = ''  # Manager APIs don't filter by manager
                        
                        # Note: audit_associate_filter may have been set earlier
                        if hasattr(module, 'build_audit_associate_filter') and 'audit_associate_filter' not in replacements:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['audit_associate_filter'] = await call_build_function(module.build_audit_associate_filter, associates)
                        
                        # Additional module-specific filters
                        if hasattr(module, 'build_associate_filter_invntry'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_invntry'] = await call_build_function(module.build_associate_filter_invntry, associates)
                        elif hasattr(module, 'build_associate_filter') and 'associate_filter_invntry' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_invntry'] = await call_build_function(module.build_associate_filter, associates, column="PYRESOLVEDUSERID")
                        
                        if hasattr(module, 'build_associate_filter_user'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_user'] = await call_build_function(module.build_associate_filter_user, associates)
                        elif hasattr(module, 'build_associate_filter') and 'associate_filter_user' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_user'] = await call_build_function(module.build_associate_filter, associates, column="USERID")
                        
                        if hasattr(module, 'build_associate_filter_audit'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_audit'] = await call_build_function(module.build_associate_filter_audit, associates)
                        elif hasattr(module, 'build_associate_filter') and 'associate_filter_audit' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_audit'] = await call_build_function(module.build_associate_filter, associates, column="AUDIT_SUBJECT_ID")
                        
                        if hasattr(module, 'build_associate_filter_assigned'):
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_assigned'] = await call_build_function(module.build_associate_filter_assigned, associates)
                        elif hasattr(module, 'build_associate_filter') and 'associate_filter_assigned' in query_template:
                            associates = request.frontline_associate_ids if hasattr(request, 'frontline_associate_ids') else None
                            replacements['associate_filter_assigned'] = await call_build_function(module.build_associate_filter, associates, column="ASSIGNEDTO")
                        
                        if hasattr(module, 'build_date_filter_where'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['date_filter_where'] = await call_build_function(module.build_date_filter_where, start, end)
                        
                        if hasattr(module, 'build_user_date_filter_where'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['user_date_filter_where'] = await call_build_function(module.build_user_date_filter_where, start, end)
                        
                        # Associates list specific filter (frontline_date_filter)
                        if 'frontline_date_filter' in query_template:
                            if hasattr(module, 'build_date_filter'):
                                start = request.start_date if hasattr(request, 'start_date') else None
                                end = request.end_date if hasattr(request, 'end_date') else None
                                replacements['frontline_date_filter'] = await call_build_function(module.build_date_filter, start, end)
                            else:
                                replacements['frontline_date_filter'] = ''
                        
                        # Manager list specific filters
                        if 'manager_date_filter' in query_template:
                            if hasattr(module, 'build_date_filter'):
                                start = request.start_date if hasattr(request, 'start_date') else None
                                end = request.end_date if hasattr(request, 'end_date') else None
                                replacements['manager_date_filter'] = await call_build_function(module.build_date_filter, start, end)
                            else:
                                replacements['manager_date_filter'] = ''
                        
                        # Audit date filter
                        if hasattr(module, 'build_audit_date_filter'):
                            start = request.start_date if hasattr(request, 'start_date') else None
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['audit_date_filter'] = await call_build_function(module.build_audit_date_filter, start, end)
                        
                        # Rework date filter (for PXCREATEDATETIME in rework queries)
                        if 'rework_date_filter' in query_template:
                            if hasattr(module, 'build_date_filter'):
                                start = request.start_date if hasattr(request, 'start_date') else None
                                end = request.end_date if hasattr(request, 'end_date') else None
                                replacements['rework_date_filter'] = await call_build_function(module.build_date_filter, start, end, date_column="PXCREATEDATETIME")
                            else:
                                replacements['rework_date_filter'] = ''
                        
                        # Manager filter (Manager API doesn't use this but handle gracefully)
                        if 'manager_filter' in query_template:
                            if hasattr(module, 'build_manager_filter'):
                                replacements['manager_filter'] = await call_build_function(module.build_manager_filter, None)
                            else:
                                replacements['manager_filter'] = ''
                        
                        if 'audit_lob_filter' in query_template:
                            # audit_lob_filter uses the same lob_filter
                            replacements['audit_lob_filter'] = lob_filter
                        
                        # Add user_id as direct replacement
                        replacements['user_id'] = request.user_id if hasattr(request, 'user_id') else ''
                        
                        # Add start_date and end_date as direct replacements
                        replacements['start_date'] = request.start_date if hasattr(request, 'start_date') else ''
                        replacements['end_date'] = request.end_date if hasattr(request, 'end_date') else ''
                        
                        # MISSING FILTERS - Added based on comprehensive analysis
                        # 1. Config imports (SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA)
                        from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
                        replacements['SNOWFLAKE_DATABASE'] = SNOWFLAKE_DATABASE
                        replacements['SNOWFLAKE_SCHEMA'] = SNOWFLAKE_SCHEMA
                        
                        # 2. Direct parameter substitutions
                        replacements['associate_id'] = request.frontline_associate_id if hasattr(request, 'frontline_associate_id') else ''
                        replacements['page_size'] = str(request.page_size) if hasattr(request, 'page_size') else '20'
                        
                        # 3. Build function handlers for missing filters
                        if hasattr(module, 'build_access_group_filter'):
                            user_access_group = request.user_access_group if hasattr(request, 'user_access_group') else None
                            replacements['access_group_filter'] = await call_build_function(module.build_access_group_filter, user_access_group)
                        
                        if hasattr(module, 'build_manager_filter_invntry'):
                            replacements['manager_filter_invntry'] = await call_build_function(module.build_manager_filter_invntry, request.user_id if hasattr(request, 'user_id') else None)
                        
                        if hasattr(module, 'build_manager_filter_user'):
                            replacements['manager_filter_user'] = await call_build_function(module.build_manager_filter_user, request.user_id if hasattr(request, 'user_id') else None)
                        
                        if hasattr(module, 'build_pended_created_filter'):
                            end = request.end_date if hasattr(request, 'end_date') else None
                            replacements['pended_created_filter'] = await call_build_function(module.build_pended_created_filter, end)
                        
                        # 4. user_manager_filter - doesn't have build function, use manager_filter_user or empty
                        if hasattr(module, 'build_manager_filter_user') and 'user_manager_filter' not in replacements:
                            replacements['user_manager_filter'] = await call_build_function(module.build_manager_filter_user, request.user_id if hasattr(request, 'user_id') else None)
                        else:
                            replacements['user_manager_filter'] = ''
                        
                        # Add pagination placeholders
                        if hasattr(request, 'page') and hasattr(request, 'page_size'):
                            offset = (request.page - 1) * request.page_size
                            replacements['limit'] = str(request.page_size)
                            replacements['offset'] = str(offset)
                        else:
                            replacements['limit'] = '20'
                            replacements['offset'] = '0'
                        
                        # Drilldown specific filters
                        if hasattr(module, 'build_sort_clause'):
                            replacements['sort_clause'] = ''
                        
                        # Replace all placeholders - handle both {{placeholder}} and {placeholder} formats
                        import re
                        for key, value in replacements.items():
                            # Replace {{placeholder}} format
                            formatted_query = formatted_query.replace('{{' + key + '}}', value if value else '')
                            # Replace {placeholder} format
                            formatted_query = formatted_query.replace('{' + key + '}', value if value else '')
                        
                        # Clean up any remaining unreplaced placeholders
                        remaining_placeholders = re.findall(r'\{\{?[^}]+\}?\}', formatted_query)
                        for placeholder in remaining_placeholders:
                            formatted_query = formatted_query.replace(placeholder, '')
                        
                        sql_queries.append({
                            'module': module_name,
                            'query_name': attr_name,
                            'api_response': api_response,
                            'sql': formatted_query.strip()
                        })
                    except Exception as e:
                        logger.warning(f"Could not format query {attr_name} in {module_name}: {e}")
    
    except Exception as e:
        logger.error(f"Error extracting SQL from {module_name}: {e}")
    
    return sql_queries

async def main():
    """Main execution function."""
    logger.info("Starting SQL extraction for Performance IQ Manager APIs...")
    
    # Create request objects
    base_request = ManagerBaseRequest(**PAYLOAD)
    
    # Create pagination request object (using Pydantic BaseModel dynamically)
    from pydantic import BaseModel, Field
    from typing import Optional, List
    
    class PaginationRequest(BaseModel):
        user_id: Optional[str] = None
        start_date: Optional[str] = None
        end_date: Optional[str] = None
        lob: Optional[List[str]] = None
        frontline_associate_ids: Optional[List[str]] = None
        page: int = 1
        page_size: int = 20
    
    pagination_request = PaginationRequest(**PAGINATION_PAYLOAD)
    
    # List of all modules to process
    modules = [
        header_kpis,
        quality_outcomes,
        associate_utilization,
        associates_list,
        pended_items_counts_drilldown,
        production_pct_achieved_drilldown,
        rebuttal_drilldown,
        work_items_drilldown,
        audit_score_drilldown,
        rework_drilldown,
        fuse_time_drilldown,
        audit_errors_drilldown,
        complete_audit_count_drilldown,
        ai_coach_manager,
        user_activity,
        manager_list,
        manager_lob,
        manager_capacity_insight_drilldown,
        watchlist_manager_drilldown
    ]
    
    all_sql_queries = []
    
    # Extract SQL from each module
    for module in modules:
        logger.info(f"Processing module: {module.__name__}")
        queries = await extract_sql_from_module(module, base_request, pagination_request)
        all_sql_queries.extend(queries)
        logger.info(f"  Found {len(queries)} queries")
    
    # Write to README
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"MANAGER_API_SQL_DOCUMENTATION.md"
    
    # Group queries by module
    from collections import defaultdict, Counter
    queries_by_module = defaultdict(list)
    for query in all_sql_queries:
        queries_by_module[query['module']].append(query)
    
    # Write comprehensive README
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# Performance IQ Manager API - SQL Documentation\n\n")
        f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"**Total APIs:** {len(modules)}\n")
        f.write(f"**Total SQL Queries:** {len(all_sql_queries)}\n\n")
        
        # Table of Contents
        f.write("## Table of Contents\n\n")
        for i, module_name in enumerate(sorted(queries_by_module.keys()), 1):
            query_count = len(queries_by_module[module_name])
            f.write(f"{i}. [{module_name}](#{module_name.replace('_', '-')}) ({query_count} queries)\n")
        f.write("\n---\n\n")
        
        # Detailed documentation for each module
        for module_name in sorted(queries_by_module.keys()):
            queries = queries_by_module[module_name]
            f.write(f"## {module_name}\n\n")
            f.write(f"**Number of Queries:** {len(queries)}\n\n")
            
            for i, query in enumerate(queries, 1):
                f.write(f"### {i}. {query['query_name']}\n\n")
                f.write("**SQL Query:**\n\n")
                f.write("```sql\n")
                f.write(query['sql'])
                f.write("\n```\n\n")
                f.write("---\n\n")
        
        # Summary section
        f.write("## Summary\n\n")
        f.write("### Queries per Module\n\n")
        f.write("| Module | Query Count |\n")
        f.write("|--------|-------------|\n")
        module_counts = Counter(q['module'] for q in all_sql_queries)
        for module, count in sorted(module_counts.items()):
            f.write(f"| {module} | {count} |\n")
        
        f.write("\n### Test Payload Used\n\n")
        f.write("```json\n")
        f.write(json.dumps(PAYLOAD, indent=2))
        f.write("\n```\n\n")
        
        f.write("### Pagination Payload Used\n\n")
        f.write("```json\n")
        f.write(json.dumps(PAGINATION_PAYLOAD, indent=2))
        f.write("\n```\n")
    
    logger.info(f"\n{'='*80}")
    logger.info(f"SQL extraction complete!")
    logger.info(f"Total queries extracted: {len(all_sql_queries)}")
    logger.info(f"Output file: {output_file}")
    logger.info(f"{'='*80}\n")
    
    # Print summary by module
    module_counts = Counter(q['module'] for q in all_sql_queries)
    logger.info("Queries per module:")
    for module, count in sorted(module_counts.items()):
        logger.info(f"  {module}: {count}")

if __name__ == "__main__":
    asyncio.run(main())
