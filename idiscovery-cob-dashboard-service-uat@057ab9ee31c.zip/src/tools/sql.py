from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

def get_fuse_time_query(user_id: str, start_date: str, end_date: str, lob: str = None) -> str:
    """
    Generate SQL query to fetch total fuse time for a user within a date range
    
    Args:
        user_id: User ID to query
        start_date: Start date in YYYYMMDD format
        end_date: End date in YYYYMMDD format
    
    Returns:
        SQL query string
    """
    query = f"""
select DISTINCT USERID, LOGINDATE, a.TOTALSYSTEMTIME, b.LOB from {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE a
LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE b ON a.USERID = b.ASSIGNEDTO WHERE USERID = '{user_id}'
AND LOGINDATE >= CAST('{start_date}' AS DATE) AND LOGINDATE <= CAST('{end_date}' AS DATE)
    """
    if lob:
        query += f" AND b.LOB = '{lob}'"

    return query

def get_non_productive_time_query(user_id: str, start_date: str, end_date: str, lob: str = None) -> str:
    """
    Generate SQL query to fetch non-productive time for a user within a date range
    
    Args:
        user_id: User ID to query
        start_date: Start date in YYYYMMDD format
        end_date: End date in YYYYMMDD format
    
    Returns:
        SQL query string
    """
    query = f"""
select DISTINCT USERID, LOGINDATE, a.NON_PRODUCTIVE_TIME, b.LOB from {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE a
LEFT JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE b ON a.USERID = b.ASSIGNEDTO WHERE USERID = '{user_id}'
AND LOGINDATE >= CAST('{start_date}' AS DATE) AND LOGINDATE <= CAST('{end_date}' AS DATE)
    """
    if lob:
        query += f" AND b.LOB = '{lob}'"

    return query