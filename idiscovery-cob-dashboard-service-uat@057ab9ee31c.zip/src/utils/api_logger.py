"""
API Logging Utilities for Splunk Integration

This module provides structured JSON logging for easy Splunk filtering:
- Middleware: Automatically captures timing for ALL API requests
- Decorator: Adds custom context to specific endpoints

Splunk Query Examples:
    # All API timing logs
    index=your_index event_type="api_request"
    
    # Specific API
    index=your_index event_type="api_request" api_name="get_associate_utilization"
    
    # All Director APIs
    index=your_index event_type="api_request" api_group="Performance_IQ_Director"
    
    # Slow APIs (>500ms)
    index=your_index event_type="api_request" duration_ms > 500
    
    # Average response time per API
    index=your_index event_type="api_request" | stats avg(duration_ms) by api_name
"""

import json
import logging
import time
import uuid
from datetime import datetime, timezone
from functools import wraps
from typing import Optional, Dict, Any, Callable, Iterable
from contextvars import ContextVar

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

# Context variable to store request-specific data across async calls
_request_context: ContextVar[Dict[str, Any]] = ContextVar("request_context", default={})
_DEFAULT_RUNTIME_LOGGER_NAMES = (None, "uvicorn", "uvicorn.error", "uvicorn.access")


class SplunkJSONFormatter(logging.Formatter):
    """
    JSON formatter optimized for Splunk ingestion.
    Outputs one JSON object per line for easy parsing.
    """

    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Add extra fields from the record (e.g., api_name, duration_ms)
        if hasattr(record, "extra_fields"):
            log_data.update(record.extra_fields)

        return json.dumps(log_data, default=str)


def setup_json_logging(
    logger_name: str = None,
    level: int = logging.INFO,
    enable_console: bool = True
) -> logging.Logger:
    """
    Configure a logger with JSON formatting for Splunk.
    
    Args:
        logger_name: Name of the logger (None for root logger)
        level: Logging level
        enable_console: Whether to add console handler
    
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    logger.propagate = False

    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()

    if enable_console:
        handler = logging.StreamHandler()
        handler.setFormatter(SplunkJSONFormatter())
        logger.addHandler(handler)

    return logger


def dedupe_stream_handlers(logger: logging.Logger) -> int:
    """Remove duplicate stream handlers from a logger."""
    seen = set()
    removed = 0

    for handler in list(logger.handlers):
        stream = getattr(handler, "stream", None)
        key = (type(handler), id(stream))

        if key in seen:
            logger.removeHandler(handler)
            removed += 1
            continue

        seen.add(key)

    return removed


def dedupe_runtime_loggers(logger_names: Optional[Iterable[Optional[str]]] = None) -> int:
    """Remove duplicate stream handlers from the root and runtime logger set."""
    names = tuple(logger_names or _DEFAULT_RUNTIME_LOGGER_NAMES)
    removed = 0

    for logger_name in names:
        removed += dedupe_stream_handlers(logging.getLogger(logger_name))

    return removed


def get_request_id() -> Optional[str]:
    """Get the current request ID from context."""
    ctx = _request_context.get()
    return ctx.get("request_id")


def _extract_api_group(path: str) -> str:
    """Extract API group from path for filtering."""
    if path.startswith("/director"):
        return "Performance_IQ_Director"
    elif path.startswith("/manager"):
        return "Performance_IQ_Manager"
    elif path.startswith("/auditor-manager"):
        return "Performance_IQ_Auditor_Manager"
    elif path.startswith("/fl-auditor"):
        return "Performance_IQ_FL_Auditor"
    elif path.startswith("/workforce-iq"):
        return "WorkForce_IQ"
    elif path.startswith("/snowflake") or path.startswith("/user-role"):
        return "common"
    elif path in ["/", "/health"]:
        return "system"
    else:
        return "Performance_IQ"


def _extract_api_name(request: Request) -> str:
    """Extract a clean API name from the route."""
    route = request.scope.get("route")
    if route and hasattr(route, "endpoint"):
        return route.endpoint.__name__
    # Fallback: use path
    path = request.url.path.strip("/").replace("/", "_").replace("-", "_")
    return path or "root"


class APITimingMiddleware(BaseHTTPMiddleware):
    """
    FastAPI middleware that logs timing metrics for every API request.
    
    Emits structured JSON logs with fields optimized for Splunk filtering:
    - event_type: Always "api_request" for easy filtering
    - api_name: Function name of the endpoint
    - api_path: URL path
    - api_group: Controller group (Performance_IQ, Performance_IQ_Director, common)
    - method: HTTP method
    - duration_ms: Response time in milliseconds
    - status_code: HTTP status code
    - request_id: Unique ID for request correlation
    """

    def __init__(self, app, logger: logging.Logger = None):
        super().__init__(app)
        self.logger = logger or logging.getLogger("api.timing")

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        dedupe_runtime_loggers()

        # Generate unique request ID
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))

        # Store in context for access by decorators/handlers
        ctx = {"request_id": request_id, "start_time": time.perf_counter()}
        token = _request_context.set(ctx)

        try:
            # Process request
            start_time = time.perf_counter()
            response = await call_next(request)
            duration_ms = (time.perf_counter() - start_time) * 1000

            # Build log record with extra fields
            self._log_request(
                request=request,
                status_code=response.status_code,
                duration_ms=duration_ms,
                request_id=request_id,
            )

            # Add request ID to response headers for tracing
            response.headers["X-Request-ID"] = request_id
            return response

        except Exception as e:
            duration_ms = (time.perf_counter() - start_time) * 1000
            self._log_request(
                request=request,
                status_code=500,
                duration_ms=duration_ms,
                request_id=request_id,
                error=str(e),
            )
            raise
        finally:
            _request_context.reset(token)

    def _log_request(
        self,
        request: Request,
        status_code: int,
        duration_ms: float,
        request_id: str,
        error: str = None,
    ):
        """Emit structured log entry for the API request."""
        path = request.url.path
        api_name = _extract_api_name(request)
        api_group = _extract_api_group(path)
        ctx = _request_context.get()
        custom_context = ctx.get("custom_context", {})

        api_name = custom_context.get("api_name_override", api_name)
        api_group = custom_context.get("api_group_override", api_group)

        extra_fields = {
            "event_type": "api_request",
            "project": "COB",
            "api_name": api_name,
            "api_path": path,
            "api_group": api_group,
            "method": request.method,
            "duration_ms": round(duration_ms, 2),
            "status_code": status_code,
            "request_id": request_id,
        }

        if error:
            extra_fields["error"] = error

        # Add custom context from decorator if present
        if custom_context:
            extra_fields["custom_context"] = {
                key: value
                for key, value in custom_context.items()
                if key not in {"api_name_override", "api_group_override"}
            }

        # Create log record with extra fields
        record = logging.LogRecord(
            name=self.logger.name,
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg=f"API {request.method} {path} completed in {duration_ms:.2f}ms",
            args=(),
            exc_info=None,
        )
        record.extra_fields = extra_fields

        self.logger.handle(record)


def api_timer(
    api_name: str = None,
    api_group: str = None,
    include_params: bool = False,
    custom_fields: Dict[str, Any] = None,
):
    """
    Decorator to add custom context to API timing logs.
    
    Use this when you need to add custom fields beyond what middleware captures.
    
    Args:
        api_name: Override the auto-detected API name
        api_group: Override the auto-detected API group
        include_params: Whether to log request parameters
        custom_fields: Additional fields to include in the log
    
    Example:
        @router.post("/my-endpoint")
        @api_timer(api_name="custom_api_name", custom_fields={"feature": "reports"})
        async def my_endpoint(request: MyRequest):
            ...
    """

    def decorator(func: Callable):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            ctx = _request_context.get()
            
            # Add custom context that middleware will pick up
            custom_context = custom_fields.copy() if custom_fields else {}
            if api_name:
                custom_context["api_name_override"] = api_name
            if api_group:
                custom_context["api_group_override"] = api_group
            if include_params:
                # Safely extract serializable params
                custom_context["params"] = {
                    k: str(v) for k, v in kwargs.items()
                    if not k.startswith("_")
                }

            ctx["custom_context"] = custom_context
            _request_context.set(ctx)

            return await func(*args, **kwargs)

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            ctx = _request_context.get()
            
            custom_context = custom_fields.copy() if custom_fields else {}
            if api_name:
                custom_context["api_name_override"] = api_name
            if api_group:
                custom_context["api_group_override"] = api_group
            if include_params:
                custom_context["params"] = {
                    k: str(v) for k, v in kwargs.items()
                    if not k.startswith("_")
                }

            ctx["custom_context"] = custom_context
            _request_context.set(ctx)

            return func(*args, **kwargs)

        # Return appropriate wrapper based on function type
        import asyncio
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator


def log_api_event(
    event_type: str,
    api_name: str,
    message: str,
    level: int = logging.INFO,
    **extra_fields
):
    """
    Log a custom API event with structured fields for Splunk.
    
    Use this for logging specific events within an API handler
    (e.g., database query timing, external API calls).
    
    Args:
        event_type: Type of event (e.g., "db_query", "external_api")
        api_name: Name of the API this event belongs to
        message: Human-readable log message
        level: Logging level
        **extra_fields: Additional fields to include
    
    Example:
        log_api_event(
            event_type="db_query",
            api_name="get_associate_utilization",
            message="Executed FUSE time query",
            duration_ms=150.5,
            query_type="fuse_time"
        )
    """
    logger = logging.getLogger("api.events")

    fields = {
        "event_type": event_type,
        "project": "COB",
        "api_name": api_name,
        "request_id": get_request_id(),
        **extra_fields,
    }

    record = logging.LogRecord(
        name=logger.name,
        level=level,
        pathname="",
        lineno=0,
        msg=message,
        args=(),
        exc_info=None,
    )
    record.extra_fields = fields

    logger.handle(record)
