import logging
import os
from typing import Iterable, Optional, Set

from fastapi import Request
from fastapi.responses import JSONResponse, Response
from starlette.middleware.base import BaseHTTPMiddleware

import config as config
from .jwt_auth import get_jwt_user_id, verify_jwt_token

logger = logging.getLogger(__name__)


def _get_bool_setting(name: str, default: str = "false") -> bool:
    configured_value = getattr(config, name, None)
    if isinstance(configured_value, bool):
        return configured_value

    raw_value = os.environ.get(name)
    if raw_value is None and configured_value is not None:
        raw_value = str(configured_value)

    return (raw_value or default).lower() == "true"


def _get_str_setting(name: str, default: str = "") -> str:
    raw_value = os.environ.get(name)
    if raw_value is not None:
        return raw_value

    configured_value = getattr(config, name, None)
    if configured_value is None:
        return default

    return str(configured_value)


def _normalize_path(path: str) -> str:
    normalized_path = path.strip()
    if normalized_path == "/":
        return normalized_path

    return normalized_path.rstrip("/")


class APIAuthMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app,
        *,
        enabled: bool,
        protected_paths: Iterable[str],
        protect_all_routes: bool = False,
        header_name: str = "Authorization",
        excluded_paths: Optional[Iterable[str]] = None,
    ):
        super().__init__(app)
        self.enabled = enabled
        self.protect_all_routes = protect_all_routes
        self.header_name = header_name
        self.protected_paths: Set[str] = {
            _normalize_path(path) for path in protected_paths if path and path.strip()
        }
        self.excluded_paths: Set[str] = {
            _normalize_path(path) for path in (excluded_paths or []) if path and path.strip()
        }

    def _should_authenticate(self, request: Request) -> bool:
        if not _get_bool_setting("API_AUTH_ENABLED", "true"):
            return False

        if request.method.upper() == "OPTIONS":
            return False

        path = _normalize_path(request.url.path)
        if path in self.excluded_paths:
            return False

        if _get_bool_setting("API_AUTH_PROTECT_ALL_ROUTES", "true") or self.protect_all_routes:
            return True

        return path in self.protected_paths

    def _extract_request_token(self, request: Request) -> Optional[str]:
        raw_value = request.headers.get(self.header_name)
        if raw_value:
            token = raw_value.strip()
            if self.header_name.lower() == "authorization" and token.lower().startswith("bearer "):
                token = token[7:].strip()

            prefix = _get_str_setting("API_AUTH_HEADER_PREFIX", "").strip()
            if prefix and token.startswith(prefix):
                token = token[len(prefix):].strip()

            if token:
                return token

        return None

    async def dispatch(self, request: Request, call_next) -> Response:
        if not self._should_authenticate(request):
            return await call_next(request)

        provided_token = self._extract_request_token(request)
        if not provided_token:
            return JSONResponse(
                status_code=401,
                content={"detail": "Missing authentication token"},
            )

        try:
            token_payload = verify_jwt_token(provided_token)
        except Exception as exc:
            logger.warning("JWT verification failed: %s", exc)
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid authentication token"},
            )

        request.state.is_authenticated = True
        request.state.auth_token = provided_token
        request.state.auth_claims = token_payload
        request.state.user_id = get_jwt_user_id(token_payload)
        request.state.user_role = token_payload.get("role")
        request.state.domain_id = token_payload.get("domainID")
        request.state.jwt_subject = token_payload.get("sub")
        request.state.jwt_groups = token_payload.get("groups") or []
        return await call_next(request)
