"""
Cache Key Builder Utility

Provides deterministic filter hashing for Redis cache keys to ensure proper cache isolation
when different filter combinations are used across Performance IQ APIs.

Cache Key Format: session:{session_id}:{filters_hash}:{metric_name}

Example:
    filters = {
        'start_date': '2026-03-01',
        'end_date': '2026-03-25',
        'lob': ['Commercial', 'Medicare'],
        'manager_ids': ['ROSETSC']
    }
    hash = build_filters_hash(**filters)
    # Returns: '7f3a2b1c4d5e6f7a'
"""

import hashlib
import json
import logging
from typing import Any, Dict, Optional, List

logger = logging.getLogger(__name__)


def build_filters_hash(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    lob: Optional[List[str]] = None,
    director_ids: Optional[List[str]] = None,
    manager_ids: Optional[List[str]] = None,
    frontline_associate_ids: Optional[List[str]] = None,
    user_id: Optional[str] = None,
    auditor_ids: Optional[List[str]] = None,
    auditor_manager_ids: Optional[List[str]] = None,
    **kwargs  # Additional filters for specific APIs
) -> str:
    """
    Generate deterministic hash from filter parameters.
    
    This function creates a consistent hash for any combination of filter parameters,
    ensuring that the same filters always produce the same hash regardless of the order
    in which they are provided.
    
    Args:
        start_date: Start date filter (YYYY-MM-DD format)
        end_date: End date filter (YYYY-MM-DD format)
        lob: List of Line of Business values
        director_ids: List of director IDs
        manager_ids: List of manager IDs
        frontline_associate_ids: List of frontline associate IDs
        user_id: Single user ID filter
        auditor_ids: List of auditor IDs
        auditor_manager_ids: List of auditor manager IDs
        **kwargs: Additional filter parameters for specific APIs
        
    Returns:
        16-character hex string (first 16 chars of SHA-256 hash)
        
    Examples:
        >>> build_filters_hash(start_date='2026-03-01', end_date='2026-03-25')
        '7f3a2b1c4d5e6f7a'
        
        >>> build_filters_hash(lob=['Commercial', 'Medicare'], manager_ids=['MGR001'])
        '9d4e5f2a1b3c7d8e'
    """
    # Build sorted dict of non-None filters
    filters = {}
    
    # Add standard filters if provided
    if start_date is not None:
        filters['start_date'] = start_date
    if end_date is not None:
        filters['end_date'] = end_date
    if lob is not None and len(lob) > 0:
        # Sort list filters for consistency
        filters['lob'] = sorted([str(x) for x in lob if x is not None])
    if director_ids is not None and len(director_ids) > 0:
        filters['director_ids'] = sorted([str(x) for x in director_ids if x is not None])
    if manager_ids is not None and len(manager_ids) > 0:
        filters['manager_ids'] = sorted([str(x) for x in manager_ids if x is not None])
    if frontline_associate_ids is not None and len(frontline_associate_ids) > 0:
        filters['frontline_associate_ids'] = sorted([str(x) for x in frontline_associate_ids if x is not None])
    if user_id is not None:
        filters['user_id'] = str(user_id)
    if auditor_ids is not None and len(auditor_ids) > 0:
        filters['auditor_ids'] = sorted([str(x) for x in auditor_ids if x is not None])
    if auditor_manager_ids is not None and len(auditor_manager_ids) > 0:
        filters['auditor_manager_ids'] = sorted([str(x) for x in auditor_manager_ids if x is not None])
    
    # Add any additional filters from kwargs
    for key, value in sorted(kwargs.items()):
        if value is not None:
            if isinstance(value, list):
                # Sort list values for consistency
                if len(value) > 0:
                    filters[key] = sorted([str(x) for x in value if x is not None])
            else:
                filters[key] = str(value)
    
    # If no filters provided, return empty hash indicator
    if not filters:
        logger.debug("No filters provided, using 'nofilters' hash")
        return "nofilters"
    
    # Generate deterministic JSON string (sorted keys)
    filter_string = json.dumps(filters, sort_keys=True, separators=(',', ':'))
    
    # Hash using SHA-256 and return first 16 characters
    hash_value = hashlib.sha256(filter_string.encode('utf-8')).hexdigest()[:16]
    
    logger.debug(f"Generated filters hash: {hash_value} from filters: {filter_string}")
    
    return hash_value


def build_filters_dict_from_request(request: Any) -> Dict[str, Any]:
    """
    Extract filter parameters from a request object into a dictionary.
    
    This helper function extracts all common filter attributes from request objects
    used across Performance IQ APIs, making it easier to pass filters to caching functions.
    
    Args:
        request: Request object (DirectorBaseRequest, ManagerBaseRequest, etc.)
        
    Returns:
        Dictionary of filter parameters with None values excluded
        
    Examples:
        >>> filters = build_filters_dict_from_request(request)
        >>> filters_hash = build_filters_hash(**filters)
    """
    filters = {}
    
    # Extract common filter attributes
    filter_attrs = [
        'start_date',
        'end_date',
        'lob',
        'director_ids',
        'manager_ids',
        'frontline_associate_ids',
        'user_id',
        'auditor_ids',
        'auditor_manager_ids',
    ]
    
    for attr in filter_attrs:
        value = getattr(request, attr, None)
        if value is not None:
            # Skip empty lists
            if isinstance(value, list) and len(value) == 0:
                continue
            filters[attr] = value
    
    return filters


def validate_filters_hash(filters_hash: str) -> bool:
    """
    Validate that a filters hash is in the correct format.
    
    Args:
        filters_hash: The hash string to validate
        
    Returns:
        True if valid, False otherwise
        
    Examples:
        >>> validate_filters_hash('7f3a2b1c4d5e6f7a')
        True
        >>> validate_filters_hash('nofilters')
        True
        >>> validate_filters_hash('invalid')
        False
    """
    if filters_hash == "nofilters":
        return True
    
    # Must be exactly 16 hex characters
    if len(filters_hash) != 16:
        return False
    
    try:
        int(filters_hash, 16)
        return True
    except ValueError:
        return False
