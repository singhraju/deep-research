import base64
import json
import logging
import os
import time
import urllib.request
from threading import Lock
from typing import Any, Optional

import config as config
from jwcrypto import jwk, jwt

logger = logging.getLogger(__name__)


DEFAULT_JWKS_CACHE_TTL_SECONDS = 300
DEFAULT_JWKS_TIMEOUT_SECONDS = 5


def _get_str_setting(name: str, default: str = "") -> str:
    raw_value = os.environ.get(name)
    if raw_value is not None:
        return raw_value

    configured_value = getattr(config, name, None)
    if configured_value is None:
        return default

    return str(configured_value)


def _get_int_setting(name: str, default: int) -> int:
    raw_value = os.environ.get(name)
    if raw_value is None:
        configured_value = getattr(config, name, None)
        raw_value = None if configured_value is None else str(configured_value)

    try:
        return int(raw_value) if raw_value is not None else default
    except (TypeError, ValueError):
        return default


def _decode_segment(segment: str) -> dict[str, Any]:
    padding = "=" * (-len(segment) % 4)
    decoded = base64.urlsafe_b64decode(f"{segment}{padding}")
    return json.loads(decoded.decode("utf-8"))


def _normalize_audience(audience: Any) -> list[str]:
    if audience is None:
        return []
    if isinstance(audience, str):
        return [audience]
    if isinstance(audience, list):
        return [str(value) for value in audience]
    return [str(audience)]


def _resolve_jwks_url() -> str:
    explicit_url = str(getattr(config, "API_AUTH_JWKS_URL", "") or "").strip()
    if not explicit_url:
        raise ValueError("API_AUTH_JWKS_URL is not configured")
    return explicit_url


class JWKSKeyStore:
    def __init__(self) -> None:
        self._lock = Lock()
        self._keys: dict[str, dict[str, Any]] = {}
        self._refreshed_at = 0.0

    def _jwks_url(self) -> str:
        return _resolve_jwks_url()

    def _cache_ttl(self) -> int:
        return _get_int_setting("API_AUTH_JWKS_CACHE_TTL_SECONDS", DEFAULT_JWKS_CACHE_TTL_SECONDS)

    def _timeout_seconds(self) -> int:
        return _get_int_setting("API_AUTH_JWKS_TIMEOUT_SECONDS", DEFAULT_JWKS_TIMEOUT_SECONDS)

    def _is_cache_valid(self) -> bool:
        if not self._keys:
            return False
        return (time.time() - self._refreshed_at) < self._cache_ttl()

    def _refresh_locked(self) -> None:
        jwks_url = self._jwks_url()
        if not jwks_url:
            raise ValueError("API_AUTH_JWKS_URL is not configured")

        request = urllib.request.Request(jwks_url, headers={"Accept": "application/json"}, method="GET")
        with urllib.request.urlopen(request, timeout=self._timeout_seconds()) as response:
            payload = json.loads(response.read().decode("utf-8"))

        keys = payload.get("keys")
        if not isinstance(keys, list) or not keys:
            raise ValueError("JWKS response does not contain any keys")

        mapping: dict[str, dict[str, Any]] = {}
        for key_payload in keys:
            if not isinstance(key_payload, dict):
                continue
            kid = key_payload.get("kid")
            if kid:
                mapping[str(kid)] = key_payload

        if not mapping:
            raise ValueError("JWKS response does not contain usable kid entries")

        self._keys = mapping
        self._refreshed_at = time.time()

    def get_key_payload(self, kid: Optional[str]) -> dict[str, Any]:
        with self._lock:
            if not self._is_cache_valid() or (kid and kid not in self._keys):
                self._refresh_locked()

            if kid and kid in self._keys:
                return self._keys[kid]

            if not kid and len(self._keys) == 1:
                return next(iter(self._keys.values()))

            raise KeyError(f"No JWKS key found for kid '{kid}'")


class JWTAuthVerifier:
    def __init__(self) -> None:
        self._keystore = JWKSKeyStore()

    def _expected_algorithm(self) -> str:
        return _get_str_setting("API_AUTH_JWT_ALGORITHM", "RS256")

    def _expected_issuer(self) -> str:
        return _get_str_setting("API_AUTH_JWT_ISSUER", "idiscovery.auth.service.com")

    def _expected_audience(self) -> str:
        return _get_str_setting("API_AUTH_JWT_AUDIENCE", "idiscovery.users")

    def _user_id_claim(self) -> str:
        return _get_str_setting("API_AUTH_USER_ID_CLAIM", "domainID")

    def _fallback_user_id_claim(self) -> str:
        return _get_str_setting("API_AUTH_FALLBACK_USER_ID_CLAIM", "sub")

    def _parse_header(self, token: str) -> dict[str, Any]:
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError("JWT must contain exactly 3 segments")
        return _decode_segment(parts[0])

    def _validate_claims(self, claims: dict[str, Any]) -> None:
        current_time = int(time.time())

        if claims.get("iss") != self._expected_issuer():
            raise ValueError("JWT issuer mismatch")

        audiences = _normalize_audience(claims.get("aud"))
        if self._expected_audience() not in audiences:
            raise ValueError("JWT audience mismatch")

        exp = claims.get("exp")
        if exp is None or int(exp) <= current_time:
            raise ValueError("JWT has expired")

        nbf = claims.get("nbf")
        if nbf is not None and int(nbf) > current_time:
            raise ValueError("JWT not yet valid")

        user_id = claims.get(self._user_id_claim()) or claims.get(self._fallback_user_id_claim())
        if not user_id:
            raise ValueError("JWT does not contain a user identifier")

    def verify_token(self, token: str) -> dict[str, Any]:
        header = self._parse_header(token)
        algorithm = header.get("alg")
        if algorithm != self._expected_algorithm():
            raise ValueError("Unexpected JWT algorithm")

        kid = header.get("kid")
        key_payload = self._keystore.get_key_payload(str(kid) if kid is not None else None)
        key = jwk.JWK.from_json(json.dumps(key_payload))
        verified_jwt = jwt.JWT(jwt=token, key=key)
        claims = json.loads(verified_jwt.claims)
        self._validate_claims(claims)
        return claims


_verifier = JWTAuthVerifier()



def verify_jwt_token(token: str) -> dict[str, Any]:
    return _verifier.verify_token(token)



def get_jwt_user_id(claims: dict[str, Any]) -> Optional[str]:
    claim_name = _get_str_setting("API_AUTH_USER_ID_CLAIM", "domainID")
    fallback_claim_name = _get_str_setting("API_AUTH_FALLBACK_USER_ID_CLAIM", "sub")
    user_id = claims.get(claim_name) or claims.get(fallback_claim_name)
    if user_id is None:
        return None
    return str(user_id)
