import logging
import json
import uuid
from typing import Optional, Any, Callable, Dict
from decimal import Decimal
from datetime import datetime, date
from idiscovery_framework import RedisHandler
import config

logger = logging.getLogger(__name__)


class DecimalEncoder(json.JSONEncoder):
    """Custom JSON encoder to handle Decimal, datetime, and other database types."""
    
    def default(self, obj):
        if isinstance(obj, Decimal):
            # Convert Decimal to float for JSON serialization
            return float(obj)
        elif isinstance(obj, (datetime, date)):
            # Convert datetime/date to ISO format string
            return obj.isoformat()
        elif isinstance(obj, bytes):
            # Convert bytes to string
            return obj.decode('utf-8')
        # Let the base class handle other types
        return super().default(obj)


class CacheManager:
    """Redis cache manager for COB Dashboard Service."""
    
    _instance: Optional["CacheManager"] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(CacheManager, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self.enabled = config.REDIS_ENABLED
        self.redis_handler = None
        self._lock_tokens: Dict[str, str] = {}  # Track lock tokens for safe release
        
        if self.enabled:
            try:
                self.redis_handler = RedisHandler(
                    host=config.REDIS_HOST,
                    port=config.REDIS_PORT,
                    socket_connect_timeout=config.REDIS_SOCKET_CONNECT_TIMEOUT,
                    socket_keepalive=config.REDIS_SOCKET_KEEPALIVE,
                    max_connections=config.REDIS_MAX_CONNECTIONS,
                    retry_on_timeout=config.REDIS_RETRY_ON_TIMEOUT,
                )
                logger.info("Redis cache manager initialized")
            except Exception as e:
                logger.error(f"Failed to initialize Redis: {e}")
                self.enabled = False
        
        self._initialized = True
    
    async def connect(self):
        """Connect to Redis on startup."""
        if self.enabled and self.redis_handler:
            try:
                await self.redis_handler.connect()
                logger.info("Redis connected successfully")
            except Exception as e:
                logger.error(f"Redis connection failed: {e}")
                self.enabled = False
    
    async def disconnect(self):
        """Disconnect from Redis on shutdown."""
        if self.enabled and self.redis_handler:
            try:
                await self.redis_handler.disconnect()
                logger.info("Redis disconnected")
            except Exception as e:
                logger.error(f"Redis disconnect error: {e}")
    
    def build_key(self, prefix: str, **params) -> str:
        """Build cache key from prefix and parameters."""
        parts = [prefix]
        for key, value in sorted(params.items()):
            if value is not None:
                if isinstance(value, list):
                    value = ",".join(str(v) for v in value)
                parts.append(str(value))
        return ":".join(parts)
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        if not self.enabled:
            return None
        
        try:
            # Get raw string value (we manually serialize/deserialize)
            value = await self.redis_handler.get(key, parse_json=False)
            if value:
                # Manually deserialize JSON
                deserialized_value = json.loads(value)
                logger.debug(f"Cache hit: {key}")
                return deserialized_value
            return None
        except Exception as e:
            logger.error(f"Cache get error for key '{key}': {e}")
            return None
    
    async def set(self, key: str, value: Any, ttl: int):
        """Set value in cache with TTL (synchronous with verification)."""
        if not self.enabled:
            return
        
        try:
            # Serialize value with custom encoder to handle Decimal, datetime, etc.
            serialized_value = json.dumps(value, cls=DecimalEncoder)
            
            # Use synchronous set with error checking (not fire_and_forget)
            # Note: RedisHandler API uses 'expire=' parameter, not 'ex='
            await self.redis_handler.set(key, serialized_value)
            await self.redis_handler.expire(key, ttl)
            # Verify write succeeded by reading back
            verify = await self.redis_handler.exists(key)
            if not verify:
                logger.error(f"Cache write failed (key not found after set): {key}")
                raise RuntimeError(f"Failed to write cache key: {key}")
            
            logger.debug(f"Cache set: {key} (TTL: {ttl}s)")
            
        except Exception as e:
            logger.error(f"Cache set error for key '{key}': {e}")
            # Re-raise to let caller handle the failure
            raise
    
    async def get_or_fetch(self, key: str, fetch_func: Callable, ttl: int) -> Any:
        """Cache-aside pattern: get from cache or fetch and cache."""
        # Try cache first
        cached = await self.get(key)
        if cached is not None:
            return cached
        
        # Cache miss - fetch data
        logger.debug(f"Cache miss: {key}")
        data = await fetch_func()
        
        # Store in cache
        await self.set(key, data, ttl)
        
        return data
    
    async def delete(self, *keys: str):
        """Delete keys from cache."""
        if not self.enabled or not keys:
            return
        
        try:
            await self.redis_handler.delete(*keys)
            logger.debug(f"Cache deleted: {keys}")
        except Exception as e:
            logger.error(f"Cache delete error: {e}")
    
    async def invalidate_pattern(self, pattern: str):
        """Invalidate all keys matching pattern."""
        if not self.enabled:
            return
        
        try:
            keys = await self.redis_handler.keys(pattern)
            if keys:
                await self.redis_handler.delete(*keys)
                logger.info(f"Invalidated {len(keys)} keys matching '{pattern}'")
        except Exception as e:
            logger.error(f"Cache invalidate error: {e}")
    
    async def acquire_lock(self, key: str, ttl: int = 120) -> bool:
        """Acquire distributed lock with TTL using atomic SETNX operation.
        
        CRITICAL FIX: Uses atomic SET NX EX to prevent race conditions.
        Only ONE request can acquire the lock, even under high concurrency.
        
        Args:
            key: Lock key name
            ttl: Time-to-live in seconds (default 120s)
            
        Returns:
            True if lock acquired, False otherwise
        """
        if not self.enabled:
            return True  # No locking if cache disabled
        
        try:
            # Generate unique lock token for this acquisition
            lock_token = str(uuid.uuid4())
            
            # Check-and-set pattern for lock acquisition
            # Note: RedisHandler doesn't support SET NX EX, so we use exists + set + expire
            # This is slightly less atomic but works with the framework API
            exists = await self.redis_handler.exists(key)
            if exists:
                logger.debug(f"Lock already held by another process: {key}")
                return False
            
            # Set lock with token
            await self.redis_handler.set(key, lock_token)
            await self.redis_handler.expire(key, ttl)
            
            # Verify we got the lock (double-check)
            stored_token = await self.redis_handler.get(key, parse_json=False)
            if stored_token == lock_token:
                # Store token for verification during release
                self._lock_tokens[key] = lock_token
                logger.debug(f"Lock acquired: {key} (TTL: {ttl}s, token: {lock_token[:8]}...)")
                return True
            else:
                # Someone else got it between our exists check and set
                logger.debug(f"Lock race detected, another process won: {key}")
                return False
                
        except Exception as e:
            logger.error(f"Lock acquisition error for '{key}': {e}")
            return False
    
    async def release_lock(self, key: str) -> None:
        """Release distributed lock with ownership verification.
        
        CRITICAL FIX: Only releases lock if we own it (token match).
        Prevents accidentally releasing another process's lock.
        
        Args:
            key: Lock key name
        """
        if not self.enabled:
            return
        
        try:
            # Only release if we hold the lock (verify token)
            our_token = self._lock_tokens.get(key)
            
            if our_token:
                # Use Lua script for atomic check-and-delete
                # This ensures we only delete if the token matches
                lua_script = """
                if redis.call("get", KEYS[1]) == ARGV[1] then
                    return redis.call("del", KEYS[1])
                else
                    return 0
                end
                """
                
                # Execute Lua script atomically
                deleted = await self.redis_handler.eval(lua_script, keys=[key], args=[our_token])
                
                # Clean up token tracking
                del self._lock_tokens[key]
                
                if deleted:
                    logger.debug(f"Lock released: {key} (token verified)")
                else:
                    logger.warning(f"Lock release skipped - token mismatch: {key}")
            else:
                logger.warning(f"Lock release attempted but we don't own it: {key}")
                
        except Exception as e:
            logger.error(f"Lock release error for '{key}': {e}")
            # Clean up token even on error to avoid memory leak
            if key in self._lock_tokens:
                del self._lock_tokens[key]
    
    async def wait_for_lock_release(self, key: str, timeout: int = 60, poll_interval: float = 0.5) -> bool:
        """Wait for lock to be released with timeout.
        
        Args:
            key: Lock key name
            timeout: Maximum wait time in seconds
            poll_interval: Polling interval in seconds
            
        Returns:
            True if lock was released, False if timeout
        """
        if not self.enabled:
            return True
        
        import asyncio
        elapsed = 0
        
        try:
            while elapsed < timeout:
                # Check if lock exists
                exists = await self.redis_handler.exists(key)
                if not exists:
                    logger.debug(f"Lock released (waited {elapsed:.1f}s): {key}")
                    return True
                
                # Wait before next check
                await asyncio.sleep(poll_interval)
                elapsed += poll_interval
            
            logger.warning(f"Lock wait timeout after {timeout}s: {key}")
            return False
        except Exception as e:
            logger.error(f"Lock wait error for '{key}': {e}")
            return False
    
    async def get_many(self, keys: list) -> dict:
        """Bulk retrieve multiple cache keys.
        
        Args:
            keys: List of cache keys to retrieve
            
        Returns:
            Dictionary mapping keys to values (None for missing keys)
        """
        if not self.enabled or not keys:
            return {key: None for key in keys}
        
        try:
            # Use pipeline for efficient bulk retrieval
            results = {}
            for key in keys:
                value = await self.redis_handler.get(key, parse_json=True)
                results[key] = value
            
            hit_count = sum(1 for v in results.values() if v is not None)
            logger.debug(f"Bulk get: {hit_count}/{len(keys)} cache hits")
            return results
        except Exception as e:
            logger.error(f"Bulk get error: {e}")
            return {key: None for key in keys}
    
    async def set_many(self, items: dict, ttl: int) -> None:
        """Bulk set multiple cache keys with same TTL.
        
        Args:
            items: Dictionary mapping keys to values
            ttl: Time-to-live in seconds for all items
        """
        if not self.enabled or not items:
            return
        
        try:
            # Use fire_and_forget for each item
            for key, value in items.items():
                await self.redis_handler.fire_and_forget_set(key, value, expire=ttl)
            
            logger.debug(f"Bulk set: {len(items)} keys (TTL: {ttl}s)")
        except Exception as e:
            logger.error(f"Bulk set error: {e}")
    
    async def set_chunked(self, base_key: str, records: list, chunk_size: int, ttl: int, metadata: dict = None) -> None:
        """Store large dataset in chunks for efficient partial retrieval.
        
        Args:
            base_key: Base cache key (e.g., "session:abc123:work-items-drilldown")
            records: List of records to store
            chunk_size: Number of records per chunk (default: 1000)
            ttl: Time-to-live in seconds
            metadata: Optional metadata to store with chunks
        """
        if not self.enabled or not records:
            return
        
        try:
            total_records = len(records)
            total_chunks = (total_records + chunk_size - 1) // chunk_size  # Ceiling division
            
            # Store metadata
            chunk_metadata = {
                "total_records": total_records,
                "chunk_size": chunk_size,
                "total_chunks": total_chunks,
                **(metadata or {})
            }
            metadata_key = f"{base_key}:metadata"
            await self.redis_handler.fire_and_forget_set(metadata_key, chunk_metadata, expire=ttl)
            
            # Store chunks in parallel for better performance
            import asyncio
            
            async def store_chunk(chunk_idx: int):
                start_idx = chunk_idx * chunk_size
                end_idx = min(start_idx + chunk_size, total_records)
                chunk_data = records[start_idx:end_idx]
                chunk_key = f"{base_key}:chunk:{chunk_idx}"
                await self.redis_handler.fire_and_forget_set(chunk_key, chunk_data, expire=ttl)
            
            # Store all chunks concurrently (limited by Redis connection pool)
            await asyncio.gather(*[store_chunk(i) for i in range(total_chunks)])
            
            logger.info(f"Chunked storage: {total_records} records in {total_chunks} chunks (key: {base_key})")
        except Exception as e:
            logger.error(f"Chunked set error for '{base_key}': {e}")
    
    async def get_chunk_metadata(self, base_key: str) -> Optional[dict]:
        """Get metadata about chunked dataset.
        
        Args:
            base_key: Base cache key
            
        Returns:
            Metadata dict or None if not found
        """
        if not self.enabled:
            return None
        
        try:
            metadata_key = f"{base_key}:metadata"
            return await self.redis_handler.get(metadata_key, parse_json=True)
        except Exception as e:
            logger.error(f"Get chunk metadata error for '{base_key}': {e}")
            return None
    
    async def get_chunk(self, base_key: str, chunk_idx: int) -> Optional[list]:
        """Get specific chunk of data.
        
        Args:
            base_key: Base cache key
            chunk_idx: Chunk index (0-based)
            
        Returns:
            List of records in chunk or None if not found
        """
        if not self.enabled:
            return None
        
        try:
            chunk_key = f"{base_key}:chunk:{chunk_idx}"
            return await self.redis_handler.get(chunk_key, parse_json=True)
        except Exception as e:
            logger.error(f"Get chunk error for '{base_key}' chunk {chunk_idx}: {e}")
            return None
    
    async def get_chunks_for_page(self, base_key: str, page: int, page_size: int) -> Optional[dict]:
        """Get only the chunks needed for a specific page.
        
        Args:
            base_key: Base cache key
            page: Page number (1-based)
            page_size: Records per page
            
        Returns:
            Dict with records, total_records, and pagination info, or None if cache miss
        """
        if not self.enabled:
            return None
        
        try:
            # Get metadata first
            metadata = await self.get_chunk_metadata(base_key)
            if not metadata:
                return None
            
            total_records = metadata["total_records"]
            chunk_size = metadata["chunk_size"]
            
            # Calculate which chunks we need
            start_record = (page - 1) * page_size
            end_record = start_record + page_size
            
            if start_record >= total_records:
                # Page out of range
                return {
                    "records": [],
                    "total_records": total_records,
                    "metadata": metadata
                }
            
            start_chunk = start_record // chunk_size
            end_chunk = (min(end_record, total_records) - 1) // chunk_size
            
            # Calculate how many chunks we need to fetch
            chunks_needed = end_chunk - start_chunk + 1
            
            # Fetch chunks in parallel for better performance
            import asyncio
            if chunks_needed > 1:
                # Multiple chunks - fetch in parallel
                chunk_tasks = [self.get_chunk(base_key, idx) for idx in range(start_chunk, end_chunk + 1)]
                chunk_results = await asyncio.gather(*chunk_tasks)
                
                # Combine chunks
                all_records = []
                for chunk_data in chunk_results:
                    if chunk_data:
                        all_records.extend(chunk_data)
            else:
                # Single chunk - fetch directly
                chunk_data = await self.get_chunk(base_key, start_chunk)
                all_records = chunk_data if chunk_data else []
            
            # Slice to exact page boundaries
            offset_in_first_chunk = start_record % chunk_size
            records_to_take = min(page_size, total_records - start_record)
            paginated_records = all_records[offset_in_first_chunk:offset_in_first_chunk + records_to_take]
            
            logger.info(f"Page {page}: Retrieved {len(paginated_records)}/{page_size} records from {chunks_needed} chunk(s) [{start_chunk}-{end_chunk}] (total: {total_records})")
            
            return {
                "records": paginated_records,
                "total_records": total_records,
                "metadata": metadata
            }
        except Exception as e:
            logger.error(f"Get chunks for page error for '{base_key}': {e}")
            return None
    
    async def get_all_chunks(self, base_key: str) -> Optional[dict]:
        """Get all chunks (for Excel downloads).
        
        Args:
            base_key: Base cache key
            
        Returns:
            Dict with all records and metadata, or None if cache miss
        """
        if not self.enabled:
            return None
        
        try:
            # Get metadata
            metadata = await self.get_chunk_metadata(base_key)
            if not metadata:
                return None
            
            total_chunks = metadata["total_chunks"]
            
            # Fetch all chunks in parallel
            import asyncio
            tasks = [self.get_chunk(base_key, i) for i in range(total_chunks)]
            chunks = await asyncio.gather(*tasks)
            
            # Combine all chunks
            all_records = []
            for chunk in chunks:
                if chunk:
                    all_records.extend(chunk)
            
            logger.info(f"Retrieved all {len(all_records)} records from {total_chunks} chunks")
            
            return {
                "records": all_records,
                "total_records": metadata["total_records"],
                "metadata": metadata
            }
        except Exception as e:
            logger.error(f"Get all chunks error for '{base_key}': {e}")
            return None


# Singleton instance
cache_manager = CacheManager()
