# Manual API Testing Guide - Rebuttal Drilldown Fixes

## Pre-requisites

1. **Start the server** (in a separate terminal):
   ```bash
   cd /Users/AH64226/Downloads/idiscovery-cob-dashboard-service
   poetry run python src/idiscovery-cob-dashboard-service.py
   ```

2. **Wait for server to start** - Look for:
   ```
   INFO:     Application startup complete.
   INFO:     Uvicorn running on http://0.0.0.0:8000
   ```

3. **In another terminal, run the test script**:
   ```bash
   python tests/test_rebuttal_endpoints.py
   ```

---

## Alternative: Manual cURL Testing

If you prefer to test manually with cURL, use these commands:

### 1. Test Quality Outcomes (Get Rebuttal Count)

```bash
curl -X POST "http://localhost:8000/api/v1/manager/quality-outcomes" \
  -H "Content-Type: application/json" \
  -d '{
    "start_date": "2026-01-17",
    "end_date": "2026-04-17",
    "lob": [],
    "associate_id": []
  }' | jq '.'
```

**Expected:** Should return `rebuttal_count` field

---

### 2. Test Rebuttal Drilldown (First Page)

```bash
curl -X POST "http://localhost:8000/api/v1/manager/rebuttal-drilldown" \
  -H "Content-Type: application/json" \
  -d '{
    "start_date": "2026-01-17",
    "end_date": "2026-04-17",
    "lob": [],
    "associate_id": [],
    "page_limit": 50,
    "page_number": 1
  }' | jq '.'
```

**Expected:** 
- `total_records` should match `rebuttal_count` from quality-outcomes
- `records` array contains data
- Each record should have `domain_id` field (auditor name)

---

### 3. Test Excel Download

```bash
curl -X POST "http://localhost:8000/api/v1/manager/rebuttal-drilldown/excel" \
  -H "Content-Type: application/json" \
  -d '{
    "start_date": "2026-01-17",
    "end_date": "2026-04-17",
    "lob": [],
    "associate_id": []
  }' --output rebuttal_test.xlsx
```

**Expected:** Downloads `rebuttal_test.xlsx` file

---

### 4. Test with LOB Filter

```bash
curl -X POST "http://localhost:8000/api/v1/manager/rebuttal-drilldown" \
  -H "Content-Type: application/json" \
  -d '{
    "start_date": "2026-01-17",
    "end_date": "2026-04-17",
    "lob": ["Commercial"],
    "associate_id": [],
    "page_limit": 25,
    "page_number": 1
  }' | jq '.'
```

---

## Quick Validation Checklist

After running the tests, verify:

- [ ] **Count Alignment:** Quality outcomes `rebuttal_count` = Drilldown `total_records`
- [ ] **No Non-Audit Records:** All `work_item_id` values start with "AUD-"
- [ ] **Multiple Error Combos:** If an audit has multiple errors, drilldown shows multiple rows
- [ ] **Auditor Name:** Records show auditor name in `domain_id` field
- [ ] **Pagination:** Different pages return different records
- [ ] **LOB Filter:** Commercial filter reduces record count appropriately
- [ ] **Excel Download:** File downloads successfully and contains data

---

## Expected Results (Based on Validation)

For 90-day window (2026-01-17 to 2026-04-17):

| Metric | Expected Value |
|--------|----------------|
| Quality Outcomes `rebuttal_count` | 383 |
| Drilldown `total_records` | 383 |
| Unique Audit Cases | 246 |
| Non-Audit Records | 0 |
| Commercial LOB Count | 285 |
| Medicare LOB Count | 4 |
| Medicaid LOB Count | 94 |

---

## Troubleshooting

### Server not starting - "Address already in use"

```bash
# Find process using port 8000
lsof -ti:8000

# Kill the process (if found)
kill -9 <PID>

# Or kill all on port 8000
lsof -ti:8000 | xargs kill -9

# Then restart server
poetry run python src/idiscovery-cob-dashboard-service.py
```

### Connection refused

- Verify server is running: `ps aux | grep idiscovery`
- Check logs for startup errors
- Verify port 8000 is not blocked by firewall

### Authentication errors

- Check if API requires authentication headers
- Add bearer token if needed:
  ```bash
  -H "Authorization: Bearer YOUR_TOKEN"
  ```

---

## Success Criteria

✅ **All tests pass if:**

1. Quality outcomes returns data with `rebuttal_count`
2. Drilldown `total_records` matches `rebuttal_count`
3. No error responses (200 status code)
4. Records contain proper field names (`domain_id` not `associate_name`)
5. Excel downloads successfully
6. LOB and date filters work correctly

---

## Automated Test Script

Once server is running, the automated script will test:

1. ✅ Quality Outcomes API
2. ✅ Rebuttal Drilldown - First Page
3. ✅ Rebuttal Drilldown - Pagination (Page 2)
4. ✅ Rebuttal Drilldown - LOB Filter
5. ✅ Rebuttal Drilldown - Date Range
6. ✅ Excel Download - Full Dataset
7. ✅ Excel Download - LOB Filter

Run with:
```bash
python tests/test_rebuttal_endpoints.py
```

---

## Next Steps After Testing

1. **If all tests pass:**
   - ✅ Mark as tested and ready for QA
   - Create pull request
   - Update documentation

2. **If tests fail:**
   - Check error messages
   - Verify database connection
   - Review SQL fixes in code
   - Check server logs

---

## Contact

**Questions or Issues?**
- Check server logs: Look for errors in terminal output
- Verify database credentials: Check `.env` file
- Test SQL directly: Run validation scripts in `/tests/validate_*.py`
