# Director API Test Suite

Comprehensive test suite for Performance IQ Director APIs.

## 📋 Test File

### `test_director_apis.py`
**Complete test suite covering all Director APIs (52 tests)**
- Core Director KPIs and Metrics (8 tests)
- Hierarchy & List APIs (7 tests)  
- Fixed Drilldown Endpoints (2 tests) - Recently fixed manager/associate filters
- Already Working Drilldown Endpoints (5 tests)
- Manager Filtering Scenarios (3 tests)
- Associate Filtering Scenarios (3 tests)
- Pagination Tests (4 tests)
- Different Directors/LOBs (6 tests)
- Additional Drilldown APIs (6 tests)
- Error Handling & Edge Cases (4 tests)
- Performance Scenarios (4 tests)

## 🚀 Quick Start

### Running Tests 

```bash
# Run the comprehensive test suite
poetry run python tests/test_director_apis.py
```

## 📊 Test Coverage

### Core Director APIs (6 endpoints)
- `/director/header-kpis`
- `/director/demand-inventory` 
- `/director/operational-flow`
- `/director/associate-utilization`
- `/director/quality-outcomes`
- `/director/sla-health`

### Director Drilldown APIs (13 endpoints)
- `/director/escalation-count-drilldown`
- `/director/rebuttal-drilldown` 
- `/director/production-pct-achieved-drilldown`
- `/director/pended-items-drilldown`
- `/director/work-items-director-drilldown`
- `/director/fuse-time-director-drilldown`
- `/director/audit-score-director-drilldown`
- `/director/audit-sample-pct-drilldown`
- `/director/capacity-insight-drilldown`
- `/director/completed-ata-counts-drilldown`
- `/director/rework-pct-drilldown`
- `/director/sla-health-drilldown`
- `/director/watchlist-drilldown`

### Hierarchy & List APIs (3 endpoints)
- `/director/directors-list`
- `/director/managers-list`
- `/director/associates-list`

### AI Coach API (1 endpoint)
- `/director/ai-coach`

## 🧪 Test Scenarios

- **Basic Configuration**: Proven working directors, managers, associates
- **Filter Variations**: No filters, multiple LOBs, multiple managers/associates
- **Pagination**: Different page sizes (5, 10, 20, 50)
- **Date Ranges**: 7 days (optimal), 30 days, 1 year
- **Error Handling**: Invalid users, future dates, minimal payloads
- **Performance**: All LOBs, multiple managers/associates, long date ranges

## 📈 Test Data

Uses proven working configuration from comprehensive testing:

```python
WORKING_DIRECTORS = ["AA10203", "AA17007", "AA36671", "AB01839", "AB26472"]
WORKING_MANAGERS = ["LYKINDN", "AE08708", "AH45556", "AE09148", "CHAPPLD"]
WORKING_LOBS = ["Commercial", "Medicare", "Medicaid"]
```

## 🔧 Recent Fixes Validated

The test suite validates recent manager/associate filtering fixes:
- **rebuttal_drilldown.py** - Added missing filters to SQL queries
- **escalation_count_drilldown.py** - Added missing filters to SQL queries

## 📊 Expected Results

- **Status Code**: 200 (no 422 validation errors)
- **Success Rate**: > 80% for working configurations  
- **Response Structure**: Valid JSON with required fields
- **Data Presence**: Records found with proven working configuration

## 🚨 Troubleshooting

### Server Not Available
```bash
poetry run python src/idiscovery-cob-dashboard-service.py
```

### No Data Returned
- Use proven working configuration (7-day date range)
- Verify user IDs exist in database
- Check manager/associate relationships

