import io
import logging
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

framework_module = types.ModuleType("idiscovery_framework")


class _DummyRedisHandler:
    def __init__(self, *args, **kwargs):
        pass


framework_module.RedisHandler = _DummyRedisHandler
sys.modules.setdefault("idiscovery_framework", framework_module)

from utils.api_logger import dedupe_stream_handlers, dedupe_runtime_loggers, setup_json_logging, _extract_api_group


class ApiLoggerTests(unittest.TestCase):
    def test_setup_json_logging_disables_propagation(self):
        logger = setup_json_logging("test.api.logger")

        self.assertFalse(logger.propagate)
        self.assertEqual(len(logger.handlers), 1)

    def test_dedupe_stream_handlers_removes_duplicate_stream_handlers(self):
        logger = logging.getLogger("test.duplicate.logger")
        logger.handlers.clear()
        logger.propagate = True

        stream = io.StringIO()
        first = logging.StreamHandler(stream)
        second = logging.StreamHandler(stream)
        logger.addHandler(first)
        logger.addHandler(second)

        removed = dedupe_stream_handlers(logger)

        self.assertEqual(removed, 1)
        self.assertEqual(len(logger.handlers), 1)

    def test_dedupe_stream_handlers_removes_duplicates_with_different_formatters(self):
        logger = logging.getLogger("test.duplicate.formatter.logger")
        logger.handlers.clear()
        logger.propagate = True

        stream = io.StringIO()
        first = logging.StreamHandler(stream)
        second = logging.StreamHandler(stream)
        first.setFormatter(logging.Formatter("%(message)s"))
        second.setFormatter(logging.Formatter("%(levelname)s:%(message)s"))
        logger.addHandler(first)
        logger.addHandler(second)

        removed = dedupe_stream_handlers(logger)

        self.assertEqual(removed, 1)
        self.assertEqual(len(logger.handlers), 1)

    def test_dedupe_runtime_loggers_removes_duplicates_from_named_loggers(self):
        logger = logging.getLogger("test.runtime.logger")
        logger.handlers.clear()

        stream = io.StringIO()
        logger.addHandler(logging.StreamHandler(stream))
        logger.addHandler(logging.StreamHandler(stream))

        removed = dedupe_runtime_loggers(["test.runtime.logger"])

        self.assertEqual(removed, 1)
        self.assertEqual(len(logger.handlers), 1)

    def test_extract_api_group_classifies_workforce_path(self):
        self.assertEqual(_extract_api_group("/workforce-iq/ai-coach"), "WorkForce_IQ")
        self.assertEqual(_extract_api_group("/manager/header-kpis"), "Performance_IQ_Manager")
        self.assertEqual(_extract_api_group("/auditor-manager/header-kpis"), "Performance_IQ_Auditor_Manager")


if __name__ == "__main__":
    unittest.main()
