#!/bin/bash

# Quick test for comprehensive warming with a single session

BASE_URL="http://localhost:8001"
USER_ID="AB77504"
START_DATE="2026-03-01"
END_DATE="2026-03-25"

echo "=========================================="
echo "QUICK COMPREHENSIVE WARMING TEST"
echo "=========================================="
echo ""

# Test 1: Trigger warming
echo "1. Calling header-kpis..."
RESPONSE=$(curl -s -X POST "$BASE_URL/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["Commercial"]
  }')

SESSION_ID=$(echo "$RESPONSE" | jq -r '.cache_metadata.session_id // .session_id // empty')
WORK_ITEMS=$(echo "$RESPONSE" | jq -r '.work_items_completed // "N/A"')

if [ -z "$SESSION_ID" ]; then
    echo "❌ FAIL: No session ID"
    exit 1
fi

echo "✅ Session ID: $SESSION_ID"
echo "✅ Work items: $WORK_ITEMS"
echo ""

# Wait for warming
echo "2. Waiting 95 seconds for warming..."
sleep 95
echo ""

# Test 2: Verify all APIs cached
echo "3. Checking cache status..."
RESPONSE=$(curl -s -X POST "$BASE_URL/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["Commercial"],
    "session_id": "'"$SESSION_ID"'"
  }')

APIS_CACHED=$(echo "$RESPONSE" | jq -r '.cache_metadata.apis_cached | length')
CACHE_HIT=$(echo "$RESPONSE" | jq -r '.cache_metadata.cache_hit')

echo "APIs cached: $APIS_CACHED"
echo "Cache hit: $CACHE_HIT"

if [ "$APIS_CACHED" -ge 20 ]; then
    echo "✅ PASS: $APIS_CACHED APIs cached"
else
    echo "❌ FAIL: Only $APIS_CACHED APIs cached"
fi

echo ""

# Test 3: Test pended items (the one with the bug fix)
echo "4. Testing pended-items-drilldown..."
PENDED_RESPONSE=$(curl -s -X POST "$BASE_URL/director/pended-items-drilldown" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["Commercial"],
    "session_id": "'"$SESSION_ID"'",
    "page": 1,
    "page_size": 10
  }')

PENDED_STATUS=$(echo "$PENDED_RESPONSE" | jq -r '.status')
PENDED_TOTAL=$(echo "$PENDED_RESPONSE" | jq -r '.page.total_records // 0')

if [ "$PENDED_STATUS" == "success" ]; then
    echo "✅ PASS: Pended items working (Total: $PENDED_TOTAL)"
else
    echo "❌ FAIL: Pended items error"
    echo "$PENDED_RESPONSE" | jq '.'
fi

echo ""
echo "=========================================="
echo "TEST COMPLETE"
echo "=========================================="
