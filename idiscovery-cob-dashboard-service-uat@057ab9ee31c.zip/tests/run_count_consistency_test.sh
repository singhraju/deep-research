#!/bin/bash

# Run Count Consistency Test
# This script tests whether counts match between dashboard and drilldown APIs

echo "======================================================================"
echo "         Count Consistency Test for COB Dashboard Service            "
echo "======================================================================"
echo ""

# Check if server is running
echo "Checking if server is running on localhost:8000..."
if curl -s http://localhost:8000/docs > /dev/null 2>&1; then
    echo "✅ Server is running"
else
    echo "❌ Server is not running on localhost:8000"
    echo ""
    echo "Please start the server first:"
    echo "  poetry run uvicorn src.idiscovery-cob-dashboard-service:app --reload"
    echo ""
    exit 1
fi

echo ""
echo "Running count consistency tests..."
echo ""

# Run the Python test script
cd "$(dirname "$0")/.." || exit
python3 tests/test_count_consistency.py

# Capture exit code
EXIT_CODE=$?

echo ""
if [ $EXIT_CODE -eq 0 ]; then
    echo "======================================================================"
    echo "                     ✅ ALL TESTS PASSED                              "
    echo "======================================================================"
else
    echo "======================================================================"
    echo "                     ❌ SOME TESTS FAILED                             "
    echo "======================================================================"
    echo ""
    echo "Please review the test output above for details."
fi

exit $EXIT_CODE
