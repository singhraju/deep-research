#!/bin/bash

# Test All AI Coach Endpoints - After Bug Fixes (2026-04-15)
# This script tests all 5 AI Coach endpoints to verify fixes

BASE_URL="http://localhost:8001"
TIMESTAMP=$(date +%Y-%m-%d)

echo "=========================================="
echo "AI Coach Endpoints Test Suite"
echo "Testing all 5 endpoints after bug fixes"
echo "Time: $(date)"
echo "=========================================="
echo ""

# Color codes for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counter
TOTAL_TESTS=5
PASSED=0
FAILED=0

# Function to test an endpoint
test_endpoint() {
    local endpoint=$1
    local payload=$2
    local test_name=$3
    
    echo -e "${YELLOW}Testing: $test_name${NC}"
    echo "Endpoint: POST $endpoint"
    
    # Make the request and capture response
    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL$endpoint" \
        -H "Content-Type: application/json" \
        -d "$payload")
    
    # Extract HTTP status code (last line)
    http_code=$(echo "$response" | tail -n1)
    # Extract JSON response (all but last line)
    json_response=$(echo "$response" | sed '$d')
    
    # Check if request was successful
    if [ "$http_code" -eq 200 ]; then
        # Check if response contains expected fields (performance_summary OR message_text for FL Auditor)
        if echo "$json_response" | jq -e '.performance_summary' > /dev/null 2>&1; then
            status=$(echo "$json_response" | jq -r '.status')
            summary=$(echo "$json_response" | jq -r '.performance_summary' | head -c 100)
            
            if [ "$status" = "success" ]; then
                echo -e "${GREEN}✅ PASS${NC} - HTTP $http_code - Status: $status"
                echo "   Summary preview: ${summary}..."
                ((PASSED++))
            else
                echo -e "${YELLOW}⚠️  PARTIAL${NC} - HTTP $http_code - Status: $status"
                echo "   Summary: ${summary}..."
                ((PASSED++))
            fi
        elif echo "$json_response" | jq -e '.message_text' > /dev/null 2>&1; then
            # FL Auditor uses message_text instead of performance_summary
            status=$(echo "$json_response" | jq -r '.status')
            summary=$(echo "$json_response" | jq -r '.message_text' | head -c 100)
            
            if [ "$status" = "success" ]; then
                echo -e "${GREEN}✅ PASS${NC} - HTTP $http_code - Status: $status"
                echo "   Summary preview: ${summary}..."
                ((PASSED++))
            else
                echo -e "${YELLOW}⚠️  PARTIAL${NC} - HTTP $http_code - Status: $status"
                echo "   Summary: ${summary}..."
                ((PASSED++))
            fi
        else
            echo -e "${RED}❌ FAIL${NC} - HTTP $http_code - Invalid response format"
            echo "   Response: $json_response"
            ((FAILED++))
        fi
    else
        echo -e "${RED}❌ FAIL${NC} - HTTP $http_code"
        echo "   Error: $json_response"
        ((FAILED++))
    fi
    
    echo ""
}

# Test 1: Frontline AI Coach
echo "=========================================="
echo "Test 1/5: Frontline AI Coach"
echo "=========================================="
test_endpoint "/ai-coach" '{
  "user_id": "AA99826",
  "start_date": "2025-02-01",
  "end_date": "2026-02-07",
  "lob": ["Commercial"]
}' "Frontline AI Coach"

# Test 2: Director AI Coach
echo "=========================================="
echo "Test 2/5: Director AI Coach"
echo "=========================================="
test_endpoint "/director/ai-coach" '{
  "user_id": "AB12345",
  "start_date": "2025-02-01",
  "end_date": "2026-02-07",
  "director_id": ["AB12345"],
  "lob": ["Commercial"]
}' "Director AI Coach"

# Test 3: Manager AI Coach
echo "=========================================="
echo "Test 3/5: Manager AI Coach"
echo "=========================================="
test_endpoint "/manager/ai-coach" '{
  "user_id": ["AC98765"],
  "start_date": "2025-02-01",
  "end_date": "2026-02-07",
  "manager_ids": ["AC98765"],
  "lob": ["Commercial"]
}' "Manager AI Coach"

# Test 4: FL Auditor AI Coach
echo "=========================================="
echo "Test 4/5: FL Auditor AI Coach"
echo "=========================================="
test_endpoint "/fl-auditor/ai-coach" '{
  "user_id": "AF18133",
  "start_date": "2025-02-01",
  "end_date": "2026-02-07",
  "lob": ["Commercial"]
}' "FL Auditor AI Coach"

# Test 5: Auditor Manager AI Coach
echo "=========================================="
echo "Test 5/5: Auditor Manager AI Coach"
echo "=========================================="
test_endpoint "/auditor-manager/ai-coach" '{
  "user_id": "AM12345",
  "start_date": "2025-02-01",
  "end_date": "2026-02-07",
  "lob": ["Commercial"]
}' "Auditor Manager AI Coach"

# Summary
echo "=========================================="
echo "TEST SUMMARY"
echo "=========================================="
echo "Total Tests: $TOTAL_TESTS"
echo -e "Passed: ${GREEN}$PASSED${NC}"
echo -e "Failed: ${RED}$FAILED${NC}"

if [ $FAILED -eq 0 ]; then
    echo -e "\n${GREEN}🎉 ALL TESTS PASSED!${NC}"
    exit 0
else
    echo -e "\n${RED}❌ SOME TESTS FAILED${NC}"
    exit 1
fi
