"""
Comprehensive test for all Performance IQ Director APIs with session_id parameter.
Tests cache warming and cache hits across all APIs.
"""

import os
import requests
import time
import json
import hashlib
from io import BytesIO

from openpyxl import load_workbook

LOCAL_BASE_URL = os.environ.get("DIRECTOR_TEST_LOCAL_BASE_URL", "http://0.0.0.0:8001")
REMOTE_BASE_URL = os.environ.get(
    "DIRECTOR_TEST_REMOTE_BASE_URL",
    "http://idiscovery-cob-dashboard-service.idiscovery-dev.idiscovery-istio-ingress.slvr-dig-sharedservdigital2.awsdns.internal.das",
)
TIMEOUT = int(os.environ.get("DIRECTOR_TEST_TIMEOUT", "180"))
MODE = os.environ.get("DIRECTOR_TEST_MODE", "compare").strip().lower()
PAYLOAD_FILE = os.environ.get("DIRECTOR_TEST_PAYLOAD_FILE", "tests/director_test_payload.json")
NUMERIC_TOLERANCE = float(os.environ.get("DIRECTOR_TEST_NUMERIC_TOLERANCE", "0"))
INCLUDE_EXCEL = os.environ.get("DIRECTOR_TEST_INCLUDE_EXCEL", "1").strip() in {"1", "true", "yes"}
EXCEL_MAX_ROWS = int(os.environ.get("DIRECTOR_TEST_EXCEL_MAX_ROWS", "0"))
EXCEL_MAX_COLS = int(os.environ.get("DIRECTOR_TEST_EXCEL_MAX_COLS", "0"))
ONLY_PATHS = {
    p.strip()
    for p in os.environ.get("DIRECTOR_TEST_ONLY_PATHS", "").split(",")
    if p.strip()
}
SESSION_ID_OVERRIDE = os.environ.get("DIRECTOR_TEST_SESSION_ID")
FRESH_SESSION = os.environ.get("DIRECTOR_TEST_FRESH_SESSION", "0").strip() in {"1", "true", "yes"}


def _is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _json_load_payload() -> dict:
    payload_json = os.environ.get("DIRECTOR_TEST_PAYLOAD_JSON")
    if payload_json:
        payload = json.loads(payload_json)
        if not isinstance(payload, dict):
            raise ValueError("DIRECTOR_TEST_PAYLOAD_JSON must be a JSON object")
        return payload
    with open(PAYLOAD_FILE, "r", encoding="utf-8") as f:
        payload = json.load(f)
        if not isinstance(payload, dict):
            raise ValueError(f"Payload file {PAYLOAD_FILE} must contain a JSON object")
        return payload


def _apply_session_overrides(payload: dict) -> dict:
    updated = dict(payload)
    if SESSION_ID_OVERRIDE:
        updated["session_id"] = SESSION_ID_OVERRIDE
    elif FRESH_SESSION:
        updated["session_id"] = f"compare_{int(time.time())}"
    return updated


def _get_openapi(base_url: str) -> dict:
    url = f"{base_url.rstrip('/')}/openapi.json"
    resp = requests.get(url, timeout=TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def _is_excel_path(path: str) -> bool:
    return "/download-excel" in path


def _should_include_director_endpoint(path: str, method: str, spec: dict) -> bool:
    if not path.startswith("/director"):
        return False
    if method not in {"get", "post"}:
        return False
    tags = spec.get("tags")
    if isinstance(tags, list) and "Performance_IQ_Director" not in tags:
        return False
    if _is_excel_path(path):
        return INCLUDE_EXCEL
    if any(token in path for token in ("csv",)):
        return False
    return True


def _list_director_endpoints(openapi: dict) -> list[dict]:
    endpoints: list[dict] = []
    paths = openapi.get("paths", {}) if isinstance(openapi, dict) else {}
    for path, methods in paths.items():
        if not isinstance(path, str):
            continue
        if not isinstance(methods, dict):
            continue
        for method, spec in methods.items():
            if not isinstance(spec, dict):
                continue
            if not _should_include_director_endpoint(path, method, spec):
                continue
            endpoints.append(
                {
                    "method": method,
                    "path": path,
                    "name": spec.get("operationId") or f"{method.upper()} {path}",
                }
            )
    endpoints.sort(key=lambda e: (e["path"], e["method"]))
    return endpoints


def _build_payload_for_endpoint(endpoint: dict, base_payload: dict) -> dict:
    path = endpoint.get("path", "")
    payload = dict(base_payload)

    if _is_excel_path(path):
        payload.pop("page", None)
        payload.pop("page_size", None)
        payload.pop("frontline_associate_id", None)
        return payload

    if "page" not in payload:
        payload["page"] = 1
    if "page_size" not in payload:
        payload["page_size"] = 20

    if path.endswith("/managers-list") and "directors" not in payload:
        payload["directors"] = base_payload.get("director_ids") or []

    if path.endswith("/user-activity"):
        if "frontline_associate_id" not in payload:
            associates = base_payload.get("frontline_associate_ids") or []
            payload["frontline_associate_id"] = associates[0] if associates else None

    return payload


_IGNORE_KEYS = {
    "cache_metadata",
    "request_id",
    "generated_at",
    "cached_at",
    "expires_at",
    "cache_hit",
    "cache_warming",
}


def _sort_list_if_possible(items: list):
    if not items:
        return items
    if all(isinstance(x, (str, int, float, bool, type(None))) for x in items):
        return sorted(items, key=lambda v: "" if v is None else str(v))
    if all(isinstance(x, dict) for x in items):
        candidate_keys = [
            "id",
            "PYID",
            "pyid",
            "status",
            "priority",
            "user_id",
            "userid",
            "associate_id",
            "manager_id",
            "director_id",
            "date",
            "resolved_date",
            "LOGINDATE",
            "logindate",
        ]
        for k in candidate_keys:
            if all(k in x for x in items):
                return sorted(items, key=lambda d: "" if d.get(k) is None else str(d.get(k)))
    return items


def _normalize(obj):
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if k in _IGNORE_KEYS:
                continue
            out[k] = _normalize(v)
        return out
    if isinstance(obj, list):
        normalized = [_normalize(x) for x in obj]
        return _sort_list_if_possible(normalized)
    return obj


def _compare_numbers(a, b, path: str):
    if _is_number(a) and _is_number(b) and NUMERIC_TOLERANCE > 0:
        if abs(float(a) - float(b)) <= NUMERIC_TOLERANCE:
            return True, None
        return False, f"{path}: {a} != {b} (tolerance={NUMERIC_TOLERANCE})"
    return None, None


def _compare_dicts(a: dict, b: dict, path: str):
    a_keys = set(a.keys())
    b_keys = set(b.keys())
    if a_keys != b_keys:
        return False, f"{path}: keys differ (only_in_a={sorted(a_keys - b_keys)}, only_in_b={sorted(b_keys - a_keys)})"
    for k in sorted(a_keys):
        ok, err = _deep_compare(a[k], b[k], f"{path}.{k}")
        if not ok:
            return ok, err
    return True, None


def _compare_lists(a: list, b: list, path: str):
    if len(a) != len(b):
        return False, f"{path}: list length {len(a)} != {len(b)}"
    for i, (av, bv) in enumerate(zip(a, b)):
        ok, err = _deep_compare(av, bv, f"{path}[{i}]")
        if not ok:
            return ok, err
    return True, None


def _deep_compare(a, b, path: str = "$"):
    ok, err = _compare_numbers(a, b, path)
    if ok is not None:
        return ok, err

    if type(a) != type(b):
        return False, f"{path}: type {type(a).__name__} != {type(b).__name__}"

    if isinstance(a, dict):
        return _compare_dicts(a, b, path)

    if isinstance(a, list):
        return _compare_lists(a, b, path)

    if a != b:
        return False, f"{path}: {a!r} != {b!r}"
    return True, None


def _truncate_excel_limits(row_idx: int, col_idx: int) -> bool:
    if EXCEL_MAX_ROWS > 0 and row_idx > EXCEL_MAX_ROWS:
        return True
    if EXCEL_MAX_COLS > 0 and col_idx > EXCEL_MAX_COLS:
        return True
    return False


def _excel_signature(xlsx_bytes: bytes):
    wb = load_workbook(BytesIO(xlsx_bytes), read_only=True, data_only=True)
    sig = {"sheets": [], "hash": "", "rows": {}}

    h = hashlib.sha256()
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        sig["sheets"].append(sheet_name)

        max_row_seen = 0
        max_col_seen = 0
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
            if EXCEL_MAX_ROWS > 0 and row_idx > EXCEL_MAX_ROWS:
                break
            max_row_seen = row_idx
            for col_idx, cell_value in enumerate(row, start=1):
                if EXCEL_MAX_COLS > 0 and col_idx > EXCEL_MAX_COLS:
                    break
                max_col_seen = max(max_col_seen, col_idx)
                normalized = "" if cell_value is None else str(cell_value)
                h.update(normalized.encode("utf-8"))
                h.update(b"\x1f")
            h.update(b"\x1e")

        sig["rows"][sheet_name] = {"rows": max_row_seen, "cols": max_col_seen}
        h.update(b"\x1d")

    sig["hash"] = h.hexdigest()
    wb.close()
    return sig


def _compare_excel(local_bytes: bytes, remote_bytes: bytes):
    local_sig = _excel_signature(local_bytes)
    remote_sig = _excel_signature(remote_bytes)
    if local_sig["sheets"] != remote_sig["sheets"]:
        return False, f"sheets differ (local={local_sig['sheets']}, remote={remote_sig['sheets']})"
    if local_sig["hash"] != remote_sig["hash"]:
        return False, f"excel content hash differs (local={local_sig['hash']}, remote={remote_sig['hash']})"
    return True, None


def _request_excel(base_url: str, endpoint: dict, payload: dict):
    method = endpoint["method"]
    path = endpoint["path"]
    url = f"{base_url.rstrip('/')}{path}"
    start = time.time()
    if method == "post":
        resp = requests.post(url, json=payload, timeout=TIMEOUT)
    else:
        resp = requests.get(url, params=payload, timeout=TIMEOUT)
    duration_ms = int((time.time() - start) * 1000)
    if resp.status_code != 200:
        return {
            "ok": False,
            "status": resp.status_code,
            "duration_ms": duration_ms,
            "error": resp.text[:200],
        }
    return {
        "ok": True,
        "status": resp.status_code,
        "duration_ms": duration_ms,
        "bytes": resp.content,
        "content_type": resp.headers.get("content-type", ""),
    }


def _request_json(base_url: str, endpoint: dict, payload: dict):
    method = endpoint["method"]
    path = endpoint["path"]
    url = f"{base_url.rstrip('/')}{path}"
    start = time.time()

    if method == "post":
        resp = requests.post(url, json=payload, timeout=TIMEOUT)
    else:
        resp = requests.get(url, params=payload, timeout=TIMEOUT)

    duration_ms = int((time.time() - start) * 1000)
    content_type = resp.headers.get("content-type", "")
    if "application/json" not in content_type.lower():
        return {
            "ok": False,
            "status": resp.status_code,
            "duration_ms": duration_ms,
            "error": f"Non-JSON response content-type={content_type}",
            "raw": resp.text[:200],
        }

    try:
        data = resp.json()
    except Exception as e:
        return {
            "ok": False,
            "status": resp.status_code,
            "duration_ms": duration_ms,
            "error": f"JSON decode error: {type(e).__name__}: {str(e)}",
            "raw": resp.text[:200],
        }

    if resp.status_code != 200:
        return {
            "ok": False,
            "status": resp.status_code,
            "duration_ms": duration_ms,
            "error": data,
        }

    return {
        "ok": True,
        "status": resp.status_code,
        "duration_ms": duration_ms,
        "data": data,
    }

def main():
    print("=" * 80)
    print("Testing Performance IQ Director APIs")
    print(f"Mode: {MODE}")
    print(f"Local Base URL: {LOCAL_BASE_URL}")
    print(f"Remote Base URL: {REMOTE_BASE_URL}")
    print(f"Timeout: {TIMEOUT}s")
    print(f"Payload file: {PAYLOAD_FILE}")
    print(f"Include Excel: {INCLUDE_EXCEL}")
    print("=" * 80)

    base_payload = _apply_session_overrides(_json_load_payload())

    if MODE != "compare":
        raise ValueError(f"Unsupported DIRECTOR_TEST_MODE={MODE!r}. Use 'compare'.")

    local_openapi = _get_openapi(LOCAL_BASE_URL)
    remote_openapi = _get_openapi(REMOTE_BASE_URL)

    local_endpoints = _list_director_endpoints(local_openapi)
    remote_endpoints = _list_director_endpoints(remote_openapi)

    local_set = {(e["method"], e["path"]) for e in local_endpoints}
    remote_set = {(e["method"], e["path"]) for e in remote_endpoints}
    common = sorted(local_set & remote_set, key=lambda x: (x[1], x[0]))
    if ONLY_PATHS:
        common = [c for c in common if c[1] in ONLY_PATHS]

    if not common:
        raise RuntimeError("No common /director endpoints found between local and remote openapi specs")

    print(f"Common Director endpoints: {len(common)}")

    matched = 0
    mismatched = 0
    failed = 0
    skipped = 0
    excel_matched = 0
    excel_mismatched = 0
    excel_failed = 0

    for method, path in common:
        endpoint = {"method": method, "path": path, "name": f"{method.upper()} {path}"}
        payload = _build_payload_for_endpoint(endpoint, base_payload)

        print(f"\n{endpoint['name']}")
        if _is_excel_path(path):
            local_resp = _request_excel(LOCAL_BASE_URL, endpoint, payload)
            remote_resp = _request_excel(REMOTE_BASE_URL, endpoint, payload)

            print(f"  Local:  status={local_resp.get('status')} duration={local_resp.get('duration_ms')}ms")
            print(f"  Remote: status={remote_resp.get('status')} duration={remote_resp.get('duration_ms')}ms")

            if not local_resp.get("ok") or not remote_resp.get("ok"):
                excel_failed += 1
                print(f"  FAIL: {local_resp.get('error')} | {remote_resp.get('error')}")
                continue

            ok, err = _compare_excel(local_resp["bytes"], remote_resp["bytes"])
            if ok:
                excel_matched += 1
                print("  MATCH")
            else:
                excel_mismatched += 1
                print(f"  MISMATCH: {err}")
            continue

        local_resp = _request_json(LOCAL_BASE_URL, endpoint, payload)
        remote_resp = _request_json(REMOTE_BASE_URL, endpoint, payload)

        print(f"  Local:  status={local_resp.get('status')} duration={local_resp.get('duration_ms')}ms")
        print(f"  Remote: status={remote_resp.get('status')} duration={remote_resp.get('duration_ms')}ms")

        if not local_resp.get("ok") or not remote_resp.get("ok"):
            failed += 1
            print(f"  FAIL: {local_resp.get('error')} | {remote_resp.get('error')}")
            continue

        local_norm = _normalize(local_resp["data"])
        remote_norm = _normalize(remote_resp["data"])

        ok, err = _deep_compare(local_norm, remote_norm)
        if ok:
            matched += 1
            print("  MATCH")
        else:
            mismatched += 1
            print(f"  MISMATCH: {err}")
            if endpoint["path"] == "/director/demand-inventory":
                print(f"  Local backlog_by_status: {local_norm.get('backlog_by_status')}")
                print(f"  Remote backlog_by_status: {remote_norm.get('backlog_by_status')}")

    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    print(f"Matched:    {matched}")
    print(f"Mismatched: {mismatched}")
    print(f"Failed:     {failed}")
    print(f"Skipped:    {skipped}")
    if INCLUDE_EXCEL:
        print(f"Excel Matched:    {excel_matched}")
        print(f"Excel Mismatched: {excel_mismatched}")
        print(f"Excel Failed:     {excel_failed}")
    print(f"Total:      {len(common)}")
    print("=" * 80 + "\n")

if __name__ == "__main__":
    main()
