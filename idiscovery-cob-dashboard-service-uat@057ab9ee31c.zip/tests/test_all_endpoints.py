"""
Test script to verify all Director and Manager API endpoints are working.
Run this after starting the server to check if any endpoints are down.
Uses example payloads from DirectorBaseRequest and ManagerBaseRequest models.
"""
import requests
import json
import time

# Configuration
BASE_URL = "http://localhost:8000"  # Change this to your server URL

# Director request payload (from DirectorBaseRequest example in models.py)
director_request = {
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": ["Commercial"],
    "director_ids": ["AL50321"],
    "manager_ids": ["ROSETSC"],
    "frontline_associate_ids": ["HINERTR", "AH40730"]
}

# Manager request payload (from ManagerBaseRequest example in models.py)
manager_request = {
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": ["Commercial"],
    "manager_ids": ["ROSETSC"],
    "frontline_associate_ids": ["HINERTR", "AH40730"]
}

# Director endpoints
director_endpoints = [
    "/director/header-kpis",
    "/director/quality-outcomes",
    "/director/demand-inventory",
    "/director/operational-flow",
    "/director/associate-utilization",
    "/director/sla-health",
    "/director/directors-list",
    "/director/managers-list",
    "/director/lobs",
    "/director/completed-audit-count-drilldown",
    "/director/rework-pct-drilldown",
    "/director/rebuttal-drilldown",
    "/director/escalation-count-drilldown",
    "/director/pended-items-drilldown",
    "/director/production-pct-achieved-drilldown",
    "/director/audit-score-director-drilldown",
    "/director/audit-sample-pct-drilldown",
    "/director/work-items-director-drilldown",
    "/director/fuse-time-director-drilldown",
    "/director/watchlist-drilldown",
    "/director/sla-health-drilldown",
    "/director/cycle-takt-drilldown",
    "/director/completed-ata-counts-drilldown",
    "/director/capacity-insight-drilldown",
    "/director/audit-error-director-drilldown",
]

# Manager endpoints
manager_endpoints = [
    "/manager/header-kpis",
    "/manager/quality-outcomes",
    "/manager/associate-utilization",
    "/manager/managers-list",
    "/manager/associates-list",
    "/manager/lobs",
    "/manager/user-activity",
    "/manager/completed-audit-count-drilldown",
    "/manager/rework-pct-drilldown",
    "/manager/rebuttal-drilldown",
    "/manager/pended-items-drilldown",
    "/manager/production-pct-achieved-drilldown",
    "/manager/work-items-manager-drilldown",
    "/manager/fuse-time-manager-drilldown",
    "/manager/audit-score-manager-drilldown",
    "/manager/audit-error-manager-drilldown",
    "/manager/capacity-insight-manager-drilldown",
]

def test_endpoint(endpoint_path, request_data):
    """Test a single endpoint and return status"""
    url = f"{BASE_URL}{endpoint_path}"
    
    print(f"\n{'='*80}")
    print(f"Testing: {endpoint_path}")
    print(f"{'='*80}")
    print(f"📤 Request Payload:")
    print(json.dumps(request_data, indent=2))
    
    try:
        response = requests.post(url, json=request_data, timeout=60)
        
        print(f"\n📥 Response Status: {response.status_code}")
        
        if response.status_code == 200:
            try:
                response_json = response.json()
                print(f"📥 Response Data (first 500 chars):")
                print(json.dumps(response_json, indent=2)[:500])
            except:
                print(f"📥 Response Text (first 500 chars):")
                print(response.text[:500])
        else:
            print(f"❌ Error Response:")
            print(response.text[:500])
        
        return {
            "endpoint": endpoint_path,
            "status_code": response.status_code,
            "success": response.status_code == 200,
            "error": None if response.status_code == 200 else response.text[:200],
            "response": response.json() if response.status_code == 200 else None
        }
    except requests.exceptions.ConnectionError:
        print(f"Connection Error - Server may not be running")
        return {
            "endpoint": endpoint_path,
            "status_code": None,
            "success": False,
            "error": "Connection Error - Server may not be running",
            "response": None
        }
    except requests.exceptions.Timeout:
        print(f" Timeout - Request took too long")
        return {
            "endpoint": endpoint_path,
            "status_code": None,
            "success": False,
            "error": "Timeout - Request took too long",
            "response": None
        }
    except Exception as e:
        print(f" Exception: {str(e)[:200]}")
        return {
            "endpoint": endpoint_path,
            "status_code": None,
            "success": False,
            "error": str(e)[:200],
            "response": None
        }

def main():
    print("=" * 80)
    print("Testing All Performance IQ API Endpoints")
    print("=" * 80)
    print(f"Base URL: {BASE_URL}")
    print(f"Director Payload: {json.dumps(director_request, indent=2)}")
    print(f"Manager Payload: {json.dumps(manager_request, indent=2)}")
    print("=" * 80)
    
    all_results = []
    start_time = time.time()
    
    # Test Director endpoints
    print("\n🔵 TESTING DIRECTOR ENDPOINTS")
    print("-" * 80)
    for endpoint in director_endpoints:
        result = test_endpoint(endpoint, director_request)
        all_results.append(result)
        
        status_icon = "yes" if result["success"] else "no"
        print(f"{status_icon} {endpoint:50} | Status: {result['status_code']}")
        if not result["success"] and result["error"]:
            print(f"   Error: {result['error']}")
    
    # Test Manager endpoints
    print("\n TESTING MANAGER ENDPOINTS")
    print("-" * 80)
    for endpoint in manager_endpoints:
        result = test_endpoint(endpoint, manager_request)
        all_results.append(result)
        
        status_icon = "yes" if result["success"] else "no"
        print(f"{status_icon} {endpoint:50} | Status: {result['status_code']}")
        if not result["success"] and result["error"]:
            print(f"   Error: {result['error']}")
    
    elapsed_time = time.time() - start_time
    
    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    
    total = len(all_results)
    passed = sum(1 for r in all_results if r["success"])
    failed = total - passed
    
    print(f"Total Endpoints: {total}")
    print(f" Passed: {passed}")
    print(f" Failed: {failed}")
    print(f"⏱  Total Time: {elapsed_time:.2f} seconds")
    print(f" Average Time per Endpoint: {elapsed_time/total:.2f} seconds")
    
    # Separate Director and Manager results
    director_results = [r for r in all_results if r["endpoint"].startswith("/director")]
    manager_results = [r for r in all_results if r["endpoint"].startswith("/manager")]
    
    director_passed = sum(1 for r in director_results if r["success"])
    manager_passed = sum(1 for r in manager_results if r["success"])
    
    print(f"\n🔵 Director: {director_passed}/{len(director_results)} passed")
    print(f"🟢 Manager: {manager_passed}/{len(manager_results)} passed")
    
    if failed > 0:
        print("\n❌ FAILED ENDPOINTS:")
        print("-" * 80)
        for result in all_results:
            if not result["success"]:
                print(f"  • {result['endpoint']}")
                if result["error"]:
                    print(f"    Error: {result['error'][:200]}")
    else:
        print("\n🎉 All endpoints are working!")
    
    # Save results to JSON file
    results_data = {
        "test_run_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "base_url": BASE_URL,
        "summary": {
            "total_endpoints": total,
            "passed": passed,
            "failed": failed,
            "director_passed": director_passed,
            "director_total": len(director_results),
            "manager_passed": manager_passed,
            "manager_total": len(manager_results),
            "elapsed_time_seconds": round(elapsed_time, 2),
            "average_time_per_endpoint": round(elapsed_time/total, 2) if total > 0 else 0
        },
        "results": all_results
    }
    
    output_file = "endpoint_test_results.json"
    with open(output_file, 'w') as f:
        json.dump(results_data, f, indent=2)
    
    print(f"\n📄 Detailed results saved to: {output_file}")

if __name__ == "__main__":
    main()
