#!/bin/bash

# Comprehensive test script for all Manager APIs
# Tests: session_id support, cache reuse, count consistency, deduplication fix

echo "================================================"
echo "Manager APIs Comprehensive Test Suite"
echo "================================================"
echo ""

# Check if server is running
echo "Checking if server is running on localhost:8001..."
if ! curl -s http://localhost:8001/health > /dev/null 2>&1; then
    echo "❌ Error: Server is not running on localhost:8001"
    echo "Please start the server first with: poetry run uvicorn src.idiscovery-cob-dashboard-service:app --reload --port 8001"
    exit 1
fi

echo "✅ Server is running"
echo ""

# Run Python test script
echo "Running comprehensive Manager APIs test..."
echo ""

python3 tests/test_all_manager_apis.py

# Capture exit code
EXIT_CODE=$?

echo ""
echo "================================================"
if [ $EXIT_CODE -eq 0 ]; then
    echo "✅ ALL TESTS PASSED"
    echo ""
    echo "Verified:"
    echo "  ✓ All Manager APIs responding"
    echo "  ✓ Session_id support working"
    echo "  ✓ Cache reuse functioning"
    echo "  ✓ Count consistency maintained"
    echo "  ✓ No deduplication issues"
else
    echo "❌ SOME TESTS FAILED"
    echo ""
    echo "Please review the output above for details."
fi
echo "================================================"

exit $EXIT_CODE
