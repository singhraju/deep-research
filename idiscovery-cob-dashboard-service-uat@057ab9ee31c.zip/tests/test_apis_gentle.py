"""
Gentle API testing - tests one API at a time with delays to avoid overwhelming the server.
"""

import requests
import time

BASE_URL = "http://localhost:8001"
SESSION_ID = f"gentle_test_{int(time.time())}"

PAYLOAD = {
    "user_id": "AB77504",
    "start_date": "2026-04-01",
    "end_date": "2026-04-10",
    "lob": ["Commercial"],
    "session_id": SESSION_ID
}

APIS = [
    "header-kpis",
    "operational-flow",
    "demand-inventory",
    "quality-outcomes",
    "associate-utilization",
    "sla-health"
]

def test_single_api(api_name):
    """Test a single API."""
    url = f"{BASE_URL}/director/{api_name}"
    print(f"\n{'='*60}")
    print(f"Testing: {api_name}")
    print(f"URL: {url}")
    
    try:
        start = time.time()
        response = requests.post(url, json=PAYLOAD, timeout=60)
        duration = int((time.time() - start) * 1000)
        
        if response.status_code == 200:
            data = response.json()
            cache_meta = data.get("cache_metadata", {})
            
            print(f"✅ SUCCESS - {duration}ms")
            print(f"   Cache Hit: {cache_meta.get('cache_hit', 'N/A')}")
            print(f"   Cache Warming: {cache_meta.get('cache_warming', 'N/A')}")
            print(f"   Session ID: {cache_meta.get('session_id', 'N/A')}")
            print(f"   APIs Cached: {cache_meta.get('apis_cached', 'N/A')}")
            return True
        else:
            print(f"❌ FAILED - Status {response.status_code}")
            print(f"   Response: {response.text[:200]}")
            return False
    except Exception as e:
        print(f"❌ ERROR: {str(e)[:200]}")
        return False

print(f"\n{'='*60}")
print(f"Gentle API Testing with Session ID")
print(f"Session: {SESSION_ID}")
print(f"{'='*60}")

results = {}
for api in APIS:
    success = test_single_api(api)
    results[api] = success
    
    if not success:
        print(f"\n⚠️  Stopping tests - {api} failed")
        break
    
    # Wait 2 seconds between API calls
    print("\n⏳ Waiting 2 seconds before next API...")
    time.sleep(2)

print(f"\n{'='*60}")
print("SUMMARY")
print(f"{'='*60}")
success_count = sum(1 for v in results.values() if v)
print(f"APIs Tested: {len(results)}/{len(APIS)}")
print(f"Successful: {success_count}/{len(results)}")
print(f"{'='*60}\n")
