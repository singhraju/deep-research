#!/bin/bash

# Cache Testing Script using curl
# Tests one Director API at a time with session caching

set -e

API_URL="http://localhost:8001"
SESSION_ID="session_curl_test_$(date +%s)"

# Test payload
PAYLOAD=$(cat <<EOF
{
  "user_id": "AB77504",
  "start_date": "2026-04-01",
  "end_date": "2026-04-10",
  "lob": ["Commercial", "EGR"],
  "director_ids": ["AF32384", "AH75838"],
  "manager_ids": ["AH79824", "HARPEDN"],
  "frontline_associate_ids": ["AL89026", "AL06130", "AH36147"],
  "session_id": "${SESSION_ID}"
}
EOF
)

echo "========================================================================"
echo "CACHE TESTING - Header KPIs API"
echo "========================================================================"
echo "Session ID: ${SESSION_ID}"
echo "API: /director/header-kpis"
echo ""

# Call 1 - Cache Miss Expected
echo "------------------------------------------------------------------------"
echo "CALL 1: Cache Miss Expected (Triggering Cache Warming)"
echo "------------------------------------------------------------------------"
START1=$(date +%s%3N)
RESPONSE1=$(curl -s -w "\nHTTP_STATUS:%{http_code}\nTIME_TOTAL:%{time_total}" \
  -X POST "${API_URL}/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d "${PAYLOAD}")

HTTP_CODE1=$(echo "$RESPONSE1" | grep "HTTP_STATUS" | cut -d: -f2)
TIME1=$(echo "$RESPONSE1" | grep "TIME_TOTAL" | cut -d: -f2)
BODY1=$(echo "$RESPONSE1" | sed '/HTTP_STATUS/d' | sed '/TIME_TOTAL/d')

echo "Status Code: ${HTTP_CODE1}"
echo "Response Time: ${TIME1}s"

if [ "${HTTP_CODE1}" = "200" ]; then
    CACHE_HIT1=$(echo "$BODY1" | python3 -c "import sys, json; d=json.load(sys.stdin); print(d.get('cache_metadata', {}).get('cache_hit', 'N/A'))" 2>/dev/null || echo "N/A")
    CACHE_WARMING1=$(echo "$BODY1" | python3 -c "import sys, json; d=json.load(sys.stdin); print(d.get('cache_metadata', {}).get('cache_warming', 'N/A'))" 2>/dev/null || echo "N/A")
    WORK_ITEMS1=$(echo "$BODY1" | python3 -c "import sys, json; d=json.load(sys.stdin); print(d.get('work_items_completed', 'N/A'))" 2>/dev/null || echo "N/A")
    
    echo "Cache Hit: ${CACHE_HIT1}"
    echo "Cache Warming: ${CACHE_WARMING1}"
    echo "Work Items Completed: ${WORK_ITEMS1}"
    
    if [ "${CACHE_HIT1}" = "False" ]; then
        echo "✓ Cache Miss Confirmed (Expected)"
    else
        echo "✗ Unexpected Cache Hit on first call"
    fi
else
    echo "✗ API Error:"
    echo "$BODY1" | head -20
fi

# Wait for cache warming to complete
echo ""
echo "Waiting 3 seconds for cache warming to complete..."
sleep 3

# Call 2 - Cache Hit Expected
echo ""
echo "------------------------------------------------------------------------"
echo "CALL 2: Cache Hit Expected (From Redis)"
echo "------------------------------------------------------------------------"
START2=$(date +%s%3N)
RESPONSE2=$(curl -s -w "\nHTTP_STATUS:%{http_code}\nTIME_TOTAL:%{time_total}" \
  -X POST "${API_URL}/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d "${PAYLOAD}")

HTTP_CODE2=$(echo "$RESPONSE2" | grep "HTTP_STATUS" | cut -d: -f2)
TIME2=$(echo "$RESPONSE2" | grep "TIME_TOTAL" | cut -d: -f2)
BODY2=$(echo "$RESPONSE2" | sed '/HTTP_STATUS/d' | sed '/TIME_TOTAL/d')

echo "Status Code: ${HTTP_CODE2}"
echo "Response Time: ${TIME2}s"

if [ "${HTTP_CODE2}" = "200" ]; then
    CACHE_HIT2=$(echo "$BODY2" | python3 -c "import sys, json; d=json.load(sys.stdin); print(d.get('cache_metadata', {}).get('cache_hit', 'N/A'))" 2>/dev/null || echo "N/A")
    CACHED_AT=$(echo "$BODY2" | python3 -c "import sys, json; d=json.load(sys.stdin); print(d.get('cache_metadata', {}).get('cached_at', 'N/A'))" 2>/dev/null || echo "N/A")
    WORK_ITEMS2=$(echo "$BODY2" | python3 -c "import sys, json; d=json.load(sys.stdin); print(d.get('work_items_completed', 'N/A'))" 2>/dev/null || echo "N/A")
    
    echo "Cache Hit: ${CACHE_HIT2}"
    echo "Cached At: ${CACHED_AT}"
    echo "Work Items Completed: ${WORK_ITEMS2}"
    
    if [ "${CACHE_HIT2}" = "True" ]; then
        echo "✅ CACHE HIT CONFIRMED!"
        
        # Calculate speedup
        SPEEDUP=$(python3 -c "print(f'{float('${TIME1}') / float('${TIME2}'):.1f}x')" 2>/dev/null || echo "N/A")
        IMPROVEMENT=$(python3 -c "print(f'{((float('${TIME1}') - float('${TIME2}')) / float('${TIME1}')) * 100:.1f}%')" 2>/dev/null || echo "N/A")
        
        echo "Performance: ${TIME1}s → ${TIME2}s (${SPEEDUP} speedup, ${IMPROVEMENT} faster)"
        
        # Verify data consistency
        if [ "${WORK_ITEMS1}" = "${WORK_ITEMS2}" ]; then
            echo "✅ Data Consistency: PASSED (work_items match)"
        else
            echo "❌ Data Consistency: FAILED (${WORK_ITEMS1} vs ${WORK_ITEMS2})"
        fi
    else
        echo "❌ CACHE MISS (Expected Hit)"
    fi
else
    echo "✗ API Error:"
    echo "$BODY2" | head -20
fi

# Call 3 - Force Refresh Test
echo ""
echo "------------------------------------------------------------------------"
echo "CALL 3: Force Refresh Test (Should Bypass Cache)"
echo "------------------------------------------------------------------------"

PAYLOAD_REFRESH=$(cat <<EOF
{
  "user_id": "AB77504",
  "start_date": "2026-04-01",
  "end_date": "2026-04-10",
  "lob": ["Commercial", "EGR"],
  "director_ids": ["AF32384", "AH75838"],
  "manager_ids": ["AH79824", "HARPEDN"],
  "frontline_associate_ids": ["AL89026", "AL06130", "AH36147"],
  "session_id": "${SESSION_ID}",
  "force_refresh": true
}
EOF
)

RESPONSE3=$(curl -s -w "\nHTTP_STATUS:%{http_code}\nTIME_TOTAL:%{time_total}" \
  -X POST "${API_URL}/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d "${PAYLOAD_REFRESH}")

HTTP_CODE3=$(echo "$RESPONSE3" | grep "HTTP_STATUS" | cut -d: -f2)
TIME3=$(echo "$RESPONSE3" | grep "TIME_TOTAL" | cut -d: -f2)
BODY3=$(echo "$RESPONSE3" | sed '/HTTP_STATUS/d' | sed '/TIME_TOTAL/d')

echo "Status Code: ${HTTP_CODE3}"
echo "Response Time: ${TIME3}s"

if [ "${HTTP_CODE3}" = "200" ]; then
    CACHE_HIT3=$(echo "$BODY3" | python3 -c "import sys, json; d=json.load(sys.stdin); print(d.get('cache_metadata', {}).get('cache_hit', 'N/A'))" 2>/dev/null || echo "N/A")
    
    echo "Cache Hit: ${CACHE_HIT3}"
    
    if [ "${CACHE_HIT3}" = "False" ]; then
        echo "✅ Force Refresh Working (Cache Bypassed)"
    else
        echo "❌ Force Refresh Not Working (Still using cache)"
    fi
fi

echo ""
echo "========================================================================"
echo "TEST SUMMARY"
echo "========================================================================"
echo "Session ID: ${SESSION_ID}"
echo "Call 1 (Miss):    ${TIME1}s - Cache Hit: ${CACHE_HIT1}"
echo "Call 2 (Hit):     ${TIME2}s - Cache Hit: ${CACHE_HIT2}"
echo "Call 3 (Refresh): ${TIME3}s - Cache Hit: ${CACHE_HIT3}"
echo "========================================================================"
