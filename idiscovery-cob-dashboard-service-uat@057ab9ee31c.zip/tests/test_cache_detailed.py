#!/usr/bin/env python3
"""Detailed cache testing for header-kpis"""

import requests
import json
import time

payload = {
    "user_id": "AB77504",
    "start_date": "2026-04-01",
    "end_date": "2026-04-10",
    "lob": ["Commercial", "EGR", "GRS", "MMP", "Medicaid", "Medicare"],
    "director_ids": ["AF32384", "AH75838", "AL50321", "SANTICH", "AD82517"],
    "manager_ids": ["AH79824", "HARPEDN", "AD23980", "AG54148", "AC85459"],
    "frontline_associate_ids": ["AL89026", "AL06130", "AH36147"],
    "session_id": "session_cache_test_456"
}

def test_cache(endpoint, api_name):
    print("=" * 100)
    print(f"Testing Cache for: {api_name}")
    print(f"Endpoint: {endpoint}")
    print("=" * 100)
    
    url = f"http://localhost:8001{endpoint}"
    
    # First call
    print("\n1️⃣  FIRST CALL (Should be CACHE MISS)")
    print("-" * 100)
    start = time.time()
    resp1 = requests.post(url, json=payload)
    time1 = time.time() - start
    
    print(f"Status: {resp1.status_code}")
    print(f"Time: {time1:.3f}s")
    
    if resp1.status_code == 200:
        data1 = resp1.json()
        
        if 'cache_metadata' in data1:
            cache_meta = data1['cache_metadata']
            print(f"\n✓ Cache Metadata Found:")
            print(f"  - cache_hit: {cache_meta.get('cache_hit', 'N/A')}")
            print(f"  - session_id: {cache_meta.get('session_id', 'N/A')}")
            print(f"  - cached_at: {cache_meta.get('cached_at', 'N/A')}")
            print(f"  - expires_at: {cache_meta.get('expires_at', 'N/A')}")
            print(f"  - apis_cached: {cache_meta.get('apis_cached', [])}")
        else:
            print("\n✗ No cache_metadata in response")
            print(f"Response keys: {list(data1.keys())}")
    else:
        print(f"Error: {resp1.text[:200]}")
        return
    
    # Wait a bit
    time.sleep(1)
    
    # Second call
    print("\n\n2️⃣  SECOND CALL (Should be CACHE HIT)")
    print("-" * 100)
    start = time.time()
    resp2 = requests.post(url, json=payload)
    time2 = time.time() - start
    
    print(f"Status: {resp2.status_code}")
    print(f"Time: {time2:.3f}s")
    
    if resp2.status_code == 200:
        data2 = resp2.json()
        
        if 'cache_metadata' in data2:
            cache_meta = data2['cache_metadata']
            print(f"\n✓ Cache Metadata Found:")
            print(f"  - cache_hit: {cache_meta.get('cache_hit', 'N/A')}")
            print(f"  - session_id: {cache_meta.get('session_id', 'N/A')}")
            print(f"  - cached_at: {cache_meta.get('cached_at', 'N/A')}")
            print(f"  - expires_at: {cache_meta.get('expires_at', 'N/A')}")
            
            if cache_meta.get('cache_hit'):
                print(f"\n  ✅ CACHE HIT CONFIRMED!")
            else:
                print(f"\n  ❌ CACHE MISS (Expected HIT)")
        else:
            print("\n✗ No cache_metadata in response")
    else:
        print(f"Error: {resp2.text[:200]}")
        return
    
    # Performance comparison
    print("\n\n📊 PERFORMANCE COMPARISON")
    print("-" * 100)
    improvement = ((time1 - time2) / time1) * 100
    speedup = time1 / time2 if time2 > 0 else 0
    
    print(f"Call 1 (Cache Miss): {time1:.3f}s")
    print(f"Call 2 (Cache Hit):  {time2:.3f}s")
    print(f"Improvement: {improvement:.1f}% faster")
    print(f"Speedup: {speedup:.1f}x")
    
    # Test force refresh
    print("\n\n3️⃣  THIRD CALL (force_refresh=True)")
    print("-" * 100)
    payload_refresh = payload.copy()
    payload_refresh['force_refresh'] = True
    
    start = time.time()
    resp3 = requests.post(url, json=payload_refresh)
    time3 = time.time() - start
    
    print(f"Status: {resp3.status_code}")
    print(f"Time: {time3:.3f}s")
    
    if resp3.status_code == 200:
        data3 = resp3.json()
        
        if 'cache_metadata' in data3:
            cache_meta = data3['cache_metadata']
            print(f"\n✓ Cache Metadata Found:")
            print(f"  - cache_hit: {cache_meta.get('cache_hit', 'N/A')}")
            
            if not cache_meta.get('cache_hit'):
                print(f"\n  ✅ FORCE REFRESH WORKING (Cache bypassed)")
            else:
                print(f"\n  ❌ FORCE REFRESH NOT WORKING (Still cache hit)")
    
    print("\n" + "=" * 100 + "\n\n")


# Test all APIs
test_cache("/director/header-kpis", "Header KPIs")
test_cache("/director/operational-flow", "Operational Flow")
test_cache("/director/demand-inventory", "Demand Inventory")
test_cache("/director/quality-outcomes", "Quality Outcomes")
test_cache("/director/associate-utilization", "Associate Utilization")
test_cache("/director/sla-health", "SLA Health")
