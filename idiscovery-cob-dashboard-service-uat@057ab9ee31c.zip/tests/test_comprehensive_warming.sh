#!/bin/bash

# Test Comprehensive Cache Warming (22 APIs)
# Tests: 6 core + 16 drilldown APIs all warming together

BASE_URL="http://localhost:8001"
USER_ID="AB77504"
START_DATE="2026-03-01"
END_DATE="2026-03-25"
LOB="Commercial"

echo "======================================"
echo "COMPREHENSIVE CACHE WARMING TEST"
echo "Testing: 22 APIs (6 core + 16 drilldowns)"
echo "======================================"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test counter
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

test_result() {
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}✓ PASS${NC}: $2"
        PASSED_TESTS=$((PASSED_TESTS + 1))
    else
        echo -e "${RED}✗ FAIL${NC}: $2"
        FAILED_TESTS=$((FAILED_TESTS + 1))
    fi
}

# Step 1: Call a core API to trigger comprehensive warming
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}STEP 1: Trigger Comprehensive Warming${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

echo "Calling header-kpis (should trigger warming of ALL 22 APIs)..."
START_TIME=$(date +%s)

RESPONSE=$(curl -s -X POST "$BASE_URL/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["'"$LOB"'"]
  }')

END_TIME=$(date +%s)
DURATION=$((END_TIME - START_TIME))

echo "$RESPONSE" > /tmp/comprehensive_warming_response.json
cat /tmp/comprehensive_warming_response.json | jq '.' > /dev/null 2>&1
if [ $? -eq 0 ]; then
    test_result 0 "API returned valid JSON"
else
    test_result 1 "API returned invalid JSON"
    echo "Response: $RESPONSE"
    exit 1
fi

# Extract session_id
SESSION_ID=$(echo "$RESPONSE" | jq -r '.cache_metadata.session_id // .session_id // empty')
if [ -z "$SESSION_ID" ]; then
    test_result 1 "Session ID extraction"
    echo "Response: $RESPONSE" | jq '.'
    exit 1
else
    test_result 0 "Session ID extraction: $SESSION_ID"
fi

# Check cache_warming flag
CACHE_WARMING=$(echo "$RESPONSE" | jq -r '.cache_metadata.cache_warming // false')
if [ "$CACHE_WARMING" == "true" ]; then
    test_result 0 "Cache warming triggered (cache_warming=true)"
else
    test_result 1 "Cache warming NOT triggered (cache_warming=$CACHE_WARMING)"
fi

echo ""
echo -e "${YELLOW}⏱  First API call took: ${DURATION}s${NC}"
echo ""

# Step 2: Wait for comprehensive warming to complete
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}STEP 2: Waiting for Comprehensive Warming${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

WAIT_TIME=90
echo -e "${YELLOW}Waiting ${WAIT_TIME} seconds for all 22 APIs to warm...${NC}"
echo "Expected: 6 core + 16 drilldown APIs"
echo ""

for i in $(seq 1 $WAIT_TIME); do
    printf "\rProgress: [%-50s] %d/%d seconds" $(printf '#%.0s' $(seq 1 $((i*50/WAIT_TIME)))) $i $WAIT_TIME
    sleep 1
done
echo ""
echo ""

# Step 3: Test cache hits for CORE APIs
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}STEP 3: Test CORE APIs (6) - Cache Hits${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

CORE_APIS=(
    "header-kpis"
    "operational-flow"
    "demand-inventory"
    "quality-outcomes"
    "associate-utilization"
    "sla-health"
)

CORE_CACHE_HITS=0

for API in "${CORE_APIS[@]}"; do
    echo "Testing: $API..."
    START=$(date +%s%3N)
    
    RESPONSE=$(curl -s -X POST "$BASE_URL/director/$API" \
      -H "Content-Type: application/json" \
      -d '{
        "user_id": "'"$USER_ID"'",
        "start_date": "'"$START_DATE"'",
        "end_date": "'"$END_DATE"'",
        "lob": ["'"$LOB"'"],
        "session_id": "'"$SESSION_ID"'"
      }')
    
    END=$(date +%s%3N)
    DURATION=$((END - START))
    
    CACHE_HIT=$(echo "$RESPONSE" | jq -r '.cache_metadata.cache_hit // false')
    
    if [ "$CACHE_HIT" == "true" ]; then
        echo -e "  ${GREEN}✓ Cache HIT${NC} - Response time: ${DURATION}ms"
        CORE_CACHE_HITS=$((CORE_CACHE_HITS + 1))
    else
        echo -e "  ${RED}✗ Cache MISS${NC} - Response time: ${DURATION}ms"
    fi
done

echo ""
if [ $CORE_CACHE_HITS -eq 6 ]; then
    test_result 0 "All 6 core APIs cache hits ($CORE_CACHE_HITS/6)"
else
    test_result 1 "Core APIs cache hits ($CORE_CACHE_HITS/6)"
fi
echo ""

# Step 4: Test cache hits for DRILLDOWN APIs
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}STEP 4: Test DRILLDOWN APIs (16) - Cache Hits${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

DRILLDOWN_CACHE_HITS=0
DRILLDOWN_TOTAL=0

# Test a subset of drilldowns (to keep test time reasonable)
DRILLDOWN_APIS=(
    "work-items-director-drilldown"
    "audit-score-director-drilldown"
    "fuse-time-director-drilldown"
    "production-pct-achieved-drilldown"
    "completed-audit-count-drilldown"
    "rebuttal-drilldown"
)

for API in "${DRILLDOWN_APIS[@]}"; do
    echo "Testing: $API..."
    DRILLDOWN_TOTAL=$((DRILLDOWN_TOTAL + 1))
    START=$(date +%s%3N)
    
    RESPONSE=$(curl -s -X POST "$BASE_URL/director/$API" \
      -H "Content-Type: application/json" \
      -d '{
        "user_id": "'"$USER_ID"'",
        "start_date": "'"$START_DATE"'",
        "end_date": "'"$END_DATE"'",
        "lob": ["'"$LOB"'"],
        "session_id": "'"$SESSION_ID"'",
        "page": 1,
        "page_size": 50
      }')
    
    END=$(date +%s%3N)
    DURATION=$((END - START))
    
    # Check for cache hit
    CACHE_HIT=$(echo "$RESPONSE" | jq -r '.cache_metadata.cache_hit // false')
    
    if [ "$CACHE_HIT" == "true" ]; then
        echo -e "  ${GREEN}✓ Cache HIT${NC} - Response time: ${DURATION}ms"
        DRILLDOWN_CACHE_HITS=$((DRILLDOWN_CACHE_HITS + 1))
    else
        echo -e "  ${YELLOW}○ Cache MISS${NC} - Response time: ${DURATION}ms (may need pagination params)"
    fi
done

echo ""
if [ $DRILLDOWN_CACHE_HITS -gt 0 ]; then
    test_result 0 "Drilldown cache hits ($DRILLDOWN_CACHE_HITS/$DRILLDOWN_TOTAL tested)"
else
    test_result 1 "No drilldown cache hits ($DRILLDOWN_CACHE_HITS/$DRILLDOWN_TOTAL tested)"
fi
echo ""

# Step 5: Check Redis for cached APIs
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}STEP 5: Verify Comprehensive Warming${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

echo "Checking session metadata..."
METADATA_RESPONSE=$(curl -s -X POST "$BASE_URL/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["'"$LOB"'"],
    "session_id": "'"$SESSION_ID"'"
  }')

APIS_CACHED=$(echo "$METADATA_RESPONSE" | jq -r '.cache_metadata.apis_cached // []')
APIS_COUNT=$(echo "$APIS_CACHED" | jq '. | length')

echo "APIs cached in metadata: $APIS_COUNT"
if [ "$APIS_COUNT" -ge 6 ]; then
    test_result 0 "At least 6 APIs cached (found: $APIS_COUNT)"
else
    test_result 1 "Expected at least 6 APIs cached (found: $APIS_COUNT)"
fi

echo ""
echo "Cached API list:"
echo "$APIS_CACHED" | jq -r '.[]' | while read api; do
    echo "  - $api"
done

echo ""

# Final Summary
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}TEST SUMMARY${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "Total Tests:  $TOTAL_TESTS"
echo -e "${GREEN}Passed:       $PASSED_TESTS${NC}"
echo -e "${RED}Failed:       $FAILED_TESTS${NC}"
echo ""

if [ $FAILED_TESTS -eq 0 ]; then
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}✓ ALL TESTS PASSED!${NC}"
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo "✅ Comprehensive warming verified!"
    echo "✅ Session ID: $SESSION_ID"
    echo "✅ Core APIs: $CORE_CACHE_HITS/6 cache hits"
    echo "✅ Drilldowns: $DRILLDOWN_CACHE_HITS/$DRILLDOWN_TOTAL cache hits"
    echo ""
    exit 0
else
    echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${RED}✗ SOME TESTS FAILED${NC}"
    echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    exit 1
fi
