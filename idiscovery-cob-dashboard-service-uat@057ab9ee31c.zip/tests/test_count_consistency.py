#!/usr/bin/env python3
"""
Test script to verify count consistency between dashboard and drilldown APIs.

Tests:
1. Manager: header-kpis.pended_items_count vs pended-items-drilldown.total_records
2. Manager: quality-outcomes.rebuttal_count vs rebuttal-drilldown.total_records  
3. Manager: quality-outcomes.rework_pct vs rework-pct-drilldown.total_records
4. Director: demand-inventory.pended_items_count vs pended-items-drilldown.total_records
"""

import asyncio
import httpx
import json
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

# API Base URL - Update this to your server URL
BASE_URL = "http://localhost:8001"

# Test filters
TEST_FILTERS = {
    "user_id": "AD44140",
    "start_date": (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"),
    "end_date": datetime.now().strftime("%Y-%m-%d"),
    "lob": ["Commercial"],
    "manager_ids": [],
    "frontline_associate_ids": [],
    "session_id": None  # Will be generated
}

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    END = '\033[0m'
    BOLD = '\033[1m'

def print_header(title: str):
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*80}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.BLUE}{title.center(80)}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*80}{Colors.END}\n")

def print_success(message: str):
    print(f"{Colors.GREEN}✅ {message}{Colors.END}")

def print_error(message: str):
    print(f"{Colors.RED}❌ {message}{Colors.END}")

def print_warning(message: str):
    print(f"{Colors.YELLOW}⚠️  {message}{Colors.END}")

def print_info(message: str):
    print(f"{Colors.BLUE}ℹ️  {message}{Colors.END}")

async def call_api(endpoint: str, payload: Dict[str, Any], client: httpx.AsyncClient) -> Dict[str, Any]:
    """Call API and return response JSON."""
    try:
        response = await client.post(f"{BASE_URL}{endpoint}", json=payload, timeout=30.0)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print_error(f"API call failed for {endpoint}: {str(e)}")
        return {}

async def test_manager_pended_items(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Manager pended items count consistency."""
    print_header("TEST 1: Manager Pended Items Count")
    
    # Prepare payloads
    header_payload = {
        **TEST_FILTERS,
        "session_id": session_id
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "page": 1,
        "page_size": 20,
        "status": []
    }
    
    # Call APIs
    print_info("Calling /manager/header-kpis...")
    header_response = await call_api("/manager/header-kpis", header_payload, client)
    
    print_info("Calling /manager/pended-items-drilldown...")
    drilldown_response = await call_api("/manager/pended-items-drilldown", drilldown_payload, client)
    
    if not header_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    # Extract counts
    pended_count = header_response.get("pended_items_count", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Header KPIs pended_items_count: {pended_count}")
    print(f"  Drilldown total_records:         {total_records}")
    
    # Verify match
    if pended_count == total_records:
        print_success(f"PASS: Counts match ({pended_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Header={pended_count}, Drilldown={total_records}")
        return False

async def test_manager_rebuttal_count(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Manager rebuttal count consistency."""
    print_header("TEST 2: Manager Rebuttal Count")
    
    # Prepare payloads
    quality_payload = {
        **TEST_FILTERS,
        "session_id": session_id
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "page": 1,
        "page_size": 20
    }
    
    # Call APIs
    print_info("Calling /manager/quality-outcomes...")
    quality_response = await call_api("/manager/quality-outcomes", quality_payload, client)
    
    print_info("Calling /manager/rebuttal-drilldown...")
    drilldown_response = await call_api("/manager/rebuttal-drilldown", drilldown_payload, client)
    
    if not quality_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    # Extract counts
    rebuttal_count = quality_response.get("rebuttal_count", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Quality Outcomes rebuttal_count: {rebuttal_count}")
    print(f"  Drilldown total_records:         {total_records}")
    
    # Verify match
    if rebuttal_count == total_records:
        print_success(f"PASS: Counts match ({rebuttal_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Quality={rebuttal_count}, Drilldown={total_records}")
        return False

async def test_manager_rework_count(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Manager rework count consistency."""
    print_header("TEST 3: Manager Rework Count")
    
    # Prepare payloads
    quality_payload = {
        **TEST_FILTERS,
        "session_id": session_id
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "page": 1,
        "page_size": 20
    }
    
    # Call APIs
    print_info("Calling /manager/quality-outcomes...")
    quality_response = await call_api("/manager/quality-outcomes", quality_payload, client)
    
    print_info("Calling /manager/rework-pct-drilldown...")
    drilldown_response = await call_api("/manager/rework-pct-drilldown", drilldown_payload, client)
    
    if not quality_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    # Extract counts (rework_pct is returned as string count)
    rework_count_str = quality_response.get("rework_pct", "0")
    try:
        rework_count = int(rework_count_str)
    except:
        rework_count = 0
    
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Quality Outcomes rework_pct:     {rework_count}")
    print(f"  Drilldown total_records:         {total_records}")
    
    # Verify match
    if rework_count == total_records:
        print_success(f"PASS: Counts match ({rework_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Quality={rework_count}, Drilldown={total_records}")
        return False

async def test_manager_completed_audit_count(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Manager completed audit count consistency."""
    print_header("TEST 4: Manager Completed Audit Count")
    
    quality_payload = {
        **TEST_FILTERS,
        "session_id": session_id
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "page": 1,
        "page_size": 20
    }
    
    print_info("Calling /manager/quality-outcomes...")
    quality_response = await call_api("/manager/quality-outcomes", quality_payload, client)
    
    print_info("Calling /manager/completed-audit-count-drilldown...")
    drilldown_response = await call_api("/manager/completed-audit-count-drilldown", drilldown_payload, client)
    
    if not quality_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    completed_audit_count = quality_response.get("completed_audit_count", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Quality Outcomes completed_audit_count: {completed_audit_count}")
    print(f"  Drilldown total_records:                {total_records}")
    
    if completed_audit_count == total_records:
        print_success(f"PASS: Counts match ({completed_audit_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Quality={completed_audit_count}, Drilldown={total_records}")
        return False

async def test_manager_work_items_production_pct(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Manager work items count consistency with production-pct-achieved-drilldown."""
    print_header("TEST 5: Manager Work Items (Production Pct Drilldown)")
    
    header_payload = {
        **TEST_FILTERS,
        "session_id": session_id
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "page": 1,
        "page_size": 20
    }
    
    print_info("Calling /manager/header-kpis...")
    header_response = await call_api("/manager/header-kpis", header_payload, client)
    
    print_info("Calling /manager/production-pct-achieved-drilldown...")
    drilldown_response = await call_api("/manager/production-pct-achieved-drilldown", drilldown_payload, client)
    
    if not header_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    work_items_completed = header_response.get("work_items_completed", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Header KPIs work_items_completed: {work_items_completed}")
    print(f"  Drilldown total_records:          {total_records}")
    
    if work_items_completed == total_records:
        print_success(f"PASS: Counts match ({work_items_completed})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Header={work_items_completed}, Drilldown={total_records}")
        return False

async def test_manager_work_items_drilldown(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Manager work items count consistency with work-items-drilldown."""
    print_header("TEST 6: Manager Work Items (Work Items Drilldown)")
    
    header_payload = {
        **TEST_FILTERS,
        "session_id": session_id
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "page": 1,
        "page_size": 20
    }
    
    print_info("Calling /manager/header-kpis...")
    header_response = await call_api("/manager/header-kpis", header_payload, client)
    
    print_info("Calling /manager/work-items-manager-drilldown...")
    drilldown_response = await call_api("/manager/work-items-manager-drilldown", drilldown_payload, client)
    
    if not header_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    work_items_completed = header_response.get("work_items_completed", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Header KPIs work_items_completed: {work_items_completed}")
    print(f"  Drilldown total_records:          {total_records}")
    
    if work_items_completed == total_records:
        print_success(f"PASS: Counts match ({work_items_completed})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Header={work_items_completed}, Drilldown={total_records}")
        return False

async def test_director_pended_items(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Director pended items count consistency."""
    print_header("TEST 7: Director Pended Items Count")
    
    # Prepare payloads
    demand_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": []
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": [],
        "page": 1,
        "page_size": 20,
        "status": []
    }
    
    # Call APIs
    print_info("Calling /director/demand-inventory...")
    demand_response = await call_api("/director/demand-inventory", demand_payload, client)
    
    print_info("Calling /director/pended-items-drilldown...")
    drilldown_response = await call_api("/director/pended-items-drilldown", drilldown_payload, client)
    
    if not demand_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    # Extract counts
    pended_count = demand_response.get("pended_items_count", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Demand Inventory pended_items_count: {pended_count}")
    print(f"  Drilldown total_records:             {total_records}")
    
    # Verify match
    if pended_count == total_records:
        print_success(f"PASS: Counts match ({pended_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Demand={pended_count}, Drilldown={total_records}")
        return False

async def test_cache_reuse(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test that cache reuse is working by checking logs."""
    print_header("TEST 5: Cache Reuse Verification")
    
    print_info("Testing cache hit behavior...")
    print_warning("NOTE: Check server logs for '✅ Reused cached' messages")
    
    # Call Manager header-kpis twice with same session_id
    payload = {**TEST_FILTERS, "session_id": session_id}
    
    print_info("First call to /manager/header-kpis (should cache)...")
    response1 = await call_api("/manager/header-kpis", payload, client)
    
    print_info("Second call to /manager/header-kpis (should hit cache)...")
    response2 = await call_api("/manager/header-kpis", payload, client)
    
    if response1 and response2:
        print_success("Both calls succeeded - check server logs for cache hits")
        return True
    else:
        print_error("One or both calls failed")
        return False

async def test_director_rebuttal_count(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Director rebuttal count consistency."""
    print_header("TEST 6: Director Rebuttal Count")
    
    quality_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": []
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": [],
        "page": 1,
        "page_size": 20
    }
    
    print_info("Calling /director/quality-outcomes...")
    quality_response = await call_api("/director/quality-outcomes", quality_payload, client)
    
    print_info("Calling /director/rebuttal-drilldown...")
    drilldown_response = await call_api("/director/rebuttal-drilldown", drilldown_payload, client)
    
    if not quality_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    rebuttal_count = quality_response.get("rebuttal_count", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Quality Outcomes rebuttal_count: {rebuttal_count}")
    print(f"  Drilldown total_records:         {total_records}")
    
    if rebuttal_count == total_records:
        print_success(f"PASS: Counts match ({rebuttal_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Quality={rebuttal_count}, Drilldown={total_records}")
        return False

async def test_director_rework_count(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Director rework count consistency."""
    print_header("TEST 7: Director Rework Count")
    
    quality_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": []
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": [],
        "page": 1,
        "page_size": 20
    }
    
    print_info("Calling /director/quality-outcomes...")
    quality_response = await call_api("/director/quality-outcomes", quality_payload, client)
    
    print_info("Calling /director/rework-pct-drilldown...")
    drilldown_response = await call_api("/director/rework-pct-drilldown", drilldown_payload, client)
    
    if not quality_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    rework_count_str = quality_response.get("rework_pct", "0")
    try:
        rework_count = int(rework_count_str)
    except:
        rework_count = 0
    
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Quality Outcomes rework_pct:     {rework_count}")
    print(f"  Drilldown total_records:         {total_records}")
    
    if rework_count == total_records:
        print_success(f"PASS: Counts match ({rework_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Quality={rework_count}, Drilldown={total_records}")
        return False

async def test_director_completed_audit_count(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Director completed audit count consistency."""
    print_header("TEST 8: Director Completed Audit Count")
    
    quality_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": []
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": [],
        "page": 1,
        "page_size": 20
    }
    
    print_info("Calling /director/quality-outcomes...")
    quality_response = await call_api("/director/quality-outcomes", quality_payload, client)
    
    print_info("Calling /director/completed-audit-count-drilldown...")
    drilldown_response = await call_api("/director/completed-audit-count-drilldown", drilldown_payload, client)
    
    if not quality_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    completed_audit_count = quality_response.get("completed_audit_count", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Quality Outcomes completed_audit_count: {completed_audit_count}")
    print(f"  Drilldown total_records:                {total_records}")
    
    if completed_audit_count == total_records:
        print_success(f"PASS: Counts match ({completed_audit_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Quality={completed_audit_count}, Drilldown={total_records}")
        return False

async def test_director_escalation_count(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Director escalation count consistency."""
    print_header("TEST 9: Director Escalation Count")
    
    demand_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": []
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": [],
        "page": 1,
        "page_size": 20
    }
    
    print_info("Calling /director/demand-inventory...")
    demand_response = await call_api("/director/demand-inventory", demand_payload, client)
    
    print_info("Calling /director/escalation-count-drilldown...")
    drilldown_response = await call_api("/director/escalation-count-drilldown", drilldown_payload, client)
    
    if not demand_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    escalation_count = demand_response.get("escalation_count", 0)
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Demand Inventory escalation_count: {escalation_count}")
    print(f"  Drilldown total_records:           {total_records}")
    
    if escalation_count == total_records:
        print_success(f"PASS: Counts match ({escalation_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Demand={escalation_count}, Drilldown={total_records}")
        return False

async def test_director_watchlist_count(client: httpx.AsyncClient, session_id: str) -> bool:
    """Test Director watchlist count consistency."""
    print_header("TEST 10: Director Watchlist Count")
    
    demand_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": []
    }
    
    drilldown_payload = {
        **TEST_FILTERS,
        "session_id": session_id,
        "director_ids": [],
        "page": 1,
        "page_size": 20
    }
    
    print_info("Calling /director/demand-inventory...")
    demand_response = await call_api("/director/demand-inventory", demand_payload, client)
    
    print_info("Calling /director/watchlist-drilldown...")
    drilldown_response = await call_api("/director/watchlist-drilldown", drilldown_payload, client)
    
    if not demand_response or not drilldown_response:
        print_error("Failed to get responses from APIs")
        return False
    
    watchlist_count_str = demand_response.get("watchlist_count", "0")
    try:
        watchlist_count = int(watchlist_count_str)
    except:
        watchlist_count = 0
    
    total_records = drilldown_response.get("page", {}).get("total_records", 0)
    
    print(f"\n  Demand Inventory watchlist_count: {watchlist_count}")
    print(f"  Drilldown total_records:          {total_records}")
    
    if watchlist_count == total_records:
        print_success(f"PASS: Counts match ({watchlist_count})")
        return True
    else:
        print_error(f"FAIL: Counts mismatch! Demand={watchlist_count}, Drilldown={total_records}")
        return False

async def main():
    """Run all tests."""
    print_header("COUNT CONSISTENCY TEST SUITE")
    print_info(f"Test filters:")
    print(f"  User ID: {TEST_FILTERS['user_id']}")
    print(f"  Date Range: {TEST_FILTERS['start_date']} to {TEST_FILTERS['end_date']}")
    print(f"  LOB: {TEST_FILTERS['lob']}")
    print(f"  Base URL: {BASE_URL}")
    
    # Generate session_id
    session_id = f"test_session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    print_info(f"Session ID: {session_id}")
    
    results = []
    
    async with httpx.AsyncClient() as client:
        # Run Manager API tests
        results.append(("Manager Pended Items", await test_manager_pended_items(client, session_id)))
        results.append(("Manager Rebuttal Count", await test_manager_rebuttal_count(client, session_id)))
        results.append(("Manager Rework Count", await test_manager_rework_count(client, session_id)))
        results.append(("Manager Completed Audit Count", await test_manager_completed_audit_count(client, session_id)))
        results.append(("Manager Work Items (Production Pct)", await test_manager_work_items_production_pct(client, session_id)))
        results.append(("Manager Work Items (Drilldown)", await test_manager_work_items_drilldown(client, session_id)))
        
        # Run Director API tests  
        results.append(("Director Pended Items", await test_director_pended_items(client, session_id)))
        results.append(("Director Rebuttal Count", await test_director_rebuttal_count(client, session_id)))
        results.append(("Director Rework Count", await test_director_rework_count(client, session_id)))
        results.append(("Director Completed Audit Count", await test_director_completed_audit_count(client, session_id)))
        results.append(("Director Escalation Count", await test_director_escalation_count(client, session_id)))
        results.append(("Director Watchlist Count", await test_director_watchlist_count(client, session_id)))
        
        # Run cache test
        results.append(("Cache Reuse", await test_cache_reuse(client, session_id)))
    
    # Print summary
    print_header("TEST SUMMARY")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        if result:
            print_success(f"{test_name}: PASSED")
        else:
            print_error(f"{test_name}: FAILED")
    
    print(f"\n{Colors.BOLD}Total: {passed}/{total} tests passed{Colors.END}")
    
    if passed == total:
        print_success(f"\n🎉 ALL TESTS PASSED! Count consistency verified across all APIs.")
        return 0
    else:
        print_error(f"\n⚠️  {total - passed} test(s) failed. Please review the output above.")
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)
