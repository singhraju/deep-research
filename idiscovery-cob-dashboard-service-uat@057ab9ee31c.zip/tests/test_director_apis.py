import os
import requests
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

BASE_URL = os.environ.get("DIRECTOR_TEST_BASE_URL", "http://localhost:8000")
TIMEOUT = int(os.environ.get("DIRECTOR_TEST_TIMEOUT", "60"))

# Proven working test data from comprehensive testing feedback
WORKING_DIRECTORS = ["AA10203", "AA17007", "AA36671", "AB01839", "AB26472"]
WORKING_MANAGERS = ["LYKINDN", "AE08708", "AH45556", "AE09148", "CHAPPLD"]
WORKING_ASSOCIATES = ["AA99826", "AA10203", "LYKINDN", "AH45556", "AE09148", "CHAPPLD", "AL48579"]
WORKING_LOBS = ["Commercial", "Medicare", "Medicaid"]

def print_separator():
    print("\n" + "="*80 + "\n")

def test_endpoint(endpoint_name, url, payload, expected_status=200, validate_data=True):
    """Enhanced test function with comprehensive validation"""
    print(f"Testing: {endpoint_name}")
    print(f"   URL: {url}")
    print(f"   Payload: {json.dumps(payload, indent=2)}")
    
    try:
        response = requests.post(url, json=payload, timeout=TIMEOUT)
        print(f"   Status Code: {response.status_code}")
        
        if response.status_code == expected_status:
            if response.status_code == 200:
                data = response.json()
                status = data.get('status', 'N/A')
                message = data.get('message', 'N/A')
                
                print(f"   Response Status: {status}")
                print(f"   Message: {message}")
                print(f"   Response Keys: {list(data.keys())}")
                
                # Validate response structure
                if validate_data:
                    validation_result = validate_response_structure(data, url)
                    if not validation_result:
                        print("   FAILED - Invalid response structure")
                        return False
                
                # Check for data presence
                has_data = check_data_presence(data)
                print(f"   Data Present: {'Yes' if has_data else 'No'}")
                
                # Additional validation for drilldown endpoints
                if 'drilldown' in url and 'records' in data:
                    records = data.get('records', [])
                    page_info = data.get('page', {})
                    total_records = page_info.get('total_records', 0)
                    
                    print(f"   Records in Response: {len(records)}")
                    print(f"   Total Records Available: {total_records}")
                    print(f"   Page: {page_info.get('page', 'N/A')}/{page_info.get('total_pages', 'N/A')}")
                    
                    # Check for 422 validation errors (should not happen after fixes)
                    if response.status_code == 422:
                        print("   FAILED - 422 Validation Error (drilldown fix needed)")
                        return False
                    
                    if has_data:
                        print("   PASSED - Response received with data")
                    else:
                        print("   PASSED - Response received but no data (may be expected)")
                else:
                    print("   PASSED - Response received")
            
            return True
        else:
            print(f"   FAILED - Status {response.status_code}: {response.text[:200]}...")
        return False
    except Exception as e:
        print(f"   FAILED - Request error: {str(e)}")
        return False
    finally:
        print_separator()

def validate_response_structure(data: Dict[str, Any], endpoint: str) -> bool:
    """Validate response structure based on endpoint type"""
    required_fields = ["status", "message"]
    
    # Check for drilldown endpoints
    if "drilldown" in endpoint:
        required_fields.extend(["page", "records"])
        if "page" in data:
            page_fields = ["page", "page_limit", "total_records", "total_pages", "has_next", "has_previous"]
            for field in page_fields:
                if field not in data["page"]:
                    print(f"   Missing page field: {field}")
                    return False
    
    # Check for list endpoints - they have specific field names, not "data"
    elif any(x in endpoint for x in ["list", "managers", "associates", "directors"]):
        # List endpoints have their own specific field names:
        # directors-list -> "directors", managers-list -> "managers", associates-list -> "associates"
        pass  # No additional required fields beyond status and message
        
    # Check for KPI endpoints - they have individual metric fields, not a "data" field
    # KPI endpoints include: header-kpis, demand-inventory, operational-flow, etc.
    # They return individual metric fields directly in the response
    
    for field in required_fields:
        if field not in data:
            print(f"   Missing required field: {field}")
            return False
            
    return True

def check_data_presence(data: Dict[str, Any]) -> bool:
    """Check if response contains actual data"""
    if "records" in data:
        return len(data.get("records", [])) > 0
    elif "data" in data:
        return len(data.get("data", [])) > 0 if isinstance(data["data"], list) else bool(data.get("data"))
    elif "directors" in data:
        return len(data.get("directors", [])) > 0
    elif "managers" in data:
        return len(data.get("managers", [])) > 0
    elif "associates" in data:
        return len(data.get("associates", [])) > 0
    else:
        # For KPI endpoints, check if any metric fields have non-N/A values
        metric_fields = [
            "work_items_completed", "production_pct_achieved", "audit_score_pct",
            "cycle_time_avg", "takt_time", "volume_forecast_accuracy",
            "backlog_volume", "escalation_count", "pended_items_count",
            "lead_time_avg_minutes", "audit_sample_pct", "rebuttal_count"
        ]
        for field in metric_fields:
            if field in data and data[field] not in ["N/A", None, "", 0]:
                return True
        return False

def get_date_ranges() -> Dict[str, Dict[str, str]]:
    """Get different date ranges for testing"""
    now = datetime.now()
    return {
        "7_days": {
            "start_date": (now - timedelta(days=7)).strftime("%Y-%m-%d"),
            "end_date": now.strftime("%Y-%m-%d")
        },
        "30_days": {
            "start_date": (now - timedelta(days=30)).strftime("%Y-%m-%d"),
            "end_date": now.strftime("%Y-%m-%d")
        },
        "90_days": {
            "start_date": (now - timedelta(days=90)).strftime("%Y-%m-%d"),
            "end_date": now.strftime("%Y-%m-%d")
        },
        "1_year": {
            "start_date": (now - timedelta(days=365)).strftime("%Y-%m-%d"),
            "end_date": now.strftime("%Y-%m-%d")
        }
    }

def check_server_availability():
    """Check if the API server is available"""
    print("Checking API server availability...")
    
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=5)
        if response.status_code == 200:
            print("Server is available. Starting tests...")
            return True
        else:
            print(f"Server returned status {response.status_code}")
            return False
    except Exception as e:
        print("Server is not available at http://localhost:8000")
        print("Please start the server with: poetry run python src/idiscovery-cob-dashboard-service.py")
        return False

def main():
    """Main test execution function with comprehensive testing"""
    start_time = time.time()
    
    print("COMPREHENSIVE DIRECTOR API TESTING")
    print(f"Test Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Base URL: {BASE_URL}")
    print(f"Timeout: {TIMEOUT}s")
    
    # Check server availability
    if not check_server_availability():
        print("\nCannot proceed without API server. Exiting.")
        return
    
    date_ranges = get_date_ranges()
    test_results = {}
    
    print("\n" + "="*80)
    print("PERFORMANCE_IQ_DIRECTOR API COMPREHENSIVE TESTING")
    print("="*80)
    print(f"Using optimal 7-day date range (highest success rate from feedback)")
    print(f"Date Range: {date_ranges['7_days']['start_date']} to {date_ranges['7_days']['end_date']}")
    print_separator()
    
    # Base payload with proven working configuration
    base_request = {
        "user_id": WORKING_DIRECTORS[0],  # AA10203
        **date_ranges["7_days"],
        "lob": ["Commercial"],
        "manager_ids": [WORKING_MANAGERS[0]],  # LYKINDN
        "frontline_associate_ids": []
    }
    
    print("TEST SET 1: Basic Director KPIs and Metrics")
    print_separator()
    
    test_results["header_kpis_1"] = test_endpoint(
        "1. Header KPIs - with manager filter",
        f"{BASE_URL}/director/header-kpis",
        base_request
    )
    
    test_results["header_kpis_2"] = test_endpoint(
        "2. Header KPIs - no filters",
        f"{BASE_URL}/director/header-kpis",
        {
            "user_id": WORKING_DIRECTORS[0],
            **date_ranges["7_days"],
            "lob": [],
            "manager_ids": [],
            "frontline_associate_ids": []
        }
    )
    
    test_results["operational_flow_1"] = test_endpoint(
        "3. Operational Flow - with LOB filter",
        f"{BASE_URL}/director/operational-flow",
        base_request
    )
    
    test_results["operational_flow_2"] = test_endpoint(
        "4. Operational Flow - multiple managers",
        f"{BASE_URL}/director/operational-flow",
        {
            "user_id": WORKING_DIRECTORS[0],
            **date_ranges["7_days"],
            "lob": ["Commercial", "Medicare"],
            "manager_ids": [WORKING_MANAGERS[0], WORKING_MANAGERS[1]],
            "frontline_associate_ids": []
        }
    )
    
    test_results["associate_utilization"] = test_endpoint(
        "5. Associate Utilization",
        f"{BASE_URL}/director/associate-utilization",
        base_request
    )
    
    test_results["demand_inventory"] = test_endpoint(
        "6. Demand Inventory",
        f"{BASE_URL}/director/demand-inventory",
        base_request
    )
    
    test_results["quality_outcomes"] = test_endpoint(
        "7. Quality Outcomes",
        f"{BASE_URL}/director/quality-outcomes",
        base_request
    )
    
    test_results["sla_health"] = test_endpoint(
        "8. SLA Health (Placeholder)",
        f"{BASE_URL}/director/sla-health",
        base_request
    )
    
    print("\nTEST SET 2: AI Coach")
    print_separator()
    
    test_results["ai_coach"] = test_endpoint(
        "9. AI Coach",
        f"{BASE_URL}/director/ai-coach",
        {
            "user_id": WORKING_DIRECTORS[0],
            **date_ranges["7_days"],
            "director_id": [WORKING_DIRECTORS[0]],
            "manager_id": [WORKING_MANAGERS[0]],
            "associates_id": [],
            "lob": ["Commercial"]
        }
    )
    
    print("\nTEST SET 3: List APIs")
    print_separator()
    
    test_results["directors_list"] = test_endpoint(
        "10. Directors List",
        f"{BASE_URL}/director/directors-list",
        {
            "user_id": WORKING_DIRECTORS[0],
            **date_ranges["1_year"]  # Use 1 year for hierarchy APIs
        }
    )
    
    test_results["managers_list_1"] = test_endpoint(
        "11. Managers List - Director AA10203",
        f"{BASE_URL}/director/managers-list",
        {
            "user_id": WORKING_DIRECTORS[0],
            "director_id": WORKING_DIRECTORS[0],
            **date_ranges["1_year"]
        }
    )
    
    test_results["managers_list_2"] = test_endpoint(
        "12. Managers List - Director AA17007",
        f"{BASE_URL}/director/managers-list",
        {
            "user_id": WORKING_DIRECTORS[1],
            "director_id": WORKING_DIRECTORS[1],
            **date_ranges["1_year"]
        }
    )
    
    test_results["associates_list_1"] = test_endpoint(
        "13. Associates List - with manager filter",
        f"{BASE_URL}/director/associates-list",
        {
            "user_id": WORKING_DIRECTORS[0],
            "director_id": WORKING_DIRECTORS[0],
            "manager_id": WORKING_MANAGERS[0],
            **date_ranges["1_year"]
        }
    )
    
    test_results["associates_list_2"] = test_endpoint(
        "14. Associates List - no manager filter",
        f"{BASE_URL}/director/associates-list",
        {
            "user_id": WORKING_DIRECTORS[0],
            "director_id": WORKING_DIRECTORS[0],
            **date_ranges["1_year"]
        }
    )
    
    # Test with different directors
    for i, director in enumerate(WORKING_DIRECTORS[2:4]):  # Test 2 more directors
        test_results[f"managers_list_director_{i+3}"] = test_endpoint(
            f"15. Managers List - Director {i+3} ({director})",
            f"{BASE_URL}/director/managers-list",
            {
                "user_id": director,
                "director_id": director,
                **date_ranges["1_year"]
            }
        )
    
    print("\nTEST SET 4: Drilldown APIs (Paginated)")
    print_separator()
    
    # Base drilldown payload with new format
    drilldown_base = {
        "user_id": WORKING_DIRECTORS[0],
        **date_ranges["7_days"],
        "lob": ["Commercial"],
        "manager_ids": [WORKING_MANAGERS[0]],
        "frontline_associate_ids": [],
        "page": 1,
        "page_size": 20
    }
    
    # Test the recently fixed endpoints
    test_results["rebuttal_drilldown_fixed"] = test_endpoint(
        "16. Rebuttal Drilldown - FIXED (manager/associate filters)",
        f"{BASE_URL}/director/rebuttal-drilldown",
        drilldown_base
    )
    
    test_results["escalation_drilldown_fixed"] = test_endpoint(
        "17. Escalation Count Drilldown - FIXED (manager/associate filters)",
        f"{BASE_URL}/director/escalation-count-drilldown",
        drilldown_base
    )
    
    print("\nTEST SET 5: ALREADY WORKING DRILLDOWN ENDPOINTS")
    print_separator()
    
    # Test the endpoints that were already working
    test_results["production_drilldown_working"] = test_endpoint(
        "18. Production Pct Achieved Drilldown - Already had filters",
        f"{BASE_URL}/director/production-pct-achieved-drilldown",
        drilldown_base
    )
    
    test_results["pended_items_drilldown_working"] = test_endpoint(
        "19. Pended Items Drilldown - Already had filters",
        f"{BASE_URL}/director/pended-items-drilldown",
        drilldown_base
    )
    
    test_results["work_items_drilldown_working"] = test_endpoint(
        "20. Work Items Director Drilldown - Already had filters",
        f"{BASE_URL}/director/work-items-director-drilldown",
        drilldown_base
    )
    
    test_results["fuse_time_drilldown_working"] = test_endpoint(
        "21. Fuse Time Director Drilldown - Already had filters",
        f"{BASE_URL}/director/fuse-time-director-drilldown",
        drilldown_base
    )
    
    test_results["audit_score_drilldown_working"] = test_endpoint(
        "22. Audit Score Director Drilldown - Already had filters",
        f"{BASE_URL}/director/audit-score-director-drilldown",
        drilldown_base
    )
    
    print("\nTEST SET 6: MANAGER FILTERING SCENARIOS")
    print_separator()
    
    # Single manager filter
    single_manager_payload = drilldown_base.copy()
    single_manager_payload.update({
        "manager_ids": [WORKING_MANAGERS[0]],
        "frontline_associate_ids": []
    })
    
    test_results["single_manager_filter"] = test_endpoint(
        "23. Single Manager Filter Test",
        f"{BASE_URL}/director/rebuttal-drilldown",
        single_manager_payload
    )
    
    # Multiple manager filter
    multi_manager_payload = drilldown_base.copy()
    multi_manager_payload.update({
        "manager_ids": [WORKING_MANAGERS[0], WORKING_MANAGERS[1]],
        "frontline_associate_ids": []
    })
    
    test_results["multi_manager_filter"] = test_endpoint(
        "24. Multiple Manager Filter Test",
        f"{BASE_URL}/director/escalation-count-drilldown",
        multi_manager_payload
    )
    
    # No manager filter
    no_manager_payload = drilldown_base.copy()
    no_manager_payload.update({
        "manager_ids": [],
        "frontline_associate_ids": []
    })
    
    test_results["no_manager_filter"] = test_endpoint(
        "25. No Manager Filter Test",
        f"{BASE_URL}/director/production-pct-achieved-drilldown",
        no_manager_payload
    )
    
    print("\nTEST SET 7: ASSOCIATE FILTERING SCENARIOS")
    print_separator()
    
    # Single associate filter
    single_associate_payload = drilldown_base.copy()
    single_associate_payload.update({
        "manager_ids": [],
        "frontline_associate_ids": [WORKING_ASSOCIATES[0]]
    })
    
    test_results["single_associate_filter"] = test_endpoint(
        "26. Single Associate Filter Test",
        f"{BASE_URL}/director/rebuttal-drilldown",
        single_associate_payload
    )
    
    # Multiple associate filter
    multi_associate_payload = drilldown_base.copy()
    multi_associate_payload.update({
        "manager_ids": [],
        "frontline_associate_ids": [WORKING_ASSOCIATES[0], WORKING_ASSOCIATES[1]]
    })
    
    test_results["multi_associate_filter"] = test_endpoint(
        "27. Multiple Associate Filter Test",
        f"{BASE_URL}/director/escalation-count-drilldown",
        multi_associate_payload
    )
    
    # Combined manager and associate filter
    combined_payload = drilldown_base.copy()
    combined_payload.update({
        "manager_ids": [WORKING_MANAGERS[0]],
        "frontline_associate_ids": [WORKING_ASSOCIATES[0]]
    })
    
    test_results["combined_filter"] = test_endpoint(
        "28. Combined Manager and Associate Filter Test",
        f"{BASE_URL}/director/pended-items-drilldown",
        combined_payload
    )
    
    print("\nTEST SET 8: PAGINATION SCENARIOS")
    print_separator()
    
    # Test different page sizes
    page_sizes = [5, 10, 20, 50]
    
    for i, page_size in enumerate(page_sizes):
        pagination_payload = drilldown_base.copy()
        pagination_payload.update({
            "page": 1,
            "page_size": page_size
        })
        
        test_results[f"pagination_size_{page_size}"] = test_endpoint(
            f"{29 + i}. Pagination Test - Page Size {page_size}",
            f"{BASE_URL}/director/work-items-director-drilldown",
            pagination_payload
        )
    
    print("\nTEST SET 9: DIFFERENT DIRECTORS")
    print_separator()
    
    # Test with different working directors
    for i, director in enumerate(WORKING_DIRECTORS[1:4]):  # Test 3 more directors
        director_payload = drilldown_base.copy()
        director_payload.update({
            "user_id": director,
            "manager_ids": [],
            "frontline_associate_ids": []
        })
        
        test_results[f"director_{i+2}_test"] = test_endpoint(
            f"{33 + i}. Director {i+2} Test ({director})",
            f"{BASE_URL}/director/rebuttal-drilldown",
            director_payload
        )
    
    print("\nTEST SET 10: DIFFERENT LOBs")
    print_separator()
    
    # Test with different LOBs
    for i, lob in enumerate(WORKING_LOBS):
        lob_payload = drilldown_base.copy()
        lob_payload.update({
            "lob": [lob]
        })
        
        test_results[f"lob_{lob.lower()}_test"] = test_endpoint(
            f"{36 + i}. LOB {lob} Test",
            f"{BASE_URL}/director/escalation-count-drilldown",
            lob_payload
        )
    
    print("\nTEST SET 11: ADDITIONAL DRILLDOWN APIs")
    print_separator()
    
    # Test additional drilldown endpoints
    additional_endpoints = [
        ("/director/audit-sample-pct-drilldown", "Audit Sample Pct Drilldown"),
        ("/director/capacity-insight-drilldown", "Capacity Insight Drilldown"),
        ("/director/completed-ata-counts-drilldown", "Completed ATA Counts Drilldown"),
        ("/director/rework-pct-drilldown", "Rework Pct Drilldown"),
        ("/director/sla-health-drilldown", "SLA Health Drilldown"),
        ("/director/watchlist-drilldown", "Watchlist Drilldown")
    ]
    
    for i, (endpoint, name) in enumerate(additional_endpoints):
        test_results[f"additional_drilldown_{i+1}"] = test_endpoint(
            f"{39 + i}. {name}",
            f"{BASE_URL}{endpoint}",
            drilldown_base
        )
    
    print("\nTEST SET 12: ERROR HANDLING & EDGE CASES")
    print_separator()
    
    # Test with invalid user_id
    invalid_user_payload = drilldown_base.copy()
    invalid_user_payload.update({
        "user_id": "INVALID_USER"
    })
    
    test_results["invalid_user_test"] = test_endpoint(
        "45. Invalid User ID Test",
        f"{BASE_URL}/director/header-kpis",
        invalid_user_payload,
        expected_status=200,
        validate_data=False
    )
    
    # Test with future date range
    future_date_payload = {
        "user_id": WORKING_DIRECTORS[0],
        "start_date": "2030-01-01",
        "end_date": "2030-12-31",
        "lob": [],
        "manager_ids": [],
        "frontline_associate_ids": []
    }
    
    test_results["future_date_test"] = test_endpoint(
        "46. Future Date Range Test",
        f"{BASE_URL}/director/header-kpis",
        future_date_payload,
        expected_status=200,
        validate_data=False
    )
    
    # Test with minimal payload
    minimal_payload = {
        "user_id": WORKING_DIRECTORS[0]
    }
    
    test_results["minimal_payload_test"] = test_endpoint(
        "47. Minimal Payload Test",
        f"{BASE_URL}/director/header-kpis",
        minimal_payload,
        expected_status=200,
        validate_data=False
    )
    
    # Test large page number
    large_page_payload = drilldown_base.copy()
    large_page_payload.update({
        "page": 999,
        "page_size": 20
    })
    
    test_results["large_page_test"] = test_endpoint(
        "48. Large Page Number Test",
        f"{BASE_URL}/director/escalation-count-drilldown",
        large_page_payload,
        expected_status=200,
        validate_data=False
    )
    
    print("\nTEST SET 13: PERFORMANCE SCENARIOS")
    print_separator()
    
    # Test with all LOBs
    all_lobs_payload = {
        "user_id": WORKING_DIRECTORS[0],
        **date_ranges["7_days"],
        "lob": WORKING_LOBS,
        "manager_ids": [],
        "frontline_associate_ids": []
    }
    
    test_results["all_lobs_performance"] = test_endpoint(
        "49. All LOBs Performance Test",
        f"{BASE_URL}/director/header-kpis",
        all_lobs_payload
    )
    
    # Test with multiple managers
    multi_managers_payload = {
        "user_id": WORKING_DIRECTORS[0],
        **date_ranges["7_days"],
        "lob": ["Commercial"],
        "manager_ids": WORKING_MANAGERS[:3],
        "frontline_associate_ids": []
    }
    
    test_results["multi_managers_performance"] = test_endpoint(
        "50. Multiple Managers Performance Test",
        f"{BASE_URL}/director/demand-inventory",
        multi_managers_payload
    )
    
    # Test with multiple associates
    multi_associates_payload = {
        "user_id": WORKING_DIRECTORS[0],
        **date_ranges["7_days"],
        "lob": ["Commercial"],
        "manager_ids": [],
        "frontline_associate_ids": WORKING_ASSOCIATES[:4]
    }
    
    test_results["multi_associates_performance"] = test_endpoint(
        "51. Multiple Associates Performance Test",
        f"{BASE_URL}/director/operational-flow",
        multi_associates_payload
    )
    
    # Test with longer date range
    long_range_payload = {
        "user_id": WORKING_DIRECTORS[0],
        **date_ranges["1_year"],
        "lob": ["Commercial"],
        "manager_ids": [WORKING_MANAGERS[0]],
        "frontline_associate_ids": []
    }
    
    test_results["long_range_performance"] = test_endpoint(
        "52. 1 Year Date Range Performance Test",
        f"{BASE_URL}/director/quality-outcomes",
        long_range_payload
    )
    
    # Print comprehensive summary
    end_time = time.time()
    execution_time = end_time - start_time
    
    print("\n" + "="*80)
    print("COMPREHENSIVE TEST EXECUTION SUMMARY")
    print("="*80)
    
    total_tests = len(test_results)
    passed_tests = sum(1 for result in test_results.values() if result)
    failed_tests = total_tests - passed_tests
    success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0
    
    print(f"Total Tests Executed: {total_tests}")
    print(f"Tests Passed: {passed_tests}")
    print(f"Tests Failed: {failed_tests}")
    print(f"Success Rate: {success_rate:.1f}%")
    print(f"Total Execution Time: {execution_time:.2f} seconds")
    
    # Categorize results
    fixed_endpoints_results = {k: v for k, v in test_results.items() if 'fixed' in k}
    working_endpoints_results = {k: v for k, v in test_results.items() if 'working' in k}
    filtering_results = {k: v for k, v in test_results.items() if any(x in k for x in ['manager', 'associate', 'filter'])}
    
    print("\nRESULTS BY CATEGORY:")
    
    if fixed_endpoints_results:
        fixed_passed = sum(1 for result in fixed_endpoints_results.values() if result)
        fixed_total = len(fixed_endpoints_results)
        print(f"   Fixed Endpoints: {fixed_passed}/{fixed_total} passed ({(fixed_passed/fixed_total*100):.1f}%)")
    
    if working_endpoints_results:
        working_passed = sum(1 for result in working_endpoints_results.values() if result)
        working_total = len(working_endpoints_results)
        print(f"   Already Working Endpoints: {working_passed}/{working_total} passed ({(working_passed/working_total*100):.1f}%)")
    
    if filtering_results:
        filtering_passed = sum(1 for result in filtering_results.values() if result)
        filtering_total = len(filtering_results)
        print(f"   Filtering Scenarios: {filtering_passed}/{filtering_total} passed ({(filtering_passed/filtering_total*100):.1f}%)")
    
    if success_rate >= 90:
        print("\nEXCELLENT! The Director API fixes are working perfectly!")
    elif success_rate >= 70:
        print("\nGOOD! Most Director endpoints are working correctly.")
    elif success_rate >= 50:
        print("\nMODERATE! Some Director endpoints need attention.")
    else:
        print("\nATTENTION NEEDED! Many Director endpoints are failing.")
    
    if failed_tests > 0:
        print("\nFAILED TESTS:")
        for test_name, result in test_results.items():
            if not result:
                print(f"   - {test_name}")
    
    # Specific validation for fixed endpoints
    fixed_endpoints_failed = [k for k, v in fixed_endpoints_results.items() if not v]
    if fixed_endpoints_failed:
        print("\nCRITICAL: Recently fixed endpoints are still failing:")
        for endpoint in fixed_endpoints_failed:
            print(f"   - {endpoint}")
        print("   These may need additional manager/associate filter fixes.")
    else:
        print("\nSUCCESS: All recently fixed drilldown endpoints are working!")
    
    print(f"\nTest completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)

if __name__ == "__main__":
    main()
