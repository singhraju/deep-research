#!/bin/bash

# =============================================================================
# Director API Test Script - Using cURL
# =============================================================================
# This script tests all major Director APIs with sample requests
# Base URL: http://localhost:8001
# =============================================================================

BASE_URL="http://localhost:8001"

# Color codes for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Director API Testing with cURL${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# =============================================================================
# Test 1: Header KPIs
# =============================================================================
echo -e "${GREEN}Test 1: Header KPIs${NC}"
echo -e "${YELLOW}Endpoint: POST /director/header-kpis${NC}"
echo ""

curl -X POST "${BASE_URL}/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": ["Commercial"],
    "manager_ids": null,
    "frontline_associate_ids": null,
    "session_id": null
  }' | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 2: Operational Flow
# =============================================================================
echo -e "${GREEN}Test 2: Operational Flow${NC}"
echo -e "${YELLOW}Endpoint: POST /director/operational-flow${NC}"
echo ""

curl -X POST "${BASE_URL}/director/operational-flow" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": ["Commercial"]
  }' | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 3: Demand Inventory
# =============================================================================
echo -e "${GREEN}Test 3: Demand Inventory${NC}"
echo -e "${YELLOW}Endpoint: POST /director/demand-inventory${NC}"
echo ""

curl -X POST "${BASE_URL}/director/demand-inventory" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": null
  }' | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 4: Quality Outcomes
# =============================================================================
echo -e "${GREEN}Test 4: Quality Outcomes${NC}"
echo -e "${YELLOW}Endpoint: POST /director/quality-outcomes${NC}"
echo ""

curl -X POST "${BASE_URL}/director/quality-outcomes" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": ["Commercial"]
  }' | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 5: Associate Utilization
# =============================================================================
echo -e "${GREEN}Test 5: Associate Utilization${NC}"
echo -e "${YELLOW}Endpoint: POST /director/associate-utilization${NC}"
echo ""

curl -X POST "${BASE_URL}/director/associate-utilization" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25"
  }' | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 6: SLA Health
# =============================================================================
echo -e "${GREEN}Test 6: SLA Health${NC}"
echo -e "${YELLOW}Endpoint: POST /director/sla-health${NC}"
echo ""

curl -X POST "${BASE_URL}/director/sla-health" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": null
  }' | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 7: Managers List
# =============================================================================
echo -e "${GREEN}Test 7: Managers List${NC}"
echo -e "${YELLOW}Endpoint: POST /director/managers-list${NC}"
echo ""

curl -X POST "${BASE_URL}/director/managers-list" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "directors": [],
    "search": null
  }' | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 8: Associates List
# =============================================================================
echo -e "${GREEN}Test 8: Associates List${NC}"
echo -e "${YELLOW}Endpoint: POST /director/associates-list${NC}"
echo ""

curl -X POST "${BASE_URL}/director/associates-list" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "manager_ids": null,
    "search": null,
    "limit": 50
  }' | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 9: With Session ID (Cache Test)
# =============================================================================
echo -e "${GREEN}Test 9: Header KPIs with Session ID (Cache Test)${NC}"
echo -e "${YELLOW}First call - Should populate cache${NC}"
echo ""

SESSION_ID="test_session_$(date +%s)"

curl -X POST "${BASE_URL}/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\"
  }" | jq '.'

echo -e "\n${YELLOW}Second call with same session_id - Should hit cache${NC}"
echo ""

curl -X POST "${BASE_URL}/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\"
  }" | jq '.'

echo -e "\n${BLUE}----------------------------------------${NC}\n"

# =============================================================================
# Test 10: Health Check
# =============================================================================
echo -e "${GREEN}Test 10: Health Check${NC}"
echo -e "${YELLOW}Endpoint: GET /health${NC}"
echo ""

curl -X GET "http://localhost:8001/health" | jq '.'

echo -e "\n${BLUE}========================================${NC}"
echo -e "${BLUE}  Testing Complete${NC}"
echo -e "${BLUE}========================================${NC}"
