#!/usr/bin/env python3
"""
Director APIs Cache Testing Script

Tests all 6 core Director APIs with session-based caching:
1. First call (cache miss) - should warm the cache
2. Second call (cache hit) - should return from cache
3. Measures response times and verifies cache metadata
"""

import requests
import json
import time
from datetime import datetime
from typing import Dict, Any, List


BASE_URL = "http://localhost:8001"

# Test payload from user
TEST_PAYLOAD = {
    "user_id": "AB77504",
    "start_date": "2026-04-01",
    "end_date": "2026-04-10",
    "lob": ["Commercial", "EGR", "GRS", "MMP", "Medicaid", "Medicare"],
    "director_ids": ["AF32384", "AH75838", "AL50321", "SANTICH", "AD82517"],
    "manager_ids": ["AH79824", "HARPEDN", "AD23980", "AG54148", "AC85459", "AH89970", "AG66523", "MEYERCH", "AC85676", "VLGRIGG", "AC87144", "AD48374", "AC87000", "AL50205", "AM67537", "RCH0301", "AE08708", "LUCASCR", "LYONSML", "AL96141", "LYKINDN", "AB40695", "AA71486", "AL93492", "AL50321", "AB22155", "ROSETSC", "SANTICH", "AD59226", "AH48411", "AC55351", "AC85601", "AB42481", "WILLIHR", "AG40722"],
    "frontline_associate_ids": ["AL89026", "AL06130", "AH36147", "ABSHEMN", "AH93714", "AG69408", "AB86043", "AF41565", "AC80655", "AA37988", "AL06110", "AD28415", "AL71961", "AF87904", "AH51176", "AL87298", "AL72429", "AH49017", "AD66122", "AF81154", "AD92754", "AL06193", "AL25054", "AG38776", "AE09148", "AB80277", "AD07810", "AA76390", "AG32983", "AC93537", "AF04799", "AD49574", "AG11943", "AH45714", "AA74146", "AL52002", "AB26472", "AD60355", "AH89288", "AG07245", "AD93011", "AF03176", "AI05065", "AL42117", "AL77130", "AH49575", "AG67968", "MCCOWLS", "AD09821", "AC77516", "AF60339", "AG17296", "AH23177", "HILSOGW", "RCH0825", "AL06148", "AI06732", "SMITHLR", "AB73830", "AG03652", "AH29995", "AL41742", "AD37776", "GENIEBR", "AL67447", "AL25023", "AC87929", "AG34022", "AA56975", "AA74713", "BURNSLC", "AL25041", "AM26456", "AL19218", "AD07864", "AL87284", "AF17474", "CAMBIST", "AF96818", "AD27845", "AH71055", "AH46771", "AL87935", "AH47520", "CHADWLR", "AC62545", "TLCHAMB", "AG12941", "CHAPPLD", "AF43626", "AH86357", "AA75020", "AL87293", "AE03231", "1694MU", "AF77812", "AG37359", "CHOUIBR", "AL28448", "AM40200", "AB77920", "AB63059", "AB16441", "AG18167", "AD25827", "AL07185", "AD72098", "AG17454", "AC87258", "AG37977", "AG43921", "AH49003", "AH23172", "AD61670", "AC86407", "AL87805", "AL48579", "AL87296", "AG97528", "AG19761", "AB58771", "AF32607", "AH47515", "DEBORPM", "AL37336", "AA87228", "AD44668", "AC51885", "AM27147", "AH70026", "AC21803", "AL48587", "ZGCC228", "AB45725", "AL41838", "AF08727", "AH44962", "AH47516", "AL88207", "AB58018", "AA80476", "AG53083", "AM38857", "AD77978", "AC62520", "AD28236", "AB52397", "AG05468", "AB82886", "AG33021", "AF51518", "AM26455", "ZKFC185", "AH90413", "AH95976", "AL39738", "AL71522", "AB62163", "AG32969", "AG05470", "AB56908", "AA74749", "AD68878", "AF39225", "AG17203", "AD18280", "AH20934", "FREEMMC", "AD30755", "AD32137", "AG02412", "AL52004", "AH89285", "LNG7225", "AM39092", "AB25883", "GARLATN", "AD48198", "AF51400", "AG11951", "AM39094", "AF88900", "AM27266", "9431MU", "AA51379", "AH46800", "AH84706", "AG09915", "AG03422", "AC89038", "AD72744", "GRIDEDN", "AF56933", "ZGCC455", "AM27267", "AG01748", "AG17616", "AF67828", "AF64171", "AF16184", "AF04619", "AH03241", "AF05867", "AG07229", "AG39237", "HARTMCR", "AH60371", "AH64028", "HAYGODW", "AG07687", "AL52557", "AG37152", "AH50799", "AB73904", "AF13083", "AB56798", "AG05406", "HILLRT", "HINERTR", "AD98856", "AI02559", "AI06493", "AL07622", "AF09222", "AM12755", "AD76729", "AF26471", "AD59432", "AC86010", "AF30872", "AB60221", "AA29275", "AD24397", "AG49958", "JACOBBL", "AF42102", "AC03159", "AH46778", "AH45556", "AF13999", "AD43617", "AD44140", "AL04289", "AG91557", "AF19242", "AD05012", "AB80099", "AG20166", "AB75098", "AE02191", "AF08628", "KEENEMC", "KEMPEPM", "AF33136", "AG58037", "AB78267", "AD58252", "AD38413", "AA75452", "AF78570", "PENDLSS", "AA03452", "AF94568", "AF38247", "AA75814", "AH75368", "AM38763", "AD65927", "AF61806", "AH40730", "AH27747", "AC97216", "AG04945", "AL89132", "AH26686", "AD16347", "AL07630", "AL06156", "AG34261", "AC92626", "AB25633", "AL87807", "AD95234", "AL06132", "MANNTM", "AG52447", "AG19216", "AF19077", "AF78653", "AG57276", "AB68417", "MASCOGL", "AH91231", "ZKFCCKA", "AG11824", "AB70423", "AB59612", "AH90863", "AL06163", "AM40206", "AD32485", "AL28150", "AD63606", "AH71097", "AH95677", "AB32550", "AH48427", "AD40944", "AA68866", "AG57298", "AG36847", "AL49667", "AF92881", "AL03114", "AL87808", "AL73781", "AG32991", "AD21110", "AD27552", "AG33109", "AL89337", "AF32076", "AC95494", "AI06256", "AL09084", "AM23773", "AD76733", "AL30100", "AH68436", "AL87937", "AH47518", "AG31629", "AC17131", "AM03566", "AC74547", "AA73951", "PISCIPL", "AL87961", "AL55109", "AL48910", "POGOZTH", "AB93211", "ZMMII71", "AA76114", "AG55003", "AB44206", "AH32085", "AL06604", "AC39021", "AA75237", "AD54060", "AB32557", "AG11807", "AF76893", "AA75306", "AG86807", "AL87803", "AG44646", "AD35966", "RICHAPR", "AG07239", "AF46350", "AF18006", "AD37774", "AB68174", "AL88282", "AF06689", "AF24503", "AH23167", "AL52446", "AC49685", "AF91938", "AG33014", "AM39791", "AB80786", "ZULHAF8", "AM03563", "AH25264", "MCINTNT", "AG20176", "AF86909", "AA61463", "AB20279", "RULINKR", "AB25813", "AL29877", "AL14917", "SIMONRC", "AL28148", "AC27658", "AH95723", "AL06622", "AL06106", "AF84737", "AF35029", "AG01440", "SCHEFSS", "AA03588", "AD24171", "AD94224", "AC34295", "AC86001", "AD58516", "AG20178", "AA27556", "ZKFC099", "AM27149", "SINGLDL", "SIXJN", "AG44119", "SMITHMN", "AG20182", "AD10428", "AL88113", "SMOCKBR", "AL87279", "ZKFCCN5", "AL44616", "AG11837", "AH23214", "AF75736", "AF88081", "AB25531", "AM05316", "STAPLCN", "STEWARB", "AC03585", "RCH1676", "AD36149", "AC80766", "AC25592", "AH52369", "AA09707", "NICHOLZ", "AB43354", "AH37816", "AG11809", "AF22372", "AG63835", "AD21661", "AD34725", "AB01412", "AF96322", "TYREERG", "AA73988", "AA76583", "AA67917", "AF38812", "9441MU", "AM37430", "AF58540", "AA75523", "WALLAVC", "AH46825", "AD32392", "AF97971", "ZHHM040", "AB33087", "AB28985", "AB72656", "AH35466", "AB42916", "AL55963", "AG54997", "AG19645", "AL41962", "AF80411", "AB84189", "AF35865", "AF58129", "AG32696", "AB16029", "AF88885", "AG33154", "AM64331", "AH24135", "AG01684", "AF24098", "AF71102", "ZGCA054", "AD63251", "AD57512", "AD96409", "AL28418"],
    "session_id": "session_1775802826828_xn9ktp2oc"
}

# Core Director APIs
CORE_APIS = [
    {"name": "Header KPIs", "endpoint": "/director/header-kpis"},
    {"name": "Operational Flow", "endpoint": "/director/operational-flow"},
    {"name": "Demand Inventory", "endpoint": "/director/demand-inventory"},
    {"name": "Quality Outcomes", "endpoint": "/director/quality-outcomes"},
    {"name": "Associate Utilization", "endpoint": "/director/associate-utilization"},
    {"name": "SLA Health", "endpoint": "/director/sla-health"}
]


def format_time(seconds: float) -> str:
    """Format time in appropriate unit."""
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    return f"{seconds:.2f}s"


def extract_cache_metadata(response_data: Dict[str, Any]) -> Dict[str, Any]:
    """Extract cache metadata from API response."""
    metadata = {}
    
    # Check for cache metadata in response
    if isinstance(response_data, dict):
        if "cache_metadata" in response_data:
            metadata = response_data["cache_metadata"]
        elif "metadata" in response_data:
            metadata = response_data.get("metadata", {})
    
    return {
        "cache_hit": metadata.get("cache_hit", False),
        "cached_at": metadata.get("cached_at", "N/A"),
        "expires_at": metadata.get("expires_at", "N/A"),
        "session_id": metadata.get("session_id", "N/A"),
        "apis_cached": metadata.get("apis_cached", [])
    }


def call_api(api_name: str, endpoint: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Call a Director API and return response with timing."""
    url = f"{BASE_URL}{endpoint}"
    
    start_time = time.time()
    try:
        response = requests.post(url, json=payload, timeout=60)
        elapsed = time.time() - start_time
        
        if response.status_code == 200:
            data = response.json()
            cache_meta = extract_cache_metadata(data)
            
            return {
                "success": True,
                "status_code": 200,
                "elapsed_time": elapsed,
                "cache_hit": cache_meta["cache_hit"],
                "cache_metadata": cache_meta,
                "data_keys": list(data.keys()) if isinstance(data, dict) else None
            }
        else:
            return {
                "success": False,
                "status_code": response.status_code,
                "elapsed_time": elapsed,
                "error": response.text[:200]
            }
    except Exception as e:
        elapsed = time.time() - start_time
        return {
            "success": False,
            "status_code": 0,
            "elapsed_time": elapsed,
            "error": str(e)
        }


def print_separator(char="=", length=100):
    """Print a separator line."""
    print(char * length)


def print_result(api_name: str, call_num: int, result: Dict[str, Any]):
    """Print individual API call result."""
    cache_status = "✓ CACHE HIT" if result.get("cache_hit") else "✗ CACHE MISS"
    time_str = format_time(result["elapsed_time"])
    
    if result["success"]:
        print(f"  Call {call_num}: {cache_status} | Time: {time_str} | Status: {result['status_code']}")
        
        if result.get("cache_metadata"):
            meta = result["cache_metadata"]
            if meta.get("session_id") != "N/A":
                print(f"           Session: {meta['session_id']}")
            if meta.get("apis_cached"):
                print(f"           APIs Cached: {len(meta['apis_cached'])} APIs")
    else:
        print(f"  Call {call_num}: ✗ FAILED | Time: {time_str} | Status: {result['status_code']}")
        print(f"           Error: {result.get('error', 'Unknown error')[:100]}")


def test_all_apis():
    """Test all core Director APIs with cache verification."""
    print_separator("=")
    print("DIRECTOR APIs CACHE TESTING")
    print_separator("=")
    print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Base URL: {BASE_URL}")
    print(f"Session ID: {TEST_PAYLOAD['session_id']}")
    print(f"Date Range: {TEST_PAYLOAD['start_date']} to {TEST_PAYLOAD['end_date']}")
    print(f"LOBs: {', '.join(TEST_PAYLOAD['lob'])}")
    print(f"Directors: {len(TEST_PAYLOAD['director_ids'])}")
    print(f"Managers: {len(TEST_PAYLOAD['manager_ids'])}")
    print(f"Associates: {len(TEST_PAYLOAD['frontline_associate_ids'])}")
    print_separator("=")
    print()
    
    results_summary = []
    
    for idx, api in enumerate(CORE_APIS, 1):
        print(f"{idx}. Testing: {api['name']}")
        print(f"   Endpoint: {api['endpoint']}")
        
        # First call - should be cache miss (or trigger cache warming)
        print("   First Call (Cache Miss Expected)...")
        result1 = call_api(api['name'], api['endpoint'], TEST_PAYLOAD)
        print_result(api['name'], 1, result1)
        
        # Small delay to ensure cache is written
        time.sleep(0.5)
        
        # Second call - should be cache hit
        print("   Second Call (Cache Hit Expected)...")
        result2 = call_api(api['name'], api['endpoint'], TEST_PAYLOAD)
        print_result(api['name'], 2, result2)
        
        # Calculate improvement
        if result1["success"] and result2["success"]:
            improvement = ((result1["elapsed_time"] - result2["elapsed_time"]) / result1["elapsed_time"]) * 100
            speedup = result1["elapsed_time"] / result2["elapsed_time"] if result2["elapsed_time"] > 0 else 0
            
            print(f"   Performance: {improvement:.1f}% faster | {speedup:.1f}x speedup")
            
            results_summary.append({
                "api": api['name'],
                "call1_time": result1["elapsed_time"],
                "call1_cache": result1.get("cache_hit", False),
                "call2_time": result2["elapsed_time"],
                "call2_cache": result2.get("cache_hit", False),
                "improvement": improvement,
                "speedup": speedup,
                "success": True
            })
        else:
            results_summary.append({
                "api": api['name'],
                "success": False,
                "error": result1.get("error") or result2.get("error")
            })
        
        print()
    
    # Print summary
    print_separator("=")
    print("CACHE TESTING SUMMARY")
    print_separator("=")
    
    successful_tests = [r for r in results_summary if r.get("success")]
    failed_tests = [r for r in results_summary if not r.get("success")]
    
    if successful_tests:
        print("\n✓ SUCCESSFUL TESTS:")
        print(f"{'API':<30} {'Call 1':<12} {'Call 2':<12} {'Speedup':<12} {'Cache Status'}")
        print("-" * 100)
        
        for result in successful_tests:
            call1_time = format_time(result['call1_time'])
            call2_time = format_time(result['call2_time'])
            speedup = f"{result['speedup']:.1f}x"
            cache_status = "✓ HIT" if result['call2_cache'] else "✗ MISS"
            
            print(f"{result['api']:<30} {call1_time:<12} {call2_time:<12} {speedup:<12} {cache_status}")
        
        # Calculate averages
        avg_speedup = sum(r['speedup'] for r in successful_tests) / len(successful_tests)
        avg_improvement = sum(r['improvement'] for r in successful_tests) / len(successful_tests)
        
        print("-" * 100)
        print(f"Average Speedup: {avg_speedup:.1f}x | Average Improvement: {avg_improvement:.1f}%")
    
    if failed_tests:
        print("\n✗ FAILED TESTS:")
        for result in failed_tests:
            print(f"  - {result['api']}: {result.get('error', 'Unknown error')[:100]}")
    
    print_separator("=")
    print(f"End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print_separator("=")
    
    # Test with force_refresh
    print("\n\nTESTING FORCE REFRESH...")
    print_separator("-")
    test_payload_refresh = TEST_PAYLOAD.copy()
    test_payload_refresh["force_refresh"] = True
    
    print("Calling Header KPIs with force_refresh=True...")
    result_refresh = call_api("Header KPIs", "/director/header-kpis", test_payload_refresh)
    print_result("Header KPIs", 1, result_refresh)
    print("(Should be cache miss even though data was cached)")
    print_separator("=")


if __name__ == "__main__":
    test_all_apis()
