#!/bin/bash

# Test: Verify Drilldown APIs Don't Trigger Core API Warming
# Only the 6 core dashboard APIs should trigger warming

echo "=============================================="
echo "Drilldown API Warming Test"
echo "=============================================="
echo ""

BASE_URL="http://localhost:8001"
SESSION_ID="test_drilldown_$(date +%s)"

echo "📋 Test Objective:"
echo "  - Verify drilldown APIs DO NOT trigger warming of 6 core APIs"
echo "  - Verify core APIs DO trigger warming"
echo ""
echo "Session ID: ${SESSION_ID}"
echo ""

# Test 1: Call a drilldown API first
echo "=============================================="
echo "Test 1: Call Drilldown API (work-items-drilldown)"
echo "=============================================="
echo "Expected: Should NOT trigger warming of core APIs"
echo ""

DRILLDOWN_RESPONSE=$(curl -s -X POST ${BASE_URL}/director/work-items-drilldown \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\",
    \"page\": 1,
    \"page_size\": 10
  }")

echo "Response:"
echo "$DRILLDOWN_RESPONSE" | jq '{
  total_count,
  page,
  cache_metadata
}'

CACHE_WARMING=$(echo "$DRILLDOWN_RESPONSE" | jq -r '.cache_metadata.cache_warming // "null"')
echo ""
if [ "$CACHE_WARMING" == "false" ] || [ "$CACHE_WARMING" == "null" ]; then
    echo "✅ Drilldown API did NOT trigger warming (correct)"
else
    echo "❌ Drilldown API triggered warming (incorrect - should not warm core APIs)"
fi
echo ""

# Wait a moment
sleep 2

# Test 2: Now call a core API
echo "=============================================="
echo "Test 2: Call Core API (header-kpis)"
echo "=============================================="
echo "Expected: SHOULD trigger warming of all 6 core APIs"
echo ""

CORE_RESPONSE=$(curl -s -X POST ${BASE_URL}/director/header-kpis \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\"
  }")

echo "Response:"
echo "$CORE_RESPONSE" | jq '{
  work_items_completed,
  cache_metadata
}'

CORE_CACHE_WARMING=$(echo "$CORE_RESPONSE" | jq -r '.cache_metadata.cache_warming')
echo ""
if [ "$CORE_CACHE_WARMING" == "true" ]; then
    echo "✅ Core API triggered warming (correct)"
else
    echo "❌ Core API did NOT trigger warming (incorrect)"
fi
echo ""

# Wait for warming to complete
echo "⏳ Waiting 10 seconds for warming to complete..."
sleep 10
echo ""

# Test 3: Verify warming completed
echo "=============================================="
echo "Test 3: Verify Warming Completed"
echo "=============================================="

VERIFY_RESPONSE=$(curl -s -X POST ${BASE_URL}/director/header-kpis \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\"
  }")

CACHE_HIT=$(echo "$VERIFY_RESPONSE" | jq -r '.cache_metadata.cache_hit')
APIS_CACHED=$(echo "$VERIFY_RESPONSE" | jq -r '.cache_metadata.apis_cached | length')

echo "Cache Hit: ${CACHE_HIT}"
echo "APIs Cached: ${APIS_CACHED}/6"
echo ""

if [ "$CACHE_HIT" == "true" ] && [ "$APIS_CACHED" == "6" ]; then
    echo "✅ All 6 core APIs cached successfully"
    echo ""
    echo "Cached APIs:"
    echo "$VERIFY_RESPONSE" | jq -r '.cache_metadata.apis_cached[]' | while read api; do
        echo "  ✓ $api"
    done
else
    echo "❌ Warming incomplete"
fi
echo ""

# Summary
echo "=============================================="
echo "Test Summary"
echo "=============================================="
echo ""
echo "Core APIs (should trigger warming):"
echo "  - header-kpis"
echo "  - operational-flow"
echo "  - demand-inventory"
echo "  - quality-outcomes"
echo "  - associate-utilization"
echo "  - sla-health"
echo ""
echo "Drilldown APIs (should NOT trigger warming):"
echo "  - work-items-drilldown"
echo "  - audit-score-drilldown"
echo "  - fuse-time-drilldown"
echo "  - production-pct-drilldown"
echo "  - ... and all other drilldowns"
echo ""

if [ "$CACHE_WARMING" == "false" ] || [ "$CACHE_WARMING" == "null" ]; then
    if [ "$CORE_CACHE_WARMING" == "true" ] && [ "$CACHE_HIT" == "true" ] && [ "$APIS_CACHED" == "6" ]; then
        echo "✅ ALL TESTS PASSED"
        echo ""
        echo "Behavior verified:"
        echo "  ✓ Drilldown APIs don't trigger warming"
        echo "  ✓ Core APIs trigger warming"
        echo "  ✓ All 6 core APIs cached"
        echo "  ✓ Efficient caching strategy working"
    else
        echo "⚠️  PARTIAL PASS - Core warming issues"
    fi
else
    echo "❌ TESTS FAILED"
    echo "Drilldown API incorrectly triggered warming"
fi
echo ""
echo "=============================================="
