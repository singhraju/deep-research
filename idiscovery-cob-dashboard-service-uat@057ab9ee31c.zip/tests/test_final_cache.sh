#!/bin/bash

SESSION_ID="final_test_$(date +%s)"
PAYLOAD="{\"user_id\":\"AB77504\",\"start_date\":\"2026-04-01\",\"end_date\":\"2026-04-10\",\"lob\":[\"Commercial\"],\"session_id\":\"${SESSION_ID}\"}"

echo "========================================================================"
echo "FINAL CACHE TEST - Header KPIs API"
echo "========================================================================"
echo "Session: ${SESSION_ID}"
echo ""

echo "CALL 1: Cache Miss (Triggers Warming)"
echo "------------------------------------------------------------------------"
START1=$(date +%s%N)
RESP1=$(curl -s -w "\n%{time_total}" -X POST "http://localhost:8001/director/header-kpis" \
  -H "Content-Type: application/json" -d "${PAYLOAD}")
END1=$(date +%s%N)
TIME1=$(echo "$RESP1" | tail -1)
BODY1=$(echo "$RESP1" | head -n -1)

CACHE_HIT1=$(echo "$BODY1" | python3 -c "import sys,json; print(json.load(sys.stdin).get('cache_metadata',{}).get('cache_hit','N/A'))" 2>/dev/null)
WORK1=$(echo "$BODY1" | python3 -c "import sys,json; print(json.load(sys.stdin).get('work_items_completed','N/A'))" 2>/dev/null)

echo "Time: ${TIME1}s | cache_hit: ${CACHE_HIT1} | work_items: ${WORK1}"

echo ""
echo "Waiting 10 seconds for background cache warming to complete..."
sleep 10

echo ""
echo "CALL 2: Cache Hit (From Redis)"
echo "------------------------------------------------------------------------"
START2=$(date +%s%N)
RESP2=$(curl -s -w "\n%{time_total}" -X POST "http://localhost:8001/director/header-kpis" \
  -H "Content-Type: application/json" -d "${PAYLOAD}")
END2=$(date +%s%N)
TIME2=$(echo "$RESP2" | tail -1)
BODY2=$(echo "$RESP2" | head -n -1)

CACHE_HIT2=$(echo "$BODY2" | python3 -c "import sys,json; print(json.load(sys.stdin).get('cache_metadata',{}).get('cache_hit','N/A'))" 2>/dev/null)
CACHED_AT=$(echo "$BODY2" | python3 -c "import sys,json; print(json.load(sys.stdin).get('cache_metadata',{}).get('cached_at','N/A'))" 2>/dev/null)
APIS=$(echo "$BODY2" | python3 -c "import sys,json; print(len(json.load(sys.stdin).get('cache_metadata',{}).get('apis_cached',[])))" 2>/dev/null)
WORK2=$(echo "$BODY2" | python3 -c "import sys,json; print(json.load(sys.stdin).get('work_items_completed','N/A'))" 2>/dev/null)

echo "Time: ${TIME2}s | cache_hit: ${CACHE_HIT2} | work_items: ${WORK2}"
echo "Cached At: ${CACHED_AT} | APIs Cached: ${APIS}"

echo ""
echo "CALL 3: Another Cache Hit"
echo "------------------------------------------------------------------------"
START3=$(date +%s%N)
RESP3=$(curl -s -w "\n%{time_total}" -X POST "http://localhost:8001/director/header-kpis" \
  -H "Content-Type: application/json" -d "${PAYLOAD}")
END3=$(date +%s%N)
TIME3=$(echo "$RESP3" | tail -1)
BODY3=$(echo "$RESP3" | head -n -1)

CACHE_HIT3=$(echo "$BODY3" | python3 -c "import sys,json; print(json.load(sys.stdin).get('cache_metadata',{}).get('cache_hit','N/A'))" 2>/dev/null)
WORK3=$(echo "$BODY3" | python3 -c "import sys,json; print(json.load(sys.stdin).get('work_items_completed','N/A'))" 2>/dev/null)

echo "Time: ${TIME3}s | cache_hit: ${CACHE_HIT3} | work_items: ${WORK3}"

echo ""
echo "========================================================================"
echo "SUMMARY"
echo "========================================================================"
echo "Call 1 (Miss):  ${TIME1}s - cache_hit: ${CACHE_HIT1}"
echo "Call 2 (Hit):   ${TIME2}s - cache_hit: ${CACHE_HIT2}"
echo "Call 3 (Hit):   ${TIME3}s - cache_hit: ${CACHE_HIT3}"

if [ "${CACHE_HIT2}" = "True" ] && [ "${CACHE_HIT3}" = "True" ]; then
    echo ""
    echo "✅ CACHE WORKING! Speedup: $(python3 -c "print(f'{float('${TIME1}') / float('${TIME2}'):.1f}x')")"
    echo "Data Consistent: work_items = ${WORK1} → ${WORK2} → ${WORK3}"
else
    echo ""
    echo "❌ Cache not hitting as expected"
fi
echo "========================================================================"
