#!/usr/bin/env python3
"""
FL Auditor Cache Testing Script

This script tests the caching implementation for FL Auditor endpoints:
- header-kpis (5 metrics cached)
- rebuttals (3 metrics cached)
- time-utilization (1 metric cached)
- Drilldown cache reuse (work_items, complete_audit_count, rebuttal_count)
"""

import requests
import json
import time
from typing import Dict, Any

BASE_URL = "http://localhost:8000/cobdashboard/v1/fl-auditor"

# Test payload
PAYLOAD = {
    "user_id": "AD47536",
    "start_date": "2024-01-01",
    "end_date": "2024-12-31",
    "lob": ["Medicare"]
}

def print_section(title: str):
    """Print a formatted section header"""
    print("\n" + "=" * 100)
    print(f"  {title}")
    print("=" * 100)

def print_subsection(title: str):
    """Print a formatted subsection header"""
    print(f"\n{title}")
    print("-" * 100)

def test_endpoint_caching(endpoint: str, api_name: str, payload: Dict[str, Any]) -> str:
    """
    Test caching for a specific endpoint
    Returns the session_id for further testing
    """
    print_section(f"Testing: {api_name}")
    
    url = f"{BASE_URL}{endpoint}"
    session_id = None
    
    # First call - Cache MISS
    print_subsection("[1] FIRST CALL (Cache MISS Expected)")
    start = time.time()
    try:
        resp1 = requests.post(url, json=payload, timeout=30)
        time1 = time.time() - start
        
        print(f"Status: {resp1.status_code}")
        print(f"Response Time: {time1:.3f}s")
        
        if resp1.status_code == 200:
            data1 = resp1.json()
            
            # Check for cache_metadata
            if 'cache_metadata' in data1:
                cache_meta = data1['cache_metadata']
                session_id = cache_meta.get('session_id')
                print(f"\nCache Metadata Found:")
                print(f"  - cache_hit: {cache_meta.get('cache_hit', 'N/A')}")
                print(f"  - session_id: {session_id}")
                print(f"  - cached_at: {cache_meta.get('cached_at', 'N/A')}")
            else:
                print("\nWARNING: No cache_metadata in response (might not be implemented for this endpoint)")
                # Try to extract session_id from logs or generate one
                session_id = "test_session_123"
        else:
            print(f"ERROR: {resp1.text[:300]}")
            return None
            
    except Exception as e:
        print(f"ERROR: Request failed: {str(e)}")
        return None
    
    if not session_id:
        print("\nWARNING: No session_id available, skipping cache hit test")
        return None
    
    # Wait a bit
    time.sleep(1)
    
    # Second call - Cache HIT
    print_subsection("[2] SECOND CALL (Cache HIT Expected)")
    payload_with_session = payload.copy()
    payload_with_session['session_id'] = session_id
    
    start = time.time()
    try:
        resp2 = requests.post(url, json=payload_with_session, timeout=30)
        time2 = time.time() - start
        
        print(f"Status: {resp2.status_code}")
        print(f"Response Time: {time2:.3f}s")
        
        if resp2.status_code == 200:
            data2 = resp2.json()
            
            if 'cache_metadata' in data2:
                cache_meta = data2['cache_metadata']
                print(f"\nCache Metadata Found:")
                print(f"  - cache_hit: {cache_meta.get('cache_hit', 'N/A')}")
                print(f"  - session_id: {cache_meta.get('session_id', 'N/A')}")
                
                if cache_meta.get('cache_hit'):
                    print(f"\n  SUCCESS: CACHE HIT CONFIRMED!")
                else:
                    print(f"\n  WARNING: CACHE MISS (Expected HIT - check Redis)")
            
            # Performance comparison
            print_subsection("[PERFORMANCE COMPARISON]")
            improvement = ((time1 - time2) / time1) * 100 if time1 > 0 else 0
            speedup = time1 / time2 if time2 > 0 else 0
            
            print(f"Call 1 (Cache Miss): {time1:.3f}s")
            print(f"Call 2 (Cache Hit):  {time2:.3f}s")
            print(f"Improvement: {improvement:.1f}% faster")
            print(f"Speedup: {speedup:.1f}x")
            
            if improvement > 50:
                print(f"\nSUCCESS: SIGNIFICANT PERFORMANCE IMPROVEMENT - Cache is working!")
            elif improvement > 0:
                print(f"\nWARNING: Moderate improvement - Cache might be working but check Redis")
            else:
                print(f"\nERROR: NO IMPROVEMENT - Cache not working, check Redis connection")
        else:
            print(f"ERROR: {resp2.text[:300]}")
            
    except Exception as e:
        print(f"ERROR: Request failed: {str(e)}")
    
    return session_id


def test_drilldown_cache_reuse(session_id: str):
    """Test drilldown endpoints reusing cached counts"""
    print_section("Testing: Drilldown Cache Reuse")
    
    drilldowns = [
        ("/work-items-drilldown", "Work Items Drilldown", "work_items_completed"),
        ("/complete-audit-count-drilldown", "Complete Audit Count Drilldown", "complete_audit_count"),
        ("/rebuttal-count-drilldown", "Rebuttal Count Drilldown", "rebuttal_count")
    ]
    
    for endpoint, name, metric_name in drilldowns:
        print_subsection(f"Testing: {name}")
        
        url = f"{BASE_URL}{endpoint}"
        payload_with_session = PAYLOAD.copy()
        payload_with_session['session_id'] = session_id
        payload_with_session['page'] = 1
        payload_with_session['page_size'] = 20
        
        try:
            start = time.time()
            resp = requests.post(url, json=payload_with_session, timeout=30)
            elapsed = time.time() - start
            
            print(f"Status: {resp.status_code}")
            print(f"Response Time: {elapsed:.3f}s")
            
            if resp.status_code == 200:
                data = resp.json()
                if 'page' in data:
                    page_info = data['page']
                    print(f"Total Records: {page_info.get('total_records', 'N/A')}")
                    print(f"Total Pages: {page_info.get('total_pages', 'N/A')}")
                    print(f"\nSUCCESS: Drilldown executed successfully")
                    print(f"   Check logs for: 'Reused cached {metric_name} count'")
            else:
                print(f"ERROR: {resp.text[:300]}")
                
        except Exception as e:
            print(f"ERROR: Request failed: {str(e)}")


def main():
    """Run all cache tests"""
    print_section("FL AUDITOR CACHE TESTING")
    print("This script will test caching for FL Auditor endpoints")
    print("Make sure the service is running on http://localhost:8000")
    print("Make sure Redis is running and REDIS_ENABLED=True in config")
    
    # Test 1: Header KPIs
    session_id = test_endpoint_caching("/header-kpis", "Header KPIs", PAYLOAD)
    
    # Test 2: Rebuttals
    test_endpoint_caching("/rebuttals", "Rebuttals", PAYLOAD)
    
    # Test 3: Time Utilization
    test_endpoint_caching("/time-utilization", "Time Utilization", PAYLOAD)
    
    # Test 4: Drilldown Cache Reuse (if we have a session_id)
    if session_id:
        print("\n\n")
        test_drilldown_cache_reuse(session_id)
    else:
        print("\n\nWARNING: Skipping drilldown cache reuse tests (no session_id available)")
    
    # Final summary
    print_section("TEST SUMMARY")
    print("""
[SUCCESS] What to look for in successful cache implementation:
   1. First call takes 5-10 seconds (Snowflake queries)
   2. Second call takes <1 second (Redis cache)
   3. Performance improvement >90%
   4. cache_metadata shows cache_hit: true on second call
   5. Drilldown logs show "Reused cached count"

[ERROR] If cache is NOT working:
   1. Check Redis is running: redis-cli ping
   2. Check REDIS_ENABLED=True in config
   3. Check logs for cache errors
   4. Verify session_id is being passed correctly
   
[LOGS] Check application logs for detailed cache behavior:
   - "Auto-generated session_id: <uuid>"
   - "Cache hit for metric: <metric_name>"
   - "Reused cached count: <number>"
    """)


if __name__ == "__main__":
    main()
