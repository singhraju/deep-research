#!/bin/bash

# Test Manager Completed Audit Count Query Updates
# Tests both quality-outcomes (caching) and drilldown (cache reuse)

BASE_URL="http://localhost:8001"
TIMESTAMP=$(date +%s)

echo "========================================"
echo "Manager Completed Audit Count API Test"
echo "========================================"
echo ""

# Test payload - using sample data from director_test_payload.json
PAYLOAD='{
  "user_id": "AA71486",
  "manager_ids": ["AA71486"],
  "frontline_associate_ids": ["AD66122", "AD92754", "AL06193", "AL25054", "AG38776"],
  "lob": ["Commercial"],
  "start_date": "2026-03-01",
  "end_date": "2026-04-15"
}'

echo "Test Payload:"
echo "$PAYLOAD" | jq '.' 2>/dev/null || echo "$PAYLOAD"
echo ""

# Step 1: Test /manager/quality-outcomes (should cache completed_audit_count)
echo "========================================="
echo "Step 1: Testing /manager/quality-outcomes"
echo "========================================="
echo ""

QUALITY_RESPONSE=$(curl -s -X POST \
  "$BASE_URL/manager/quality-outcomes" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD")

echo "Response:"
echo "$QUALITY_RESPONSE" | jq '.' 2>/dev/null || echo "$QUALITY_RESPONSE"
echo ""

# Extract session_id and completed_audit_count
SESSION_ID=$(echo "$QUALITY_RESPONSE" | jq -r '.session_id // empty' 2>/dev/null)
COMPLETED_AUDIT_COUNT=$(echo "$QUALITY_RESPONSE" | jq -r '.completed_audit_count // .data.completed_audit_count // empty' 2>/dev/null)

if [ -z "$SESSION_ID" ]; then
  echo "❌ ERROR: No session_id returned"
  exit 1
fi

if [ -z "$COMPLETED_AUDIT_COUNT" ]; then
  echo "❌ ERROR: No completed_audit_count in response"
  exit 1
fi

echo "✅ Session ID: $SESSION_ID"
echo "✅ Completed Audit Count: $COMPLETED_AUDIT_COUNT"
echo ""

# Wait a moment for cache to settle
sleep 1

# Step 2: Test /manager/completed-audit-count-drilldown (should reuse cached count)
echo "========================================="
echo "Step 2: Testing /manager/completed-audit-count-drilldown"
echo "========================================="
echo ""

DRILLDOWN_PAYLOAD=$(echo "$PAYLOAD" | jq --arg sid "$SESSION_ID" '. + {session_id: $sid, page: 1, page_size: 20}')

echo "Drilldown Payload (with session_id):"
echo "$DRILLDOWN_PAYLOAD" | jq '.' 2>/dev/null || echo "$DRILLDOWN_PAYLOAD"
echo ""

DRILLDOWN_RESPONSE=$(curl -s -X POST \
  "$BASE_URL/manager/completed-audit-count-drilldown" \
  -H "Content-Type: application/json" \
  -d "$DRILLDOWN_PAYLOAD")

echo "Response:"
echo "$DRILLDOWN_RESPONSE" | jq '.' 2>/dev/null || echo "$DRILLDOWN_RESPONSE"
echo ""

# Extract total_records from page object
TOTAL_RECORDS=$(echo "$DRILLDOWN_RESPONSE" | jq -r '.page.total_records // .total_records // empty' 2>/dev/null)

if [ -z "$TOTAL_RECORDS" ]; then
  echo "❌ ERROR: No total_records in drilldown response"
  exit 1
fi

echo "✅ Drilldown Total Records: $TOTAL_RECORDS"
echo ""

# Step 3: Verify counts match (cache consistency)
echo "========================================="
echo "Step 3: Cache Consistency Verification"
echo "========================================="
echo ""

if [ "$COMPLETED_AUDIT_COUNT" == "$TOTAL_RECORDS" ]; then
  echo "✅ SUCCESS: Counts match!"
  echo "   quality-outcomes.completed_audit_count = $COMPLETED_AUDIT_COUNT"
  echo "   drilldown.total_records = $TOTAL_RECORDS"
else
  echo "❌ FAILURE: Counts DO NOT match!"
  echo "   quality-outcomes.completed_audit_count = $COMPLETED_AUDIT_COUNT"
  echo "   drilldown.total_records = $TOTAL_RECORDS"
  exit 1
fi
echo ""

# Step 4: Test pagination (verify consistent total_records across pages)
echo "========================================="
echo "Step 4: Testing Pagination Consistency"
echo "========================================="
echo ""

for PAGE in 1 2 3; do
  echo "Testing Page $PAGE..."
  
  PAGE_PAYLOAD=$(echo "$PAYLOAD" | jq --arg sid "$SESSION_ID" --argjson p "$PAGE" '. + {session_id: $sid, page: $p, page_size: 5}')
  
  PAGE_RESPONSE=$(curl -s -X POST \
    "$BASE_URL/manager/completed-audit-count-drilldown" \
    -H "Content-Type: application/json" \
    -d "$PAGE_PAYLOAD")
  
  PAGE_TOTAL=$(echo "$PAGE_RESPONSE" | jq -r '.page.total_records // .total_records // empty' 2>/dev/null)
  PAGE_COUNT=$(echo "$PAGE_RESPONSE" | jq -r '.records | length // .data | length // 0' 2>/dev/null)
  
  if [ "$PAGE_TOTAL" == "$COMPLETED_AUDIT_COUNT" ]; then
    echo "  ✅ Page $PAGE: total_records=$PAGE_TOTAL (consistent), records=$PAGE_COUNT"
  else
    echo "  ❌ Page $PAGE: total_records=$PAGE_TOTAL (INCONSISTENT!), expected=$COMPLETED_AUDIT_COUNT"
    exit 1
  fi
done
echo ""

# Step 5: Test without session_id (cache miss - should use COUNT query)
echo "========================================="
echo "Step 5: Testing Without session_id (Cache Miss)"
echo "========================================="
echo ""

NO_SESSION_PAYLOAD=$(echo "$PAYLOAD" | jq '. + {page: 1, page_size: 10}')

echo "Testing drilldown WITHOUT session_id..."
NO_SESSION_RESPONSE=$(curl -s -X POST \
  "$BASE_URL/manager/completed-audit-count-drilldown" \
  -H "Content-Type: application/json" \
  -d "$NO_SESSION_PAYLOAD")

NO_SESSION_TOTAL=$(echo "$NO_SESSION_RESPONSE" | jq -r '.page.total_records // .total_records // empty' 2>/dev/null)

if [ -z "$NO_SESSION_TOTAL" ]; then
  echo "❌ ERROR: No total_records in response"
  exit 1
fi

echo "✅ Count Query Total: $NO_SESSION_TOTAL"
echo ""

if [ "$NO_SESSION_TOTAL" == "$COMPLETED_AUDIT_COUNT" ]; then
  echo "✅ SUCCESS: Cache miss count matches cached count"
  echo "   (Both queries produce same result)"
else
  echo "⚠️  WARNING: Counts differ (may indicate query inconsistency)"
  echo "   Cached count: $COMPLETED_AUDIT_COUNT"
  echo "   Direct count: $NO_SESSION_TOTAL"
fi
echo ""

# Summary
echo "========================================="
echo "TEST SUMMARY"
echo "========================================="
echo ""
echo "✅ All tests passed!"
echo ""
echo "Verified:"
echo "  1. ✅ quality-outcomes caches completed_audit_count"
echo "  2. ✅ drilldown reuses cached count (total_records matches)"
echo "  3. ✅ Pagination maintains consistent total_records"
echo "  4. ✅ Cache miss fallback works (COUNT query)"
echo ""
echo "Session ID: $SESSION_ID"
echo "Completed Audit Count: $COMPLETED_AUDIT_COUNT"
echo ""
echo "Check server logs for cache hit messages:"
echo "  '✅ Reused cached completed audit count'"
echo ""
