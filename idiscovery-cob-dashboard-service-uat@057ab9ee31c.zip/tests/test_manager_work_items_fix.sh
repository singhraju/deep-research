#!/bin/bash

# Test script for Manager Work Items deduplication fix
# This verifies that the RETIME deduplication fix is working correctly

echo "================================================"
echo "Manager Work Items Deduplication Fix Test"
echo "================================================"
echo ""

# Check if server is running
echo "Checking if server is running on localhost:8001..."
if ! curl -s http://localhost:8001/health > /dev/null 2>&1; then
    echo "❌ Error: Server is not running on localhost:8001"
    echo "Please start the server first: cd /path/to/project && python -m uvicorn src.idiscovery-cob-dashboard-service:app --reload --port 8001"
    exit 1
fi

echo "✅ Server is running"
echo ""

# Run Python test script
echo "Running Python test script..."
echo ""

python3 tests/test_manager_work_items_fix.py

# Capture exit code
EXIT_CODE=$?

echo ""
echo "================================================"
if [ $EXIT_CODE -eq 0 ]; then
    echo "✅ ALL TESTS PASSED - Deduplication fix verified!"
else
    echo "❌ TESTS FAILED - Please review output above"
fi
echo "================================================"

exit $EXIT_CODE
