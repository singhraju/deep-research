#!/bin/bash

SESSION_ID="flow_test_$(date +%s)"
PAYLOAD="{\"user_id\":\"AB77504\",\"start_date\":\"2026-04-01\",\"end_date\":\"2026-04-10\",\"lob\":[\"Commercial\"],\"session_id\":\"${SESSION_ID}\"}"

echo "========================================================================"
echo "CACHE TEST - Operational Flow API"
echo "========================================================================"
echo "Session: ${SESSION_ID}"
echo ""

echo "[CALL 1] Cache Miss - Triggering Warming"
echo "------------------------------------------------------------------------"
curl -s -w "\nTime: %{time_total}s\n" -X POST "http://localhost:8001/director/operational-flow" \
  -H "Content-Type: application/json" \
  -d "${PAYLOAD}" | python3 << 'PYEOF'
import sys, json
try:
    data = json.load(sys.stdin)
    cm = data.get('cache_metadata', {}) or {}
    print(f"Status: {data.get('status')}")
    print(f"cache_hit: {cm.get('cache_hit')}")
    print(f"cache_warming: {cm.get('cache_warmin#!/bin/bash

SESSION_ID="flow_test_$(da.
SESSION_ItimPAYLOAD="{\"user_id\":\"AB77504\"nt
echo "========================================================================"
echo "CACHE TEST - Operational Flow API"
echo "======================---echo "CACHE TEST - Operational Flow API"
echo "===============================w echo "=================================p:echo "Session: ${SESSION_ID}"
echo ""

echo "[CALL 1] Cache Miss - Triggering jsecho ""

echo "[CALL 1] Cachthon3 << 'Pecho "----------------------------------------adcurl -s -w "\nTime: %{time_total}s\n" -X POST "http://localhost:8001/director/{d  -H "Content-Type: application/json" \
  -d "${PAYLOAD}" | python3 << 'PYEOF'
import sys, json
et  -d "${PAYLOAD}" | python3 << 'PYEOF'Isimport sys, json
try:
    data = json])try:
    data =f"   d_    _avg: {data.get('lead_time_a    print(f"Status: {data.get('status')}")
       print(f"cache_hit: {cm.get('cache_hit      print(f"cache_warming: {cm.get('cache_warri
SESError parsing response")
PYEOF

echo ""
echo "[CALL 3] AnSESSION_ItimPAYLOAD="{\"us--echo "========================================--echo "CACHE TEST - Operational Flow API"
echo "======================---echost:8echo "======================---echo "CACoecho "===============================w echo "=========================
iecho ""

echo "[CALL 1] Cache Miss - Triggering jsecho ""

echo "[CALL 1] Cachthon3 << 'Pecho "-------------(f
echo _hi
echo "[CALL 1] Cachthon3 << 'Pecho "----------e_a  -d "${PAYLOAD}" | python3 << 'PYEOF'
import sys, json
et  -d "${PAYLOAD}" | python3 << 'PYEOF'Isimport sys, json
try:
    data = json])t========================================"
