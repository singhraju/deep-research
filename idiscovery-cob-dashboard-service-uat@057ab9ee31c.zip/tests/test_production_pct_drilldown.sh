#!/bin/bash

# Test Production % Drilldown endpoint
# This tests the corrected PRODUCTIVETIME parsing logic in drilldown queries

echo "========================================================="
echo "Testing Manager Production % Drilldown"
echo "========================================================="
echo ""

# Test 1: First page of drilldown
echo "Test 1: Production % Drilldown - Page 1"
echo "----------------------------------------"
curl -X POST http://localhost:8001/manager/production-pct-achieved-drilldown \
  -H "Content-Type: application/json" \
  -d '{
    "screen_id": "production_pct_achieved",
    "user_id": "ROSETSC",
    "start_date": "2026-03-01",
    "end_date": "2026-04-01",
    "lob": ["Commercial"],
    "page": 1,
    "page_size": 5,
    "session_id": "test-drilldown-prod-pct"
  }' | jq '{
    status: .status,
    total_count: .page.total_count,
    current_page: .page.current_page,
    total_pages: .page.total_pages,
    records_count: (.records | length),
    sample_record: .records[0] | {
      associate: .associate,
      work_item_id: .work_item_id,
      standard_time: .standard_time,
      worktype: .worktype
    }
  }'

echo ""
echo ""

# Test 2: Check pagination
echo "Test 2: Production % Drilldown - Page 2"
echo "----------------------------------------"
curl -X POST http://localhost:8001/manager/production-pct-achieved-drilldown \
  -H "Content-Type: application/json" \
  -d '{
    "screen_id": "production_pct_achieved",
    "user_id": "ROSETSC",
    "start_date": "2026-03-01",
    "end_date": "2026-04-01",
    "lob": ["Commercial"],
    "page": 2,
    "page_size": 5
  }' | jq '{
    status: .status,
    current_page: .page.current_page,
    records_count: (.records | length)
  }'

echo ""
echo ""

# Test 3: With filters - specific associates
echo "Test 3: Production % Drilldown - With Associate Filter"
echo "-------------------------------------------------------"
curl -X POST http://localhost:8001/manager/production-pct-achieved-drilldown \
  -H "Content-Type: application/json" \
  -d '{
    "screen_id": "production_pct_achieved",
    "user_id": "ROSETSC",
    "start_date": "2026-03-01",
    "end_date": "2026-04-01",
    "lob": ["Commercial"],
    "frontline_associate_ids": ["HINERTR"],
    "page": 1,
    "page_size": 10
  }' | jq '{
    status: .status,
    total_count: .page.total_count,
    records: .records | map({
      associate: .associate,
      work_item_id: .work_item_id,
      resolved_date: .resolved_date
    })
  }'

echo ""
echo ""

# Test 4: Excel download endpoint
echo "Test 4: Production % Drilldown - Excel Download (First 100 records)"
echo "--------------------------------------------------------------------"
curl -X POST http://localhost:8001/manager/production-pct-achieved-drilldown-excel \
  -H "Content-Type: application/json" \
  -d '{
    "query": {
      "screen_id": "production_pct_achieved",
      "user_id": "ROSETSC",
      "start_date": "2026-03-01",
      "end_date": "2026-04-01",
      "lob": ["Commercial"]
    }
  }' \
  --output /tmp/production_pct_drilldown_test.xlsx

if [ -f /tmp/production_pct_drilldown_test.xlsx ]; then
  echo "✅ Excel file downloaded successfully"
  echo "File size: $(ls -lh /tmp/production_pct_drilldown_test.xlsx | awk '{print $5}')"
  echo "File location: /tmp/production_pct_drilldown_test.xlsx"
else
  echo "❌ Excel download failed"
fi

echo ""
echo "========================================================="
echo "Tests Complete"
echo "========================================================="
