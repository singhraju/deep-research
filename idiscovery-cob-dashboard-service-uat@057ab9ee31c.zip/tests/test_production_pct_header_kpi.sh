#!/bin/bash

# Test Production % in Manager Header KPIs endpoint
# This tests the corrected PRODUCTIVETIME parsing logic

echo "=========================================="
echo "Testing Manager Header KPI - Production %"
echo "=========================================="
echo ""

# Test with sample manager request
echo "Test 1: Manager Header KPIs with date range"
echo "--------------------------------------------"
curl -X POST http://localhost:8001/manager/header-kpis \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "ROSETSC",
    "start_date": "2026-03-01",
    "end_date": "2026-04-01",
    "lob": ["Commercial"],
    "session_id": "test-session-prod-pct"
  }' | jq '.data.production_pct_achieved'

echo ""
echo ""

# Test with different date range
echo "Test 2: Manager Header KPIs - Different Date Range"
echo "---------------------------------------------------"
curl -X POST http://localhost:8001/manager/header-kpis \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "ROSETSC",
    "start_date": "2026-03-15",
    "end_date": "2026-03-25",
    "lob": ["Commercial"]
  }' | jq '{
    production_pct: .data.production_pct_achieved,
    status: .status,
    message: .message
  }'

echo ""
echo ""

# Test with full response to see all KPIs
echo "Test 3: Full Header KPI Response"
echo "---------------------------------"
curl -X POST http://localhost:8001/manager/header-kpis \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "ROSETSC",
    "start_date": "2026-03-01",
    "end_date": "2026-04-01",
    "lob": ["Commercial"]
  }' | jq '{
    status: .status,
    data: {
      production_pct: .data.production_pct_achieved,
      work_items_completed: .data.work_items_completed,
      audit_score: .data.audit_score_percentage
    }
  }'

echo ""
echo "=========================================="
echo "Tests Complete"
echo "=========================================="
