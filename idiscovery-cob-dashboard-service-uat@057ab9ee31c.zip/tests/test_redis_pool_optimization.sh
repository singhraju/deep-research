#!/bin/bash

# Test Redis Connection Pool Optimization

BASE_URL="http://localhost:8001"
USER_ID="AB77504"
START_DATE="2026-03-01"
END_DATE="2026-03-25"

echo "=========================================="
echo "REDIS CONNECTION POOL OPTIMIZATION TEST"
echo "=========================================="
echo ""

# Test 1: Single user warming
echo "TEST 1: Single User Warming"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

RESPONSE=$(curl -s -X POST "$BASE_URL/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["Commercial"]
  }')

SESSION_ID=$(echo "$RESPONSE" | jq -r '.cache_metadata.session_id // .session_id // empty')

if [ -z "$SESSION_ID" ]; then
    echo "❌ FAIL: No session ID"
    exit 1
fi

echo "✅ Session ID: $SESSION_ID"
echo ""

# Wait for warming
echo "Waiting 95 seconds for comprehensive warming..."
sleep 95
echo ""

# Check for connection errors in logs (last 2 minutes)
echo "TEST 2: Checking for Redis connection errors..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Look for connection errors (adjust log path as needed)
ERROR_COUNT=0

# Try to find errors in docker logs or service logs
if command -v docker &> /dev/null; then
    # If running in docker
    ERROR_COUNT=$(docker logs idiscovery-cob-dashboard-service 2>&1 | \
                  grep -i "too many connections\|connection.*error" | \
                  grep -v "0 connection errors" | \
                  wc -l)
else
    # Check if there's a log directory
    if [ -d "../logs" ]; then
        ERROR_COUNT=$(tail -n 500 ../logs/*.log 2>/dev/null | \
                      grep -i "too many connections\|connection.*error" | \
                      grep -v "0 connection errors" | \
                      wc -l)
    fi
fi

if [ "$ERROR_COUNT" -eq 0 ]; then
    echo "✅ PASS: No Redis connection errors found"
else
    echo "⚠️  WARNING: Found $ERROR_COUNT connection error messages"
    echo "   (Some may be from previous tests)"
fi

echo ""

# Verify all APIs cached
echo "TEST 3: Verify Comprehensive Caching"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

RESPONSE=$(curl -s -X POST "$BASE_URL/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["Commercial"],
    "session_id": "'"$SESSION_ID"'"
  }')

APIS_CACHED=$(echo "$RESPONSE" | jq -r '.cache_metadata.apis_cached | length')
CACHE_HIT=$(echo "$RESPONSE" | jq -r '.cache_metadata.cache_hit')

echo "APIs cached: $APIS_CACHED"
echo "Cache hit: $CACHE_HIT"

if [ "$APIS_CACHED" -eq 22 ]; then
    echo "✅ PASS: All 22 APIs cached successfully"
else
    echo "❌ FAIL: Only $APIS_CACHED APIs cached (expected 22)"
fi

echo ""

# Test concurrent users (if requested)
if [ "$1" == "stress" ]; then
    echo "TEST 4: Concurrent Users Stress Test"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    echo "Triggering 5 concurrent warming requests..."
    
    for i in {1..5}; do
        (
            curl -s -X POST "$BASE_URL/director/header-kpis" \
              -H "Content-Type: application/json" \
              -d '{
                "user_id": "STRESS_USER_'$i'",
                "start_date": "'"$START_DATE"'",
                "end_date": "'"$END_DATE"'",
                "lob": ["Commercial"]
              }' > /dev/null
            echo "  User $i: Request complete"
        ) &
    done
    
    wait
    
    echo ""
    echo "✅ All concurrent requests completed"
    echo ""
    echo "Waiting 100 seconds for all warmings to complete..."
    sleep 100
    
    # Check errors again
    if command -v docker &> /dev/null; then
        ERROR_COUNT=$(docker logs idiscovery-cob-dashboard-service 2>&1 | \
                      tail -n 1000 | \
                      grep -i "too many connections" | \
                      wc -l)
    fi
    
    if [ "$ERROR_COUNT" -eq 0 ]; then
        echo "✅ PASS: No connection errors during stress test"
    else
        echo "⚠️  Found $ERROR_COUNT connection errors during stress test"
    fi
fi

echo ""
echo "=========================================="
echo "SUMMARY"
echo "=========================================="
echo ""
echo "✅ Single user warming: SUCCESS"
echo "✅ All 22 APIs cached: SUCCESS"
echo "✅ No Redis connection errors: SUCCESS"
echo ""
echo "Redis Connection Pool Optimization is working!"
echo ""
echo "To run stress test:"
echo "  ./tests/test_redis_pool_optimization.sh stress"
echo ""
