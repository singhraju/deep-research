#!/bin/bash
# Test Redis implementation in different scenarios

set -e

echo "======================================"
echo "Redis Implementation Testing Script"
echo "======================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "ℹ️  $1"
}

# Function to check if Redis is running
check_redis() {
    if command -v docker &> /dev/null; then
        if docker ps | grep -q redis-local; then
            return 0
        fi
    fi
    return 1
}

# Function to start Redis with Docker
start_redis() {
    echo ""
    print_info "Starting Redis with Docker..."
    
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed. Please install Docker Desktop."
        print_info "Download from: https://www.docker.com/products/docker-desktop"
        return 1
    fi
    
    # Remove existing container if exists
    docker rm -f redis-local 2>/dev/null || true
    
    # Start Redis
    docker run --name redis-local -p 6379:6379 -d redis:latest
    
    # Wait for Redis to be ready
    sleep 2
    
    # Test connection
    if docker exec redis-local redis-cli ping | grep -q PONG; then
        print_success "Redis started successfully!"
        return 0
    else
        print_error "Redis started but not responding"
        return 1
    fi
}

# Function to stop Redis
stop_redis() {
    echo ""
    print_info "Stopping Redis..."
    docker rm -f redis-local 2>/dev/null || true
    print_success "Redis stopped"
}

# Menu
show_menu() {
    echo ""
    echo "Choose a test scenario:"
    echo ""
    echo "1) Test WITHOUT Redis (graceful degradation)"
    echo "2) Test WITH Redis (Docker required)"
    echo "3) Run unit tests (mock Redis)"
    echo "4) Start Redis for manual testing"
    echo "5) Stop Redis"
    echo "6) Monitor Redis keys"
    echo "7) Clear Redis cache"
    echo "0) Exit"
    echo ""
    read -p "Enter choice [0-7]: " choice
}

# Test without Redis
test_without_redis() {
    echo ""
    print_info "Testing WITHOUT Redis (graceful degradation)..."
    echo ""
    
    # Export env vars
    export REDIS_ENABLED=false
    export SESSION_CACHE_ENABLED=false
    
    print_info "Environment:"
    echo "  REDIS_ENABLED=false"
    echo "  SESSION_CACHE_ENABLED=false"
    echo ""
    
    print_info "This mode:"
    echo "  ✅ APIs work with direct DB queries"
    echo "  ✅ No caching overhead"
    echo "  ✅ Slower response times (2-5 seconds)"
    echo "  ❌ No cache warming"
    echo "  ❌ No session consistency"
    echo ""
    
    print_success "Ready to test! Start your service:"
    echo "  python src/idiscovery-cob-dashboard-service.py"
    echo ""
    
    print_info "Example API call:"
    echo '  curl -X POST http://localhost:8000/cobdashboard/v1/director/header-kpis \\'
    echo '    -H "Content-Type: application/json" \\'
    echo '    -d '"'"'{"lob": ["Commercial"], "start_date": "2024-01-01", "end_date": "2024-01-31"}'"'"
    echo ""
}

# Test with Redis
test_with_redis() {
    echo ""
    print_info "Testing WITH Redis..."
    echo ""
    
    # Check/start Redis
    if ! check_redis; then
        print_warning "Redis not running. Starting..."
        if ! start_redis; then
            print_error "Failed to start Redis"
            return 1
        fi
    else
        print_success "Redis is already running"
    fi
    
    # Export env vars
    export REDIS_ENABLED=true
    export SESSION_CACHE_ENABLED=true
    export REDIS_HOST=localhost
    export REDIS_PORT=6379
    
    print_info "Environment:"
    echo "  REDIS_ENABLED=true"
    echo "  SESSION_CACHE_ENABLED=true"
    echo "  REDIS_HOST=localhost"
    echo "  REDIS_PORT=6379"
    echo ""
    
    print_info "This mode:"
    echo "  ✅ Full caching enabled"
    echo "  ✅ Session-based consistency"
    echo "  ✅ Fast cache hits (<500ms)"
    echo "  ✅ Cache warming supported"
    echo ""
    
    print_success "Ready to test! Start your service:"
    echo "  python src/idiscovery-cob-dashboard-service.py"
    echo ""
    
    print_info "Example API calls:"
    echo ""
    echo "First call (cache miss):"
    echo '  curl -X POST http://localhost:8000/cobdashboard/v1/director/header-kpis \\'
    echo '    -H "Content-Type: application/json" \\'
    echo '    -d '"'"'{"lob": ["Commercial"], "start_date": "2024-01-01", "end_date": "2024-01-31", "session_id": "test123"}'"'"
    echo ""
    echo "Second call (cache hit - should be fast!):"
    echo '  curl -X POST http://localhost:8000/cobdashboard/v1/director/header-kpis \\'
    echo '    -H "Content-Type: application/json" \\'
    echo '    -d '"'"'{"lob": ["Commercial"], "start_date": "2024-01-01", "end_date": "2024-01-31", "session_id": "test123"}'"'"
    echo ""
}

# Run unit tests
run_unit_tests() {
    echo ""
    print_info "Running unit tests with mocked Redis..."
    echo ""
    
    if ! command -v pytest &> /dev/null; then
        print_warning "pytest not installed. Installing..."
        pip install pytest pytest-asyncio
    fi
    
    cd "$(dirname "$0")/.."
    python tests/test_without_redis.py
    
    echo ""
    print_success "Unit tests completed!"
    echo ""
}

# Monitor Redis
monitor_redis() {
    echo ""
    print_info "Monitoring Redis keys..."
    echo ""
    
    if ! check_redis; then
        print_error "Redis is not running. Start it first (option 4)."
        return 1
    fi
    
    echo "All session keys:"
    docker exec redis-local redis-cli KEYS "session:*"
    
    echo ""
    echo "Redis info:"
    docker exec redis-local redis-cli INFO keyspace
    
    echo ""
    print_info "Press Ctrl+C to stop monitoring"
    echo ""
    docker exec -it redis-local redis-cli MONITOR
}

# Clear Redis cache
clear_cache() {
    echo ""
    print_info "Clearing Redis cache..."
    echo ""
    
    if ! check_redis; then
        print_error "Redis is not running."
        return 1
    fi
    
    # Count keys before
    before=$(docker exec redis-local redis-cli KEYS "session:*" | wc -l)
    
    # Clear all session keys
    docker exec redis-local redis-cli --eval - session:* , <<'EOF'
for _,k in ipairs(redis.call('keys', ARGV[1] .. '*')) do
    redis.call('del', k)
end
EOF
    
    # Count keys after
    after=$(docker exec redis-local redis-cli KEYS "session:*" | wc -l)
    
    print_success "Deleted $before session keys"
    echo ""
}

# Main loop
main() {
    while true; do
        show_menu
        
        case $choice in
            1)
                test_without_redis
                ;;
            2)
                test_with_redis
                ;;
            3)
                run_unit_tests
                ;;
            4)
                start_redis
                ;;
            5)
                stop_redis
                ;;
            6)
                monitor_redis
                ;;
            7)
                clear_cache
                ;;
            0)
                echo ""
                print_info "Exiting..."
                
                # Ask if should stop Redis
                if check_redis; then
                    read -p "Stop Redis before exiting? (y/n): " stop_choice
                    if [[ $stop_choice == "y" ]]; then
                        stop_redis
                    fi
                fi
                
                exit 0
                ;;
            *)
                print_error "Invalid choice. Please try again."
                ;;
        esac
        
        read -p "Press Enter to continue..."
    done
}

# Run main
main
