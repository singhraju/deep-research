#!/bin/bash

# Session Cache Validation Test
# Tests the refactored session cache with direct function calls (no HTTP overhead)

echo "=============================================="
echo "Session Cache Validation Test"
echo "=============================================="
echo ""

# Configuration
BASE_URL="http://localhost:8001"
SESSION_ID="test_session_$(date +%s)"

echo "📋 Test Configuration:"
echo "  - Base URL: ${BASE_URL}"
echo "  - Session ID: ${SESSION_ID}"
echo "  - Test User: AB77504"
echo "  - Date Range: 2026-03-01 to 2026-03-25"
echo "  - LOB: Commercial"
echo ""

# Test 1: Health Check
echo "=============================================="
echo "Test 1: Health Check"
echo "=============================================="
HEALTH=$(curl -s ${BASE_URL}/health)
echo "$HEALTH" | jq '.'
if echo "$HEALTH" | jq -e '.status == "ok"' > /dev/null; then
    echo "✅ Server is healthy"
else
    echo "❌ Server health check failed"
    exit 1
fi
echo ""

# Test 2: First API Call (Cache Miss - Triggers Warming)
echo "=============================================="
echo "Test 2: First Call - Cache Miss"
echo "=============================================="
echo "Calling /director/header-kpis with session_id..."
echo ""

FIRST_CALL=$(curl -s -X POST ${BASE_URL}/director/header-kpis \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\"
  }")

echo "Response Summary:"
echo "$FIRST_CALL" | jq '{
  work_items_completed,
  production_pct_achieved,
  audit_score_avg,
  cache_metadata
}'

# Validate first call
CACHE_HIT=$(echo "$FIRST_CALL" | jq -r '.cache_metadata.cache_hit')
if [ "$CACHE_HIT" == "false" ]; then
    echo "✅ Cache miss detected (expected)"
else
    echo "❌ Expected cache miss, got cache hit"
fi

CACHE_WARMING=$(echo "$FIRST_CALL" | jq -r '.cache_metadata.cache_warming')
if [ "$CACHE_WARMING" == "true" ]; then
    echo "✅ Cache warming triggered"
else
    echo "⚠️  Cache warming not triggered"
fi
echo ""

# Wait for cache warming to complete
echo "⏳ Waiting 10 seconds for background cache warming..."
sleep 10
echo ""

# Test 3: Second API Call (Cache Hit)
echo "=============================================="
echo "Test 3: Second Call - Cache Hit"
echo "=============================================="
echo "Calling /director/header-kpis with same session_id..."
echo ""

SECOND_CALL=$(curl -s -X POST ${BASE_URL}/director/header-kpis \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\"
  }")

echo "Response Summary:"
echo "$SECOND_CALL" | jq '{
  work_items_completed,
  production_pct_achieved,
  audit_score_avg,
  cache_metadata
}'

# Validate second call
CACHE_HIT2=$(echo "$SECOND_CALL" | jq -r '.cache_metadata.cache_hit')
if [ "$CACHE_HIT2" == "true" ]; then
    echo "✅ Cache hit confirmed"
else
    echo "❌ Expected cache hit, got cache miss"
fi

APIS_CACHED=$(echo "$SECOND_CALL" | jq -r '.cache_metadata.apis_cached | length')
echo "✅ APIs Cached: ${APIS_CACHED}/6"

CACHED_LIST=$(echo "$SECOND_CALL" | jq -r '.cache_metadata.apis_cached[]')
echo ""
echo "Cached APIs:"
echo "$CACHED_LIST" | while read api; do
    echo "  ✓ $api"
done
echo ""

# Test 4: Verify All 6 Core APIs
echo "=============================================="
echo "Test 4: Verify All 6 Core APIs Cached"
echo "=============================================="

EXPECTED_APIS=("header-kpis" "operational-flow" "demand-inventory" "quality-outcomes" "associate-utilization" "sla-health")
ALL_CACHED=true

for api in "${EXPECTED_APIS[@]}"; do
    if echo "$CACHED_LIST" | grep -q "$api"; then
        echo "  ✅ $api"
    else
        echo "  ❌ $api (MISSING)"
        ALL_CACHED=false
    fi
done
echo ""

if [ "$ALL_CACHED" == "true" ]; then
    echo "✅ All 6 core APIs successfully cached"
else
    echo "❌ Some APIs missing from cache"
fi
echo ""

# Test 5: Test Another Core API (should also be cache hit)
echo "=============================================="
echo "Test 5: Test operational-flow (Cache Hit)"
echo "=============================================="

OPERATIONAL_FLOW=$(curl -s -X POST ${BASE_URL}/director/operational-flow \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\"
  }")

OP_CACHE_HIT=$(echo "$OPERATIONAL_FLOW" | jq -r '.cache_metadata.cache_hit')
echo "operational-flow cache_hit: ${OP_CACHE_HIT}"

if [ "$OP_CACHE_HIT" == "true" ]; then
    echo "✅ operational-flow returned from cache"
else
    echo "❌ operational-flow cache miss (unexpected)"
fi
echo ""

# Final Summary
echo "=============================================="
echo "Test Summary"
echo "=============================================="
echo "Session ID: ${SESSION_ID}"
echo ""
echo "Results:"
if [ "$CACHE_HIT" == "false" ] && [ "$CACHE_HIT2" == "true" ] && [ "$ALL_CACHED" == "true" ] && [ "$OP_CACHE_HIT" == "true" ]; then
    echo "✅ ALL TESTS PASSED"
    echo ""
    echo "Session cache is working correctly:"
    echo "  ✓ First call triggers cache warming"
    echo "  ✓ All 6 APIs cached successfully"
    echo "  ✓ Subsequent calls return from cache"
    echo "  ✓ No 404 errors (direct function calls working)"
    echo ""
    echo "🎉 Session Cache Refactor: SUCCESS!"
else
    echo "❌ SOME TESTS FAILED"
    echo "Review the output above for details"
fi
echo ""
echo "=============================================="
