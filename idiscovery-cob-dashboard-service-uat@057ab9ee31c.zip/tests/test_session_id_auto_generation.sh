#!/bin/bash

# Test: Verify Session ID Auto-Generation
# Tests that when session_id is missing, it is automatically generated

echo "=============================================="
echo "Session ID Auto-Generation Test"
echo "=============================================="
echo ""

BASE_URL="http://localhost:8001"

echo "📋 Test Objective:"
echo "  - Verify session_id is auto-generated when missing from payload"
echo "  - Verify auto-generated session_id is returned in response"
echo "  - Verify cache warming works with auto-generated session_id"
echo ""

# Test 1: Call API WITHOUT session_id
echo "=============================================="
echo "Test 1: Call API Without session_id"
echo "=============================================="
echo "Expected: session_id should be auto-generated"
echo ""

RESPONSE=$(curl -s -X POST ${BASE_URL}/director/header-kpis \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": ["Commercial"]
  }')

echo "Response:"
echo "$RESPONSE" | jq '{
  work_items_completed,
  cache_metadata
}'

SESSION_ID=$(echo "$RESPONSE" | jq -r '.cache_metadata.session_id')
echo ""
echo "Auto-generated session_id: ${SESSION_ID}"

if [ "$SESSION_ID" != "null" ] && [ ! -z "$SESSION_ID" ]; then
    echo "✅ session_id was auto-generated"
    
    # Check format: session_{timestamp}_{hash}
    if [[ $SESSION_ID == session_* ]]; then
        echo "✅ session_id has correct format: session_*"
    else
        echo "❌ session_id format is incorrect: ${SESSION_ID}"
    fi
else
    echo "❌ session_id was NOT auto-generated"
    exit 1
fi
echo ""

# Test 2: Use the auto-generated session_id in a second call
echo "=============================================="
echo "Test 2: Use Auto-Generated session_id"
echo "=============================================="
echo "Expected: Should use existing cache"
echo ""

# Wait for warming
echo "⏳ Waiting 10 seconds for cache warming..."
sleep 10
echo ""

RESPONSE2=$(curl -s -X POST ${BASE_URL}/director/header-kpis \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${SESSION_ID}\"
  }")

echo "Response with same session_id:"
echo "$RESPONSE2" | jq '{
  work_items_completed,
  cache_metadata
}'

CACHE_HIT=$(echo "$RESPONSE2" | jq -r '.cache_metadata.cache_hit')
APIS_CACHED=$(echo "$RESPONSE2" | jq -r '.cache_metadata.apis_cached | length')

echo ""
if [ "$CACHE_HIT" == "true" ]; then
    echo "✅ Cache hit confirmed with auto-generated session_id"
    echo "✅ APIs Cached: ${APIS_CACHED}/6"
else
    echo "❌ Cache miss (expected cache hit)"
fi
echo ""

# Test 3: Different API with NO session_id (should get NEW auto-generated ID)
echo "=============================================="
echo "Test 3: Different Call Without session_id"
echo "=============================================="
echo "Expected: NEW session_id should be auto-generated"
echo ""

RESPONSE3=$(curl -s -X POST ${BASE_URL}/director/operational-flow \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "AB77504",
    "start_date": "2026-03-01",
    "end_date": "2026-03-25",
    "lob": ["Commercial"]
  }')

NEW_SESSION_ID=$(echo "$RESPONSE3" | jq -r '.cache_metadata.session_id')
echo "New auto-generated session_id: ${NEW_SESSION_ID}"

if [ "$NEW_SESSION_ID" != "$SESSION_ID" ] && [ "$NEW_SESSION_ID" != "null" ]; then
    echo "✅ New session_id auto-generated (different from first)"
else
    echo "⚠️  Same session_id or null"
fi
echo ""

# Test 4: Explicit session_id should NOT be overridden
echo "=============================================="
echo "Test 4: Explicit session_id Not Overridden"
echo "=============================================="
echo "Expected: Provided session_id should be used"
echo ""

EXPLICIT_SESSION="my_custom_session_123"

RESPONSE4=$(curl -s -X POST ${BASE_URL}/director/header-kpis \
  -H "Content-Type: application/json" \
  -d "{
    \"user_id\": \"AB77504\",
    \"start_date\": \"2026-03-01\",
    \"end_date\": \"2026-03-25\",
    \"lob\": [\"Commercial\"],
    \"session_id\": \"${EXPLICIT_SESSION}\"
  }")

RETURNED_SESSION=$(echo "$RESPONSE4" | jq -r '.cache_metadata.session_id')
echo "Provided session_id: ${EXPLICIT_SESSION}"
echo "Returned session_id: ${RETURNED_SESSION}"

if [ "$RETURNED_SESSION" == "$EXPLICIT_SESSION" ]; then
    echo "✅ Explicit session_id was preserved (not overridden)"
else
    echo "❌ Session_id was overridden (should preserve user-provided value)"
fi
echo ""

# Summary
echo "=============================================="
echo "Test Summary"
echo "=============================================="
echo ""
echo "Session ID Auto-Generation:"
echo "  Format: session_{timestamp}_{random_hash}"
echo "  Example: session_1775821614_abc123def"
echo ""
echo "Behavior:"
echo "  1. No session_id in payload → Auto-generated ✅"
echo "  2. Auto-generated ID triggers warming ✅"
echo "  3. Auto-generated ID can be reused ✅"
echo "  4. Explicit session_id preserved ✅"
echo ""

if [ "$SESSION_ID" != "null" ] && [[ $SESSION_ID == session_* ]] && [ "$CACHE_HIT" == "true" ] && [ "$RETURNED_SESSION" == "$EXPLICIT_SESSION" ]; then
    echo "✅ ALL TESTS PASSED"
    echo ""
    echo "Auto-generation working correctly:"
    echo "  ✓ session_id auto-generated when missing"
    echo "  ✓ Correct format (session_{timestamp}_{hash})"
    echo "  ✓ Cache warming triggered"
    echo "  ✓ Explicit session_id not overridden"
else
    echo "❌ SOME TESTS FAILED"
    echo "Review the output above for details"
fi
echo ""
echo "=============================================="
