#!/usr/bin/env python3
"""Quick test to see actual API response structure"""

import requests
import json

payload = {
    "user_id": "AB77504",
    "start_date": "2026-04-01",
    "end_date": "2026-04-10",
    "lob": ["Commercial"],
    "director_ids": ["AF32384"],
    "manager_ids": ["AH79824"],
    "frontline_associate_ids": ["AL89026"],
    "session_id": "session_test_123"
}

# Test operational flow (working)
print("=" * 80)
print("Testing: /director/operational-flow")
print("=" * 80)
response = requests.post("http://localhost:8001/director/operational-flow", json=payload)
print(f"Status Code: {response.status_code}")
if response.status_code == 200:
    data = response.json()
    print(f"Response keys: {list(data.keys())}")
    print(f"\nFull response (first 500 chars):")
    print(json.dumps(data, indent=2)[:500])
else:
    print(f"Error: {response.text}")

print("\n\n")

# Test header kpis (failing)
print("=" * 80)
print("Testing: /director/header-kpis")
print("=" * 80)
response = requests.post("http://localhost:8001/director/header-kpis", json=payload)
print(f"Status Code: {response.status_code}")
if response.status_code == 200:
    data = response.json()
    print(f"Response keys: {list(data.keys())}")
    print(f"\nFull response (first 500 chars):")
    print(json.dumps(data, indent=2)[:500])
else:
    print(f"Error: {response.text}")
