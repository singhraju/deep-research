#!/usr/bin/env python3
"""
FINAL SQL Validation - Exact Match Test

This validates the FIXED queries using EXACT same CTEs and joins as production code.
"""

import sys
import os

project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'src'))

from src.db.connection_manager import connection_manager
from src.config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from datetime import datetime, timedelta

TEST_START_DATE = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')
TEST_END_DATE = datetime.now().strftime('%Y-%m-%d')

print("=" * 80)
print("FINAL VALIDATION - EXACT MATCH TEST")
print("=" * 80)

engine = connection_manager.get_engine()

# EXACT COUNT Query from quality_outcomes.py
COUNT_QUERY_EXACT = f"""
WITH audit_deduped AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND PXCREATEDATETIME IS NOT NULL
      AND DATE(PXCREATEDATETIME) >= '{TEST_START_DATE}'
      AND DATE(PXCREATEDATETIME) <= '{TEST_END_DATE}'
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        AND DATE(PXCREATEDATETIME) >= '{TEST_START_DATE}'
        AND DATE(PXCREATEDATETIME) <= '{TEST_END_DATE}'
),
audit_with_manager AS (
    SELECT
        a.PYID,
        a.AUDIT_SUBJECT_ID
    FROM audit_deduped a
    INNER JOIN associate_hierarchy ah
        ON a.CASE_TO_AUDIT = ah.PYID
        AND ah.rn = 1
    WHERE a.rn = 1
),
rebuttal_details AS (
    SELECT
        act.CASEID,
        act.ERRORCATEGORYTYPE,
        act.ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY act.CASEID, act.ERRORCATEGORYTYPE, act.ERRORCATEGORY
            ORDER BY act.PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY act
    WHERE act.CASEID LIKE 'AUD%'
      AND act.ERRORCATEGORYTYPE IS NOT NULL
      AND act.ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_audit_cases
FROM audit_with_manager awm
INNER JOIN rebuttal_details rd
    ON awm.PYID = rd.CASEID
    AND rd.rn = 1
"""

# EXACT FIXED PAGINATED Query
PAGINATED_QUERY_EXACT = f"""
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        DATE(PXCREATEDATETIME) AS resolved_date,
        PLATFORM,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'  -- ✅ FIX 1
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND PXCREATEDATETIME IS NOT NULL
      AND DATE(PXCREATEDATETIME) >= '{TEST_START_DATE}'
      AND DATE(PXCREATEDATETIME) <= '{TEST_END_DATE}'
),
associate_hierarchy AS (
    SELECT
        PYID,
        ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
    WHERE 1=1
        AND DATE(PXCREATEDATETIME) >= '{TEST_START_DATE}'
        AND DATE(PXCREATEDATETIME) <= '{TEST_END_DATE}'
),
deduped_user_profile AS (
    SELECT
        USERID,
        TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
        ROW_NUMBER() OVER (
            PARTITION BY USERID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORY,
        ERRORCATEGORYTYPE,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY  -- ✅ FIX 3
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'            -- ✅ FIX 2
      AND ERRORCATEGORYTYPE IS NOT NULL  -- ✅ FIX 2
      AND ERRORCATEGORY IS NOT NULL      -- ✅ FIX 2
)
SELECT COUNT(*) as total_records
FROM deduped_audit a
INNER JOIN associate_hierarchy ah
    ON a.CASE_TO_AUDIT = ah.PYID
    AND ah.rn = 1
INNER JOIN deduped_user_profile u
    ON a.AUDIT_SUBJECT_ID = u.USERID
    AND u.rn = 1
LEFT JOIN deduped_audit_activity aa
    ON a.PYID = aa.CASEID
    AND aa.rn = 1
WHERE a.rn = 1
  AND u.rn = 1
"""

print("\n🔍 Running EXACT COUNT Query (from quality_outcomes.py)...")
try:
    count_result = engine.execute_query(COUNT_QUERY_EXACT, limit=1)
    if count_result:
        count_row = count_result[0]
        rebuttal_count = count_row.get('REBUTTAL_COUNT', 0)
        unique_cases = count_row.get('UNIQUE_AUDIT_CASES', 0)
        print("✓ COUNT Query Results:")
        print(f"  Rebuttal Count (error combinations): {rebuttal_count}")
        print(f"  Unique Audit Cases: {unique_cases}")
except Exception as e:
    print(f"❌ Error: {e}")
    rebuttal_count = 0

print("\n🔍 Running EXACT FIXED PAGINATED Query (from rebuttal_drilldown.py)...")
try:
    paginated_result = engine.execute_query(PAGINATED_QUERY_EXACT, limit=1)
    if paginated_result:
        paginated_row = paginated_result[0]
        drilldown_count = paginated_row.get('TOTAL_RECORDS', 0)
        print("✓ PAGINATED Query Results:")
        print(f"  Drilldown Records: {drilldown_count}")
except Exception as e:
    print(f"❌ Error: {e}")
    drilldown_count = 0

print("\n" + "=" * 80)
print("FINAL COMPARISON")
print("=" * 80)
print(f"\nDashboard Count: {rebuttal_count} error combinations")
print(f"Drilldown Records: {drilldown_count} records")

if rebuttal_count == drilldown_count:
    print(f"\n🎉 ✅ PERFECT MATCH!")
    print("  All fixes working correctly")
    print("  Queries are perfectly aligned")
else:
    diff = abs(rebuttal_count - drilldown_count)
    pct = (diff / rebuttal_count * 100) if rebuttal_count > 0 else 0
    print(f"\n⚠️ Difference: {diff} records ({pct:.1f}%)")
    print("\nPossible causes:")
    print("  1. LEFT JOIN vs INNER JOIN behavior")
    print("  2. Audits with no matching error details")
    print("  3. User profile join filtering")
    
    # Diagnostic query
    print("\n🔍 Running diagnostic to find the cause...")
    
    DIAGNOSTIC_QUERY = f"""
    WITH audit_with_errors AS (
        SELECT DISTINCT CASEID
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
        WHERE CASEID LIKE 'AUD%'
          AND ERRORCATEGORYTYPE IS NOT NULL
          AND ERRORCATEGORY IS NOT NULL
    ),
    audit_with_manager AS (
        SELECT DISTINCT a.PYID
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE a
        INNER JOIN {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE ah
            ON a.CASE_TO_AUDIT = ah.PYID
        WHERE a.REBUTTALFLAG = 'Y'
          AND a.PYID LIKE 'AUD%'
          AND a.PYSTATUSWORK = 'Resolved-Completed'
          AND DATE(a.PXCREATEDATETIME) >= '{TEST_START_DATE}'
          AND DATE(a.PXCREATEDATETIME) <= '{TEST_END_DATE}'
    )
    SELECT
        COUNT(DISTINCT awm.PYID) as audits_with_manager,
        COUNT(DISTINCT awe.CASEID) as audits_with_errors,
        COUNT(DISTINCT CASE WHEN awe.CASEID IS NOT NULL THEN awm.PYID ELSE NULL END) as both
    FROM audit_with_manager awm
    LEFT JOIN audit_with_errors awe ON awm.PYID = awe.CASEID
    """
    
    try:
        diag_result = engine.execute_query(DIAGNOSTIC_QUERY, limit=1)
        if diag_result:
            diag = diag_result[0]
            print(f"\n  Audits with manager: {diag.get('AUDITS_WITH_MANAGER', 0)}")
            print(f"  Audits with error details: {diag.get('AUDITS_WITH_ERRORS', 0)}")
            print(f"  Audits with both: {diag.get('BOTH', 0)}")
    except Exception as e:
        print(f"  Diagnostic error: {e}")

print("\n" + "=" * 80)
