#!/usr/bin/env python3
"""
Comprehensive SQL Validation - Multiple Scenarios

Tests FIXED queries across:
- Multiple date ranges (7d, 30d, 60d, 90d, 180d, 1y)
- Different LOB filters (Commercial, Government, Both, None)
- Edge cases and combinations

This ensures fixes work across all real-world scenarios.
"""

import sys
import os
from datetime import datetime, timedelta

project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'src'))

from src.db.connection_manager import connection_manager
from src.config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA

print("=" * 100)
print("COMPREHENSIVE SQL VALIDATION - MULTIPLE SCENARIOS")
print("=" * 100)

engine = connection_manager.get_engine()

def build_lob_filter(lob_list):
    """Build LOB filter SQL"""
    if not lob_list:
        return ""
    
    if len(lob_list) == 1:
        return f"AND LOB = '{lob_list[0]}'"
    else:
        lob_values = "','".join(lob_list)
        return f"AND LOB IN ('{lob_values}')"

def run_validation(test_name, start_date, end_date, lob_filter_sql="", lob_filter_label="All LOBs"):
    """Run validation for specific scenario"""
    
    # COUNT Query
    COUNT_QUERY = f"""
    WITH audit_deduped AS (
        SELECT
            PYID,
            CASE_TO_AUDIT,
            REBUTTALFLAG,
            PXCREATEDATETIME,
            DATE(PXCREATEDATETIME) AS created_date,
            LOB,
            AUDITOR_ID,
            AUDIT_SUBJECT_ID,
            ROW_NUMBER() OVER (
                PARTITION BY PYID
                ORDER BY PXUPDATEDATETIME DESC
            ) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
        WHERE REBUTTALFLAG = 'Y'
          AND PYID LIKE 'AUD%'
          AND PYSTATUSWORK = 'Resolved-Completed'
          AND PXCREATEDATETIME IS NOT NULL
          AND DATE(PXCREATEDATETIME) >= '{start_date}'
          AND DATE(PXCREATEDATETIME) <= '{end_date}'
          {lob_filter_sql}
    ),
    associate_hierarchy AS (
        SELECT
            PYID,
            ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        WHERE 1=1
            AND DATE(PXCREATEDATETIME) >= '{start_date}'
            AND DATE(PXCREATEDATETIME) <= '{end_date}'
    ),
    audit_with_manager AS (
        SELECT
            a.PYID,
            a.AUDIT_SUBJECT_ID
        FROM audit_deduped a
        INNER JOIN associate_hierarchy ah
            ON a.CASE_TO_AUDIT = ah.PYID
            AND ah.rn = 1
        WHERE a.rn = 1
    ),
    rebuttal_details AS (
        SELECT
            act.CASEID,
            act.ERRORCATEGORYTYPE,
            act.ERRORCATEGORY,
            ROW_NUMBER() OVER (
                PARTITION BY act.CASEID, act.ERRORCATEGORYTYPE, act.ERRORCATEGORY
                ORDER BY act.PXUPDATEDATETIME DESC
            ) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY act
        WHERE act.CASEID LIKE 'AUD%'
          AND act.ERRORCATEGORYTYPE IS NOT NULL
          AND act.ERRORCATEGORY IS NOT NULL
    )
    SELECT
        COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
        COUNT(DISTINCT rd.CASEID) AS unique_audit_cases
    FROM audit_with_manager awm
    INNER JOIN rebuttal_details rd
        ON awm.PYID = rd.CASEID
        AND rd.rn = 1
    """
    
    # PAGINATED Query (FIXED)
    PAGINATED_QUERY = f"""
    WITH deduped_audit AS (
        SELECT
            PYID,
            CASE_TO_AUDIT,
            INTAKESOURCESYSTEM,
            PYSTATUSWORK,
            LOB,
            PXCREATEDATETIME,
            PYRESOLVEDTIMESTAMP,
            DATE(PXCREATEDATETIME) AS resolved_date,
            PLATFORM,
            AUDIT_SUBJECT_ID,
            ROW_NUMBER() OVER (
                PARTITION BY PYID
                ORDER BY PXUPDATEDATETIME DESC
            ) as rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
        WHERE REBUTTALFLAG = 'Y'
          AND PYID LIKE 'AUD%'
          AND PYSTATUSWORK = 'Resolved-Completed'
          AND PXCREATEDATETIME IS NOT NULL
          AND DATE(PXCREATEDATETIME) >= '{start_date}'
          AND DATE(PXCREATEDATETIME) <= '{end_date}'
          {lob_filter_sql}
    ),
    associate_hierarchy AS (
        SELECT
            PYID,
            ROW_NUMBER() OVER (PARTITION BY PYID ORDER BY PXUPDATEDATETIME DESC) AS rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_INVNTRY_PROFILE
        WHERE 1=1
            AND DATE(PXCREATEDATETIME) >= '{start_date}'
            AND DATE(PXCREATEDATETIME) <= '{end_date}'
    ),
    deduped_user_profile AS (
        SELECT
            USERID,
            TRIM(COALESCE(FIRSTNAME, '') || ' ' || COALESCE(LASTNAME, '')) AS USERNAME,
            ROW_NUMBER() OVER (
                PARTITION BY USERID
                ORDER BY PXUPDATEDATETIME DESC
            ) as rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_USER_PROFILE
    ),
    deduped_audit_activity AS (
        SELECT
            CASEID,
            ERRORCATEGORY,
            ERRORCATEGORYTYPE,
            REBUTTALOUTCOME,
            ROW_NUMBER() OVER (
                PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
                ORDER BY PXUPDATEDATETIME DESC
            ) as rn
        FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
        WHERE CASEID LIKE 'AUD%'
          AND ERRORCATEGORYTYPE IS NOT NULL
          AND ERRORCATEGORY IS NOT NULL
    )
    SELECT COUNT(*) as total_records
    FROM deduped_audit a
    INNER JOIN associate_hierarchy ah
        ON a.CASE_TO_AUDIT = ah.PYID
        AND ah.rn = 1
    INNER JOIN deduped_user_profile u
        ON a.AUDIT_SUBJECT_ID = u.USERID
        AND u.rn = 1
    LEFT JOIN deduped_audit_activity aa
        ON a.PYID = aa.CASEID
        AND aa.rn = 1
    WHERE a.rn = 1
      AND u.rn = 1
    """
    
    try:
        # Run COUNT query
        count_result = engine.execute_query(COUNT_QUERY, limit=1)
        count_val = count_result[0].get('REBUTTAL_COUNT', 0) if count_result else 0
        unique_cases = count_result[0].get('UNIQUE_AUDIT_CASES', 0) if count_result else 0
        
        # Run PAGINATED query
        paginated_result = engine.execute_query(PAGINATED_QUERY, limit=1)
        drilldown_val = paginated_result[0].get('TOTAL_RECORDS', 0) if paginated_result else 0
        
        # Check match
        is_match = (count_val == drilldown_val)
        status = "✅ PASS" if is_match else "❌ FAIL"
        
        return {
            'test_name': test_name,
            'date_range': f"{start_date} to {end_date}",
            'lob_filter': lob_filter_label,
            'count': count_val,
            'drilldown': drilldown_val,
            'unique_cases': unique_cases,
            'match': is_match,
            'status': status
        }
    except Exception as e:
        return {
            'test_name': test_name,
            'date_range': f"{start_date} to {end_date}",
            'lob_filter': lob_filter_label,
            'count': 0,
            'drilldown': 0,
            'unique_cases': 0,
            'match': False,
            'status': f"❌ ERROR: {str(e)[:50]}"
        }

# ============================================================================
# TEST SCENARIOS
# ============================================================================

test_scenarios = []
today = datetime.now()

print("\n" + "=" * 100)
print("RUNNING COMPREHENSIVE TESTS")
print("=" * 100)

# Test 1: Different Date Ranges
print("\n📅 TEST SET 1: DIFFERENT DATE RANGES (No LOB Filter)")
print("-" * 100)

date_ranges = [
    ("Last 7 Days", 7),
    ("Last 30 Days", 30),
    ("Last 60 Days", 60),
    ("Last 90 Days", 90),
    ("Last 180 Days", 180),
    ("Last 1 Year", 365),
]

for label, days in date_ranges:
    start_date = (today - timedelta(days=days)).strftime('%Y-%m-%d')
    end_date = today.strftime('%Y-%m-%d')
    
    print(f"\n  Testing: {label} ({start_date} to {end_date})...", end=" ")
    result = run_validation(label, start_date, end_date)
    test_scenarios.append(result)
    
    print(f"{result['status']}")
    print(f"    Count: {result['count']}, Drilldown: {result['drilldown']}, Cases: {result['unique_cases']}")

# Test 2: LOB Filters (90-day window)
print("\n\n🏢 TEST SET 2: LOB FILTERS (Last 90 Days)")
print("-" * 100)

start_date_90d = (today - timedelta(days=90)).strftime('%Y-%m-%d')
end_date_90d = today.strftime('%Y-%m-%d')

lob_scenarios = [
    ("Commercial Only", ["Commercial"], "AND LOB = 'Commercial'"),
    ("Government Only", ["Government"], "AND LOB = 'Government'"),
    ("Medicare Only", ["Medicare"], "AND LOB = 'Medicare'"),
    ("Medicaid Only", ["Medicaid"], "AND LOB = 'Medicaid'"),
    ("All LOBs", [], ""),
]

for label, lob_list, lob_sql in lob_scenarios:
    print(f"\n  Testing: {label}...", end=" ")
    lob_label = label
    result = run_validation(f"LOB: {label}", start_date_90d, end_date_90d, lob_sql, lob_label)
    test_scenarios.append(result)
    
    print(f"{result['status']}")
    print(f"    Count: {result['count']}, Drilldown: {result['drilldown']}, Cases: {result['unique_cases']}")

# Test 3: Specific Date Windows
print("\n\n📆 TEST SET 3: SPECIFIC TIME WINDOWS")
print("-" * 100)

specific_windows = [
    ("Current Month", 
     datetime(today.year, today.month, 1).strftime('%Y-%m-%d'),
     today.strftime('%Y-%m-%d')),
    
    ("Last Month",
     (datetime(today.year, today.month, 1) - timedelta(days=1)).replace(day=1).strftime('%Y-%m-%d'),
     (datetime(today.year, today.month, 1) - timedelta(days=1)).strftime('%Y-%m-%d')),
    
    ("Current Quarter",
     datetime(today.year, ((today.month-1)//3)*3+1, 1).strftime('%Y-%m-%d'),
     today.strftime('%Y-%m-%d')),
]

for label, start, end in specific_windows:
    print(f"\n  Testing: {label} ({start} to {end})...", end=" ")
    result = run_validation(label, start, end)
    test_scenarios.append(result)
    
    print(f"{result['status']}")
    print(f"    Count: {result['count']}, Drilldown: {result['drilldown']}, Cases: {result['unique_cases']}")

# Test 4: Edge Cases
print("\n\n⚠️  TEST SET 4: EDGE CASES")
print("-" * 100)

edge_cases = [
    ("Single Day", 
     today.strftime('%Y-%m-%d'),
     today.strftime('%Y-%m-%d')),
    
    ("Very Old Data (2 years)",
     (today - timedelta(days=730)).strftime('%Y-%m-%d'),
     (today - timedelta(days=700)).strftime('%Y-%m-%d')),
]

for label, start, end in edge_cases:
    print(f"\n  Testing: {label} ({start} to {end})...", end=" ")
    result = run_validation(label, start, end)
    test_scenarios.append(result)
    
    print(f"{result['status']}")
    print(f"    Count: {result['count']}, Drilldown: {result['drilldown']}, Cases: {result['unique_cases']}")

# ============================================================================
# SUMMARY REPORT
# ============================================================================

print("\n\n" + "=" * 100)
print("COMPREHENSIVE TEST SUMMARY")
print("=" * 100)

# Count passes and fails
total_tests = len(test_scenarios)
passed = sum(1 for t in test_scenarios if t['match'])
failed = total_tests - passed

print(f"\n📊 Overall Results:")
print(f"  Total Tests: {total_tests}")
print(f"  Passed: {passed} ✅")
print(f"  Failed: {failed} {'❌' if failed > 0 else ''}")
print(f"  Success Rate: {(passed/total_tests*100):.1f}%")

if failed > 0:
    print(f"\n❌ Failed Tests:")
    for test in test_scenarios:
        if not test['match']:
            print(f"  - {test['test_name']}")
            print(f"    Date Range: {test['date_range']}")
            print(f"    LOB Filter: {test['lob_filter']}")
            print(f"    Count: {test['count']}, Drilldown: {test['drilldown']}")
            print(f"    Status: {test['status']}")

# Detailed Results Table
print("\n\n📋 DETAILED RESULTS TABLE")
print("=" * 100)
print(f"{'Test Scenario':<30} {'Date Range':<25} {'LOB Filter':<15} {'Count':>8} {'Drill':>8} {'Cases':>8} {'Match':<6}")
print("-" * 100)

for test in test_scenarios:
    date_range_short = test['date_range'][:25]
    lob_short = test['lob_filter'][:15]
    match_symbol = "✅" if test['match'] else "❌"
    
    print(f"{test['test_name']:<30} {date_range_short:<25} {lob_short:<15} "
          f"{test['count']:>8} {test['drilldown']:>8} {test['unique_cases']:>8} {match_symbol:<6}")

# Statistics
print("\n\n📈 STATISTICS")
print("=" * 100)

total_count = sum(t['count'] for t in test_scenarios)
total_drilldown = sum(t['drilldown'] for t in test_scenarios)
avg_count = total_count / total_tests if total_tests > 0 else 0
avg_drilldown = total_drilldown / total_tests if total_tests > 0 else 0

print(f"  Total Error Combinations (across all tests): {total_count}")
print(f"  Total Drilldown Records (across all tests): {total_drilldown}")
print(f"  Average Count per Test: {avg_count:.1f}")
print(f"  Average Drilldown per Test: {avg_drilldown:.1f}")

# Find test with most data
if test_scenarios:
    max_test = max(test_scenarios, key=lambda x: x['count'])
    print(f"\n  Largest Dataset: {max_test['test_name']}")
    print(f"    Count: {max_test['count']}, Drilldown: {max_test['drilldown']}")

# ============================================================================
# FINAL VERDICT
# ============================================================================

print("\n\n" + "=" * 100)
print("FINAL VERDICT")
print("=" * 100)

if passed == total_tests:
    print("\n🎉 ✅ ALL TESTS PASSED!")
    print("\n  The FIXED SQL queries work correctly across:")
    print("    ✅ Multiple date ranges (7d to 1 year)")
    print("    ✅ Different LOB filters (Commercial, Government, etc.)")
    print("    ✅ Specific time windows (month, quarter)")
    print("    ✅ Edge cases (single day, old data)")
    print("\n  COUNT and DRILLDOWN queries are perfectly aligned!")
    print("  Ready for production deployment.")
else:
    print(f"\n⚠️  {failed} TEST(S) FAILED")
    print("\n  Review failed tests above for issues.")
    print("  May need additional debugging or filter adjustments.")

print("\n" + "=" * 100)
print("COMPREHENSIVE TESTING COMPLETE")
print("=" * 100)
