#!/usr/bin/env python3
"""
SQL Validation Script for Rebuttal Drilldown Issues

This script tests and validates the 4 identified issues:
1. PYID filter missing in PAGINATED query
2. NULL error category filters missing
3. Count aggregation mismatch
4. Auditor field naming (visual check)

Run this script to confirm issues before applying fixes.
"""

import sys
import os

# Add project root and src to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, 'src'))

from src.db.connection_manager import connection_manager
from src.config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from datetime import datetime, timedelta

# Test parameters - adjust as needed
TEST_START_DATE = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')
TEST_END_DATE = datetime.now().strftime('%Y-%m-%d')
TEST_LOB = None  # Set to ['Commercial'] to test specific LOB
TEST_MANAGER = None  # Set to specific manager ID to test

print("=" * 80)
print("REBUTTAL DRILLDOWN SQL VALIDATION")
print("=" * 80)
print(f"Database: {SNOWFLAKE_DATABASE}")
print(f"Schema: {SNOWFLAKE_SCHEMA}")
print(f"Test Date Range: {TEST_START_DATE} to {TEST_END_DATE}")
print()

# Get database engine
engine = connection_manager.get_engine()

# ============================================================================
# TEST 1: Check for non-AUD records in PAGINATED query (PYID filter issue)
# ============================================================================
print("\n" + "=" * 80)
print("TEST 1: PYID Filter Validation")
print("=" * 80)

PYID_CHECK_QUERY = f"""
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        INTAKESOURCESYSTEM,
        PYSTATUSWORK,
        LOB,
        PXCREATEDATETIME,
        PYRESOLVEDTIMESTAMP,
        DATE(PXCREATEDATETIME) AS resolved_date,
        PLATFORM,
        AUDIT_SUBJECT_ID,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      -- MISSING: AND PYID LIKE 'AUD%'  (This is the issue!)
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND PXCREATEDATETIME IS NOT NULL
      AND DATE(PXCREATEDATETIME) >= '{TEST_START_DATE}'
      AND DATE(PXCREATEDATETIME) <= '{TEST_END_DATE}'
)
SELECT
    COUNT(*) as total_records,
    SUM(CASE WHEN PYID LIKE 'AUD%' THEN 1 ELSE 0 END) as audit_records,
    SUM(CASE WHEN PYID NOT LIKE 'AUD%' THEN 1 ELSE 0 END) as non_audit_records,
    MIN(CASE WHEN PYID NOT LIKE 'AUD%' THEN PYID ELSE NULL END) as sample_non_audit_pyid
FROM deduped_audit
WHERE rn = 1
"""

print("\nRunning PYID filter check...")
print("Query: Checking for non-AUD% records that shouldn't be included")

try:
    result = engine.execute_query(PYID_CHECK_QUERY, limit=1)
    if result:
        row = result[0]
        print(f"\n✓ Results:")
        print(f"  Total Records: {row.get('TOTAL_RECORDS', 0)}")
        print(f"  Audit Records (AUD%): {row.get('AUDIT_RECORDS', 0)}")
        print(f"  Non-Audit Records: {row.get('NON_AUDIT_RECORDS', 0)}")
        
        if row.get('NON_AUDIT_RECORDS', 0) > 0:
            print(f"\n❌ ISSUE CONFIRMED: Found {row.get('NON_AUDIT_RECORDS')} non-audit records!")
            print(f"  Sample non-audit PYID: {row.get('SAMPLE_NON_AUDIT_PYID')}")
            print("  Fix Required: Add 'AND PYID LIKE 'AUD%'' filter")
        else:
            print("\n✓ No non-audit records found (but filter should still be added for consistency)")
except Exception as e:
    print(f"\n❌ Error executing query: {e}")

# ============================================================================
# TEST 2: Check for NULL error categories (Filter missing issue)
# ============================================================================
print("\n" + "=" * 80)
print("TEST 2: NULL Error Category Validation")
print("=" * 80)

NULL_ERROR_CHECK_QUERY = f"""
WITH deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORY,
        ERRORCATEGORYTYPE,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    -- MISSING: WHERE CASEID LIKE 'AUD%'
    -- MISSING: AND ERRORCATEGORYTYPE IS NOT NULL
    -- MISSING: AND ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(*) as total_records,
    SUM(CASE WHEN ERRORCATEGORYTYPE IS NULL THEN 1 ELSE 0 END) as null_error_type,
    SUM(CASE WHEN ERRORCATEGORY IS NULL THEN 1 ELSE 0 END) as null_error_category,
    SUM(CASE WHEN ERRORCATEGORYTYPE IS NOT NULL AND ERRORCATEGORY IS NOT NULL THEN 1 ELSE 0 END) as valid_errors,
    MIN(CASE WHEN CASEID NOT LIKE 'AUD%' THEN CASEID ELSE NULL END) as sample_non_audit_caseid
FROM deduped_audit_activity
WHERE rn = 1
LIMIT 1
"""

print("\nRunning NULL error category check...")
print("Query: Checking for NULL ERRORCATEGORYTYPE or ERRORCATEGORY")

try:
    result = engine.execute_query(NULL_ERROR_CHECK_QUERY, limit=1)
    if result:
        row = result[0]
        print(f"\n✓ Results:")
        print(f"  Total Records: {row.get('TOTAL_RECORDS', 0)}")
        print(f"  NULL Error Type: {row.get('NULL_ERROR_TYPE', 0)}")
        print(f"  NULL Error Category: {row.get('NULL_ERROR_CATEGORY', 0)}")
        print(f"  Valid Errors: {row.get('VALID_ERRORS', 0)}")
        
        if row.get('NULL_ERROR_TYPE', 0) > 0 or row.get('NULL_ERROR_CATEGORY', 0) > 0:
            print("\n❌ ISSUE CONFIRMED: Found NULL error categories!")
            print("  Fix Required: Add WHERE clause with NOT NULL filters")
        else:
            print("\n✓ No NULL errors found (but filters should still be added for data quality)")
except Exception as e:
    print(f"\n❌ Error executing query: {e}")

# ============================================================================
# TEST 3: Count Aggregation Mismatch (Primary Issue)
# ============================================================================
print("\n" + "=" * 80)
print("TEST 3: Count vs Drilldown Records Mismatch")
print("=" * 80)

# COUNT Query (from quality_outcomes.py) - Correct logic
COUNT_QUERY = f"""
WITH audit_deduped AS (
    SELECT
        PYID,
        REBUTTALFLAG,
        PXCREATEDATETIME,
        DATE(PXCREATEDATETIME) AS created_date,
        LOB,
        AUDITOR_ID,
        AUDIT_SUBJECT_ID,
        CASE_TO_AUDIT,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYID LIKE 'AUD%'
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND PXCREATEDATETIME IS NOT NULL
      AND DATE(PXCREATEDATETIME) >= '{TEST_START_DATE}'
      AND DATE(PXCREATEDATETIME) <= '{TEST_END_DATE}'
),
rebuttal_details AS (
    SELECT
        act.CASEID,
        act.ERRORCATEGORYTYPE,
        act.ERRORCATEGORY,
        ROW_NUMBER() OVER (
            PARTITION BY act.CASEID, act.ERRORCATEGORYTYPE, act.ERRORCATEGORY
            ORDER BY act.PXUPDATEDATETIME DESC
        ) AS rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY act
    WHERE act.CASEID LIKE 'AUD%'
      AND act.ERRORCATEGORYTYPE IS NOT NULL
      AND act.ERRORCATEGORY IS NOT NULL
)
SELECT
    COUNT(DISTINCT rd.CASEID || '|' || rd.ERRORCATEGORYTYPE || '|' || rd.ERRORCATEGORY) AS REBUTTAL_COUNT,
    COUNT(DISTINCT rd.CASEID) AS unique_audit_cases
FROM audit_deduped a
INNER JOIN rebuttal_details rd
    ON a.PYID = rd.CASEID
    AND rd.rn = 1
WHERE a.rn = 1
"""

# PAGINATED Query (from rebuttal_drilldown.py) - Current buggy logic
PAGINATED_COUNT_QUERY = f"""
WITH deduped_audit AS (
    SELECT
        PYID,
        CASE_TO_AUDIT,
        ROW_NUMBER() OVER (
            PARTITION BY PYID
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_PROFILE
    WHERE REBUTTALFLAG = 'Y'
      AND PYSTATUSWORK = 'Resolved-Completed'
      AND PXCREATEDATETIME IS NOT NULL
      AND DATE(PXCREATEDATETIME) >= '{TEST_START_DATE}'
      AND DATE(PXCREATEDATETIME) <= '{TEST_END_DATE}'
),
deduped_audit_activity AS (
    SELECT
        CASEID,
        ERRORCATEGORY,
        ERRORCATEGORYTYPE,
        REBUTTALOUTCOME,
        ROW_NUMBER() OVER (
            PARTITION BY CASEID  -- BUG: Should partition by CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY
            ORDER BY PXUPDATEDATETIME DESC
        ) as rn
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    -- BUG: Missing WHERE clause
)
SELECT
    COUNT(*) as total_drilldown_records
FROM deduped_audit a
LEFT JOIN deduped_audit_activity aa
    ON a.PYID = aa.CASEID
    AND aa.rn = 1
WHERE a.rn = 1
"""

print("\nRunning COUNT query (from quality-outcomes)...")
try:
    count_result = engine.execute_query(COUNT_QUERY, limit=1)
    if count_result:
        count_row = count_result[0]
        rebuttal_count = count_row.get('REBUTTAL_COUNT', 0)
        unique_cases = count_row.get('UNIQUE_AUDIT_CASES', 0)
        print("\n✓ COUNT Query Results:")
        print(f"  Rebuttal Count (error combinations): {rebuttal_count}")
        print(f"  Unique Audit Cases: {unique_cases}")
except Exception as e:
    print(f"\n❌ Error executing COUNT query: {e}")
    rebuttal_count = 0
    unique_cases = 0

print("\nRunning PAGINATED query (from rebuttal-drilldown)...")
try:
    paginated_result = engine.execute_query(PAGINATED_COUNT_QUERY, limit=1)
    if paginated_result:
        paginated_row = paginated_result[0]
        drilldown_count = paginated_row.get('TOTAL_DRILLDOWN_RECORDS', 0)
        print("\n✓ PAGINATED Query Results:")
        print(f"  Drilldown Records: {drilldown_count}")
except Exception as e:
    print(f"\n❌ Error executing PAGINATED query: {e}")
    drilldown_count = 0

print("\n" + "-" * 80)
print("COMPARISON:")
print("-" * 80)
print(f"  Dashboard Count (quality-outcomes): {rebuttal_count}")
print(f"  Drilldown Records (rebuttal-drilldown): {drilldown_count}")

if rebuttal_count > drilldown_count:
    print("\n❌ ISSUE CONFIRMED: Count Mismatch!")
    print(f"  Difference: {rebuttal_count - drilldown_count} records missing from drilldown")
    print("  Root Cause: PAGINATED query partitions by CASEID only (gets 1 row per audit)")
    print("              COUNT query counts by (CASEID + ERROR_TYPE + ERROR_CATEGORY)")
    print("  Fix Required: Change PARTITION BY to include ERRORCATEGORYTYPE, ERRORCATEGORY")
elif rebuttal_count == drilldown_count:
    print(f"\n✓ Counts match (but verify partition logic is correct)")
else:
    print(f"\n⚠️  Drilldown has MORE records than count - unexpected!")

# ============================================================================
# TEST 4: Find Example Multi-Error Audit
# ============================================================================
print("\n" + "=" * 80)
print("TEST 4: Find Audits with Multiple Error Combinations")
print("=" * 80)

MULTI_ERROR_QUERY = f"""
WITH error_combos AS (
    SELECT
        CASEID,
        COUNT(DISTINCT ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) as error_combo_count,
        LISTAGG(DISTINCT ERRORCATEGORYTYPE, ', ') WITHIN GROUP (ORDER BY ERRORCATEGORYTYPE) as error_types,
        LISTAGG(DISTINCT ERRORCATEGORY, ', ') WITHIN GROUP (ORDER BY ERRORCATEGORY) as error_categories
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.COB_AI_AUDIT_ACTIVITY
    WHERE CASEID LIKE 'AUD%'
      AND ERRORCATEGORYTYPE IS NOT NULL
      AND ERRORCATEGORY IS NOT NULL
    GROUP BY CASEID
    HAVING COUNT(DISTINCT ERRORCATEGORYTYPE || '|' || ERRORCATEGORY) > 1
)
SELECT
    CASEID,
    error_combo_count,
    error_types,
    error_categories
FROM error_combos
ORDER BY error_combo_count DESC
LIMIT 5
"""

print("\nSearching for audits with multiple error combinations...")
print("(These are cases where COUNT > DRILLDOWN should occur)")

try:
    multi_error_result = engine.execute_query(MULTI_ERROR_QUERY, limit=5)
    if multi_error_result:
        print(f"\n✓ Found {len(multi_error_result)} example cases:\n")
        for idx, row in enumerate(multi_error_result, 1):
            print(f"  {idx}. {row.get('CASEID')} - {row.get('ERROR_COMBO_COUNT')} error combinations")
            print(f"     Error Types: {row.get('ERROR_TYPES', 'N/A')[:80]}")
            print(f"     Error Categories: {row.get('ERROR_CATEGORIES', 'N/A')[:80]}")
            print()
        
        if len(multi_error_result) > 0:
            print("✓ These cases prove the count mismatch issue exists!")
            print("  With current PAGINATED logic: Each case shows as 1 row")
            print("  With COUNT logic: Each case counts as multiple combinations")
    else:
        print("\n✓ No multi-error audits found in test period")
        print("  (All audits have only 1 error combination)")
except Exception as e:
    print(f"\n❌ Error finding multi-error audits: {e}")

# ============================================================================
# SUMMARY
# ============================================================================
print("\n" + "=" * 80)
print("VALIDATION SUMMARY")
print("=" * 80)

print("\n✅ ISSUES VALIDATED:")
print("  1. PYID Filter Missing - Check results above")
print("  2. NULL Error Filters Missing - Check results above")
print("  3. Count Aggregation Mismatch - Check comparison above")
print("  4. Auditor Field Naming - Not testable via SQL (Python code issue)")

print("\n📋 NEXT STEPS:")
print("  1. Review the validation results above")
print("  2. If issues confirmed, apply fixes to rebuttal_drilldown.py")
print("  3. Re-run this validation script after fixes")
print("  4. Verify counts match perfectly")

print("\n" + "=" * 80)
print("VALIDATION COMPLETE")
print("=" * 80)
