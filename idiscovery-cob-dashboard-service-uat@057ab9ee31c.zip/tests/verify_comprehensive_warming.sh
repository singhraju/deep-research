#!/bin/bash

# Quick verification of comprehensive cache warming

BASE_URL="http://localhost:8001"
USER_ID="AB77504"
START_DATE="2026-03-01"
END_DATE="2026-03-25"
LOB="Commercial"

echo "=========================================="
echo "COMPREHENSIVE WARMING VERIFICATION"
echo "=========================================="
echo ""

# Step 1: Trigger warming
echo "1. Calling header-kpis to trigger comprehensive warming..."
RESPONSE=$(curl -s -X POST "$BASE_URL/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["'"$LOB"'"]
  }')

SESSION_ID=$(echo "$RESPONSE" | jq -r '.cache_metadata.session_id // .session_id // empty')

if [ -z "$SESSION_ID" ]; then
    echo "❌ Failed to get session ID"
    exit 1
fi

echo "✅ Session ID: $SESSION_ID"
echo ""

# Step 2: Wait for warming
echo "2. Waiting 90 seconds for comprehensive warming..."
sleep 90
echo "✅ Wait complete"
echo ""

# Step 3: Check metadata
echo "3. Checking cache metadata..."
RESPONSE=$(curl -s -X POST "$BASE_URL/director/header-kpis" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["'"$LOB"'"],
    "session_id": "'"$SESSION_ID"'"
  }')

APIS_CACHED=$(echo "$RESPONSE" | jq -r '.cache_metadata.apis_cached // [] | length')
CACHE_HIT=$(echo "$RESPONSE" | jq -r '.cache_metadata.cache_hit // false')

echo "APIs cached: $APIS_CACHED"
echo "Cache hit: $CACHE_HIT"

if [ "$APIS_CACHED" -ge 20 ]; then
    echo "✅ SUCCESS: $APIS_CACHED APIs cached (expected 22)"
else
    echo "❌ FAIL: Only $APIS_CACHED APIs cached (expected 22)"
fi

if [ "$CACHE_HIT" == "true" ]; then
    echo "✅ SUCCESS: Cache hit working"
else
    echo "❌ FAIL: Cache hit not working"
fi

echo ""
echo "Cached APIs:"
echo "$RESPONSE" | jq -r '.cache_metadata.apis_cached[]' | head -25

echo ""
echo "4. Testing drilldown cache hit..."
DRILL_RESPONSE=$(curl -s -X POST "$BASE_URL/director/work-items-director-drilldown" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "'"$USER_ID"'",
    "start_date": "'"$START_DATE"'",
    "end_date": "'"$END_DATE"'",
    "lob": ["'"$LOB"'"],
    "session_id": "'"$SESSION_ID"'",
    "page": 1,
    "page_size": 50
  }')

DRILL_CACHE_HIT=$(echo "$DRILL_RESPONSE" | jq -r '.cache_metadata.cache_hit // false')

if [ "$DRILL_CACHE_HIT" == "true" ]; then
    echo "✅ SUCCESS: Drilldown cache hit working!"
else
    echo "⚠️  Drilldown cache status: $DRILL_CACHE_HIT"
fi

echo ""
echo "=========================================="
echo "VERIFICATION COMPLETE"
echo "=========================================="
