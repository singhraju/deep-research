#!/usr/bin/env python3
"""
Implementation Verification Script

Confirms all 4 fixes are correctly applied to rebuttal_drilldown.py
"""

import os
import sys

project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
target_file = os.path.join(project_root, 'src', 'controllers', 'Performance_IQ_Manager', 'rebuttal_drilldown.py')

print("=" * 80)
print("IMPLEMENTATION VERIFICATION")
print("=" * 80)
print(f"\nTarget File: {target_file}")
print()

with open(target_file, 'r') as f:
    content = f.read()
    lines = content.split('\n')

# Verification checks
checks = {
    "Fix 1: PYID LIKE 'AUD%' filter added": False,
    "Fix 2: CASEID LIKE 'AUD%' filter added": False,
    "Fix 3: ERRORCATEGORYTYPE IS NOT NULL filter added": False,
    "Fix 4: ERRORCATEGORY IS NOT NULL filter added": False,
    "Fix 5: PARTITION BY includes ERRORCATEGORYTYPE": False,
    "Fix 6: PARTITION BY includes ERRORCATEGORY": False,
    "Fix 7: SQL alias changed to auditor_name": False,
    "Fix 8: Python code uses AUDITOR_NAME (line ~429)": False,
    "Fix 9: Python code uses AUDITOR_NAME (line ~579)": False,
}

# Check each fix
for i, line in enumerate(lines, 1):
    # Fix 1: PYID filter in deduped_audit
    if "AND PYID LIKE 'AUD%'" in line and i < 100:
        checks["Fix 1: PYID LIKE 'AUD%' filter added"] = True
        print(f"✅ Fix 1 found at line {i}: {line.strip()}")
    
    # Fix 2-4: WHERE clause in deduped_audit_activity
    if "WHERE CASEID LIKE 'AUD%'" in line:
        checks["Fix 2: CASEID LIKE 'AUD%' filter added"] = True
        print(f"✅ Fix 2 found at line {i}: {line.strip()}")
    
    if "AND ERRORCATEGORYTYPE IS NOT NULL" in line:
        checks["Fix 3: ERRORCATEGORYTYPE IS NOT NULL filter added"] = True
        print(f"✅ Fix 3 found at line {i}: {line.strip()}")
    
    if "AND ERRORCATEGORY IS NOT NULL" in line:
        checks["Fix 4: ERRORCATEGORY IS NOT NULL filter added"] = True
        print(f"✅ Fix 4 found at line {i}: {line.strip()}")
    
    # Fix 5-6: PARTITION BY change
    if "PARTITION BY CASEID, ERRORCATEGORYTYPE, ERRORCATEGORY" in line:
        checks["Fix 5: PARTITION BY includes ERRORCATEGORYTYPE"] = True
        checks["Fix 6: PARTITION BY includes ERRORCATEGORY"] = True
        print(f"✅ Fix 5 & 6 found at line {i}: {line.strip()}")
    
    # Fix 7: SQL alias
    if "u.USERNAME as auditor_name" in line:
        checks["Fix 7: SQL alias changed to auditor_name"] = True
        print(f"✅ Fix 7 found at line {i}: {line.strip()}")
    
    # Fix 8-9: Python field references
    if 'record.get("AUDITOR_NAME")' in line or 'row.get("AUDITOR_NAME")' in line:
        if i < 450:
            checks["Fix 8: Python code uses AUDITOR_NAME (line ~429)"] = True
            print(f"✅ Fix 8 found at line {i}: {line.strip()[:80]}...")
        else:
            checks["Fix 9: Python code uses AUDITOR_NAME (line ~579)"] = True
            print(f"✅ Fix 9 found at line {i}: {line.strip()[:80]}...")

# Summary
print("\n" + "=" * 80)
print("VERIFICATION SUMMARY")
print("=" * 80)

all_passed = all(checks.values())
passed_count = sum(checks.values())
total_count = len(checks)

for check_name, passed in checks.items():
    status = "✅ PASS" if passed else "❌ FAIL"
    print(f"{status} - {check_name}")

print("\n" + "-" * 80)
print(f"Results: {passed_count}/{total_count} checks passed")

if all_passed:
    print("\n🎉 ✅ ALL FIXES VERIFIED!")
    print("\nAll 4 critical fixes are correctly implemented:")
    print("  1. ✅ PYID filter added to deduped_audit CTE")
    print("  2. ✅ WHERE clause added to deduped_audit_activity CTE (3 filters)")
    print("  3. ✅ PARTITION BY updated to include error fields")
    print("  4. ✅ Field renamed from associate_name to auditor_name (SQL + Python)")
    print("\n✨ Implementation is COMPLETE and ready for testing!")
else:
    print(f"\n❌ VERIFICATION FAILED - {total_count - passed_count} check(s) missing")
    print("\nMissing fixes:")
    for check_name, passed in checks.items():
        if not passed:
            print(f"  ❌ {check_name}")

print("\n" + "=" * 80)
sys.exit(0 if all_passed else 1)
