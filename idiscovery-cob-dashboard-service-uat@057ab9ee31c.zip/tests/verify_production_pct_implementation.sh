#!/bin/bash

echo "============================================================"
echo "Production % Query Implementation Verification"
echo "============================================================"
echo ""
echo "This script verifies the Production % query replacement:"
echo "1. PRODUCTIVETIME parsing (not duration calculation)"
echo "2. Correct deduplication logic (RETIME DESC NULLS LAST)"
echo "3. Simplified count query"
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "============================================================"
echo "Step 1: Verify Service is Running on Port 8001"
echo "============================================================"
if lsof -i :8001 | grep -q LISTEN; then
    echo -e "${GREEN}✅ Service is running on port 8001${NC}"
else
    echo -e "${RED}❌ Service is NOT running on port 8001${NC}"
    echo "Please start the service first: ./bin/run"
    exit 1
fi
echo ""

echo "============================================================"
echo "Step 2: Test Header KPI Endpoint Structure"
echo "============================================================"
echo "Testing with minimal request..."

RESPONSE=$(curl -s -X POST http://localhost:8001/manager/header-kpis \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "ROSETSC",
    "start_date": "2026-03-01",
    "end_date": "2026-04-01"
  }')

STATUS=$(echo "$RESPONSE" | jq -r '.status // "error"')
PROD_PCT=$(echo "$RESPONSE" | jq -r '.data.production_pct_achieved // "null"')

echo "Response Status: $STATUS"
echo "Production %: $PROD_PCT"

if [ "$STATUS" = "success" ]; then
    echo -e "${GREEN}✅ Header KPI endpoint responding successfully${NC}"
    
    if [ "$PROD_PCT" != "null" ]; then
        echo -e "${GREEN}✅ Production % returned: $PROD_PCT${NC}"
        echo -e "${YELLOW}Note: Value should be calculated using PRODUCTIVETIME parsing${NC}"
    else
        echo -e "${YELLOW}⚠️  Production % is null (no data for this user/date range)${NC}"
        echo "This is expected if test data doesn't exist"
    fi
else
    echo -e "${RED}❌ Header KPI endpoint failed${NC}"
    echo "$RESPONSE" | jq '.'
fi
echo ""

echo "============================================================"
echo "Step 3: Test Drilldown Endpoint Structure"
echo "============================================================"
echo "Testing drilldown with pagination..."

DRILL_RESPONSE=$(curl -s -X POST http://localhost:8001/manager/production-pct-achieved-drilldown \
  -H "Content-Type: application/json" \
  -d '{
    "screen_id": "production_pct_achieved",
    "user_id": "ROSETSC",
    "start_date": "2026-03-01",
    "end_date": "2026-04-01",
    "page": 1,
    "page_size": 5
  }')

DRILL_STATUS=$(echo "$DRILL_RESPONSE" | jq -r '.status // "error"')
TOTAL_COUNT=$(echo "$DRILL_RESPONSE" | jq -r '.page.total_count // "null"')
RECORDS=$(echo "$DRILL_RESPONSE" | jq -r '.records | length')

echo "Response Status: $DRILL_STATUS"
echo "Total Count: $TOTAL_COUNT"
echo "Records in Page: $RECORDS"

if [ "$DRILL_STATUS" = "success" ]; then
    echo -e "${GREEN}✅ Drilldown endpoint responding successfully${NC}"
    
    if [ "$TOTAL_COUNT" != "null" ] && [ "$TOTAL_COUNT" != "0" ]; then
        echo -e "${GREEN}✅ Found $TOTAL_COUNT work items${NC}"
        echo ""
        echo "Sample Record Fields:"
        echo "$DRILL_RESPONSE" | jq '.records[0] | keys' 2>/dev/null
    else
        echo -e "${YELLOW}⚠️  No records found (count: $TOTAL_COUNT)${NC}"
        echo "This is expected if test data doesn't exist"
    fi
else
    echo -e "${RED}❌ Drilldown endpoint failed${NC}"
    echo "$DRILL_RESPONSE" | jq '.'
fi
echo ""

echo "============================================================"
echo "Step 4: Verify Query Implementation in Code"
echo "============================================================"

# Check for PRODUCTIVETIME parsing in header_kpis.py
if grep -q "SPLIT_PART(PRODUCTIVETIME" src/controllers/Performance_IQ_Manager/header_kpis.py; then
    echo -e "${GREEN}✅ header_kpis.py: PRODUCTIVETIME parsing found${NC}"
else
    echo -e "${RED}❌ header_kpis.py: PRODUCTIVETIME parsing NOT found${NC}"
fi

# Check for PRODUCTIVETIME parsing in drilldown
if grep -q "SPLIT_PART(PRODUCTIVETIME" src/controllers/Performance_IQ_Manager/production_pct_achieved_drilldown.py; then
    echo -e "${GREEN}✅ production_pct_achieved_drilldown.py: PRODUCTIVETIME parsing found${NC}"
else
    echo -e "${RED}❌ production_pct_achieved_drilldown.py: PRODUCTIVETIME parsing NOT found${NC}"
fi

# Check for correct deduplication logic
if grep -q "ORDER BY RETIME DESC NULLS LAST" src/controllers/Performance_IQ_Manager/header_kpis.py; then
    echo -e "${GREEN}✅ header_kpis.py: Correct deduplication (RETIME DESC NULLS LAST)${NC}"
else
    echo -e "${YELLOW}⚠️  header_kpis.py: Deduplication logic may differ${NC}"
fi

if grep -q "ORDER BY RETIME DESC NULLS LAST" src/controllers/Performance_IQ_Manager/production_pct_achieved_drilldown.py; then
    echo -e "${GREEN}✅ production_pct_achieved_drilldown.py: Correct deduplication${NC}"
else
    echo -e "${YELLOW}⚠️  production_pct_achieved_drilldown.py: Deduplication logic may differ${NC}"
fi

# Check that old calculation method is removed
if grep -q "LUNCH_DURATION + BREAK_DURATION" src/controllers/Performance_IQ_Manager/header_kpis.py; then
    echo -e "${RED}❌ header_kpis.py: Old duration calculation still present${NC}"
else
    echo -e "${GREEN}✅ header_kpis.py: Old duration calculation removed${NC}"
fi

if grep -q "LUNCH_DURATION + BREAK_DURATION" src/controllers/Performance_IQ_Manager/production_pct_achieved_drilldown.py; then
    echo -e "${RED}❌ production_pct_achieved_drilldown.py: Old duration calculation still present${NC}"
else
    echo -e "${GREEN}✅ production_pct_achieved_drilldown.py: Old duration calculation removed${NC}"
fi

echo ""

echo "============================================================"
echo "Step 5: Check Server Logs for Errors"
echo "============================================================"

if [ -f logs/app.log ]; then
    ERROR_COUNT=$(grep -c "ERROR" logs/app.log | tail -20 || echo "0")
    echo "Recent errors in logs: $ERROR_COUNT"
    
    if [ "$ERROR_COUNT" -gt "0" ]; then
        echo -e "${YELLOW}Recent ERROR logs:${NC}"
        grep "ERROR" logs/app.log | tail -5
    else
        echo -e "${GREEN}✅ No recent errors in logs${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  Log file not found${NC}"
fi

echo ""

echo "============================================================"
echo "Summary: Production % Query Implementation Status"
echo "============================================================"
echo ""
echo "✅ COMPLETED CHANGES:"
echo "  - PRODUCTIVETIME parsing implemented (replaces duration calculations)"
echo "  - Deduplication logic updated (RETIME DESC NULLS LAST)"
echo "  - Both header KPI and drilldown queries updated"
echo "  - Old calculation method removed"
echo ""
echo "📊 API ENDPOINTS:"
echo "  - POST /manager/header-kpis (Production %)"
echo "  - POST /manager/production-pct-achieved-drilldown"
echo "  - POST /manager/production-pct-achieved-drilldown-excel"
echo ""
echo "🔍 TESTING NOTES:"
echo "  - If Production % returns null, verify test data exists:"
echo "    • User ID has work items in date range"
echo "    • User has PRODUCTIVETIME data in COB_AI_USER_PROFILE"
echo "    • LOB filter matches work items"
echo ""
echo "📝 NEXT STEPS:"
echo "  1. Test with real user data (verify user_id and date range)"
echo "  2. Compare Production % values before/after (should differ)"
echo "  3. Verify count query performance"
echo "  4. Test pagination and Excel download"
echo ""
echo "============================================================"
