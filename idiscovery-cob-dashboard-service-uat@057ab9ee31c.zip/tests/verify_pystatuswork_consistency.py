#!/usr/bin/env python3
"""
Comprehensive verification of PYSTATUSWORK value consistency across all queries.
Checks for:
1. Consistent value usage
2. Correct table usage (INVNTRY vs AUDIT)
3. Pattern consistency
"""

import os
import re
from pathlib import Path
from collections import defaultdict

# PYSTATUSWORK value patterns
EXPECTED_PATTERNS = {
    'COB_AI_INVNTRY_PROFILE': {
        'resolved': "('Resolved-Completed', 'Resolved-AutoCloseLink')",
        'description': 'Resolved work items in inventory profile'
    },
    'COB_AI_AUDIT_PROFILE': {
        'resolved': "('Resolved-Completed', 'Resolved-AutoCloseLink')",
        'resolved_only': "'Resolved-Completed'",
        'open_feedback': "('Open-FeedbackReview', 'Open-RebuttalReview')",
        'open_audit': "('Open-AuditReview', 'Open-AuditUnassigned')",
        'all_statuses': "('Open-FeedbackReview', 'Open-RebuttalReview', 'Open-UpdateAuditCase', 'Resolved-Completed')",
        'description': 'Audit cases with various statuses'
    }
}

def find_python_files(src_dir):
    """Find all Python files in src/controllers directory."""
    controllers_dir = Path(src_dir) / 'controllers'
    services_dir = Path(src_dir) / 'services'
    
    python_files = []
    python_files.extend(list(controllers_dir.rglob('*.py')))
    python_files.extend(list(services_dir.rglob('*.py')))
    
    return python_files

def extract_pystatuswork_patterns(file_path):
    """Extract all PYSTATUSWORK usage patterns from a file."""
    patterns = []
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # Find all PYSTATUSWORK patterns
        # Pattern 1: PYSTATUSWORK IN (...)
        in_patterns = re.finditer(
            r"PYSTATUSWORK\s+IN\s+\((.*?)\)",
            content,
            re.IGNORECASE | re.DOTALL
        )
        for match in in_patterns:
            patterns.append({
                'type': 'IN',
                'values': match.group(1).strip(),
                'line': content[:match.start()].count('\n') + 1
            })
        
        # Pattern 2: PYSTATUSWORK = '...'
        eq_patterns = re.finditer(
            r"PYSTATUSWORK\s*=\s*'([^']+)'",
            content,
            re.IGNORECASE
        )
        for match in eq_patterns:
            patterns.append({
                'type': '=',
                'values': f"'{match.group(1)}'",
                'line': content[:match.start()].count('\n') + 1
            })
            
        # Detect table context
        for pattern in patterns:
            line_num = pattern['line']
            # Get surrounding context
            lines = content.split('\n')
            context_start = max(0, line_num - 20)
            context_end = min(len(lines), line_num + 5)
            context = '\n'.join(lines[context_start:context_end])
            
            if 'COB_AI_INVNTRY_PROFILE' in context:
                pattern['table'] = 'COB_AI_INVNTRY_PROFILE'
            elif 'COB_AI_AUDIT_PROFILE' in context:
                pattern['table'] = 'COB_AI_AUDIT_PROFILE'
            else:
                pattern['table'] = 'UNKNOWN'
                
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        
    return patterns

def verify_consistency():
    """Main verification function."""
    
    src_dir = Path(__file__).parent.parent / 'src'
    
    print("=" * 80)
    print("PYSTATUSWORK CONSISTENCY VERIFICATION")
    print("=" * 80)
    print()
    
    # Collect all patterns
    all_patterns = defaultdict(list)
    file_count = 0
    pattern_count = 0
    
    for file_path in find_python_files(src_dir):
        patterns = extract_pystatuswork_patterns(file_path)
        if patterns:
            file_count += 1
            pattern_count += len(patterns)
            for pattern in patterns:
                pattern['file'] = str(file_path.relative_to(src_dir.parent))
                all_patterns[pattern['table']].append(pattern)
    
    print(f"📊 Scanned {file_count} files with PYSTATUSWORK usage")
    print(f"📊 Found {pattern_count} total PYSTATUSWORK patterns")
    print()
    
    # Analyze by table
    issues = []
    
    for table, patterns in sorted(all_patterns.items()):
        print(f"\n{'='*80}")
        print(f"TABLE: {table}")
        print(f"{'='*80}")
        print(f"Usage count: {len(patterns)} occurrences")
        print()
        
        # Group by unique value patterns
        value_groups = defaultdict(list)
        for pattern in patterns:
            key = f"{pattern['type']} {pattern['values']}"
            value_groups[key].append(pattern)
        
        print(f"Unique patterns found: {len(value_groups)}")
        print()
        
        for idx, (value_pattern, occurrences) in enumerate(sorted(value_groups.items()), 1):
            print(f"{idx}. Pattern: {value_pattern}")
            print(f"   Occurrences: {len(occurrences)}")
            print(f"   Examples:")
            for occ in occurrences[:3]:  # Show first 3 examples
                print(f"     - {occ['file']}:{occ['line']}")
            if len(occurrences) > 3:
                print(f"     ... and {len(occurrences) - 3} more")
            print()
    
    # Check for order inconsistencies
    print(f"\n{'='*80}")
    print("ORDER CONSISTENCY CHECK")
    print(f"{'='*80}")
    print()
    
    invntry_patterns = all_patterns['COB_AI_INVNTRY_PROFILE']
    order_issues = []
    
    for pattern in invntry_patterns:
        values = pattern['values']
        # Check if order is reversed
        if "'Resolved-AutoCloseLink', 'Resolved-Completed'" in values:
            order_issues.append(pattern)
    
    if order_issues:
        print(f"⚠️  Found {len(order_issues)} files with reversed order:")
        for issue in order_issues:
            print(f"   - {issue['file']}:{issue['line']}")
            print(f"     Current: {issue['values']}")
            print(f"     Expected: ('Resolved-Completed', 'Resolved-AutoCloseLink')")
        print()
    else:
        print("✅ All INVNTRY_PROFILE queries use consistent order")
        print()
    
    # Summary
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    print()
    
    print(f"✅ Total files checked: {file_count}")
    print(f"✅ Total patterns found: {pattern_count}")
    print()
    
    print("📋 PYSTATUSWORK Values in Use:")
    print()
    print("   COB_AI_INVNTRY_PROFILE:")
    print("   - 'Resolved-Completed'")
    print("   - 'Resolved-AutoCloseLink'")
    print()
    print("   COB_AI_AUDIT_PROFILE:")
    print("   - 'Resolved-Completed'")
    print("   - 'Resolved-AutoCloseLink'")
    print("   - 'Open-FeedbackReview'")
    print("   - 'Open-RebuttalReview'")
    print("   - 'Open-UpdateAuditCase'")
    print("   - 'Open-AuditReview'")
    print("   - 'Open-AuditUnassigned'")
    print()
    
    if order_issues:
        print(f"⚠️  {len(order_issues)} order inconsistencies found")
        return 1
    else:
        print("✅ No critical issues found - all patterns are consistent!")
        return 0

if __name__ == "__main__":
    exit(verify_consistency())
