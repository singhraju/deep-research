#!/usr/bin/env python3
"""
Script to verify unique PYSTATUSWORK values in COB_AI_INVNTRY_PROFILE table.
"""

import sys
import os

# Add parent directory to path to import modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from db.connection_manager import get_engine

async def main():
    """Query unique PYSTATUSWORK values from database."""
    
    query = """
    SELECT DISTINCT PYSTATUSWORK
    FROM COB_AI_INVNTRY_PROFILE
    WHERE PYSTATUSWORK IS NOT NULL
    ORDER BY PYSTATUSWORK;
    """
    
    print("Querying unique PYSTATUSWORK values...")
    print("=" * 60)
    
    try:
        engine = get_engine()
        results = engine.execute_query(query)
        
        if not results:
            print("No results found.")
            return
        
        print(f"\nFound {len(results)} unique values:\n")
        
        for idx, row in enumerate(results, 1):
            value = row.get('PYSTATUSWORK', 'N/A')
            print(f"{idx:3d}. {value}")
        
        print("\n" + "=" * 60)
        print(f"Total unique PYSTATUSWORK values: {len(results)}")
        
    except Exception as e:
        print(f"Error querying database: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
