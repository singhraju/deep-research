import asyncio
import sys
import types
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from fastapi import Response

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

framework_module = types.ModuleType("idiscovery_framework")
llm_module = types.ModuleType("idiscovery_framework.llm")
framework_openai_module = types.ModuleType("idiscovery_framework.llm.openai_service")


class _DummyOpenAIService:
    def __init__(self, *args, **kwargs):
        pass


class _DummyRedisHandler:
    def __init__(self, *args, **kwargs):
        pass

    async def connect(self):
        return None

    async def disconnect(self):
        return None


framework_openai_module.OpenAIService = _DummyOpenAIService
framework_module.RedisHandler = _DummyRedisHandler
sys.modules.setdefault("idiscovery_framework", framework_module)
sys.modules.setdefault("idiscovery_framework.llm", llm_module)
sys.modules.setdefault("idiscovery_framework.llm.openai_service", framework_openai_module)

from controllers.WorkForce_IQ import ai_coach as workforce_ai_coach
from schema import WorkforceIQAICoachRequest
from services.openai_service import normalize_ai_summary


class WorkforceAICoachTests(unittest.TestCase):
    def test_normalize_ai_summary_parses_json_payload(self):
        normalized = normalize_ai_summary('{"performance_summary": "Backlog pressure is rising", "confidence": 0.84}')

        self.assertEqual(normalized["performance_summary"], "Backlog pressure is rising")
        self.assertEqual(normalized["parsed_payload"]["confidence"], 0.84)

    def test_workforce_controller_passes_session_id_to_metrics_fetch(self):
        seen = {}

        async def fake_fetch_workforce_metrics(**kwargs):
            seen["session_id"] = kwargs.get("session_id")
            return {
                "metrics": {"backlog_volume": {"label": "Backlog Volume", "value": 10}},
                "data_gaps": [],
            }

        async def fake_generate_performance_summary(**_kwargs):
            return '{"performance_summary": "OK"}'

        request = WorkforceIQAICoachRequest(
            user_id="u123",
            start_date="2024-01-01",
            end_date="2024-01-31",
            persona="director",
            session_id="abc123xyz",
        )
        response = Response()

        with patch.object(
            workforce_ai_coach,
            "fetch_workforce_metrics",
            side_effect=fake_fetch_workforce_metrics,
        ), patch.object(
            workforce_ai_coach,
            "generate_performance_summary",
            side_effect=fake_generate_performance_summary,
        ):
            result = asyncio.run(workforce_ai_coach.get_workforce_ai_coach(request, response))

        self.assertEqual(result.status, "success")
        self.assertEqual(seen.get("session_id"), "abc123xyz")

    def test_workforce_controller_reads_parsed_payload(self):
        async def fake_fetch_workforce_metrics(**_kwargs):
            return {
                "metrics": {"backlog_volume": {"label": "Backlog Volume", "value": 12}},
                "data_gaps": ["aggregator_gap"],
            }

        async def fake_generate_performance_summary(**_kwargs):
            return (
                '{'
                '"performance_summary": "Shift staffing to backlog-heavy queues", '
                '"confidence": 0.91, '
                '"primary_issue": "Backlog pressure", '
                '"primary_metric": "backlog_volume", '
                '"secondary_issues": ["Capacity tightness"], '
                '"data_gaps": ["llm_gap"], '
                '"recommended_action": "Rebalance work", '
                '"severity": "high"'
                '}'
            )

        request = WorkforceIQAICoachRequest(
            user_id="u123",
            start_date="2024-01-01",
            end_date="2024-01-31",
            persona="director",
        )
        response = Response()

        with patch.object(
            workforce_ai_coach.config,
            "is_ai_coach_enabled",
            lambda role: True,
        ), patch.object(
            workforce_ai_coach,
            "fetch_workforce_metrics",
            new=fake_fetch_workforce_metrics,
        ), patch.object(
            workforce_ai_coach,
            "generate_performance_summary",
            new=fake_generate_performance_summary,
        ), patch.object(
            workforce_ai_coach,
            "AICoachResponse",
            new=SimpleNamespace,
        ):
            result = asyncio.run(workforce_ai_coach.get_workforce_ai_coach(request, response))

        self.assertEqual(result.status, "success")
        self.assertEqual(result.performance_summary, "Shift staffing to backlog-heavy queues")
        self.assertEqual(result.confidence, 0.91)
        self.assertEqual(result.primary_issue, "Backlog pressure")
        self.assertEqual(result.primary_metric, "backlog_volume")
        self.assertEqual(result.secondary_issues, ["Capacity tightness"])
        self.assertEqual(result.data_gaps, ["llm_gap"])
        self.assertEqual(result.recommended_action, "Rebalance work")
        self.assertEqual(result.severity, "high")
        self.assertEqual(result.metadata["persona"], "director")

    def test_workforce_controller_filters_metrics_by_persona_before_llm(self):
        captured = {}

        async def fake_fetch_workforce_metrics(**_kwargs):
            return {
                "metrics": {
                    "backlog_volume": {"label": "Backlog Volume", "value": 18},
                    "actual_membership": {"label": "Actual Membership", "value": "27.2M"},
                    "top_work_type": {"label": "Top Work Type", "value": "CIW"},
                    "top_market": {"label": "Top Market by Inventory", "value": "GA"},
                },
                "data_gaps": ["actual_membership", "top_market"],
            }

        async def fake_generate_performance_summary(**kwargs):
            captured["metrics_data"] = kwargs["metrics_data"]
            return '{"performance_summary": "Manager workforce summary"}'

        request = WorkforceIQAICoachRequest(
            user_id="u123",
            start_date="2024-01-01",
            end_date="2024-01-31",
            persona="manager",
        )
        response = Response()

        with patch.object(
            workforce_ai_coach.config,
            "is_ai_coach_enabled",
            lambda role: True,
        ), patch.object(
            workforce_ai_coach,
            "fetch_workforce_metrics",
            new=fake_fetch_workforce_metrics,
        ), patch.object(
            workforce_ai_coach,
            "generate_performance_summary",
            new=fake_generate_performance_summary,
        ), patch.object(
            workforce_ai_coach,
            "AICoachResponse",
            new=SimpleNamespace,
        ):
            result = asyncio.run(workforce_ai_coach.get_workforce_ai_coach(request, response))

        self.assertEqual(result.status, "success")
        self.assertEqual(result.metadata["persona"], "manager")
        self.assertIn("backlog_volume", captured["metrics_data"]["metrics"])
        self.assertIn("top_work_type", captured["metrics_data"]["metrics"])
        self.assertIn("actual_membership", captured["metrics_data"]["metrics"])
        self.assertIn("top_market", captured["metrics_data"]["metrics"])

    def test_workforce_controller_rejects_unsupported_persona(self):
        request = WorkforceIQAICoachRequest(
            user_id="u123",
            start_date="2024-01-01",
            end_date="2024-01-31",
            persona="frontline",
        )
        response = Response()

        with patch.object(
            workforce_ai_coach.config,
            "is_ai_coach_enabled",
            lambda role: True,
        ), patch.object(
            workforce_ai_coach,
            "AICoachResponse",
            new=SimpleNamespace,
        ):
            result = asyncio.run(workforce_ai_coach.get_workforce_ai_coach(request, response))

        self.assertEqual(response.status_code, 422)
        self.assertEqual(result.status, "error")
        self.assertIn("Unsupported Workforce persona", result.message)

    def test_workforce_controller_sets_http_500_when_metrics_fetch_fails(self):
        async def fake_fetch_workforce_metrics(**_kwargs):
            return {
                "error": "metrics backend unavailable",
                "data_gaps": ["backlog_volume"],
                "metrics": {},
            }

        request = WorkforceIQAICoachRequest(
            user_id="u123",
            start_date="2024-01-01",
            end_date="2024-01-31",
            persona="director",
        )
        response = Response()

        with patch.object(
            workforce_ai_coach.config,
            "is_ai_coach_enabled",
            lambda role: True,
        ), patch.object(
            workforce_ai_coach,
            "fetch_workforce_metrics",
            new=fake_fetch_workforce_metrics,
        ), patch.object(
            workforce_ai_coach,
            "AICoachResponse",
            new=SimpleNamespace,
        ):
            result = asyncio.run(workforce_ai_coach.get_workforce_ai_coach(request, response))

        self.assertEqual(response.status_code, 500)
        self.assertEqual(result.status, "error")
        self.assertIn("metrics backend unavailable", result.message)


if __name__ == "__main__":
    unittest.main()
