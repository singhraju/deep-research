"""
Reimbursement Policy Extraction Agent

Top-K is the agent's only mode. Given a semantic-view ``yaml_path`` and an optional
nested AND/OR ``filters`` tree, it ranks a dimension (default: provider taxonomy) by a
declared metric (default: total paid) over the claims view, then hydrates and extracts
structured adjudication rules for the top-ranked taxonomies' reimbursement policies via
the Carelon policy comparison API and the Snowflake policy database. A supplied
``pattern`` dict is optional narrative enrichment only (title / evidence summary /
why-it-matters); codes, states, and LOBs are derived solely from ``filters``.

Usage:
    >>> from deep_research_agents import ReimbursementAgent
    >>>
    >>> agent = ReimbursementAgent(
    ...     snowflake_helper=snowpark,  # Optional, will auto-build if not provided
    ... )
    >>>
    >>> results = agent(
    ...     yaml_path="configs/correlation_pattern/coc_ecap_oon_semantic_view.yaml",
    ...     filters={"logic": "AND", "conditions": [
    ...         {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"},
    ...     ]},
    ... )
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
import uuid
import textwrap
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, TypedDict
from typing import override
import requests
import pandas as pd
from langgraph.graph import END, START, StateGraph
from pydantic import ValidationError

from deep_research_core.base_agent import AgentBase, AgentConfigurationError, CredentialProvider
from deep_research_core.query_builder_agent import QueryBuilderAgent
from deep_research_utils.app_constant import AppConstants
from deep_research_utils.semantic_sql import (
    SemanticCatalog,
    build_semantic_catalog,
    collect_filter_leaves,
    ensure_dir,
    execute_sql_to_df,
    load_semantic_yaml,
    resolve_semantic_model_path,
)
from deep_research_utils.topk_sql import (
    DEFAULT_METRIC,
    build_topk_query_sql,
)
from deep_research_agents.models.reimbursement_models import (
    PolicyExtractionResponse,
    TableSchemaResponse,
    ElevanceSummaryResponse,
    ReimbursementAgentResponseSchema,
    PolicyTriageResponse,
)

try:
    from deep_research_utils.logger_config import get_logger

    logger = get_logger(__name__)
except ImportError:  # pragma: no cover - local/dev fallback
    logger = logging.getLogger(__name__)

# ============================================================================
# Run persistence helpers (queries + summary only — NEVER rows)
# ============================================================================
#
# Top-K mode writes a per-run artifact directory mirroring the correlation
# agent's layout (correlation_agent.build_run_id / write_text / write_json), but
# deliberately persists ONLY the query definition and a small JSON summary — no
# subset table, no parquet, no result rows. These live locally (rather than being
# imported from correlation_agent) to keep the two agents decoupled.


def _slugify(text: Any) -> str:
    """Lowercase, hyphenated slug safe for a directory name (mirrors correlation)."""
    slug = re.sub(r"[^a-z0-9]+", "-", str(text).strip().lower()).strip("-")
    return slug or "reimbursement-topk"


def _build_run_id(slug_source: Any) -> str:
    """``{utc_timestamp}_{slug}_{uuid8}`` — same shape as correlation's run ids."""
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{timestamp}_{_slugify(slug_source)[:40]}_{uuid.uuid4().hex[:8]}"


def _write_text(path: Path, content: str) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(content)


def _write_json(path: Path, payload: Any) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False, default=str)


# ============================================================================
# Type Definitions
# ============================================================================


class ReimbursementState(TypedDict, total=False):
    """State for reimbursement policy extraction agent (single-pattern processing)."""
    
    # Orchestrator inputs - PATTERN REQUIRED
    conversation_id: str  # Conversation ID from orchestrator
    query: str  # User query from UI
    context: Dict[str, Any]  # Full context from orchestrator (must contain 'pattern')
    job_id: str  # Job ID for this execution
    
    # Pattern data (extracted from context)
    pattern: Dict[str, Any]  # Single pattern structure from pattern agent
    pattern_rank: int  # Pattern identifier
    
    # Clinical codes carried from the filter tree (via _extract_filter_codes)
    cpt_codes: str  # Comma-separated CPT/HCPCS codes (from filters)
    drg_codes: List[str]  # DRG codes (from filters)
    search_keywords: List[str]  # Optional keyword hints for policy search (list of keywords)
    
    # Intermediate state
    raw_policies: List[Dict[str, Any]]  # Raw API response
    filtered_policies: List[Dict[str, Any]]  # After deduplication
    policy_content: List[Dict[str, Any]]  # Full text from Snowflake
    
    # Resources
    snowflake_helper: Any  # SnowparkHelper instance
    llm: Any  # LLM client (GPT-5.4 for all operations except policy processing)
    llm_nano: Any  # LLM client for policy processing (GPT-5.4-nano for speed)
    llm_mini: Any  # LLM client used only on extract retry (GPT-5.4-mini, stronger instruction-following)
    
    # Execution tracking
    start_time: str  # ISO timestamp
    input_tokens: int  # Total input tokens
    output_tokens: int  # Total output tokens
    
    # Output
    result: List[Dict[str, Any]]  # Extracted rules per policy
    policy_contamination_summary: Dict[str, Any]  # validate_policies_node aggregate
    table_structure: TableSchemaResponse  # Column analysis and structure metadata
    column_metadata: List[Dict[str, str]]  # LLM-generated column info
    formatted_output: Dict[str, Any]  # Formatted reimbursement output with summary_table and individual_policies
    elevance_executive_summary: Optional[str]  # Elevance executive summary (from notebook logic)
    recommended_action: Optional[List[Dict[str, Any]]]  # List of structured recommendations
    recommendation_validation: Optional[Dict[str, Any]]  # Validator verdict + dropped-item summary

    # --- Semantic-YAML SQL mode (shared setup) ---
    # The agent is decoupled: top-K is the only mode. It is always driven by a
    # semantic-view YAML (+ an optional nested AND/OR filters tree); there is no
    # pattern or legacy cpt_codes mode. A supplied `pattern` is narrative-only.
    mode: str  # always "topk" (the sole mode)
    yaml_path: str  # Resolved+validated semantic-view YAML path
    semantic_model: Dict[str, Any]  # Parsed semantic YAML
    catalog: SemanticCatalog  # build_semantic_catalog(semantic_model) output
    persist_queries: bool  # Whether to persist the query + summary locally (never rows)
    output_root: str  # Root dir for per-run query/summary artifacts (default reimbursement_runs)

    # --- Top-K mode (rank one dimension by a declared metric) ---
    # Populated ONLY when mode == "topk". Pattern and legacy modes never set these.
    dimension: str               # Group-by dimension (default provider_taxonomy_type)
    metric: str                  # Ranking metric name declared in the model's metrics
    top_k: int                   # Number of ranked rows to return (the query's LIMIT)
    filters: Any                 # Optional nested AND/OR filter tree narrowing the population
    topk_query: str              # Built SQL (build_topk_query_node output)
    topk_meta: Dict[str, Any]    # Resolved dimension/metric/alias/table metadata
    topk_result: Dict[str, Any]  # run_topk_query_node output: sql + rows + persistence meta

    # --- Top-K taxonomy->policy chain (find_taxonomy_policies_node) ---
    # Ranked NUCC taxonomy codes pulled from topk_result rows, and the policy
    # metadata they map to via configs/policy_taxonomy_mapping.json. Populated
    # only in top-K mode.
    taxonomy_codes: List[str]              # Ranked taxonomy codes from the top-K rows
    taxonomy_policies: List[Dict[str, Any]]  # Policy metadata mapped from those codes
    states: List[str]            # Optional state-code narrowing for policy hydration
    lobs: List[str]              # Optional line-of-business narrowing for policy hydration
    filter_codes: Dict[str, List[str]]  # code-type -> values pulled from the filters tree
                                         # (state/lob/drg/cpt/hcpcs/procedure/diagnosis/revenue);
                                         # feeds the relevance judge + rule extraction
    fetch_competitor_policies: bool  # When True, hydrate peer payors' policies sharing the
                                     # mapped policies' topics instead of the policies themselves


# ============================================================================
# Prompts
# ============================================================================


SYSTEM_PROMPT = """You are an expert at analyzing healthcare reimbursement policies and extracting key information.
Read the policy text and return valid JSON only.
Follow the exact schema provided.
Do not output markdown or explanatory text.
Use null or [] when information is missing."""

USER_PROMPT_TEMPLATE = """Given the following codes/context: {pattern_details}

Policy Text: {policy_text}

Extract adjudication rules for the requested codes. Return ONLY valid JSON matching this schema:

{{
  "policy_metadata": {{
    "policy_scope": "string",
    "effective_date": "string or null",
    "specialty_specific": "boolean",
    "diagnosis_specific": "boolean"
  }},
  "results": [
    {{
      "code": "string",
      "mention_status": "mentioned | not_mentioned",
      "payor_level_summary": "string",
      "site_of_service": "string",
      "bundling_logic": "string",
      "code_interactions": "string",
      "authorization_requirements": "string",
      "documentation_requirements": "string",
      "limitations": "string",
      "exclusions": "string",
      "specific_rule_text": "string",
      "confidence": "high | medium | low",

      "action_type": "deny | bundle | require_auth | pay_separately | allow_with_conditions | limit | null",
      "target_codes": ["string", ...],
      "related_codes": ["string", ...],
      "required_modifiers": ["string", ...],
      "excluded_modifiers": ["string", ...],
      "revenue_codes": ["string", ...],
      "pairing_conditions": ["string", ...],
      "utilization_limits": ["string", ...],
      "prior_auth_thresholds": ["string", ...],
      "discharge_status_conditions": ["string", ...],
      "program_scope": ["string", ...],
      "state_specific_rules": ["string", ...],
      "provider_role_restrictions": ["string", ...],
      "exemptions": ["string", ...]
    }}
  ]
}}

Prose field guidance:
- code: DRG code or CPT code being analyzed
- mention_status: Whether the code is explicitly mentioned in the policy
- payor_level_summary: Overall aggregated summary for this code
- site_of_service: Allowed, restricted, or excluded settings
- bundling_logic: Whether the code is bundled, inclusive, or separately reimbursed
- code_interactions: Interactions with other codes or procedures
- authorization_requirements: Prior authorization or notification requirements
- documentation_requirements: Required clinical documentation
- limitations: Frequency, quantity, or other limitations
- exclusions: Conditions or scenarios where code is not covered
- specific_rule_text: Exact text from policy supporting the finding
- confidence: Your confidence in the extraction

Structured edit-rule field guidance — these power code-specific recommendations.
Extract ONLY the minimal code/identifier WITHOUT any descriptive prefix text.
Strip labels like "CPT ", "Modifier ", "RC ", "Code ", hyphens, or parenthetical
descriptions. If you see "Modifier D - Diagnostic", extract just "D". If you see
"CPT 99291 (critical care)", extract just "99291". Keep each array entry ≤8 words.
Use empty arrays (not null) when nothing applies.

IMPORTANT: Distinguish between CODES and MODIFIERS:
- CODES (target_codes/related_codes): Procedure/diagnosis identifiers — always
  have digits (99291, G0378, 469, A0427). Even HCPCS has letter + 4 DIGITS.
- MODIFIERS (required_modifiers/excluded_modifiers): Claim-line qualifiers —
  typically 1-3 alphanumeric chars (25, 59, XU, GM, QL, QM, D, E, H).
If you see 1-2 uppercase letters (GM, QL, QN) in an ambulance policy, those are
MODIFIERS, not codes. Put them in required_modifiers or excluded_modifiers.

- action_type: The dominant action the rule takes (deny / bundle / require_auth /
  pay_separately / allow_with_conditions / limit). null if unclear.
- target_codes: Extract ONLY procedure/diagnosis code identifiers. Must be either
  (a) 3-5 digits with optional letter (CPT/DRG: 99291, 469, 99284T), or
  (b) letter + 4 digits (HCPCS: G0378, A0427), or
  (c) letter + 2+ digits with optional decimal (ICD-10: O30.001, C50.9).
  Accept ranges (e.g., ["99210-99220"], ["A0426-A0428"]).
  Do NOT put 1-2 letter codes here — those are modifiers (see below).
  Examples: ✓ ["99291", "G0378", "469", "99210-99220"] ✗ ["GM", "QL", "CPT 99291"]
- related_codes: Same rules as target_codes. Other procedure/diagnosis codes
  referenced in the condition (e.g., ["99281", "99285", "G0378"]).
  Do NOT put modifiers (GM, QL, QM, QN, etc.) here — use required_modifiers/excluded_modifiers.
- required_modifiers / excluded_modifiers: Extract ONLY the 1-3 character
  modifier code. Strip any prefix text like "Modifier ", "modifier ", leading
  hyphens, or descriptions. Examples:
    ✓ Correct: ["25"], ["59", "XU"], ["D", "E"], ["GM", "QL"]
    ✗ Wrong: ["Modifier 25"], ["modifier D"], ["-H"], ["Modifier GM"]
  If the policy says "Modifier D - Diagnostic site", extract just "D".
  If the policy says "-H (Hospital)", extract just "H".
- revenue_codes: Extract ONLY the 3-5 digit code, preserving X wildcards and
  ranges. Strip any prefix like "RC ", "Revenue Code ", etc. Examples:
    ✓ Correct: ["045X", "0762", "068X", "0450-0459"]
    ✗ Wrong: ["RC 0762", "Revenue Code 045X", "0450 (emergency)"]
- pairing_conditions: Short claim-/timing-level phrases. Examples:
  "same claim line", "same date of service", "day before ED visit",
  "within 24 hours of ED visit".
- utilization_limits: Numeric limits with units. Examples:
  "10 hrs/week BCBA", "max 8 hours per DOS", "30 sessions/year".
- prior_auth_thresholds: PA trigger phrases citing the code + threshold.
  Examples: "PA required after 20 sessions of 90837",
  "auth required for >2 units of G0378".
- discharge_status_conditions: Discharge-disposition restrictions formatted
  "discharge status <code> (<label>)". Example: "discharge status 01 (home)".
- program_scope: Programs the rule applies to. Examples: ["COPPS"], ["DRG"],
  ["APC"], ["OPPS"], ["MS-DRG"], ["Case rate"].
- state_specific_rules: State-scoped rules. Example: "NC: 20 session cap".
- provider_role_restrictions: Role / oversight requirements. Examples:
  "BCBA oversight required", "QP/AP billing only".
- exemptions: Conditions that EXEMPT a claim from the rule (look for "except",
  "unless", "does not apply when"). Cite the exempting code/RC verbatim.
  Examples: "observation RC 0762", "trauma activation RC 068X".

Anti-contamination guardrails (CRITICAL — violations cause downstream filtering):
1. Describe ONLY the payer that authored this policy. Never reference any
   other payer by name (Cigna, Aetna, Humana, UHC, United Health, Elevance,
   Anthem, Molina, BCBS, Blue Cross, Kaiser, WellCare) in payor_level_summary,
   specific_rule_text, or any field. If the policy text mentions another
   payer comparatively, paraphrase without naming them.
2. target_codes, related_codes, required_modifiers, excluded_modifiers, and
   revenue_codes must contain ONLY the minimal code identifier without any
   prefix labels or descriptions. Do NOT copy:
   - Prompt headers: "DRG Codes:", "CPT/HCPCS Codes:", "Pattern:"
   - Code type prefixes: "CPT ", "HCPCS ", "Modifier ", "RC ", "Code "
   - Leading symbols: "-" (unless it's part of a range like "99210-99220")
   - Descriptions: "Modifier D - Diagnostic", "CPT 99291 (critical care)"
   Extract ONLY: "99291", "D", "0762", "99210-99220"
3. Distinguish "off-topic" from "uses different code system". The requested
   codes/context may reference a DRG/MS-DRG label, a CPT/HCPCS code, an ICD-10
   diagnosis, or a clinical concept — and the policy may adjudicate the same
   claims using any of those code systems.
   - OFF-TOPIC (policy governs an unrelated clinical area, e.g. an
     anesthesia-only policy when the request is about behavioral health,
     or a readmission billing policy when the request is about a surgical
     DRG): return empty arrays for the structured edit-rule fields and
     say so in payor_level_summary.
   - ON-TOPIC but uses a different code system than the request specifies
     (e.g. policy cites CPT/HCPCS or modifiers while the request names a
     DRG, or policy cites ICD-10 diagnoses while the request names a
     procedure): EXTRACT every code/modifier/revenue code that appears
     in the policy and governs the same claims. A bundling rule, a
     modifier requirement, or a coverage limit that applies to the
     requested clinical area is in-scope even if the policy never quotes
     the DRG/CPT label from the prompt. Empty arrays are the WRONG
     answer here.
   Do NOT fabricate codes or rules from the prompt headers — every code
   you return must appear verbatim in the policy text.

Return ONLY valid JSON, no explanatory text."""

TRIAGE_SYSTEM_PROMPT = """You rank reimbursement policies by relevance to a billing pattern.
Return ONLY valid JSON with relevancy scores for each policy.
Score each policy from 0-100 based on how relevant its title is to the pattern context.
Order the list from most to least relevant. Do not invent policy IDs."""

TRIAGE_USER_PROMPT_TEMPLATE = """Pattern context:
{pattern_details}

Candidate policies (policy_id | payor | title):
{policy_lines}

Score each policy's relevance to the pattern from 0-100:
- 80-100: Highly relevant (title directly references CPT/DRG codes or clinical concept)
- 60-79: Moderately relevant (title relates to the clinical area or context)
- 40-59: Somewhat relevant (title has tangential connection)
- 0-39: Low relevance (title appears off-topic or unrelated)

Prefer policies whose titles reference the CPT/DRG codes, the clinical concept in the
pattern, or the LOB/state context.

Return ONLY JSON in this format:
{{
  "policy_scores": [
    {{"policy_id": "<id>", "relevancy_score": <0-100>, "reasoning": "<brief explanation>"}},
    ...
  ],
  "selected_policy_ids": ["<id1>", "<id2>", ...]
}}

Order both lists from most to least relevant."""


# Top-K ranking dimension for the chained taxonomy->policy flow. Unlike the
# generic topk default (`provider_taxonomy_type`, a specialty NAME), this is the
# NUCC 10-char taxonomy CODE (e.g. "282N00000X") whose values key directly into
# configs/policy_taxonomy_mapping.json — so the ranked rows can be mapped to
# reimbursement policies in find_taxonomy_policies_node.
TAXONOMY_CODE_DIMENSION = "provider_taxonomy_specialization_code"

# Selection rule applied to the ranked taxonomies before mapping them to
# policies (find_taxonomy_policies_node). Ranked rows come from the top-K SQL
# ordered by metric DESC; we drop sentinel codes, keep the smallest top set
# whose cumulative metric reaches the Pareto threshold, then hard-cap the count
# so only the highest-value taxonomies drive the policy search.
TAXONOMY_EXCLUDE_CODES = {"-2"}      # sentinel taxonomies dropped before selection
TAXONOMY_PARETO_THRESHOLD = 0.90     # cumulative metric share cutoff
TAXONOMY_MAX_SELECTED = 3            # hard cap on taxonomies mapped to policies


# Maps a logical code-type to the filter-tree ``field`` names that represent it.
# Used by ``_extract_filter_codes`` to pull state / LOB / clinical codes out of
# the same nested AND/OR ``filters`` tree that drives the top-K ranking query.
# Matching is case-insensitive on the leaf ``field``. Field names vary per
# semantic YAML, so extend the alias lists as new views are onboarded. Code
# types whose fields are absent from the active YAML simply never appear in the
# tree and are ignored (no error).
FILTER_CODE_ALIASES: Dict[str, List[str]] = {
    "state":     ["state_code", "service_area_state", "plan_state_code", "st_cd"],
    "lob":       ["lob_code", "lob_description", "lob_nm"],
    "drg":       ["drg_code", "drg_name"],
    "procedure": ["procedure_code", "procedure_name"],
    "cpt":       ["cpt_code", "cpt"],
    "hcpcs":     ["hcpcs_code", "hcpcs"],
    "diagnosis": ["primary_diagnosis_code", "diagnosis_code", "diagnosis_ccs_class", "diag_code"],
    "revenue":   ["revenue_code", "rvnu_code", "rvnu"],
}

# Reverse index (field name -> code type), lower-cased, built once at import.
_FILTER_FIELD_TO_CODE_TYPE: Dict[str, str] = {
    field.lower(): code_type
    for code_type, fields in FILTER_CODE_ALIASES.items()
    for field in fields
}

# ST_CD values that denote a national / non-state-specific reimbursement policy.
# Reimbursement policies are mostly national (state is encoded in the policy
# title, not ST_CD), so state narrowing must keep these alongside the requested
# states or it would exclude every applicable national policy. NULL / blank
# ST_CD are handled directly in the predicate; this catches an explicit marker
# if one exists. Conservative default -- confirm/extend against live PLCY_MTDTA.
POLICY_NATIONAL_ST_CD_SENTINELS: tuple = ("ALL", "US", "USA", "NATIONAL")

# Per-payor + global caps applied at the end of search_policies_node.
# Elevance is pinned (always retained when present in API results) — the
# triage LLM never gets to drop it.
POLICY_CAP_MAX_PER_PAYOR = 5
POLICY_CAP_MAX_TOTAL = 30
ELEVANCE_PAYOR_TOKEN = "Elevance"
POLICY_RELEVANCY_THRESHOLD = 60  # Minimum relevancy score (0-100) to include a policy

# ============================================================================
# Reimbursement Policy Agent
# ============================================================================


class ReimbursementPolicyAgent(QueryBuilderAgent):
    """
    Agent for extracting structured adjudication rules from reimbursement policies.
    
    This agent:
    1. Searches for policies via Carelon policy comparison API
    2. Filters and deduplicates policies by payor and hash
    3. Retrieves full policy text from Snowflake
    4. Uses LLM to extract structured rules for each CPT code
    
    Args:
        snowflake_helper: Optional SnowparkHelper instance
        snowflake_helper_builder: Optional callable that returns SnowparkHelper
        policy_api_url: Base URL for policy comparison API
        retry_delay: Seconds to wait before retrying failed LLM calls
        max_retries: Maximum number of retries for failed LLM calls
        **kwargs: Additional arguments passed to AgentBase
    """

    api_response_model = ReimbursementAgentResponseSchema

    # QueryBuilderAgent defaults: rank the NUCC taxonomy CODE dimension (not the
    # generic provider_taxonomy_type name) by total_paid, so the ranked rows key
    # into policy_taxonomy_mapping.json for the taxonomy->policy chain. These match
    # the fallbacks build_topk_query_node already applies, so behavior is unchanged.
    TOPK_DEFAULT_DIMENSION = TAXONOMY_CODE_DIMENSION
    TOPK_DEFAULT_METRIC = DEFAULT_METRIC

    def __init__(
        self,
        snowflake_helper: Optional[Any] = None,
        snowflake_helper_builder: Optional[Callable[[], Any]] = None,
        policy_api_url: str = "https://policy-comparison-api.carelon.com/policy_comparison/search",
        retry_delay: int = 30,
        max_retries: int = 1,
        llm_timeout: Optional[float] = None,
        **kwargs
    ):
        # Configuration (set before base init)
        self.policy_api_url = policy_api_url
        self.retry_delay = retry_delay
        self.max_retries = max_retries
        
        # Initialize base agent first (sets up self.logger)
        # Pass llm_timeout to base class - it will be stored as self.llm_timeout
        super().__init__(
            agent_name="reimbursement_policy",
            state_class=ReimbursementState,
            llm_reasoning_effort="medium",  # GPT-5.4 for all operations except policy processing
            llm_timeout=llm_timeout,
            **kwargs
        )
        
        # Initialize Snowflake connection (after logger is available)
        self.snowflake_helper = self._init_snowflake(
            snowflake_helper,
            snowflake_helper_builder
        )
        
        # Build table registry from config (all config items are tables for this agent)
        self._table_registry = self._build_table_registry()
        
        # Initialize mini LLM for policy processing (GPT-5.4-nano for better performance with large sets)
        self.llm_nano = self._init_llm("nano")

        # Initialize the retry LLM (GPT-5.4-mini, one tier up from nano with
        # stronger instruction-following). Used ONLY when the first nano
        # attempt at policy extraction fails — escalating on retry gives
        # the policy a second chance with a model that's better at
        # respecting the anti-leakage guardrails in USER_PROMPT_TEMPLATE.
        self.llm_mini = self._init_llm("mini")

        # Per-invocation token tracking — populated by _record_tokens after every
        # successful llm.invoke() and reset at the start of each prepare_state().
        # The lock protects the read-modify-write inside _record_tokens when
        # extract_rules / the relevance judge fan out across worker threads.
        self._token_breakdown: Dict[str, Dict[str, int]] = {}
        self._token_lock = threading.Lock()

    def _init_llm(self, model_type: str = "base") -> Any:
        """
        Initialize LLM with specified model configuration.

        Args:
            model_type: Type of model to initialize ('base', 'mini', or 'nano')
                - 'base': GPT-5.4-mini with medium reasoning (for retry operations)
                - 'mini': GPT-5.4-nano with low reasoning (for fast policy extraction)
                - 'nano': GPT-5.4-nano with low reasoning (alias for 'mini')

        Returns:
            Configured ChatOpenAI instance
        """
        model_configs = {
            "base": {"model": "gpt-5.4", "reasoning": "high"},
            "mini": {"model": "gpt-5.4-mini", "reasoning": "medium"},
            "nano": {"model": "gpt-5.4-nano", "reasoning": "low"},
        }

        if model_type not in model_configs:
            self.logger.warning(f"Unknown model type '{model_type}', defaulting to 'base'")
            model_type = "base"

        config = model_configs[model_type]
        
        try:
            from langchain_openai import ChatOpenAI
            from deep_research_core.base_agent import CredentialProvider

            creds = CredentialProvider.get_instance()
            token = creds.get_llm_token()

            llm = ChatOpenAI(
                base_url=AppConstants.OPENAI_BASE_URL,
                model=config["model"],
                api_key=token,  # pyright: ignore[reportArgumentType]
                extra_body={"reasoning_effort": config["reasoning"]},
                http_client=AppConstants.http_client_,
                http_async_client=AppConstants.http_async_client_,
            )

            self.logger.info(
                f"Initialized {model_type} LLM: {config['model']} "
                f"with reasoning_effort='{config['reasoning']}'"
            )
            return llm

        except Exception as e:
            self.logger.warning(f"Failed to initialize {model_type} LLM: {e}")
            # Fallback to main LLM if initialization fails
            return getattr(self, 'llm', None) or self._initialize_llm()

    def _invoke_llm_with_retry(self, llm: Any, messages: list, **invoke_kwargs) -> Any:
        """
        Dispatch an LLM invocation to the right retry path based on which
        of the agent's three LLMs (`self.llm` / `self.llm_nano` /
        `self.llm_mini`) was passed.

        - Main LLM → delegates to the base class `_invoke_with_token_retry`,
          which already wires `self.llm` + `self._initialize_llm` into the
          `ehap_retry.llm_invoke` helper.
        - Mini / retry LLMs → the base method can't be reused (it hardcodes
          `self.llm` and `self._initialize_llm`), so we call `llm_invoke`
          directly with the matching tier-specific reinitializer so a
          refresh rebuilds the SAME tier (nano stays nano, mini stays mini).

        The shared `cache_utils` token cache singleton means a refresh
        triggered by any tier benefits the other two.

        Falls back to plain `llm.invoke(...)` when EHAP is not configured
        (test mode / external LLM injection / agent constructed via
        `__new__`), preserving prior behavior.
        """
        # Extract schema parameter for logging (not passed to LLM)
        schema = invoke_kwargs.pop('schema', 'unknown')
        
        # Guard against attribute-less test instances (`__new__` bypass).
        ehap = getattr(self, "ehap", None)
        if ehap is None:
            result = llm.invoke(messages, **invoke_kwargs)
            return result

        # Main LLM — reuse the base class helper. It handles token refresh,
        # reinitializer wiring, and `self.llm` reassignment for us.
        if llm is self.llm:
            result = self._invoke_with_token_retry(messages, **invoke_kwargs)
            return result

        # Mini / retry — base helper is hardcoded to self.llm, so use
        # `ehap_retry.llm_invoke` directly with the matching tier factory.
        if llm is getattr(self, "llm_nano", None):
            def reinitializer():
                return self._init_llm("mini")
            llm_role = "mini"
        elif llm is getattr(self, "llm_mini", None):
            def reinitializer():
                return self._init_llm("base")
            llm_role = "retry"
        else:
            # Unknown LLM (custom inject, partially-built test instance).
            # Safest fallback: invoke without retry wiring rather than
            # silently rebuilding it as the main LLM.
            result = llm.invoke(messages, **invoke_kwargs)
            return result

        from deep_research_utils.ehap_retry import llm_invoke

        result, updated_llm = llm_invoke(
            llm=llm,
            ehap=ehap,
            messages=messages,
            llm_reinitializer=reinitializer,
            timeout=self.llm_timeout,
            **invoke_kwargs,
        )

        # Replace the stale agent-level reference when a token refresh
        # recreated the client. Parallel threads holding the old closure
        # ref will pick up the fresh client on their next call via the
        # cache_utils singleton check.
        if updated_llm is not llm:
            if llm_role == "mini":
                self.llm_nano = updated_llm
            else:  # "retry"
                self.llm_mini = updated_llm

        return result

    def _build_table_registry(self) -> Dict[str, str]:
        """Build table registry from agent config."""
        # All config items for reimbursement agent are tables
        return dict(self._agent_config)
    
    def _init_snowflake(
        self, 
        helper: Optional[Any], 
        builder: Optional[Callable[[], Any]]
    ) -> Any:
        """
        Initialize Snowflake connection using same pattern as LLM.
        
        Args:
            helper: Pre-configured SnowparkHelper instance
            builder: Callable that returns SnowparkHelper
            
        Returns:
            Configured SnowparkHelper instance
            
        Raises:
            AgentConfigurationError: If Snowflake cannot be initialized
        """
        if helper:
            return helper
        
        if builder:
            try:
                return builder()
            except Exception as e:
                self.logger.error(f"Snowflake builder failed: {e}")
                raise
        
        # Auto-build from credentials
        try:
            from deep_research_utils.snowflake_helper import SnowparkHelper
            
            creds = CredentialProvider.get_instance()
            snowflake_creds = creds.get_snowflake_credentials()
            
            return SnowparkHelper(
                batch_size=10000,
                max_workers=6,
                enable_metrics=True,
                connection_pool_size=4,
                **snowflake_creds
            )
        except Exception as e:
            self.logger.warning(
                f"Snowflake credentials not configured; provide a helper to execute the agent.",
                exc_info=e
            )
            return None
    
    def table(self, name: str) -> str:
        """
        Get fully qualified table name for the current environment.
        
        Args:
            name: Logical table name (e.g., 'policy_metadata')
            
        Returns:
            Fully qualified table name (e.g., 'D01_COC.COC_DTI.PLCY_MTDTA')
            
        Raises:
            KeyError: If table name not configured
            
        Example:
            >>> self.table('policy_metadata')
            'D01_COC.COC_DTI.PLCY_MTDTA'  # in dev
            'P01_COC.COC_DTI.PLCY_MTDTA'  # in prod
        """
        if name not in self._table_registry:
            available = ', '.join(sorted(self._table_registry.keys()))
            raise KeyError(
                f"Table '{name}' not configured for reimbursement agent in environment '{AppConstants.ENV}'. "
                f"Available tables: {available}"
            )
        return self._table_registry[name]

    # ========================================================================
    # Required Base Class Methods
    # ========================================================================

    @property
    def node_name(self) -> str:
        """Entry node name (not used since we override build_graph)."""
        return "build_topk"

    @override
    def node_function(self, state: ReimbursementState):
        """Node function (not used since we override build_graph)."""
        pass

    @override
    def prepare_state(
        self,
        conversation_id: Optional[str] = None,
        query: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        job_id: Optional[str] = None,
        yaml_path: Optional[str] = None,
        filters: Any = None,
        metric: Optional[str] = None,
        dimension: Optional[str] = None,
        top_k: int = 10,
        persist_queries: bool = True,
        output_root: Optional[str] = None,
        fetch_competitor_policies: bool = False,
        catalog: Optional[SemanticCatalog] = None,
        pattern: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Prepare initial state for a single top-K ranking run.

        The agent has ONE mode: rank a dimension (default the NUCC taxonomy code)
        by a declared metric (default total paid) over a semantic-view claims
        table, optionally narrowed by a nested AND/OR ``filters`` tree, keeping the
        top ``top_k`` rows and chaining the ranked dimension into the
        taxonomy->policy hydration + rule-extraction tail.

        The agent is decoupled from every other agent: it never parses business
        patterns or correlation cards for codes. Callers that start from a pattern
        convert its source cards into a ``filters`` tree themselves (see
        :func:`deep_research_utils.build_filter_tree_from_cards`) and pass that
        tree here; the states / LOBs / clinical codes used to narrow policy
        hydration are read back out of that same tree (:meth:`_extract_filter_codes`).

        Args:
            conversation_id: Conversation ID from the caller.
            query: User query (context/logging only).
            context: Optional overrides (``yaml_path`` / ``dimension`` / ``metric`` /
                ``top_k`` / ``filters`` / ``persist_queries`` / ``output_root`` /
                ``fetch_competitor_policies``) and a fallback ``pattern`` used only
                for narrative enrichment.
            job_id: Job ID for this execution (auto-generated if not provided).
            yaml_path: Semantic-view YAML declaring the dimension + metrics.
                REQUIRED (top-level or via ``context['yaml_path']``).
            filters: Optional nested AND/OR filter tree narrowing the ranking.
            metric / dimension / top_k: Ranking controls (see defaults above).
            pattern: Optional business-pattern dict used ONLY to enrich the
                extraction / judge / recommendation prompts (title, evidence
                summary, why-it-matters). It is NEVER parsed for codes; the ranking
                and all code/state/LOB signals come solely from ``filters``.
            **kwargs: Additional state values.

        Returns:
            Initial top-K state dictionary.

        Raises:
            AgentConfigurationError: If no ``yaml_path`` resolves, or the
                dimension / metric / top_k / filter tree is invalid for that YAML.
        """
        # Note: Snowflake validation happens in fetch_content_node (where it's
        # actually used), so the API can start without credentials.

        # Reset per-invocation token bookkeeping before any LLM call in the graph.
        self._token_breakdown = {}

        # Top-K is the ONLY mode. A semantic-view YAML is required (supplied
        # top-level or via context); without one there is nothing to rank.
        resolved_yaml_input = yaml_path or (context or {}).get("yaml_path")
        if not resolved_yaml_input:
            raise AgentConfigurationError(
                "yaml_path is required for the reimbursement top-K agent "
                "(pass it directly or via context['yaml_path'])."
            )

        # A supplied pattern is narrative enrichment ONLY. Prefer the explicit
        # `pattern` argument; fall back to context['pattern']. It flows verbatim
        # into state['pattern'] so the shared extraction / judge / recommendation
        # tail (which already reads pattern.get(...)) can enrich titles/summaries.
        # It is NEVER parsed for codes; those come solely from `filters`.
        narrative = pattern if isinstance(pattern, dict) else (context or {}).get("pattern")
        if not isinstance(narrative, dict):
            narrative = {}

        # Rank one dimension (default provider taxonomy CODE) by a declared metric
        # (default total_paid) over the semantic view's claims table, optionally
        # narrowed by a nested AND/OR filter tree, keeping the top `top_k` rows.
        # Rows are returned in-memory; only the query + summary persist.
        # Two-layer merge-loader (QueryBuilderAgent): resolves + validates the
        # path, then stitches an optional Layer-2 logic sibling onto the Layer-1
        # schema. Back-compatible -- a legacy single YAML loads unchanged, so the
        # current file keeps working byte-for-byte; splitting it is opt-in later.
        resolved_yaml, semantic_model, catalog = self._load_semantic_view(
            resolved_yaml_input,
            default_path=None,
            error_cls=AgentConfigurationError,
        )

        # Default to the NUCC taxonomy CODE dimension (not the generic
        # provider_taxonomy_type name) so the ranked rows key into
        # policy_taxonomy_mapping.json for the taxonomy->policy chain.
        resolved_dimension = (
            dimension or (context or {}).get("dimension") or TAXONOMY_CODE_DIMENSION
        )
        resolved_metric = (
            metric or (context or {}).get("metric") or DEFAULT_METRIC
        )
        resolved_top_k = int(top_k or (context or {}).get("top_k") or 10)
        resolved_filters = (
            filters if filters is not None else (context or {}).get("filters")
        )

        # Fail fast on an unknown dimension/metric, bad top_k, or unresolvable
        # filter field before the graph runs (raises AgentConfigurationError).
        self._validate_topk_params(
            semantic_model,
            catalog,
            dimension=resolved_dimension,
            metric=resolved_metric,
            top_k=resolved_top_k,
            filters=resolved_filters,
        )

        # Persistence (queries + summary only, NEVER rows). On by default;
        # callers/tests disable via persist_queries=False. A context override
        # is honored only when the kwarg is left at its True default.
        # output_root defaults to the "reimbursement_runs" sibling of
        # correlation's "correlation_runs".
        context_persist = (context or {}).get("persist_queries")
        resolved_persist = (
            bool(context_persist) if (persist_queries and context_persist is not None)
            else bool(persist_queries)
        )
        resolved_output_root = (
            output_root
            or (context or {}).get("output_root")
            or "reimbursement_runs"
        )

        # When set, the taxonomy->policy chain hydrates peer payors' policies
        # sharing the mapped policies' topics (via policy_metadata_topic_comparison)
        # instead of the specific policies themselves. Off by default.
        resolved_fetch_competitor = bool(
            fetch_competitor_policies
            or (context or {}).get("fetch_competitor_policies")
        )

        self.logger.info(
            "Reimbursement top-K mode: yaml=%s dimension=%s metric=%s top_k=%s "
            "has_filters=%s has_pattern=%s persist_queries=%s output_root=%s "
            "fetch_competitor_policies=%s",
            resolved_yaml, resolved_dimension, resolved_metric, resolved_top_k,
            resolved_filters is not None, bool(narrative), resolved_persist,
            resolved_output_root, resolved_fetch_competitor,
        )

        # Pull state / LOB / clinical codes out of the SAME filter tree the
        # ranking query uses. `states`/`lobs` narrow policy hydration
        # (find_taxonomy_policies_node -> _fetch_policy_details_from_db, which
        # already supports ST_CD/LOB_NM IN (...)); `filter_codes` steers the
        # relevance judge + rule extraction. Code types whose fields aren't
        # declared in the active YAML never appear in the tree and are ignored.
        filter_codes = self._extract_filter_codes(resolved_filters)
        resolved_states = filter_codes.get("state") or None
        # Collapse claims-side LOB variants (e.g. "Commercial Individual") to
        # the policy table's canonical LOB_NM ("Commercial") before hydration;
        # a verbatim value never matches LOB_NM. Shared with the API path.
        resolved_lobs = self._normalize_lob_to_policy(filter_codes.get("lob", [])) or None
        # Legacy pipeline keys read directly by extract_rules_node and the
        # judge summary. CPT + HCPCS historically share one comma-joined line.
        legacy_cpt_codes = ", ".join(
            filter_codes.get("cpt", []) + filter_codes.get("hcpcs", [])
        )
        legacy_drg_codes = filter_codes.get("drg", [])
        if filter_codes:
            self.logger.info(
                "Reimbursement top-K filter codes: states=%s lobs=%s clinical=%s",
                resolved_states, resolved_lobs,
                {k: v for k, v in filter_codes.items() if k not in ("state", "lob")},
            )

        return {
            "mode": "topk",
            "conversation_id": conversation_id,
            "query": query,
            "context": context,
            "job_id": job_id or uuid.uuid4().hex,
            "yaml_path": resolved_yaml,
            "semantic_model": semantic_model,
            "catalog": catalog,
            "dimension": resolved_dimension,
            "metric": resolved_metric,
            "top_k": resolved_top_k,
            "filters": resolved_filters,
            # Filter-derived narrowing/signals (all default to None/empty
            # when the tree carries no matching fields).
            "states": resolved_states,
            "lobs": resolved_lobs,
            "filter_codes": filter_codes,
            "persist_queries": bool(resolved_persist),
            "output_root": resolved_output_root,
            "fetch_competitor_policies": resolved_fetch_competitor,
            "snowflake_helper": self.snowflake_helper,
            # LLMs for the shared extraction pipeline the top-K chain continues
            # into (extract_rules / analyze_table_structure / format_output /
            # generate_recommendation / validate_recommendation).
            "llm": self.llm,
            "llm_nano": self.llm_nano,
            "llm_mini": self.llm_mini,
            # Optional narrative enrichment. An empty dict (not None) keeps the
            # tail's `pattern.get(...)` calls safe; when a pattern was supplied it
            # flows through here to enrich titles / summaries / recommendation
            # prose. Codes/states/LOBs still come only from `filters` above.
            "pattern": narrative,
            "pattern_rank": narrative.get("pattern_rank"),
            "cpt_codes": legacy_cpt_codes,
            "drg_codes": legacy_drg_codes,
            "start_time": datetime.now(timezone.utc).isoformat(),
            "input_tokens": 0,
            "output_tokens": 0,
            **kwargs,
        }

    @override
    def extract_result(self, graph_output: Dict[str, Any]) -> Dict[str, Any]:
        """Build the orchestrator-compliant output envelope for a top-K run.

        Top-K is the only mode: the ranked taxonomies -> mapped policies ->
        extraction -> recommendation chain produces the standard pipeline
        envelope with the ranking + taxonomy trail layered on. When a narrative
        ``pattern`` was supplied it enriches the envelope title/summary;
        :meth:`_extract_topk_result` wraps :meth:`_extract_pattern_result` so the
        envelope stays byte-compatible for the aggregator + UI.

        Args:
            graph_output: Final graph state.

        Returns:
            Orchestrator-compliant output with reimbursement data and recommendations.
        """
        return self._extract_topk_result(graph_output)

    # ========================================================================
    # Graph Construction (Override base class)
    # ========================================================================
    
    @override
    def build_graph(self) -> StateGraph:
        """
        Build multi-node graph for policy extraction pipeline with recommendation generation.
        
        Returns:
            Compiled StateGraph
        """
        graph = StateGraph(self.state_class)

        # Top-K entry: build the ranking SQL (build_topk), run it (run_topk),
        # then find policies using the new orchestrator node (find_policies)
        # which tries taxonomy-based search first and falls back to keyword search,
        # before merging into the shared extraction pipeline at fetch_content.
        graph.add_node("build_topk", self.build_topk_query_node)
        graph.add_node("run_topk", self.run_topk_query_node)
        graph.add_node("find_policies", self.find_policies_node)
        graph.add_node("fetch_content", self.fetch_content_node)
        graph.add_node("extract_rules", self.extract_rules_node)
        graph.add_node("validate_policies", self.validate_policies_node)
        graph.add_node("analyze_table_structure", self.analyze_table_structure_node)
        graph.add_node("format_output", self.format_output_node)
        graph.add_node("generate_recommendation", self.generate_recommendation_node)
        graph.add_node("validate_recommendation", self.validate_recommendation_node)

        # Single linear flow (top-K is the only mode): rank -> find policies
        # (taxonomy + keyword fallback) -> shared extraction/recommendation pipeline.
        # Notable tail nodes:
        #   - find_policies: orchestrates taxonomy-based search with keyword fallback
        #   - validate_policies: deterministic relevance gate that attaches a
        #     `contamination` block to each policy result so downstream nodes
        #     (table summarization, recommendation peer benchmarks) can skip
        #     cross-payer leaks, prompt-leak target_codes, and title/content
        #     topic mismatches.
        #   - validate_recommendation: LLM critique of the final recommendation
        #     items for scope drift / source-disclaim.
        graph.add_edge(START, "build_topk")
        graph.add_edge("build_topk", "run_topk")
        graph.add_edge("run_topk", "find_policies")
        graph.add_edge("find_policies", "fetch_content")
        graph.add_edge("fetch_content", "extract_rules")
        graph.add_edge("extract_rules", "validate_policies")
        graph.add_edge("validate_policies", "analyze_table_structure")
        graph.add_edge("analyze_table_structure", "format_output")
        graph.add_edge("format_output", "generate_recommendation")
        graph.add_edge("generate_recommendation", "validate_recommendation")
        graph.add_edge("validate_recommendation", END)

        return graph

    # ========================================================================
    # Graph Nodes
    # ========================================================================

    def build_topk_query_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """Top-K mode (build): compose the ranking SQL from the semantic model.

        Ranks ``dimension`` (default provider_taxonomy_type) by ``metric`` (a
        declared metric, default total_paid), optionally narrowed by the nested
        AND/OR ``filters`` tree, keeping the top ``top_k`` rows. No Snowflake
        call here — this node only builds + stores the SQL (and its resolved
        metadata) so ``run_topk_query_node`` can execute it.
        """
        semantic_model: Dict[str, Any] = state["semantic_model"]
        built = build_topk_query_sql(
            semantic_model,
            dimension=state.get("dimension") or TAXONOMY_CODE_DIMENSION,
            metric=state.get("metric") or DEFAULT_METRIC,
            top_k=int(state.get("top_k", 10) or 10),
            filters=state.get("filters"),
            catalog=state.get("catalog"),
        )

        self.logger.info(
            "build_topk_query: ranking %r by metric %r (top_k=%d, has_filters=%s)",
            built["dimension"], built["metric"], built["top_k"], built["has_filters"],
        )
        return {"topk_query": built["sql"], "topk_meta": built}

    def _persist_run(
        self,
        state: Dict[str, Any],
        *,
        sql: str,
        meta: Dict[str, Any],
        rows: List[Dict[str, Any]],
        row_count: int,
        truncated: bool,
    ) -> Optional[Tuple[str, Dict[str, str]]]:
        """Persist the ranking query + a small JSON summary (NEVER rows).

        Overrides the QueryBuilderAgent hook to keep reimbursement's exact
        ``reimbursement_runs/<run_id>/queries|summary|manifest`` layout. On by
        default; disabled when ``state['persist_queries']`` is falsy (returns
        ``None`` -> nothing persisted, and no ``run_dir``/``artifacts`` splice).
        """
        if not bool(state.get("persist_queries", True)):
            return None

        output_root = state.get("output_root") or "reimbursement_runs"
        created_at = datetime.now(timezone.utc).isoformat()
        run_id = _build_run_id(
            state.get("query") or f"topk_{meta.get('dimension', 'taxonomy')}"
        )
        run_dir = ensure_dir(Path(output_root) / run_id)
        queries_dir = ensure_dir(run_dir / "queries")
        summary_dir = ensure_dir(run_dir / "summary")
        top_k = int(meta.get("top_k") or state.get("top_k", 10) or 10)

        files: List[str] = []
        _write_text(queries_dir / "topk_query.sql", sql)
        files.append("queries/topk_query.sql")

        _write_json(
            summary_dir / "summary.json",
            {
                "dimension": meta.get("dimension"),
                "metric": meta.get("metric"),
                "top_k": top_k,
                "yaml_path": state.get("yaml_path"),
                "row_count": row_count,
                "truncated": truncated,
                "has_filters": meta.get("has_filters"),
                "created_at": created_at,
            },
        )
        files.append("summary/summary.json")

        _write_json(
            run_dir / "manifest.json",
            {
                "run_id": run_id,
                "created_at": created_at,
                "files": files,
                "queries_persisted": True,
                "rows_persisted": False,
            },
        )

        return str(run_dir), {
            "topk_query": "queries/topk_query.sql",
            "summary": "summary/summary.json",
            "manifest": "manifest.json",
        }

    def run_topk_query_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """Top-K mode (run): execute the built ranking SQL and return the top rows.

        Executes ``topk_query`` (which already carries its ORDER BY + LIMIT),
        optionally persists the query + a small JSON summary to a per-run
        artifact directory, then returns the ranked rows in-memory. Result
        **rows are never persisted** — only the query definition + summary are.
        """
        topk_query: str = state["topk_query"]
        meta: Dict[str, Any] = state.get("topk_meta", {}) or {}
        snowflake_helper = state.get("snowflake_helper")

        if snowflake_helper is None:
            raise RuntimeError("Snowflake helper is required to run the top-K query.")

        # Execute + JSON-safe serialize via the shared QueryBuilderAgent helper
        # (numpy scalars -> native, NaN -> null, datetimes -> ISO).
        rows, row_count = self._execute_to_rows(snowflake_helper, topk_query)
        top_k = int(meta.get("top_k") or state.get("top_k", 10) or 10)
        # The query is LIMIT top_k, so a full page means there may be more groups
        # ranked below the returned top-K.
        truncated = row_count >= top_k

        # Optional local persistence of the query + summary (NEVER rows),
        # delegated to the _persist_run hook overridden below.
        persisted = self._persist_run(
            state,
            sql=topk_query,
            meta=meta,
            rows=rows,
            row_count=row_count,
            truncated=truncated,
        )
        run_dir_str: Optional[str] = persisted[0] if persisted is not None else None
        artifacts: Optional[Dict[str, str]] = persisted[1] if persisted is not None else None

        self.logger.info(
            "run_topk_query: ran top-%d ranking of %r by %r (returned_rows=%d, "
            "truncated=%s) — rows returned in-memory, not persisted; queries+summary %s",
            top_k, meta.get("dimension"), meta.get("metric"), row_count, truncated,
            f"written to {run_dir_str}" if run_dir_str else "not persisted",
        )

        topk_result: Dict[str, Any] = {
            "dimension": meta.get("dimension"),
            "metric": meta.get("metric"),
            "metric_alias": meta.get("metric_alias"),
            "top_k": top_k,
            "topk_query": topk_query,
            "yaml_path": state.get("yaml_path"),
            "has_filters": meta.get("has_filters"),
            "rows": rows,
            "row_count": row_count,
            "truncated": truncated,
        }
        if run_dir_str is not None:
            topk_result["run_dir"] = run_dir_str
            topk_result["artifacts"] = artifacts

        return {"topk_result": topk_result}

    def find_policies_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """LangGraph node: orchestrate policy search with taxonomy-first, keyword-fallback strategy.
        
        This node provides a unified entry point for policy discovery that:
        1. First attempts taxonomy-based policy mapping (provider-centric approach)
        2. Falls back to keyword-based API search if taxonomy yields no results
        
        Args:
            state: Current graph state
            
        Returns:
            Dict with filtered_policies (and additional metadata from whichever method succeeded)
        """
        pattern_rank = state.get("pattern", {}).get("pattern_rank") if state.get("pattern") else None
        
        # Try taxonomy-based search first
        self.logger.info(f"Pattern {pattern_rank}: Attempting taxonomy-based policy search")
        taxonomy_result = self._find_taxonomy_policies(state)
        
        filtered_policies = taxonomy_result.get("filtered_policies") or []
        
        # Check if we got results
        if filtered_policies:
            self.logger.info(
                f"Pattern {pattern_rank}: Taxonomy search succeeded with {len(filtered_policies)} policies"
            )
            return taxonomy_result
        
        # Fallback to keyword-based search
        self.logger.info(
            f"Pattern {pattern_rank}: Taxonomy search yielded no policies, falling back to keyword search"
        )
        keyword_result = self.search_policies_using_search_keywords(state)
        
        filtered_policies = keyword_result.get("filtered_policies") or []
        self.logger.info(
            f"Pattern {pattern_rank}: Keyword search returned {len(filtered_policies)} policies"
        )
        
        return keyword_result

    def fetch_content_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """
        Node 2: Fetch full policy content from Snowflake.

        Args:
            state: Current graph state

        Returns:
            Updated state with policy_content
        """
        if not state.get("filtered_policies"):
            self.logger.info("fetch_content: no filtered policies, skipping Snowflake query")
            return {"policy_content": []}

        # Validate Snowflake connection (following correlation agent pattern)
        snowflake_helper = state.get("snowflake_helper")
        if snowflake_helper is None:
            from deep_research_core.base_agent import AgentExecutionError
            raise AgentExecutionError(
                "Snowflake connection is required but not configured. "
                "Please provide Snowflake credentials via environment variables:\n"
                "  - SNOWFLAKE_ACCOUNT\n"
                "  - SNOWFLAKE_USER\n"
                "  - SNOWFLAKE_SECRET\n"
                "  - SNOWFLAKE_WAREHOUSE\n"
                "  - SNOWFLAKE_DATABASE\n"
                "  - SNOWFLAKE_SCHEMA\n"
                "Or pass a snowflake_helper instance when creating the agent."
            )
        
        policies = state["filtered_policies"]
        policy_ids = [p['policy_id'] for p in policies]
        
        self.logger.info(f"Fetching content for {len(policy_ids)} policies")
        
        # SQL query to get full policy text
        # Uses environment-aware table from registry.
        # ORDER BY PLCY_ID makes the row order deterministic across runs
        # (Snowflake GROUP BY otherwise returns an arbitrary order, which
        # used to misalign format_output_node's positional metadata
        # lookup — the bug is now fixed via dict lookup, but determinism
        # still helps log readability and any future positional consumer).
        sql = f"""
        SELECT PLCY_ID,
               LISTAGG(PAGE_DATA_TXT, '\n') WITHIN GROUP (ORDER BY PAGE_NBR) AS POLICY_TEXT
        FROM {self.table('policy_search_detail')}
        WHERE PLCY_ID IN ({{policy_ids}})
        GROUP BY PLCY_ID
        ORDER BY PLCY_ID
        """
        
        policy_ids_str = ", ".join([f"'{pid}'" for pid in policy_ids])
        df_content = snowflake_helper.execute_query_and_return_pandas_df(
            sql.format(policy_ids=policy_ids_str)
        )
        
        self.logger.info(f"Retrieved content for {len(df_content)} policies")
        
        return {
            "policy_content": df_content.to_dict('records')
        }
    
    def extract_rules_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """
        Node 3: Extract structured rules from each policy using LLM.
        
        Uses GPT-5.4-nano for policy processing to improve performance with large policy sets.
        
        Args:
            state: Current graph state
            
        Returns:
            Updated state with result
        """
        policy_content = state.get("policy_content") or []
        filtered_policies = state.get("filtered_policies") or []
        if not filtered_policies or not policy_content:
            self.logger.info("extract_rules: no policies to extract, returning empty result")
            return {"result": []}

        cpt_codes = state["cpt_codes"]
        drg_codes = state.get("drg_codes", [])
        filter_codes = state.get("filter_codes") or {}
        pattern = state.get("pattern")
        llm_nano = state["llm_nano"]  # GPT-5.4-nano — first attempt
        # GPT-5.4-mini escalated for the retry path; falls back to nano if
        # the retry LLM wasn't initialized (offline / stub-agent contexts).
        llm_mini = state.get("llm_mini") or llm_nano

        # Build pattern_details string for LLM prompt (from notebook)
        # This works even when pattern is None by focusing on codes
        pattern_details_parts = []

        # Add DRG codes if available
        if drg_codes:
            pattern_details_parts.append(f"DRG Codes: {', '.join(drg_codes)}")

        # Add CPT codes if available (fallback)
        if cpt_codes:
            pattern_details_parts.append(f"CPT/HCPCS Codes: {cpt_codes}")

        # Add the remaining clinical codes carried from the filter tree so the
        # LLM extracts rules specific to them. DRG and CPT/HCPCS are already
        # represented above via drg_codes/cpt_codes; these are the extra types.
        for label, key in (
            ("Procedure Codes", "procedure"),
            ("Diagnosis Codes", "diagnosis"),
            ("Revenue Codes", "revenue"),
        ):
            values = filter_codes.get(key) or []
            if values:
                pattern_details_parts.append(f"{label}: {', '.join(values)}")

        # Add pattern title if available (optional - works without it)
        if pattern:
            pattern_title = pattern.get("pattern_title") or pattern.get("top_pattern")
            if pattern_title:
                pattern_details_parts.append(f"Pattern: {pattern_title}")

        # Fallback to cpt_codes if no pattern_details_parts were built
        # This ensures we always have some context for the LLM
        pattern_details = "\n".join(pattern_details_parts) if pattern_details_parts else cpt_codes

        # Index filtered_policies by policy_id so we can resolve a stable
        # human-readable title at log time. The API exposes the title via
        # `policy_title` (the doc-name field on the search hit); fall back
        # to `external_link` / `policy_link` filename if no title field.
        title_by_id: Dict[str, str] = {}
        for fp in filtered_policies:
            pid = fp.get("policy_id")
            if not pid:
                continue
            title = (
                fp.get("policy_title")
                or fp.get("document_name")
                or fp.get("external_link")
                or fp.get("policy_link")
                or ""
            )
            title_by_id[pid] = title

        total = len(policy_content)
        concurrency = self._resolve_extract_concurrency()

        self.logger.info(
            f"Extracting rules from {total} policies "
            f"(env={AppConstants.ENV!r}, concurrency={concurrency})"
        )
        self.logger.info(f"Pattern details: {pattern_details}")

        def _process_one(idx: int, policy: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            """Run extract → sanitize for a single policy. Returns the
            sanitized response dict (with PLCY_ID stamped) on success, or
            None on terminal failure. Per-policy retry uses llm_mini."""
            policy_id = policy['PLCY_ID']
            policy_title = title_by_id.get(policy_id, "")
            self.logger.info(
                f"Processing policy {idx+1}/{total}: policy_id={policy_id} title={policy_title!r}"
            )

            total_attempts = 1 + max(0, self.max_retries)
            
            for attempt in range(1, total_attempts + 1):
                try:
                    # Dynamically switch to retry LLM after the first failure
                    current_llm = llm_nano if attempt == 1 else llm_mini
                    
                    response = self._extract_policy_rules(
                        policy['POLICY_TEXT'],
                        pattern_details,
                        current_llm
                    )
                    response = self._sanitize_extracted_facts(policy_id, policy_title, response)
                    response["PLCY_ID"] = policy_id
                    
                    if attempt > 1:
                        self.logger.info(
                            f"Extract retry succeeded on gpt-5.4-mini for "
                            f"policy_id={policy_id} title={policy_title!r}"
                        )
                    return response

                except Exception as e:
                    # Handle final failure case
                    if attempt == total_attempts:
                        self.logger.error(
                            f"Extract failed after final attempt ({attempt}/{total_attempts}) "
                            f"for policy_id={policy_id} title={policy_title!r}: {e}; dropping policy"
                        )
                        return None
                    
                    # Handle intermediate failure / retry logging
                    self.logger.warning(
                        f"Extract attempt {attempt} failed for policy_id={policy_id} "
                        f"title={policy_title!r}: {e}; retrying after {self.retry_delay}s"
                    )
                    time.sleep(self.retry_delay)

            return None

        # Fan out one task per policy, then reassemble in the original
        # policy_content order so results[i] still corresponds to
        # policy_content[i]. Downstream format_output_node no longer
        # relies on this index, but preserving it keeps logs readable
        # and any future positional consumers correct.
        by_index: Dict[int, Optional[Dict[str, Any]]] = {}
        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            futures = {
                pool.submit(_process_one, i, policy): i
                for i, policy in enumerate(policy_content)
            }
            for fut in as_completed(futures):
                i = futures[fut]
                by_index[i] = fut.result()

        results: List[Optional[Dict[str, Any]]] = [by_index.get(i) for i in range(total)]
        successful = sum(1 for r in results if r is not None)
        self.logger.info(f"Successfully processed {successful}/{total} policies")

        return {"result": results}

    def validate_policies_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """
        Node 4: Relevance gate — deterministic checks + LLM relevance judge.

        Sits between extract_rules and analyze_table_structure. For each
        extracted policy, runs:
          - Deterministic identity / cross-payer-leak / prompt-leak /
            mention_status checks (`check_policy_contamination`). These
            are domain-agnostic — they catch real failures regardless of
            whether the pattern is OB, oncology, cardiology, etc.
          - An LLM relevance judge (`_judge_policy_relevance`) that asks
            "does this policy actually adjudicate the requested codes/clinical area?"
            The judge replaces the previous hardcoded OB topic-keyword heuristic —
            its medical knowledge generalizes to any specialty.

        Supports both pattern-based and pattern-less modes.

        Judges run in parallel via `_resolve_extract_concurrency()`.
        Each policy gets a `contamination` block attached in place;
        quarantine-severity policies are excluded by downstream nodes.
        Logs every flag with policy_id + payer + title + severity + flags
        + reasons so the operator can trace every drop.
        """
        results = state.get("result") or []
        filtered_policies = state.get("filtered_policies") or []
        if not results:
            self.logger.info("validate_policies: no results to validate, passthrough")
            return {
                "result": [],
                "policy_contamination_summary": {
                    "total_extracted": 0,
                    "quarantined": [],
                    "warned": [],
                },
            }

        pattern = state.get("pattern")  # Can be None in top-K mode
        cpt_codes = (state.get("cpt_codes") or "").strip()
        drg_codes = state.get("drg_codes") or []
        # `llm_nano` powers the judge; tests that build the agent via
        # __new__ may not provide it — in that case the judge is skipped
        # and the remaining deterministic checks (identity, prompt-leak,
        # cross-payer-name-leak) still run.
        llm_nano = state.get("llm_nano")

        meta_by_id: Dict[str, Dict[str, Any]] = {}
        for fp in filtered_policies:
            pid = fp.get("policy_id")
            if pid:
                meta_by_id[pid] = fp

        # Stage 1: build per-policy contexts (no LLM yet). Skipping
        # non-dict results so the rest of the pipeline doesn't get
        # surprises from extract_rules failures.
        policy_contexts: List[Dict[str, Any]] = []
        for policy_result in results:
            if not isinstance(policy_result, dict):
                continue

            policy_id = policy_result.get("PLCY_ID")
            meta = meta_by_id.get(policy_id, {}) if policy_id else {}
            llm_meta = policy_result.get("policy_metadata") or {}

            payer = meta.get("payor") or "Unknown Payer"
            # Prefer the API-supplied title over the LLM-extracted scope
            # for topic inference and the judge prompt — `policy_scope`
            # is often a coverage sentence ("All members in California"),
            # not a document title.
            title = (
                meta.get("policy_title")
                or meta.get("document_name")
                or llm_meta.get("policy_scope")
                or ""
            )
            policy_url = meta.get("external_link") or meta.get("policy_link") or ""

            evidence_chunks: List[str] = []
            for rule in policy_result.get("results") or []:
                if not isinstance(rule, dict):
                    continue
                for key in ("payor_level_summary", "specific_rule_text"):
                    val = rule.get(key)
                    if isinstance(val, str) and val.strip():
                        evidence_chunks.append(val.strip())
            evidence = " ".join(evidence_chunks)

            edit_rule_facts = self._aggregate_edit_rule_facts(
                policy_result.get("results") or []
            )

            policy_contexts.append({
                "policy_result": policy_result,
                "policy_id": policy_id,
                "payer": payer,
                "title": title,
                "evidence": evidence,
                "edit_rule_facts": edit_rule_facts,
                "policy_url": policy_url,
            })

        # Stage 2: fan out LLM relevance judge calls. Judge runs only
        # when an llm_nano is provided AND we have non-empty evidence
        # to score against (empty evidence → mention_status path is the
        # right signal, no need to spend tokens). Verdict default-keeps
        # on any error so judge hiccups never silently quarantine.
        judge_by_id: Dict[Optional[str], Optional[Dict[str, Any]]] = {}
        if llm_nano is not None and policy_contexts:
            pattern_summary = self._build_judge_pattern_summary(
                pattern, drg_codes, cpt_codes, state.get("filter_codes")
            )
            concurrency = self._resolve_extract_concurrency()
            self.logger.info(
                f"Running relevance judge on {len(policy_contexts)} policies "
                f"(concurrency={concurrency})"
            )

            def _judge_one(ctx: Dict[str, Any]) -> tuple:
                # Skip the LLM call when evidence is empty — judge
                # would have nothing to score and defaults to relevant.
                if not (ctx["evidence"] or "").strip():
                    return ctx["policy_id"], None
                try:
                    verdict = self._judge_policy_relevance(
                        pattern_summary=pattern_summary,
                        policy_title=ctx["title"],
                        evidence=ctx["evidence"],
                        llm=llm_nano,
                    )
                    return ctx["policy_id"], verdict
                except Exception as exc:
                    self.logger.warning(
                        f"Relevance judge failed for "
                        f"policy_id={ctx['policy_id']!r}: {exc}; "
                        f"defaulting to relevant=true"
                    )
                    return ctx["policy_id"], None

            with ThreadPoolExecutor(max_workers=concurrency) as pool:
                for pid, verdict in pool.map(_judge_one, policy_contexts):
                    judge_by_id[pid] = verdict

        # Stage 3: deterministic checks + apply judge verdict.
        quarantined: List[Dict[str, Any]] = []
        warned: List[Dict[str, Any]] = []

        for ctx in policy_contexts:
            policy_result = ctx["policy_result"]
            contamination = PolicyContaminationChecker.check_policy_contamination(
                policy_id=ctx["policy_id"],
                payer=ctx["payer"],
                title=ctx["title"],
                evidence=ctx["evidence"],
                edit_rule_facts=ctx["edit_rule_facts"],
                policy_url=ctx["policy_url"],
                judge_verdict=judge_by_id.get(ctx["policy_id"]),
            )

            if contamination:
                policy_result["contamination"] = contamination
                self.logger.info(
                    f"validate_policies: policy_id={ctx['policy_id']!r} "
                    f"payer={ctx['payer']!r} title={ctx['title']!r} "
                    f"severity={contamination['severity']} "
                    f"flags={contamination['flags']} "
                    f"reasons={contamination['reasons']}"
                )
                summary_entry = {
                    "policy_id": ctx["policy_id"],
                    "payer": ctx["payer"],
                    "title": ctx["title"],
                    "flags": contamination["flags"],
                    "reasons": contamination["reasons"],
                }
                if contamination["severity"] == "quarantine":
                    quarantined.append(summary_entry)
                else:
                    warned.append(summary_entry)

        total_extracted = sum(1 for r in results if isinstance(r, dict))
        self.logger.info(
            f"validate_policies summary: {len(quarantined)} quarantined, "
            f"{len(warned)} warned out of {total_extracted} extracted policies"
        )

        return {
            "result": results,
            "policy_contamination_summary": {
                "total_extracted": total_extracted,
                "quarantined": quarantined,
                "warned": warned,
            },
        }

    def analyze_table_structure_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """
        Node 4: Analyze pattern context and generate dynamic table structure (from notebook).

        Uses pattern-aware LLM column generation to select the most relevant columns
        for comparing payer behavior on this specific pattern.

        Args:
            state: Current graph state

        Returns:
            Updated state with table_structure (TableSchemaResponse) and column_metadata
        """
        results = state.get("result") or []
        pattern = state.get("pattern", {})
        drg_codes = state.get("drg_codes", [])
        search_keywords = state.get("search_keywords", [])
        llm = state["llm"]

        if not results:
            self.logger.info("analyze_table_structure: no results, returning empty schema")
            return {
                "table_structure": TableSchemaResponse(columns=[], selected_categories=[]),
                "column_metadata": []
            }

        self.logger.info("Generating dynamic table structure using pattern context")

        # Collect category samples from all policies
        category_samples = self._collect_category_samples(results)

        if not category_samples:
            self.logger.warning("No rule categories found in policies")
            return {
                "table_structure": TableSchemaResponse(columns=[], selected_categories=[]),
                "column_metadata": []
            }

        # Build pattern context for LLM
        pattern_context = self._build_pattern_context(pattern, drg_codes, search_keywords)

        # Generate dynamic columns using LLM (pattern-aware + user-query-aware)
        user_query = state.get("query")
        schema = self._generate_dynamic_columns(pattern_context, category_samples, llm, user_query=user_query)

        # Convert to column_metadata format for backward compatibility
        column_metadata = [col.model_dump() for col in schema.columns]

        self.logger.info(
            f"Generated {len(schema.columns)} dynamic columns: "
            f"{[c.id for c in schema.columns]}"
        )

        return {
            "table_structure": schema,
            "column_metadata": column_metadata
        }

    def format_output_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """
        Node 5: Format extracted rules using comprehensive notebook logic.

        Uses pattern-aware dynamic columns and per-cell LLM summarization
        to create high-quality payer comparison tables.

        Args:
            state: Current graph state

        Returns:
            Updated state with formatted_output
        """
        from collections import defaultdict

        results = state.get("result") or []
        filtered_policies = state.get("filtered_policies") or []
        table_structure = state.get("table_structure")  # TableSchemaResponse
        # `or {}` (not `.get("pattern", {})`) so a present-but-None seed (top-K
        # mode) still yields a dict — the tail calls pattern.get(...) directly.
        pattern = state.get("pattern") or {}
        llm = state["llm"]

        if not results or not filtered_policies:
            self.logger.info(
                "format_output: no results/policies, emitting empty formatted output"
            )
            empty_summary = {
                "title": "Payer Policy Summary",
                "subtitle": self._resolve_pattern_title(pattern),
                "columns": [],
                "rows": [],
            }
            formatted_output: Dict[str, Any] = {
                "summary_table": empty_summary,
                "individual_policies": [],
            }
            pattern_rank = state.get("pattern_rank")
            if pattern_rank is not None:
                formatted_output["pattern_rank"] = pattern_rank
            return {"formatted_output": formatted_output}

        self.logger.info("Formatting output with comprehensive payer policy summary logic")

        # Index API metadata by policy_id rather than positional index.
        # `results[i]` corresponds to `policy_content[i]` (Snowflake
        # GROUP BY order), NOT to `filtered_policies[i]` — so the old
        # `filtered_policies[i]` lookup attached the wrong payer / title /
        # URL to every surviving policy. Dict lookup by PLCY_ID matches
        # the pattern already used in `validate_policies_node`.
        meta_by_id: Dict[str, Dict[str, Any]] = {}
        for fp in filtered_policies:
            pid = fp.get("policy_id")
            if pid:
                meta_by_id[pid] = fp

        # Build individual policies list and group by payer
        individual_policies = []
        policies_by_payer = defaultdict(list)

        for policy_result in results:
            if policy_result is None:
                continue

            plcy_id = policy_result.get("PLCY_ID")
            policy_metadata = meta_by_id.get(str(plcy_id), {}) if plcy_id else {}

            # Extract metadata from LLM response
            llm_metadata = policy_result.get("policy_metadata", {})
            policy_results = policy_result.get("results", [])

            # Determine payer name
            payer_name = policy_metadata.get("payor", "Unknown Payer")

            # Determine policy title
            policy_title = llm_metadata.get("policy_scope") or policy_metadata.get("policy_title", "Policy Document")

            # Determine tags from payer category
            specialty = llm_metadata.get("specialty_specific")
            diagnosis = llm_metadata.get("diagnosis_specific")
            tags = []
            if specialty:
                tags.append("Specialty-Specific")
            if diagnosis:
                tags.append("Diagnosis-Specific")

            # Get effective date
            effective_date = llm_metadata.get("effective_date", "N/A")

            # Extract evidence from first result
            evidence = "No specific policy rules documented"
            if policy_results:
                first_result = policy_results[0]
                evidence = (first_result.get("payor_level_summary") or
                           first_result.get("specific_rule_text") or
                           first_result.get("authorization_requirements", evidence))

            # Get policy URL
            policy_url = policy_metadata.get("external_link") or policy_metadata.get("policy_link", "")

            # Aggregate structured edit-rule facts across this policy's rules.
            # Surfaces verbatim codes/modifiers/limits in the API output so the
            # UI can render chips alongside the human-readable evidence string.
            edit_rule_facts = self._aggregate_edit_rule_facts(policy_results)

            # Contamination block attached by validate_policies_node
            # (severity = "quarantine" | "warn" | None). Riding it through
            # individual_policies means downstream nodes and the API
            # response see the same quarantine decision.
            contamination = policy_result.get("contamination")

            # Build individual policy entry
            policy_entry = {
                "policy_id": policy_result.get("PLCY_ID"),
                "payer_name": payer_name,
                "policy_title": policy_title,
                "tags": tags,
                "effective_date": effective_date,
                "evidence": evidence,
                "policy_url": policy_url,
                "edit_rule_facts": edit_rule_facts,
                "contamination": contamination,
                "results": policy_results,  # Keep for aggregation
                "metadata": llm_metadata
            }

            # Quarantined policies are removed from the API output
            # entirely — they don't appear in individual_policies, the
            # summary table, or the recommendation. The aggregate counts
            # and policy_id:title pairs survive in
            # `policy_contamination_summary` (graph state) and surface in
            # validation.warnings so reviewers can still see what was
            # caught and why, without polluting the UI.
            if contamination and contamination.get("severity") == "quarantine":
                self.logger.info(
                    f"Output: dropping quarantined "
                    f"policy_id={policy_result.get('PLCY_ID')!r} "
                    f"title={policy_title!r} payer={payer_name!r} "
                    f"flags={contamination.get('flags')} "
                    f"reasons={contamination.get('reasons')}"
                )
                continue

            individual_policies.append(policy_entry)
            policies_by_payer[payer_name].append(policy_entry)

        # Build dynamic summary table using comprehensive notebook logic
        if table_structure is None or not table_structure.columns:
            # Fallback if no dynamic columns generated
            self.logger.warning("No dynamic columns generated, using simple table")
            summary_table = {
                "title": "Payer Policy Summary",
                "subtitle": pattern.get("top_pattern") or pattern.get("pattern_title", "Pattern Analysis"),
                "columns": [
                    {"id": "payer_org", "label": "Payer Organization", "type": "text"},
                    {"id": "policy_effective_date", "label": "Policy Effective Date", "type": "date"}
                ],
                "rows": []
            }
        else:
            # Build columns: payer_org + dynamic + appeals + effective_date (notebook order)
            dynamic_columns = [col.model_dump() for col in table_structure.columns]
            BASE_COLUMNS = [
                {"id": "payer_org", "label": "Payer Organization", "type": "text"},
                {"id": "appeals_process", "label": "Appeals Process\n(Documented)", "type": "badge"},
                {"id": "policy_effective_date", "label": "Policy Effective Date\n(Last Updated)", "type": "date"},
            ]
            columns = [BASE_COLUMNS[0]] + dynamic_columns + [BASE_COLUMNS[1], BASE_COLUMNS[2]]

            # Build rows with per-cell LLM summarization (notebook logic)
            summary_rows = []
            for payer_name in sorted(policies_by_payer.keys()):
                payer_policies = policies_by_payer[payer_name]
                row = {"payer_org": payer_name}

                # Fixed badges/dates (notebook helpers)
                row["appeals_process"] = self._appeals_badge(payer_policies)
                row["policy_effective_date"] = self._latest_effective_date(payer_policies)

                # Dynamic columns with per-cell LLM summarization
                for col_mapping in table_structure.selected_categories:
                    col_def = next((c for c in dynamic_columns if c["id"] == col_mapping.id), None)
                    if not col_def:
                        continue

                    # Aggregate rule texts for these categories
                    rule_texts = self._aggregate_rule_texts(payer_policies, col_mapping.categories)

                    # LLM summarization per cell (notebook logic)
                    row[col_mapping.id] = self._summarize_column_value(
                        payer_name,
                        col_def["label"],
                        rule_texts,
                        col_def.get("type", "text"),
                        llm
                    )

                summary_rows.append(row)

            # Build summary table structure
            summary_table = {
                "title": "Payer Policy Summary",
                "subtitle": pattern.get("top_pattern") or pattern.get("pattern_title", "Pattern Analysis"),
                "columns": columns,
                "rows": summary_rows
            }

        # Clean up individual policies (remove temporary fields)
        for policy in individual_policies:
            policy.pop("results", None)
            policy.pop("metadata", None)

        # Build final formatted output
        formatted_output = {
            "summary_table": summary_table,
            "individual_policies": individual_policies
        }

        # Add pattern_rank if in single-pattern mode
        pattern_rank = state.get("pattern_rank")
        if pattern_rank is not None:
            formatted_output["pattern_rank"] = pattern_rank

        self.logger.info(
            f"Formatted {len(individual_policies)} policies into {len(summary_table.get('rows', []))} payer rows "
            f"with {len(summary_table.get('columns', []))} columns (using comprehensive notebook logic)"
        )

        return {"formatted_output": formatted_output}

    def generate_recommendation_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """
        Node 6: Generate pattern-specific policy recommendations (structured list).

        Uses pattern context + Elevance summary + policy summary table to generate
        executive-facing recommendations via LLM with structured output.
        Uses notebook's logic with rank 1, other fields empty for now.

        Supports both pattern-based and pattern-less (top-K) modes.

        Args:
            state: Current graph state

        Returns:
            Updated state with recommended_action as List[Dict]
        """
        pattern = state.get("pattern")
        pattern_rank = state.get("pattern_rank")
        formatted_output = state.get("formatted_output") or {}
        llm = state["llm"]

        # Skip recommendations only if there are no policies to work with
        if not formatted_output.get("individual_policies"):
            self.logger.info(
                "Skipping recommendation generation (no individual policies to summarize)"
            )
            return {"recommended_action": [], "elevance_executive_summary": None}

        # Generate Elevance executive summary first (needed for recommendations).
        # Source from formatted_output.individual_policies, not raw state["result"]:
        # the extractor LLM doesn't return a payer name on its response, so the
        # raw result has no `payer_name`/`payor`/`PAYOR_NM` field for the
        # Elevance filter to match against. Payer attribution is attached during
        # format_output_node via a PLCY_ID join with filtered_policies — so the
        # formatted entries are the first place where `payer_name` is reliably
        # populated. Quarantined policies are already excluded from
        # individual_policies, so no extra filter is needed here.
        drg_codes = state.get("drg_codes", [])
        search_keywords = state.get("search_keywords", [])
        elevance_lookup_policies = formatted_output.get("individual_policies", []) or []
        user_query = state.get("query")

        elevance_summary = self._generate_elevance_executive_summary(
            pattern=pattern,
            pattern_rank=pattern_rank,
            drg_codes=drg_codes,
            keyword=search_keywords,
            pattern_policies=elevance_lookup_policies,
            llm=llm,
            user_query=user_query,
        )

        # Pivot the formatted individual_policies (each already carrying
        # `edit_rule_facts`) by payer, then derive per-payer aggregates and
        # cross-payer benchmarks to feed the recommendation prompt.
        # Only QUARANTINE-severity policies are excluded — those are the
        # ones where the relevance judge said the policy is topically
        # irrelevant or the identity/leak checks tripped at quarantine
        # severity. Warn-severity policies (e.g. cross-payer leak where
        # own payer is also mentioned) still inform peer benchmarks; the
        # warn flag stays attached for reviewer visibility in the API
        # response.
        from collections import defaultdict
        policies_by_payer: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        excluded = 0
        for policy in formatted_output.get("individual_policies", []) or []:
            contamination = policy.get("contamination") or {}
            severity = contamination.get("severity")
            if severity == "quarantine":
                excluded += 1
                self.logger.info(
                    f"Recommendation: excluding {severity}-severity "
                    f"policy_id={policy.get('policy_id')!r} "
                    f"title={policy.get('policy_title')!r} "
                    f"payer={policy.get('payer_name')!r} "
                    f"flags={contamination.get('flags')}"
                )
                continue
            payer_name = policy.get("payer_name") or "Unknown Payer"
            policies_by_payer[payer_name].append(policy)
        if excluded:
            self.logger.info(
                f"Recommendation: excluded {excluded} quarantined policy/ies "
                f"from peer benchmarks"
            )
        specific_facts = self._collect_payer_edit_rule_facts(policies_by_payer)

        recommendations = self._generate_policy_recommendations(
            pattern_context=pattern,
            pattern_rank=pattern_rank,
            summary_table=formatted_output.get("summary_table", {}),
            elevance_summary=elevance_summary,
            llm=llm,
            user_query=user_query,
            specific_facts=specific_facts,
        )

        # Attach transient validator inputs to each rec so
        # `validate_recommendation_node` can re-resolve citations and re-render
        # description/evidence/citation after filtering. Popped before
        # `extract_result` builds the API response.
        citation_index = {
            c["id"]: c
            for c in (specific_facts.get("citations") or [])
            if isinstance(c, dict) and isinstance(c.get("id"), str)
        }
        for rec in recommendations:
            rec["_citation_index"] = citation_index
            rec["_specific_facts"] = specific_facts

        if pattern_rank is not None:
            self.logger.info(f"Generated {len(recommendations)} recommendations for pattern {pattern_rank}")
        else:
            self.logger.info(f"Generated {len(recommendations)} recommendations without a pattern")

        # Return both recommendations and elevance summary for extract_result
        return {
            "recommended_action": recommendations,
            "elevance_executive_summary": elevance_summary
        }

    def validate_recommendation_node(self, state: ReimbursementState) -> Dict[str, Any]:
        """
        Node 7: Critique the generated recommendation against the pattern and
        the cited sources, and strip items that fail the balanced
        drop-threshold (scope drift OR source-disclaims-target).

        Always emits `recommendation_validation` so `extract_result` can
        surface a status in the validation block. The recommendation itself
        is either left alone (all items aligned), pruned in place (some
        items dropped — description / evidence / citation re-rendered over
        survivors), or fully suppressed (all items dropped → empty list).
        """
        recommendations = state.get("recommended_action") or []
        if not recommendations:
            self.logger.info("Validator skipped — no recommendation to validate")
            return {
                "recommended_action": [],
                "recommendation_validation": {
                    "decision": "skipped",
                    "summary": "no recommendation to validate",
                    "dropped_count": 0,
                    "kept_count": 0,
                    "verdicts": [],
                }
            }

        llm = state["llm"]
        pattern = state.get("pattern") or {}
        user_query = state.get("query")
        formatted_output = state.get("formatted_output") or {}
        individual_policies = formatted_output.get("individual_policies") or []
        subtitle = (formatted_output.get("summary_table") or {}).get("subtitle", "")

        new_recs: List[Dict[str, Any]] = []
        # Aggregate verdicts across all recs (today there's at most one rec
        # per pattern, but keep the loop honest for future shape changes).
        all_verdicts: List[Dict[str, Any]] = []
        total_dropped = 0
        total_kept = 0
        summary_lines: List[str] = []
        any_items_dropped = False

        for rec_idx, rec in enumerate(recommendations):
            items = rec.pop("_items", None)
            citation_index = rec.pop("_citation_index", None) or {}
            specific_facts = rec.pop("_specific_facts", None)

            if not items:
                # Nothing to validate — keep the rec as-is.
                new_recs.append(rec)
                continue

            verdict_data = self._run_recommendation_validator(
                items=items,
                citation_index=citation_index,
                individual_policies=individual_policies,
                pattern=pattern,
                user_query=user_query,
                summary_table_subtitle=subtitle,
                llm=llm,
            )
            verdicts = verdict_data.get("verdicts") or []
            summary = verdict_data.get("summary") or ""

            # Default-keep when the validator returns no usable verdicts —
            # never silently drop a recommendation on a parser hiccup.
            drop_indices = {
                v["item_index"] for v in verdicts if v["decision"] == "drop"
            }
            kept_items: List[Dict[str, Any]] = []
            for idx, item in enumerate(items):
                if idx in drop_indices:
                    continue
                kept_items.append(item)

            dropped = len(items) - len(kept_items)
            total_dropped += dropped
            total_kept += len(kept_items)
            # Tag verdicts with rec_idx for downstream inspection.
            for v in verdicts:
                v_tagged = dict(v)
                v_tagged["rec_index"] = rec_idx
                all_verdicts.append(v_tagged)
            if summary:
                summary_lines.append(summary)

            if dropped > 0:
                any_items_dropped = True
                self.logger.info(
                    f"Validator dropped {dropped} item(s) from recommendation "
                    f"{rec_idx}: {summary or '(no summary)'}"
                )

            if not kept_items:
                # Full drop — suppress this rec entirely.
                continue

            # Re-render description and rebuild evidence/citation/peer over
            # the survivors so chips don't reference dropped items' sources.
            filtered_rec = {
                "headline": rec.get("headline"),
                "items": kept_items,
            }
            rec["description"] = self._render_recommendation_description(filtered_rec)
            evidence, peer_benchmarking, citation = self._evidence_and_citation_from_items(
                items=kept_items,
                citation_index=citation_index,
                specific_facts=specific_facts,
                has_citations=bool(citation_index),
            )
            rec["evidence"] = evidence
            rec["peer_benchmarking"] = peer_benchmarking
            rec["citation"] = citation
            new_recs.append(rec)

        if not new_recs:
            decision = "suppressed"
        elif any_items_dropped:
            decision = "items_dropped"
        else:
            decision = "ok"

        return {
            "recommended_action": new_recs,
            "recommendation_validation": {
                "decision": decision,
                "summary": " | ".join(summary_lines) if summary_lines else "all items aligned with pattern",
                "dropped_count": total_dropped,
                "kept_count": total_kept,
                "verdicts": all_verdicts,
            },
        }

    # ========================================================================
    # Pattern Context Extraction
    # ========================================================================

    def _resolve_pattern_title(self, pattern: Dict[str, Any]) -> str:
        """Resolve a human-readable pattern title from pattern-agent output.

        Resolution order matches the pattern agent's field aliases:
        pattern_title → top_pattern → title → "Unknown Pattern".
        """
        if not pattern:
            return "Unknown Pattern"
        return (
            pattern.get("pattern_title")
            or pattern.get("top_pattern")
            or pattern.get("title")
            or "Unknown Pattern"
        )

    # ========================================================================
    # Top-K chain — map ranked taxonomies to policies
    # ========================================================================

    def _find_taxonomy_policies(self, state: ReimbursementState) -> Dict[str, Any]:
        """Helper: map the ranked provider taxonomies to reimbursement policies.

        Bridges the ranking nodes to the shared extraction pipeline. Reads the
        ranked rows from ``topk_result``, pulls the NUCC taxonomy code from each
        row (the ranking dimension column), maps those codes to policy metadata
        via ``configs/policy_taxonomy_mapping.json``, hydrates each policy from
        Snowflake, and returns them as ``filtered_policies`` in the same API
        shape ``fetch_content_node`` expects (``policy_id`` / ``policy_title`` /
        ``external_link`` / ``payor``).
        """
        topk_result = state.get("topk_result") or {}
        rows = topk_result.get("rows") or []
        dimension = (
            topk_result.get("dimension")
            or state.get("dimension")
            or TAXONOMY_CODE_DIMENSION
        )

        metric_alias = topk_result.get("metric_alias")
        ranked = self._extract_ranked_taxonomies(rows, dimension, metric_alias)
        codes = self._select_top_taxonomies(ranked)
        if not codes:
            self.logger.warning(
                "find_taxonomy_policies: no taxonomy codes selected from top-%s %r "
                "ranking; nothing to map to policies",
                topk_result.get("top_k"), dimension,
            )
            return {"filtered_policies": [], "taxonomy_codes": [], "taxonomy_policies": []}

        self.logger.info(
            "find_taxonomy_policies: mapping %d ranked taxonomy code(s) to policies: %s",
            len(codes), codes,
        )

        policies_meta = self.get_policies_for_taxonomy_mapping(codes)
        if not policies_meta:
            self.logger.warning(
                "find_taxonomy_policies: no policies mapped from %d taxonomy code(s)",
                len(codes),
            )
            return {"filtered_policies": [], "taxonomy_codes": codes, "taxonomy_policies": []}

        snowflake_helper = state.get("snowflake_helper")
        if snowflake_helper is None:
            raise RuntimeError(
                "Snowflake helper is required to hydrate taxonomy-mapped policies."
            )

        # Optional narrowing. Top-K mode has no pattern/context, so these are
        # off unless a caller supplies them explicitly (see prepare_state).
        states = state.get("states") or None
        lobs = state.get("lobs") or None
        fetch_competitor_policies = bool(state.get("fetch_competitor_policies"))

        filtered_policies: List[Dict[str, Any]] = []
        seen_policy_ids: set = set()
        for policy_meta in policies_meta:
            policy_number = policy_meta.get("policy_number")
            if not policy_number:
                continue
            records = self._fetch_policy_details_from_db(
                snowflake_helper, policy_number, states, lobs,
                fetch_competitor_policies=fetch_competitor_policies,
            )
            for record in records:
                policy_id = record.get("policy_id")
                if policy_id in seen_policy_ids:
                    continue
                seen_policy_ids.add(policy_id)
                filtered_policies.append(record)

        self.logger.info(
            "find_taxonomy_policies: %d taxonomy code(s) -> %d mapped policy(ies) -> "
            "%d hydrated policy record(s) ready for extraction",
            len(codes), len(policies_meta), len(filtered_policies),
        )

        return {
            "filtered_policies": filtered_policies,
            "taxonomy_codes": codes,
            "taxonomy_policies": policies_meta,
        }

    @staticmethod
    def _normalize_filter_values(value: Any) -> List[str]:
        """Flatten a leaf ``value`` into a list of clean string tokens.

        Handles list/tuple values, comma-delimited strings, and scalars; strips
        whitespace and drops empties. First-seen order preserved.
        """
        if isinstance(value, (list, tuple)):
            raw: List[Any] = list(value)
        elif isinstance(value, str) and "," in value:
            raw = value.split(",")
        else:
            raw = [value]
        out: List[str] = []
        for item in raw:
            if item is None:
                continue
            token = str(item).strip()
            if token:
                out.append(token)
        return out

    @staticmethod
    def _normalize_lob_to_policy(lobs: Any) -> List[str]:
        """Collapse business-unit-qualified claims LOB variants to the canonical
        top-level names the policy table's ``LOB_NM`` column stores.

        The semantic view's LOB descriptions carry qualified variants (e.g.
        "Commercial Individual", "GBD Medicaid", "Medicare GRS"), but the policy
        side only stores the top-level name ("Commercial" / "Medicare" /
        "Medicaid"). Applying a qualified value verbatim to ``LOB_NM`` matches
        nothing. Unknown values pass through unchanged. Empties are dropped and
        the result is de-duplicated preserving first-seen order.

        Used by the top-K path (``prepare_state``) to collapse claims-side LOB
        filter values before policy hydration in ``find_taxonomy_policies_node``.
        """
        if not lobs:
            return []
        mapping = {
            "commercial individual": "Commercial",
            "commercial local group": "Commercial",
            "medicare grs": "Medicare",
            "medicare indiv": "Medicare",
            "gbd medicare": "Medicare",
            "gbd medicaid": "Medicaid",
        }
        out: List[str] = []
        for lob in lobs:
            if lob is None:
                continue
            token = str(lob).strip()
            if not token:
                continue
            canonical = mapping.get(token.lower(), token)
            if canonical not in out:
                out.append(canonical)
        return out

    def _extract_filter_codes(self, filters: Any) -> Dict[str, List[str]]:
        """Pull state / LOB / clinical codes out of the ``filters`` tree.

        Walks every leaf via ``collect_filter_leaves`` and buckets its value(s)
        by logical code type using ``FILTER_CODE_ALIASES``. Leaves whose field
        is not a recognized code alias are ignored (per design: code types whose
        fields are absent from the active YAML never reach here). Values are
        de-duplicated per code type preserving first-seen order. Returns only
        code types actually present; ``{}`` when ``filters`` is empty/None.
        """
        if not filters:
            return {}
        collected: Dict[str, List[str]] = {}
        for leaf in collect_filter_leaves(filters):
            field = leaf.get("field")
            if not field:
                continue
            code_type = _FILTER_FIELD_TO_CODE_TYPE.get(str(field).lower())
            if not code_type:
                continue
            bucket = collected.setdefault(code_type, [])
            for token in self._normalize_filter_values(leaf.get("value")):
                if token not in bucket:
                    bucket.append(token)
        return collected

    @staticmethod
    def _row_value_ci(row: Dict[str, Any], key: str) -> Any:
        """Case-insensitive lookup of ``key`` in a top-K result row.

        The ranking query aliases dimension/metric columns lower-case, but
        Snowflake upper-cases unquoted aliases, so the row keys come back upper.
        """
        key_lower = str(key).lower()
        for k, v in row.items():
            if str(k).lower() == key_lower:
                return v
        return None

    def _extract_ranked_taxonomies(
        self,
        rows: List[Dict[str, Any]],
        dimension: str,
        metric_alias: Optional[str],
    ) -> List[tuple]:
        """Pull ``(code, metric)`` pairs out of the ranked top-K rows.

        Preserves the incoming (metric-DESC) order, drops blank codes, and
        de-dupes by code keeping the first (highest-ranked) occurrence. The
        metric is coerced to ``float`` where possible, else ``None`` (so the
        Pareto step can detect an unusable metric and fall back).
        """
        ranked: List[tuple] = []
        seen: set = set()
        for row in rows:
            value = self._row_value_ci(row, dimension)
            if value is None:
                continue
            code = str(value).strip()
            if not code or code in seen:
                continue
            seen.add(code)

            metric_val: Optional[float] = None
            if metric_alias:
                raw_metric = self._row_value_ci(row, metric_alias)
                if raw_metric is not None and str(raw_metric).strip() != "":
                    try:
                        metric_val = float(raw_metric)
                    except (TypeError, ValueError):
                        metric_val = None
            ranked.append((code, metric_val))
        return ranked

    def _select_top_taxonomies(self, ranked: List[tuple]) -> List[str]:
        """Narrow ranked ``(code, metric)`` pairs to the taxonomies to search.

        Selection rule:
          1. Drop sentinel codes in ``TAXONOMY_EXCLUDE_CODES`` (e.g. ``"-2"``).
          2. Compute the cumulative Pareto count: the smallest number of
             top-ranked taxonomies whose combined metric reaches
             ``TAXONOMY_PARETO_THRESHOLD`` of the total. If any metric is
             missing or the positive total is <= 0, Pareto is undefined and we
             fall back to keeping all remaining (the cap below still narrows).
          3. Return the top ``min(TAXONOMY_MAX_SELECTED, pareto_count)`` codes,
             in rank order.
        """
        clean = [(code, metric) for code, metric in ranked
                 if code not in TAXONOMY_EXCLUDE_CODES]
        excluded = len(ranked) - len(clean)
        if not clean:
            self.logger.warning(
                "select_top_taxonomies: no taxonomies left after excluding %s "
                "from %d ranked code(s)", TAXONOMY_EXCLUDE_CODES, len(ranked),
            )
            return []

        metrics = [metric for _, metric in clean]
        total = sum(m for m in metrics if m is not None)
        if any(m is None for m in metrics) or total <= 0:
            pareto_count = len(clean)
            self.logger.warning(
                "select_top_taxonomies: metric unusable for Pareto "
                "(missing values or non-positive total); falling back to all "
                "%d remaining taxonomies before the cap", len(clean),
            )
        else:
            cutoff = TAXONOMY_PARETO_THRESHOLD * total
            running = 0.0
            pareto_count = 0
            for _, metric in clean:
                running += metric or 0.0
                pareto_count += 1
                if running >= cutoff:
                    break
            pareto_count = max(1, pareto_count)

        final_count = min(TAXONOMY_MAX_SELECTED, pareto_count)
        selected = [code for code, _ in clean[:final_count]]
        self.logger.info(
            "select_top_taxonomies: %d ranked -> excluded %d sentinel -> "
            "Pareto-%.0f%% count %d -> capped at %d -> selected %s",
            len(ranked), excluded, TAXONOMY_PARETO_THRESHOLD * 100,
            pareto_count, TAXONOMY_MAX_SELECTED, selected,
        )
        return selected

    def get_policies_for_taxonomy_mapping(self, taxonomy_codes: List[str]) -> List[Dict]:
        """
        Retrieve policies associated with given taxonomy codes.

        Args:
            taxonomy_codes: List of taxonomy codes to filter policies

        Returns:
            List of unique policies matching the provided taxonomy codes
        """
        from collections import defaultdict

        current_dir = Path(__file__).resolve().parent

        # Navigate up 3 levels to reach the project root directory where configs reside.
        policy_taxonomy_mapping_path = (
            current_dir.parents[3] / "configs" / "policy_taxonomy_mapping.json"
        )

        try:
            with open(policy_taxonomy_mapping_path, "r") as file:
                policies_data = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            # Prevent low-level I/O leakage and provide an operational error with the expected path.
            self.logger.error(
                f"Failed to load policy taxonomy mapping from path: {policy_taxonomy_mapping_path}"
            )
            raise RuntimeError(
                f"Failed to load policy taxonomy mapping from path: {policy_taxonomy_mapping_path}"
            ) from e

        taxonomy_to_policies = defaultdict(list)

        for policy in policies_data:
            policy_metadata = {
                "policy_category": policy.get("policy_category"),
                "policy_number": policy.get("policy_number"),
                "policy_topic": policy.get("policy_topic"),
                "claim_type": policy.get("claim_type"),
            }

            taxonomy_list = policy.get("taxonomy", [])

            if isinstance(taxonomy_list, list) and taxonomy_list:
                for taxonomy_entry in taxonomy_list:
                    code = taxonomy_entry.get("taxonomy_code")

                    if code and policy_metadata not in taxonomy_to_policies[code]:
                        taxonomy_to_policies[code].append(policy_metadata)

        matching_policies = []
        seen_policies = set()

        for code in taxonomy_codes:
            policies = taxonomy_to_policies.get(code, [])
            for policy in policies:
                policy_key = (
                    policy["policy_category"],
                    policy["policy_number"],
                    policy["policy_topic"],
                    policy["claim_type"],
                )
                if policy_key not in seen_policies:
                    seen_policies.add(policy_key)
                    matching_policies.append(policy)

        return matching_policies

    def _fetch_policy_details_from_db(
        self,
        snowflake_helper: Any,
        policy_number: str,
        states: Optional[List[str]] = None,
        lobs: Optional[List[str]] = None,
        fetch_competitor_policies: bool = False
    ) -> List:
        """Fetches medical reimbursement policy metadata from Snowflake matching specific demographics."""

        def escape_sql(val):
            return str(val).replace("'", "''")

        def state_clause(state_values: List[str]) -> str:
            """State narrowing that also keeps national / state-agnostic policies.

            Reimbursement policies are mostly national (state lives in the policy
            title, not ST_CD), so a strict ``ST_CD IN (...)`` would drop every
            applicable national policy. Keep rows whose ST_CD matches a requested
            state OR is null / blank / an explicit national sentinel. Case-folded
            to survive the exact-match brittleness of ST_CD. Handles a single
            state and a list identically.
            """
            state_in = ", ".join(f"'{escape_sql(str(st).strip())}'" for st in state_values)
            sentinels = ", ".join(f"'{s}'" for s in POLICY_NATIONAL_ST_CD_SENTINELS)
            return (
                f"(ST_CD IN ({state_in}) OR ST_CD IS NULL OR TRIM(ST_CD) = ''"
                f" OR UPPER(TRIM(ST_CD)) IN ({sentinels}))"
            )

        def lob_clause(lob_values: List[str]) -> str:
            """LOB narrowing, case-folded, that also keeps unlabelled policies.

            Callers pass policy-canonical LOB names (see ``_normalize_lob_to_policy``).
            Compare case-insensitively and keep rows with null / blank LOB_NM so
            national/unlabelled policies survive.
            """
            lob_in = ", ".join(
                f"'{escape_sql(str(lob).strip().upper())}'" for lob in lob_values
            )
            return f"(UPPER(TRIM(LOB_NM)) IN ({lob_in}) OR LOB_NM IS NULL OR TRIM(LOB_NM) = '')"

        # Normalize the bind value the same way the column is normalized in the
        # WHERE clause (UPPER + all spaces removed). The taxonomy mapping's
        # policy numbers carry incidental leading/trailing whitespace (e.g.
        # "C-22001 ", " C-20003"); without this, those policies would compare
        # against a space-stripped/upper-cased column and silently match nothing.
        sanitized_policy_number = escape_sql(str(policy_number).replace(" ", "").upper())
        policy_table = self.table("policy_metadata")

        try:
            if not fetch_competitor_policies:
                where_clauses = [
                    "PLCY_TYPE_NM = 'Reimbursement'",
                    f"UPPER(REPLACE(PAYOR_ASGN_PLCY_ID, ' ', '')) = '{sanitized_policy_number}'"
                ]
                if states:
                    where_clauses.append(state_clause(states))
                if lobs:
                    where_clauses.append(lob_clause(lobs))

                sql = f"""
                    SELECT
                        PLCY_ID,
                        PLCY_TTL_TXT,
                        PAYOR_ASGN_PLCY_ID,
                        ST_CD,
                        PAYOR_NM,
                        LOB_NM,
                        CLM_TYPE_NM,
                        PLCY_URL_TXT
                    FROM {policy_table}
                    WHERE {" AND ".join(where_clauses)}
                        AND ACTV_STTS_NM ILIKE 'Active'
                        AND STTS_NM NOT ILIKE '%delete%'
                    QUALIFY ROW_NUMBER() OVER (PARTITION BY PLCY_ID ORDER BY RCRD_DT DESC) = 1
                    LIMIT 5;
                """
                df = snowflake_helper.execute_query_and_return_pandas_df(sql)

            else:
                topc_table = self.table("policy_metadata_topic_comparison")
                filters = []
                if states:
                    filters.append(state_clause(states))
                if lobs:
                    filters.append(lob_clause(lobs))
                filters_where_clauses = f"AND {' AND '.join(filters)}" if filters else ""

                topic_lookup_sql = f"""
                    WITH reimb_plcy AS (
                        SELECT PLCY_ID
                        FROM {policy_table}
                        WHERE PLCY_TYPE_NM ILIKE 'Reimbursement'
                            AND UPPER(REPLACE(PAYOR_ASGN_PLCY_ID, ' ', '')) = '{sanitized_policy_number}'
                            AND ACTV_STTS_NM ILIKE 'Active'
                            AND STTS_NM NOT ILIKE '%delete%'
                        QUALIFY ROW_NUMBER() OVER (PARTITION BY PLCY_ID ORDER BY RCRD_DT DESC) = 1
                    ),

                    topc AS (
                        SELECT PLCY_ID, TOPC_ID
                        FROM {topc_table}
                        WHERE STTS_NM NOT ILIKE '%delete%'
                        QUALIFY ROW_NUMBER() OVER (PARTITION BY PLCY_ID, TOPC_ID ORDER BY EDL_LOAD_DTM DESC) = 1
                    )

                    SELECT DISTINCT
                        t.TOPC_ID
                    FROM reimb_plcy p
                    JOIN topc t
                        ON p.PLCY_ID = t.PLCY_ID;
                """

                df_topics = snowflake_helper.execute_query_and_return_pandas_df(topic_lookup_sql)

                if df_topics.empty:
                    self.logger.info(f"No topics found for policy_number: {policy_number}. Returning empty list.")
                    return []

                topic_ids_str = ", ".join([f"'{escape_sql(tid)}'" for tid in df_topics["TOPC_ID"].dropna()])

                competitor_sql = f"""
                    WITH reimb_plcy AS (
                        SELECT PLCY_ID, PAYOR_ASGN_PLCY_ID, PLCY_TTL_TXT, PAYOR_NM, LOB_NM, ST_CD, CLM_TYPE_NM, PLCY_URL_TXT
                        FROM {policy_table}
                        WHERE PLCY_TYPE_NM ILIKE 'Reimbursement'
                            AND ACTV_STTS_NM ILIKE 'Active'
                            AND STTS_NM NOT ILIKE '%delete%'
                            {filters_where_clauses}
                        QUALIFY ROW_NUMBER() OVER (PARTITION BY PLCY_ID ORDER BY RCRD_DT DESC) = 1
                    ),

                    topc AS (
                        SELECT PLCY_ID, TOPC_ID
                        FROM {topc_table}
                        WHERE TOPC_ID IN ({topic_ids_str})
                            AND STTS_NM NOT ILIKE '%delete%'
                        QUALIFY ROW_NUMBER() OVER (PARTITION BY PLCY_ID, TOPC_ID ORDER BY EDL_LOAD_DTM DESC) = 1
                    )

                    SELECT DISTINCT
                        p.PLCY_ID,
                        p.PLCY_TTL_TXT,
                        p.PAYOR_ASGN_PLCY_ID,
                        p.ST_CD,
                        p.PAYOR_NM,
                        p.LOB_NM,
                        p.CLM_TYPE_NM,
                        p.PLCY_URL_TXT
                    FROM reimb_plcy p
                    JOIN topc t
                        ON p.PLCY_ID = t.PLCY_ID
                    LIMIT 5;
                """
                df = snowflake_helper.execute_query_and_return_pandas_df(competitor_sql)

            if df.empty:
                return []

            df = df.rename(columns={
                "PLCY_ID": "policy_id",
                "PLCY_TTL_TXT": "policy_title",
                "PLCY_URL_TXT": "external_link",
                "PAYOR_NM": "payor"
            })
            self.logger.info(f"Retrieved Policy metadata for {len(df)} policies")
            return df.to_dict("records")

        except Exception:
            self.logger.exception(f"Failed to fetch policy details from DB for policy_number: {policy_number}")
            return []

    # ========================================================================
    # Search policy with policy-comparison-api
    # ========================================================================

    def _normalize_lob_list(self, lob_list: List[str]) -> List[str]:
        """Normalize LOB values to canonical API names.
        
        Collapses business-unit-qualified LOB variants to top-level names
        that the policy_comparison API expects.
        """
        lob_mapping = {
            "Commercial Individual": "Commercial",
            "Commercial Local Group": "Commercial",
            "Medicare GRS": "Medicare",
            "Medicare Indiv": "Medicare",
            "GBD Medicare": "Medicare",
            "GBD Medicaid": "Medicaid",
        }
        return [lob_mapping.get(lob, lob) for lob in lob_list] if lob_list else []

    def _generate_search_keywords(
        self,
        drg_codes: List[str],
        cpt_codes: str,
        llm: Any = None,
        user_query: Optional[str] = None,
        llm_mini: Any = None,
    ) -> List[str]:
        """Generate search keywords from DRG codes (preferred) or CPT codes.
        
        DRG codes are prioritized for specificity. Uses LLM to enrich codes with
        clinical topics so narrative policies are matched alongside code-listing documents.
        
        LLM tier selection:
          - DRG: uses main LLM (complex multi-code reasoning)
          - CPT: uses llm_mini (simple classification task)
        
        Args:
            drg_codes: List of DRG codes from pattern
            cpt_codes: Comma-separated CPT codes
            llm: Main LLM for DRG keywords
            user_query: Optional user question (tie-breaker only)
            llm_mini: Smaller LLM for CPT keywords (cost/latency optimization)
            
        Returns:
            List of search keywords for policy API
        """
        # DRG path (preferred)
        if drg_codes:
            if llm:
                return self._generate_search_keywords_from_drg(drg_codes, llm, user_query=user_query)
            
            # Fallback: extract keywords from first DRG
            primary_drg = drg_codes[0]
            words = primary_drg.replace("without", "").replace("with", "").split()
            meaningful = [w for w in words if len(w) > 2 and w.lower() not in {"the", "and", "for"}]
            keywords = [" ".join(meaningful[:2])] if meaningful else [primary_drg]
            self.logger.info(f"Extracted keywords from first DRG: {keywords}")
            return keywords

        # CPT path
        if cpt_codes:
            cpt_llm = llm_mini or llm
            if cpt_llm:
                return [self._generate_search_keywords_from_cpt(cpt_codes, cpt_llm, user_query=user_query)]
            
            # Fallback: use raw first code
            first_cpt = cpt_codes.split(",")[0].strip()
            self.logger.info(f"No LLM; using raw CPT code: {first_cpt}")
            return [first_cpt]

        self.logger.warning("No DRG or CPT codes available")
        return ["Unknown"]

    def _generate_search_keywords_from_drg(
        self, drg_codes: List[str], llm: Any, user_query: Optional[str] = None
    ) -> List[str]:
        """Generate search keywords from DRG codes using LLM.
        
        Identifies top 3 clinical keywords from DRG descriptions, stripping billing
        jargon to match natural language in policy documents.
        
        Args:
            drg_codes: List of DRG code descriptions
            llm: LLM client for keyword generation
            user_query: Optional user question (tie-breaker only)
            
        Returns:
            List of 3 keywords or fallback from first DRG
        """
        if not drg_codes:
            return []

        drg_codes_str = json.dumps(drg_codes)
        
        user_question_block = ""
        if user_query:
            cleaned = self._clean_user_query(user_query)
            if cleaned:
                user_question_block = f"\nUser question (tie-breaker only): {cleaned}\n"

        keyword_prompt = textwrap.dedent(f"""
            Translate DRG billing codes into clinical search terms for a policy search engine.

            DRG codes: {drg_codes_str}
            {user_question_block}
            
            TASK:
            1. Extract core CLINICAL CONDITION or PROCEDURE from each DRG
            2. Strip billing modifiers: MCC, CC, W/O, W/, WITHOUT, WITH, age thresholds, severity
            3. Convert to clinical terms that appear in medical policies
            4. Return exactly 3 most relevant keywords, ordered by relevance

            RULES:
            - 1-2 words per keyword
            - Natural medical language only
            - Avoid generic terms: "surgery", "procedure", "inpatient", "MS DRG"
            - Focus on specific condition, body system, or clinical procedure

            EXAMPLES:
            - "291 - Heart Failure & Shock W MCC" → "heart failure, cardiogenic shock, heart disease"
            - "193 - Simple Pneumonia W CC" → "pneumonia, lung infection, pneumonitis"
            - "470 - Major Hip Joint Replacement" → "hip replacement, joint arthroplasty, hip arthroplasty"

            Return ONLY 3 comma-separated keywords.""")

        messages = [
            {"role": "system", "content": "You are a medical coding expert. Generate concise search keywords."},
            {"role": "user", "content": keyword_prompt},
        ]

        try:
            response = self._invoke_llm_with_retry(llm, messages, schema="search_keywords")
            self._record_tokens("search_keywords", response)
            keywords_raw = response.content.strip().strip('"').strip("'")
            keywords = [k.strip() for k in keywords_raw.split(",")]
            
            self.logger.info(f"DRG keywords from {len(drg_codes)} code(s): {keywords}")
            return keywords

        except Exception as e:
            self.logger.warning(f"DRG keyword generation failed: {e}, using fallback")
            words = drg_codes[0].replace("without", "").replace("with", "").split()
            meaningful = [w for w in words if len(w) > 2 and w.lower() not in {"the", "and", "for"}]
            fallback = [" ".join(meaningful[:2])] if meaningful else [drg_codes[0]]
            self.logger.info(f"Fallback keywords: {fallback}")
            return fallback

    def _generate_search_keywords_from_cpt(self, cpt_codes: str, llm: Any, user_query: Optional[str] = None) -> str:
        """Generate search keywords from CPT/HCPCS codes using LLM.
        
        Combines the first code with a clinical category keyword to match both
        code-listing documents and narrative policies that describe rules by topic.
        
        Args:
            cpt_codes: Comma-separated CPT/HCPCS codes
            llm: LLM client for keyword generation
            user_query: Optional user question (tie-breaker only)
            
        Returns:
            String "<code>,<clinical_topic>" or raw first code on error
        """
        if not cpt_codes:
            return ""

        first_code = cpt_codes.split(",")[0].strip()
        code_list = [c.strip() for c in cpt_codes.split(",") if c.strip()]
        codes_str = json.dumps(code_list)

        user_question_block = ""
        if user_query:
            cleaned = self._clean_user_query(user_query)
            if cleaned:
                user_question_block = f"\nUser question (tie-breaker only): {cleaned}\n"

        keyword_prompt = textwrap.dedent(f"""
            Given CPT/HCPCS codes: {codes_str}
            {user_question_block}
            Identify the SINGLE most relevant clinical CATEGORY keyword (1-2 words) for searching reimbursement policies.

            Prefer broader category names that appear in policy TITLES, not narrow clinical nouns.
            
            Category examples:
            - Ambulance/EMS (A04xx-A09xx): "ambulance" or "transportation"
            - E/M codes (99xxx): "evaluation and management"
            - Behavioral health (90xxx-908xx): "behavioral health"
            - J-codes (drugs): "injection" or "drug administration"
            - Imaging (7xxxx): "diagnostic imaging" or modality ("CT", "MRI")
            - Surgery: surgical category (e.g. "spine surgery", "orthopedic surgery")
            - GI/endoscopy (43xxx): "endoscopy"
            - Hospital outpatient (G04xx): "hospital outpatient"

            Avoid generic terms: "procedure", "service", "professional service", "medical service"
            Return ONLY the keyword phrase, no quotes or explanations.""")

        messages = [
            {"role": "system", "content": "You are a medical coding expert. Generate concise search keywords."},
            {"role": "user", "content": keyword_prompt},
        ]

        try:
            response = self._invoke_llm_with_retry(llm, messages)
            self._record_tokens("search_keywords", response)
            keyword = response.content.strip().strip('"').strip("'").split(",")[0].split("\n")[0].strip()

            if not keyword:
                self.logger.warning(f"Empty CPT keyword for {code_list}, using first code: {first_code}")
                return first_code

            combined = f"{first_code},{keyword}"
            self.logger.info(f"CPT keyword from {len(code_list)} code(s): '{combined}' (topic='{keyword}')")
            return combined

        except Exception as e:
            self.logger.warning(f"CPT keyword generation failed: {e}, using first code: {first_code}")
            return first_code

    def search_policies_using_search_keywords(self, state: ReimbursementState) -> Dict[str, Any]:
        """Search for policies via API using pattern-specific keywords with LOB/State filters.

        Args:
            state: Current graph state

        Returns:
            Updated state with filtered_policies
        """
        cpt_codes = state["cpt_codes"]
        drg_codes = state.get("drg_codes", [])
        pattern = state.get("pattern")
        query = state.get("query")
        states = state.get('states')
        lobs = state.get('lobs')
        llm = state.get("llm")
        llm_mini = state.get("llm_mini")
        pattern_rank = pattern.get("pattern_rank") if pattern else None

        # Generate search keywords from DRG/CPT codes using LLM
        search_keywords = self._generate_search_keywords(
            drg_codes, cpt_codes, llm=llm, user_query=query, llm_mini=llm_mini
        )

        self.logger.info(f"Pattern {pattern_rank}: Search keywords: {search_keywords}")
        state["search_keywords"] = search_keywords

        # Short-circuit if no search context available
        if not search_keywords and not cpt_codes:
            self.logger.warning(
                f"Pattern {pattern_rank}: insufficient search context. Skipping policy API call."
            )
            return {
                "raw_policies": [],
                "filtered_policies": [],
                "search_context_status": "insufficient",
            }

        if search_keywords:
            self.logger.info(f"Pattern {pattern_rank}: Available keywords: {search_keywords}")
        else:
            self.logger.info(f"Pattern {pattern_rank}: Searching with CPT codes: {cpt_codes}")

        # Build POST data with filters (from notebook logic)
        post_data = {"policy_type": ["Reimbursement"]}

        # Add LOB and State filters if pattern is available
        if pattern:
            # Extract LOB, State, and Product using notebook's comprehensive logic
            # Add LOB filter if available
            if lobs:
                # Normalize the lob filter (eg: Commercial Indvidual -> Commercial)
                lobs = self._normalize_lob_list(lobs)
                post_data["lob"] = lobs

            else:
                self.logger.warning(f"Pattern {pattern_rank}: No LOB filter available (not found in cards)")

            # Add State filter if available
            if states:
                post_data["state"] = states
            else:
                self.logger.warning(
                    f"Pattern {pattern_rank}: No State filter available (not found in pattern or cards)"
                )
        else:
            self.logger.info("Legacy mode: No pattern context, skipping LOB/State filters")

        # Log final filter configuration
        active_filters = {k: v for k, v in post_data.items() if k != "policy_type"}
        if active_filters:
            self.logger.info(f"Pattern {pattern_rank}: Active API filters: {active_filters}")
        else:
            self.logger.warning(
                f"Pattern {pattern_rank}: No LOB/State filters active - may return many irrelevant policies"
            )

        # API call with POST body for filters (with retry mechanism)
        max_retries = 2
        retry_delays = [1, 2]  # Seconds to wait between retries
        raw_data = {}

        for attempt in range(max_retries + 1):
            # Set keyword based on attempt number
            if search_keywords:
                if attempt == 0:
                    # First attempt: use first two keywords
                    keywords_to_use = search_keywords[:2]
                    keyword_for_api = ", ".join(keywords_to_use)
                    self.logger.info(
                        f"Pattern {pattern_rank}: First attempt - using first 2 keywords: '{keyword_for_api}'"
                    )
                else:
                    # Retry attempts: use all three keywords
                    keyword_for_api = ", ".join(search_keywords)
                    self.logger.info(
                        f"Pattern {pattern_rank}: Retry attempt {attempt} - using all keywords: '{keyword_for_api}'"
                    )

                url = f"{self.policy_api_url}?keyword={keyword_for_api}&user_type=onshore"

                try:
                    response = requests.post(
                        url, headers={"Content-Type": "application/json"}, json=post_data, verify=AppConstants.SSL_CERT_FILE
                    )
                    response.raise_for_status()
                    raw_data = response.json()
                    break  # Success, exit retry loop

                except (requests.RequestException, requests.HTTPError) as e:
                    if attempt < max_retries:
                        delay = retry_delays[attempt]
                        self.logger.warning(
                            f"Pattern {pattern_rank}: Policy API call failed (attempt {attempt + 1}/{max_retries + 1}): {e}. "
                            f"Retrying in {delay} second(s)..."
                        )
                        time.sleep(delay)
                    else:
                        self.logger.error(
                            f"Pattern {pattern_rank}: Policy API call failed after {max_retries + 1} attempts: {e}"
                        )
                        raise

        self.logger.info(
            f"Pattern {pattern_rank}: API returned {len(raw_data.get('sentencelist', 0))} policies (with keyword + filters)"
        )

        # Convert to DataFrame for additional filtering
        df = pd.DataFrame(raw_data)
        df = df["sentencelist"].apply(pd.Series)

        # Log original payor distribution before any filtering
        original_payors = df["payor"].value_counts().to_dict()
        self.logger.info(f"Pattern {pattern_rank}: Original payors from API: {original_payors}")

        # Check for Elevance in original API response
        elevance_in_api = df["payor"].str.contains("Elevance", case=False, na=False).any()
        if elevance_in_api:
            elevance_count = df["payor"].str.contains("Elevance", case=False, na=False).sum()
            elevance_types = (
                df[df["payor"].str.contains("Elevance", case=False, na=False)]["policy_type"].value_counts().to_dict()
            )
            self.logger.info(
                f"Pattern {pattern_rank}: Found {elevance_count} Elevance policies in API response with types: {elevance_types}"
            )

        # Filter by file type
        df["file_type"] = df.policy_link.str.split(".").str[-1]
        df = df[df["file_type"] == "pdf"]

        # Policy type should already be filtered by API, but double-check
        df = df[df["policy_type"] == "Reimbursement"]

        # Remove duplicates by payor & external_link
        df = df.drop_duplicates(subset=["payor", "external_link"])

        self.logger.info(f"Pattern {pattern_rank}: After PDF/policy_type/dedup: {len(df)} policies")

        # Dedup by (payor, policy_title). Elevance
        # publishes identical titles per state, so 200 policy_ids can
        # collapse to ~20 unique (payor, title) pairs. Keep the row with
        # the highest policy_score per group; falls back to first
        # occurrence when scores are missing or non-numeric (API returned
        # score-descending order, so keep="first" is safe).
        if "policy_title" in df.columns and len(df) > 0:
            before = len(df)
            if "policy_score" in df.columns:
                sort_scores = pd.to_numeric(df["policy_score"], errors="coerce").fillna(0)
                df = (
                    df.assign(_sort_score=sort_scores)
                    .sort_values(by="_sort_score", ascending=False, kind="mergesort")
                    .drop(columns=["_sort_score"])
                )
            df = df.drop_duplicates(subset=["payor", "policy_title"], keep="first")
            self.logger.info(f"Pattern {pattern_rank}: (payor, title) dedup: {before} → {len(df)} policies")

        # Verify Elevance survived filtering
        if elevance_in_api:
            elevance_after_filter = df["payor"].str.contains("Elevance", case=False, na=False).sum()
            if elevance_after_filter > 0:
                self.logger.info(
                    f"Pattern {pattern_rank}: ✓ Retained {elevance_after_filter} Elevance policies after filtering"
                )
            else:
                self.logger.warning(f"Pattern {pattern_rank}: ⚠ Lost all Elevance policies during filtering!")

        # Get policy hashes from Snowflake
        policy_ids = df.policy_id.unique().tolist()
        df_hash = self._get_policy_hashes(policy_ids)

        # Merge and deduplicate by hash
        df = df.merge(df_hash, left_on="policy_id", right_on="PLCY_ID", how="left")
        df = df.drop_duplicates(subset=["payor", "PDF_HASH_VAL_ID"])

        self.logger.info(f"Pattern {pattern_rank}: After hash deduplication: {len(df)} unique policies")

        # Check for both internal and external Elevance policies (informational only)
        internal_elevance_payors = ["Elevance Health (Internal)", "Elevance Health (internal)"]
        has_internal_elevance = df["payor"].isin(internal_elevance_payors).any()
        has_external_elevance = (df["payor"] == "Elevance Health (external)").any()

        if has_internal_elevance and has_external_elevance:
            internal_count = len(df[df["payor"].isin(internal_elevance_payors)])
            external_count = len(df[df["payor"] == "Elevance Health (external)"])
            self.logger.info(
                f"Pattern {pattern_rank}: Found both internal ({internal_count}) and external ({external_count}) "
                f"Elevance policies - keeping both as they may contain different information"
            )
        elif has_internal_elevance:
            internal_count = len(df[df["payor"].isin(internal_elevance_payors)])
            self.logger.info(f"Pattern {pattern_rank}: Found {internal_count} internal Elevance policy(ies)")
        elif has_external_elevance:
            external_count = len(df[df["payor"] == "Elevance Health (external)"])
            self.logger.info(f"Pattern {pattern_rank}: Found {external_count} external Elevance policy(ies)")

        # Cap the policy set with three goals:
        #   1. Always keep Elevance policies when present (pinned, not subject to LLM triage)
        #   2. Cap each payor at POLICY_CAP_MAX_PER_PAYOR so one payor cannot crowd out others
        #   3. Use an LLM title-triage call to pick the most relevant non-Elevance policies
        #      when the per-payor-capped set still exceeds the remaining budget. Triage falls
        #      back to API ordering on any failure so the pattern always makes progress.
        df = self._apply_policy_caps(
            df=df,
            pattern_rank=pattern_rank,
            pattern_details=self._build_pattern_details(state),
            llm_nano=state.get("llm_nano"),
        )

        self.logger.info(f"Pattern {pattern_rank}: ✓ Final policy count: {len(df)} policies ready for extraction")

        # Summary of search effectiveness
        if len(df) == 0:
            self.logger.warning(
                f"Pattern {pattern_rank}: No policies found! Check if filters are too restrictive or keyword is too specific."
            )

        return {
            "raw_policies": raw_data,
            "filtered_policies": df.to_dict("records"),
        }

    def _apply_policy_caps(
        self,
        df: pd.DataFrame,
        pattern_rank: Optional[int],
        pattern_details: str,
        llm_nano: Any,
    ) -> pd.DataFrame:
        """Apply Elevance pinning + per-payor cap + LLM relevance triage + global cap.

        Returns a DataFrame of length <= POLICY_CAP_MAX_TOTAL. Elevance policies
        present in the input are guaranteed in the output (subject to the
        per-payor cap). The triage LLM is consulted only for non-Elevance rows,
        and only when the per-payor-capped non-Elevance set still exceeds the
        remaining budget. Any triage failure silently falls back to API order.
        """
        before = len(df)
        if before == 0:
            return df

        is_elevance = df["payor"].str.contains(ELEVANCE_PAYOR_TOKEN, case=False, na=False)
        elevance_df = df[is_elevance].groupby("payor", sort=False, group_keys=False).head(POLICY_CAP_MAX_PER_PAYOR)
        other_df = df[~is_elevance].groupby("payor", sort=False, group_keys=False).head(POLICY_CAP_MAX_PER_PAYOR)

        other_budget = max(0, POLICY_CAP_MAX_TOTAL - len(elevance_df))
        triage_ran = False
        triage_scores = {}

        if len(other_df) > 0 and llm_nano is not None:
            triage_result = self._triage_policy_titles(
                other_df=other_df,
                pattern_details=pattern_details,
                target_count=other_budget,
                llm=llm_nano,
                pattern_rank=pattern_rank,
            )
            if triage_result:
                selected_ids, triage_scores = triage_result
                available = set(other_df["policy_id"])
                ordered = [pid for pid in selected_ids if pid in available]
                if ordered:
                    other_df = other_df.set_index("policy_id").loc[ordered].reset_index()
                    triage_ran = True
                    # Apply budget cap only if we exceed it after threshold filtering
                    if len(other_df) > other_budget:
                        self.logger.info(
                            f"Pattern {pattern_rank}: Threshold filtering returned {len(other_df)} policies, "
                            f"capping to budget of {other_budget}"
                        )
                        other_df = other_df.head(other_budget)

        # Only apply head() if triage didn't run
        if not triage_ran:
            other_df = other_df.head(other_budget)

        result = pd.concat([elevance_df, other_df], ignore_index=True)

        if len(result) < before:
            score_info = ""
            if triage_scores:
                avg_score = sum(triage_scores.values()) / len(triage_scores)
                score_info = f", avg_relevancy={avg_score:.1f}"

            self.logger.warning(
                f"Pattern {pattern_rank}: Capped {before} → {len(result)} policies "
                f"(≤{POLICY_CAP_MAX_PER_PAYOR}/payor, ≤{POLICY_CAP_MAX_TOTAL} total, "
                f"Elevance pinned, triage_used={triage_ran}{score_info}). "
                f"Payor distribution: {result['payor'].value_counts().to_dict()}"
            )

        return result

    def _get_policy_hashes(self, policy_ids: List[str]) -> pd.DataFrame:
        """Get policy hashes from Snowflake for deduplication.
        
        Args:
            policy_ids: List of policy IDs
            
        Returns:
            DataFrame with PLCY_ID and PDF_HASH_VAL_ID columns
        """
        if not policy_ids:
            return pd.DataFrame(columns=["PLCY_ID", "PDF_HASH_VAL_ID"])

        sql = f"""
        SELECT PLCY_ID, PDF_HASH_VAL_ID
        FROM {self.table("policy_metadata")}
        WHERE PLCY_ID IN ({{policy_ids}})
          AND ACTV_STTS_NM = 'Active'
          AND STTS_NM NOT ILIKE '%delete%'
        QUALIFY ROW_NUMBER() OVER (PARTITION BY PLCY_ID ORDER BY RCRD_DT DESC) = 1
        """
        policy_ids_str = ", ".join([f"'{pid}'" for pid in policy_ids])
        return self.snowflake_helper.execute_query_and_return_pandas_df(sql.format(policy_ids=policy_ids_str))

    def _build_pattern_details(self, state: ReimbursementState) -> str:
        """Build pattern context string for LLM triage.
        
        Assembles the same context used by extract_rules_node.
        """
        parts = []

        drg_codes = state.get("drg_codes") or []
        if drg_codes:
            parts.append(f"DRG Codes: {', '.join(drg_codes)}")

        cpt_codes = state.get("cpt_codes")
        if cpt_codes:
            parts.append(f"CPT/HCPCS Codes: {cpt_codes}")

        pattern = state.get("pattern") or {}
        pattern_title = pattern.get("pattern_title") or pattern.get("top_pattern")
        if pattern_title:
            parts.append(f"Pattern: {pattern_title}")

        return "\n".join(parts) if parts else (cpt_codes or "")

    def _triage_policy_titles(
        self,
        other_df: pd.DataFrame,
        pattern_details: str,
        target_count: int,
        llm: Any,
        pattern_rank: Optional[int],
        relevancy_threshold: int = POLICY_RELEVANCY_THRESHOLD,
    ) -> Optional[tuple[List[str], Dict[str, int]]]:
        """Ask the mini LLM to rank non-Elevance policy_ids by title relevance.

        Returns a tuple of (selected_policy_ids, score_map) where:
        - selected_policy_ids: List of policy IDs meeting the relevancy threshold, ordered by score
        - score_map: Dict mapping policy_id to relevancy_score

        Returns None on any failure (LLM error, malformed JSON, empty selection,
        validation error). Callers must treat None as "fall back to API order".
        """
        records = (
            other_df[["policy_id", "payor", "policy_title"]].fillna("").to_dict("records")
            if "policy_title" in other_df.columns
            else [
                {"policy_id": r.get("policy_id", ""), "payor": r.get("payor", ""), "policy_title": ""}
                for r in other_df.to_dict("records")
            ]
        )

        policy_lines = "\n".join(f"{r['policy_id']} | {r['payor']} | {r['policy_title']}" for r in records)

        user_prompt = TRIAGE_USER_PROMPT_TEMPLATE.format(
            pattern_details=pattern_details or "(no pattern context)",
            policy_lines=policy_lines,
            target_count=target_count,
        )
        messages = [
            {"role": "system", "content": TRIAGE_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ]

        try:
            response = self._invoke_llm_with_retry(llm, messages, schema="triage_policies")
            self._record_tokens("triage_policies", response)

            content = response.content.strip()
            if content.startswith("```"):
                lines = content.split("\n")
                if len(lines) > 2:
                    content = "\n".join(lines[1:-1])

            data = json.loads(content)
            validated = PolicyTriageResponse(**data)

            # Build score map from policy_scores if available
            score_map = {}
            if validated.policy_scores:
                score_map = {ps.policy_id: ps.relevancy_score for ps in validated.policy_scores}

                # Filter by relevancy threshold
                filtered_ids = [
                    ps.policy_id for ps in validated.policy_scores if ps.relevancy_score >= relevancy_threshold
                ]

                if filtered_ids:
                    self.logger.info(
                        f"Pattern {pattern_rank}: Triage filtered {len(validated.policy_scores)} → "
                        f"{len(filtered_ids)} policies using threshold {relevancy_threshold}. "
                        f"Score range: {min(score_map.values())}-{max(score_map.values())}"
                    )
                    return (filtered_ids, score_map)

                self.logger.warning(
                    f"Pattern {pattern_rank}: No policies met relevancy threshold {relevancy_threshold}; "
                    f"falling back to API order"
                )
                return None

            # Fallback to selected_policy_ids if policy_scores not available
            if not validated.selected_policy_ids:
                self.logger.warning(
                    f"Pattern {pattern_rank}: Triage returned empty selection; falling back to API order"
                )
                return None

            # Use selected_policy_ids without scores (backward compatibility)
            self.logger.info(
                f"Pattern {pattern_rank}: Triage returned {len(validated.selected_policy_ids)} policies "
                f"(no scores available, using count-based selection)"
            )
            return (validated.selected_policy_ids, {})

        except (json.JSONDecodeError, ValidationError) as e:
            self.logger.warning(
                f"Pattern {pattern_rank}: Triage LLM returned malformed payload ({type(e).__name__}); "
                f"falling back to API order"
            )
            return None
        except Exception as e:
            self.logger.warning(
                f"Pattern {pattern_rank}: Triage LLM call failed ({type(e).__name__}: {e}); falling back to API order"
            )
            return None

    # ========================================================================
    # Policy Relevance Judging
    # ========================================================================

    def _build_judge_pattern_summary(
        self,
        pattern: Optional[Dict[str, Any]],
        drg_codes: List[str],
        cpt_codes: str,
        filter_codes: Optional[Dict[str, List[str]]] = None,
    ) -> str:
        """Build a compact pattern descriptor for the relevance judge prompt.
        Keeps the input the LLM sees small and consistent regardless of
        medical specialty.

        Supports both pattern-based and pattern-less modes. When pattern
        is None, builds the summary from codes alone.

        Intentionally omits `pattern_details` / `why_it_matters`. Those fields
        embed the pattern's specific clinical drivers (e.g., hypertensive
        pregnancy, vasa previa for an OB pattern), which historically anchored
        the judge into rejecting topically-relevant policies that didn't
        address those exact drivers. The judge's job is topical screening,
        not driver-level matching — title + codes are sufficient signal.

        Args:
            pattern: Pattern data dictionary
            drg_codes: List of DRG codes
            cpt_codes: CPT/HCPCS codes string
            filter_codes: Optional additional filter codes

        Returns:
            Compact summary string for the judge prompt
        """
        parts: List[str] = []
        
        # Extract pattern title if pattern is available
        if pattern:
            pattern_title = (
                pattern.get("top_pattern")
                or pattern.get("pattern_title")
                or ""
            )
            if pattern_title:
                parts.append(f"Pattern title: {pattern_title}")
        
        # Always include codes (these are the primary signal)
        if drg_codes:
            parts.append(f"DRG codes: {', '.join(drg_codes[:5])}")
        if cpt_codes:
            parts.append(f"CPT/HCPCS codes: {cpt_codes}")
        # Extra clinical codes carried from the filter tree (top-K mode) so the
        # judge screens topical relevance against them too. DRG and CPT/HCPCS
        # are already covered above via drg_codes/cpt_codes.
        for label, key in (
            ("Procedure codes", "procedure"),
            ("Diagnosis codes", "diagnosis"),
            ("Revenue codes", "revenue"),
        ):
            values = (filter_codes or {}).get(key) or []
            if values:
                parts.append(f"{label}: {', '.join(values[:5])}")
        return "\n".join(parts) if parts else "(no codes or context provided)"

    def _judge_policy_relevance(
        self,
        pattern_summary: str,
        policy_title: str,
        evidence: str,
        llm: Any,
    ) -> Optional[Dict[str, Any]]:
        """Ask an LLM: could this policy plausibly apply to claims for the
        requested codes/clinical area? Returns
        ``{"relevant": bool, "confidence": "high|medium|low", "reason": str}``
        or None on parse failure (caller treats None as default-keep).

        Works in both pattern-based and pattern-less modes. The pattern_summary
        parameter contains either pattern title + codes or just codes.

        The prompt frames relevance as TOPICAL applicability — a maternity
        bundling policy is relevant to any cesarean DRG codes, even if the
        policy doesn't address specific clinical drivers (hypertensive
        pregnancy, prior C-section, etc.) that might be in a pattern narrative.
        This matches how reimbursement policies actually adjudicate: at the
        code/procedure level, not at the comorbidity-mix level.

        Mirrors the LLM-as-judge shape used in
        `recommendation_dtr_agent._check_pattern_relevance` — same prompt
        structure, same parse-then-validate flow, same default-keep
        behavior on parser hiccups.
        
        Args:
            pattern_summary: Compact summary from _build_judge_pattern_summary
            policy_title: Policy document title
            evidence: Policy evidence text (will be truncated to ~500 chars)
            llm: LLM client
            
        Returns:
            Verdict dict or None on parse failure
        """
        # Trim evidence to keep the prompt small — judge mainly needs
        # enough context to recognize the topic, not the full text.
        evidence_excerpt = (evidence or "").strip()
        if len(evidence_excerpt) > 500:
            evidence_excerpt = evidence_excerpt[:500] + "…"

        prompt = (
            "You are screening a healthcare reimbursement policy for TOPICAL "
            "relevance to requested codes/clinical area. Use your medical knowledge — "
            "the request may be from any specialty (OB, oncology, cardiology, etc.).\n\n"
            f"Requested codes/context:\n{pattern_summary}\n\n"
            f"Policy title: {policy_title or '(unknown)'}\n"
            f"Policy evidence (first ~500 chars):\n{evidence_excerpt or '(empty)'}\n\n"
            "Question: Could the rules in this policy plausibly apply to claims "
            "for the requested codes / procedures / clinical area?\n\n"
            "Answer relevant=TRUE if the policy governs the same clinical area "
            "(e.g., a 'Global Maternity/Obstetric Package' policy is relevant to "
            "any cesarean delivery DRG; an 'Assistant at Surgery' policy is "
            "relevant if it covers cesarean CPT codes; a 'Multiple Births' "
            "policy is relevant to obstetric delivery codes). The policy "
            "does NOT need to address every specific code variant, DRG severity "
            "level, or modifier mentioned in the request — broad topical "
            "applicability is enough.\n\n"
            "Answer relevant=FALSE only when the policy is clearly about a "
            "different clinical area (e.g., 'Anesthesia Professional Services' "
            "for a cardiology request, 'Readmission' billing rules for a "
            "non-readmission request, generic 'Add-on Coding' guidance with no "
            "tie to the requested procedures).\n\n"
            "Reply with JSON only, no markdown:\n"
            '{"relevant": true|false, "confidence": "high|medium|low", '
            '"reason": "<one-sentence rationale>"}\n\n'
            "Bias toward relevant=true. If unsure, answer relevant=true with "
            "confidence=low — false-positive quarantines are far worse than "
            "letting a borderline policy through."
        )

        messages = [
            {"role": "system", "content": "You are a healthcare policy relevance judge. Output only valid JSON."},
            {"role": "user", "content": prompt},
        ]

        try:
            response = self._invoke_llm_with_retry(llm, messages, schema="relevance_judge")
            self._record_tokens("relevance_judge", response)
            content = (response.content or "").strip()
            if content.startswith("```"):
                lines = content.split("\n")
                if len(lines) > 2:
                    content = "\n".join(lines[1:-1])
            data = json.loads(content)
            if not isinstance(data, dict):
                return None
            return {
                "relevant": bool(data.get("relevant", True)),
                "confidence": (data.get("confidence") or "low").strip().lower(),
                "reason": (data.get("reason") or "").strip(),
            }
        except (json.JSONDecodeError, ValueError) as exc:
            self.logger.debug(f"Relevance judge parse failed: {exc}")
            return None

    # ========================================================================
    # Recommendation Generation Logic
    # ========================================================================

    def _generate_policy_recommendations(
        self,
        pattern_context: Optional[Dict[str, Any]],
        pattern_rank: Optional[int],
        summary_table: Dict[str, Any],
        elevance_summary: Optional[str],
        llm: Any,
        user_query: Optional[str] = None,
        specific_facts: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Generate a single, code-specific policy recommendation per pattern.

        The LLM emits a structured object containing a headline and a list of
        items (each kind="edit" for Style A or kind="immediate_action" for
        Style B). The agent renders those items into the multi-line
        `description` string and surfaces the supporting facts in `evidence`
        and `peer_benchmarking`.

        Args:
            pattern_context: Pattern data with title, details, etc. (None in top-K mode)
            pattern_rank: Pattern identifier (None in top-K mode)
            summary_table: Policy summary table with payer comparisons
            elevance_summary: Elevance executive summary (if explainable), or None
            llm: LLM client
            user_query: Optional user question for steering
            specific_facts: Output of `_collect_payer_edit_rule_facts` —
                {per_payer, peer_benchmarks}. When present, the prompt requires
                items[].text to cite at least one fact verbatim.

        Returns:
            List with a single recommendation dict (or [] if none warranted).
        """
        # Extract pattern info (notebook's _pattern_context helper)
        # Support both pattern-based and pattern-less modes
        if pattern_context is not None:
            pattern_title = (
                pattern_context.get("top_pattern")
                or pattern_context.get("pattern_title")
                or f"Pattern {pattern_rank}" if pattern_rank is not None else "Policy Analysis"
            )
            pattern_evidence = (
                pattern_context.get("evidence_summary")
                or pattern_context.get("pattern_details")
                or pattern_context.get("why_it_matters")
                or ""
            )
        else:
            # Pattern-less mode: derive context from user query or use generic label
            pattern_title = "Policy Analysis"
            pattern_evidence = ""

        # Build compact table for LLM (notebook logic)
        compact_table = self._compact_summary_table(summary_table)

        # Render the structured fact blocks. When non-empty, the prompt will
        # require the LLM to cite from them verbatim AND tag each item with
        # citation ids drawn from the citation block.
        per_payer_block, peer_block, citation_block = self._format_facts_for_prompt(
            specific_facts
        )
        has_specifics = bool(per_payer_block or peer_block)
        has_citations = bool(citation_block)
        citation_index: Dict[str, Dict[str, Any]] = {
            c["id"]: c
            for c in ((specific_facts or {}).get("citations") or [])
            if isinstance(c, dict) and isinstance(c.get("id"), str)
        }

        # Optional user-question framing — included only when the query carries
        # specific intent (generic stubs are filtered out by _clean_user_query).
        cleaned_query = self._clean_user_query(user_query)
        user_question_block = (
            f"User question (frame the recommendation to address this if relevant):\n{cleaned_query}\n\n"
            if cleaned_query else ""
        )

        # Adapt pattern section based on whether we have pattern context
        if pattern_context is not None:
            pattern_section = f"""Pattern:
            - Title: {pattern_title}
            - Evidence: {pattern_evidence}"""
        else:
            # Pattern-less mode: focus on codes and user query
            pattern_section = f"""Analysis Context:
            - Focus: {pattern_title}
            - Note: Recommendations are based on policy comparison across payers for the requested codes/keywords."""

        prompt = textwrap.dedent(f"""
            You are generating a code-specific reimbursement policy recommendation.

            {user_question_block}{pattern_section}

            Elevance policy summary (if available):
            {elevance_summary or "None"}

            {per_payer_block}

            {peer_block}

            {citation_block}

            Payer policy summary table (compact):
            {compact_table}

            Output JSON schema:
            {{
            "has_recommendation": true|false,
            "recommendation": {{
                "headline": "1-sentence directive naming the target code/program",
                "items": [
                {{
                    "kind": "edit" | "immediate_action",
                    "text": "single concrete action — MUST cite ≥1 code/modifier/revenue code/threshold/numeric limit verbatim",
                    "citations": ["C3", "C7"],
                    "scope": ["COPPS"] or ["NC"] or ["all states"] or [],
                    "peer_cite": "UHC and Humana cap at 10 hrs/week" or null,
                    "exemptions": ["observation RC 0762"] or []
                }}
                ]
            }} or null
            }}

            Rules:
            1) When the "Specific facts per payer" / "Peer benchmark facts" blocks contain
            data, every items[].text MUST cite at least one VERBATIM code, modifier,
            revenue code, threshold, or numeric limit drawn from those facts.
            2) GROUNDING: When an "Available citations" block is present above, every
            items[].citations array MUST be non-empty and every id in it MUST be one
            of the listed citation ids (e.g. "C1", "C2", ...). Cite ONLY ids whose
            fact your items[].text actually relies on. Items without ≥1 valid
            citation id will be DROPPED downstream. If you cannot ground an action
            in ≥1 listed citation, omit that item rather than invent one. If no
            items survive grounding, set has_recommendation=false and
            recommendation=null.
            3) Vague phrases like "tighter guardrails", "stricter edits", or "clearer
            documentation" are NOT acceptable when specifics are available. If you
            cannot cite a specific code/modifier/revenue code/threshold from the facts,
            set has_recommendation=false and recommendation=null.
            4) Use kind="edit" for deny/bundle/exempt-style rules (renders as
            "Edit 1: Deny 99291 when..."). Use kind="immediate_action" for
            utilization-management or threshold-style actions (renders as
            "IA — Implement PA required for 90837 after 20 sessions").
            5) Always preserve X wildcards in revenue codes (write 045X, not 0450) and
            modifier formats verbatim (e.g., "25", "59", "XU").
            6) If Elevance evidence is provided, frame the recommendation as aligning
            Elevance to the strongest peer cost-control behavior; otherwise present
            the peer behavior as an adoption opportunity.
            7) MERGE OVERLAPPING ITEMS. Two items are overlapping — and MUST be emitted
            as a single item — when they act on the SAME target codes AND the SAME
            required modifiers (or, for IA items, the same code + same threshold
            metric). Express sub-conditions, narrower scopes, or refinements
            (teaching-hospital qualifications, provider-role guardrails, state
            carve-outs, documentation requirements) as additional clauses inside
            that one item's `text`, or via the `exemptions` / `scope` fields — do
            NOT split them into a second `edit` item. Items are genuinely separate
            only when they touch a distinct code set, a distinct modifier set, or
            a distinct action_type (deny vs bundle vs allow_with_conditions vs
            require_auth vs limit). When in doubt, merge.
            8) Generate at most 5 items. Prefer fewer, sharper items over many vague ones.
            9) Output JSON only, no markdown.
            10) If a user question is provided above, tailor the recommendation's framing
                to address it — but never invent claims unsupported by the facts above.
            11) PEER CITATION: When the "Peer benchmark facts" block above is non-empty,
                each items[].peer_cite MUST be a non-empty string for items whose cited
                codes / modifiers / revenue codes / thresholds / limits also appear in
                those peer facts. The string MUST name the other payer(s) and summarize
                their guardrail in one sentence (examples — adapt to your domain:
                "UHC and Humana cap at 10 hrs/week", "Cigna requires modifier 22 with a
                documented multiple gestation diagnosis", "Molina applies MPPR bundling
                on the same operative session", "Aetna denies revenue code 0762 outside
                observation"). Use peer_cite=null only when the item's grounding is
                single-payer and no peer benchmark applies.
            """)

        messages = [
            {"role": "system", "content": "You are a healthcare reimbursement strategist. Output ONLY valid JSON."},
            {"role": "user", "content": prompt}
        ]

        rank_label = f"Pattern {pattern_rank}" if pattern_rank is not None else "Query"
        self.logger.debug(
            f"{rank_label} recommendation prompt "
            f"has_specifics={has_specifics} has_citations={has_citations} "
            f"citation_count={len(citation_index)}"
        )

        try:
            response = self._invoke_llm_with_retry(llm, messages, schema="policy_recommendations")
            self._record_tokens("policy_recommendations", response)
            content = response.content.strip()

            # Remove markdown fences if present (from notebook logic)
            if content.startswith("```"):
                lines = content.split("\n")
                if len(lines) > 2:
                    content = "\n".join(lines[1:-1])

            data = json.loads(content)

            has_recommendation = data.get("has_recommendation", False)
            recommendation_obj = data.get("recommendation")

            # Backward compatibility: tolerate the old shape where
            # recommendation was a plain string.
            if has_recommendation and isinstance(recommendation_obj, str):
                description = recommendation_obj.strip()
                items: List[Dict[str, Any]] = []
            elif has_recommendation and isinstance(recommendation_obj, dict):
                items = [i for i in (recommendation_obj.get("items") or []) if isinstance(i, dict)]
                # When a citation index is available, every item must cite ≥1
                # valid id. Drop ungrounded items; if all drop, the
                # recommendation is suppressed entirely. This is the central
                # mechanism that prevents implementation-level claims from
                # floating without a named policy source.
                if has_citations:
                    grounded_items: List[Dict[str, Any]] = []
                    dropped = 0
                    for item in items:
                        raw_cids = item.get("citations") or []
                        if not isinstance(raw_cids, list):
                            dropped += 1
                            continue
                        valid_cids = [
                            cid for cid in raw_cids
                            if isinstance(cid, str) and cid in citation_index
                        ]
                        if not valid_cids:
                            dropped += 1
                            continue
                        # Normalise to the validated subset so downstream
                        # rendering / evidence aggregation only sees resolvable
                        # ids.
                        item["citations"] = valid_cids
                        grounded_items.append(item)
                    if dropped:
                        self.logger.info(
                            f"{rank_label}: dropped {dropped} ungrounded "
                            f"recommendation item(s) (no valid citation id)"
                        )
                    items = grounded_items
                    if not items:
                        self.logger.info(
                            f"{rank_label}: all recommendation items "
                            f"lacked valid citations — suppressing recommendation"
                        )
                        return []
                # Rebuild the recommendation dict so the description render
                # only reflects items that survived grounding.
                filtered_rec = {
                    "headline": recommendation_obj.get("headline"),
                    "items": items,
                }
                description = self._render_recommendation_description(filtered_rec)
            else:
                self.logger.info(f"No policy-driven recommendation for {rank_label}")
                return []

            if not description:
                self.logger.info(
                    f"{rank_label}: LLM returned no renderable recommendation items"
                )
                return []

            evidence, peer_benchmarking, citation = self._evidence_and_citation_from_items(
                items=items,
                citation_index=citation_index,
                specific_facts=specific_facts,
                has_citations=has_citations,
            )

            structured_rec = {
                "rank": 1,
                "priority": "MEDIUM",
                "category": "Policy",
                "description": description,
                "evidence": evidence,
                "story_alignment": [],
                "peer_benchmarking": peer_benchmarking,
                "citation": citation,
                # Transient — consumed by `validate_recommendation_node` and
                # popped before the API response is built. Keys are prefixed
                # with an underscore as a convention; `extract_result` does
                # not look at them.
                "_items": items,
            }

            self.logger.info(f"Generated recommendation for {rank_label}")
            return [structured_rec]

        except (json.JSONDecodeError, KeyError) as e:
            self.logger.warning(
                f"Failed to parse recommendation for {rank_label}: {e}"
            )
            return []
        except Exception as e:
            self.logger.error(
                f"Unexpected error generating recommendation for {rank_label}: {e}"
            )
            return []

    def _collect_payer_edit_rule_facts(
        self,
        policies_by_payer: Dict[str, List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        """
        Build the per-payer aggregate + cross-payer peer benchmarks + per-fact
        citation index the recommendation prompt consumes.

        Args:
            policies_by_payer: Mapping of payer name -> list of policy_entry dicts
                (each already carrying `edit_rule_facts` from format_output_node,
                with `results` still attached for safe fallback aggregation).

        Returns:
            {
              "per_payer": {<payer>: {<key>: [...], ...}, ...},
              "peer_benchmarks": [
                {"fact_key": "utilization_limits", "fact": "10 hrs/week BCBA",
                 "payers": ["UHC", "Humana"], "citation_ids": ["C7", "C12"]},
                ...
              ],
              "citations": [
                {"id": "C1", "payer": "United Health",
                 "policy_title": "Outpatient Hospital Observation Policy, Facility",
                 "policy_url": "https://...",
                 "fact_key": "revenue_codes", "fact": "0762"},
                ...
              ]
            }

            peer_benchmarks contains only facts that appear under ≥2 payers,
            sorted by payer-count descending so the LLM sees the strongest
            cross-payer signals first.

            `citations` is the authoritative grounding list: every entry binds
            a verbatim fact to its source payer + policy_title + policy_url.
            The recommendation prompt requires each item to cite ≥1 id from
            this list, so implementation-level rules cannot float without a
            named source.
        """
        per_payer: Dict[str, Dict[str, List[str]]] = {}
        citations: List[Dict[str, Any]] = []
        # (payer, policy_title, fact_key, fact) -> citation id, used so the
        # same fact from the same source is cited under one stable id.
        citation_by_source: Dict[tuple, str] = {}
        # (fact_key, fact) -> list of citation ids, for peer_benchmarks lookup.
        citations_by_fact: Dict[tuple, List[str]] = {}

        for payer_name, policies in (policies_by_payer or {}).items():
            payer_facts: Dict[str, List[str]] = {key: [] for key in self.EDIT_RULE_FACT_KEYS}
            payer_actions: List[str] = []
            for policy in policies or []:
                if policy is None:
                    continue
                policy_title = policy.get("policy_title") or "Unknown Policy"
                policy_url = policy.get("policy_url") or ""
                # Prefer the pre-aggregated edit_rule_facts on the policy entry;
                # fall back to recomputing from `results` if missing (defensive).
                facts = policy.get("edit_rule_facts")
                if not facts:
                    facts = self._aggregate_edit_rule_facts(policy.get("results", []))
                for key in self.EDIT_RULE_FACT_KEYS:
                    for value in facts.get(key, []) or []:
                        if not isinstance(value, str):
                            continue
                        cleaned = value.strip()
                        if not cleaned:
                            continue
                        if cleaned not in payer_facts[key]:
                            payer_facts[key].append(cleaned)
                        source_key = (payer_name, policy_title, key, cleaned)
                        if source_key not in citation_by_source:
                            cid = f"C{len(citations) + 1}"
                            citation_by_source[source_key] = cid
                            citations.append({
                                "id": cid,
                                "payer": payer_name,
                                "policy_title": policy_title,
                                "policy_url": policy_url,
                                "fact_key": key,
                                "fact": cleaned,
                            })
                            citations_by_fact.setdefault((key, cleaned), []).append(cid)
                for action in facts.get("action_types", []) or []:
                    if action and action not in payer_actions:
                        payer_actions.append(action)
            payer_facts["action_types"] = payer_actions
            per_payer[payer_name] = payer_facts

        # Pivot to peer benchmarks: each distinct (fact_key, fact) -> list of payers.
        index: Dict[tuple, List[str]] = {}
        for payer_name, facts in per_payer.items():
            for key in self.EDIT_RULE_FACT_KEYS:
                for value in facts.get(key, []):
                    bucket = index.setdefault((key, value), [])
                    if payer_name not in bucket:
                        bucket.append(payer_name)

        peer_benchmarks: List[Dict[str, Any]] = []
        for (fact_key, fact), payers in index.items():
            if len(payers) >= 2:
                peer_benchmarks.append({
                    "fact_key": fact_key,
                    "fact": fact,
                    "payers": sorted(payers),
                    "citation_ids": list(citations_by_fact.get((fact_key, fact), [])),
                })
        peer_benchmarks.sort(key=lambda b: (-len(b["payers"]), b["fact_key"], b["fact"]))

        return {
            "per_payer": per_payer,
            "peer_benchmarks": peer_benchmarks,
            "citations": citations,
        }

    def _aggregate_edit_rule_facts(
        self,
        policy_results: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Aggregate one policy's rule results into a flat de-duplicated dict
        of edit-rule fact arrays. Preserves first-seen order for stable output.

        Args:
            policy_results: The `results` list from one PolicyExtractionResponse
                (each item ~ PolicyRuleResult.model_dump()).

        Returns:
            Dict with one List[str] per EDIT_RULE_FACT_KEYS key (always present,
            possibly empty) plus an `action_types` aggregate for visibility.
        """
        facts: Dict[str, List[str]] = {key: [] for key in self.EDIT_RULE_FACT_KEYS}
        action_types: List[str] = []

        for rule in policy_results or []:
            if not isinstance(rule, dict):
                continue
            for key in self.EDIT_RULE_FACT_KEYS:
                values = rule.get(key) or []
                if not isinstance(values, list):
                    continue
                for value in values:
                    if not isinstance(value, str):
                        continue
                    cleaned = value.strip()
                    if cleaned and cleaned not in facts[key]:
                        facts[key].append(cleaned)
            action = rule.get("action_type")
            if isinstance(action, str):
                cleaned = action.strip()
                if cleaned and cleaned not in action_types:
                    action_types.append(cleaned)

        facts["action_types"] = action_types
        return facts

    def _evidence_and_citation_from_items(
        self,
        items: List[Dict[str, Any]],
        citation_index: Dict[str, Dict[str, Any]],
        specific_facts: Optional[Dict[str, Any]],
        has_citations: bool,
    ) -> tuple[List[str], List[str], List[str]]:
        """
        Build (evidence, peer_benchmarking, citation) lists from the given
        recommendation items. Used by `_generate_policy_recommendations` and
        re-used by `validate_recommendation_node` after pruning so the chips
        only reflect surviving items' citations.

        Args:
            items: Items that survived grounding / validation.
            citation_index: id -> source-record map from
                `_collect_payer_edit_rule_facts.citations`.
            specific_facts: Original facts payload — used only for the
                no-citation-index fallback (back-compat with legacy callers).
            has_citations: Whether the citation index was populated for this
                recommendation. When False, falls back to the legacy
                exemptions/scope-based evidence aggregation.

        Returns:
            (evidence, peer_benchmarking, citation) — three List[str] surfaces
            for the recommendation dict.
        """
        # Resolve each item's citation ids to the underlying source records,
        # then surface them as the recommendation's `evidence` (grounding)
        # and `citation` (per-policy URL list). `peer_benchmarking` keeps
        # the LLM-provided peer_cite prose for legibility in the UI.
        resolved_citations: List[Dict[str, Any]] = []
        seen_cids: set = set()
        for item in items:
            for cid in (item.get("citations") or []):
                if cid in seen_cids:
                    continue
                src = citation_index.get(cid)
                if not src:
                    continue
                seen_cids.add(cid)
                resolved_citations.append(src)

        evidence: List[str] = []
        for src in resolved_citations:
            line = (
                f'{src["payer"]} · {src["policy_title"]}: '
                f'"{src["fact"]}" [{src["fact_key"]}]'
            )
            if line not in evidence:
                evidence.append(line)

        peer_benchmarking: List[str] = []
        for item in items:
            peer = item.get("peer_cite")
            if isinstance(peer, str) and peer.strip() and peer not in peer_benchmarking:
                peer_benchmarking.append(peer.strip())

        # Citation: one entry per unique source policy, with URL when
        # available so the UI can render clickable references.
        citation: List[str] = []
        seen_policies: set = set()
        for src in resolved_citations:
            key = (src["payer"], src["policy_title"])
            if key in seen_policies:
                continue
            seen_policies.add(key)
            url = src.get("policy_url") or "(no URL)"
            citation.append(
                f'{src["payer"]} · {src["policy_title"]} — {url}'
            )

        # Fallback for the no-citation-index path (defensive — shouldn't
        # happen when has_citations is True). Preserves prior behaviour
        # so legacy callers without specific_facts still get something.
        if not has_citations:
            for item in items:
                for code in (item.get("exemptions") or []):
                    if isinstance(code, str) and code.strip() and code not in evidence:
                        evidence.append(code.strip())
                for scope in (item.get("scope") or []):
                    if isinstance(scope, str) and scope.strip() and scope not in evidence:
                        evidence.append(scope.strip())
            if specific_facts and not citation:
                for entry in (specific_facts.get("peer_benchmarks") or [])[:5]:
                    fact = entry.get("fact")
                    payers = entry.get("payers") or []
                    if fact and payers:
                        citation.append(f"{fact} — {', '.join(payers)}")

        return evidence, peer_benchmarking, citation

    def _format_facts_for_prompt(
        self,
        specific_facts: Optional[Dict[str, Any]]
    ) -> tuple[str, str, str]:
        """
        Render the structured per-payer facts, peer-benchmark facts, and
        per-fact citation index into three prompt blocks. Returns ('', '', '')
        when nothing to show, so the prompt can include the blocks
        unconditionally without leaving empty headers.

        The citation block is the authoritative grounding list — every
        recommendation item must cite ≥1 id from it (enforced by the parse
        step in `_generate_policy_recommendations`).
        """
        if not specific_facts:
            return "", "", ""

        per_payer = specific_facts.get("per_payer") or {}
        peer_benchmarks = specific_facts.get("peer_benchmarks") or []
        citations = specific_facts.get("citations") or []

        per_payer_lines: List[str] = []
        for payer_name in sorted(per_payer.keys()):
            facts = per_payer[payer_name] or {}
            kept = [(k, v) for k, v in facts.items() if v]
            if not kept:
                continue
            per_payer_lines.append(f"- {payer_name}:")
            for key, values in kept:
                rendered = ", ".join(values[:10])
                per_payer_lines.append(f"    {key}: {rendered}")

        per_payer_block = (
            "Specific facts per payer (cite verbatim — codes, modifiers, "
            "revenue codes, thresholds, limits, exemptions):\n"
            + "\n".join(per_payer_lines)
            if per_payer_lines else ""
        )

        peer_lines: List[str] = []
        for entry in peer_benchmarks[:20]:
            fact = entry.get("fact")
            payers = entry.get("payers") or []
            key = entry.get("fact_key")
            cids = entry.get("citation_ids") or []
            if fact and payers:
                cid_suffix = f" — citations: {', '.join(cids)}" if cids else ""
                peer_lines.append(
                    f"- [{key}] {fact} — payers: {', '.join(payers)}{cid_suffix}"
                )

        peer_block = (
            "Peer benchmark facts (shared by ≥2 payers — useful for 'UHC and "
            "Humana cap at 10 hrs/week' style cites):\n"
            + "\n".join(peer_lines)
            if peer_lines else ""
        )

        citation_lines: List[str] = []
        for entry in citations:
            cid = entry.get("id")
            payer = entry.get("payer")
            policy_title = entry.get("policy_title")
            fact_key = entry.get("fact_key")
            fact = entry.get("fact")
            if not (cid and payer and fact_key and fact):
                continue
            citation_lines.append(
                f"[{cid}] {payer} · \"{policy_title}\" → {fact_key}: \"{fact}\""
            )

        citation_block = (
            "Available citations (grounding for the recommendation — each "
            "items[].citations entry MUST be one of these ids):\n"
            + "\n".join(citation_lines)
            if citation_lines else ""
        )

        return per_payer_block, peer_block, citation_block

    def _render_recommendation_description(
        self,
        recommendation: Dict[str, Any]
    ) -> str:
        """
        Render the structured recommendation object the LLM returns into the
        final multi-line `description` string. Picks Style A (Recommendation <n>: edit-rule)
        or Style B (headline + IA lines) per item.kind.
        """
        headline = (recommendation.get("headline") or "").strip()
        items = recommendation.get("items") or []

        edit_items: List[Dict[str, Any]] = []
        ia_items: List[Dict[str, Any]] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            kind = (item.get("kind") or "").strip().lower()
            if kind == "edit":
                edit_items.append(item)
            else:
                ia_items.append(item)

        lines: List[str] = []

        # Style A — edit-rule blocks numbered Recommendation 1/Recommendation 2/...
        for idx, item in enumerate(edit_items, start=1):
            text = (item.get("text") or "").strip()
            if not text:
                continue
            line = f"Recommendation {idx}: {text}"
            scope = [s for s in (item.get("scope") or []) if s]
            if scope:
                line += f" Apply to {', '.join(scope)}."
            exemptions = [e for e in (item.get("exemptions") or []) if e]
            if exemptions:
                line += f" Exempt: {', '.join(exemptions)}."
            peer = (item.get("peer_cite") or "").strip()
            if peer:
                line += f" Peer: {peer}."
            lines.append(line)
            lines.append("")

        # Style B — headline + IA bullets
        if ia_items:
            if headline and not lines:
                lines.append(headline)
            elif headline and lines:
                # Mixed output: keep headline before IA section
                lines.append("")
                lines.append(headline)
            for item in ia_items:
                text = (item.get("text") or "").strip()
                if not text:
                    continue
                line = f"IA — {text}"
                scope = [s for s in (item.get("scope") or []) if s]
                if scope:
                    line += f" ({', '.join(scope)})"
                peer = (item.get("peer_cite") or "").strip()
                if peer:
                    line += f" {peer}."
                exemptions = [e for e in (item.get("exemptions") or []) if e]
                if exemptions:
                    line += f" Exempt: {', '.join(exemptions)}."
                lines.append(line)

        # Fallback: only headline, no items.
        if not lines and headline:
            lines.append(headline)

        return "\n".join(lines).strip()

    def _run_recommendation_validator(
        self,
        items: List[Dict[str, Any]],
        citation_index: Dict[str, Dict[str, Any]],
        individual_policies: List[Dict[str, Any]],
        pattern: Dict[str, Any],
        user_query: Optional[str],
        summary_table_subtitle: str,
        llm: Any,
    ) -> Dict[str, Any]:
        """
        Run the pattern/scope critique LLM call. Returns a dict
        `{verdicts: [{item_index, decision, reason}, ...], summary: "..."}`
        — one verdict per input item, in the same order.

        Two drop criteria (balanced threshold):
          1. The item's scenario is outside the pattern's scope.
          2. The cited source policy's own evidence summary indicates the
             policy is off-topic for the pattern (e.g. an anesthesia
             policy cited for an OB bundling rule). Note: a policy that
             adjudicates the topic via CPT codes / global packages while
             not naming a specific DRG label is NOT a topic disclaim —
             see prompt for the carve-out.

        Other items must be `keep` — the validator must not drop items
        merely because it would word them differently.

        Returns an empty-verdicts dict on parse failure so the caller can
        fall back to the unfiltered recommendation rather than swallow it.
        """
        if not items:
            return {"verdicts": [], "summary": "no items to validate"}

        cleaned_query = self._clean_user_query(user_query)
        user_question_block = (
            f"User question:\n{cleaned_query}\n\n" if cleaned_query else ""
        )

        # Build the pattern context block.
        pattern_title = (
            pattern.get("top_pattern")
            or pattern.get("pattern_title")
            or f"Pattern {pattern.get('pattern_rank', '')}"
        )
        pattern_evidence = (
            pattern.get("evidence_summary")
            or pattern.get("pattern_details")
            or pattern.get("why_it_matters")
            or ""
        )
        priority_entities = pattern.get("priority_entities") or {}
        states = priority_entities.get("states") or []
        states_block = ", ".join(states) if states else "(none specified)"
        pattern_block = (
            f"Pattern:\n"
            f"- Title: {pattern_title}\n"
            f"- States in scope: {states_block}\n"
            f"- LOB / Subtitle: {summary_table_subtitle or '(none)'}\n"
            f"- Pattern evidence: {pattern_evidence}\n"
        )

        # Look up each cited policy's per-policy evidence summary so the
        # validator sees disclaimer phrases like "referenced only in
        # policy-history language" — the T4-catching signal.
        policy_summary_by_key: Dict[tuple, str] = {}
        for p in individual_policies or []:
            key = (p.get("payer_name") or "", p.get("policy_title") or "")
            summary = p.get("evidence") or ""
            if summary:
                policy_summary_by_key[key] = summary

        items_block_lines: List[str] = []
        for idx, item in enumerate(items):
            text = (item.get("text") or "").strip()
            kind = (item.get("kind") or "").strip()
            scope = item.get("scope") or []
            peer = item.get("peer_cite") or ""
            cids = item.get("citations") or []
            items_block_lines.append(f"Item {idx}:")
            items_block_lines.append(f"  kind: {kind}")
            items_block_lines.append(f"  text: {text}")
            items_block_lines.append(
                f"  scope: {', '.join(scope) if scope else '(none)'}"
            )
            items_block_lines.append(f"  peer_cite: {peer or '(none)'}")
            items_block_lines.append("  citations:")
            for cid in cids:
                src = citation_index.get(cid)
                if not src:
                    items_block_lines.append(f"    [{cid}] (unknown id)")
                    continue
                policy_summary = policy_summary_by_key.get(
                    (src["payer"], src["policy_title"]),
                    "(no policy-level summary available)",
                )
                items_block_lines.append(
                    f'    [{cid}] {src["payer"]} · "{src["policy_title"]}" → '
                    f'{src["fact_key"]}: "{src["fact"]}"'
                )
                items_block_lines.append(
                    f"          source policy summary: {policy_summary}"
                )
        items_block = "\n".join(items_block_lines)

        prompt = textwrap.dedent(f"""
            You are reviewing draft reimbursement-policy recommendation items for fit with the user's pattern and the cited sources.

            {user_question_block}{pattern_block}
            Items to review:
            {items_block}

            Decide `keep` or `drop` for each item by item_index. Mark an item `drop` ONLY when one of the following is clearly true:

            1. SCOPE DRIFT — The item's scenario is outside the pattern's scope.
                Example: an item about preventive-medicine pairing in a pattern that
                is about an ED visit gap. The cited fact may be real but the
                scenario doesn't apply to this pattern.

            2. SOURCE DISCLAIMS TOPIC — At least one cited source's "source policy
                summary" indicates the policy does NOT adjudicate the clinical area
                at all. Examples: an Anesthesia Professional Services policy cited
                for an OB bundling rule, a generic "Add-on Coding" guide cited for a
                modifier-22 documentation rule, a Readmission policy cited for an ED
                denial rule.

                IMPORTANT carve-out: a policy that adjudicates the topic via CPT
                codes / global packages / modifiers — while not explicitly naming
                the pattern's DRG label — is NOT a topic disclaim. For DRG-driven
                patterns (e.g. cesarean delivery), professional OB policies using
                CPT-based global maternity logic, multiple-birth modifier rules,
                and assistant-at-surgery rules are LEGITIMATE grounding even if
                their summary says "does not reference the DRG code." Keep those
                items.

            Otherwise keep the item. Do NOT drop items merely because they are
            aggressive, you would word them differently, or you cannot verify them
            without external lookup. Default to `keep` when uncertain.

            Return JSON only, no markdown:
            {{
            "verdicts": [
                {{"item_index": 0, "decision": "keep" | "drop", "reason": "1 short sentence"}},
                ...
            ],
            "summary": "1-sentence overview of what was dropped and why, or 'all items aligned with pattern'"
            }}
            """)

        messages = [
            {"role": "system", "content": "You are a healthcare reimbursement policy reviewer. Output ONLY valid JSON."},
            {"role": "user", "content": prompt},
        ]

        try:
            response = self._invoke_llm_with_retry(llm, messages, schema="validate_recommendation")
            self._record_tokens("validate_recommendation", response)
            content = response.content.strip()
            if content.startswith("```"):
                lines = content.split("\n")
                if len(lines) > 2:
                    content = "\n".join(lines[1:-1])
            data = json.loads(content)
        except (json.JSONDecodeError, AttributeError, KeyError) as e:
            self.logger.warning(f"Validator response parse failed: {e}")
            return {"verdicts": [], "summary": f"validator parse failure: {e}"}
        except Exception as e:
            self.logger.error(f"Unexpected validator error: {e}")
            return {"verdicts": [], "summary": f"validator error: {e}"}

        verdicts_raw = data.get("verdicts") or []
        verdicts: List[Dict[str, Any]] = []
        for v in verdicts_raw:
            if not isinstance(v, dict):
                continue
            idx = v.get("item_index")
            decision = (v.get("decision") or "").strip().lower()
            if not isinstance(idx, int) or decision not in ("keep", "drop"):
                continue
            if idx < 0 or idx >= len(items):
                continue
            verdicts.append({
                "item_index": idx,
                "decision": decision,
                "reason": (v.get("reason") or "").strip(),
            })

        return {"verdicts": verdicts, "summary": (data.get("summary") or "").strip()}

    def _compact_summary_table(
        self,
        summary_table: Dict[str, Any],
        max_rows: int = 12,
        max_cell_chars: int = 120
    ) -> str:
        """
        Convert summary table to compact text representation for LLM (from notebook).

        Args:
            summary_table: Full summary table structure
            max_rows: Maximum rows to include
            max_cell_chars: Max characters per cell

        Returns:
            Compact JSON string with column labels and truncated values
        """
        columns = summary_table.get("columns", [])
        rows = summary_table.get("rows", [])

        if not columns or not rows:
            return json.dumps({"columns": [], "rows": []})

        # Build column labels mapping
        col_labels = {col["id"]: col.get("label", col["id"]) for col in columns}

        # Build compact rows (limit to first max_rows payers)
        compact_rows = []
        for row in rows[:max_rows]:
            compact_row = {}
            for col in columns:
                col_id = col["id"]
                value = row.get(col_id, "-")
                if value is None or value == "":
                    value = "-"
                if isinstance(value, str) and len(value) > max_cell_chars:
                    value = value[:max_cell_chars] + "..."
                compact_row[col_labels[col_id]] = value
            compact_rows.append(compact_row)

        # Format as JSON for LLM
        compact_data = {
            "columns": [col_labels[c["id"]] for c in columns],
            "rows": compact_rows
        }

        return json.dumps(compact_data, indent=2)

    # ========================================================================
    # Elevance Executive Summary Helpers (from notebook)
    # ========================================================================

    def _extract_elevance_policies(self, pattern_policies: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter to policies from Elevance (internal or external).

        Skips both failed extractions (None) and quarantined policies so
        the Elevance executive summary cannot be built from contaminated
        evidence (e.g. an Elevance policy whose extracted text actually
        names Cigna).
        """
        elevance_policies = []
        for policy in pattern_policies:
            # Skip None policies (failed extractions)
            if policy is None:
                continue
            # Skip quarantined policies — same rationale as everywhere
            # else: contaminated extractions must not seed downstream
            # outputs visible to the user.
            contamination = policy.get("contamination") if isinstance(policy, dict) else None
            if contamination and contamination.get("severity") == "quarantine":
                continue
            payer = (policy.get("PAYOR_NM") or policy.get("payer_name") or policy.get("payor", "")).lower()
            if "elevance" in payer:
                elevance_policies.append(policy)
        return elevance_policies

    def _build_elevance_evidence(self, policies: List[Dict[str, Any]], max_rules: int = 12) -> str:
        """Extract key rule evidence from Elevance policies."""
        fields = [
            "bundling_logic",
            "denial_conditions",
            "code_interactions",
            "site_of_service",
            "authorization_requirements",
            "documentation_requirements",
            "limitations",
            "exclusions",
            "payor_level_summary",
            "specific_rule_text",
        ]
        lines: List[str] = []
        for policy in policies:
            # Skip None policies (failed extractions)
            if policy is None:
                continue
            # Accept either the raw extract dict (key="policy_metadata") or the
            # formatted individual_policies dict (key="metadata"). The two
            # callers pass different shapes; this normalization lets the same
            # function work for both without per-caller branching.
            metadata = policy.get("metadata") or policy.get("policy_metadata") or {}
            policy_title = (
                policy.get("policy_title")
                or metadata.get("policy_title")
                or metadata.get("policy_scope")
                or policy.get("policy_id")
                or policy.get("PLCY_ID", "Policy")
            )
            eff_date = (
                policy.get("effective_date")
                or metadata.get("effective_date")
                or "N/A"
            )
            lines.append(f"Policy: {policy_title} (Effective: {eff_date})")

            for rule in policy.get("results", []) or []:
                for field in fields:
                    value = (rule.get(field) or "").strip()
                    if value:
                        lines.append(f"- {field}: {value}")

        evidence_text = "\n".join(lines[:max_rules])
        # Trim to max 4000 chars for prompt safety
        return evidence_text if len(evidence_text) <= 4000 else evidence_text[:4000] + "..."

    def _generate_elevance_executive_summary(
        self,
        pattern: Optional[Dict[str, Any]],
        pattern_rank: Optional[int],
        drg_codes: List[str],
        keyword: List[str],
        pattern_policies: List[Dict[str, Any]],
        llm: Any,
        user_query: Optional[str] = None
    ) -> Optional[str]:
        """
        Generate a short executive summary ONLY when Elevance policy evidence plausibly explains the pattern.
        Returns None if not explainable or no Elevance policy evidence is available.

        From notebook logic.
        """
        elevance_policies = self._extract_elevance_policies(pattern_policies)
        if not elevance_policies:
            rank_label = f"Pattern {pattern_rank}" if pattern_rank is not None else "Query"
            self.logger.info(f"{rank_label}: No Elevance policies found")
            return None

        evidence = self._build_elevance_evidence(elevance_policies)
        if not evidence.strip():
            rank_label = f"Pattern {pattern_rank}" if pattern_rank is not None else "Query"
            self.logger.info(f"{rank_label}: No relevant Elevance evidence found")
            return None

        pattern_context = self._build_pattern_context(pattern, drg_codes, keyword)

        # Optional user-question framing — included only when the query carries
        # specific intent (generic stubs are filtered out by _clean_user_query).
        cleaned_query = self._clean_user_query(user_query)
        user_question_block = (
            f"\nUser question (frame the summary to address this if relevant):\n{cleaned_query}\n"
            if cleaned_query else ""
        )

        # Adapt prompt based on whether we have pattern context or not
        if pattern is not None:
            context_intro = "You are writing an executive summary explaining whether an Elevance reimbursement policy plausibly explains a cost anomaly pattern."
            explainability_rule = "1) Only mark \"explainable\" = true if the evidence supports a reimbursement rule or restriction that could potentially explain the pattern."
        else:
            context_intro = "You are writing an executive summary of Elevance reimbursement policies relevant to the requested codes and keywords."
            explainability_rule = "1) Mark \"explainable\" = true if the evidence contains relevant reimbursement rules or restrictions for the requested codes/keywords."

        prompt = textwrap.dedent(f"""
            {context_intro}

            Pattern context:
            {pattern_context}
            {user_question_block}
            Elevance policy evidence:
            {evidence}

            STRICT RULES:
            {explainability_rule}
            2) If explainable = false, summary MUST be null.
            3) Summary must be 1-3 sentences, executive tone, no speculation, no uncertainty language.
            4) If a user question is provided above, orient the summary toward it — but never assert anything not supported by the Elevance policy evidence.

            Output JSON ONLY:
            {{"explainable": true|false, "summary": "..." or null}}
            """)

        messages = [
            {"role": "system", "content": "You are a reimbursement policy analyst. Output ONLY valid JSON."},
            {"role": "user", "content": prompt},
        ]

        try:
            response = self._invoke_llm_with_retry(llm, messages, schema="elevance_summary")
            self._record_tokens("elevance_summary", response)
            content = response.content.strip()

            # Remove markdown code fences if present
            if content.startswith("```"):
                lines = content.split("\n")
                if len(lines) > 2:
                    content = "\n".join(lines[1:-1])

            data = json.loads(content)
            validated = ElevanceSummaryResponse(**data)

            rank_label = f"Pattern {pattern_rank}" if pattern_rank is not None else "Query"
            self.logger.info(f"{rank_label}: Elevance explainable={validated.explainable}")
            if validated.explainable and validated.summary:
                self.logger.info(f"{rank_label}: {validated.summary}")
                return validated.summary.strip()
            return None
        except (json.JSONDecodeError, ValidationError, ValueError) as exc:
            rank_label = f"Pattern {pattern_rank}" if pattern_rank is not None else "Query"
            self.logger.warning(f"Elevance summary parse failed for {rank_label}: {exc}")
            return None

    def _extract_pattern_result(self, graph_output: Dict[str, Any]) -> Dict[str, Any]:
        """Build the standard pattern/pipeline result envelope from graph state.

        Shared by pattern/legacy mode (``extract_result``) and top-K mode
        (``_extract_topk_result`` calls this, then layers the ranking + taxonomy
        trail on top). Returns the orchestrator-compliant envelope, or a compact
        dict in direct mode (no ``conversation_id``).
        """
        # Extract pattern information.
        # Resolution order: pattern.pattern_title → pattern.top_pattern →
        # pattern.title → summary_table.subtitle. Only fall back to
        # "Unknown Pattern" when no source provides a real title; the
        # subtitle fallback closes a regression where the table read
        # "California cesarean delivery spend..." but the explanation
        # block still said "Unknown Pattern".
        pattern_rank = graph_output.get("pattern_rank")
        pattern = graph_output.get("pattern", {}) or {}
        formatted_output = graph_output.get("formatted_output", {}) or {}
        summary_table = formatted_output.get("summary_table")
        subtitle_fallback = (summary_table or {}).get("subtitle") if isinstance(summary_table, dict) else None
        pattern_title = self._resolve_pattern_title(pattern)
        # Subtitle is only available post-format_output; when the pattern
        # itself carries no title, fall back to the rendered table subtitle
        # so the explanation block stays in sync with the summary table.
        if pattern_title == "Unknown Pattern" and subtitle_fallback:
            pattern_title = subtitle_fallback

        # Extract results
        policies = graph_output.get("result", [])
        reimbursement_policies = formatted_output.get("individual_policies", [])
        recommended_action = graph_output.get("recommended_action", [])  # List of structured recs

        # Calculate statistics
        total_policies = len(policies)
        successful = sum(1 for p in policies if p is not None)
        failed = total_policies - successful

        # Extract CPT/DRG codes processed
        cpt_codes = graph_output.get("cpt_codes", "")
        drg_codes = graph_output.get("drg_codes", [])
        codes_list = [c.strip() for c in cpt_codes.split(",") if c.strip()] if cpt_codes else []

        # Extract Elevance Executive Summary (generated in recommendation node)
        # Note: This is generated during generate_recommendation_node, not here
        elevance_executive_summary = graph_output.get("elevance_executive_summary")

        # Build explanation
        explanation = {
            "summary": f"Processed reimbursement policies for pattern {pattern_rank}: {pattern_title}",
            "pattern_rank": pattern_rank,
            "pattern_title": pattern_title,
            "cpt_codes_requested": codes_list,
            "drg_codes_requested": drg_codes,
            "total_policies_found": total_policies,
            "successful_extractions": successful,
            "failed_extractions": failed,
            "recommendations_generated": len(recommended_action) if recommended_action else 0,
            "extraction_method": "LLM-based structured extraction from policy text",
            "data_sources": [
                "Carelon Policy Comparison API",
                "Snowflake Policy Database (environment-aware table registry)"
            ]
        }

        # Build validation (standard format: checks as list, not dict)
        checks = []
        if total_policies > 0:
            checks.append({"check": "policies_found", "passed": True, "message": f"Found {total_policies} policies"})
        else:
            checks.append({"check": "policies_found", "passed": False, "message": "No policies found"})

        if successful > 0:
            checks.append({"check": "extractions_successful", "passed": True, "message": f"{successful} successful extractions"})
        else:
            checks.append({"check": "extractions_successful", "passed": False, "message": "All extractions failed"})

        if pattern_rank is not None:
            checks.append({"check": "pattern_identified", "passed": True, "message": f"Pattern {pattern_rank} identified"})
        else:
            checks.append({"check": "pattern_identified", "passed": False, "message": "Pattern rank not identified"})

        # Report each declared downstream filter's attestation. Present only on
        # a segmented run whose analysis mode declares
        # `pattern_segmentation.downstream_filters`, so an unsegmented run's
        # validation block is unchanged. A failed check is not an error: it says
        # the policy search stayed deliberately broad because the pattern's
        # evidence only partly attested the filter value.
        scope_filter_status = graph_output.get("scope_filter_status") or {}
        for filter_name, spec in sorted((scope_filter_status.get("filters") or {}).items()):
            values = spec.get("values") or []
            if spec.get("attested"):
                message = (
                    f"{filter_name} filter applied as {values} - attested by all "
                    f"{spec.get('cards_total', 0)} source card(s)"
                )
            else:
                scope_note = ", ".join(scope_filter_status.get("segment_values") or []) or "none"
                message = (
                    f"{filter_name} filter suppressed: {spec.get('cards_missing', 0)} of "
                    f"{spec.get('cards_total', 0)} source card(s) attest no {filter_name} "
                    f"(segment scope: {scope_note}); searched without it rather than "
                    f"narrowing to {values}"
                )
            checks.append({
                "check": f"{filter_name}_filter_attested",
                "passed": bool(spec.get("attested")),
                "message": message,
            })

        # Surface the recommendation validator verdict in the existing
        # validation block. `validate_recommendation_node` always emits a
        # decision; `skipped` means no recommendation was produced upstream
        # and we don't add a noisy check for it.
        rec_validation = graph_output.get("recommendation_validation") or {}
        rec_decision = rec_validation.get("decision")
        if rec_decision in ("ok", "items_dropped", "suppressed"):
            checks.append({
                "check": "recommendation_pattern_aligned",
                "passed": rec_decision != "suppressed",
                "message": rec_validation.get("summary", ""),
            })

        # Surface policy-level contamination from validate_policies_node.
        # The aggregate `policy_contamination_summary` carries the per-policy
        # severity decisions; per-policy `contamination` blocks ride along
        # on reimbursement_policies entries automatically.
        contamination_summary = graph_output.get("policy_contamination_summary") or {}
        quarantined_list = contamination_summary.get("quarantined") or []
        warned_list = contamination_summary.get("warned") or []
        contamination_total = contamination_summary.get("total_extracted") or successful

        cross_payer_hits = [
            q for q in (quarantined_list + warned_list)
            if "cross_payer_name_leak" in (q.get("flags") or [])
        ]
        checks.append({
            "check": "cross_payer_contamination_detected",
            "passed": not cross_payer_hits,
            "message": (
                f"{len(cross_payer_hits)} policy/ies leak another payer's name in evidence"
                if cross_payer_hits else "no cross-payer name leakage detected"
            ),
        })

        if contamination_total > 0:
            quarantine_rate = len(quarantined_list) / contamination_total
            relevance_passed = quarantine_rate < 0.3
            checks.append({
                "check": "policy_relevance_pass_rate",
                "passed": relevance_passed,
                "message": (
                    f"{len(quarantined_list)}/{contamination_total} policies quarantined "
                    f"({quarantine_rate:.0%}); threshold 30%"
                ),
            })

            # When more than half the extracted policies carry warn-level
            # contamination flags, the run is technically successful but
            # the source pool is suspect — flip is_valid to
            # "valid_with_warnings" so consumers surface the caveat.
            warning_rate = len(warned_list) / contamination_total
            warning_passed = warning_rate < 0.5
            checks.append({
                "check": "policy_warning_rate",
                "passed": warning_passed,
                "message": (
                    f"{len(warned_list)}/{contamination_total} policies warning-flagged "
                    f"({warning_rate:.0%}); threshold 50%"
                ),
            })

        # is_valid carries three states:
        #   - False (bool): no policies extracted successfully — the agent
        #     produced nothing trustworthy.
        #   - "valid_with_warnings" (str): extractions succeeded but at
        #     least one critical check failed (cross-payer leak, low
        #     relevance pass rate, recommendation suppressed, etc.).
        #     Consumers should surface the failed checks before acting.
        #   - True (bool): every check passed.
        if successful == 0:
            is_valid: Any = False
        elif any(not c["passed"] for c in checks):
            is_valid = "valid_with_warnings"
        else:
            is_valid = True

        validation = {
            "is_valid": is_valid,
            "checks": checks,
            "warnings": [],
            "errors": []
        }

        def _format_policy_pairs(entries: List[Dict[str, Any]]) -> str:
            pairs = []
            for e in entries:
                pid = e.get("policy_id") or "?"
                title = e.get("title") or "(no title)"
                pairs.append(f"{pid}:{title}")
            return ", ".join(pairs)

        if quarantined_list:
            validation["warnings"].append(
                f"{len(quarantined_list)} policy/ies quarantined for contamination "
                f"(excluded from peer benchmarks and summary-table summarization): "
                f"[{_format_policy_pairs(quarantined_list)}]. See per-policy "
                f"`contamination` field on reimbursement_policies for flags + reasons."
            )
        if warned_list:
            validation["warnings"].append(
                f"{len(warned_list)} policy/ies flagged with contamination warnings "
                f"(kept in output): [{_format_policy_pairs(warned_list)}]."
            )

        rec_dropped = rec_validation.get("dropped_count", 0)
        if rec_dropped:
            validation["warnings"].append(
                f"Validator dropped {rec_dropped} recommendation item(s) for "
                f"scope drift or source-disclaimed citations. "
                f"See recommendation_validation in graph state for per-item reasons."
            )

        if failed > 0:
            validation["warnings"].append(
                f"{failed} out of {total_policies} policies failed extraction. "
                f"Check logs for details."
            )

        if successful == 0:
            validation["errors"].append(
                "No policies were successfully extracted. All LLM extractions failed."
            )

        if pattern_rank is None:
            validation["warnings"].append(
                "Pattern rank not identified. This may indicate missing pattern context."
            )

        # Check if conversation_id was provided (orchestrator mode)
        conversation_id = graph_output.get("conversation_id")
        job_id = graph_output.get("job_id", uuid.uuid4().hex)

        # Calculate execution time
        start_time = graph_output.get("start_time")
        end_time = datetime.now(timezone.utc).isoformat()

        # Build tokens info from per-LLM-call bookkeeping accumulated during this run.
        # Each category corresponds to one of the agent's LLM call sites:
        #   - extract_rules:          per-policy rule extraction (extract_rules_node, gpt-5.4-nano)
        #   - dynamic_columns:        pattern-aware column selection (analyze_table_structure_node)
        #   - cell_summarization:     per-cell payer summary (format_output_node)
        #   - elevance_summary:       Elevance executive summary (generate_recommendation_node)
        #   - policy_recommendations: final policy recommendation (generate_recommendation_node)
        breakdown = self._token_breakdown
        total_input = sum(entry.get("input", 0) for entry in breakdown.values())
        total_output = sum(entry.get("output", 0) for entry in breakdown.values())
        tokens = {
            "input": total_input,
            "output": total_output,
            "breakdown": breakdown
        }

        # Build execution info (standard format: duration_ms in milliseconds)
        duration_seconds = self._calculate_duration(start_time, end_time)
        execution = {
            "start_time": start_time,
            "end_time": end_time,
            "duration_ms": int(duration_seconds * 1000),  # Convert to milliseconds
            "version": "2.0.0"  # Updated for single-pattern processing
        }

        # Determine status using standard values: success | partial_success | failed
        if successful == total_policies and total_policies > 0:
            status = "success"
        elif successful > 0:
            status = "partial_success"
        else:
            status = "failed"

        # Build orchestrator-compliant output (standard format across all agents)
        orchestrator_output = {
            "job_id": job_id,
            "conversation_id": conversation_id,
            "agent": "reimbursement_policy",
            "status": status,
            "output": {
                "pattern_rank": pattern_rank,
                "summary_table": summary_table,
                "reimbursement_policies": reimbursement_policies,
                "elevance_executive_summary": elevance_executive_summary,
                "policies_processed": total_policies,
                "policies_successful": successful,
                "policies_failed": failed
            },
            "recommended_action": recommended_action,
            "visual_component": {},  # Reserved for future visualizations
            "explanation": explanation,
            "validation": validation,
            "tokens": tokens,
            "execution": execution
        }

        # If conversation_id is None, we're in direct mode - return formatted output with recommendations
        if conversation_id is None:
            return {
                "summary_table": summary_table,
                "reimbursement_policies": reimbursement_policies,
                "elevance_executive_summary": elevance_executive_summary,
                "recommended_action": recommended_action
            }

        return orchestrator_output

    def _extract_topk_result(self, graph_output: Dict[str, Any]) -> Dict[str, Any]:
        """Top-K-mode result envelope.

        Top-K mode chains the ranking nodes into the shared extraction pipeline
        (ranked taxonomies -> mapped policies -> extraction -> recommendation),
        so the envelope is the standard pipeline envelope built by
        ``_extract_pattern_result`` with the ranking + taxonomy trail layered on:
        ``output.topk`` (the ranking payload), ``output.taxonomy_codes`` and
        ``output.taxonomy_policies`` (the taxonomy->policy mapping trail), and the
        ranking diagnostics inside ``explanation`` (with ``explanation.mode ==
        "topk"``). In direct mode (no ``conversation_id``) the same trail is
        attached to the pattern path's compact dict.
        """
        base = self._extract_pattern_result(graph_output)

        topk = graph_output.get("topk_result", {}) or {}
        taxonomy_codes = graph_output.get("taxonomy_codes", []) or []
        taxonomy_policies = graph_output.get("taxonomy_policies", []) or []
        run_dir = topk.get("run_dir")
        row_count = topk.get("row_count")

        trail = {
            "topk": topk,
            "taxonomy_codes": taxonomy_codes,
            "taxonomy_policies": taxonomy_policies,
        }

        # Direct mode: _extract_pattern_result returns a compact dict (no
        # orchestrator envelope). Attach the ranking + taxonomy trail alongside.
        if not isinstance(base, dict) or "output" not in base:
            compact: Dict[str, Any] = dict(base) if isinstance(base, dict) else {"result": base}
            compact.update(trail)
            return compact

        base["output"].update(trail)

        explanation = base.get("explanation")
        if isinstance(explanation, dict):
            explanation["mode"] = "topk"
            explanation["dimension"] = topk.get("dimension")
            explanation["metric"] = topk.get("metric")
            explanation["top_k"] = topk.get("top_k")
            explanation["yaml_path"] = topk.get("yaml_path")
            explanation["returned_rows"] = row_count
            explanation["has_filters"] = topk.get("has_filters")
            explanation["truncated"] = topk.get("truncated")
            explanation["taxonomy_codes_found"] = len(taxonomy_codes)
            explanation["taxonomy_policies_mapped"] = len(taxonomy_policies)
            # Ranking query + summary may be persisted; result rows never are.
            explanation["persisted"] = {"queries": run_dir is not None, "rows": False}
            explanation["run_dir"] = run_dir

        # Surface the ranking outcome as its own validation check alongside the
        # extraction checks so a 0-row ranking is visible even when the pipeline
        # tail produced nothing to validate. The pattern-oriented
        # `pattern_identified` check / "Pattern rank not identified" warning are
        # meaningless in top-K mode (there is no pattern) — drop them so the
        # envelope does not misleadingly flag the run as missing pattern context,
        # then recompute is_valid over the remaining top-K-relevant checks.
        validation = base.get("validation")
        if isinstance(validation, dict):
            rows_found = bool(row_count)
            checks = [
                c for c in validation.get("checks", [])
                if c.get("check") != "pattern_identified"
            ]
            checks.insert(0, {
                "check": "topk_rows_found",
                "passed": rows_found,
                "message": f"{row_count} ranked row(s)",
            })
            validation["checks"] = checks

            validation["warnings"] = [
                w for w in validation.get("warnings", [])
                if "Pattern rank not identified" not in w
            ]
            if not rows_found:
                validation["warnings"].append("Top-K query returned 0 rows.")

            successful = (base.get("output") or {}).get("policies_successful") or 0
            if not rows_found or successful == 0:
                validation["is_valid"] = False
            elif any(not c.get("passed") for c in checks):
                validation["is_valid"] = "valid_with_warnings"
            else:
                validation["is_valid"] = True

        return base

    def _calculate_duration(self, start_time: Optional[str], end_time: str) -> float:
        """
        Calculate duration in seconds between start and end times.

        Args:
            start_time: ISO timestamp string
            end_time: ISO timestamp string

        Returns:
            Duration in seconds
        """
        if not start_time:
            return 0.0

        try:
            start = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
            end = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
            return (end - start).total_seconds()
        except Exception:
            return 0.0

    def _validate_topk_params(
        self,
        semantic_model: Dict[str, Any],
        catalog: Optional[SemanticCatalog],
        *,
        dimension: str,
        metric: str,
        top_k: int,
        filters: Any = None,
    ) -> None:
        """Validate top-K request params against the model BEFORE the graph runs.

        Delegates to :func:`build_topk_query_sql` (which performs the full
        resolution — dimension exists, metric resolves, single-table, top_k >= 1,
        filter fields resolve) and re-raises its ``ValueError`` as a clear
        ``AgentConfigurationError``, so a bad request fails fast here rather than
        surfacing as a bare ``ValueError`` from inside the build node. Reusing the
        real builder keeps validation and construction from ever drifting apart.
        """
        try:
            build_topk_query_sql(
                semantic_model,
                dimension=dimension,
                metric=metric,
                top_k=top_k,
                filters=filters,
                catalog=catalog,
            )
        except ValueError as exc:
            raise AgentConfigurationError(str(exc)) from exc

    # ========================================================================
    # Table Formatting & Summarization
    # ========================================================================

    def _aggregate_rule_texts(
        self,
        payer_policies: List[Dict[str, Any]],
        categories: List[str]
    ) -> List[str]:
        """Collect unique rule texts for the payer across selected categories."""
        texts: List[str] = []
        for policy in payer_policies:
            if policy is None:
                continue
            for rule in policy.get("results", []) or []:
                for cat in categories:
                    value = (rule.get(cat) or "").strip()
                    if value and value not in texts:
                        texts.append(value)
        return texts

    def _summarize_column_value(
        self,
        payer_name: str,
        column_label: str,
        rule_texts: List[str],
        column_type: str,
        llm: Any
    ) -> str:
        """
        Summarize payer rule texts into a compact cell value using LLM (from notebook).
        """
        if not rule_texts:
            return "-"

        sample_text = "\n".join(f"- {text[:300]}" for text in rule_texts[:5])

        if column_type == "badge":
            prompt = textwrap.dedent(f"""
                Summarize payer behavior into a short badge (<=3 words) for column: {column_label}.
                If the payer clearly has a rule, use a concise label (e.g., "Bundles", "Denies", "Requires Auth").
                If unclear, return "-".
                Payer: {payer_name}
                Rules:
                {sample_text}
                Output ONLY the badge text.""")
        else:
            prompt = textwrap.dedent(f"""
                Summarize payer behavior into ONE concise sentence (<=15 words) for column: {column_label}.
                Payer: {payer_name}
                Rules:
                {sample_text}
                Output ONLY the summary text.""")

        messages = [
            {"role": "system", "content": "You are a concise policy summarizer. Output only the requested text."},
            {"role": "user", "content": prompt},
        ]

        try:
            response = self._invoke_llm_with_retry(llm, messages, schema="cell_summarization")
            self._record_tokens("cell_summarization", response)
            return response.content.strip() or "-"
        except Exception as exc:
            self.logger.warning(f"Summarization failed for {payer_name}/{column_label}: {exc}")
            fallback = rule_texts[0][:120]
            return fallback + ("..." if len(rule_texts[0]) > 120 else "")

    # ========================================================================
    # Helper Methods
    # ========================================================================

    def _parse_date(self, date_str: str) -> tuple[str, Optional[datetime]]:
        """Parse date string into datetime; return original string and parsed datetime if possible."""
        date_formats = (
            "%m/%d/%Y",
            "%Y-%m-%d",
            "%m/%d/%y",
            "%Y/%m/%d",
            "%b %d, %Y",
            "%B %d, %Y",
        )

        if not date_str:
            return "N/A", None
        for fmt in date_formats:
            try:
                return date_str, datetime.strptime(date_str, fmt)
            except ValueError:
                continue
        return date_str, None

    def _latest_effective_date(self, payer_policies: List[Dict[str, Any]]) -> str:
        """Pick the most recent effective date across payer policies."""
        dates: List[tuple[str, Optional[datetime]]] = []
        for policy in payer_policies:
            if policy is None:
                continue
            effective_date = policy.get("policy_metadata", {}).get("effective_date")
            raw, parsed = self._parse_date(effective_date or "")
            if raw != "N/A":
                dates.append((raw, parsed))
        if not dates:
            return "N/A"
        parsed_dates = [d for d in dates if d[1] is not None]
        if parsed_dates:
            return max(parsed_dates, key=lambda x: x[1] or datetime.min)[0]
        return dates[0][0]

    def _handle_validation_error(
        self,
        error: ValidationError,
        context: str
    ) -> None:
        """
        Log validation errors with structured information.

        Args:
            error: Pydantic ValidationError
            context: Context description (e.g., "policy extraction")
        """
        self.logger.error(f"Validation error in {context}:")
        for err in error.errors():
            field = " -> ".join(str(loc) for loc in err['loc'])
            self.logger.error(f"  Field: {field}")
            self.logger.error(f"  Error: {err['msg']}")
            self.logger.error(f"  Input: {err.get('input', 'N/A')}")

    def _extract_policy_rules(
        self,
        policy_text: str,
        pattern_details: str,
        llm: Any
    ) -> Dict[str, Any]:
        """
        Extract structured rules from a single policy using LLM with Pydantic validation.

        Uses pattern details (DRG codes, CPT codes, pattern context) from notebook approach.

        Args:
            policy_text: Full policy text
            pattern_details: Pattern context including DRG/CPT codes and pattern title
            llm: LLM client

        Returns:
            Dictionary with 'policy_metadata' and 'results' keys

        Raises:
            json.JSONDecodeError: If LLM response is not valid JSON
            ValidationError: If response doesn't match Pydantic schema
        """
        user_prompt = USER_PROMPT_TEMPLATE.format(
            policy_text=policy_text,
            pattern_details=pattern_details
        )

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]

        response = self._invoke_llm_with_retry(llm, messages, schema="extract_rules")
        self._record_tokens("extract_rules", response)

        # Parse and validate with Pydantic
        try:
            content = response.content.strip()

            # Remove markdown code fences if present
            if content.startswith("```"):
                lines = content.split("\n")
                # Remove first and last line (code fences)
                if len(lines) > 2:
                    # Also remove language identifier if present (e.g., ```json)
                    content = "\n".join(lines[1:-1])

            # Parse JSON
            data = json.loads(content)

            # Coerce string values to lists for list fields (LLM sometimes returns strings)
            if "results" in data and isinstance(data["results"], list):
                for result in data["results"]:
                    if isinstance(result, dict):
                        for field in self.EDIT_RULE_FACT_KEYS:
                            if field in result and isinstance(result[field], str):
                                result[field] = [result[field]] if result[field].strip() else []

            # Validate with Pydantic
            validated = PolicyExtractionResponse(**data)

            # Return as dictionary
            return validated.model_dump()

        except json.JSONDecodeError as e:
            self.logger.error(f"JSON parsing error in policy extraction: {e}")
            self.logger.error(f"Raw response: {response.content[:500]}...")
            raise
        except ValidationError as e:
            self._handle_validation_error(e, "policy extraction")
            raise

    # Structured edit-rule fact keys (List[str] in PolicyRuleResult). These
    # power the specific-recommendation path: aggregated per-policy into
    # `edit_rule_facts` on each reimbursement_policies entry, and pivoted
    # across payers into peer benchmarks for the recommendation prompt.
    EDIT_RULE_FACT_KEYS = [
        "target_codes",
        "related_codes",
        "required_modifiers",
        "excluded_modifiers",
        "revenue_codes",
        "pairing_conditions",
        "utilization_limits",
        "prior_auth_thresholds",
        "discharge_status_conditions",
        "program_scope",
        "state_specific_rules",
        "provider_role_restrictions",
        "exemptions",
    ]

    @classmethod
    def _resolve_extract_concurrency(cls) -> int:
        """Read REIMBURSEMENT_EXTRACT_CONCURRENCY env var if set, else fall
        back to the per-env default keyed off AppConstants.ENV. Always
        returns >= 1 so callers can pass it straight to ThreadPoolExecutor."""
        # Per-environment concurrency caps for LLM-heavy nodes (extract_rules
        # + the relevance judge). Sized against ~12K tokens/call on
        # gpt-5.4-nano against each env's tier limits:
        #   prod=8  → 3M TPM / 100 RPM tier: ~80 RPM, ~1M TPM (well under both)
        #   dev=3   → shared-quota safe
        #   uat=3   → shared-quota safe
        #   local=1 → 30 RPM / 100K TPM tier: TPM is binding (12K/call × 8.3 =
        #             ~100K TPM ceiling), so a single worker is the only safe
        #             setting. Going higher will trip 429s.
        # Override at runtime with REIMBURSEMENT_EXTRACT_CONCURRENCY=<int>.

        extract_concurrency_by_env: Dict[str, int] = {
            "dev": 3, "uat": 3, "prod": 8, "local": 8,
        }
        override = os.environ.get("REIMBURSEMENT_EXTRACT_CONCURRENCY")
        if override:
            try:
                return max(1, int(override))
            except ValueError:
                pass
        return extract_concurrency_by_env.get(AppConstants.ENV, 3)

    def _appeals_badge(self, payer_policies: List[Dict[str, Any]]) -> str:
        """Return X if any policy documents appeals, else '-'."""
        documented = any(
            policy.get("policy_metadata", {}).get("appeals_process_documented") or
            policy.get("policy_metadata", {}).get("specialty_specific")
            for policy in payer_policies
            if policy is not None
        )
        return "X" if documented else "-"

    # ========================================================================
    # Phase 1b: Post-extraction sanitization
    # ========================================================================
    #
    # The extraction LLM (gpt-5.4-nano with reasoning_effort=low) is known
    # to copy the prompt's "DRG Codes:" header back into target_codes when
    # the policy text has no real codes to extract — a classic prompt-leak
    # pattern. It also sometimes substitutes a competing payer's name in
    # the prose evidence. The new prompt guardrails attack this upstream
    # (see USER_PROMPT_TEMPLATE), but we still sanitize the output as a
    # belt-and-suspenders pass so any miss is logged and stripped before
    # the data reaches the validation node or downstream consumers.
    #
    # Sanitizer drops are logged at WARNING with policy_id + policy_title +
    # field + dropped value + reason, so reviewers can trace every change.

    def _sanitize_field_values(
        self,
        policy_id: Optional[str],
        policy_title: Optional[str],
        field: str,
        values: List[Any],
        pattern: "re.Pattern[str]",
    ) -> List[str]:
        """Filter one structured list field against a regex whitelist,
        dropping prompt-leak strings unconditionally. Logs every drop.
        
        For modifier fields (required_modifiers, excluded_modifiers),
        normalizes values by stripping 'Modifier ' prefix, leading hyphens,
        and uppercasing (e.g. 'Modifier D' → 'D', '-H' → 'H', 'gt' → 'GT').
        """
        kept: List[str] = []
        is_modifier_field = field in ("required_modifiers", "excluded_modifiers")
        
        for raw in values or []:
            if not isinstance(raw, str):
                self.logger.warning(
                    f"Sanitizer dropped {field}={raw!r} from "
                    f"policy_id={policy_id} title={policy_title!r}: not a string"
                )
                continue
            cleaned = raw.strip()
            if not cleaned:
                continue
            if PolicyContaminationChecker._looks_like_prompt_leak(cleaned):
                self.logger.warning(
                    f"Sanitizer dropped {field}={cleaned!r} from "
                    f"policy_id={policy_id} title={policy_title!r}: prompt-header leak"
                )
                continue
            
            # For modifier fields, pre-normalize before validation:
            # Strip "Modifier " prefix (LLM sometimes extracts "Modifier D" instead of "D"),
            # strip leading hyphen (CMS ambulance notation), and uppercase.
            candidate = cleaned
            if is_modifier_field:
                # Strip case-insensitive "Modifier " prefix if present
                if candidate.lower().startswith("modifier "):
                    candidate = candidate[9:].strip()  # len("Modifier ") = 9
                # Strip leading hyphen and uppercase
                candidate = candidate.lstrip("-").upper()
            
            if not pattern.match(candidate):
                self.logger.warning(
                    f"Sanitizer dropped {field}={cleaned!r} from "
                    f"policy_id={policy_id} title={policy_title!r}: failed {field} format check"
                )
                continue
            
            # Store the normalized form for modifier fields, original for others
            if is_modifier_field:
                kept.append(candidate)
            else:
                kept.append(cleaned)
        return kept

    def _sanitize_extracted_facts(
        self,
        policy_id: Optional[str],
        policy_title: Optional[str],
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Belt-and-suspenders cleanup of LLM-extracted facts. Mutates and
        returns `payload`. For every rule in payload["results"]:

          - target_codes / related_codes are filtered against code_regex:
            * CPT/DRG single codes (3-5 digits, optional alpha suffix: 99284, 469, 99284T)
            * HCPCS single codes (letter + 4 digits: G0378, A0427)
            * ICD-10 single codes (letter + 2+ digits: O30.001, C50.911)
            * Code ranges (99210-99220, A0426-A0428, C50.0-C50.9)
          - required_modifiers / excluded_modifiers are filtered against _MODIFIER_RE:
            * Standard 1-3 alphanumeric chars (25, 59, XU)
            * "Modifier " prefix (Modifier D, Modifier E) — normalized to D, E
            * CMS ambulance notation with leading hyphen (-H, -I, -X) — normalized to H, I, X
            * Case-insensitive (gt/GT both accepted, normalized to GT)
          - revenue_codes are filtered against revenue_code_regex:
            * 3-5 digit codes with optional X or digit suffix (0762, 045X, 068X)
            * Revenue code ranges (0450-0459)

        Every drop is logged at WARNING with policy_id + title for traceability.
        Modifier values are normalized ("Modifier " prefix stripped, leading hyphen stripped, uppercased).
        Returns payload unchanged if it isn't a dict (defensive — extract_rules
        catches LLM failures upstream).
        """
        
        # Field-level regex whitelists for sanitization.
        # CPT: 3-5 digits (includes DRGs), optional trailing letter (e.g. 99284, 99284T, 469).
        # HCPCS: 1 letter + 4 digits (e.g. G0378, A0427).
        # ICD-10 diagnosis: letter + 2 digits + optional ".dddd" + optional
        # trailing "-" (e.g. O30.001, Z37.50-, C50.911). Universally clinical
        # (OB uses O/Z codes, oncology uses C/D, cardiology uses I, etc.)
        # Ranges: Policies often specify code ranges (e.g. 99210-99220, A0426-A0428,
        # C50.0-C50.9). These are kept verbatim as single tokens.
        code_regex = re.compile(
            r"^\d{3,5}[A-Z]?$"                                    # CPT/DRG single (3-5 digits, optional alpha suffix)
            r"|^[A-Z]\d{4}$"                                       # HCPCS Level II single (e.g. G0378)
            r"|^[A-Z]\d{2}(\.\d{1,4})?-?$"                        # ICD-10 single (e.g. O30.001, Z37.50-, C50)
            r"|^\d{3,5}[A-Z]?-\d{3,5}[A-Z]?$"                    # CPT/DRG range (e.g. 99210-99220, 469-470)
            r"|^[A-Z]\d{4}-[A-Z]\d{4}$"                           # HCPCS range (e.g. A0426-A0428)
            r"|^[A-Z]\d{2}(\.\d{1,4})?-[A-Z]\d{2}(\.\d{1,4})?$"  # ICD-10 range (e.g. C50.0-C50.9)
        )
        # Modifiers: 1-3 chars (digits or letters). Accept optional leading hyphen
        # for CMS ambulance origin/destination notation (e.g. -H, -I, -X).
        # The leading hyphen is stripped during normalization in _sanitize_field_values.
        modifier_regex = re.compile(r"^-?[A-Z0-9]{1,3}$", re.IGNORECASE)
        # Revenue codes: 3-5 digits with optional X wildcard or digit suffix (e.g. 0762, 045X, 068X).
        # Also accepts ranges (e.g. 0450-0459) for bundling rules.
        revenue_code_regex = re.compile(
            r"^\d{3,5}[X0-9]?$"          # single code: 3-5 digits with optional X/digit suffix
            r"|^\d{2,4}X$"               # X-wildcard: e.g. 045X, 068X, 76X
            r"|^\d{3,5}-\d{3,5}$"        # range: e.g. 0450-0459, 762-769
        )

        if not isinstance(payload, dict):
            return payload
        rules = payload.get("results")
        if not isinstance(rules, list):
            return payload

        field_patterns: List[tuple] = [
            ("target_codes", code_regex),
            ("related_codes", code_regex),
            ("required_modifiers", modifier_regex),
            ("excluded_modifiers", modifier_regex),
            ("revenue_codes", revenue_code_regex),
        ]

        for rule in rules:
            if not isinstance(rule, dict):
                continue
            for field, pattern in field_patterns:
                values = rule.get(field)
                if not isinstance(values, list):
                    continue
                rule[field] = self._sanitize_field_values(
                    policy_id, policy_title, field, values, pattern
                )

        return payload

    def _collect_category_samples(
        self,
        policies: List[Dict[str, Any]],
        max_samples: int = 3
    ) -> Dict[str, List[str]]:
        """Collect distinct sample snippets for each rule category."""
        # Constants for comprehensive summary logic
        rule_categories = [
            "site_of_service",
            "bundling_logic",
            "code_interactions",
            "authorization_requirements",
            "documentation_requirements",
            "limitations",
            "exclusions",
            "mention_status",
            "payor_level_summary",
            "specific_rule_text",
        ]

        samples = {category: [] for category in rule_categories}
        for policy in policies:
            # Skip None policies (failed extractions)
            if policy is None:
                continue
            for rule in policy.get("results", []) or []:
                for category in rule_categories:
                    value = (rule.get(category) or "").strip()
                    if value and value not in samples[category]:
                        samples[category].append(value)
        return {k: v[:max_samples] for k, v in samples.items() if v}

    def _clean_user_query(self, user_query: Optional[str]) -> Optional[str]:
        """
        Normalize a user query for use as an LLM steering signal.

        Returns the stripped query when it carries specific intent, or None when
        it's empty, whitespace, or a known generic stub (e.g. "Analyze the spike").
        Callers should fall back to existing behavior when this returns None.
        """
        # Generic user queries that carry no useful intent signal. When the query
        # matches one of these (case-insensitive, after stripping), helpers treat it
        # as if no query were provided and fall back to pattern/DRG context alone.

        generic_user_queries = frozenset({
            "",
            "analyze the spike",
            "why did costs increase?",
            "why did costs increase",
            "analyze this",
            "what happened?",
            "what happened",
        })
        if not user_query or not isinstance(user_query, str):
            return None
        cleaned = user_query.strip()
        if not cleaned:
            return None
        if cleaned.lower() in generic_user_queries:
            return None
        return cleaned

    def _build_pattern_context(
        self,
        pattern: Dict[str, Any] | None,
        drg_codes: List[str],
        keyword: List[str]
    ) -> str:
        """Build a concise pattern context string for the LLM."""
        # Top-K mode chains into this shared pipeline node without a pattern
        # (prepare_state seeds pattern=None), so guard against a missing dict.
        pattern = pattern or {}
        title = pattern.get("top_pattern") or pattern.get("pattern_title") or f"Pattern {pattern.get('pattern_rank', '')}"
        details = pattern.get("pattern_details", "")
        drg_preview = json.dumps(drg_codes[:5]) + ("..." if len(drg_codes) > 5 else "")
        keyword_str = ', '.join(keyword) if keyword else 'N/A'
        return (
            f"Pattern title: {title}\n"
            f"Keywords: {keyword_str}\n"
            f"DRG codes: {drg_preview}\n"
            f"Details: {details}"
        )

    def _generate_dynamic_columns(
        self,
        pattern_context: str,
        category_samples: Dict[str, List[str]],
        llm: Any,
        user_query: Optional[str] = None
    ) -> TableSchemaResponse:
        """
        Ask the LLM to pick 1-2 dynamic columns relevant to the pattern (from notebook).
        """
        if not category_samples:
            return TableSchemaResponse(columns=[], selected_categories=[])

        samples_text = "\n".join(
            f"- {cat}: {(' | '.join(vals))[:350]}"
            for cat, vals in category_samples.items()
        )

        # Optional user-question framing — included only when the query carries
        # specific intent (generic stubs are filtered out by _clean_user_query).
        cleaned_query = self._clean_user_query(user_query)
        user_question_block = (
            f"\nUser question (lean toward categories that help answer this, if supporting samples exist):\n{cleaned_query}\n"
            if cleaned_query else ""
        )

        prompt = textwrap.dedent(f"""
            You are designing a payer policy summary table for a specific pattern.

            Pattern context:
            {pattern_context}
            {user_question_block}
            Available rule categories with samples:
            {samples_text}

            Task:
            Select the 1-2 most informative columns to compare payer behavior for this pattern.
            Each column should map to 1-2 underlying categories from the list above.

            Output JSON ONLY with this schema:
            {{
            "columns": [
                {{"id": "snake_case_id", "label": "Short Label (<=6 words)", "type": "text|badge"}}
            ],
            "selected_categories": [
                {{"id": "snake_case_id", "categories": ["category1", "category2"]}}
            ]
            }}

            Rules:
            - Use "badge" when the output is a short flag/value (<=3 words, e.g., "Bundles", "Denies", "Requires Auth").
            - Use "text" when a brief sentence is needed.
            - Do NOT include payer or effective date columns; those are added separately.
            - If a user question is provided above and emphasizes a specific category (e.g., denials, bundling, authorization, modifiers), prefer columns covering that category — but only when the available samples support it.
            """)

        messages = [
            {"role": "system", "content": "You are a healthcare reimbursement analyst. Output ONLY valid JSON."},
            {"role": "user", "content": prompt},
        ]

        try:
            response = self._invoke_llm_with_retry(llm, messages, schema="dynamic_columns")
            self._record_tokens("dynamic_columns", response)
            content = response.content.strip()

            # Remove markdown code fences if present
            if content.startswith("```"):
                lines = content.split("\n")
                if len(lines) > 2:
                    content = "\n".join(lines[1:-1])

            data = json.loads(content)
            return TableSchemaResponse(**data)
        except (json.JSONDecodeError, ValidationError, ValueError) as exc:
            self.logger.warning(f"Column generation failed, using fallback. Error: {exc}")
            return TableSchemaResponse(columns=[], selected_categories=[])

    # ========================================================================
    # Token Tracking Helpers
    # ========================================================================

    def _extract_token_usage(self, response: Any) -> Dict[str, int]:
        """
        Pull input/output token counts from a LangChain LLM response.

        Handles both new-style (`usage_metadata`) and legacy
        (`response_metadata['token_usage']`) shapes. Returns zeros if neither
        is present so callers never need to guard.
        """
        usage = getattr(response, "usage_metadata", None)
        if usage:
            return {
                "input": int(usage.get("input_tokens") or 0),
                "output": int(usage.get("output_tokens") or 0),
            }
        response_metadata = getattr(response, "response_metadata", None) or {}
        token_usage = response_metadata.get("token_usage") or {}
        return {
            "input": int(token_usage.get("prompt_tokens") or 0),
            "output": int(token_usage.get("completion_tokens") or 0),
        }

    def _record_tokens(self, category: str, response: Any) -> None:
        """Record tokens from one LLM call into the per-category breakdown.
        Thread-safe under worker-pool fan-out (extract_rules / relevance
        judge) via self._token_lock."""
        try:
            tokens = self._extract_token_usage(response)
        except Exception as exc:  # defensive — never let token bookkeeping break a node
            self.logger.debug(f"Token extraction failed for {category}: {exc}")
            return
        lock = getattr(self, "_token_lock", None)
        if lock is None:
            # Old test instances built with __new__ may not have the lock;
            # fall back to lockless update — fine in single-threaded tests.
            lock = threading.Lock()
            self._token_lock = lock
        with lock:
            entry = self._token_breakdown.setdefault(
                category, {"input": 0, "output": 0, "calls": 0}
            )
            entry["input"] += tokens["input"]
            entry["output"] += tokens["output"]
            entry["calls"] += 1

    # ========================================================================
    # Functions/Methods created by devs but not used anywhere (can remove after review)
    # ========================================================================

    # def _collect_rule_categories(self, results: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    #     """
    #     Collect all non-empty rule categories across all policies.

    #     Args:
    #         results: List of policy extraction results

    #     Returns:
    #         Dictionary mapping category names to list of sample values
    #     """
    #     category_samples = {
    #         "site_of_service": [],
    #         "bundling_logic": [],
    #         "code_interactions": [],
    #         "modifier_usage": [],
    #         "denial_conditions": [],
    #         "unit_pricing_logic": [],
    #         "documentation_requirements": [],
    #         "evidence_summary": []
    #     }

    #     for policy_result in results:
    #         if policy_result is None:
    #             continue

    #         policy_rules = policy_result.get("results", [])
    #         for rule in policy_rules:
    #             for category in category_samples.keys():
    #                 value = (rule.get(category) or "").strip()
    #                 if value and value not in category_samples[category]:
    #                     category_samples[category].append(value)

    #     # Filter out empty categories
    #     return {k: v for k, v in category_samples.items() if v}

    # def _select_rule_categories(
    #     self,
    #     category_samples: Dict[str, List[str]]
    # ) -> List[Dict[str, Any]]:
    #     """
    #     Select 1-2 most relevant rule categories and combine related ones.

    #     Args:
    #         category_samples: Dictionary of category names to sample values

    #     Returns:
    #         List of category combinations to use as columns
    #     """
    #     # Score categories by variation (more unique values = more informative)
    #     category_scores = {
    #         cat: len(values) for cat, values in category_samples.items()
    #     }

    #     # Predefined category combinations
    #     combinations = {
    #         "denial_summary": ["denial_conditions", "evidence_summary"],
    #         "bundling_rules": ["bundling_logic", "code_interactions"],
    #         "service_restrictions": ["site_of_service", "modifier_usage"],
    #         "documentation_billing": ["documentation_requirements", "unit_pricing_logic"]
    #     }

    #     # Score combinations based on constituent categories
    #     combination_scores = {}
    #     for combo_name, categories in combinations.items():
    #         score = sum(category_scores.get(cat, 0) for cat in categories)
    #         if score > 0:  # Only include if at least one category has data
    #             combination_scores[combo_name] = {
    #                 "score": score,
    #                 "categories": [c for c in categories if c in category_samples]
    #             }

    #     # Select top 1-2 combinations
    #     sorted_combos = sorted(
    #         combination_scores.items(),
    #         key=lambda x: x[1]["score"],
    #         reverse=True
    #     )

    #     selected = []
    #     for combo_name, combo_data in sorted_combos[:2]:  # Max 2 columns
    #         selected.append({
    #             "id": combo_name,
    #             "categories": combo_data["categories"]
    #         })

    #     return selected

    # def _generate_column_labels(
    #     self,
    #     selected_categories: List[Dict[str, Any]],
    #     category_samples: Dict[str, List[str]],
    #     llm: Any
    # ) -> List[Dict[str, str]]:
    #     """
    #     Use LLM to generate concise column labels with Pydantic validation.

    #     Args:
    #         selected_categories: Selected category combinations
    #         category_samples: Sample values for each category
    #         llm: LLM client

    #     Returns:
    #         List of column metadata with id, label, type
    #     """
    #     if not selected_categories:
    #         return []

    #     # Build samples for LLM
    #     samples_text = ""
    #     for cat_combo in selected_categories:
    #         cat_id = cat_combo["id"]
    #         categories = cat_combo["categories"]
    #         samples_text += f"\n{cat_id} (combines: {', '.join(categories)}):\n"
    #         for cat in categories[:2]:  # Show max 2 samples per category
    #             if cat in category_samples and category_samples[cat]:
    #                 samples_text += f"  - {category_samples[cat][0][:80]}...\n"

    #     prompt = textwrap.dedent(f"""
    #         Given these policy rule categories and sample content:
    #         {samples_text}

    #         Generate concise column labels (max 5 words each) for a summary table.
    #         Labels should be clear, professional, and suitable for table headers.

    #         IMPORTANT: Output ONLY valid JSON, no markdown code fences.

    #         Output JSON:
    #         {{
    #         "columns": [
    #             {{"id": "category_id", "label": "Column Label (max 5 words)", "type": "text"}}
    #         ]
    #         }}
    #         """)

    #     messages = [
    #         {"role": "system", "content": SYSTEM_PROMPT},
    #         {"role": "user", "content": prompt}
    #     ]

    #     try:
    #         response = self._invoke_llm_with_retry(llm, messages, schema="column_labels")
    #         content = response.content.strip()

    #         # Remove markdown code fences if present
    #         if content.startswith("```"):
    #             lines = content.split("\n")
    #             if len(lines) > 2:
    #                 content = "\n".join(lines[1:-1])

    #         # Parse JSON
    #         data = json.loads(content)

    #         # Validate with Pydantic
    #         validated = ColumnLabelsResponse(**data)

    #         # Return as list of dicts
    #         return [col.model_dump() for col in validated.columns]

    #     except (json.JSONDecodeError, ValidationError) as e:
    #         if isinstance(e, ValidationError):
    #             self._handle_validation_error(e, "column label generation")
    #         else:
    #             self.logger.warning(f"Failed to parse column labels JSON: {e}")

    #         # Fallback to simple labels
    #         self.logger.info("Using fallback column labels")
    #         return [
    #             {
    #                 "id": cat["id"],
    #                 "label": cat["id"].replace("_", " ").title(),
    #                 "type": "text"
    #             }
    #             for cat in selected_categories
    #         ]

    # def _aggregate_payer_rules(
    #     self,
    #     payer_policies: List[Dict[str, Any]],
    #     category_id: str,
    #     categories: List[str],
    #     llm: Any
    # ) -> str:
    #     """
    #     Aggregate rules for a payer across multiple policies with Pydantic validation.

    #     Args:
    #         payer_policies: List of policies for this payer
    #         category_id: Category combination ID
    #         categories: List of rule categories to aggregate
    #         llm: LLM client

    #     Returns:
    #         Aggregated rule text (max 15 words)
    #     """
    #     # Collect all rule texts for these categories
    #     rule_texts = []
    #     for policy in payer_policies:
    #         if policy is None:
    #             continue
    #         policy_results = policy.get("results", [])
    #         for result in policy_results:
    #             for cat in categories:
    #                 text = result.get(cat, "") or ""  # Handle None values
    #                 text = text.strip() if isinstance(text, str) else ""
    #                 if text and text not in rule_texts:
    #                     rule_texts.append(text)

    #     if not rule_texts:
    #         return "-"

    #     if len(rule_texts) == 1:
    #         return rule_texts[0]

    #     # Multiple rules - use LLM to summarize
    #     payer_name = payer_policies[0].get("payer_name", "Unknown")
    #     rules_list = "\n".join([f"- {text}" for text in rule_texts[:5]])  # Max 5 rules

    #     prompt = textwrap.dedent(f"""
    #         Summarize these policy rules for {payer_name} into ONE concise statement (max 15 words):

    #         {rules_list}

    #         IMPORTANT: Output only the summary text. No JSON, no markdown, just the plain text summary.""")

    #     messages = [
    #         {"role": "system", "content": "You are a concise policy summarizer. Output only the requested summary text."},
    #         {"role": "user", "content": prompt}
    #     ]

    #     try:
    #         response = self._invoke_llm_with_retry(llm, messages, schema="table_schema")
    #         summary_text = response.content.strip()

    #         # Validate with Pydantic (will auto-truncate if needed)
    #         validated = RuleSummary(summary=summary_text)

    #         return validated.summary

    #     except ValidationError as e:
    #         self._handle_validation_error(e, f"rule summarization for {payer_name}")
    #         # Fallback: return first rule (may exceed word limit but at least has content)
    #         return rule_texts[0]
    #     except Exception as e:
    #         self.logger.warning(f"Failed to summarize rules for {payer_name}: {e}")
    #         # Fallback: return first rule
    #         return rule_texts[0]

# ============================================================================
# Policy Contamination Checker
# ============================================================================

class PolicyContaminationChecker:
    """Handles all policy contamination checks and payer identity validation.

    Consolidates cross-payer leak detection, prompt leak detection, policy
    identity mismatch checks, and LLM relevance judge integration.
    """

    # Known payer names used by the cross-payer contamination check.
    # Match is case-insensitive and word-boundary-anchored; any of these
    # names appearing in another payer's evidence is a leak signal.
    KNOWN_PAYERS = [
        "Cigna",
        "Aetna",
        "Humana",
        "United Health",
        "UnitedHealth",
        "UHC",
        "United Healthcare",
        "Elevance",
        "Anthem",
        "Molina",
        "BCBS",
        "Blue Cross",
        "BlueCross",
        "Kaiser",
        "WellCare",
    ]

    # URL-substring → canonical payer key. Used by the policy identity
    # check to confirm policy_url matches payer_name. The first matching
    # substring wins, so order more-specific domains before generic ones.
    _URL_TO_PAYER: List[tuple] = [
        ("uhcprovider.com", "united"),
        ("unitedhealthcare.com", "united"),
        ("uhc.com", "united"),
        ("elevancehealth.com", "elevance"),
        ("anthem.com", "elevance"),
        ("molinahealthcare.com", "molina"),
        ("molina.com", "molina"),
        ("cigna.com", "cigna"),
        ("humana.com", "humana"),
        ("aetna.com", "aetna"),
        ("kaiserpermanente.org", "kaiser"),
        ("kaiser.com", "kaiser"),
        ("wellcare.com", "wellcare"),
        ("bcbs.com", "bcbs"),
    ]

    # Payer-name token → canonical payer key. Substring match against the
    # lowercased payer name from the search API. Order more-specific tokens
    # first so "blue cross" wins over "blue".
    _PAYER_NAME_TO_CANONICAL: List[tuple] = [
        ("blue cross", "bcbs"),
        ("bluecross", "bcbs"),
        ("united health", "united"),
        ("unitedhealth", "united"),
        ("united healthcare", "united"),
        ("elevance", "elevance"),
        ("anthem", "elevance"),
        ("cigna", "cigna"),
        ("humana", "humana"),
        ("molina", "molina"),
        ("aetna", "aetna"),
        ("kaiser", "kaiser"),
        ("wellcare", "wellcare"),
        ("bcbs", "bcbs"),
        ("uhc", "united"),
    ]

    # policy_id prefix → canonical payer key. Used as a soft signal — we
    # only flag a mismatch when the prefix is recognized AND it disagrees
    # with the URL-derived canonical, because Elevance issues policies
    # under many prefix conventions (RP_GBD_*, RP_COM_ELV_EXTERNAL_*).
    _POLICY_ID_PREFIX_TO_PAYER: Dict[str, str] = {
        "CIG": "cigna",
        "UHC": "united",
        "HUM": "humana",
        "ELV": "elevance",
        "MOH": "molina",
    }

    # Prompt-header phrases that occasionally leak into structured fields
    # when the LLM has no real codes to extract. Used by the sanitizer and
    # by the defense-in-depth `drg_prompt_leak_detected` check.
    PROMPT_LEAK_MARKERS = (
        "drg codes:",
        "cpt/hcpcs codes:",
        "cpt codes:",
        "hcpcs codes:",
        "pattern:",
    )

    # ------------------------------------------------------------------
    # Contamination check helpers
    # ------------------------------------------------------------------

    @classmethod
    def _canonicalize_payer(cls, name: str) -> str:
        """Lowercased payer name with common suffixes stripped — used so
        the cross-payer leak check treats 'Elevance Health (external)' and
        'Elevance' as the same payer when comparing against KNOWN_PAYERS.
        """
        if not name:
            return ""
        lowered = name.lower()
        # Drop parenthetical qualifiers like '(external)' / '(internal)'.
        lowered = re.sub(r"\s*\([^)]*\)\s*", " ", lowered)
        return re.sub(r"\s+", " ", lowered).strip()

    @classmethod
    def _payer_key_from_name(cls, payer: str) -> Optional[str]:
        """Map a payer_name string to a canonical key (e.g. 'cigna', 'united').
        Returns None when the name doesn't match any known payer token."""
        if not payer:
            return None
        lowered = payer.lower()
        for token, canonical in cls._PAYER_NAME_TO_CANONICAL:
            if token in lowered:
                return canonical
        return None

    @classmethod
    def _payer_key_from_url(cls, policy_url: str) -> Optional[str]:
        """Map a policy_url to a canonical payer key based on its domain.
        Returns None when the URL doesn't match any known domain."""
        if not policy_url:
            return None
        lowered = policy_url.lower()
        for domain, canonical in cls._URL_TO_PAYER:
            if domain in lowered:
                return canonical
        return None

    @classmethod
    def _payer_key_from_policy_id(cls, policy_id: str) -> Optional[str]:
        """Map a policy_id like 'RP_COM_CIG_00021' to a canonical payer key
        using the second-or-third underscore-separated token. Returns None
        when no recognized prefix is present (Elevance often falls here —
        e.g. 'RP_GBD_*' or 'RP_COM_ELV_EXTERNAL_*' — so a None here
        means 'no constraint', not 'mismatch')."""
        if not policy_id:
            return None
        upper = policy_id.upper()
        for token in upper.split("_"):
            if token in cls._POLICY_ID_PREFIX_TO_PAYER:
                return cls._POLICY_ID_PREFIX_TO_PAYER[token]
        return None

    @staticmethod
    def _looks_like_prompt_leak(value: str) -> bool:
        """True iff the value contains one of the known prompt-header phrases."""
        lowered = value.lower()
        return any(marker in lowered for marker in PolicyContaminationChecker.PROMPT_LEAK_MARKERS)

    @classmethod
    def check_policy_contamination(
        cls,
        policy_id: Optional[str],
        payer: str,
        title: str,
        evidence: str,
        edit_rule_facts: Dict[str, Any],
        policy_url: str = "",
        judge_verdict: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Run all contamination checks against one policy. Returns None
        when the policy is clean, otherwise a dict
        ``{flags: [...], severity: "quarantine"|"warn", reasons: [...]}``.

        Quarantine wins over warn when both severities trigger on the same
        policy — downstream consumers filter on the worst case.

        All checks here are domain-agnostic:
          - cross_payer_name_leak: canonicalizes both sides so Anthem and
            Elevance are treated as the same payer.
          - drg_prompt_leak_detected: post-sanitizer defense-in-depth.
          - policy_identity_mismatch: payer_name vs URL vs policy_id prefix
            triangulation — catches misattributed records.
          - policy_topic_irrelevant: LLM relevance judge verdict
            (`judge_verdict`). Sole authority on topical relevance —
            replaces the old mention_status-based deterministic disclaim
            check, which fired false-positives on DRG patterns whose
            policies adjudicate via CPT codes.
        """
        flags: List[str] = []
        reasons: List[str] = []
        worst_severity: Optional[str] = None

        def record(flag: str, severity: str, reason: str) -> None:
            nonlocal worst_severity
            if flag not in flags:
                flags.append(flag)
                reasons.append(reason)
            if severity == "quarantine" or worst_severity != "quarantine":
                worst_severity = severity

        # 1. Cross-payer name leakage in evidence text.
        # Canonicalize own payer once so the leak check can compare
        # canonical-vs-canonical (Anthem and Elevance both map to
        # "elevance" — see _PAYER_NAME_TO_CANONICAL — and shouldn't
        # mutually trip the check).
        own_payer_canonical = cls._canonicalize_payer(payer)
        own_payer_key = cls._payer_key_from_name(payer)
        evidence_lower = evidence.lower()
        own_payer_in_evidence = False
        if own_payer_canonical:
            own_tokens = [t for t in own_payer_canonical.split() if len(t) >= 4]
            own_payer_in_evidence = any(
                token in evidence_lower for token in own_tokens
            )
        leaked_payers: List[str] = []
        for other in cls.KNOWN_PAYERS:
            other_canon = cls._canonicalize_payer(other)
            if not other_canon:
                continue
            # Skip if the candidate resolves to the same canonical payer
            # as the owner (Anthem == Elevance). This is the fix that
            # eliminates the Anthem-in-Elevance-policy false positive.
            other_key = cls._payer_key_from_name(other)
            if other_key and own_payer_key and other_key == own_payer_key:
                continue
            if other_canon in own_payer_canonical or own_payer_canonical in other_canon:
                continue
            if re.search(rf"\b{re.escape(other_canon)}\b", evidence_lower):
                leaked_payers.append(other)
        if leaked_payers:
            severity = "quarantine" if not own_payer_in_evidence else "warn"
            record(
                "cross_payer_name_leak",
                severity,
                f"evidence mentions other payer(s) {leaked_payers}; "
                f"own payer {'absent' if not own_payer_in_evidence else 'also mentioned'}",
            )

        # 2. DRG-prompt leak defense-in-depth (post-sanitize, this should
        # be empty; if anything still trips here, the sanitizer regressed).
        leaked_strings: List[str] = []
        for key in ("target_codes", "related_codes"):
            for v in edit_rule_facts.get(key, []) or []:
                if isinstance(v, str) and cls._looks_like_prompt_leak(v):
                    leaked_strings.append(f"{key}={v!r}")
        if leaked_strings:
            record(
                "drg_prompt_leak_detected",
                "quarantine",
                f"prompt-header string(s) survived sanitizer: {leaked_strings}",
            )

        # 3. Hard policy identity check: payer_name, policy_url, and (when
        # recognizable) policy_id prefix must all map to the same canonical
        # payer. A mismatch here means the record is internally inconsistent
        # — the payer label can't be trusted as a source attribution.
        name_payer = cls._payer_key_from_name(payer)
        url_payer = cls._payer_key_from_url(policy_url)
        id_payer = cls._payer_key_from_policy_id(policy_id or "")
        identity_mismatches: List[str] = []
        if name_payer and url_payer and name_payer != url_payer:
            identity_mismatches.append(
                f"payer_name={payer!r} → {name_payer!r} vs policy_url={policy_url!r} → {url_payer!r}"
            )
        if name_payer and id_payer and name_payer != id_payer:
            identity_mismatches.append(
                f"payer_name={payer!r} → {name_payer!r} vs policy_id={policy_id!r} prefix → {id_payer!r}"
            )
        if url_payer and id_payer and url_payer != id_payer:
            identity_mismatches.append(
                f"policy_url={policy_url!r} → {url_payer!r} vs policy_id={policy_id!r} prefix → {id_payer!r}"
            )
        if identity_mismatches:
            record(
                "policy_identity_mismatch",
                "quarantine",
                "; ".join(identity_mismatches),
            )

        # 4. LLM relevance judge verdict. Generalizes to any specialty
        # (OB, oncology, cardiology, etc.) because it inherits the model's
        # medical knowledge.
        # Severity ladder (high-confidence-only quarantine — see below):
        #   relevant=False + confidence == high        → quarantine
        #   relevant=False + confidence in {medium, low, unknown} → warn
        # Only `high` quarantines because the cesarean run on 2026-06-12
        # showed the judge can rate clearly-relevant maternity policies as
        # `confidence=high` not-relevant when the pattern narrative cites
        # specific clinical drivers. Demoting `medium` to warn keeps those
        # borderline cases visible in the API output instead of silently
        # dropping them. On parse failure / missing verdict the policy
        # passes (default keep) so judge hiccups never drop policies.
        if isinstance(judge_verdict, dict) and judge_verdict.get("relevant") is False:
            confidence = (judge_verdict.get("confidence") or "").strip().lower()
            reason = (judge_verdict.get("reason") or "").strip() or "(no reason given)"
            if confidence == "high":
                record(
                    "policy_topic_irrelevant",
                    "quarantine",
                    f"relevance judge: relevant=false confidence={confidence!r}: {reason}",
                )
            else:
                record(
                    "policy_topic_irrelevant",
                    "warn",
                    f"relevance judge: relevant=false confidence={confidence or 'unknown'!r}: {reason}",
                )

        if not flags:
            return None
        return {
            "flags": flags,
            "severity": worst_severity or "warn",
            "reasons": reasons,
        }


# ============================================================================
# Main Agent Builder
# ============================================================================

def build_app(
    snowflake_helper: Optional[Any] = None,
    snowflake_helper_builder: Optional[Callable[[], Any]] = None,
    llm: Optional[Any] = None,
    llm_builder: Optional[Callable[[], Any]] = None,
    **kwargs
) -> ReimbursementPolicyAgent:
    """
    Build reimbursement policy extraction agent.

    Args:
        snowflake_helper: Optional SnowparkHelper instance
        snowflake_helper_builder: Optional callable that returns SnowparkHelper
        llm: Optional pre-configured LLM client
        llm_builder: Optional callable that returns LLM client
        **kwargs: Additional arguments passed to agent

    Returns:
        A ReimbursementPolicyAgent instance (top-K mode)

    Example:
        >>> agent = build_app(snowflake_helper=snowpark)
        >>> results = agent(yaml_path="configs/correlation_pattern/view.yaml")
    """
    agent = ReimbursementPolicyAgent(
        snowflake_helper=snowflake_helper,
        snowflake_helper_builder=snowflake_helper_builder,
        llm=llm,
        llm_builder=llm_builder,
        **kwargs
    )

    return agent
