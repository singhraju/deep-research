"""
Example: Reimbursement Policy Agent API

This example demonstrates how to expose the existing ReimbursementPolicyAgent
as a REST API using the AgentAPIBuilder.
"""

from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field, validator

from deep_research_core import AgentAPIBuilder
from deep_research_agents import ReimbursementAgent


# ============================================================================
# Custom Request Model with Validation
# ============================================================================


class ReimbursementTopKRequest(BaseModel):
    """Top-K request: rank one dimension by a declared metric over a claims view.

    Given a semantic-view ``yaml_path`` and an optional nested AND/OR ``filters``
    tree, build ``SELECT <dimension>, <metric> ... GROUP BY <dimension>
    ORDER BY <metric> DESC LIMIT <top_k>`` and run it. The default ranks provider
    taxonomies (provider specialties) by total paid. Only the query + a JSON
    summary persist; the ranked rows are returned in-memory and never persisted.
    """
    yaml_path: str = Field(
        ...,
        description="Semantic-view YAML that declares the dimension + metrics",
        example="configs/correlation_pattern/coc_ecap_oon_semantic_view_with_samples_local_offshore.yaml",
    )
    dimension: str = Field(
        "provider_taxonomy_type",
        description=(
            "Dimension to rank (group by). Default provider_taxonomy_type "
            "(a.k.a. 'taxonomy' — the provider specialty)."
        ),
        min_length=1,
    )
    metric: str = Field(
        "total_paid",
        description=(
            "Ranking metric — a metric declared in the YAML's metrics: list "
            "(bare name like 'total_paid' or fully-qualified 'expense_detail.total_paid')."
        ),
        min_length=1,
    )
    top_k: int = Field(
        10,
        ge=1,
        le=1000,
        description="Number of top-ranked rows to return (the query's LIMIT).",
    )
    filters: Optional[Union[Dict[str, Any], List[Any]]] = Field(
        None,
        description=(
            "Optional nested AND/OR filter tree narrowing the ranked population. "
            "A leaf is {field, operator, value}; a group is "
            "{logic: AND|OR, conditions: [...]}; a bare list is implicitly ANDed."
        ),
    )
    persist_queries: bool = Field(
        True,
        description=(
            "Persist the built ranking query + a JSON summary to a per-run "
            "directory under output_root. Result rows are never persisted."
        ),
    )
    fetch_competitor_policies: bool = Field(
        False,
        description=(
            "When True, the taxonomy->policy chain hydrates peer payors' "
            "reimbursement policies that share the mapped policies' topics "
            "(via the policy_metadata_topic_comparison table) instead of the "
            "specific mapped policies. Requires that table to be configured in "
            "the environment INI; off by default."
        ),
    )
    output_root: Optional[str] = Field(
        None,
        description="Root dir for per-run query/summary artifacts (default: reimbursement_runs)",
    )
    conversation_id: Optional[str] = Field(
        None,
        description="Optional conversation ID for tracking",
    )
    query: Optional[str] = Field(
        None,
        description="Optional user query for context",
    )
    pattern: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "Optional business-pattern dict used ONLY to enrich the extraction / "
            "judge / recommendation prompts (title, evidence summary, "
            "why-it-matters). It is never parsed for codes; the ranking and all "
            "code/state/LOB signals come solely from `filters`."
        ),
    )

    @validator("dimension", "metric")
    def _non_blank(cls, v):
        """Reject a blank/whitespace-only dimension or metric name."""
        cleaned = str(v).strip()
        if not cleaned:
            raise ValueError("must not be blank")
        return cleaned


# ============================================================================
# Build API
# ============================================================================


def create_app():
    """Create and configure the FastAPI application."""

    # Create API builder
    builder = AgentAPIBuilder(
        title="Reimbursement Policy API",
        version="1.0.0",
        description=(
            "API for ranking a dimension (default: provider taxonomy) by a "
            "declared metric over a semantic-view claims table, then extracting "
            "structured adjudication rules from the top-ranked taxonomies' "
            "reimbursement policies"
        ),
        debug=True,
    )

    # ------------------------------------------------------------------
    # Top-K endpoint (rank a dimension by a declared metric) — the agent's only
    # mode. Builds the ranking query from the request's YAML + filters, then
    # chains the ranked taxonomies into policy hydration + rule extraction. A
    # supplied `pattern` is optional narrative enrichment only.
    topk_agent = ReimbursementAgent(debug=True)

    builder.add_agent(
        topk_agent,
        path="/reimbursement/topk",
        request_model=ReimbursementTopKRequest,
        tags=["reimbursement", "topk-ranking"],
    )

    # Add CORS support
    builder.add_cors(allow_origins=["*"])
    
    # Build and return app
    return builder.build()


# Create app instance
app = create_app()


# ============================================================================
# Usage Instructions
# ============================================================================

if __name__ == "__main__":
    print("""
    Reimbursement Policy Agent API
    ==============================
    
    This API exposes the ReimbursementPolicyAgent for extracting structured
    adjudication rules from insurance reimbursement policies.
    
    Setup:
    ------
    1. Ensure environment variables are configured in .env:
       - SNOWFLAKE_* credentials
       - EHAP_* credentials for LLM access
    
    2. Install dependencies:
       uv sync
    
    3. Run the server (from project root):
       python -m uvicorn reimbursement_api:app --reload --port 8000
       
       Or if deep-research-agents is installed:
       uvicorn deep_research_agents.reimbursement_api:app --reload --port 8000
    
    Usage:
    ------

    # Top-K (the only mode): rank a dimension (default provider_taxonomy_type) by
    # a declared metric (default total_paid) over the semantic YAML's claims view,
    # optionally narrowed by a nested AND/OR filter tree, then chain the ranked
    # taxonomies into policy hydration + rule extraction. Ranked rows are returned
    # in-memory (never persisted). A `pattern` may be supplied for narrative-only
    # enrichment of titles / summaries; it is never parsed for codes.
    curl -X POST http://localhost:8000/reimbursement/topk \\
      -H "Content-Type: application/json" \\
      -d '{
        "yaml_path": "configs/correlation_pattern/coc_ecap_oon_semantic_view_with_samples_local_offshore.yaml",
        "dimension": "provider_taxonomy_type",
        "metric": "total_paid",
        "top_k": 10,
        "filters": {
          "logic": "AND",
          "conditions": [
            {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}
          ]
        },
        "persist_queries": true
      }'

    # Health check
    curl http://localhost:8000/health

    # Metrics
    curl http://localhost:8000/metrics

    Documentation:
    -------------
    Open http://localhost:8000/docs for interactive API documentation

    Features:
    ---------
    - Nested AND/OR filter-tree validation against the semantic view
    - Declared-metric ranking with a single GROUP BY / ORDER BY / LIMIT
    - Chained taxonomy -> policy hydration + LLM rule extraction
    - Metrics tracking per request
    - OpenAPI/Swagger documentation
    """)
