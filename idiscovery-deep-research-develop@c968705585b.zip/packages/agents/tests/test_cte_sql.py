"""Tests for the config-file-driven CTE builder
(:mod:`deep_research_utils.cte_sql`).

The driving case is PMPM: aggregate a claims population and a membership
population in separate CTEs, then join the aggregates and divide to form ratios.
These tests are pure SQL-string / exception assertions — no live Snowflake / LLM.

Coverage:
  * WITH / GROUP BY shape of a single CTE
  * shared filters applied to every CTE; side-specific filters on one CTE only
  * FULL OUTER / LEFT join shapes, COALESCE'd keys, NULLIF + multiplier ratios
  * dual placeholder resolution (physical inside a CTE, CTE-qualified in output)
  * injection rejection (bad identifiers) + filter-value escaping
  * validation errors (unknown source/field, dim-not-on-source, dup CTE names,
    join key not a CTE column, ratio referencing an unknown cte.column)
  * the full 4-CTE PMPM example + build-by-name lookup
  * multi-source CTEs: joins to base tables and prior CTEs, explicit aliases,
    per-side key names, cross-source column comparison
  * expression dimensions (CASE/COALESCE) and group_by alias|expr|none|false
  * correlated EXISTS / NOT EXISTS anti-joins
  * final-SELECT WHERE / GROUP BY / HAVING / ORDER BY / LIMIT / DISTINCT
  * request-filter routing (apply flag, field and table allow/deny) and the
    merge-vs-replace interaction with YAML shared_filters
"""

from __future__ import annotations

import pytest

from deep_research_utils.cte_sql import (
    build_cte_query_sql,
    build_cte_query_sql_by_name,
)


# ==========================================================================
# Fixtures / helpers
# ==========================================================================

def _semantic_model() -> dict:
    """Two-table model. Physical exprs chosen so aliases are deterministic:
    ``expense_detail`` -> ``ed``, ``membership`` -> ``m``.

    ``lob_code`` / ``service_area_state`` / ``snap_month`` / ``incurred_month``
    exist on BOTH tables (so ``resolve_field`` must disambiguate by source);
    ``hcc_high`` / ``admit_count`` are claims-only, ``mbr_status`` is
    membership-only.
    """
    period_dims = [
        {"name": "snap_month", "expr": "SNAP_YM", "data_type": "number"},
        {"name": "incurred_month", "expr": "INCRD_YM", "data_type": "number"},
    ]
    shared_dims = [
        {"name": "lob_code", "expr": "LOB_CD", "data_type": "string"},
        {"name": "service_area_state", "expr": "SRVCAREA_ST", "data_type": "string"},
    ]
    return {
        "name": "test_pmpm_view",
        "tables": [
            {
                "name": "expense_detail",
                "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                "dimensions": shared_dims
                + period_dims
                + [{"name": "hcc_high", "expr": "HCC_HIGH", "data_type": "string"}],
                "facts": [
                    {"name": "paid_amount", "expr": "ANLYTC_PAID_AMT", "data_type": "number"},
                    {"name": "admit_count", "expr": "ADMIT_CNT", "data_type": "number"},
                ],
            },
            {
                "name": "membership",
                "base_table": {"database": "DB", "schema": "SCH", "table": "MBR"},
                "dimensions": shared_dims
                + period_dims
                + [{"name": "mbr_status", "expr": "MBR_STS", "data_type": "string"}],
                "facts": [
                    {"name": "member_count", "expr": "ACTL_MBR_CNT", "data_type": "number"},
                ],
            },
        ],
    }


def _shared_filters() -> dict:
    return {
        "logic": "AND",
        "conditions": [
            {"field": "snap_month", "operator": "=", "value": 202606},
            {"field": "incurred_month", "operator": "between", "value": "202601 and 202605"},
        ],
    }


def _clm_medical() -> dict:
    return {
        "name": "clm_medical",
        "source": "expense_detail",
        "dimensions": ["lob_code", "service_area_state"],
        "measures": [
            {"name": "medical_paid", "expr": "SUM({expense_detail.paid_amount})"},
            {"name": "admits", "expr": "SUM({expense_detail.admit_count})"},
        ],
        "filters": {"logic": "AND", "conditions": [
            {"field": "hcc_high", "operator": "=", "value": "Medical"},
        ]},
    }


def _medical_mm() -> dict:
    return {
        "name": "medical_mm",
        "source": "membership",
        "dimensions": ["lob_code", "service_area_state"],
        "measures": [{"name": "member_months", "expr": "SUM({membership.member_count})"}],
    }


def _pmpm_query() -> dict:
    """Two-CTE PMPM: claims (medical) vs membership member-months."""
    return {
        "name": "pmpm_by_lob_state",
        "shared_filters": _shared_filters(),
        "ctes": [_clm_medical(), _medical_mm()],
        "output": {
            "joins": [
                {"left": "clm_medical", "right": "medical_mm",
                 "type": "full_outer", "on": ["lob_code", "service_area_state"]},
            ],
            "columns": [
                {"name": "lob_code",
                 "expr": "COALESCE({clm_medical.lob_code}, {medical_mm.lob_code})"},
                {"name": "service_area_state",
                 "expr": "COALESCE({clm_medical.service_area_state}, {medical_mm.service_area_state})"},
                {"name": "medical_paid_pmpm",
                 "expr": "{clm_medical.medical_paid} / NULLIF({medical_mm.member_months}, 0)"},
                {"name": "admits_per_1k",
                 "expr": "({clm_medical.admits} / NULLIF({medical_mm.member_months}, 0)) * 12000"},
            ],
        },
    }


def _build(query: dict) -> str:
    return build_cte_query_sql(_semantic_model(), query)


# ==========================================================================
# Shape
# ==========================================================================

def test_single_cte_with_group_by_shape():
    query = {
        "ctes": [_clm_medical()],
        "output": {"columns": [
            {"name": "lob_code", "expr": "{clm_medical.lob_code}"},
            {"name": "medical_paid", "expr": "{clm_medical.medical_paid}"},
        ]},
    }
    sql = _build(query)
    assert sql.startswith("WITH clm_medical AS (")
    assert "ed.LOB_CD AS lob_code" in sql
    assert "SUM(ed.ANLYTC_PAID_AMT) AS medical_paid" in sql
    assert "FROM DB.SCH.CLAIMS ed" in sql
    assert "GROUP BY ed.LOB_CD, ed.SRVCAREA_ST" in sql
    assert sql.rstrip().endswith("FROM clm_medical")


def test_shared_filters_applied_to_both_ctes():
    sql = _build(_pmpm_query())
    # numeric period literals unquoted, correct per-source alias on each side
    assert "ed.SNAP_YM = 202606" in sql
    assert "m.SNAP_YM = 202606" in sql
    assert "ed.INCRD_YM BETWEEN 202601 AND 202605" in sql
    assert "m.INCRD_YM BETWEEN 202601 AND 202605" in sql


def test_side_specific_filter_only_on_its_cte():
    sql = _build(_pmpm_query())
    assert "ed.HCC_HIGH = 'Medical'" in sql
    # the claims-only filter appears exactly once (not on the membership CTE)
    assert sql.count("HCC_HIGH") == 1


def test_include_shared_filters_false_drops_them():
    cte = _medical_mm()
    cte["include_shared_filters"] = False
    query = _pmpm_query()
    query["ctes"] = [_clm_medical(), cte]
    sql = _build(query)
    # shared snap filter now present only on the claims CTE
    assert "ed.SNAP_YM = 202606" in sql
    assert "m.SNAP_YM = 202606" not in sql


def test_full_outer_join_shape():
    sql = _build(_pmpm_query())
    assert "FROM clm_medical" in sql
    assert "FULL OUTER JOIN medical_mm" in sql
    assert "clm_medical.lob_code = medical_mm.lob_code" in sql
    assert "clm_medical.service_area_state = medical_mm.service_area_state" in sql


def test_boolean_on_key_from_yaml_is_accepted():
    # YAML 1.1 parses an unquoted ``on:`` key as the boolean True; the builder
    # must fall back to it so configs work whether or not the author quotes the key.
    query = _pmpm_query()
    join = query["output"]["joins"][0]
    join[True] = join.pop("on")
    sql = _build(query)
    assert "FULL OUTER JOIN medical_mm" in sql
    assert "clm_medical.lob_code = medical_mm.lob_code" in sql
    assert "clm_medical.service_area_state = medical_mm.service_area_state" in sql


def test_left_join_shape():
    query = _pmpm_query()
    query["output"]["joins"][0]["type"] = "left"
    sql = _build(query)
    assert "LEFT JOIN medical_mm" in sql


def test_coalesced_key_columns():
    sql = _build(_pmpm_query())
    assert "COALESCE(clm_medical.lob_code, medical_mm.lob_code) AS lob_code" in sql


def test_ratio_nullif_and_multiplier():
    sql = _build(_pmpm_query())
    assert "clm_medical.medical_paid / NULLIF(medical_mm.member_months, 0) AS medical_paid_pmpm" in sql
    assert "(clm_medical.admits / NULLIF(medical_mm.member_months, 0)) * 12000 AS admits_per_1k" in sql


def test_dual_placeholder_resolution():
    sql = _build(_pmpm_query())
    # physical column resolved INSIDE the CTE
    assert "SUM(ed.ANLYTC_PAID_AMT) AS medical_paid" in sql
    # CTE-qualified column referenced in the OUTPUT
    assert "clm_medical.medical_paid" in sql
    # a physical column name is never CTE-qualified in the final SELECT
    assert "medical_mm.ACTL_MBR_CNT" not in sql
    assert "clm_medical.ANLYTC_PAID_AMT" not in sql


# ==========================================================================
# Injection safety
# ==========================================================================

def test_injection_rejected_bad_cte_name():
    cte = _clm_medical()
    cte["name"] = "clm; DROP TABLE x"
    query = _pmpm_query()
    query["ctes"] = [cte, _medical_mm()]
    with pytest.raises(ValueError, match="Invalid CTE name"):
        _build(query)


def test_injection_rejected_bad_measure_name():
    cte = _clm_medical()
    cte["measures"] = [{"name": "x); DROP", "expr": "SUM({expense_detail.paid_amount})"}]
    query = _pmpm_query()
    query["ctes"] = [cte, _medical_mm()]
    with pytest.raises(ValueError, match="Invalid measure name"):
        _build(query)


def test_injection_rejected_bad_output_column_name():
    query = _pmpm_query()
    query["output"]["columns"][0]["name"] = "evil; DROP"
    with pytest.raises(ValueError, match="Invalid output column name"):
        _build(query)


def test_filter_value_is_escaped():
    cte = _clm_medical()
    cte["filters"] = {"logic": "AND", "conditions": [
        {"field": "hcc_high", "operator": "=", "value": "O'Brien"},
    ]}
    query = _pmpm_query()
    query["ctes"] = [cte, _medical_mm()]
    sql = _build(query)
    assert "ed.HCC_HIGH = 'O''Brien'" in sql


# ==========================================================================
# Validation errors
# ==========================================================================

def test_unknown_source():
    cte = _clm_medical()
    cte["source"] = "no_such_table"
    query = _pmpm_query()
    query["ctes"] = [cte, _medical_mm()]
    with pytest.raises(ValueError, match="unknown source table"):
        _build(query)


def test_unknown_field_placeholder():
    cte = _clm_medical()
    cte["measures"] = [{"name": "medical_paid", "expr": "SUM({expense_detail.nonexistent})"}]
    query = _pmpm_query()
    query["ctes"] = [cte, _medical_mm()]
    with pytest.raises(KeyError):
        _build(query)


def test_dimension_not_on_source():
    cte = _clm_medical()
    cte["dimensions"] = ["mbr_status"]  # membership-only dim on a claims source
    query = _pmpm_query()
    query["ctes"] = [cte, _medical_mm()]
    with pytest.raises(ValueError, match="this CTE does not read from"):
        _build(query)


def test_duplicate_cte_names():
    query = _pmpm_query()
    dup = _medical_mm()
    dup["name"] = "clm_medical"
    query["ctes"] = [_clm_medical(), dup]
    with pytest.raises(ValueError, match="Duplicate CTE name"):
        _build(query)


def test_join_key_not_a_cte_column():
    # A join key must be an output column of BOTH sides. (It used to have to be a
    # *dimension*; measures and expression dimensions are legitimate keys now, so
    # the check widened to "column" -- a bogus key is still rejected.)
    query = _pmpm_query()
    query["output"]["joins"][0]["on"] = ["mbr_status"]
    with pytest.raises(ValueError, match="is not a column of CTE"):
        _build(query)


def test_ratio_references_unknown_cte_column():
    query = _pmpm_query()
    query["output"]["columns"][2]["expr"] = "{clm_medical.bogus} / NULLIF({medical_mm.member_months}, 0)"
    with pytest.raises(KeyError):
        _build(query)


def test_bad_join_type():
    query = _pmpm_query()
    query["output"]["joins"][0]["type"] = "cross"
    with pytest.raises(ValueError, match="Unsupported join type"):
        _build(query)


def test_no_ctes():
    with pytest.raises(ValueError, match="at least one CTE"):
        _build({"ctes": [], "output": {"columns": [{"name": "x", "expr": "1"}]}})


# ==========================================================================
# Full example + by-name lookup
# ==========================================================================

def _pmpm_4cte_query() -> dict:
    clm_pharmacy = {
        "name": "clm_pharmacy",
        "source": "expense_detail",
        "dimensions": ["lob_code", "service_area_state"],
        "measures": [{"name": "rx_paid", "expr": "SUM({expense_detail.paid_amount})"}],
    }
    rx_mm = {
        "name": "rx_mm",
        "source": "membership",
        "dimensions": ["lob_code", "service_area_state"],
        "measures": [{"name": "member_months", "expr": "SUM({membership.member_count})"}],
    }
    return {
        "name": "pmpm_full",
        "shared_filters": _shared_filters(),
        "ctes": [_clm_medical(), _medical_mm(), clm_pharmacy, rx_mm],
        "output": {
            "joins": [
                {"left": "clm_medical", "right": "medical_mm",
                 "type": "full_outer", "on": ["lob_code", "service_area_state"]},
                {"left": "clm_medical", "right": "clm_pharmacy",
                 "type": "left", "on": ["lob_code", "service_area_state"]},
                {"left": "medical_mm", "right": "rx_mm",
                 "type": "left", "on": ["lob_code", "service_area_state"]},
            ],
            "columns": [
                {"name": "lob_code",
                 "expr": "COALESCE({clm_medical.lob_code}, {medical_mm.lob_code})"},
                {"name": "medical_paid_pmpm",
                 "expr": "{clm_medical.medical_paid} / NULLIF({medical_mm.member_months}, 0)"},
                {"name": "rx_paid_pmpm",
                 "expr": "{clm_pharmacy.rx_paid} / NULLIF({rx_mm.member_months}, 0)"},
                {"name": "admits_per_1k",
                 "expr": "({clm_medical.admits} / NULLIF({medical_mm.member_months}, 0)) * 12000"},
                {"name": "total_pmpm",
                 "expr": "({clm_medical.medical_paid} + {clm_pharmacy.rx_paid}) / NULLIF({medical_mm.member_months}, 0)"},
            ],
        },
    }


def test_full_pmpm_example():
    sql = _build(_pmpm_4cte_query())
    for name in ("clm_medical", "medical_mm", "clm_pharmacy", "rx_mm"):
        assert f"{name} AS (" in sql
    assert "FULL OUTER JOIN medical_mm" in sql
    assert "LEFT JOIN clm_pharmacy" in sql
    assert "LEFT JOIN rx_mm" in sql
    for col in ("medical_paid_pmpm", "rx_paid_pmpm", "admits_per_1k", "total_pmpm"):
        assert f"AS {col}" in sql


def test_build_by_name():
    model = _semantic_model()
    model["cte_queries"] = [_pmpm_query()]
    sql = build_cte_query_sql_by_name(model, "pmpm_by_lob_state")
    assert "FULL OUTER JOIN medical_mm" in sql


def test_build_by_name_unknown():
    model = _semantic_model()
    model["cte_queries"] = [_pmpm_query()]
    with pytest.raises(ValueError, match="No cte_query named"):
        build_cte_query_sql_by_name(model, "does_not_exist")


# ==========================================================================
# Dependent CTE pipelines: CTE-from-CTE, DISTINCT, HAVING, semi-join
# ==========================================================================

def _pcp_model() -> dict:
    """Claims + enrollment model for a PCP preventive-utilization pipeline.
    Aliases are deterministic: ``claims`` -> ``c``, ``enrollment`` -> ``e``.
    """
    return {
        "name": "pcp_view",
        "tables": [
            {
                "name": "claims",
                "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                "dimensions": [
                    {"name": "mcid", "expr": "CLM_MCID", "data_type": "string"},
                    {"name": "month", "expr": "CLM_YM", "data_type": "number"},
                    {"name": "preventive_flag", "expr": "PRVNTV_FLG", "data_type": "string"},
                ],
                "facts": [
                    {"name": "paid", "expr": "PAID_AMT", "data_type": "number"},
                ],
            },
            {
                "name": "enrollment",
                "base_table": {"database": "DB", "schema": "SCH", "table": "ENRL"},
                "dimensions": [
                    {"name": "mcid", "expr": "MBR_MCID", "data_type": "string"},
                    {"name": "month", "expr": "ENRL_YM", "data_type": "number"},
                    {"name": "pcp_flag", "expr": "PCP_FLG", "data_type": "number"},
                ],
            },
        ],
    }


def _pcp_pipeline() -> dict:
    return {
        "name": "pcp_preventive_utilization",
        "ctes": [
            {
                "name": "input_mcids",
                "source": "claims",
                "distinct": True,
                "dimensions": ["mcid"],
                "filters": {"logic": "AND", "conditions": [
                    {"field": "month", "operator": "=", "value": 202606},
                ]},
            },
            {
                "name": "all_enrollment",
                "source": "enrollment",
                "distinct": True,
                "dimensions": ["mcid", "month", "pcp_flag"],
                "semi_join": {"cte": "input_mcids", "on": ["mcid"]},
            },
            {
                "name": "pcp_ratio",
                "source": "all_enrollment",
                "dimensions": ["mcid"],
                "measures": [
                    {"name": "pcp_months", "expr": "SUM({all_enrollment.pcp_flag})"},
                    {"name": "total_months", "expr": "COUNT({all_enrollment.month})"},
                ],
                "having": "SUM({all_enrollment.pcp_flag}) / NULLIF(COUNT({all_enrollment.month}), 0) > 0.60",
            },
            {
                "name": "pcp_members",
                "source": "pcp_ratio",
                "distinct": True,
                "dimensions": ["mcid"],
            },
            {
                "name": "preventive_claims",
                "source": "claims",
                "dimensions": ["mcid"],
                "measures": [
                    {"name": "preventive_paid", "expr": "SUM({claims.paid})"},
                ],
                "filters": {"logic": "AND", "conditions": [
                    {"field": "preventive_flag", "operator": "=", "value": "Y"},
                ]},
                "semi_join": {"cte": "pcp_members", "on": ["mcid"]},
            },
        ],
        "output": {
            "joins": [
                {"left": "pcp_members", "right": "preventive_claims",
                 "type": "left", "on": ["mcid"]},
            ],
            "columns": [
                {"name": "mcid",
                 "expr": "COALESCE({pcp_members.mcid}, {preventive_claims.mcid})"},
                {"name": "preventive_paid", "expr": "{preventive_claims.preventive_paid}"},
            ],
        },
    }


def test_cte_from_cte_source_renders_in_order():
    query = {
        "ctes": [
            {"name": "agg_a", "source": "claims", "dimensions": ["mcid"],
             "measures": [{"name": "paid", "expr": "SUM({claims.paid})"}]},
            {"name": "agg_b", "source": "agg_a", "dimensions": ["mcid"],
             "measures": [{"name": "paid2", "expr": "SUM({agg_a.paid})"}]},
        ],
        "output": {
            "joins": [{"left": "agg_a", "right": "agg_b", "type": "left", "on": ["mcid"]}],
            "columns": [{"name": "paid2", "expr": "{agg_b.paid2}"}],
        },
    }
    sql = build_cte_query_sql(_pcp_model(), query)
    # agg_a declared before agg_b, and agg_b sources FROM the prior CTE by name
    assert sql.index("agg_a AS (") < sql.index("agg_b AS (")
    assert "FROM agg_a aa" in sql
    assert "SUM(aa.paid) AS paid2" in sql


def test_distinct_projection_has_no_group_by():
    query = {
        "ctes": [{"name": "input_mcids", "source": "claims", "distinct": True,
                  "dimensions": ["mcid"]}],
        "output": {"columns": [{"name": "mcid", "expr": "{input_mcids.mcid}"}]},
    }
    sql = build_cte_query_sql(_pcp_model(), query)
    assert "SELECT DISTINCT c.CLM_MCID AS mcid" in sql
    assert "GROUP BY" not in sql


def test_having_renders_after_group_by():
    sql = build_cte_query_sql(_pcp_model(), _pcp_pipeline())
    group_idx = sql.index("GROUP BY ae.mcid")
    having_idx = sql.index("HAVING SUM(ae.pcp_flag) / NULLIF(COUNT(ae.month), 0) > 0.60")
    assert group_idx < having_idx


def test_semi_join_renders_in_subquery():
    sql = build_cte_query_sql(_pcp_model(), _pcp_pipeline())
    # enrollment restricted to members present in input_mcids
    assert "e.MBR_MCID IN (SELECT input_mcids.mcid FROM input_mcids)" in sql
    # preventive claims restricted to qualifying pcp_members
    assert "c.CLM_MCID IN (SELECT pcp_members.mcid FROM pcp_members)" in sql


def test_full_pcp_pipeline_renders_end_to_end():
    sql = build_cte_query_sql(_pcp_model(), _pcp_pipeline())
    for name in ("input_mcids", "all_enrollment", "pcp_ratio",
                 "pcp_members", "preventive_claims"):
        assert f"{name} AS (" in sql
    # dependent chain wired through the synthetic catalog
    assert "FROM all_enrollment ae" in sql
    assert "FROM pcp_ratio pr" in sql
    # final left join of preventive claims onto qualifying members
    assert "FROM pcp_members" in sql
    assert "LEFT JOIN preventive_claims" in sql
    assert "pcp_members.mcid = preventive_claims.mcid" in sql


def test_forward_reference_source_rejected():
    # agg_b sources a CTE that is declared *after* it -> not yet registered
    query = {
        "ctes": [
            {"name": "agg_b", "source": "agg_a", "dimensions": ["mcid"]},
            {"name": "agg_a", "source": "claims", "dimensions": ["mcid"]},
        ],
        "output": {"columns": [{"name": "mcid", "expr": "{agg_a.mcid}"}]},
    }
    with pytest.raises(ValueError, match="unknown source table"):
        build_cte_query_sql(_pcp_model(), query)


def test_semi_join_unknown_cte_rejected():
    query = {
        "ctes": [{"name": "x", "source": "claims", "dimensions": ["mcid"],
                  "semi_join": {"cte": "nope", "on": ["mcid"]}}],
        "output": {"columns": [{"name": "mcid", "expr": "{x.mcid}"}]},
    }
    with pytest.raises(ValueError, match="unknown prior CTE"):
        build_cte_query_sql(_pcp_model(), query)


def test_caller_catalog_not_mutated_by_cte_registration():
    from deep_research_utils.semantic_sql import build_semantic_catalog
    model = _pcp_model()
    catalog = build_semantic_catalog(model)
    before = set(catalog["tables"].keys())
    build_cte_query_sql(model, _pcp_pipeline(), catalog=catalog)
    # synthetic CTE "tables" must not leak into the caller's catalog
    assert set(catalog["tables"].keys()) == before


# ==========================================================================
# Multi-source CTEs: joins inside a CTE
# ==========================================================================
#
# A CTE's FROM clause may join further base tables and previously-declared CTEs.
# One alias map spans them all, which is what lets a measure, a filter, or a join
# condition reference any of the sources with the usual {table.field} grammar.

def _joined_cte() -> dict:
    """Claims INNER JOINed to membership on two keys."""
    return {
        "name": "clm_with_mbr",
        "source": "expense_detail",
        "alias": "clm",
        "joins": [
            {
                "type": "inner",
                "table": "membership",
                "alias": "mbr",
                "on": [
                    {"left": "lob_code", "right": "lob_code"},
                    {"left": "incurred_month", "right": "incurred_month"},
                ],
            },
        ],
        "dimensions": ["lob_code"],
        "measures": [{"name": "paid", "expr": "SUM({expense_detail.paid_amount})"}],
    }


def _single_column_output(cte_name: str, column: str) -> dict:
    return {"columns": [{"name": column, "expr": "{" + cte_name + "." + column + "}"}]}


def test_cte_join_to_base_table():
    sql = _build({"ctes": [_joined_cte()], "output": _single_column_output("clm_with_mbr", "paid")})
    assert "FROM DB.SCH.CLAIMS clm" in sql
    assert "INNER JOIN DB.SCH.MBR mbr" in sql
    # each side resolves to ITS OWN physical column for the same logical name
    assert "ON clm.LOB_CD = mbr.LOB_CD" in sql
    assert "AND clm.INCRD_YM = mbr.INCRD_YM" in sql


def test_cte_join_explicit_aliases_are_used():
    sql = _build({"ctes": [_joined_cte()], "output": _single_column_output("clm_with_mbr", "paid")})
    assert "SUM(clm.ANLYTC_PAID_AMT) AS paid" in sql
    assert " ed." not in sql  # the generated alias was overridden by alias: clm


def test_cte_join_to_prior_cte():
    """A CTE may join a previously-declared CTE; its columns are then referenceable."""
    downstream = {
        "name": "narrowed",
        "source": "expense_detail",
        "alias": "clm",
        "joins": [{"type": "inner", "cte": "clm_medical", "on": ["lob_code"]}],
        "dimensions": ["service_area_state"],
        "measures": [{"name": "paid", "expr": "SUM({expense_detail.paid_amount})"}],
    }
    sql = _build({
        "ctes": [_clm_medical(), downstream],
        "output": _single_column_output("narrowed", "paid"),
    })
    assert "INNER JOIN clm_medical cm" in sql
    assert "ON clm.LOB_CD = cm.lob_code" in sql


def test_cross_source_column_comparison():
    """The whole point of one spanning alias map: compare a column to a column."""
    cte = _joined_cte()
    cte["filters"] = {"logic": "AND", "conditions": [
        {"operator": "named_filter",
         "value": "{expense_detail.snap_month} <> {membership.snap_month}"},
    ]}
    sql = _build({"ctes": [cte], "output": _single_column_output("clm_with_mbr", "paid")})
    assert "clm.SNAP_YM <> mbr.SNAP_YM" in sql


def test_cte_join_unknown_prior_cte_rejected():
    cte = _joined_cte()
    cte["joins"] = [{"type": "inner", "cte": "does_not_exist", "on": ["lob_code"]}]
    with pytest.raises(ValueError, match="unknown prior CTE"):
        _build({"ctes": [cte], "output": _single_column_output("clm_with_mbr", "paid")})


def test_cte_join_key_not_on_target_rejected():
    cte = _joined_cte()
    cte["joins"][0]["on"] = [{"left": "lob_code", "right": "hcc_high"}]  # claims-only
    with pytest.raises(ValueError, match="is not a field of"):
        _build({"ctes": [cte], "output": _single_column_output("clm_with_mbr", "paid")})


def test_duplicate_alias_rejected():
    cte = _joined_cte()
    cte["joins"][0]["alias"] = "clm"  # same as the source alias
    with pytest.raises(ValueError, match="duplicate SQL alias"):
        _build({"ctes": [cte], "output": _single_column_output("clm_with_mbr", "paid")})


# ==========================================================================
# Expression dimensions and group_by control
# ==========================================================================

def _period_dim() -> dict:
    return {
        "name": "period",
        "expr": ("CASE WHEN {expense_detail.incurred_month} >= {filters.cut} "
                 "THEN 'current' ELSE 'baseline' END"),
        "group_by": "alias",
    }


def test_expression_dimension_grouped_by_alias():
    cte = _clm_medical()
    cte["dimensions"] = ["lob_code", _period_dim()]
    sql = build_cte_query_sql(
        _semantic_model(),
        {"ctes": [cte], "output": _single_column_output("clm_medical", "medical_paid")},
        filter_values={"cut": 202601},
    )
    assert "THEN 'current' ELSE 'baseline' END AS period" in sql
    assert "ed.INCRD_YM >= 202601" in sql          # {filters.cut} is a bare literal
    assert "GROUP BY ed.LOB_CD, period" in sql     # grouped by the alias


def test_expression_dimension_grouped_by_expr():
    cte = _clm_medical()
    dim = _period_dim()
    dim["group_by"] = "expr"
    cte["dimensions"] = [dim]
    sql = build_cte_query_sql(
        _semantic_model(),
        {"ctes": [cte], "output": _single_column_output("clm_medical", "medical_paid")},
        filter_values={"cut": 202601},
    )
    assert "GROUP BY CASE WHEN ed.INCRD_YM >= 202601" in sql


def test_expression_dimension_becomes_a_referenceable_column():
    cte = _clm_medical()
    cte["dimensions"] = [_period_dim()]
    sql = build_cte_query_sql(
        _semantic_model(),
        {"ctes": [cte], "output": _single_column_output("clm_medical", "period")},
        filter_values={"cut": 202601},
    )
    assert "clm_medical.period AS period" in sql


def test_group_by_false_suppresses_grouping():
    cte = _clm_medical()
    cte["group_by"] = False
    sql = _build({"ctes": [cte], "output": _single_column_output("clm_medical", "medical_paid")})
    assert "GROUP BY" not in sql


def test_expression_dimension_without_expr_rejected():
    cte = _clm_medical()
    cte["dimensions"] = [{"name": "period"}]
    with pytest.raises(ValueError, match="declares no 'expr'"):
        _build({"ctes": [cte], "output": _single_column_output("clm_medical", "medical_paid")})


def test_bad_group_by_mode_rejected():
    cte = _clm_medical()
    dim = _period_dim()
    dim["group_by"] = "sometimes"
    cte["dimensions"] = [dim]
    with pytest.raises(ValueError, match="expected 'alias', 'expr', or 'none'"):
        build_cte_query_sql(
            _semantic_model(),
            {"ctes": [cte], "output": _single_column_output("clm_medical", "medical_paid")},
            filter_values={"cut": 202601},
        )


# ==========================================================================
# Correlated [NOT] EXISTS
# ==========================================================================

def test_not_exists_anti_join():
    cte = {
        "name": "mbr_without_claims",
        "source": "membership",
        "group_by": False,
        "dimensions": ["lob_code", "incurred_month"],
        "exists": [{
            "negate": True,
            "source": "expense_detail",
            "alias": "clm",
            "correlate": [
                {"inner": "lob_code", "outer": "lob_code"},
                {"inner": "incurred_month", "outer": "incurred_month"},
            ],
        }],
    }
    sql = _build({"ctes": [cte], "output": _single_column_output("mbr_without_claims", "lob_code")})
    assert "NOT EXISTS (SELECT 1 FROM DB.SCH.CLAIMS clm WHERE" in sql
    assert "clm.LOB_CD = m.LOB_CD" in sql
    assert "clm.INCRD_YM = m.INCRD_YM" in sql


def test_exists_carries_its_own_filters():
    cte = {
        "name": "mbr_with_medical",
        "source": "membership",
        "group_by": False,
        "dimensions": ["lob_code"],
        "exists": {
            "source": "expense_detail",
            "alias": "clm",
            "correlate": [{"inner": "lob_code", "outer": "lob_code"}],
            "filters": {"logic": "AND", "conditions": [
                {"field": "hcc_high", "operator": "=", "value": "Medical"},
            ]},
        },
    }
    sql = _build({"ctes": [cte], "output": _single_column_output("mbr_with_medical", "lob_code")})
    assert sql.count("NOT EXISTS") == 0
    assert "EXISTS (SELECT 1 FROM DB.SCH.CLAIMS clm WHERE" in sql
    assert "clm.HCC_HIGH = 'Medical'" in sql


def test_exists_unknown_correlate_key_rejected():
    cte = {
        "name": "bad", "source": "membership", "group_by": False,
        "dimensions": ["lob_code"],
        "exists": [{"source": "expense_detail",
                    "correlate": [{"inner": "mbr_status", "outer": "lob_code"}]}],
    }
    with pytest.raises(ValueError, match="is not a field of"):
        _build({"ctes": [cte], "output": _single_column_output("bad", "lob_code")})


# ==========================================================================
# Final SELECT clauses
# ==========================================================================

def test_output_where_group_by_order_by_limit():
    query = _pmpm_query()
    query["output"].update({
        "filters": {"logic": "AND", "conditions": [
            {"operator": "named_filter", "value": "{clm_medical.lob_code} IS NOT NULL"},
        ]},
        "group_by": ["lob_code"],
        "order_by": [{"column": "lob_code", "direction": "desc"}],
        "limit": 25,
    })
    sql = _build(query)
    assert "WHERE ((clm_medical.lob_code IS NOT NULL))" in sql
    assert "GROUP BY lob_code" in sql
    assert "ORDER BY lob_code DESC" in sql
    assert sql.rstrip().endswith("LIMIT 25")


def test_output_join_on_pairs_with_different_names():
    query = _pmpm_query()
    query["output"]["joins"][0]["on"] = [
        {"left": "lob_code", "right": "lob_code"},
        {"left": "service_area_state", "right": "service_area_state"},
    ]
    sql = _build(query)
    assert "ON clm_medical.lob_code = medical_mm.lob_code" in sql


def test_output_group_by_unknown_column_rejected():
    query = _pmpm_query()
    query["output"]["group_by"] = ["not_a_column"]
    with pytest.raises(ValueError, match="not a declared output column"):
        _build(query)


def test_output_order_by_bad_direction_rejected():
    query = _pmpm_query()
    query["output"]["order_by"] = [{"column": "lob_code", "direction": "sideways"}]
    with pytest.raises(ValueError, match="'asc' or 'desc'"):
        _build(query)


def test_output_limit_must_be_positive():
    query = _pmpm_query()
    query["output"]["limit"] = 0
    with pytest.raises(ValueError, match="must be positive"):
        _build(query)


# ==========================================================================
# Request-filter routing
# ==========================================================================

def _request_tree() -> dict:
    return {"logic": "AND", "conditions": [
        {"field": "hcc_high", "operator": "=", "value": "Medical"},   # claims only
        {"field": "lob_code", "operator": "=", "value": "MCM003"},    # both tables
    ]}


def _routing_query(**cte_overrides) -> dict:
    cte = {
        "name": "clm",
        "source": "expense_detail",
        "dimensions": ["lob_code"],
        "measures": [{"name": "paid", "expr": "SUM({expense_detail.paid_amount})"}],
        **cte_overrides,
    }
    return {"ctes": [cte], "output": _single_column_output("clm", "paid")}


def _build_routed(query, request_filters):
    return build_cte_query_sql(_semantic_model(), query, request_filters=request_filters)


def test_request_filters_applied_by_default():
    sql = _build_routed(_routing_query(), _request_tree())
    assert "ed.HCC_HIGH = 'Medical'" in sql
    assert "ed.LOB_CD = 'MCM003'" in sql


def test_apply_request_filters_false_drops_the_whole_tree():
    sql = _build_routed(_routing_query(apply_request_filters=False), _request_tree())
    assert "HCC_HIGH" not in sql
    assert "MCM003" not in sql


def test_exclude_filter_fields_drops_one_leaf():
    sql = _build_routed(_routing_query(exclude_filter_fields=["hcc_high"]), _request_tree())
    assert "HCC_HIGH" not in sql
    assert "ed.LOB_CD = 'MCM003'" in sql


def test_include_filter_fields_keeps_only_listed():
    sql = _build_routed(_routing_query(include_filter_fields=["hcc_high"]), _request_tree())
    assert "ed.HCC_HIGH = 'Medical'" in sql
    assert "MCM003" not in sql


def test_request_filters_merge_with_yaml_shared_by_default():
    """merge (the default) ANDs the request tree with the calculation's own
    shared_filters -- a request cannot silently drop a YAML invariant."""
    query = _routing_query()
    query["shared_filters"] = {"logic": "AND", "conditions": [
        {"field": "snap_month", "operator": "=", "value": 202606},
    ]}
    sql = _build_routed(query, _request_tree())
    assert "ed.SNAP_YM = 202606" in sql      # YAML invariant survives
    assert "ed.HCC_HIGH = 'Medical'" in sql  # request applies too


def test_replace_mode_restores_legacy_substitution():
    query = _routing_query()
    query["shared_filters"] = {"logic": "AND", "conditions": [
        {"field": "snap_month", "operator": "=", "value": 202606},
    ]}
    query["request_filters"] = {"mode": "replace"}
    sql = _build_routed(query, _request_tree())
    assert "SNAP_YM" not in sql              # YAML shared_filters replaced
    assert "ed.HCC_HIGH = 'Medical'" in sql


def test_bad_request_filters_mode_rejected():
    query = _routing_query()
    query["request_filters"] = {"mode": "sometimes"}
    with pytest.raises(ValueError, match="must be 'merge' or 'replace'"):
        _build_routed(query, _request_tree())


# ==========================================================================
# Null-operator filter leaves (no `value` key)
# ==========================================================================

def test_is_not_null_leaf_needs_no_value():
    cte = _clm_medical()
    cte["filters"] = {"logic": "AND", "conditions": [
        {"field": "hcc_high", "operator": "is not null"},
    ]}
    sql = _build({"ctes": [cte], "output": _single_column_output("clm_medical", "medical_paid")})
    assert "ed.HCC_HIGH IS NOT NULL" in sql
