from __future__ import annotations

from deep_research_agents.orchestrator import (
    _build_correlation_artifacts,
    _build_correlation_findings,
    _run_reimbursement_fanout,
)


def test_orchestrator_surfaces_interaction_findings_and_artifacts() -> None:
    result = {
        "root_metric": "expense_detail.total_paid",
        "baseline_value": 100.0,
        "comparison_value": 140.0,
        "delta_value": 40.0,
        "delta_pct": 0.4,
        "drill_path": [{"dimension": "hcc_medium", "top_segments": [{"value": "IP OB"}]}],
        "narrative_summary": "Narrative summary.",
        "interaction_summary": {
            "text": "Operational interactions concentrated in one cell.",
            "source": "llm",
        },
        "recommendations": {
            "items": [
                {
                    "text": '{"priority":1,"action":"Review the top operational cell.","rationale":"Legacy rationale.","cell_ids":["op_001"],"review_area":"unit_cost"}',
                    "cell_ids": ["op_001"],
                }
            ],
            "source": "llm",
        },
        "warnings": ["sample warning"],
        "run_dir": "/tmp/run_dir",
        "manifest_path": "/tmp/run_dir/manifest.json",
        "executive_summary_path": "/tmp/run_dir/summary/executive_summary.json",
        "interaction_matrix": {
            "operational": {
                "artifact_paths": {
                    "sql": "queries/interaction_matrix/operational.sql",
                    "delta": "aggregates/interaction_matrix/operational_delta.parquet",
                    "full_matrix": "aggregates/interaction_matrix/operational_full_matrix.parquet",
                }
            },
            "clinical": {
                "artifact_paths": {
                    "sql": "queries/interaction_matrix/clinical.sql",
                    "delta": "aggregates/interaction_matrix/clinical_delta.parquet",
                    "full_matrix": "aggregates/interaction_matrix/clinical_full_matrix.parquet",
                }
            },
        },
    }

    findings = _build_correlation_findings(result)
    artifacts = _build_correlation_artifacts(result)

    finding_ids = {item["id"] for item in findings}
    artifact_types = {item["type"] for item in artifacts}

    assert "interaction_summary" in finding_ids
    assert "interaction_recommendations" in finding_ids
    assert "warnings" in finding_ids
    recommendation_finding = next(item for item in findings if item["id"] == "interaction_recommendations")
    assert recommendation_finding["items"][0]["description"] == "Review the top operational cell."
    assert recommendation_finding["items"][0]["evidence"] == ["Interaction cell reference: op_001"]
    assert "interaction_operational_sql" in artifact_types
    assert "interaction_operational_delta" in artifact_types
    assert "interaction_operational_full_matrix" in artifact_types
    assert "interaction_clinical_sql" in artifact_types
    assert "interaction_clinical_delta" in artifact_types
    assert "interaction_clinical_full_matrix" in artifact_types


def test_orchestrator_ignores_empty_summary_findings_but_keeps_executive_artifact() -> None:
    result = {
        "root_metric": "expense_detail.total_paid",
        "baseline_value": 100.0,
        "comparison_value": 140.0,
        "delta_value": 40.0,
        "delta_pct": 0.4,
        "drill_path": [{"dimension": "hcc_medium", "top_segments": [{"value": "IP OB"}]}],
        "narrative_summary": "",
        "interaction_summary": {
            "text": "",
            "source": "disabled",
        },
        "recommended_action": [],
        "warnings": [],
        "run_dir": "/tmp/run_dir",
        "manifest_path": "/tmp/run_dir/manifest.json",
        "executive_summary_path": "/tmp/run_dir/summary/executive_summary.json",
        "interaction_matrix": {
            "operational": {"artifact_paths": {"sql": "", "delta": "", "full_matrix": ""}},
            "clinical": {"artifact_paths": {"sql": "", "delta": "", "full_matrix": ""}},
        },
    }

    findings = _build_correlation_findings(result)
    artifacts = _build_correlation_artifacts(result)

    finding_ids = {item["id"] for item in findings}
    artifact_types = {item["type"] for item in artifacts}

    assert "narrative_summary" not in finding_ids
    assert "interaction_summary" not in finding_ids
    assert "interaction_recommendations" not in finding_ids
    assert "executive_summary" in artifact_types


def test_orchestrator_surfaces_recommendations_without_interaction_summary() -> None:
    result = {
        "root_metric": "expense_detail.total_paid",
        "baseline_value": 100.0,
        "comparison_value": 140.0,
        "delta_value": 40.0,
        "delta_pct": 0.4,
        "drill_path": [{"dimension": "hcc_medium", "top_segments": [{"value": "IP OB"}]}],
        "narrative_summary": "",
        "interaction_summary": {
            "text": "",
            "source": "disabled",
        },
        "recommended_action": [
            {
                "rank": 1,
                "priority": "HIGH",
                "category": "Operational",
                "description": "Review the concentrated operational cell.",
                "evidence": [
                    "Drill segment: hcc_medium=IP OB",
                    "Interaction cell reference: op_001",
                    "Metric movement: delta +40",
                    "Caveat: Validate before broad action.",
                ],
                "story_alignment": [
                    "Why: One operational cell explains most of the delta.",
                    "research_consideration: Analyst to review claim drivers.",
                    "cost_of_care_suggestion: Claims processing opportunity.",
                ],
                "peer_benchmarking": [],
                "citation": [],
            }
        ],
        "warnings": [],
        "run_dir": "/tmp/run_dir",
        "manifest_path": "/tmp/run_dir/manifest.json",
        "executive_summary_path": "/tmp/run_dir/summary/executive_summary.json",
        "interaction_matrix": {
            "operational": {"artifact_paths": {"sql": "", "delta": "", "full_matrix": ""}},
            "clinical": {"artifact_paths": {"sql": "", "delta": "", "full_matrix": ""}},
        },
    }

    findings = _build_correlation_findings(result)

    finding_ids = {item["id"] for item in findings}

    assert "interaction_summary" not in finding_ids
    assert "interaction_recommendations" in finding_ids


# ==========================================================================
# Reimbursement fan-out (decoupled, top-K)
# ==========================================================================
#
# The orchestrator owns the card -> filter-tree conversion: for each business
# pattern it unions that pattern's source cards into ONE OR-of-AND filters tree
# and calls the (generic) reimbursement runner with the top-K contract
# (yaml_path + filters + pattern-as-narrative). It must pass NO cards/context
# payload, and land one result per pattern rank.

class _RecordingReimbursementRunner:
    """Stub runner that records every ``execute`` kwargs and echoes a result."""

    def __init__(self):
        self.calls = []

    def execute(self, **kwargs):
        self.calls.append(kwargs)
        rank = (kwargs.get("pattern") or {}).get("pattern_rank")
        return {"output": {"pattern_rank": rank}}


def _fanout_state():
    # Plan B: patterns are scoped by their *groups*; the fan-out expands each
    # source group to its cards and builds one AND-of-INs tree from the cards'
    # provider-scoping ``interaction_cell`` leaves. Clinical ``drill_context``
    # leaves (e.g. the DRG on c1) are excluded from the ranking population.
    return {
        "conversation_id": "conv-1",
        "question": "Analyze reimbursement",
        "business_patterns": [
            {"pattern_rank": 1, "source_group_ids": ["g1"], "source_card_ids": ["c1"]},
            {"pattern_rank": 2, "source_group_ids": ["g2"], "source_card_ids": ["c3"]},
        ],
        "pattern_summary": {
            "cards": [
                {"card_id": "c1", "filters": [
                    {"field": "product_description", "operator": "=", "value": "PPO", "source": "interaction_cell"},
                    {"field": "service_area_state", "operator": "=", "value": "CA", "source": "interaction_cell"},
                    {"field": "drg_name", "operator": "=", "value": "DRG X", "source": "drill_context"},
                ]},
                {"card_id": "c2", "filters": [
                    {"field": "product_description", "operator": "=", "value": "PPO", "source": "interaction_cell"},
                    {"field": "service_area_state", "operator": "=", "value": "NY", "source": "interaction_cell"},
                ]},
                {"card_id": "c3", "filters": [
                    {"field": "lob_code", "operator": "=", "value": "MEDICARE", "source": "interaction_cell"},
                ]},
            ],
            "groups": [
                {"group_id": "g1", "card_ids": ["c1", "c2"]},
                {"group_id": "g2", "card_ids": ["c3"]},
            ],
        },
    }


def test_reimbursement_fanout_builds_group_scope_tree_per_pattern_and_keys_by_rank():
    runner = _RecordingReimbursementRunner()
    out = _run_reimbursement_fanout(
        _fanout_state(), reimbursement_runner=runner, yaml_path="configs/view.yaml"
    )

    # One top-K result per pattern, keyed by rank (as strings).
    assert set(out["reimbursement_by_pattern"].keys()) == {"1", "2"}
    assert out["last_completed_stage"] == "reimbursement"

    calls_by_rank = {c["pattern"]["pattern_rank"]: c for c in runner.calls}
    assert set(calls_by_rank) == {1, 2}

    # Pattern 1: group g1 -> cards c1, c2. interaction_cell leaves only, with
    # the shared field collapsed to an IN list; the c1 drg_name (drill_context)
    # is excluded from the population.
    call1 = calls_by_rank[1]
    assert call1["yaml_path"] == "configs/view.yaml"
    assert call1["conversation_id"] == "conv-1"
    assert call1["query"] == "Analyze reimbursement"
    assert call1["pattern"]["pattern_rank"] == 1
    assert call1["filters"] == {
        "logic": "AND",
        "conditions": [
            {"field": "product_description", "operator": "=", "value": "PPO"},
            {"field": "service_area_state", "operator": "in", "value": ["CA", "NY"]},
        ],
    }
    # Clinical drill_context leaf never reaches the ranking population.
    fields1 = {leaf["field"] for leaf in call1["filters"]["conditions"]}
    assert "drg_name" not in fields1
    # Decoupled contract: NO cards / context payload leaks to the agent.
    assert "cards" not in call1
    assert "context" not in call1

    # Pattern 2: group g2 -> single card c3 -> bare AND group (no OR wrapper).
    call2 = calls_by_rank[2]
    assert call2["filters"] == {
        "logic": "AND",
        "conditions": [{"field": "lob_code", "operator": "=", "value": "MEDICARE"}],
    }


def test_reimbursement_fanout_skips_without_runner_or_patterns():
    # No runner -> skipped, no calls.
    out = _run_reimbursement_fanout(
        {"business_patterns": [{"pattern_rank": 1}]},
        reimbursement_runner=None,
        yaml_path="configs/view.yaml",
    )
    assert out["reimbursement_by_pattern"] == {}
    assert out["last_completed_stage"] == "reimbursement::skipped"

    # Runner present but no patterns -> skipped, runner never called.
    runner = _RecordingReimbursementRunner()
    out2 = _run_reimbursement_fanout(
        {"business_patterns": []}, reimbursement_runner=runner, yaml_path="configs/view.yaml"
    )
    assert out2["reimbursement_by_pattern"] == {}
    assert out2["last_completed_stage"] == "reimbursement::skipped"
    assert runner.calls == []


def test_reimbursement_fanout_applies_snap_and_incurred_period_from_intent():
    # When the resolved intent carries an analysis period (+ a snap_month
    # filter), the fan-out ANDs those period leaves onto each pattern's
    # provider-scope tree so the top-K ranking stays within the analyzed window.
    state = _fanout_state()
    state["intent"] = {
        "analysis_mode_parameters": {
            "period": {
                # ISO bounds on the orchestrator path -> normalized to YYYYMM.
                "current_period": {"start_time": "2026-01-01", "end_time": "2026-06-30"},
                "start_time": "2026-01-01",
                "end_time": "2026-06-30",
            }
        },
        "filters": [
            {"field": "snap_month", "operator": "=", "value": 202606, "source": "dimension_match"},
            {"field": "lob_description", "operator": "=", "value": "Commercial"},
        ],
    }

    runner = _RecordingReimbursementRunner()
    out = _run_reimbursement_fanout(
        state, reimbursement_runner=runner, yaml_path="configs/view.yaml"
    )
    assert set(out["reimbursement_by_pattern"].keys()) == {"1", "2"}

    calls_by_rank = {c["pattern"]["pattern_rank"]: c for c in runner.calls}

    # Pattern 2 (single provider-scope leaf) is the clearest: base leaf + the two
    # period leaves are ANDed into one group.
    tree2 = calls_by_rank[2]["filters"]
    assert tree2["logic"] == "AND"
    conds2 = tree2["conditions"]
    assert {"field": "lob_code", "operator": "=", "value": "MEDICARE"} in conds2
    assert {"field": "snap_month", "operator": "=", "value": 202606} in conds2
    assert {
        "field": "incurred_month",
        "operator": "between",
        "value": "202601 and 202606",
    } in conds2

    # Pattern 1 (provider scope already an AND of two leaves) gets the same two
    # period leaves appended alongside its provider-scope conditions.
    conds1 = calls_by_rank[1]["filters"]["conditions"]
    period_leaves = [
        {"field": "snap_month", "operator": "=", "value": 202606},
        {"field": "incurred_month", "operator": "between", "value": "202601 and 202606"},
    ]
    for leaf in period_leaves:
        assert leaf in conds1


def test_reimbursement_fanout_incurred_window_without_snap():
    # No snap_month leaf in intent -> only the incurred window is applied
    # (snap is never fabricated), per the "apply if present, else skip" rule.
    state = _fanout_state()
    state["intent"] = {
        "analysis_mode_parameters": {
            "period": {"start_time": 202601, "end_time": 202606}
        },
        "filters": [{"field": "lob_description", "operator": "=", "value": "Commercial"}],
    }

    runner = _RecordingReimbursementRunner()
    _run_reimbursement_fanout(
        state, reimbursement_runner=runner, yaml_path="configs/view.yaml"
    )
    conds2 = {c["pattern"]["pattern_rank"]: c for c in runner.calls}[2]["filters"]["conditions"]
    fields = [leaf.get("field") for leaf in conds2]
    assert "snap_month" not in fields
    assert {
        "field": "incurred_month",
        "operator": "between",
        "value": "202601 and 202606",
    } in conds2
