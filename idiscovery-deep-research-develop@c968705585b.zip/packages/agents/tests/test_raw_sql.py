"""Tests for the raw-SQL escape-hatch builder
(:func:`deep_research_utils.cte_sql.build_raw_sql`).

A ``raw_sql`` calculation carries author-written SQL with two placeholder forms:
``{table.field}`` -> ``alias.PHYSICAL`` and ``{table}`` -> ``QUALIFIED alias``.
These tests are pure SQL-string / exception assertions -- no live Snowflake / LLM.
"""

from __future__ import annotations

import pytest

from deep_research_utils.cte_sql import build_raw_sql


def _model() -> dict:
    """Single-table model; ``claims`` -> alias ``c``."""
    return {
        "name": "raw_view",
        "tables": [
            {
                "name": "claims",
                "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                "dimensions": [
                    {"name": "mcid", "expr": "CLM_MCID", "data_type": "string"},
                    {"name": "state_code", "expr": "ST_CD", "data_type": "string"},
                ],
                "facts": [
                    {"name": "paid", "expr": "PAID_AMT", "data_type": "number"},
                ],
            },
        ],
    }


def test_field_and_table_placeholders_resolve():
    spec = {
        "type": "raw_sql",
        "sql": "SELECT {claims.state_code}, SUM({claims.paid}) AS total "
               "FROM {claims} GROUP BY {claims.state_code}",
    }
    sql = build_raw_sql(_model(), spec)
    assert "c.ST_CD" in sql
    assert "SUM(c.PAID_AMT) AS total" in sql
    assert "FROM DB.SCH.CLAIMS c" in sql
    # no unresolved placeholders remain
    assert "{" not in sql and "}" not in sql


def test_unknown_field_placeholder_raises():
    spec = {"type": "raw_sql", "sql": "SELECT {claims.nonexistent} FROM {claims}"}
    with pytest.raises(KeyError):
        build_raw_sql(_model(), spec)


def test_unknown_table_placeholder_raises():
    spec = {"type": "raw_sql", "sql": "SELECT 1 FROM {no_such_table}"}
    with pytest.raises(KeyError):
        build_raw_sql(_model(), spec)


def test_empty_sql_rejected():
    with pytest.raises(ValueError, match="non-empty 'sql'"):
        build_raw_sql(_model(), {"type": "raw_sql", "sql": "   "})
