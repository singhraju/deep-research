"""Tests for reimbursement **top-K mode** (rank one dimension by a declared
metric over a semantic-view claims table) and the ``/reimbursement/topk`` endpoint.

Coverage map:
  * reimbursement_agent (top-K is the ONLY mode): single ``build_topk`` graph entry,
    ``build_topk_query_node`` SQL build + meta, ``run_topk_query_node`` verbatim
    execution (LIMIT already baked in — nothing appended) + rows + **no row
    persistence** + truncated logic, ``_validate_topk_params`` fail-fast,
    ``_extract_topk_result`` envelope, ``prepare_state`` (yaml required; a supplied
    ``pattern`` is narrative-only enrichment).
  * API: ``ReimbursementTopKRequest`` validation + route registration.

No live Snowflake / LLM: agent methods only need ``self.logger``, so instances are
built via ``__new__``. A stub helper returns a canned ranking DataFrame and records
every query so the "runs the built SQL as-is, no extra LIMIT" guarantee can be
asserted directly. ``build_topk_query_node`` reads ``semantic_model`` straight from
state, so the SQL-build/run tests use a tiny in-memory model (no disk); the
``prepare_state`` tests use the real on-disk OON view (which declares the dimension
+ metrics the defaults reference).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import pandas as pd
import pytest

from deep_research_utils.semantic_sql import build_semantic_catalog
from deep_research_agents.reimbursement_agent import (
    ReimbursementPolicyAgent,
    ReimbursementState,
)
from deep_research_core.base_agent import AgentConfigurationError

# This test file is packages/agents/tests/<f>, so parents[3] == repo root.
REPO_ROOT = Path(__file__).resolve().parents[3]
# The chained top-K default dimension is the NUCC taxonomy CODE
# (provider_taxonomy_specialization_code), which only the `local_offshore` OON
# view declares (alongside provider_taxonomy_type + expense_detail.total_paid).
OON_YAML_REL = "configs/correlation_pattern/coc_ecap_oon_semantic_view_with_samples_local_offshore.yaml"


# ==========================================================================
# Fixtures / helpers
# ==========================================================================

def _topk_model() -> dict:
    """Minimal single-table claims model.

    Physical exprs give ``expense_detail`` the alias ``ed`` (the design's worked
    example). Carries the taxonomy + lob dimensions and single-table paid/allowed
    metrics — enough to build, run, and validate a top-K ranking query.
    """
    return {
        "name": "test_topk_view",
        "tables": [
            {
                "name": "expense_detail",
                "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                "dimensions": [
                    {"name": "provider_taxonomy_type", "expr": "PROV_TXNMY_TYPE_NM", "data_type": "string"},
                    # The chained top-K default dimension: the NUCC taxonomy CODE.
                    {"name": "provider_taxonomy_specialization_code", "expr": "PROV_TXNMY_SPCLZTN_CD", "data_type": "string"},
                    {"name": "lob_code", "expr": "LOB_CD", "data_type": "string"},
                    {"name": "service_area_state", "expr": "SRVCAREA_ST_CD", "data_type": "string"},
                ],
                "facts": [
                    {"name": "paid_amount", "expr": "PAID_AMT", "data_type": "number"},
                    {"name": "allowed_amount", "expr": "ALWD_AMT", "data_type": "number"},
                ],
                "metrics": [
                    {"name": "expense_detail.total_paid", "expr": "SUM({expense_detail.paid_amount})"},
                    {"name": "expense_detail.total_allowed", "expr": "SUM({expense_detail.allowed_amount})"},
                ],
            },
        ],
    }


class _RowStubHelper:
    """SnowparkHelper stub: returns a canned ranking DataFrame and records every
    query so the "no LIMIT appended" guarantee can be asserted directly."""

    def __init__(self, df: pd.DataFrame):
        self._df = df
        self.queries: list[str] = []

    def execute_query_and_return_pandas_df(self, query: str) -> pd.DataFrame:
        self.queries.append(query)
        return self._df.copy()


def _make_agent(snowflake_helper=None) -> ReimbursementPolicyAgent:
    """Build a reimbursement agent WITHOUT running ``__init__`` (no Snowflake /
    LLM construction). Only the attributes the top-K paths touch are set."""
    agent = ReimbursementPolicyAgent.__new__(ReimbursementPolicyAgent)
    agent.logger = logging.getLogger("test_reimbursement_topk_mode")
    agent._token_breakdown = {}
    agent.snowflake_helper = snowflake_helper
    agent.llm = None
    agent.llm_nano = None
    agent.llm_mini = None
    return agent


def _run_state(agent, *, helper, dimension="provider_taxonomy_type", metric=None,
               top_k=10, filters=None, persist_queries=False, output_root=None, model=None):
    """Build the ranking SQL via ``build_topk_query_node`` (populating
    ``topk_query`` + ``topk_meta``), then splice in the run-time keys the
    ``run_topk_query_node`` reads — mirroring how the graph hands state between
    the two nodes.

    ``dimension`` defaults to the specialty-NAME dimension (not the chained
    code-dimension default) so the ranked rows stay coherent with ``TOPK_DF``
    (whose column is ``PROVIDER_TAXONOMY_TYPE``)."""
    base = {
        "mode": "topk",
        "semantic_model": model or _topk_model(),
        "dimension": dimension,
        "metric": metric,
        "top_k": top_k,
        "filters": filters,
        "catalog": None,
        "snowflake_helper": helper,
        "persist_queries": persist_queries,
        "output_root": output_root,
        "yaml_path": "/abs/view.yaml",
    }
    base.update(agent.build_topk_query_node(base))  # topk_query + topk_meta
    return base


# Two ranked rows; execute_sql_to_df lowercases columns (normalize_dataframe_columns).
TOPK_DF = pd.DataFrame({
    "PROVIDER_TAXONOMY_TYPE": ["Cardiology", "Oncology"],
    "TOTAL_PAID": [5000.0, 3000.0],
})


# ==========================================================================
# Routing
# ==========================================================================

class TestGraphEntry:
    """Top-K is the only mode. ``build_graph`` wires START straight to
    ``build_topk``; the old ``_route_entry`` dispatcher and the pattern/legacy
    ``search_policies`` node are gone, and ``node_name`` reports the single
    entry."""

    def test_route_entry_removed(self):
        # The mode dispatcher no longer exists — nothing to route.
        assert not hasattr(_make_agent(), "_route_entry")

    def test_node_name_is_build_topk(self):
        assert _make_agent().node_name == "build_topk"

    def test_graph_entry_is_build_topk_and_search_policies_gone(self):
        agent = _make_agent()
        agent.state_class = ReimbursementState  # normally set in __init__
        graph = agent.build_graph()
        assert "build_topk" in graph.nodes
        assert "search_policies" not in graph.nodes


# ==========================================================================
# build_topk_query_node (compose SQL + meta; no Snowflake call)
# ==========================================================================

class TestBuildTopkQueryNode:
    def test_defaults_shape_and_meta(self):
        # The chained top-K default dimension is the NUCC taxonomy CODE
        # (provider_taxonomy_specialization_code), not the specialty name.
        out = _make_agent().build_topk_query_node({"semantic_model": _topk_model()})
        assert set(out) == {"topk_query", "topk_meta"}

        sql = out["topk_query"]
        assert "SELECT ed.PROV_TXNMY_SPCLZTN_CD AS provider_taxonomy_specialization_code," in sql
        assert "SUM(ed.PAID_AMT) AS total_paid" in sql
        assert "FROM DB.SCH.CLAIMS ed" in sql
        assert "GROUP BY ed.PROV_TXNMY_SPCLZTN_CD" in sql
        assert "ORDER BY SUM(ed.PAID_AMT) DESC" in sql
        assert sql.rstrip().endswith("LIMIT 10")
        assert "WHERE" not in sql  # no filters -> no WHERE

        meta = out["topk_meta"]
        assert meta["dimension"] == "provider_taxonomy_specialization_code"
        assert meta["metric"] == "expense_detail.total_paid"  # fully-qualified
        assert meta["metric_alias"] == "total_paid"
        assert meta["table"] == "expense_detail"
        assert meta["top_k"] == 10
        assert meta["has_filters"] is False

    def test_honors_overrides(self):
        out = _make_agent().build_topk_query_node({
            "semantic_model": _topk_model(),
            "dimension": "lob_code",
            "metric": "total_allowed",
            "top_k": 3,
            "filters": {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"},
        })
        sql = out["topk_query"]
        assert "ed.LOB_CD AS lob_code" in sql
        assert "SUM(ed.ALWD_AMT) AS total_allowed" in sql
        assert "WHERE (ed.LOB_CD = 'COMMERCIAL')" in sql
        assert sql.rstrip().endswith("LIMIT 3")
        assert out["topk_meta"]["has_filters"] is True
        assert out["topk_meta"]["top_k"] == 3

    def test_none_values_fall_back_to_defaults(self):
        # prepare_state may hand through explicit Nones; build node coalesces them.
        out = _make_agent().build_topk_query_node({
            "semantic_model": _topk_model(),
            "dimension": None,
            "metric": None,
            "top_k": None,
            "filters": None,
        })
        assert out["topk_meta"]["dimension"] == "provider_taxonomy_specialization_code"
        assert out["topk_meta"]["metric"] == "expense_detail.total_paid"
        assert out["topk_meta"]["top_k"] == 10


# ==========================================================================
# run_topk_query_node (execute verbatim + rows, NO persistence)
# ==========================================================================

class TestRunTopkQueryNode:
    def test_executes_query_verbatim_no_limit_appended(self):
        agent = _make_agent()
        helper = _RowStubHelper(TOPK_DF)
        state = _run_state(agent, helper=helper, top_k=5)
        agent.run_topk_query_node(state)
        # Unlike the removed CTE mode, the LIMIT is already baked into the built
        # SQL, so the run node executes it as-is — the recorded query IS topk_query.
        assert helper.queries == [state["topk_query"]]
        assert state["topk_query"].rstrip().endswith("LIMIT 5")

    def test_returns_rows_and_metadata(self):
        agent = _make_agent()
        helper = _RowStubHelper(TOPK_DF)
        out = agent.run_topk_query_node(_run_state(agent, helper=helper, top_k=10))
        topk = out["topk_result"]
        assert topk["dimension"] == "provider_taxonomy_type"
        assert topk["metric"] == "expense_detail.total_paid"
        assert topk["metric_alias"] == "total_paid"
        assert topk["top_k"] == 10
        assert topk["row_count"] == 2
        assert topk["truncated"] is False
        assert topk["has_filters"] is False
        # execute_sql_to_df lowercases column names.
        assert topk["rows"][0]["provider_taxonomy_type"] == "Cardiology"
        assert topk["rows"][0]["total_paid"] == 5000.0

    def test_truncated_true_when_rowcount_hits_top_k(self):
        agent = _make_agent()
        helper = _RowStubHelper(TOPK_DF)  # 2 rows
        out = agent.run_topk_query_node(_run_state(agent, helper=helper, top_k=2))
        assert out["topk_result"]["truncated"] is True

    def test_missing_helper_raises(self):
        agent = _make_agent()
        with pytest.raises(RuntimeError):
            agent.run_topk_query_node(_run_state(agent, helper=None))

    def test_rows_are_json_safe(self):
        agent = _make_agent()
        df = pd.DataFrame({
            "provider_taxonomy_type": ["A", "B"],
            "total_paid": [1.5, float("nan")],
            "n": pd.Series([1, 2], dtype="int64"),
        })
        helper = _RowStubHelper(df)
        out = agent.run_topk_query_node(_run_state(agent, helper=helper))
        rows = out["topk_result"]["rows"]
        assert isinstance(rows[0]["n"], int)      # not numpy.int64
        assert rows[1]["total_paid"] is None      # NaN -> null

    def test_no_row_keys_persist_off(self):
        agent = _make_agent()
        helper = _RowStubHelper(TOPK_DF)
        out = agent.run_topk_query_node(_run_state(agent, helper=helper, persist_queries=False))
        topk = out["topk_result"]
        assert "run_dir" not in topk and "artifacts" not in topk
        assert set(topk.keys()) == {
            "dimension", "metric", "metric_alias", "top_k", "topk_query",
            "yaml_path", "has_filters", "rows", "row_count", "truncated",
        }

    def test_persists_query_and_summary_not_rows(self, tmp_path):
        agent = _make_agent()
        helper = _RowStubHelper(TOPK_DF)
        out = agent.run_topk_query_node(
            _run_state(agent, helper=helper, persist_queries=True, output_root=str(tmp_path))
        )
        topk = out["topk_result"]
        run_dir = Path(topk["run_dir"])
        assert run_dir.exists() and run_dir.parent == tmp_path

        assert (run_dir / "queries" / "topk_query.sql").exists()
        summary_file = run_dir / "summary" / "summary.json"
        manifest_file = run_dir / "manifest.json"
        assert summary_file.exists() and manifest_file.exists()

        summary = json.loads(summary_file.read_text(encoding="utf-8"))
        assert summary["dimension"] == "provider_taxonomy_type"
        assert summary["metric"] == "expense_detail.total_paid"
        assert summary["row_count"] == 2

        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
        assert manifest["rows_persisted"] is False
        assert manifest["queries_persisted"] is True

        # Hard guarantee: NO row/parquet/csv dump anywhere under the run dir.
        assert list(run_dir.rglob("*.parquet")) == []
        assert list(run_dir.rglob("*.csv")) == []

    def test_persist_disabled_writes_nothing(self, tmp_path):
        agent = _make_agent()
        helper = _RowStubHelper(TOPK_DF)
        out = agent.run_topk_query_node(
            _run_state(agent, helper=helper, persist_queries=False, output_root=str(tmp_path))
        )
        assert "run_dir" not in out["topk_result"]
        assert list(tmp_path.iterdir()) == []


# ==========================================================================
# _validate_topk_params (fail fast)
# ==========================================================================

class TestValidateTopkParams:
    def _cat(self, model):
        return build_semantic_catalog(model)

    def test_known_params_pass(self):
        m = _topk_model()
        # No raise == pass.
        _make_agent()._validate_topk_params(
            m, self._cat(m), dimension="provider_taxonomy_type", metric="total_paid", top_k=10
        )

    def test_unknown_dimension_rejected(self):
        m = _topk_model()
        with pytest.raises(AgentConfigurationError):
            _make_agent()._validate_topk_params(
                m, self._cat(m), dimension="__nope__", metric="total_paid", top_k=10
            )

    def test_unknown_metric_rejected(self):
        m = _topk_model()
        with pytest.raises(AgentConfigurationError):
            _make_agent()._validate_topk_params(
                m, self._cat(m), dimension="provider_taxonomy_type", metric="__nope__", top_k=10
            )

    @pytest.mark.parametrize("bad", [0, -1])
    def test_bad_top_k_rejected(self, bad):
        m = _topk_model()
        with pytest.raises(AgentConfigurationError):
            _make_agent()._validate_topk_params(
                m, self._cat(m), dimension="provider_taxonomy_type", metric="total_paid", top_k=bad
            )

    def test_unknown_filter_field_rejected(self):
        # render_filter_tree raises KeyError for a bad filter field; the builder
        # normalizes it to ValueError, so validation surfaces AgentConfigurationError
        # (rather than leaking a bare KeyError out of the graph).
        m = _topk_model()
        with pytest.raises(AgentConfigurationError):
            _make_agent()._validate_topk_params(
                m, self._cat(m), dimension="provider_taxonomy_type", metric="total_paid",
                top_k=10, filters={"field": "__nope__", "operator": "=", "value": "x"},
            )


# ==========================================================================
# extract_result top-K branch (_extract_topk_result)
# ==========================================================================

def _topk_payload(row_count=2, *, run_dir=None):
    payload = {
        "dimension": "provider_taxonomy_type",
        "metric": "expense_detail.total_paid",
        "metric_alias": "total_paid",
        "top_k": 10,
        "topk_query": "SELECT ed.PROV_TXNMY_TYPE_NM AS provider_taxonomy_type ... LIMIT 10",
        "yaml_path": "/abs/view.yaml",
        "has_filters": False,
        "rows": [{"provider_taxonomy_type": "Cardiology", "total_paid": 5000.0}] * row_count,
        "row_count": row_count,
        "truncated": False,
    }
    if run_dir is not None:
        payload["run_dir"] = run_dir
        payload["artifacts"] = {"topk_query": "queries/topk_query.sql"}
    return payload


def _graph_output(row_count=2, *, conversation_id="conv1", run_dir=None,
                  policies=2, taxonomy_codes=None, taxonomy_policies=None,
                  recommended_action=None):
    """A chained top-K graph state: the ranking payload PLUS the downstream
    extraction-pipeline output (``result`` / ``formatted_output`` /
    ``recommended_action``) that the shared pattern envelope builder reads.

    Top-K mode no longer dead-ends at the ranking; it maps ranked taxonomies to
    policies and runs the full pipeline, so a realistic graph state carries both
    the ranking trail and the extracted policies.
    """
    result_policies = [{"policy_id": f"P{i}", "status": "ok"} for i in range(policies)]
    individual = [
        {"policy_id": f"P{i}", "title": f"Policy {i}"} for i in range(policies)
    ]
    return {
        "mode": "topk",
        "conversation_id": conversation_id,
        "job_id": "job1",
        "start_time": "2026-08-13T00:00:00+00:00",
        "topk_result": _topk_payload(row_count, run_dir=run_dir),
        "taxonomy_codes": taxonomy_codes if taxonomy_codes is not None else ["282N00000X"],
        "taxonomy_policies": (
            taxonomy_policies if taxonomy_policies is not None
            else [{"policy_number": "R-01", "policy_category": "cat", "policy_topic": "t", "claim_type": "P"}]
        ),
        # Downstream pipeline output (present because top-K now chains).
        "result": result_policies,
        "formatted_output": {
            "summary_table": {"title": "Top taxonomies", "subtitle": "by total paid"},
            "individual_policies": individual,
        },
        "recommended_action": (
            recommended_action if recommended_action is not None
            else [{"action": "review", "detail": "..."}]
        ),
        "elevance_executive_summary": "Executive summary text",
    }


def _empty_pipeline_graph_output(row_count=0, *, conversation_id="conv1"):
    """A top-K run whose ranking returned nothing, so the chain maps no
    taxonomies, hydrates no policies, and the pipeline extracts nothing."""
    return {
        "mode": "topk",
        "conversation_id": conversation_id,
        "job_id": "job1",
        "start_time": "2026-08-13T00:00:00+00:00",
        "topk_result": _topk_payload(row_count),
        "taxonomy_codes": [],
        "taxonomy_policies": [],
        "result": [],
        "formatted_output": {"summary_table": None, "individual_policies": []},
        "recommended_action": [],
    }


class TestExtractTopkResult:
    def test_extract_result_dispatches_topk(self):
        result = _make_agent().extract_result(_graph_output(2))
        assert result["output"]["topk"]["dimension"] == "provider_taxonomy_type"
        assert result["explanation"]["mode"] == "topk"

    def test_envelope_shape_success(self):
        # Ranking returned rows AND the chained pipeline extracted policies.
        result = _make_agent()._extract_topk_result(_graph_output(2, policies=2))
        assert result["agent"] == "reimbursement_policy"
        assert result["status"] == "success"
        assert result["conversation_id"] == "conv1"
        # Ranking + taxonomy trail layered onto the pipeline output.
        assert result["output"]["topk"]["row_count"] == 2
        assert result["output"]["taxonomy_codes"] == ["282N00000X"]
        assert result["output"]["taxonomy_policies"][0]["policy_number"] == "R-01"
        # Pipeline recommendations flow through (top-K is no longer rank-only).
        assert result["recommended_action"] == [{"action": "review", "detail": "..."}]
        assert "mode" not in result  # never a top-level key
        assert result["explanation"]["mode"] == "topk"
        assert result["explanation"]["returned_rows"] == 2
        assert result["explanation"]["taxonomy_policies_mapped"] == 1
        assert result["explanation"]["persisted"] == {"queries": False, "rows": False}
        # topk_rows_found is inserted as the first validation check.
        assert result["validation"]["checks"][0]["check"] == "topk_rows_found"
        assert result["validation"]["checks"][0]["passed"] is True
        assert result["validation"]["is_valid"] is True
        # Pattern-only noise is dropped in top-K mode.
        assert all(c["check"] != "pattern_identified" for c in result["validation"]["checks"])

    def test_zero_rows_is_invalid_with_warning(self):
        result = _make_agent()._extract_topk_result(_empty_pipeline_graph_output(0))
        assert result["validation"]["is_valid"] is False
        assert result["validation"]["checks"][0]["check"] == "topk_rows_found"
        assert result["validation"]["checks"][0]["passed"] is False
        assert any("0 rows" in w for w in result["validation"]["warnings"])

    def test_direct_mode_returns_compact_form(self):
        result = _make_agent()._extract_topk_result(_graph_output(2, conversation_id=None))
        # Direct mode: the pattern path's compact dict WITH the ranking trail.
        assert result["topk"]["row_count"] == 2
        assert result["taxonomy_codes"] == ["282N00000X"]
        assert result["taxonomy_policies"][0]["policy_number"] == "R-01"
        assert result["recommended_action"] == [{"action": "review", "detail": "..."}]
        assert "reimbursement_policies" in result
        # No orchestrator envelope keys in direct mode.
        assert "status" not in result and "output" not in result

    def test_run_dir_surfaced_when_persisted(self):
        go = _graph_output(2, run_dir="/tmp/reimbursement_runs/run1")
        result = _make_agent()._extract_topk_result(go)
        assert result["explanation"]["run_dir"] == "/tmp/reimbursement_runs/run1"
        assert result["explanation"]["persisted"] == {"queries": True, "rows": False}


# ==========================================================================
# find_taxonomy_policies_node — competitor-policy flag forwarding
# ==========================================================================

class TestFindTaxonomyPoliciesCompetitorFlag:
    """The taxonomy->policy bridge must forward state['fetch_competitor_policies']
    down to _fetch_policy_details_from_db (default False)."""

    @staticmethod
    def _agent_capturing(captured: dict) -> ReimbursementPolicyAgent:
        agent = _make_agent(snowflake_helper=object())
        # One mapped policy for the single ranked code; stub the DB hydrate so the
        # test stays offline and can record the flag the node passes through.
        agent.get_policies_for_taxonomy_mapping = lambda codes: [{"policy_number": "R-01"}]

        def _fake_fetch(helper, policy_number, states, lobs,
                        fetch_competitor_policies=False):
            captured["flag"] = fetch_competitor_policies
            return [{"policy_id": "P1", "policy_title": "t",
                     "external_link": None, "payor": "X"}]

        agent._fetch_policy_details_from_db = _fake_fetch
        return agent

    @staticmethod
    def _state(**extra) -> dict:
        base = {
            "topk_result": {
                "rows": [{"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "282N00000X"}],
                "dimension": "provider_taxonomy_specialization_code",
                "top_k": 10,
            },
            "snowflake_helper": object(),
        }
        base.update(extra)
        return base

    def test_flag_defaults_false(self):
        captured: dict = {}
        out = self._agent_capturing(captured).find_taxonomy_policies_node(self._state())
        assert captured["flag"] is False
        assert len(out["filtered_policies"]) == 1
        assert out["taxonomy_codes"] == ["282N00000X"]

    def test_flag_forwarded_true(self):
        captured: dict = {}
        out = self._agent_capturing(captured).find_taxonomy_policies_node(
            self._state(fetch_competitor_policies=True)
        )
        assert captured["flag"] is True
        assert len(out["filtered_policies"]) == 1


class TestBuildPatternContextNoneGuard:
    """Top-K mode chains into analyze_table_structure with pattern=None
    (prepare_state seeds it). _build_pattern_context must tolerate that
    instead of raising AttributeError (the prior 500)."""

    def test_none_pattern_does_not_raise(self):
        agent = _make_agent()
        ctx = agent._build_pattern_context(None, ["470", "471"], ["arthroplasty"])
        assert isinstance(ctx, str)
        assert "arthroplasty" in ctx

    def test_dict_pattern_still_uses_title(self):
        agent = _make_agent()
        ctx = agent._build_pattern_context(
            {"top_pattern": "Hip replacement"}, [], []
        )
        assert "Hip replacement" in ctx


class TestSelectTopTaxonomies:
    """Selection rule feeding the policy search: drop the ``-2`` sentinel,
    keep the cumulative Pareto-90% top set, then cap at 3 (whichever is lower).
    Operates on ranked ``(code, metric)`` pairs in metric-DESC order."""

    def test_excludes_minus_two(self):
        agent = _make_agent()
        # -2 dominates the metric but must be dropped before any Pareto math.
        # Remaining total 100: 40, 75, 100 -> crosses 90% at the 3rd -> keep all 3.
        selected = agent._select_top_taxonomies(
            [("-2", 500.0), ("A", 40.0), ("B", 35.0), ("C", 25.0)]
        )
        assert "-2" not in selected
        assert selected == ["A", "B", "C"]

    def test_pareto_count_three(self):
        agent = _make_agent()
        # total 100: 70, 85, 95 -> crosses 90% at the 3rd -> min(3,3)=3
        selected = agent._select_top_taxonomies(
            [("A", 70.0), ("B", 15.0), ("C", 10.0), ("D", 5.0)]
        )
        assert selected == ["A", "B", "C"]

    def test_cap_at_three_when_pareto_larger(self):
        agent = _make_agent()
        # total 100: 30,55,75,90 -> crosses 90% at the 4th -> min(3,4)=3
        selected = agent._select_top_taxonomies(
            [("A", 30.0), ("B", 25.0), ("C", 20.0), ("D", 15.0), ("E", 10.0)]
        )
        assert selected == ["A", "B", "C"]

    def test_fewer_than_three_remaining(self):
        agent = _make_agent()
        selected = agent._select_top_taxonomies([("-2", 40.0), ("A", 60.0), ("B", 40.0)])
        assert selected == ["A", "B"]

    def test_pareto_reached_by_single_dominant(self):
        agent = _make_agent()
        # total 100: first taxonomy alone is >= 90% -> pareto_count 1 -> select 1
        selected = agent._select_top_taxonomies(
            [("A", 95.0), ("B", 3.0), ("C", 2.0)]
        )
        assert selected == ["A"]

    def test_all_zero_metric_falls_back_to_cap(self):
        agent = _make_agent()
        selected = agent._select_top_taxonomies(
            [("A", 0.0), ("B", 0.0), ("C", 0.0), ("D", 0.0)]
        )
        # non-positive total -> fallback keeps all, cap trims to 3
        assert selected == ["A", "B", "C"]

    def test_missing_metric_falls_back_to_cap(self):
        agent = _make_agent()
        selected = agent._select_top_taxonomies(
            [("A", None), ("B", None), ("C", None), ("D", None)]
        )
        assert selected == ["A", "B", "C"]

    def test_empty_after_exclusion(self):
        agent = _make_agent()
        assert agent._select_top_taxonomies([("-2", 10.0)]) == []


class TestExtractRankedTaxonomies:
    """Case-insensitive extraction of (code, metric) pairs, rank order kept,
    blanks and duplicate codes dropped."""

    def test_case_insensitive_and_dedupe(self):
        agent = _make_agent()
        rows = [
            {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "A", "TOTAL_PAID": 70},
            {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "B", "TOTAL_PAID": 30},
            {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "A", "TOTAL_PAID": 5},  # dup
            {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "  ", "TOTAL_PAID": 1},  # blank
        ]
        ranked = agent._extract_ranked_taxonomies(
            rows, "provider_taxonomy_specialization_code", "total_paid"
        )
        assert ranked == [("A", 70.0), ("B", 30.0)]

    def test_missing_metric_alias_yields_none(self):
        agent = _make_agent()
        rows = [{"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "A", "TOTAL_PAID": 70}]
        ranked = agent._extract_ranked_taxonomies(
            rows, "provider_taxonomy_specialization_code", None
        )
        assert ranked == [("A", None)]


class TestFindTaxonomyPoliciesSelection:
    """End-to-end at the node: only the selected taxonomy codes (post -2 drop,
    Pareto-90%, cap 3) are handed to get_policies_for_taxonomy_mapping."""

    def test_only_selected_codes_are_mapped(self):
        agent = _make_agent(snowflake_helper=object())
        captured: dict = {}

        def _fake_mapping(codes):
            captured["codes"] = list(codes)
            return [{"policy_number": f"R-{c}"} for c in codes]

        def _fake_fetch(helper, policy_number, states, lobs,
                        fetch_competitor_policies=False):
            return [{"policy_id": policy_number, "policy_title": "t",
                     "external_link": None, "payor": "X"}]

        agent.get_policies_for_taxonomy_mapping = _fake_mapping
        agent._fetch_policy_details_from_db = _fake_fetch

        state = {
            "topk_result": {
                "rows": [
                    {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "-2", "TOTAL_PAID": 500},
                    {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "A", "TOTAL_PAID": 70},
                    {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "B", "TOTAL_PAID": 15},
                    {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "C", "TOTAL_PAID": 10},
                    {"PROVIDER_TAXONOMY_SPECIALIZATION_CODE": "D", "TOTAL_PAID": 5},
                ],
                "dimension": "provider_taxonomy_specialization_code",
                "metric_alias": "total_paid",
                "top_k": 10,
            },
            "snowflake_helper": object(),
        }
        out = agent.find_taxonomy_policies_node(state)
        # -2 dropped; Pareto 70/85/95 -> 3; cap 3 -> A,B,C. D excluded.
        assert captured["codes"] == ["A", "B", "C"]
        assert out["taxonomy_codes"] == ["A", "B", "C"]
        assert {r["policy_id"] for r in out["filtered_policies"]} == {"R-A", "R-B", "R-C"}


class TestFormatOutputNonePattern:
    """Top-K chains into the shared format_output_node with pattern seeded
    empty (no pattern in top-K mode). The node must not crash on
    ``pattern.get(...)`` and should fall back to a generic subtitle.
    Regression for the 500 at reimbursement_agent.py:2656."""

    @staticmethod
    def _state(pattern):
        # Minimal inputs to reach the summary-table build past the empty guard,
        # using the no-dynamic-columns fallback branch (table_structure=None) so
        # no LLM stubbing is needed.
        return {
            "result": [
                {"PLCY_ID": "P1", "policy_metadata": {}, "results": []},
            ],
            "filtered_policies": [
                {"policy_id": "P1", "policy_title": "t", "payor": "Payer X"},
            ],
            "table_structure": None,
            "pattern": pattern,
            "llm": None,
        }

    def test_none_pattern_does_not_crash(self):
        agent = _make_agent()
        out = agent.format_output_node(self._state(None))
        summary = out["formatted_output"]["summary_table"]
        assert summary["subtitle"] == "Pattern Analysis"
        assert out["formatted_output"]["individual_policies"]

    def test_empty_dict_pattern_does_not_crash(self):
        agent = _make_agent()
        out = agent.format_output_node(self._state({}))
        assert out["formatted_output"]["summary_table"]["subtitle"] == "Pattern Analysis"

    def test_dict_pattern_uses_title(self):
        agent = _make_agent()
        out = agent.format_output_node(self._state({"top_pattern": "OB readmissions"}))
        assert out["formatted_output"]["summary_table"]["subtitle"] == "OB readmissions"


# ==========================================================================
# prepare_state top-K mode (precedence pattern > topk > legacy)
# ==========================================================================

class TestPrepareStateTopkMode:
    def test_yaml_triggers_topk_mode(self):
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL)
        assert state["mode"] == "topk"
        # Chained default dimension is the NUCC taxonomy CODE.
        assert state["dimension"] == "provider_taxonomy_specialization_code"
        assert state["metric"] == "total_paid"
        assert state["top_k"] == 10
        assert "semantic_model" in state and "catalog" in state
        # Pattern/legacy seeds for the shared tail: pattern must be an empty
        # dict (not None) so downstream pattern.get(...) is safe; pattern_rank
        # stays None so recommendation generation skips gracefully.
        assert state["pattern"] == {}
        assert state["pattern_rank"] is None

    def test_yaml_read_from_context(self):
        state = _make_agent().prepare_state(context={"yaml_path": OON_YAML_REL})
        assert state["mode"] == "topk"

    def test_missing_yaml_raises(self):
        # Top-K is the only mode: with neither a top-level yaml_path nor one in
        # context, prepare_state fails loudly. Legacy cpt-code invocation is gone.
        with pytest.raises(AgentConfigurationError):
            _make_agent().prepare_state(query="no yaml provided")

    def test_pattern_narrative_lands_in_state(self):
        # A supplied pattern is narrative-only: it flows verbatim into
        # state["pattern"] / state["pattern_rank"] to enrich the shared-tail
        # prompts. Codes/states/LOBs still come from filters (none here).
        pattern = {"pattern_rank": 3, "pattern_title": "OON cardiology spend"}
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL, pattern=pattern)
        assert state["mode"] == "topk"
        assert state["pattern"] == pattern
        assert state["pattern_rank"] == 3

    def test_pattern_narrative_from_context(self):
        # The pattern may also arrive via context (caller fallback path).
        pattern = {"pattern_rank": 7}
        state = _make_agent().prepare_state(
            context={"yaml_path": OON_YAML_REL, "pattern": pattern}
        )
        assert state["pattern"] == pattern
        assert state["pattern_rank"] == 7

    def test_unknown_dimension_rejected(self):
        with pytest.raises(AgentConfigurationError):
            _make_agent().prepare_state(yaml_path=OON_YAML_REL, dimension="__nope__")

    def test_top_k_override(self):
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL, top_k=25)
        assert state["top_k"] == 25

    def test_dimension_override(self):
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL, dimension="service_area_state")
        assert state["dimension"] == "service_area_state"

    def test_metric_override(self):
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL, metric="total_allowed")
        assert state["metric"] == "total_allowed"

    def test_filters_override(self):
        leaf = {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL, filters=leaf)
        assert state["filters"] == leaf
        assert state["mode"] == "topk"

    def test_persist_queries_override(self):
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL, persist_queries=False)
        assert state["persist_queries"] is False

    def test_fetch_competitor_policies_default_false(self):
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL)
        assert state["fetch_competitor_policies"] is False

    def test_fetch_competitor_policies_override(self):
        state = _make_agent().prepare_state(
            yaml_path=OON_YAML_REL, fetch_competitor_policies=True
        )
        assert state["fetch_competitor_policies"] is True

    def test_fetch_competitor_policies_from_context(self):
        state = _make_agent().prepare_state(
            context={"yaml_path": OON_YAML_REL, "fetch_competitor_policies": True}
        )
        assert state["fetch_competitor_policies"] is True

    def test_filter_codes_derived_from_filters(self):
        # A filter tree carrying state + LOB + DRG + procedure (all declared in
        # the OON view) populates states/lobs/filter_codes and the legacy
        # cpt_codes/drg_codes keys the extraction + judge read.
        filters = {
            "logic": "AND",
            "conditions": [
                {"field": "service_area_state", "operator": "in", "value": ["CA", "TX"]},
                {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"},
                {"field": "drg_code", "operator": "=", "value": "470"},
                {"field": "procedure_code", "operator": "=", "value": "99291"},
            ],
        }
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL, filters=filters)
        assert state["states"] == ["CA", "TX"]
        assert state["lobs"] == ["COMMERCIAL"]
        assert state["filter_codes"] == {
            "state": ["CA", "TX"],
            "lob": ["COMMERCIAL"],
            "drg": ["470"],
            "procedure": ["99291"],
        }
        # Legacy keys: DRG list populated; no CPT/HCPCS in the tree -> empty str.
        assert state["drg_codes"] == ["470"]
        assert state["cpt_codes"] == ""

    def test_no_filters_leaves_narrowing_unset(self):
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL)
        assert state["states"] is None
        assert state["lobs"] is None
        assert state["filter_codes"] == {}
        assert state["cpt_codes"] == ""
        assert state["drg_codes"] == []

    def test_lob_description_normalized_to_policy_canonical(self):
        # The failing payload: claims-side lob_description "Commercial Individual"
        # + a state list. state["lobs"] must carry the policy-canonical LOB_NM
        # ("Commercial") so hydration matches; filter_codes keeps the raw value
        # (normalization is hydration-only). States pass through as a list.
        filters = {
            "logic": "AND",
            "conditions": [
                {"field": "lob_description", "operator": "=", "value": "Commercial Individual"},
                {"field": "service_area_state", "operator": "in", "value": ["CA", "NY"]},
            ],
        }
        state = _make_agent().prepare_state(yaml_path=OON_YAML_REL, filters=filters)
        assert state["states"] == ["CA", "NY"]
        assert state["lobs"] == ["Commercial"]
        assert state["filter_codes"]["lob"] == ["Commercial Individual"]


# ==========================================================================
# _extract_filter_codes — pull state/LOB/clinical codes out of the filter tree
# ==========================================================================

class TestExtractFilterCodes:
    def test_none_and_empty_return_empty(self):
        agent = _make_agent()
        assert agent._extract_filter_codes(None) == {}
        assert agent._extract_filter_codes([]) == {}

    def test_state_single_leaf(self):
        agent = _make_agent()
        leaf = {"field": "service_area_state", "operator": "=", "value": "CA"}
        assert agent._extract_filter_codes(leaf) == {"state": ["CA"]}

    def test_state_aliases_all_map_to_state(self):
        agent = _make_agent()
        for field in ("state_code", "plan_state_code", "service_area_state", "ST_CD"):
            leaf = {"field": field, "operator": "=", "value": "NY"}
            assert agent._extract_filter_codes(leaf) == {"state": ["NY"]}

    def test_list_value_expanded(self):
        agent = _make_agent()
        leaf = {"field": "drg_code", "operator": "in", "value": ["470", "483"]}
        assert agent._extract_filter_codes(leaf) == {"drg": ["470", "483"]}

    def test_comma_string_value_split(self):
        agent = _make_agent()
        leaf = {"field": "drg_code", "operator": "in", "value": "470, 483 ,  "}
        assert agent._extract_filter_codes(leaf) == {"drg": ["470", "483"]}

    def test_unknown_field_ignored(self):
        # A field with no alias entry (e.g. cpt_code is not in this YAML, and
        # in_network_indicator is not a code) contributes nothing.
        agent = _make_agent()
        tree = [
            {"field": "in_network_indicator", "operator": "=", "value": "Y"},
            {"field": "drg_code", "operator": "=", "value": "470"},
        ]
        assert agent._extract_filter_codes(tree) == {"drg": ["470"]}

    def test_nested_and_or_multiple_types(self):
        agent = _make_agent()
        tree = {
            "logic": "AND",
            "conditions": [
                {"field": "service_area_state", "operator": "in", "value": ["CA", "TX"]},
                {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"},
                {
                    "logic": "OR",
                    "conditions": [
                        {"field": "drg_code", "operator": "=", "value": "470"},
                        {"field": "procedure_code", "operator": "=", "value": "99291"},
                    ],
                },
            ],
        }
        assert agent._extract_filter_codes(tree) == {
            "state": ["CA", "TX"],
            "lob": ["COMMERCIAL"],
            "drg": ["470"],
            "procedure": ["99291"],
        }

    def test_cpt_and_hcpcs_buckets_kept_separate(self):
        agent = _make_agent()
        tree = [
            {"field": "cpt_code", "operator": "=", "value": "99291"},
            {"field": "hcpcs_code", "operator": "=", "value": "J1745"},
        ]
        assert agent._extract_filter_codes(tree) == {
            "cpt": ["99291"],
            "hcpcs": ["J1745"],
        }

    def test_dedupe_preserves_first_seen_order(self):
        agent = _make_agent()
        tree = [
            {"field": "drg_code", "operator": "=", "value": "470"},
            {"field": "drg_name", "operator": "in", "value": ["470", "483"]},
        ]
        assert agent._extract_filter_codes(tree) == {"drg": ["470", "483"]}


# ==========================================================================
# _normalize_lob_to_policy — collapse claims LOB variants to policy LOB_NM
# ==========================================================================

class TestNormalizeLobToPolicy:
    def test_commercial_variants_collapse(self):
        agent = _make_agent()
        assert agent._normalize_lob_to_policy(["Commercial Individual"]) == ["Commercial"]
        assert agent._normalize_lob_to_policy(["Commercial Local Group"]) == ["Commercial"]

    def test_medicare_and_medicaid_variants(self):
        agent = _make_agent()
        assert agent._normalize_lob_to_policy(["Medicare GRS"]) == ["Medicare"]
        assert agent._normalize_lob_to_policy(["Medicare Indiv"]) == ["Medicare"]
        assert agent._normalize_lob_to_policy(["GBD Medicare"]) == ["Medicare"]
        assert agent._normalize_lob_to_policy(["GBD Medicaid"]) == ["Medicaid"]

    def test_case_insensitive_match(self):
        agent = _make_agent()
        assert agent._normalize_lob_to_policy(["commercial individual"]) == ["Commercial"]

    def test_unknown_value_passes_through(self):
        agent = _make_agent()
        assert agent._normalize_lob_to_policy(["Commercial", "Medicaid", "Foo"]) == [
            "Commercial", "Medicaid", "Foo",
        ]

    def test_dedupe_after_collapse(self):
        agent = _make_agent()
        # Both variants collapse to Commercial -> single first-seen entry.
        assert agent._normalize_lob_to_policy(
            ["Commercial Individual", "Commercial Local Group"]
        ) == ["Commercial"]

    def test_empty_none_and_blank_dropped(self):
        agent = _make_agent()
        assert agent._normalize_lob_to_policy([]) == []
        assert agent._normalize_lob_to_policy(None) == []
        assert agent._normalize_lob_to_policy(["", "  ", None]) == []


# ==========================================================================
# _fetch_policy_details_from_db — state/LOB narrowing keeps national policies
# ==========================================================================

class _SqlCaptureHelper:
    """SnowparkHelper stub that records every query and returns queued DataFrames
    (empty once exhausted) so the generated WHERE can be asserted without a DB."""

    def __init__(self, dfs=None):
        self.queries: list[str] = []
        self._dfs = list(dfs or [])
        self._i = 0

    def execute_query_and_return_pandas_df(self, sql: str) -> pd.DataFrame:
        self.queries.append(sql)
        df = self._dfs[self._i] if self._i < len(self._dfs) else pd.DataFrame()
        self._i += 1
        return df.copy()


class TestFetchPolicyDetailsNarrowing:
    """State narrowing must admit national policies (ST_CD null/blank/sentinel)
    and LOB matching must be case-folded and keep unlabelled policies; a strict
    IN (...) over-restricts every national policy to zero."""

    @staticmethod
    def _agent() -> ReimbursementPolicyAgent:
        agent = _make_agent()
        # Avoid config/ini resolution; the SQL text is what we assert on.
        agent.table = lambda name: "DB.SCH.PLCY_MTDTA"
        return agent

    def test_state_list_keeps_national(self):
        agent = self._agent()
        helper = _SqlCaptureHelper()
        agent._fetch_policy_details_from_db(helper, "R-01", states=["CA", "NY"], lobs=None)
        sql = helper.queries[0]
        assert "ST_CD IN ('CA', 'NY')" in sql
        assert "ST_CD IS NULL" in sql
        assert "TRIM(ST_CD) = ''" in sql
        assert "UPPER(TRIM(ST_CD)) IN ('ALL', 'US', 'USA', 'NATIONAL')" in sql
        # No LOB narrowing when lobs is omitted (LOB_NM still in the SELECT list).
        assert "UPPER(TRIM(LOB_NM)) IN" not in sql

    def test_single_state_same_relaxed_shape(self):
        agent = self._agent()
        helper = _SqlCaptureHelper()
        agent._fetch_policy_details_from_db(helper, "R-01", states=["CA"], lobs=None)
        sql = helper.queries[0]
        assert "ST_CD IN ('CA')" in sql
        assert "ST_CD IS NULL" in sql

    def test_lob_clause_case_folded_and_keeps_null(self):
        agent = self._agent()
        helper = _SqlCaptureHelper()
        agent._fetch_policy_details_from_db(helper, "R-01", states=None, lobs=["Commercial"])
        sql = helper.queries[0]
        assert "UPPER(TRIM(LOB_NM)) IN ('COMMERCIAL')" in sql
        assert "LOB_NM IS NULL" in sql
        # No state narrowing when states omitted.
        assert "ST_CD IN (" not in sql

    def test_competitor_branch_uses_relaxed_clauses(self):
        agent = self._agent()
        # First query is the topic lookup; return a topic so the second
        # (competitor) query — which carries the state/LOB filters — runs.
        helper = _SqlCaptureHelper(dfs=[pd.DataFrame({"TOPC_ID": ["T1"]})])
        agent._fetch_policy_details_from_db(
            helper, "R-01", states=["CA", "NY"], lobs=["Commercial"],
            fetch_competitor_policies=True,
        )
        competitor_sql = helper.queries[1]
        assert "ST_CD IN ('CA', 'NY')" in competitor_sql
        assert "ST_CD IS NULL" in competitor_sql
        assert "UPPER(TRIM(LOB_NM)) IN ('COMMERCIAL')" in competitor_sql
        assert "LOB_NM IS NULL" in competitor_sql


# ==========================================================================
# _build_judge_pattern_summary — renders extra filter-code lines
# ==========================================================================

class TestBuildJudgePatternSummary:
    def test_renders_extra_code_types(self):
        agent = _make_agent()
        summary = agent._build_judge_pattern_summary(
            pattern={},
            drg_codes=["470"],
            cpt_codes="99291",
            filter_codes={
                "procedure": ["99291"],
                "diagnosis": ["O80"],
                "revenue": ["0450"],
            },
        )
        assert "DRG codes: 470" in summary
        assert "CPT/HCPCS codes: 99291" in summary
        assert "Procedure codes: 99291" in summary
        assert "Diagnosis codes: O80" in summary
        assert "Revenue codes: 0450" in summary

    def test_no_context_returns_placeholder(self):
        agent = _make_agent()
        assert agent._build_judge_pattern_summary({}, [], "", None) == "(no pattern context)"


# ==========================================================================
# API — ReimbursementTopKRequest validation + route registration
# ==========================================================================

@pytest.fixture(scope="module")
def api_mod():
    """Import the API module (runs create_app at import). Skip if unavailable."""
    try:
        import reimbursement_api  # noqa: WPS433 (module lives in packages/agents/src)
    except Exception as exc:  # pragma: no cover - environment-dependent
        pytest.skip(f"reimbursement_api not importable: {exc}")
    return reimbursement_api


class TestTopKRequestModel:
    def test_missing_yaml_path_rejected(self, api_mod):
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            api_mod.ReimbursementTopKRequest(dimension="provider_taxonomy_type")

    def test_defaults(self, api_mod):
        req = api_mod.ReimbursementTopKRequest(yaml_path="x.yaml")
        assert req.dimension == "provider_taxonomy_type"
        assert req.metric == "total_paid"
        assert req.top_k == 10
        assert req.persist_queries is True
        assert req.output_root is None
        assert req.filters is None
        assert req.pattern is None

    def test_blank_dimension_rejected(self, api_mod):
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            api_mod.ReimbursementTopKRequest(yaml_path="x.yaml", dimension="   ")

    def test_top_k_out_of_range_rejected(self, api_mod):
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            api_mod.ReimbursementTopKRequest(yaml_path="x.yaml", top_k=0)
        with pytest.raises(ValidationError):
            api_mod.ReimbursementTopKRequest(yaml_path="x.yaml", top_k=1001)

    def test_filters_accepted(self, api_mod):
        node = {
            "logic": "AND",
            "conditions": [{"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}],
        }
        req = api_mod.ReimbursementTopKRequest(yaml_path="x.yaml", filters=node)
        assert req.filters == node

    def test_pattern_accepted(self, api_mod):
        # Optional narrative enrichment: the endpoint carries a pattern dict
        # verbatim (it flows to prepare_state(pattern=...) as narrative only).
        pattern = {"pattern_rank": 2, "pattern_title": "OON spend"}
        req = api_mod.ReimbursementTopKRequest(yaml_path="x.yaml", pattern=pattern)
        assert req.pattern == pattern

    def test_name_stripped(self, api_mod):
        req = api_mod.ReimbursementTopKRequest(
            yaml_path="x.yaml", dimension="  lob_code ", metric="  total_paid "
        )
        assert req.dimension == "lob_code"
        assert req.metric == "total_paid"

    def test_fetch_competitor_policies_default_false(self, api_mod):
        req = api_mod.ReimbursementTopKRequest(yaml_path="x.yaml")
        assert req.fetch_competitor_policies is False

    def test_fetch_competitor_policies_accepted(self, api_mod):
        req = api_mod.ReimbursementTopKRequest(
            yaml_path="x.yaml", fetch_competitor_policies=True
        )
        assert req.fetch_competitor_policies is True

    def test_topk_route_registered(self, api_mod):
        paths = {r.path for r in api_mod.app.routes if hasattr(r, "path")}
        assert "/reimbursement/topk" in paths
        # top-K is the ONLY mode: the legacy CPT extract route is gone.
        assert "/reimbursement/extract" not in paths
        # removed modes -> no cte / claims routes
        assert "/reimbursement/cte" not in paths
        assert "/reimbursement/claims" not in paths
