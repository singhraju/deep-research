"""Unit tests for the shared ``deep_research_utils.semantic_sql`` machinery.

These cover the low-level, agent-independent SQL primitives that survive as
public helpers used by ``cte_sql`` and the reimbursement agent:
  * ``render_filter_tree`` (leaf / AND / OR / nested / flat-list / empty-group /
    bad-logic / depth-limit / SQL-injection escaping),
  * ``collect_filter_fields`` (leaf-field collection order + fieldless skip),
  * ``build_from_clause`` / ``resolve_field`` (single-table FROM + field expr),
  * ``resolve_semantic_model_path`` (path-traversal security guard — still called
    by the reimbursement agent's CTE ``prepare_state`` branch).

Relocated here from ``test_reimbursement_filter_mode.py`` when the reimbursement
filter mode was removed; the functions themselves remain public and in use.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from deep_research_utils.semantic_sql import (
    build_alias_map,
    build_from_clause,
    build_period_filter_leaves,
    build_semantic_catalog,
    collect_filter_fields,
    collect_filter_leaves,
    combine_filter_trees_and,
    render_filter_tree,
    resolve_field,
    resolve_semantic_model_path,
)

OON_YAML_REL = "configs/correlation_pattern/coc_ecap_oon_semantic_view_with_samples_local.yaml"


# ==========================================================================
# Fixtures / helpers
# ==========================================================================

def _semantic_model() -> dict:
    """Minimal single-table claims view (logical table ``expense_detail``) so
    the SQL-composition tests don't depend on the full on-disk YAML.

    Physical exprs are chosen so the derived alias is ``ed`` (expense_detail →
    "ed") and columns match the design's worked examples.
    """
    return {
        "name": "test_claims_view",
        "tables": [
            {
                "name": "expense_detail",
                "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                "dimensions": [
                    {"name": "drg_code", "expr": "DRG_CD", "data_type": "string"},
                    {"name": "procedure_code", "expr": "PROC_CD", "data_type": "string"},
                    {"name": "primary_diagnosis_code", "expr": "PRMRY_DIAG_CD", "data_type": "string"},
                    {"name": "in_network_indicator", "expr": "IN_NTWK_IND", "data_type": "string"},
                    {"name": "claim_number", "expr": "CLM_NBR", "data_type": "string"},
                    {"name": "lob_code", "expr": "LOB_CD", "data_type": "string"},
                ],
                "facts": [
                    {"name": "paid_amount", "expr": "PAID_AMT", "data_type": "number"},
                ],
            }
        ],
    }


@pytest.fixture(scope="module")
def catalog() -> dict:
    return build_semantic_catalog(_semantic_model())


@pytest.fixture(scope="module")
def alias_map() -> dict:
    return build_alias_map(["expense_detail"])


# Filter-tree fixtures reused across tests
LEAF_DRG_IN = {"field": "drg_code", "operator": "in", "value": ["470", "483"]}
LEAF_PROC_EQ = {"field": "procedure_code", "operator": "=", "value": "99291"}
LEAF_INNET_EQ = {"field": "in_network_indicator", "operator": "=", "value": "Y"}
NESTED_TREE = {
    "logic": "AND",
    "conditions": [
        LEAF_DRG_IN,
        {"logic": "OR", "conditions": [LEAF_PROC_EQ, LEAF_INNET_EQ]},
    ],
}


# ==========================================================================
# render_filter_tree
# ==========================================================================

class TestRenderFilterTree:
    def test_single_leaf_is_parenthesized(self, catalog, alias_map):
        sql = render_filter_tree(LEAF_PROC_EQ, catalog, alias_map, ["expense_detail"])
        assert sql == "(ed.PROC_CD = '99291')"

    def test_flat_list_is_implicit_and(self, catalog, alias_map):
        sql = render_filter_tree([LEAF_DRG_IN, LEAF_PROC_EQ], catalog, alias_map, ["expense_detail"])
        assert sql == "((ed.DRG_CD IN ('470', '483')) AND (ed.PROC_CD = '99291'))"

    def test_explicit_or_group(self, catalog, alias_map):
        node = {"logic": "OR", "conditions": [LEAF_PROC_EQ, LEAF_INNET_EQ]}
        sql = render_filter_tree(node, catalog, alias_map, ["expense_detail"])
        assert sql == "((ed.PROC_CD = '99291') OR (ed.IN_NTWK_IND = 'Y'))"

    def test_nested_and_or(self, catalog, alias_map):
        sql = render_filter_tree(NESTED_TREE, catalog, alias_map, ["expense_detail"])
        assert sql == (
            "((ed.DRG_CD IN ('470', '483')) AND "
            "((ed.PROC_CD = '99291') OR (ed.IN_NTWK_IND = 'Y')))"
        )

    def test_empty_group_raises(self, catalog, alias_map):
        with pytest.raises(ValueError):
            render_filter_tree({"logic": "AND", "conditions": []}, catalog, alias_map, ["expense_detail"])

    def test_bad_logic_raises(self, catalog, alias_map):
        node = {"logic": "XOR", "conditions": [LEAF_PROC_EQ]}
        with pytest.raises(ValueError):
            render_filter_tree(node, catalog, alias_map, ["expense_detail"])

    def test_depth_limit_raises(self, catalog, alias_map):
        # Nest AND groups past _MAX_FILTER_DEPTH (6).
        node: dict = LEAF_PROC_EQ
        for _ in range(8):
            node = {"logic": "AND", "conditions": [node]}
        with pytest.raises(ValueError):
            render_filter_tree(node, catalog, alias_map, ["expense_detail"])

    def test_sql_injection_value_is_escaped(self, catalog, alias_map):
        node = {"field": "drg_code", "operator": "=", "value": "O'Brien"}
        sql = render_filter_tree(node, catalog, alias_map, ["expense_detail"])
        # Single quote is doubled (escaped); no un-escaped quote survives.
        assert sql == "(ed.DRG_CD = 'O''Brien')"


class TestCollectFilterFields:
    def test_nested_collects_all_leaf_fields_in_order(self):
        assert collect_filter_fields(NESTED_TREE) == [
            "drg_code",
            "procedure_code",
            "in_network_indicator",
        ]

    def test_flat_list(self):
        assert collect_filter_fields([LEAF_DRG_IN, LEAF_PROC_EQ]) == ["drg_code", "procedure_code"]

    def test_fieldless_leaf_skipped(self):
        # A named_filter-style leaf carries no 'field' and contributes nothing.
        assert collect_filter_fields({"operator": "named_filter", "value": "x"}) == []


class TestCollectFilterLeaves:
    def test_nested_collects_all_leaf_dicts_in_order(self):
        assert collect_filter_leaves(NESTED_TREE) == [
            LEAF_DRG_IN,
            LEAF_PROC_EQ,
            LEAF_INNET_EQ,
        ]

    def test_flat_list(self):
        assert collect_filter_leaves([LEAF_DRG_IN, LEAF_PROC_EQ]) == [
            LEAF_DRG_IN,
            LEAF_PROC_EQ,
        ]

    def test_single_leaf(self):
        assert collect_filter_leaves(LEAF_PROC_EQ) == [LEAF_PROC_EQ]

    def test_fieldless_leaf_skipped(self):
        # A named_filter-style leaf carries no 'field' and is skipped (nothing
        # to key on) — matches collect_filter_fields' contract.
        assert collect_filter_leaves({"operator": "named_filter", "value": "x"}) == []

    def test_empty_returns_empty(self):
        assert collect_filter_leaves([]) == []


# ==========================================================================
# resolve_semantic_model_path (security)
# ==========================================================================

class TestResolveSemanticModelPath:
    def test_valid_relative_path_within_allowed_dir(self):
        resolved = resolve_semantic_model_path(OON_YAML_REL)
        assert Path(resolved).exists()
        assert Path(resolved).name.endswith(".yaml")

    def test_path_outside_allowed_dir_rejected(self):
        # error_cls injection: the low-level module raises the type we pass.
        with pytest.raises(RuntimeError):
            resolve_semantic_model_path("../../secret.yaml", error_cls=RuntimeError)

    def test_nonexistent_within_allowed_dir_rejected(self):
        with pytest.raises(ValueError):
            resolve_semantic_model_path(
                "configs/correlation_pattern/__does_not_exist__.yaml"
            )

    def test_none_without_default_rejected(self):
        with pytest.raises(ValueError):
            resolve_semantic_model_path(None, default_path=None)


# ==========================================================================
# FROM-clause + field resolution sanity
# ==========================================================================

def test_from_clause_single_table(catalog, alias_map):
    from_clause = build_from_clause(catalog, ["expense_detail"], "expense_detail", alias_map)
    assert from_clause == "FROM DB.SCH.CLAIMS ed"
    # resolve_field returns the physical expr the projection/filters rely on.
    assert resolve_field(catalog, "drg_code")["expr"] == "DRG_CD"


# ==========================================================================
# build_period_filter_leaves (snap + incurred period leaves)
# ==========================================================================

class TestBuildPeriodFilterLeaves:
    def test_snap_only(self):
        leaves = build_period_filter_leaves(snap_month=202606)
        assert leaves == [{"field": "snap_month", "operator": "=", "value": 202606}]

    def test_incurred_window_between(self):
        leaves = build_period_filter_leaves(incurred_start=202601, incurred_end=202606)
        assert leaves == [
            {"field": "incurred_month", "operator": "between", "value": "202601 and 202606"}
        ]

    def test_snap_and_incurred_window(self):
        leaves = build_period_filter_leaves(
            snap_month=202606, incurred_start=202601, incurred_end=202606
        )
        assert leaves == [
            {"field": "snap_month", "operator": "=", "value": 202606},
            {"field": "incurred_month", "operator": "between", "value": "202601 and 202606"},
        ]

    def test_single_incurred_bound_uses_inequality(self):
        assert build_period_filter_leaves(incurred_start=202601) == [
            {"field": "incurred_month", "operator": ">=", "value": 202601}
        ]
        assert build_period_filter_leaves(incurred_end=202606) == [
            {"field": "incurred_month", "operator": "<=", "value": 202606}
        ]

    def test_none_inputs_yield_no_leaves(self):
        assert build_period_filter_leaves() == []

    def test_custom_logical_field_names(self):
        leaves = build_period_filter_leaves(
            snap_month=202606,
            incurred_start=202601,
            incurred_end=202606,
            snap_field="snap_alt",
            incurred_field="incurred_alt",
        )
        assert leaves[0]["field"] == "snap_alt"
        assert leaves[1]["field"] == "incurred_alt"


# ==========================================================================
# combine_filter_trees_and (AND-merge base tree + period leaves)
# ==========================================================================

class TestCombineFilterTreesAnd:
    def test_none_and_empty_return_none(self):
        assert combine_filter_trees_and(None, []) is None
        assert combine_filter_trees_and() is None

    def test_single_leaf_returned_unwrapped(self):
        assert combine_filter_trees_and(None, [LEAF_PROC_EQ]) == LEAF_PROC_EQ

    def test_base_tree_alone_returned_unwrapped(self):
        assert combine_filter_trees_and(LEAF_DRG_IN, []) == LEAF_DRG_IN

    def test_base_tree_anded_with_period_leaves(self):
        base = {"logic": "AND", "conditions": [LEAF_DRG_IN, LEAF_PROC_EQ]}
        period = build_period_filter_leaves(snap_month=202606)
        combined = combine_filter_trees_and(base, period)
        # A top-level AND base is flattened, not double-nested.
        assert combined["logic"] == "AND"
        assert combined["conditions"] == [
            LEAF_DRG_IN,
            LEAF_PROC_EQ,
            {"field": "snap_month", "operator": "=", "value": 202606},
        ]

    def test_or_base_preserved_as_group(self):
        or_base = {"logic": "OR", "conditions": [LEAF_PROC_EQ, LEAF_INNET_EQ]}
        period = build_period_filter_leaves(snap_month=202606)
        combined = combine_filter_trees_and(or_base, period)
        # The OR group is kept intact as one conjunct (not flattened).
        assert combined["logic"] == "AND"
        assert combined["conditions"][0] == or_base
        assert combined["conditions"][1] == {
            "field": "snap_month", "operator": "=", "value": 202606,
        }

    def test_combined_tree_renders_to_sql(self, catalog, alias_map):
        base = {"logic": "AND", "conditions": [LEAF_DRG_IN]}
        period = [{"field": "procedure_code", "operator": "=", "value": "99291"}]
        combined = combine_filter_trees_and(base, period)
        sql = render_filter_tree(combined, catalog, alias_map, ["expense_detail"])
        assert sql == "((ed.DRG_CD IN ('470', '483')) AND (ed.PROC_CD = '99291'))"
