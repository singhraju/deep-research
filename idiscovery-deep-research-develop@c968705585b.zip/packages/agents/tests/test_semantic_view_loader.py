"""Tests for the two-file (schema + logic) semantic-view merge loader
(:func:`deep_research_utils.semantic_sql.load_semantic_view`).

A semantic view may be authored as one legacy file or split into a Layer-1
(schema: ``tables`` / ``relationships``) file plus a sibling Layer-2
(logic: ``metrics`` / ``analysis_modes`` / ``calculations`` ...) file. These
tests are pure filesystem/dict assertions -- no live Snowflake / LLM.

Coverage:
  * legacy single file returns unchanged
  * ``_logic`` sibling convention is merged
  * explicit ``logic_ref`` pointer is honored (and wins over convention)
  * layer ownership: schema keys from Layer 1, analytic keys from Layer 2
  * merged dict feeds ``build_semantic_catalog`` identically to a single file
"""

from __future__ import annotations

import textwrap

import yaml

from deep_research_utils.semantic_sql import (
    build_semantic_catalog,
    load_semantic_view,
)


# ==========================================================================
# Fixtures / helpers
# ==========================================================================

def _schema_doc() -> dict:
    return {
        "name": "test_view",
        "description": "schema layer",
        "tables": [
            {
                "name": "claims",
                "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                "dimensions": [
                    {"name": "state_code", "expr": "ST_CD", "data_type": "string"},
                ],
                "facts": [
                    {"name": "paid_amount", "expr": "PAID_AMT", "data_type": "number"},
                ],
            },
        ],
        "relationships": [],
    }


def _logic_doc() -> dict:
    return {
        "metrics": [
            {"name": "total_paid", "expr": "SUM({claims.paid_amount})"},
        ],
        "analysis_modes": {"topk": {"dimension": "state_code"}},
        "calculations": {
            "provider_topk": {
                "type": "topk",
                "dimension": "state_code",
                "metric": "total_paid",
            }
        },
    }


def _single_doc() -> dict:
    merged = dict(_schema_doc())
    merged.update(_logic_doc())
    return merged


def _write(path, doc) -> str:
    path.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
    return str(path)


# ==========================================================================
# Back-compat
# ==========================================================================

def test_legacy_single_file_returned_unchanged(tmp_path):
    single = _single_doc()
    path = _write(tmp_path / "view.yaml", single)
    loaded = load_semantic_view(path)
    assert loaded == single


# ==========================================================================
# Two-file merge
# ==========================================================================

def test_logic_sibling_convention_is_merged(tmp_path):
    schema_path = _write(tmp_path / "view.yaml", _schema_doc())
    _write(tmp_path / "view_logic.yaml", _logic_doc())

    merged = load_semantic_view(schema_path)

    # schema-owned keys from Layer 1
    assert merged["name"] == "test_view"
    assert merged["description"] == "schema layer"
    assert [t["name"] for t in merged["tables"]] == ["claims"]
    # analytic keys from Layer 2
    assert merged["metrics"][0]["name"] == "total_paid"
    assert "provider_topk" in merged["calculations"]
    assert merged["analysis_modes"]["topk"]["dimension"] == "state_code"


def test_logic_ref_pointer_is_honored(tmp_path):
    schema = _schema_doc()
    schema["logic_ref"] = "custom_logic.yaml"
    schema_path = _write(tmp_path / "view.yaml", schema)
    _write(tmp_path / "custom_logic.yaml", _logic_doc())

    merged = load_semantic_view(schema_path)
    assert "provider_topk" in merged["calculations"]


def test_logic_ref_wins_over_convention(tmp_path):
    schema = _schema_doc()
    schema["logic_ref"] = "custom_logic.yaml"
    schema_path = _write(tmp_path / "view.yaml", schema)
    # convention sibling exists but points at the wrong logic
    _write(tmp_path / "view_logic.yaml", {"calculations": {"WRONG": {"type": "topk"}}})
    _write(tmp_path / "custom_logic.yaml", _logic_doc())

    merged = load_semantic_view(schema_path)
    assert "provider_topk" in merged["calculations"]
    assert "WRONG" not in merged["calculations"]


def test_missing_logic_ref_falls_back_to_schema_only(tmp_path):
    schema = _schema_doc()
    schema["logic_ref"] = "does_not_exist.yaml"
    schema_path = _write(tmp_path / "view.yaml", schema)

    merged = load_semantic_view(schema_path)
    # no sibling, dangling pointer -> schema returned as-is
    assert "calculations" not in merged
    assert merged["tables"][0]["name"] == "claims"


def test_merged_catalog_matches_single_file(tmp_path):
    # Two-file split
    schema_path = _write(tmp_path / "view.yaml", _schema_doc())
    _write(tmp_path / "view_logic.yaml", _logic_doc())
    merged = load_semantic_view(schema_path)

    # Equivalent single file
    single_path = _write(tmp_path / "single.yaml", _single_doc())
    single = load_semantic_view(single_path)

    cat_merged = build_semantic_catalog(merged)
    cat_single = build_semantic_catalog(single)

    assert cat_merged["tables"].keys() == cat_single["tables"].keys()
    assert cat_merged["metrics_by_name"].keys() == cat_single["metrics_by_name"].keys()
    assert "total_paid" in cat_merged["metrics_by_name"]


# ==========================================================================
# Reverse resolution: the LOGIC layer addressed directly
# ==========================================================================
#
# A request may name either half of a two-file view. Given a Layer-2 path the
# loader resolves Layer 1 from `schema_ref`, else by stripping the `_logic`
# suffix, and merges to the same dict a Layer-1 path would produce.

import pytest


def test_logic_layer_path_resolves_schema_by_convention(tmp_path):
    _write(tmp_path / "view.yaml", _schema_doc())
    logic_path = _write(tmp_path / "view_logic.yaml", _logic_doc())

    merged = load_semantic_view(logic_path)

    assert merged["name"] == "test_view"
    assert [t["name"] for t in merged["tables"]] == ["claims"]
    assert "provider_topk" in merged["calculations"]


def test_logic_layer_path_honors_schema_ref(tmp_path):
    logic = _logic_doc()
    logic["schema_ref"] = "renamed_schema.yaml"
    logic_path = _write(tmp_path / "anything_logic.yaml", logic)
    _write(tmp_path / "renamed_schema.yaml", _schema_doc())

    merged = load_semantic_view(logic_path)
    assert [t["name"] for t in merged["tables"]] == ["claims"]
    assert "provider_topk" in merged["calculations"]


def test_schema_ref_wins_over_convention(tmp_path):
    logic = _logic_doc()
    logic["schema_ref"] = "real_schema.yaml"
    logic_path = _write(tmp_path / "view_logic.yaml", logic)
    # a convention sibling exists but points at the wrong schema
    wrong = _schema_doc()
    wrong["name"] = "WRONG"
    _write(tmp_path / "view.yaml", wrong)
    _write(tmp_path / "real_schema.yaml", _schema_doc())

    merged = load_semantic_view(logic_path)
    assert merged["name"] == "test_view"


def test_either_layer_path_yields_the_same_model(tmp_path):
    schema_path = _write(tmp_path / "view.yaml", _schema_doc())
    logic_path = _write(tmp_path / "view_logic.yaml", _logic_doc())

    assert load_semantic_view(schema_path) == load_semantic_view(logic_path)


def test_unresolvable_logic_layer_raises(tmp_path):
    """The failure that used to be silent: a logic layer with no schema half
    yielded a model with no `tables`, and every table lookup downstream failed
    far from the real cause."""
    logic_path = _write(tmp_path / "orphan_logic.yaml", _logic_doc())

    with pytest.raises(ValueError, match="Layer-1 .schema. file could not be resolved"):
        load_semantic_view(logic_path)


def test_schema_ref_is_not_carried_into_the_merged_model(tmp_path):
    logic = _logic_doc()
    logic["schema_ref"] = "view.yaml"
    logic_path = _write(tmp_path / "view_logic.yaml", logic)
    _write(tmp_path / "view.yaml", _schema_doc())

    merged = load_semantic_view(logic_path)
    assert "schema_ref" not in merged


def test_empty_file_is_not_mistaken_for_a_logic_layer(tmp_path):
    """`_is_logic_layer` is deliberately narrow: a garbage file must fail the
    ordinary way, not with a confusing 'cannot resolve Layer 1'."""
    path = _write(tmp_path / "empty.yaml", {"name": "nothing"})
    assert load_semantic_view(path) == {"name": "nothing"}
