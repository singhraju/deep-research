"""Unit tests for the ``deep_research_utils.topk_sql`` top-K ranking builder.

Covers ``build_topk_query_sql`` — the pure, agent-independent SQL composer that
turns a semantic model + (dimension, metric, top_k, filters) into a single-table
``SELECT … GROUP BY … ORDER BY … LIMIT`` ranking query:
  * default shape (provider_taxonomy_type by total_paid, LIMIT 10),
  * metric resolution (bare vs fully-qualified name),
  * custom dimension / top_k / ascending direction,
  * nested AND/OR filters → WHERE (+ SQL-injection escaping via semantic_sql),
  * fail-fast ValueErrors (unknown dimension, unknown metric, bad top_k,
    cross-table metric),
  * returned metadata dict + explicit-catalog reuse.

Uses a minimal in-memory model so the tests don't depend on the on-disk YAML;
physical exprs are chosen so expense_detail's alias is ``ed`` (the design's
worked example).
"""

from __future__ import annotations

import pytest

from deep_research_utils.semantic_sql import (
    build_filter_tree_from_cards,
    build_group_scope_filter_tree,
    build_period_filter_leaves,
    build_semantic_catalog,
    collect_pattern_scope_cards,
    combine_filter_trees_and,
)
from deep_research_utils.topk_sql import (
    DEFAULT_DIMENSION,
    DEFAULT_METRIC,
    build_topk_query_sql,
)


# ==========================================================================
# Fixtures / helpers
# ==========================================================================

def _semantic_model() -> dict:
    """Two-table claims/membership view.

    ``expense_detail`` (alias ``ed``) carries the taxonomy dimension + the
    single-table metrics; ``membership`` (alias ``m``) carries its own dimension
    (``member_lob_code``) and a fact, and is joined to ``expense_detail`` by the
    ``ed_to_mbr`` relationship. It serves two purposes: grouping a
    ``membership`` dimension by an ``expense_detail`` metric exercises the
    cross-table (joined-dimension) path, and the top-level ``pmpm`` metric —
    which spans both tables — exercises the multi-table-metric guard.
    """
    return {
        "name": "test_topk_view",
        "tables": [
            {
                "name": "expense_detail",
                "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                "dimensions": [
                    {"name": "provider_taxonomy_type", "expr": "PROV_TXNMY_TYPE_NM", "data_type": "string"},
                    {"name": "lob_code", "expr": "LOB_CD", "data_type": "string"},
                    {"name": "service_area_state", "expr": "SRVCAREA_ST_CD", "data_type": "string"},
                ],
                "time_dimensions": [
                    {"name": "snap_month", "expr": "SNAP_YEAR_MNTH_NBR", "data_type": "number"},
                    {"name": "incurred_month", "expr": "INCRD_YEAR_MNTH_NBR", "data_type": "number"},
                ],
                "facts": [
                    {"name": "paid_amount", "expr": "PAID_AMT", "data_type": "number"},
                    {"name": "allowed_amount", "expr": "ALWD_AMT", "data_type": "number"},
                    {"name": "claim_number", "expr": "CLM_NBR", "data_type": "string"},
                ],
                "metrics": [
                    {"name": "expense_detail.total_paid", "expr": "SUM({expense_detail.paid_amount})"},
                    {"name": "expense_detail.total_allowed", "expr": "SUM({expense_detail.allowed_amount})"},
                    {"name": "expense_detail.claim_count", "expr": "COUNT(DISTINCT {expense_detail.claim_number})"},
                ],
            },
            {
                "name": "membership",
                "base_table": {"database": "DB", "schema": "SCH", "table": "MEMBERSHIP"},
                "dimensions": [
                    {"name": "member_lob_code", "expr": "MBR_LOB_CD", "data_type": "string"},
                ],
                "facts": [
                    {"name": "member_months", "expr": "MBR_MO", "data_type": "number"},
                ],
            },
        ],
        # Top-level cross-table metric — spans expense_detail + membership.
        "metrics": [
            {
                "name": "pmpm",
                "expr": "SUM({expense_detail.paid_amount}) / NULLIF(SUM({membership.member_months}), 0)",
            },
        ],
        # Join so a membership dimension can be ranked by an expense_detail metric.
        "relationships": [
            {
                "name": "ed_to_mbr",
                "left_table": "expense_detail",
                "right_table": "membership",
                "relationship_columns": [
                    {"left_column": "LOB_CD", "right_column": "MBR_LOB_CD"},
                ],
            },
        ],
    }


@pytest.fixture(scope="module")
def catalog() -> dict:
    return build_semantic_catalog(_semantic_model())


# Filter-tree fixtures
LEAF_LOB = {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}
LEAF_STATE = {"field": "service_area_state", "operator": "in", "value": ["CA", "NY"]}
NESTED_TREE = {
    "logic": "AND",
    "conditions": [LEAF_LOB, {"logic": "OR", "conditions": [LEAF_STATE]}],
}


# ==========================================================================
# Default / happy path
# ==========================================================================

class TestDefaultQuery:
    def test_default_shape(self):
        built = build_topk_query_sql(_semantic_model())
        sql = built["sql"]
        assert "SELECT ed.PROV_TXNMY_TYPE_NM AS provider_taxonomy_type," in sql
        assert "SUM(ed.PAID_AMT) AS total_paid" in sql
        assert "FROM DB.SCH.CLAIMS ed" in sql
        assert "GROUP BY ed.PROV_TXNMY_TYPE_NM" in sql
        assert "ORDER BY SUM(ed.PAID_AMT) DESC" in sql
        assert sql.rstrip().endswith("LIMIT 10")
        # No filters → no WHERE.
        assert "WHERE" not in sql

    def test_defaults_match_module_constants(self):
        # The builder's defaults are the exported constants the agent reuses.
        assert DEFAULT_DIMENSION == "provider_taxonomy_type"
        assert DEFAULT_METRIC == "total_paid"

    def test_returned_metadata(self):
        built = build_topk_query_sql(_semantic_model(), top_k=25)
        assert built["dimension"] == "provider_taxonomy_type"
        assert built["metric"] == "expense_detail.total_paid"  # fully-qualified
        assert built["metric_alias"] == "total_paid"
        assert built["table"] == "expense_detail"
        # Single-table ranking: driver, dimension, and the full table set agree.
        assert built["dimension_table"] == "expense_detail"
        assert built["tables"] == ["expense_detail"]
        assert built["top_k"] == 25
        assert built["descending"] is True
        assert built["has_filters"] is False


# ==========================================================================
# Metric resolution
# ==========================================================================

class TestMetricResolution:
    def test_bare_and_full_name_equivalent(self, catalog):
        bare = build_topk_query_sql(_semantic_model(), metric="total_paid", catalog=catalog)
        full = build_topk_query_sql(
            _semantic_model(), metric="expense_detail.total_paid", catalog=catalog
        )
        assert bare["sql"] == full["sql"]
        assert bare["metric"] == full["metric"] == "expense_detail.total_paid"

    def test_other_metric(self, catalog):
        built = build_topk_query_sql(_semantic_model(), metric="claim_count", catalog=catalog)
        assert "COUNT(DISTINCT ed.CLM_NBR) AS claim_count" in built["sql"]
        assert "ORDER BY COUNT(DISTINCT ed.CLM_NBR) DESC" in built["sql"]

    def test_unknown_metric_raises_listing_available(self, catalog):
        with pytest.raises(ValueError) as exc:
            build_topk_query_sql(_semantic_model(), metric="not_a_metric", catalog=catalog)
        msg = str(exc.value)
        assert "not_a_metric" in msg
        assert "total_paid" in msg  # available metrics are listed

    def test_multi_table_metric_rejected(self, catalog):
        # pmpm depends on BOTH expense_detail and membership; a metric spanning
        # multiple tables needs aggregate-then-join (CTE mode), not a flat GROUP BY.
        with pytest.raises(ValueError) as exc:
            build_topk_query_sql(_semantic_model(), metric="pmpm", catalog=catalog)
        assert "single-table" in str(exc.value)


# ==========================================================================
# Cross-table ranking: dimension on a table joined to the metric's fact table
# ==========================================================================

class TestCrossTableRanking:
    def test_joined_dimension_left_joins_from_fact(self, catalog):
        # Rank a MEMBERSHIP dimension (member_lob_code) by an EXPENSE_DETAIL
        # metric (total_paid): the fact table drives, the dimension table is
        # LEFT JOIN-ed in via the declared ed_to_mbr relationship.
        built = build_topk_query_sql(
            _semantic_model(), dimension="member_lob_code", metric="total_paid", catalog=catalog
        )
        sql = built["sql"]
        assert "SELECT m.MBR_LOB_CD AS member_lob_code," in sql
        assert "SUM(ed.PAID_AMT) AS total_paid" in sql
        # FROM the fact table, LEFT JOIN the dimension table on the declared keys.
        assert "FROM DB.SCH.CLAIMS ed" in sql
        assert "LEFT JOIN DB.SCH.MEMBERSHIP m ON ed.LOB_CD = m.MBR_LOB_CD" in sql
        assert "GROUP BY m.MBR_LOB_CD" in sql
        assert "ORDER BY SUM(ed.PAID_AMT) DESC" in sql

    def test_cross_table_metadata(self, catalog):
        built = build_topk_query_sql(
            _semantic_model(), dimension="member_lob_code", metric="total_paid", catalog=catalog
        )
        # The driver ("table") is the fact table that owns the metric; the
        # dimension_table is the joined table; "tables" lists both, fact first.
        assert built["table"] == "expense_detail"
        assert built["dimension_table"] == "membership"
        assert built["tables"] == ["expense_detail", "membership"]

    def test_filter_on_joined_dimension_table_resolves(self, catalog):
        # A filter field that lives on the joined dimension table is valid now
        # that the table is part of the query.
        built = build_topk_query_sql(
            _semantic_model(),
            dimension="member_lob_code",
            metric="total_paid",
            filters={"field": "member_lob_code", "operator": "=", "value": "MCM003"},
            catalog=catalog,
        )
        assert built["has_filters"] is True
        assert "WHERE" in built["sql"]
        assert "m.MBR_LOB_CD = 'MCM003'" in built["sql"]

    def test_dimension_with_no_relationship_to_metric_rejected(self):
        # A dimension on a table that has NO declared relationship to the
        # metric's table cannot be ranked — clear ValueError, not a bad join.
        model = {
            "name": "isolated_view",
            "tables": [
                {
                    "name": "expense_detail",
                    "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                    "dimensions": [
                        {"name": "lob_code", "expr": "LOB_CD", "data_type": "string"},
                    ],
                    "facts": [
                        {"name": "paid_amount", "expr": "PAID_AMT", "data_type": "number"},
                    ],
                    "metrics": [
                        {"name": "expense_detail.total_paid", "expr": "SUM({expense_detail.paid_amount})"},
                    ],
                },
                {
                    "name": "orphan",
                    "base_table": {"database": "DB", "schema": "SCH", "table": "ORPHAN"},
                    "dimensions": [
                        {"name": "orphan_key", "expr": "ORPHAN_KEY", "data_type": "string"},
                    ],
                },
            ],
            # No relationships declared.
        }
        with pytest.raises(ValueError) as exc:
            build_topk_query_sql(model, dimension="orphan_key", metric="total_paid")
        msg = str(exc.value)
        assert "no relationship is declared" in msg
        assert "orphan" in msg


# ==========================================================================
# Dimension / top_k / direction
# ==========================================================================

class TestDimensionAndLimit:
    def test_custom_dimension(self, catalog):
        built = build_topk_query_sql(_semantic_model(), dimension="lob_code", catalog=catalog)
        assert "SELECT ed.LOB_CD AS lob_code," in built["sql"]
        assert "GROUP BY ed.LOB_CD" in built["sql"]
        assert built["dimension"] == "lob_code"

    def test_top_k_becomes_limit(self, catalog):
        built = build_topk_query_sql(_semantic_model(), top_k=5, catalog=catalog)
        assert built["sql"].rstrip().endswith("LIMIT 5")
        assert built["top_k"] == 5

    def test_ascending_direction(self, catalog):
        built = build_topk_query_sql(_semantic_model(), descending=False, catalog=catalog)
        assert "ORDER BY SUM(ed.PAID_AMT) ASC" in built["sql"]
        assert built["descending"] is False

    def test_unknown_dimension_raises(self, catalog):
        with pytest.raises(ValueError) as exc:
            build_topk_query_sql(_semantic_model(), dimension="not_a_dim", catalog=catalog)
        assert "not_a_dim" in str(exc.value)

    @pytest.mark.parametrize("bad", [0, -1, -100])
    def test_non_positive_top_k_raises(self, catalog, bad):
        with pytest.raises(ValueError):
            build_topk_query_sql(_semantic_model(), top_k=bad, catalog=catalog)

    def test_non_integer_top_k_raises(self, catalog):
        with pytest.raises(ValueError):
            build_topk_query_sql(_semantic_model(), top_k="lots", catalog=catalog)


# ==========================================================================
# Filters
# ==========================================================================

class TestFilters:
    def test_single_leaf_where(self, catalog):
        built = build_topk_query_sql(_semantic_model(), filters=LEAF_LOB, catalog=catalog)
        assert "WHERE (ed.LOB_CD = 'COMMERCIAL')" in built["sql"]
        assert built["has_filters"] is True

    def test_nested_and_or_where(self, catalog):
        built = build_topk_query_sql(_semantic_model(), filters=NESTED_TREE, catalog=catalog)
        sql = built["sql"]
        assert "WHERE (" in sql
        assert "ed.LOB_CD = 'COMMERCIAL'" in sql
        assert "ed.SRVCAREA_ST_CD IN ('CA', 'NY')" in sql
        # WHERE sits between FROM and GROUP BY.
        assert sql.index("FROM") < sql.index("WHERE") < sql.index("GROUP BY")

    def test_empty_filter_omits_where(self, catalog):
        for empty in (None, [], {"logic": "AND", "conditions": []}):
            built = build_topk_query_sql(_semantic_model(), filters=empty, catalog=catalog)
            assert "WHERE" not in built["sql"]
            assert built["has_filters"] is False

    def test_filter_value_is_escaped(self, catalog):
        node = {"field": "lob_code", "operator": "=", "value": "O'Brien"}
        built = build_topk_query_sql(_semantic_model(), filters=node, catalog=catalog)
        # Single quote doubled by semantic_sql escaping; no un-escaped quote.
        assert "ed.LOB_CD = 'O''Brien'" in built["sql"]

    def test_period_scoping_snap_and_incurred_window(self, catalog):
        # ETL / orchestrator path: provider-scope base tree ANDed with the
        # snap (exact) + incurred (current-window) period leaves. Both period
        # columns live on the driving expense_detail table (no join needed) and
        # render as numeric (unquoted) comparisons.
        base = LEAF_LOB  # stands in for the provider-scope tree
        period = build_period_filter_leaves(
            snap_month=202606, incurred_start=202601, incurred_end=202606
        )
        tree = combine_filter_trees_and(base, period)
        built = build_topk_query_sql(_semantic_model(), filters=tree, catalog=catalog)
        sql = built["sql"]
        assert built["has_filters"] is True
        # Snap: exact numeric equality on the physical snap column.
        assert "ed.SNAP_YEAR_MNTH_NBR = 202606" in sql
        # Incurred: numeric BETWEEN window on the physical incurred column.
        assert "ed.INCRD_YEAR_MNTH_NBR BETWEEN 202601 AND 202606" in sql
        # Provider scope is preserved alongside the period leaves.
        assert "ed.LOB_CD = 'COMMERCIAL'" in sql
        # Everything lands in one WHERE between FROM and GROUP BY.
        assert sql.index("FROM") < sql.index("WHERE") < sql.index("GROUP BY")


# ==========================================================================
# Catalog reuse
# ==========================================================================

def test_explicit_catalog_is_used(catalog):
    # Passing a prebuilt catalog must produce the same SQL as building internally.
    from_internal = build_topk_query_sql(_semantic_model())
    from_explicit = build_topk_query_sql(_semantic_model(), catalog=catalog)
    assert from_internal["sql"] == from_explicit["sql"]


# ==========================================================================
# Card -> filter-tree converter (build_filter_tree_from_cards)
# ==========================================================================
#
# The caller-owned adapter that turns a business pattern's source cards (each a
# flat AND of ``{field, operator, value, source}`` leaves) into ONE nested
# AND/OR tree, so a single top-K ranking scores the true combined population
# (OR-of-AND across cards) instead of merging independently LIMIT-k-truncated
# per-card rankings. These tests pin the tree algebra and then round-trip a
# two-card tree through ``build_topk_query_sql`` to prove it renders as one
# OR-of-AND WHERE clause.

def _card(card_id, filters):
    return {"card_id": card_id, "filters": filters}


class TestBuildFilterTreeFromCards:
    def test_single_card_is_bare_and_group_source_stripped(self):
        card = _card("c1", [
            {"field": "lob_code", "operator": "=", "value": "COMMERCIAL", "source": "drill"},
            {"field": "service_area_state", "operator": "in", "value": ["CA", "NY"], "source": "drill"},
        ])
        tree = build_filter_tree_from_cards([card])
        # Single card -> its AND group, no redundant OR wrapper.
        assert tree == {
            "logic": "AND",
            "conditions": [
                {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"},
                {"field": "service_area_state", "operator": "in", "value": ["CA", "NY"]},
            ],
        }
        # Cosmetic `source` is dropped from every leaf.
        assert all("source" not in leaf for leaf in tree["conditions"])

    def test_multi_card_is_or_of_and_order_preserved(self):
        card_a = _card("a", [{"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}])
        card_b = _card("b", [
            {"field": "service_area_state", "operator": "=", "value": "CA"},
            {"field": "lob_code", "operator": "=", "value": "MEDICARE"},
        ])
        tree = build_filter_tree_from_cards([card_a, card_b])
        assert tree["logic"] == "OR"
        # OR-branch order follows card order; within-branch leaf order preserved.
        assert tree["conditions"] == [
            {"logic": "AND", "conditions": [
                {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"},
            ]},
            {"logic": "AND", "conditions": [
                {"field": "service_area_state", "operator": "=", "value": "CA"},
                {"field": "lob_code", "operator": "=", "value": "MEDICARE"},
            ]},
        ]

    def test_zero_filter_card_skipped(self):
        card_a = _card("a", [{"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}])
        empty = _card("b", [])
        no_key = {"card_id": "c"}  # no "filters" key at all
        tree = build_filter_tree_from_cards([card_a, empty, no_key])
        # Only card_a contributes -> collapses to a bare AND group (no OR wrapper).
        assert tree == {
            "logic": "AND",
            "conditions": [{"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}],
        }

    def test_all_empty_returns_none(self):
        assert build_filter_tree_from_cards([]) is None
        assert build_filter_tree_from_cards([_card("a", []), _card("b", [])]) is None
        # Leaves without a `field` contribute nothing -> still None.
        assert build_filter_tree_from_cards([_card("a", [{"operator": "=", "value": "x"}])]) is None

    def test_within_card_and_cross_card_dedup(self):
        # Duplicate leaf inside one card collapses to one; identical AND-groups
        # across cards collapse to one branch.
        card_a = _card("a", [
            {"field": "lob_code", "operator": "=", "value": "COMMERCIAL", "source": "x"},
            {"field": "lob_code", "operator": "=", "value": "COMMERCIAL", "source": "y"},
        ])
        card_b = _card("b", [{"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}])
        tree = build_filter_tree_from_cards([card_a, card_b])
        # Both cards reduce to the same single-leaf AND group -> one branch ->
        # collapses to a bare AND group.
        assert tree == {
            "logic": "AND",
            "conditions": [{"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}],
        }

    def test_same_field_different_value_stays_separate_branches(self):
        card_a = _card("a", [{"field": "lob_code", "operator": "=", "value": "COMMERCIAL"}])
        card_b = _card("b", [{"field": "lob_code", "operator": "=", "value": "MEDICARE"}])
        tree = build_filter_tree_from_cards([card_a, card_b])
        # Same field, different value -> two OR branches, never merged into one IN.
        assert tree["logic"] == "OR"
        assert len(tree["conditions"]) == 2
        values = [branch["conditions"][0]["value"] for branch in tree["conditions"]]
        assert values == ["COMMERCIAL", "MEDICARE"]

    def test_missing_operator_defaults_to_equals(self):
        card = _card("a", [{"field": "lob_code", "value": "COMMERCIAL"}])
        tree = build_filter_tree_from_cards([card])
        assert tree["conditions"][0]["operator"] == "="

    def test_dedup_disabled_keeps_duplicate_leaves(self):
        card = _card("a", [
            {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"},
            {"field": "lob_code", "operator": "=", "value": "COMMERCIAL"},
        ])
        tree = build_filter_tree_from_cards([card], dedup=False)
        assert len(tree["conditions"]) == 2

    def test_round_trips_to_single_or_of_and_where(self, catalog):
        # Two cards -> OR-of-AND -> one parenthesized WHERE with a single top-level OR.
        card_a = _card("a", [
            {"field": "lob_code", "operator": "=", "value": "COMMERCIAL", "source": "drill"},
            {"field": "service_area_state", "operator": "in", "value": ["CA", "NY"], "source": "drill"},
        ])
        card_b = _card("b", [{"field": "lob_code", "operator": "=", "value": "MEDICARE"}])
        tree = build_filter_tree_from_cards([card_a, card_b])

        built = build_topk_query_sql(_semantic_model(), filters=tree, catalog=catalog)
        sql = built["sql"]
        assert built["has_filters"] is True
        # Both card populations rendered into the one WHERE clause.
        assert "ed.LOB_CD = 'COMMERCIAL'" in sql
        assert "ed.SRVCAREA_ST_CD IN ('CA', 'NY')" in sql
        assert "ed.LOB_CD = 'MEDICARE'" in sql
        where = sql[sql.index("WHERE"):sql.index("GROUP BY")]
        # Exactly one top-level OR joins the two card branches; card A's two
        # leaves are AND-ed within its own branch.
        assert where.count(" OR ") == 1
        assert " AND " in where


# ==========================================================================
# Group-scoped filter tree (Plan B: build_group_scope_filter_tree /
# collect_pattern_scope_cards)
# ==========================================================================
#
# The Plan B path scopes a reimbursement top-K ranking by a pattern's *groups*
# (its business scope) instead of only its representative source cards, and
# builds ONE AND-of-INs tree from the group cards' provider-scoping
# ``interaction_cell`` leaves. The clinical ``drill_context`` leaves (DRG /
# diagnosis / procedure / auth) are dropped so they cannot collapse a
# provider-taxonomy ranking to one or two codes.

def _leaf(field, value, source, operator="="):
    return {"field": field, "operator": operator, "value": value, "source": source}


class TestBuildGroupScopeFilterTree:
    def test_keeps_interaction_cell_and_drops_drill_context(self):
        # One card modeled on the OON residential-treatment example: four
        # interaction_cell provider-scoping leaves + four clinical drill_context
        # leaves that would otherwise over-constrain the taxonomy ranking.
        card = _card("c1", [
            _leaf("product_description", "PPO", "interaction_cell"),
            _leaf("facility_type", "RESIDENTIAL TREATMENT CTR", "interaction_cell"),
            _leaf("service_area_state", "ME", "interaction_cell"),
            _leaf("lob_description", "Commercial Individual", "interaction_cell"),
            _leaf("drg_name", "Alcohol/Drug Abuse w/o MCC", "drill_context"),
            _leaf("hcc_medium", "IP BH", "drill_context"),
            _leaf("procedure_name", "Substance Abuse Tx", "drill_context"),
            _leaf("primary_diagnosis_code", "F10239", "drill_context"),
        ])
        tree = build_group_scope_filter_tree([card])
        assert tree == {
            "logic": "AND",
            "conditions": [
                {"field": "product_description", "operator": "=", "value": "PPO"},
                {"field": "facility_type", "operator": "=", "value": "RESIDENTIAL TREATMENT CTR"},
                {"field": "service_area_state", "operator": "=", "value": "ME"},
                {"field": "lob_description", "operator": "=", "value": "Commercial Individual"},
            ],
        }
        # No clinical drill_context field leaks through.
        fields = {leaf["field"] for leaf in tree["conditions"]}
        assert not fields & {"drg_name", "hcc_medium", "procedure_name", "primary_diagnosis_code"}

    def test_collapses_same_field_across_cards_into_in_list(self):
        # Two group cards differing only by state -> one AND group with the
        # state field collapsed to an IN list (not two OR branches).
        card_me = _card("me", [
            _leaf("product_description", "PPO", "interaction_cell"),
            _leaf("service_area_state", "ME", "interaction_cell"),
        ])
        card_ct = _card("ct", [
            _leaf("product_description", "PPO", "interaction_cell"),
            _leaf("service_area_state", "CT", "interaction_cell"),
        ])
        tree = build_group_scope_filter_tree([card_me, card_ct])
        assert tree == {
            "logic": "AND",
            "conditions": [
                {"field": "product_description", "operator": "=", "value": "PPO"},
                {"field": "service_area_state", "operator": "in", "value": ["ME", "CT"]},
            ],
        }

    def test_list_valued_leaf_is_flattened(self):
        card = _card("c1", [
            _leaf("service_area_state", ["ME", "CT"], "interaction_cell", operator="in"),
            _leaf("service_area_state", "NH", "interaction_cell"),
        ])
        tree = build_group_scope_filter_tree([card])
        assert tree["conditions"] == [
            {"field": "service_area_state", "operator": "in", "value": ["ME", "CT", "NH"]},
        ]

    def test_none_value_dropped(self):
        card = _card("c1", [
            _leaf("service_area_state", None, "interaction_cell"),
            _leaf("product_description", "PPO", "interaction_cell"),
        ])
        tree = build_group_scope_filter_tree([card])
        assert tree == {
            "logic": "AND",
            "conditions": [{"field": "product_description", "operator": "=", "value": "PPO"}],
        }

    def test_no_interaction_cell_leaves_returns_none(self):
        # A drill-validation card carrying only clinical leaves contributes
        # nothing -> None (caller ranks unfiltered) rather than an
        # over-constrained clinical-only population.
        card = _card("c1", [
            _leaf("drg_name", "Alcohol/Drug Abuse w/o MCC", "drill_context"),
            _leaf("primary_diagnosis_code", "F10239", "drill_context"),
        ])
        assert build_group_scope_filter_tree([card]) is None
        assert build_group_scope_filter_tree([]) is None

    def test_include_sources_can_admit_drill_context(self):
        card = _card("c1", [
            _leaf("product_description", "PPO", "interaction_cell"),
            _leaf("drg_name", "Alcohol/Drug Abuse w/o MCC", "drill_context"),
        ])
        tree = build_group_scope_filter_tree(
            [card], include_sources=("interaction_cell", "drill_context")
        )
        fields = {leaf["field"] for leaf in tree["conditions"]}
        assert fields == {"product_description", "drg_name"}

    def test_round_trips_to_single_and_where(self, catalog):
        card_me = _card("me", [
            _leaf("lob_code", "COMMERCIAL", "interaction_cell"),
            _leaf("service_area_state", "CA", "interaction_cell"),
        ])
        card_ny = _card("ny", [
            _leaf("lob_code", "COMMERCIAL", "interaction_cell"),
            _leaf("service_area_state", "NY", "interaction_cell"),
        ])
        tree = build_group_scope_filter_tree([card_me, card_ny])
        built = build_topk_query_sql(_semantic_model(), filters=tree, catalog=catalog)
        sql = built["sql"]
        assert built["has_filters"] is True
        assert "ed.LOB_CD = 'COMMERCIAL'" in sql
        assert "ed.SRVCAREA_ST_CD IN ('CA', 'NY')" in sql
        where = sql[sql.index("WHERE"):sql.index("GROUP BY")]
        # One AND group, no OR: the whole group population is one clause.
        assert " OR " not in where
        assert " AND " in where


class TestCollectPatternScopeCards:
    def test_expands_source_groups_to_their_cards(self):
        card_lookup = {cid: _card(cid, []) for cid in ("a", "b", "c")}
        group_lookup = {"g1": {"group_id": "g1", "card_ids": ["a", "b"]}}
        pattern = {"source_group_ids": ["g1"], "source_card_ids": ["a"]}
        cards = collect_pattern_scope_cards(
            pattern, card_lookup=card_lookup, group_lookup=group_lookup
        )
        assert [c["card_id"] for c in cards] == ["a", "b"]

    def test_dedups_cards_shared_across_groups_preserving_order(self):
        card_lookup = {cid: _card(cid, []) for cid in ("a", "b", "c")}
        group_lookup = {
            "g1": {"group_id": "g1", "card_ids": ["a", "b"]},
            "g2": {"group_id": "g2", "card_ids": ["b", "c"]},
        }
        pattern = {"source_group_ids": ["g1", "g2"]}
        cards = collect_pattern_scope_cards(
            pattern, card_lookup=card_lookup, group_lookup=group_lookup
        )
        assert [c["card_id"] for c in cards] == ["a", "b", "c"]

    def test_falls_back_to_source_card_ids_when_no_group_resolves(self):
        card_lookup = {cid: _card(cid, []) for cid in ("a", "b")}
        pattern = {"source_group_ids": ["missing"], "source_card_ids": ["a", "b"]}
        cards = collect_pattern_scope_cards(
            pattern, card_lookup=card_lookup, group_lookup={}
        )
        assert [c["card_id"] for c in cards] == ["a", "b"]

    def test_unresolvable_card_ids_dropped(self):
        card_lookup = {"a": _card("a", [])}
        group_lookup = {"g1": {"group_id": "g1", "card_ids": ["a", "ghost"]}}
        pattern = {"source_group_ids": ["g1"]}
        cards = collect_pattern_scope_cards(
            pattern, card_lookup=card_lookup, group_lookup=group_lookup
        )
        assert [c["card_id"] for c in cards] == ["a"]
