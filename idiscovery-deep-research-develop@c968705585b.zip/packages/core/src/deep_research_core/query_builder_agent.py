"""Intermediate agent base class that turns declarative semantic-view logic
into SQL.

``QueryBuilderAgent`` sits between :class:`AgentBase` and the concrete agents
(``reimbursement``, future customers). It provides three reusable capabilities
so an agent no longer has to hard-code either a customer schema or a single
calculation:

* **Two-layer loading** -- :meth:`_load_semantic_view` uses the Phase-1
  merge-loader (:func:`deep_research_utils.load_semantic_view`) so a schema
  (Layer 1: ``tables`` / ``relationships``) and its logic (Layer 2: ``metrics``
  / ``analysis_modes`` / ``calculations`` / ...) can live in two physical YAML
  files, then feeds the merged dict to ``build_semantic_catalog`` exactly as a
  single legacy file would.
* **Declarative dispatch** -- :meth:`build_calculation` reads a Layer-2
  ``calculations`` entry and switches on its ``type`` to the matching pure
  builder (``topk`` -> ``build_topk_query_sql``; ``cte_pipeline`` ->
  ``build_cte_query_sql``; ``raw_sql`` -> ``build_raw_sql``).
* **Shared execution / persistence** -- :meth:`_execute_to_rows` runs a query to
  JSON-safe rows, and generic ``build_query_node`` / ``run_query_node`` graph
  nodes assemble a result envelope, delegating on-disk artifacts to the
  overridable :meth:`_persist_run` hook (base returns ``None`` -> nothing
  persisted).

Layering: this class lives in ``core`` and may import ``utils`` (the pure
builders); it never imports ``agents``.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple

from deep_research_core.base_agent import AgentBase, AgentConfigurationError

from deep_research_utils.cte_sql import build_cte_query_sql, build_raw_sql
from deep_research_utils.semantic_sql import (
    build_semantic_catalog,
    execute_sql_to_df,
    load_semantic_view,
    resolve_semantic_model_path,
)
from deep_research_utils.topk_sql import DEFAULT_METRIC, build_topk_query_sql

__all__ = ["QueryBuilderAgent"]


class QueryBuilderAgent(AgentBase):
    """Agents that build SQL from declarative semantic-view calculations.

    Subclasses set the class attrs below to declare their defaults, then reuse
    :meth:`_load_semantic_view` / :meth:`build_calculation` (and optionally the
    generic graph nodes) instead of re-implementing loading, dispatch, and
    persistence in agent code.
    """

    #: Name of the ``calculations`` entry used when a request does not name one.
    DEFAULT_CALCULATION: Optional[str] = None
    #: Fallback ranking dimension for ``type: topk`` calculations.
    TOPK_DEFAULT_DIMENSION: Optional[str] = None
    #: Fallback ranking metric for ``type: topk`` calculations.
    TOPK_DEFAULT_METRIC: str = DEFAULT_METRIC

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------
    def _load_semantic_view(
        self,
        yaml_path: Optional[str],
        *,
        allowed_subdir: str = "configs/correlation_pattern",
        default_path: Optional[str] = None,
        error_cls: type = AgentConfigurationError,
    ) -> Tuple[str, Dict[str, Any], Any]:
        """Resolve, merge-load, and catalog a semantic view.

        Returns ``(resolved_path, merged_model, catalog)``. The merge-loader is
        back-compatible: a legacy single YAML (no Layer-2 sibling / ``logic_ref``)
        is returned unchanged, so this is a drop-in replacement for the
        ``resolve_semantic_model_path`` + ``load_semantic_yaml`` +
        ``build_semantic_catalog`` sequence agents call today.
        """
        resolved_path = resolve_semantic_model_path(
            yaml_path,
            allowed_subdir=allowed_subdir,
            default_path=default_path,
            error_cls=error_cls,
        )
        model = load_semantic_view(resolved_path)
        catalog = build_semantic_catalog(model)
        return resolved_path, model, catalog

    # ------------------------------------------------------------------
    # Declarative dispatch
    # ------------------------------------------------------------------
    def build_calculation(
        self,
        model: Dict[str, Any],
        catalog: Any,
        calc_name: Optional[str] = None,
        **overrides: Any,
    ) -> str:
        """Build SQL for one Layer-2 ``calculations`` entry.

        ``calc_name`` selects the entry (falling back to
        :attr:`DEFAULT_CALCULATION`). Non-``None`` ``overrides`` (e.g.
        ``dimension=``, ``metric=``, ``top_k=``, ``filters=``) take precedence
        over the entry's declared values, so a request can steer a calculation
        without editing YAML. Dispatch is on the entry's ``type``:

        * ``topk`` -> :func:`build_topk_query_sql`
        * ``cte_pipeline`` / ``cte`` -> :func:`build_cte_query_sql`
        * ``raw_sql`` -> :func:`build_raw_sql`

        An unknown calculation name or type, or a builder ``ValueError``, is
        surfaced as :class:`AgentConfigurationError` (fail fast before the graph
        runs).
        """
        resolved_name = calc_name or self.DEFAULT_CALCULATION
        calculations_list = model.get("calculations") or []
        
        # Convert list of calculations to dict indexed by name for backward compatibility
        if isinstance(calculations_list, list):
            calculations = {calc.get("name"): calc for calc in calculations_list if calc.get("name")}
        else:
            # Already a dict (old format)
            calculations = calculations_list

        # Capture the caller's filter tree BEFORE the override loop folds it into
        # `spec`. For a cte_pipeline these are two distinct inputs -- the request
        # tree is routed per CTE, while a `filters` key declared on the calculation
        # is that calculation's own predicate -- and conflating them makes a YAML
        # filter masquerade as a request filter.
        request_filter_tree = overrides.get("filters")

        spec: Dict[str, Any]
        if resolved_name is not None:
            if resolved_name not in calculations:
                raise AgentConfigurationError(
                    f"Unknown calculation {resolved_name!r}. Declared: "
                    f"{sorted(calculations.keys())}"
                )
            spec = dict(calculations[resolved_name])
        else:
            # No named calculation: treat overrides as an ad-hoc top-K request.
            spec = {}

        for key, value in overrides.items():
            if value is not None:
                spec[key] = value

        ctype = str(spec.get("type", "topk")).strip() or "topk"

        try:
            if ctype == "topk":
                topk_kwargs: Dict[str, Any] = {
                    "metric": spec.get("metric") or self.TOPK_DEFAULT_METRIC,
                    "top_k": int(spec.get("top_k", 10) or 10),
                    "filters": spec.get("filters"),
                    "catalog": catalog,
                    "descending": bool(spec.get("descending", True)),
                    "filter_values": spec.get("filter_values"),  # NEW
                }
                # Only pass a dimension when one resolves; otherwise let
                # build_topk_query_sql apply its own DEFAULT_DIMENSION.
                resolved_dimension = spec.get("dimension") or self.TOPK_DEFAULT_DIMENSION
                if resolved_dimension:
                    topk_kwargs["dimension"] = resolved_dimension
                built = build_topk_query_sql(model, **topk_kwargs)
                return built["sql"]
            if ctype in ("cte_pipeline", "cte"):
                return build_cte_query_sql(
                    model,
                    spec,
                    catalog=catalog,
                    request_filters=request_filter_tree,  # from the request only
                    filter_values=spec.get("filter_values"),
                )
            if ctype == "raw_sql":
                return build_raw_sql(
                    model,
                    spec,
                    catalog=catalog,
                    filter_values=spec.get("filter_values"),  # NEW
                )
        except ValueError as exc:
            raise AgentConfigurationError(str(exc)) from exc

        raise AgentConfigurationError(
            f"Unknown calculation type {ctype!r} for {resolved_name!r}. "
            "Supported: topk, cte_pipeline, raw_sql."
        )

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------
    def _execute_to_rows(
        self, snowflake_helper: Any, sql: str
    ) -> Tuple[List[Dict[str, Any]], int]:
        """Run ``sql`` and return ``(rows, row_count)`` as JSON-safe records.

        Numpy scalars collapse to native Python, ``NaN`` -> ``null``, datetimes
        -> ISO strings -- the same serialization agents use before returning
        rows in-memory.
        """
        if snowflake_helper is None:
            raise RuntimeError("Snowflake helper is required to run the query.")
        df = execute_sql_to_df(snowflake_helper, sql)
        rows = json.loads(df.to_json(orient="records", date_format="iso"))
        return rows, len(rows)

    # ------------------------------------------------------------------
    # Persistence hook (override in subclasses)
    # ------------------------------------------------------------------
    def _persist_run(
        self,
        state: Dict[str, Any],
        *,
        sql: str,
        meta: Dict[str, Any],
        rows: List[Dict[str, Any]],
        row_count: int,
        truncated: bool,
    ) -> Optional[Tuple[str, Dict[str, str]]]:
        """Persist query + summary artifacts for a run.

        Base implementation persists nothing and returns ``None``. A subclass
        overrides this to write its own artifact layout and returns
        ``(run_dir, artifacts)`` where ``artifacts`` maps logical names to
        run-relative paths; those splice into the result envelope. Rows are
        never persisted here.
        """
        return None

    # ------------------------------------------------------------------
    # Generic graph nodes
    # ------------------------------------------------------------------
    def build_query_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Generic build node: compose SQL for the active calculation.

        Reads ``state['calculation']`` (or :attr:`DEFAULT_CALCULATION`), forwards
        the standard steering overrides, and stores the SQL under
        ``state['query_sql']`` alongside the resolved calculation name.
        """
        model: Dict[str, Any] = state["semantic_model"]
        catalog = state.get("catalog")
        calc_name = state.get("calculation") or self.DEFAULT_CALCULATION

        sql = self.build_calculation(
            model,
            catalog,
            calc_name=calc_name,
            dimension=state.get("dimension"),
            metric=state.get("metric"),
            top_k=state.get("top_k"),
            filters=state.get("filters"),
            filter_values=state.get("filter_values"),  # NEW
        )
        return {"query_sql": sql, "calculation": calc_name}

    def run_query_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Generic run node: execute the built SQL and assemble the envelope.

        Executes ``state['query_sql']``, computes ``row_count`` / ``truncated``
        (a full page for a top-K request means more may rank below), delegates
        artifacts to :meth:`_persist_run`, and returns ``{'query_result': ...}``.
        """
        sql: str = state["query_sql"]
        meta: Dict[str, Any] = state.get("query_meta", {}) or {}
        rows, row_count = self._execute_to_rows(state.get("snowflake_helper"), sql)

        top_k = int(meta.get("top_k") or state.get("top_k", 0) or 0)
        truncated = bool(top_k) and row_count >= top_k

        persisted = self._persist_run(
            state,
            sql=sql,
            meta=meta,
            rows=rows,
            row_count=row_count,
            truncated=truncated,
        )

        result: Dict[str, Any] = {
            "calculation": state.get("calculation") or self.DEFAULT_CALCULATION,
            "query": sql,
            "yaml_path": state.get("yaml_path"),
            "rows": rows,
            "row_count": row_count,
            "truncated": truncated,
        }
        if persisted is not None:
            run_dir, artifacts = persisted
            result["run_dir"] = run_dir
            result["artifacts"] = artifacts

        return {"query_result": result}
