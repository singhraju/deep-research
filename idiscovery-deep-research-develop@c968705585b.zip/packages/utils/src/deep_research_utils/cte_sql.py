"""Config-file-driven CTE (Common Table Expression) query builder.

Builds ``WITH <cte>, <cte> ... SELECT ... FROM <cte> JOIN <cte> ...`` queries
from a declarative ``cte_queries`` block in a semantic YAML model. The driving
use case is a PMPM (Per Member Per Month) calculation: aggregate a claims
population in one CTE and a membership population in another CTE — each with its
own ``GROUP BY`` over shared dimension keys and its own filters — then join the
two *aggregates* and divide numerator/denominator columns to form ratio outputs.

Why CTEs instead of the existing single joined ``GROUP BY`` (``paid_pmpm`` etc.)?
A flat claims-⋈-membership join sums member-months *after* fanning out by claim
lines, double-counting the denominator. Pre-aggregating each side to its grain in
its own CTE and joining the aggregates avoids that fan-out entirely.

This module lives in the lowest-level package (``deep_research_utils``) and, like
:mod:`deep_research_utils.semantic_sql`, MUST NOT import from
``deep_research_core`` or ``deep_research_agents``. It builds *only* on the shared
primitives in :mod:`~deep_research_utils.semantic_sql`.

The one genuinely new mechanism is **dual placeholder resolution**. The same
:func:`~deep_research_utils.semantic_sql.render_expression` engine is fed two
different ``(catalog, alias_map)`` pairs:

* *inside a CTE* — the real catalog + a physical alias map, so
  ``{expense_detail.paid_amount}`` becomes ``ed.ANLYTC_PAID_AMT``;
* *in the final SELECT* — a synthetic catalog where each CTE is a "table" and each
  of its output columns is a "field" whose ``expr`` is the bare column identifier,
  so ``{clm_medical.medical_paid}`` becomes ``clm_medical.medical_paid``.

That is the entire trick that lets ratio expressions reference CTE-result columns
with the same ``{a.b}`` grammar used everywhere else.

Grammar
-------
A ``cte_pipeline`` calculation is ``{ctes: [...], output: {...}}``, optionally with
``shared_filters`` and ``request_filters``.

**Calculation level**::

    shared_filters: <filter tree>     # invariants that hold for every CTE
    request_filters:
      mode: merge | replace           # merge (default) ANDs the caller's tree with
                                      # shared_filters; replace substitutes it
      apply: true | false             # default `apply_request_filters` for all CTEs

**Each CTE**::

    name: <identifier>
    source: <base table | prior CTE>
    alias: <identifier>               # optional; else derived from the name
    distinct: true|false              # SELECT DISTINCT (implies no GROUP BY)
    group_by: true|false              # false = project without collapsing rows
    joins:                            # further base tables and/or prior CTEs
      - type: inner|left|right|full_outer
        table: <base table>           # ... or  cte: <prior CTE>
        alias: <identifier>
        on:
          - <shared field name>       # same logical name on both sides, or:
          - left: <field on an already-joined source>
            right: <field on the joined target>
            left_from: <source>       # optional disambiguator
        condition: "<expr>"           # optional extra predicate
    dimensions:
      - <field name>                  # plain column, grouped by its expression
      - name: <identifier>            # expression dimension (CASE, COALESCE, cast)
        expr: "<expr>"
        group_by: alias|expr|none
    measures:
      - {name: <identifier>, expr: "<aggregate expr>"}
    filters: <filter tree>            # ANDed with the routed shared/request trees
    having: "<expr>"
    semi_join: {cte: <prior CTE>, on: [...]}      # restrict to keys present there
    exists:                           # correlated [NOT] EXISTS
      - negate: true|false
        source: <base table | prior CTE>
        alias: <identifier>
        correlate: [{inner: <field on source>, outer: <field on this CTE>}]
        filters: <filter tree scoped to the subquery source>

**Request-filter routing** (per CTE; precedence most-specific first)::

    apply_request_filters: true|false      # hard on/off
    exclude_filter_fields: [...]           # drop these leaves
    include_filter_fields: [...]           # keep only these leaves
    exclude_filters_for_tables: [...]      # drop leaves owned by these tables
    include_filters_for_tables: [...]      # keep only leaves owned by these tables

Absent every knob, the caller's tree applies to base-table CTEs and not to
CTE-sourced ones -- the behavior this builder had before the knobs existed.

**Output**::

    distinct: true|false
    joins: [{type, left, right, on: [...]}]        # same `on` forms as above
    columns: [{name: <identifier>, expr: "<expr over {cte.column}>"}]
    filters: <filter tree over CTE output columns>  -> WHERE
    apply_request_filters: true|false               # route the caller's tree here too
    group_by: [<output column name> | "<{cte.col} expr>"]
    having: "<expr>"
    order_by: [{column: <output column>, direction: asc|desc} | {expr: "...", ...}]
    limit: <positive int>

Injection safety is unchanged: every identifier this module emits is validated
against :data:`IDENTIFIER_RE`, physical columns arrive only through the catalog,
and filter values are escaped by ``render_filter_tree``.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union

import pandas as pd

from deep_research_utils.semantic_sql import (
    SemanticCatalog,
    build_alias_map,
    build_semantic_catalog,
    ensure_dir,
    execute_sql_to_df,
    extend_catalog_with_filter_values,
    render_expression,
    render_filter_tree,
    resolve_field,
)

# Matches a bare ``{table}`` placeholder (no dotted field) used only by the
# ``raw_sql`` escape hatch to expand a logical table into ``QUALIFIED alias``.
# Dotted ``{table.field}`` placeholders are handled first by ``render_expression``.
_TABLE_PLACEHOLDER_RE = re.compile(r"\{([A-Za-z0-9_]+)\}")

try:  # pragma: no cover - only referenced in a type hint / runtime df helper
    from deep_research_utils.snowflake_helper import SnowparkHelper
except Exception:  # pragma: no cover
    SnowparkHelper = Any  # type: ignore[assignment,misc]


__all__ = [
    "IDENTIFIER_RE",
    "build_cte_query_sql",
    "build_cte_query_sql_by_name",
    "build_raw_sql",
    "run_cte_query",
]


# A SQL identifier we are willing to emit verbatim (CTE names, measure/output
# column aliases, dimension names, join keys). Everything else — physical column
# expressions, filter values — flows through the catalog / escaping helpers.
IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

_JOIN_TYPES = {
    "full_outer": "FULL OUTER JOIN",
    "left": "LEFT JOIN",
    "inner": "INNER JOIN",
    "right": "RIGHT JOIN",
}


def _safe_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def _safe_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _require_identifier(value: str, what: str) -> str:
    value = str(value).strip()
    if not IDENTIFIER_RE.match(value):
        raise ValueError(f"Invalid {what}: {value!r} (must match {IDENTIFIER_RE.pattern})")
    return value


def _is_empty_filter(node: Any) -> bool:
    """True when a filter node contributes no predicate (so no WHERE is emitted)."""
    if node is None:
        return True
    if isinstance(node, (list, tuple)):
        return len(node) == 0
    if isinstance(node, dict):
        if "logic" in node and "conditions" in node:
            return not node.get("conditions")
        return False  # a leaf FilterCondition is always meaningful
    return True


def _merge_filters(*nodes: Any) -> Optional[Any]:
    """AND-merge the non-empty filter nodes into a single node (or None)."""
    present = [node for node in nodes if not _is_empty_filter(node)]
    if not present:
        return None
    if len(present) == 1:
        return present[0]
    return {"logic": "AND", "conditions": present}


def _copy_catalog(catalog: SemanticCatalog) -> SemanticCatalog:
    """Shallow-but-independent copy so synthetic CTE entries never leak into the
    caller's catalog (the same catalog may be reused across builds)."""
    return {
        "tables": dict(catalog["tables"]),
        "fields_by_name": {k: list(v) for k, v in catalog["fields_by_name"].items()},
        "table_fields": {k: dict(v) for k, v in catalog["table_fields"].items()},
        "metrics_by_name": dict(catalog.get("metrics_by_name", {})),  # type: ignore[arg-type]
        "relationships": list(catalog.get("relationships", [])),  # type: ignore[arg-type]
    }


def _extend_catalog_with_cte(catalog: SemanticCatalog, rendered: Mapping[str, Any]) -> None:
    """Register a completed CTE as a synthetic table so a *later* CTE may source
    from it (dependent CTE chains). Each output column becomes a bare-name field
    whose ``expr`` is the column identifier itself."""
    name = rendered["name"]
    table_fields: Dict[str, Any] = {}
    for col in rendered["columns"]:
        field_def = {"name": col, "table_name": name, "expr": col}
        table_fields[col] = field_def
        catalog["fields_by_name"].setdefault(col, []).append(field_def)  # type: ignore[arg-type]
    catalog["table_fields"][name] = table_fields
    catalog["tables"][name] = {"name": name, "qualified_name": name}  # type: ignore[typeddict-item]


def _on_pairs(spec: Mapping[str, Any], what: str) -> List[Dict[str, Any]]:
    """Normalize an ``on:`` list into ``[{left, right, left_from}]`` dicts.

    Two authoring forms are accepted, and may be mixed in one list:

    * a bare string — the key has the SAME logical name on both sides
      (``on: [member_account_key]``), which is the historical form; and
    * a mapping — ``{left: <field>, right: <field>, left_from: <source>}`` for
      keys named differently per side (e.g. a claim's ``incurred_month`` joining
      a membership CTE's ``incurred_month`` where the physical columns differ),
      with ``left_from`` disambiguating which already-joined source owns ``left``.

    NOTE: YAML 1.1 parses an unquoted ``on:`` key as the boolean ``True``, so both
    spellings are read.
    """
    on_value = spec.get("on")
    if on_value is None:
        on_value = spec.get(True)
    pairs: List[Dict[str, Any]] = []
    for raw in _safe_list(on_value):
        if isinstance(raw, str):
            key = raw.strip()
            pairs.append({"left": key, "right": key, "left_from": None})
            continue
        entry = _safe_dict(raw)
        left = str(entry.get("left", "")).strip()
        right = str(entry.get("right", "") or left).strip()
        if not left or not right:
            raise ValueError(f"{what}: each 'on' entry needs a 'left' (and 'right')")
        left_from = entry.get("left_from")
        pairs.append(
            {
                "left": left,
                "right": right,
                "left_from": str(left_from).strip() if left_from else None,
            }
        )
    if not pairs:
        raise ValueError(f"{what} must declare at least one 'on' key")
    return pairs


def _cte_sources(
    cte: Mapping[str, Any],
    catalog: SemanticCatalog,
    prior_ctes: Mapping[str, Mapping[str, Any]],
    name: str,
) -> Tuple[List[str], Dict[str, str]]:
    """Resolve every table/CTE this CTE reads from, plus one alias map spanning them.

    A CTE's FROM clause is ``source`` plus each ``joins:`` target (a base table via
    ``table:`` or a prior CTE via ``cte:``). Returning ONE alias map for all of them
    is what makes ``{claim_line.paid_amount}`` and ``{pcp_members.period}`` resolve
    side by side inside the same measure, filter, or join condition — including
    cross-source column comparisons.

    Aliases are generated deterministically by :func:`build_alias_map` and may be
    overridden per source with ``alias:``. Collisions raise rather than silently
    producing SQL that references the wrong table.
    """
    source = str(cte.get("source", "")).strip()
    if source not in catalog["tables"]:
        raise ValueError(f"CTE {name!r}: unknown source table {source!r}")

    sources: List[str] = [source]
    explicit: Dict[str, str] = {}
    if cte.get("alias"):
        explicit[source] = _require_identifier(cte["alias"], "CTE source alias")

    for raw_join in _safe_list(cte.get("joins")):
        join = _safe_dict(raw_join)
        is_cte_ref = "cte" in join
        target = str(join.get("table") or join.get("cte") or "").strip()
        if not target:
            raise ValueError(
                f"CTE {name!r}: each join must name a 'table:' (base table) or "
                f"'cte:' (a previously-declared CTE)"
            )
        if is_cte_ref and target not in prior_ctes:
            raise ValueError(
                f"CTE {name!r}: join references unknown prior CTE {target!r}. "
                f"Declared so far: {sorted(prior_ctes)}"
            )
        if target not in catalog["tables"]:
            raise ValueError(f"CTE {name!r}: join references unknown table {target!r}")
        if target in sources:
            raise ValueError(
                f"CTE {name!r}: {target!r} is joined more than once (self-joins need "
                f"distinct logical sources)"
            )
        sources.append(target)
        if join.get("alias"):
            explicit[target] = _require_identifier(join["alias"], "join alias")

    alias_map = build_alias_map(sources)
    alias_map.update(explicit)
    if len(set(alias_map.values())) != len(alias_map):
        raise ValueError(
            f"CTE {name!r}: duplicate SQL alias across sources {alias_map}. "
            f"Set a distinct 'alias:' on one of them."
        )
    return sources, alias_map


def _render_cte_joins(
    cte: Mapping[str, Any],
    catalog: SemanticCatalog,
    alias_map: Mapping[str, str],
    sources: Sequence[str],
    name: str,
) -> List[str]:
    """Render the JOIN lines of a CTE's FROM clause.

    Each ``on`` key pair is resolved through the catalog on BOTH sides, so a
    mistyped field fails here with a clear message rather than reaching Snowflake.
    The left side must belong to a source already in the FROM clause (the CTE's
    own source, or a target joined earlier), which also enforces a sane join order.
    """
    source = sources[0]
    joined: List[str] = [source]
    lines: List[str] = []

    for raw_join in _safe_list(cte.get("joins")):
        join = _safe_dict(raw_join)
        join_type = str(join.get("type", "inner")).strip().lower()
        if join_type not in _JOIN_TYPES:
            raise ValueError(
                f"CTE {name!r}: unsupported join type {join.get('type')!r} "
                f"(expected one of {sorted(_JOIN_TYPES)})"
            )
        target = str(join.get("table") or join.get("cte") or "").strip()

        conditions: List[str] = []
        for pair in _on_pairs(join, f"CTE {name!r} join to {target!r}"):
            left_name = _require_identifier(pair["left"], "join key")
            right_name = _require_identifier(pair["right"], "join key")
            preferred = [pair["left_from"]] if pair["left_from"] else list(joined)

            left_field = resolve_field(catalog, left_name, preferred_tables=preferred)
            if left_field is None or left_field["table_name"] not in joined:
                raise ValueError(
                    f"CTE {name!r}: join key {left_name!r} does not resolve to an "
                    f"already-joined source (in scope: {joined})"
                )
            right_field = resolve_field(catalog, right_name, preferred_tables=[target])
            if right_field is None or right_field["table_name"] != target:
                raise ValueError(
                    f"CTE {name!r}: join key {right_name!r} is not a field of {target!r}"
                )
            conditions.append(
                f"{alias_map[left_field['table_name']]}.{left_field['expr']}"
                f" = {alias_map[target]}.{right_field['expr']}"
            )

        # Escape hatch for a predicate the key-pair form cannot express
        # (an inequality, a literal bound, a function call).
        extra = str(join.get("condition", "")).strip()
        if extra:
            conditions.append(render_expression(extra, dict(alias_map), catalog))

        lines.append(
            f"  {_JOIN_TYPES[join_type]} {catalog['tables'][target]['qualified_name']}"
            f" {alias_map[target]}\n    ON " + "\n   AND ".join(conditions)
        )
        joined.append(target)

    return lines


def _render_exists(
    spec: Mapping[str, Any],
    catalog: SemanticCatalog,
    outer_alias_map: Mapping[str, str],
    sources: Sequence[str],
    name: str,
) -> str:
    """Render a correlated ``[NOT] EXISTS (SELECT 1 FROM ... WHERE ...)`` predicate.

    This is the anti-join the ``semi_join`` helper cannot express: "keep outer rows
    that have NO matching row over there", correlated on arbitrary key pairs and
    optionally narrowed by its own filter tree. ``correlate`` pairs are
    ``{inner: <field on the subquery source>, outer: <field on this CTE>}``.

    The subquery alias is derived from the source name and nudged until it cannot
    collide with any outer alias, so the correlation always binds to the intended
    side.
    """
    subquery_source = str(spec.get("source", "")).strip()
    if subquery_source not in catalog["tables"]:
        raise ValueError(f"CTE {name!r}: exists references unknown source {subquery_source!r}")

    if spec.get("alias"):
        alias = _require_identifier(spec["alias"], "exists alias")
    else:
        alias = build_alias_map([subquery_source])[subquery_source]
    taken = set(outer_alias_map.values())
    while alias in taken:
        alias = f"{alias}_x"

    inner_alias_map = {**outer_alias_map, subquery_source: alias}

    conditions: List[str] = []
    for raw_pair in _safe_list(spec.get("correlate")):
        pair = _safe_dict(raw_pair)
        inner_name = _require_identifier(str(pair.get("inner", "")).strip(), "correlate key")
        outer_name = _require_identifier(
            str(pair.get("outer", "") or inner_name).strip(), "correlate key"
        )
        inner_field = resolve_field(catalog, inner_name, preferred_tables=[subquery_source])
        if inner_field is None or inner_field["table_name"] != subquery_source:
            raise ValueError(
                f"CTE {name!r}: correlate key {inner_name!r} is not a field of "
                f"{subquery_source!r}"
            )
        outer_field = resolve_field(catalog, outer_name, preferred_tables=list(sources))
        if outer_field is None or outer_field["table_name"] not in sources:
            raise ValueError(
                f"CTE {name!r}: correlate key {outer_name!r} is not in scope "
                f"(in scope: {list(sources)})"
            )
        conditions.append(
            f"{alias}.{inner_field['expr']}"
            f" = {outer_alias_map[outer_field['table_name']]}.{outer_field['expr']}"
        )

    if not _is_empty_filter(spec.get("filters")):
        conditions.append(
            render_filter_tree(spec["filters"], catalog, inner_alias_map, [subquery_source])
        )

    if not conditions:
        raise ValueError(
            f"CTE {name!r}: an exists block needs at least one 'correlate' pair or a filter"
        )

    negate = "NOT " if bool(spec.get("negate", False)) else ""
    qualified = catalog["tables"][subquery_source]["qualified_name"]
    return (
        f"{negate}EXISTS (SELECT 1 FROM {qualified} {alias}"
        f" WHERE {' AND '.join(conditions)})"
    )


def _render_semi_join(
    semi: Mapping[str, Any],
    sources: Sequence[str],
    alias_map: Mapping[str, str],
    catalog: SemanticCatalog,
    prior_ctes: Mapping[str, Mapping[str, Any]],
) -> str:
    """Render a semi-join predicate restricting the source to keys present in a
    prior CTE. Single key -> ``src IN (SELECT tgt FROM cte)``; multi-key ->
    ``EXISTS (SELECT 1 FROM cte WHERE ...)``."""
    target = str(semi.get("cte", "")).strip()
    if target not in prior_ctes:
        raise ValueError(f"semi_join references unknown prior CTE {target!r}")
    # YAML 1.1 parses an unquoted ``on:`` key as the boolean True.
    on_value = semi.get("on")
    if on_value is None:
        on_value = semi.get(True)
    keys = [str(key).strip() for key in _safe_list(on_value)]
    if not keys:
        raise ValueError(f"semi_join on {target!r} must declare at least one 'on' key")

    target_cols = set(prior_ctes[target]["columns"])
    pairs: List[tuple] = []
    for key in keys:
        _require_identifier(key, "semi-join key")
        src_field = resolve_field(catalog, key, preferred_tables=list(sources))
        if src_field is None or src_field["table_name"] not in sources:
            raise ValueError(f"semi_join key {key!r} is not on source {list(sources)}")
        if key not in target_cols:
            raise ValueError(f"semi_join key {key!r} is not a column of CTE {target!r}")
        pairs.append(
            (f"{alias_map[src_field['table_name']]}.{src_field['expr']}", f"{target}.{key}")
        )

    if len(pairs) == 1:
        src_col, tgt_col = pairs[0]
        return f"{src_col} IN (SELECT {tgt_col} FROM {target})"
    conditions = " AND ".join(f"{tgt_col} = {src_col}" for src_col, tgt_col in pairs)
    return f"EXISTS (SELECT 1 FROM {target} WHERE {conditions})"


def _filter_tree_for_cte(
    filter_tree: Any,
    cte_config: Mapping[str, Any],
    catalog: SemanticCatalog,
    source_table: Union[str, Sequence[str]],
) -> Optional[Any]:
    """Filter a request filter tree to include only leaves applicable to this CTE.
    
    Implements table-based filter routing: the CTE config may declare
    ``include_filters_for_tables`` or ``exclude_filters_for_tables`` to control
    which filters from the request get applied based on field→table resolution.
    
    Routing rules (evaluated in order):
      1. If ``include_filters_for_tables`` is set, keep only filters whose field
         belongs to one of those tables.
      2. If ``exclude_filters_for_tables`` is set, drop filters whose field
         belongs to one of those tables.
      3. Otherwise, keep all filters (backward compatible default).
    
    Args:
        filter_tree: The full request filter tree (nested AND/OR structure).
        cte_config: The CTE's YAML config (may contain routing directives).
        catalog: Semantic catalog for field→table resolution.
        source_table: The CTE's source table name (used as preferred table for
            field resolution).
    
    Returns:
        A filtered version of filter_tree containing only applicable leaves, or
        ``None`` if no filters remain after routing.
    
    Example:
        >>> # CTE sourced from expense_detail wants only expense_detail filters
        >>> cte_config = {"include_filters_for_tables": ["expense_detail"]}
        >>> request_filters = {
        ...     "logic": "AND",
        ...     "conditions": [
        ...         {"field": "lob_code", ...},              # on both tables
        ...         {"field": "rendering_provider_name", ...}, # expense_detail only
        ...         {"field": "member_duration_months", ...},  # membership only
        ...     ]
        ... }
        >>> routed = _filter_tree_for_cte(request_filters, cte_config, catalog, "expense_detail")
        >>> # Result contains lob_code + rendering_provider_name, but NOT member_duration_months
    """
    if filter_tree is None or _is_empty_filter(filter_tree):
        return None

    sources = [source_table] if isinstance(source_table, str) else list(source_table)

    include_tables = cte_config.get("include_filters_for_tables")
    exclude_tables = cte_config.get("exclude_filters_for_tables")
    include_fields = cte_config.get("include_filter_fields")
    exclude_fields = cte_config.get("exclude_filter_fields")

    # No routing directives = include everything (backward compatible)
    if not any((include_tables, exclude_tables, include_fields, exclude_fields)):
        return filter_tree

    def should_include_leaf(leaf: Dict[str, Any]) -> bool:
        """Determine if a filter leaf should apply to this CTE.

        Precedence, most specific first: field denylist, field allowlist, table
        denylist, table allowlist. A leaf with no ``field`` (a ``named_filter``)
        can only be routed by the field lists, which it never matches, so it
        always passes -- the author wrote it against this CTE deliberately.
        """
        field_name = leaf.get("field")
        if not field_name:
            return True

        if exclude_fields and field_name in exclude_fields:
            return False
        if include_fields:
            return field_name in include_fields

        # Resolve field to its table
        field_def = resolve_field(catalog, field_name, preferred_tables=sources)
        if field_def is None:
            # Unknown field: conservative default is to include it and let
            # render_filter_tree fail later with a clear error message
            return True

        field_table = field_def["table_name"]

        if exclude_tables and field_table in exclude_tables:
            return False
        if include_tables:
            return field_table in include_tables

        return True
    
    # Recursively filter the tree
    def filter_node(node: Any) -> Optional[Any]:
        if isinstance(node, (list, tuple)):
            # Implicit AND group
            filtered_children = [filter_node(child) for child in node]
            present = [c for c in filtered_children if c is not None]
            if not present:
                return None
            if len(present) == 1:
                return present[0]
            return present
        
        if isinstance(node, dict):
            if "logic" in node and "conditions" in node:
                # Explicit boolean group
                filtered_children = [filter_node(child) for child in node.get("conditions", [])]
                present = [c for c in filtered_children if c is not None]
                if not present:
                    return None
                if len(present) == 1:
                    return present[0]
                return {"logic": node["logic"], "conditions": present}
            else:
                # Leaf filter condition
                return node if should_include_leaf(node) else None
        
        return None
    
    return filter_node(filter_tree)


def _render_cte_dimensions(
    cte: Mapping[str, Any],
    catalog: SemanticCatalog,
    alias_map: Mapping[str, str],
    sources: Sequence[str],
    name: str,
) -> Tuple[List[str], List[str], List[str]]:
    """Render a CTE's dimension projections.

    Returns ``(names, select_parts, group_by_parts)``. A dimension is either:

    * a bare field name (historical form) -> ``<alias>.<COLUMN> AS <name>``,
      grouped by the physical expression; or
    * a mapping ``{name, expr, group_by}`` -> an arbitrary expression (a CASE that
      buckets months into 'baseline'/'comparison', a COALESCE, a cast) aliased to
      ``name``. ``group_by`` chooses what lands in GROUP BY: ``alias`` (default --
      shortest and unambiguous), ``expr`` (repeat the whole expression, for engines
      that reject alias grouping), or ``none`` (project without grouping this one).
    """
    names: List[str] = []
    select_parts: List[str] = []
    group_by_parts: List[str] = []

    for raw_dim in _safe_list(cte.get("dimensions")):
        if isinstance(raw_dim, str):
            dim = _require_identifier(raw_dim, "dimension name")
            field_def = resolve_field(catalog, dim, preferred_tables=list(sources))
            if field_def is None:
                raise ValueError(f"CTE {name!r}: unknown dimension {dim!r}")
            if field_def["table_name"] not in sources:
                raise ValueError(
                    f"CTE {name!r}: dimension {dim!r} resolves to "
                    f"{field_def['table_name']!r}, which this CTE does not read from "
                    f"(in scope: {list(sources)})"
                )
            physical = f"{alias_map[field_def['table_name']]}.{field_def['expr']}"
            names.append(dim)
            select_parts.append(f"{physical} AS {dim}")
            group_by_parts.append(physical)
            continue

        spec = _safe_dict(raw_dim)
        dim = _require_identifier(spec.get("name", ""), "dimension name")
        expr = str(spec.get("expr", "")).strip()
        if not expr:
            raise ValueError(
                f"CTE {name!r}: dimension {dim!r} is a mapping but declares no 'expr' "
                f"(use the bare-name form for a plain column)"
            )
        rendered = render_expression(expr, dict(alias_map), catalog)
        mode = str(spec.get("group_by", "alias")).strip().lower()
        if mode not in {"alias", "expr", "none"}:
            raise ValueError(
                f"CTE {name!r}: dimension {dim!r} has group_by={mode!r} "
                f"(expected 'alias', 'expr', or 'none')"
            )
        names.append(dim)
        select_parts.append(f"{rendered} AS {dim}")
        if mode == "alias":
            group_by_parts.append(dim)
        elif mode == "expr":
            group_by_parts.append(rendered)

    return names, select_parts, group_by_parts


def _render_cte_block(
    cte: Mapping[str, Any],
    catalog: SemanticCatalog,
    shared_filters: Any,
    prior_ctes: Mapping[str, Mapping[str, Any]],
    request_filters: Any = None,
    default_apply_request: Optional[bool] = None,
) -> Dict[str, Any]:
    """Render one CTE ``<name> AS (SELECT [DISTINCT] ... FROM ... [JOIN ...]
    [WHERE ...] [GROUP BY ...] [HAVING ...])``.

    ``source`` may be a base table OR a previously-declared CTE in ``prior_ctes``
    (dependent chains), and ``joins:`` may bring in further base tables and prior
    CTEs. Returns a dict with the rendered ``sql`` block plus the ``name``,
    ``dimensions`` and ``columns`` (dims + measure names) needed to build the
    synthetic catalog and validate the output joins.

    Two filter streams reach the WHERE clause and are ANDed together with the
    CTE's own ``filters``:

    * ``shared_filters`` -- the calculation's YAML-declared predicates, gated by
      the legacy ``include_shared_filters`` flag; and
    * ``request_filters`` -- the caller's filter tree, gated by
      ``apply_request_filters`` and narrowed by the include/exclude routing.
    """
    name = _require_identifier(cte.get("name", ""), "CTE name")
    sources, alias_map = _cte_sources(cte, catalog, prior_ctes, name)
    source = sources[0]
    source_is_cte = source in prior_ctes
    distinct = bool(cte.get("distinct", False))

    dimensions, select_parts, group_by_parts = _render_cte_dimensions(
        cte, catalog, alias_map, sources, name
    )

    measure_names: List[str] = []
    for raw_measure in _safe_list(cte.get("measures")):
        measure = _safe_dict(raw_measure)
        measure_name = _require_identifier(measure.get("name", ""), "measure name")
        expr = str(measure.get("expr", "")).strip()
        if not expr:
            raise ValueError(f"CTE {name!r}: measure {measure_name!r} has no expr")
        rendered = render_expression(expr, alias_map, catalog)  # KeyError on unknown field
        select_parts.append(f"{rendered} AS {measure_name}")
        measure_names.append(measure_name)

    if not select_parts:
        raise ValueError(f"CTE {name!r}: must declare at least one dimension or measure")

    # --- YAML shared filters -------------------------------------------------
    # Default ON for base-table CTEs and OFF for CTE-sourced CTEs (whose columns
    # differ), overridable with include_shared_filters. Table/field routing, when
    # declared, applies to these too.
    include_shared = cte.get("include_shared_filters", not source_is_cte)
    routed_shared = (
        _filter_tree_for_cte(shared_filters, cte, catalog, sources) if include_shared else None
    )

    # --- request filter tree -------------------------------------------------
    # Precedence: the CTE's own apply_request_filters, else the calculation-level
    # default, else the same base-table/CTE-sourced heuristic as shared filters
    # (which is what this builder did before the knob existed).
    if "apply_request_filters" in cte:
        apply_request = bool(cte["apply_request_filters"])
    elif default_apply_request is not None:
        apply_request = bool(default_apply_request)
    else:
        apply_request = not source_is_cte
    routed_request = (
        _filter_tree_for_cte(request_filters, cte, catalog, sources) if apply_request else None
    )

    where_node = _merge_filters(
        routed_shared,
        routed_request,
        cte.get("filters"),
    )

    # semi_join may be a single mapping or a list of mappings.
    raw_semi = cte.get("semi_join")
    if isinstance(raw_semi, dict):
        semi_specs = [raw_semi]
    else:
        semi_specs = [_safe_dict(item) for item in _safe_list(raw_semi)]

    # exists may likewise be a single mapping or a list of mappings.
    raw_exists = cte.get("exists")
    if isinstance(raw_exists, dict):
        exists_specs = [raw_exists]
    else:
        exists_specs = [_safe_dict(item) for item in _safe_list(raw_exists)]

    where_clauses: List[str] = []
    if where_node is not None:
        where_clauses.append(render_filter_tree(where_node, catalog, alias_map, sources))
    for semi in semi_specs:
        where_clauses.append(_render_semi_join(semi, sources, alias_map, catalog, prior_ctes))
    for exists_spec in exists_specs:
        where_clauses.append(_render_exists(exists_spec, catalog, alias_map, sources, name))

    having_expr = str(cte.get("having", "")).strip()

    # A pure DISTINCT projection dedups without a GROUP BY; `group_by: false` is
    # the explicit opt-out for a pass-through projection that carries measures or
    # simply must not collapse rows.
    group_by_enabled = bool(cte.get("group_by", True)) and not distinct

    select_kw = "  SELECT DISTINCT " if distinct else "  SELECT "
    lines = [f"{name} AS ("]
    lines.append(select_kw + ",\n         ".join(select_parts))
    lines.append(f"  FROM {catalog['tables'][source]['qualified_name']} {alias_map[source]}")
    lines.extend(_render_cte_joins(cte, catalog, alias_map, sources, name))
    if where_clauses:
        lines.append("  WHERE " + " AND ".join(where_clauses))
    if group_by_parts and group_by_enabled:
        lines.append("  GROUP BY " + ", ".join(group_by_parts))
    if having_expr:
        lines.append("  HAVING " + render_expression(having_expr, alias_map, catalog))
    lines.append(")")

    return {
        "name": name,
        "sql": "\n".join(lines),
        "dimensions": dimensions,
        "columns": dimensions + measure_names,
    }


def _build_cte_catalog(rendered_ctes: Sequence[Mapping[str, Any]]) -> SemanticCatalog:
    """Synthetic catalog: each CTE is a table, each output column a bare-name field."""
    catalog: SemanticCatalog = {
        "tables": {},
        "fields_by_name": {},
        "table_fields": {},
        "metrics_by_name": {},
        "relationships": [],
    }
    for cte in rendered_ctes:
        name = cte["name"]
        table_fields: Dict[str, Any] = {}
        for col in cte["columns"]:
            field_def = {"name": col, "table_name": name, "expr": col}
            table_fields[col] = field_def
            catalog["fields_by_name"].setdefault(col, []).append(field_def)  # type: ignore[arg-type]
        catalog["table_fields"][name] = table_fields
        catalog["tables"][name] = {"name": name, "qualified_name": name}  # type: ignore[typeddict-item]
    return catalog


def _render_final_select(
    output: Mapping[str, Any],
    rendered_ctes: Sequence[Mapping[str, Any]],
    filter_values: Optional[Dict[str, Any]] = None,
    request_filters: Any = None,
) -> str:
    """Render the final SELECT from CTE results.

    Beyond the projection and CTE joins, the output block may declare a ``WHERE``
    (``filters``), ``GROUP BY``, ``HAVING``, ``ORDER BY``, ``LIMIT`` and
    ``DISTINCT`` -- everything needed to turn joined per-member CTEs into a small
    per-period summary without an outer wrapper query.

    Args:
        output: The output specification (joins, columns, and the clauses above).
        rendered_ctes: The list of rendered CTE dicts.
        filter_values: Optional dict injected as synthetic "filters" table for
            output column expressions that reference {filters.*} placeholders.
        request_filters: The caller's filter tree, applied to the final WHERE only
            when the output block sets ``apply_request_filters: true``.

    Returns:
        The final SELECT SQL statement.
    """
    by_name = {cte["name"]: cte for cte in rendered_ctes}
    cte_alias_map = {name: name for name in by_name}
    cte_catalog = _build_cte_catalog(rendered_ctes)
    
    # Extend catalog with filter_values so output columns can reference {filters.*}
    extend_catalog_with_filter_values(cte_catalog, filter_values)

    columns = _safe_list(output.get("columns"))
    if not columns:
        raise ValueError("cte_query output must declare at least one column")
    select_parts: List[str] = []
    for raw_col in columns:
        col = _safe_dict(raw_col)
        col_name = _require_identifier(col.get("name", ""), "output column name")
        expr = str(col.get("expr", "")).strip()
        if not expr:
            raise ValueError(f"Output column {col_name!r} has no expr")
        rendered = render_expression(expr, cte_alias_map, cte_catalog)  # KeyError on unknown cte.col
        select_parts.append(f"{rendered} AS {col_name}")

    joins = _safe_list(output.get("joins"))
    if joins:
        anchor = str(_safe_dict(joins[0]).get("left", "")).strip()
    else:
        anchor = rendered_ctes[0]["name"]
    if anchor not in by_name:
        raise ValueError(f"Join anchor {anchor!r} is not a declared CTE")

    joined = {anchor}
    join_lines: List[str] = []
    for raw_join in joins:
        join = _safe_dict(raw_join)
        join_type = str(join.get("type", "")).strip().lower()
        if join_type not in _JOIN_TYPES:
            raise ValueError(
                f"Unsupported join type {join.get('type')!r} "
                f"(expected one of {sorted(_JOIN_TYPES)})"
            )
        left = str(join.get("left", "")).strip()
        right = str(join.get("right", "")).strip()
        if left not in by_name:
            raise ValueError(f"Join references unknown CTE {left!r}")
        if right not in by_name:
            raise ValueError(f"Join references unknown CTE {right!r}")
        if left not in joined:
            raise ValueError(
                f"Join left CTE {left!r} is not joined yet — order joins so each "
                f"left side is the anchor or a previously-joined CTE"
            )
        # NOTE: YAML parses an unquoted ``on:`` key as the boolean True (YAML 1.1),
        # so accept either the string "on" or the boolean True as the join-key list.
        conditions: List[str] = []
        for pair in _on_pairs(join, f"Join {left!r}->{right!r}"):
            left_key = _require_identifier(pair["left"], "join key")
            right_key = _require_identifier(pair["right"], "join key")
            # Any output column may be a join key -- a measure is a legitimate key
            # when joining pre-aggregated CTEs, and an expression dimension only
            # exists as a column.
            if left_key not in by_name[left]["columns"]:
                raise ValueError(f"Join key {left_key!r} is not a column of CTE {left!r}")
            if right_key not in by_name[right]["columns"]:
                raise ValueError(f"Join key {right_key!r} is not a column of CTE {right!r}")
            conditions.append(f"{left}.{left_key} = {right}.{right_key}")
        join_lines.append(f"{_JOIN_TYPES[join_type]} {right}\n  ON " + "\n  AND ".join(conditions))
        joined.add(right)

    select_kw = "SELECT DISTINCT " if bool(output.get("distinct", False)) else "SELECT "
    lines = [select_kw + ",\n       ".join(select_parts), f"FROM {anchor}"]
    lines.extend(join_lines)

    # --- WHERE ---------------------------------------------------------------
    # A filter tree over CTE *output columns*, rendered against the synthetic
    # catalog, so `{all_members.period} IS NOT NULL` works with the same grammar
    # used everywhere else. Request filters are routed here only when the output
    # block opts in -- the population is normally scoped inside the CTEs.
    where_node = _merge_filters(
        output.get("filters"),
        request_filters if bool(output.get("apply_request_filters", False)) else None,
    )
    if where_node is not None:
        lines.append(
            "WHERE " + render_filter_tree(where_node, cte_catalog, cte_alias_map, list(by_name))
        )

    # --- GROUP BY ------------------------------------------------------------
    # Entries name an output column (grouped by its alias) or carry a raw
    # `{cte.column}` expression for engines that reject alias grouping.
    declared_columns = {
        _safe_dict(col).get("name") for col in columns if _safe_dict(col).get("name")
    }
    group_by_parts: List[str] = []
    for raw_group in _safe_list(output.get("group_by")):
        entry = str(raw_group).strip()
        if not entry:
            continue
        if "{" in entry:
            group_by_parts.append(render_expression(entry, cte_alias_map, cte_catalog))
            continue
        _require_identifier(entry, "group by column")
        if entry not in declared_columns:
            raise ValueError(
                f"group_by references {entry!r}, which is not a declared output column "
                f"(declared: {sorted(declared_columns)})"
            )
        group_by_parts.append(entry)
    if group_by_parts:
        lines.append("GROUP BY " + ", ".join(group_by_parts))

    having_expr = str(output.get("having", "")).strip()
    if having_expr:
        lines.append("HAVING " + render_expression(having_expr, cte_alias_map, cte_catalog))

    # --- ORDER BY ------------------------------------------------------------
    order_parts: List[str] = []
    for raw_order in _safe_list(output.get("order_by")):
        if isinstance(raw_order, str):
            order_spec: Dict[str, Any] = {"column": raw_order}
        else:
            order_spec = _safe_dict(raw_order)
        direction = str(order_spec.get("direction", "asc")).strip().lower()
        if direction not in {"asc", "desc"}:
            raise ValueError(f"order_by direction must be 'asc' or 'desc', got {direction!r}")
        expr = str(order_spec.get("expr", "")).strip()
        if expr:
            order_parts.append(
                f"{render_expression(expr, cte_alias_map, cte_catalog)} {direction.upper()}"
            )
            continue
        column = _require_identifier(str(order_spec.get("column", "")).strip(), "order by column")
        if column not in declared_columns:
            raise ValueError(
                f"order_by references {column!r}, which is not a declared output column "
                f"(declared: {sorted(declared_columns)})"
            )
        order_parts.append(f"{column} {direction.upper()}")
    if order_parts:
        lines.append("ORDER BY " + ", ".join(order_parts))

    limit = output.get("limit")
    if limit is not None:
        try:
            limit_value = int(limit)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"output limit must be an integer, got {limit!r}") from exc
        if limit_value <= 0:
            raise ValueError(f"output limit must be positive, got {limit_value}")
        lines.append(f"LIMIT {limit_value}")

    return "\n".join(lines)


def build_cte_query_sql(
    semantic_model: Mapping[str, Any],
    cte_query: Mapping[str, Any],
    *,
    catalog: Optional[SemanticCatalog] = None,
    request_filters: Any = None,
    filter_values: Optional[Dict[str, Any]] = None,
) -> str:
    """Build a full ``WITH ... SELECT ...`` query from one declarative CTE spec.

    ``semantic_model`` is the parsed semantic YAML (provides ``tables`` etc.).
    ``cte_query`` is a single entry from the model's ``cte_queries`` list or a
    calculation spec with ``ctes`` / ``output`` keys.
    
    Args:
        semantic_model: The full semantic YAML model.
        cte_query: Calculation spec containing ``ctes`` and ``output``.
        catalog: Optional pre-built catalog (built from semantic_model if not provided).
        request_filters: Optional filter tree from the request. When provided,
            replaces YAML ``shared_filters`` and enables table-based routing.
        filter_values: Optional dict of key→value pairs injected as a synthetic
            ``filters`` table, allowing expressions like ``{filters.baseline_start}``.
    
    Returns:
        The full SQL query as a string.
    """
    catalog = catalog or build_semantic_catalog(dict(semantic_model))
    # Work on an independent copy so each completed CTE can be registered as a
    # synthetic source for later CTEs without mutating the caller's catalog.
    combined = _copy_catalog(catalog)
    
    # Inject filter_values as a synthetic "filters" table before rendering
    extend_catalog_with_filter_values(combined, filter_values)

    raw_ctes = _safe_list(cte_query.get("ctes"))
    if not raw_ctes:
        raise ValueError("cte_query must declare at least one CTE under 'ctes'")

    # How the request tree combines with the calculation's YAML `shared_filters`:
    #   merge   (default) -- both apply, ANDed. A request narrows the population
    #                        without being able to drop a YAML invariant.
    #   replace           -- the request tree stands in for shared_filters, which
    #                        is what this builder did before the flag existed.
    request_config = _safe_dict(cte_query.get("request_filters"))
    mode = str(request_config.get("mode", "merge")).strip().lower()
    if mode not in {"merge", "replace"}:
        raise ValueError(
            f"request_filters.mode must be 'merge' or 'replace', got {mode!r}"
        )
    default_apply_request = request_config.get("apply")

    yaml_shared = cte_query.get("shared_filters")
    if mode == "replace" and request_filters is not None:
        yaml_shared = None

    rendered_ctes: List[Dict[str, Any]] = []
    prior_ctes: Dict[str, Dict[str, Any]] = {}
    seen: set = set()
    for raw_cte in raw_ctes:
        rendered = _render_cte_block(
            _safe_dict(raw_cte),
            combined,
            yaml_shared,
            prior_ctes,
            request_filters=request_filters,
            default_apply_request=default_apply_request,
        )
        if rendered["name"] in seen:
            raise ValueError(f"Duplicate CTE name: {rendered['name']!r}")
        seen.add(rendered["name"])
        rendered_ctes.append(rendered)
        prior_ctes[rendered["name"]] = rendered
        _extend_catalog_with_cte(combined, rendered)

    with_clause = "WITH " + ",\n".join(cte["sql"] for cte in rendered_ctes)
    final_select = _render_final_select(
        _safe_dict(cte_query.get("output")),
        rendered_ctes,
        filter_values=filter_values,  # Pass filter_values to output SELECT
        request_filters=request_filters,
    )
    return f"{with_clause}\n{final_select}"


def build_cte_query_sql_by_name(
    semantic_model: Mapping[str, Any],
    name: str,
    *,
    catalog: Optional[SemanticCatalog] = None,
) -> str:
    """Look up a named entry in the model's ``cte_queries`` list and build its SQL."""
    for raw_query in _safe_list(semantic_model.get("cte_queries")):
        query = _safe_dict(raw_query)
        if str(query.get("name", "")).strip() == str(name).strip():
            return build_cte_query_sql(semantic_model, query, catalog=catalog)
    raise ValueError(f"No cte_query named {name!r} in semantic model")


def build_raw_sql(
    semantic_model: Mapping[str, Any],
    spec: Mapping[str, Any],
    *,
    catalog: Optional[SemanticCatalog] = None,
    filter_values: Optional[Dict[str, Any]] = None,
) -> str:
    """Resolve an author-written raw-SQL calculation into physical SQL.

    This is the deliberate "any logic" escape hatch: ``spec['sql']`` is arbitrary
    SQL authored with placeholder forms resolved against the semantic catalog:

    * ``{table.field}`` -> ``<alias>.<PHYSICAL_COLUMN>`` (via ``render_expression``);
    * ``{table}``       -> ``<QUALIFIED_TABLE> <alias>`` (for ``FROM`` / ``JOIN``);
    * ``{filters.key}`` -> literal value (when ``filter_values`` is provided).

    A single deterministic alias map spans all tables, so column and table
    placeholders for the same logical table always agree. No structural
    validation is performed beyond placeholder resolution -- unknown placeholders
    raise ``KeyError``. Prefer ``topk`` / ``cte_pipeline`` where they fit.
    
    Args:
        semantic_model: The full semantic YAML model.
        spec: Calculation spec containing the ``sql`` key.
        catalog: Optional pre-built catalog.
        filter_values: Optional dict injected as synthetic ``filters`` table.
    
    Returns:
        The resolved SQL string.
    """
    catalog = catalog or build_semantic_catalog(dict(semantic_model))
    # Work on a copy so filter_values don't leak into the caller's catalog
    catalog = _copy_catalog(catalog)
    extend_catalog_with_filter_values(catalog, filter_values)
    
    sql = str(spec.get("sql", "")).strip()
    if not sql:
        raise ValueError("raw_sql calculation must declare a non-empty 'sql'")

    # The synthetic ``filters`` table registered by extend_catalog_with_filter_values
    # must NOT get a physical alias: render_expression treats "table is in alias_map"
    # as "this is a real table" and would emit `f.202411` instead of the literal
    # `202411` for every {filters.*} placeholder.
    alias_map = build_alias_map(
        [name for name in catalog["tables"].keys() if name != "filters"]
    )
    # 1) dotted {table.field} -> alias.PHYSICAL (consumes those braces)
    rendered = render_expression(sql, alias_map, catalog)

    # 2) remaining bare {table} -> QUALIFIED alias
    def _table_replacer(match: "re.Match[str]") -> str:
        table_name = match.group(1)
        table_def = catalog["tables"].get(table_name)
        if not table_def:
            raise KeyError(f"Unknown table placeholder: {table_name}")
        return f"{table_def['qualified_name']} {alias_map[table_name]}"

    return _TABLE_PLACEHOLDER_RE.sub(_table_replacer, rendered)


def run_cte_query(
    snowflake_helper: "SnowparkHelper",
    semantic_model: Mapping[str, Any],
    cte_query_or_name: Union[str, Mapping[str, Any]],
    *,
    output_dir: Optional[Path] = None,
    save_parquet: bool = False,
) -> pd.DataFrame:
    """Build the CTE SQL, execute it, and return a (column-normalized) DataFrame.

    Pass either a ``cte_query`` dict or the name of an entry in ``cte_queries``.
    When ``save_parquet`` is set, the result is written to
    ``<output_dir>/<name>.parquet`` (rows are only persisted when explicitly asked).
    """
    if isinstance(cte_query_or_name, str):
        query = None
        for raw_query in _safe_list(semantic_model.get("cte_queries")):
            candidate = _safe_dict(raw_query)
            if str(candidate.get("name", "")).strip() == cte_query_or_name.strip():
                query = candidate
                break
        if query is None:
            raise ValueError(f"No cte_query named {cte_query_or_name!r} in semantic model")
    else:
        query = _safe_dict(cte_query_or_name)

    sql = build_cte_query_sql(semantic_model, query)
    df = execute_sql_to_df(snowflake_helper, sql)

    if save_parquet:
        if output_dir is None:
            raise ValueError("save_parquet=True requires output_dir")
        name = str(query.get("name", "cte_query")).strip() or "cte_query"
        target = ensure_dir(Path(output_dir)) / f"{name}.parquet"
        df.to_parquet(target)
    return df
