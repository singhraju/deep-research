"""Shared semantic-YAML → SQL machinery.

Extracted **verbatim** from ``correlation_agent.py`` so it can be shared by the
correlation and reimbursement agents without duplicating logic. Correlation
imports these names back (behavior preserved); the reimbursement agent's filter
mode consumes them to build claims queries from a semantic view.

This module lives in the lowest-level package (``deep_research_utils``) and MUST
NOT import from ``deep_research_core`` or ``deep_research_agents`` — those
packages depend on ``deep_research_utils``, so importing them here would create a
circular import. Anything that needs a higher-level exception type (e.g.
:func:`resolve_semantic_model_path`) accepts it via an ``error_cls`` parameter
instead of importing it.

The only intentional additions beyond the verbatim extraction are the nested
boolean filter grammar (:func:`render_filter_tree`, :func:`collect_filter_fields`)
and the generalized :func:`resolve_semantic_model_path` (parameterized allowed
directory / default / error type). Everything else matches the correlation
originals line-for-line.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import (
    Any,
    Dict,
    List,
    Literal,
    Mapping,
    Optional,
    Sequence,
    Set,
    Tuple,
    TypedDict,
    Union,
)

import pandas as pd
import yaml

try:  # pragma: no cover - logging is best-effort
    from deep_research_utils.logger_config import get_logger

    logger = get_logger(__name__)
except Exception:  # pragma: no cover
    logger = logging.getLogger(__name__)

try:  # pragma: no cover - only referenced in a type hint / runtime df helper
    from deep_research_utils.snowflake_helper import SnowparkHelper
except Exception:  # pragma: no cover
    SnowparkHelper = Any  # type: ignore[assignment,misc]


__all__ = [
    # Types
    "FilterSource",
    "FilterCondition",
    "FieldDefinition",
    "MetricDefinition",
    "RelationshipDefinition",
    "TableDefinition",
    "SemanticCatalog",
    "FilterNode",
    # Primitives
    "NUMERIC_PATTERN",
    "PLACEHOLDER_PATTERN",
    "escape_sql_string",
    "maybe_number",
    "ensure_dir",
    "normalize_dataframe_columns",
    "execute_sql_to_df",
    # Catalog / resolution
    "load_semantic_yaml",
    "load_semantic_view",
    "parse_metric_dependencies",
    "build_semantic_catalog",
    "resolve_field",
    "build_alias_map",
    "render_expression",
    "extend_catalog_with_filter_values",
    "find_relationship",
    "build_from_clause",
    # Filter rendering
    "render_filter_clause",
    "normalize_filters_for_sql",
    "render_filter_tree",
    "collect_filter_fields",
    "collect_filter_leaves",
    # Path resolution
    "resolve_semantic_model_path",
]


# =============================
# Semantic types
# =============================

FilterSource = Literal["dimension_match", "named_filter"]


class FilterCondition(TypedDict):
    field: str
    operator: str
    value: Any
    source: FilterSource


class FieldDefinition(TypedDict, total=False):
    name: str
    table_name: str
    expr: str
    data_type: str
    description: str
    label: str
    kind: str
    synonyms: List[str]


class MetricDefinition(TypedDict, total=False):
    name: str
    expr: str
    description: str
    dependency_tables: List[str]
    primary_table: Optional[str]


class RelationshipDefinition(TypedDict, total=False):
    name: str
    left_table: str
    right_table: str
    relationship_columns: List[Dict[str, str]]


class TableDefinition(TypedDict, total=False):
    name: str
    description: str
    database: str
    schema: str
    table: str
    qualified_name: str


class SemanticCatalog(TypedDict):
    tables: Dict[str, TableDefinition]
    fields_by_name: Dict[str, List[FieldDefinition]]
    table_fields: Dict[str, Dict[str, FieldDefinition]]
    metrics_by_name: Dict[str, MetricDefinition]
    relationships: List[RelationshipDefinition]


# =============================
# Primitives
# =============================

NUMERIC_PATTERN = re.compile(r"^-?\d+(\.\d+)?$")
PLACEHOLDER_PATTERN = re.compile(r"\{([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)\}")


def _safe_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def _safe_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def escape_sql_string(value: str) -> str:
    return value.replace("'", "''")


def maybe_number(value: str) -> bool:
    return bool(NUMERIC_PATTERN.match(str(value).strip()))


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def normalize_dataframe_columns(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    out.columns = [str(col).strip().lower() for col in out.columns]
    return out


def _filter_value_key(value: Any) -> str:
    """Create a stable key for deduplicating filter values."""
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True, ensure_ascii=True, default=str)
    return str(value)


def execute_sql_to_df(snowflake_helper: "SnowparkHelper", query: str) -> pd.DataFrame:
    logger.debug("Executing SQL (%s chars)", len(query))
    df = snowflake_helper.execute_query_and_return_pandas_df(query)
    return normalize_dataframe_columns(df)


# =============================
# YAML loading + catalog
# =============================

def load_semantic_yaml(path: str) -> Dict[str, Any]:
    """Load semantic YAML file (loaded fresh per request based on yaml_path payload)."""
    logger.info("🔍 Loading semantic YAML from: %s", path)
    with open(path, "r", encoding="utf-8") as handle:
        payload = yaml.safe_load(handle)
    logger.info("✅ Semantic YAML loaded successfully: %s", payload.get('name', 'unknown'))
    return payload if isinstance(payload, dict) else {}


# Top-level keys owned by the schema layer (Layer 1) vs. the logic layer (Layer 2).
# When a semantic view is split into two physical files, Layer 1 contributes the
# structural keys and Layer 2 contributes the analytic keys; the merge below keeps
# each side authoritative for its own keys.
_LAYER1_KEYS = ("tables", "relationships")
_LAYER2_KEYS = ("metrics", "filters", "analysis_modes", "calculations", "cte_queries")


def _find_logic_layer_path(layer1_path: Path, layer1_model: Mapping[str, Any]) -> Optional[Path]:
    """Resolve the Layer-2 (logic) file for a Layer-1 (schema) file, or ``None``.

    Resolution order:
      1. An explicit ``logic_ref`` top-level key in the Layer-1 file (relative
         paths are resolved against the Layer-1 file's directory).
      2. Naming convention — the same stem with a ``_logic`` suffix
         (e.g. ``view.yaml`` -> ``view_logic.yaml``).
    Returns the first path that exists, else ``None`` (legacy single-file view).
    """
    logic_ref = layer1_model.get("logic_ref")
    if isinstance(logic_ref, str) and logic_ref.strip():
        candidate = Path(logic_ref.strip()).expanduser()
        if not candidate.is_absolute():
            candidate = layer1_path.parent / candidate
        if candidate.exists():
            return candidate
        logger.warning("logic_ref %s not found (resolved to %s)", logic_ref, candidate)

    convention = layer1_path.with_name(f"{layer1_path.stem}_logic{layer1_path.suffix}")
    if convention.exists():
        return convention
    return None


def _find_schema_layer_path(layer2_path: Path, layer2_model: Mapping[str, Any]) -> Optional[Path]:
    """Resolve the Layer-1 (schema) file for a Layer-2 (logic) file, or ``None``.

    The mirror image of :func:`_find_logic_layer_path`, so a request may address a
    semantic view by *either* half. Resolution order:

      1. An explicit ``schema_ref`` top-level key in the Layer-2 file (relative
         paths are resolved against the Layer-2 file's directory).
      2. Naming convention — the same stem with the ``_logic`` suffix removed
         (e.g. ``view_logic.yaml`` -> ``view.yaml``).

    Returns the first path that exists, else ``None``.
    """
    schema_ref = layer2_model.get("schema_ref")
    if isinstance(schema_ref, str) and schema_ref.strip():
        candidate = Path(schema_ref.strip()).expanduser()
        if not candidate.is_absolute():
            candidate = layer2_path.parent / candidate
        if candidate.exists():
            return candidate
        logger.warning("schema_ref %s not found (resolved to %s)", schema_ref, candidate)

    stem = layer2_path.stem
    if stem.endswith("_logic"):
        convention = layer2_path.with_name(f"{stem[: -len('_logic')]}{layer2_path.suffix}")
        if convention.exists():
            return convention
    return None


def _is_logic_layer(model: Mapping[str, Any]) -> bool:
    """True when ``model`` looks like a Layer-2 (logic) document.

    A logic layer declares no ``tables`` (that is Layer 1's job) and carries either
    an explicit ``schema_ref`` pointer or at least one analytic key. Keeping the
    test this narrow means an empty/garbage file is NOT mistaken for a logic layer
    — it falls through to the normal path and fails with the ordinary error.
    """
    if model.get("tables"):
        return False
    if isinstance(model.get("schema_ref"), str) and model["schema_ref"].strip():
        return True
    return any(model.get(key) for key in _LAYER2_KEYS)


def _merge_layers(layer1: Dict[str, Any], layer2: Mapping[str, Any]) -> Dict[str, Any]:
    """Merge a logic layer onto a schema layer (Layer 1 owns structure + identity)."""
    merged: Dict[str, Any] = dict(layer1)
    for key in _LAYER2_KEYS:
        if key in layer2 and layer2[key] is not None:
            merged[key] = layer2[key]
    # Any additional keys present only in the logic layer (forward-compat) are
    # carried over without overriding schema-owned or identity keys.
    reserved = set(_LAYER1_KEYS) | {"name", "description", "logic_ref", "schema_ref"}
    for key, value in layer2.items():
        if key not in merged and key not in reserved:
            merged[key] = value
    return merged


def load_semantic_view(path: str) -> Dict[str, Any]:
    """Load a semantic view, merging a two-file (schema + logic) split when present.

    A semantic view may be authored as either:

    * a single legacy file (schema + logic together) — returned unchanged; or
    * two physical files: **Layer 1** (schema: ``tables`` / ``relationships``) and
      **Layer 2** (logic: ``metrics`` / ``analysis_modes`` / ``calculations`` /
      ``cte_queries`` / ``filters``).

    ``path`` may address **either half** of a two-file view:

    * a Layer-1 path resolves its logic sibling via :func:`_find_logic_layer_path`
      (``logic_ref``, else the ``<stem>_logic`` convention);
    * a Layer-2 path resolves its schema sibling via :func:`_find_schema_layer_path`
      (``schema_ref``, else stripping the ``_logic`` suffix).

    Either way the result is one dict with the exact shape
    :func:`build_semantic_catalog` consumes: Layer 1 owns the structural and
    identity keys, Layer 2 owns the analytic keys. Back-compatible — a legacy
    single file (no pointer and no sibling) is returned verbatim.

    Raises:
        ValueError: When ``path`` is a logic layer whose schema sibling cannot be
            resolved. Without this the caller would silently receive a model with
            no ``tables``, and every downstream table lookup would fail with a
            confusing "unknown source table" far from the real cause.
    """
    document = load_semantic_yaml(path)
    document_path = Path(path).expanduser()

    # Layer-2 addressed directly: resolve the schema half and merge in reverse.
    if _is_logic_layer(document):
        schema_path = _find_schema_layer_path(document_path, document)
        if schema_path is None:
            raise ValueError(
                f"{path} looks like a Layer-2 (logic) semantic view — it declares no "
                f"'tables' — but its Layer-1 (schema) file could not be resolved. "
                f"Add a 'schema_ref: <file>' key to it, or name the schema file "
                f"'{document_path.stem.removesuffix('_logic')}{document_path.suffix}' "
                f"alongside it."
            )
        layer1 = load_semantic_yaml(str(schema_path))
        logger.info("🧬 Merging logic layer %s into schema layer %s", path, schema_path)
        return _merge_layers(layer1, document)

    # Layer-1 (or a legacy single file) addressed: resolve the logic half forward.
    logic_path = _find_logic_layer_path(document_path, document)
    if logic_path is None:
        return document

    layer2 = load_semantic_yaml(str(logic_path))
    logger.info("🧬 Merging logic layer %s into schema layer %s", logic_path, path)
    return _merge_layers(document, layer2)


def parse_metric_dependencies(expr: str) -> List[str]:
    dependencies: Set[str] = set()
    for table_name, _ in PLACEHOLDER_PATTERN.findall(expr or ""):
        dependencies.add(table_name)
    return sorted(dependencies)


def build_semantic_catalog(semantic_model: Dict[str, Any]) -> SemanticCatalog:
    tables: Dict[str, TableDefinition] = {}
    fields_by_name: Dict[str, List[FieldDefinition]] = {}
    table_fields: Dict[str, Dict[str, FieldDefinition]] = {}
    metrics_by_name: Dict[str, MetricDefinition] = {}
    relationships: List[RelationshipDefinition] = []

    def register_field(table_name: str, kind: str, raw_field: Mapping[str, Any]) -> None:
        field_name = str(raw_field.get("name", "")).strip()
        expr = str(raw_field.get("expr", "")).strip()
        if not field_name or not expr:
            return

        label = str(raw_field.get("label") or raw_field.get("display_name") or "").strip()
        field_def: FieldDefinition = {
            "name": field_name,
            "table_name": table_name,
            "expr": expr,
            "data_type": str(raw_field.get("data_type", "")).strip(),
            "description": str(raw_field.get("description", "")).strip(),
            "label": label,
            "kind": kind,
            "synonyms": [str(item).strip() for item in _safe_list(raw_field.get("synonyms")) if str(item).strip()],
        }
        table_fields.setdefault(table_name, {})[field_name] = field_def
        fields_by_name.setdefault(field_name, []).append(field_def)

    for raw_table in _safe_list(semantic_model.get("tables")):
        table_dict = _safe_dict(raw_table)
        table_name = str(table_dict.get("name", "")).strip()
        if not table_name:
            continue

        base_table = _safe_dict(table_dict.get("base_table"))
        database = str(base_table.get("database", "")).strip()
        schema = str(base_table.get("schema", "")).strip()
        physical_table = str(base_table.get("table", "")).strip()
        qualified_name = ".".join([part for part in (database, schema, physical_table) if part])

        tables[table_name] = {
            "name": table_name,
            "description": str(table_dict.get("description", "")).strip(),
            "database": database,
            "schema": schema,
            "table": physical_table,
            "qualified_name": qualified_name,
        }

        for kind in ("dimensions", "time_dimensions", "facts"):
            for field in _safe_list(table_dict.get(kind)):
                register_field(table_name, kind[:-1] if kind.endswith("s") else kind, _safe_dict(field))

        for raw_metric in _safe_list(table_dict.get("metrics")):
            metric_dict = _safe_dict(raw_metric)
            metric_name = str(metric_dict.get("name", "")).strip()
            expr = str(metric_dict.get("expr", "")).strip()
            if not metric_name or not expr:
                continue
            dependencies = parse_metric_dependencies(expr) or [table_name]
            metrics_by_name[metric_name] = {
                "name": metric_name,
                "expr": expr,
                "description": str(metric_dict.get("description", "")).strip(),
                "dependency_tables": dependencies,
                "primary_table": table_name,
            }

    for raw_metric in _safe_list(semantic_model.get("metrics")):
        metric_dict = _safe_dict(raw_metric)
        metric_name = str(metric_dict.get("name", "")).strip()
        expr = str(metric_dict.get("expr", "")).strip()
        if not metric_name or not expr:
            continue
        dependencies = parse_metric_dependencies(expr)
        metrics_by_name[metric_name] = {
            "name": metric_name,
            "expr": expr,
            "description": str(metric_dict.get("description", "")).strip(),
            "dependency_tables": dependencies,
            "primary_table": dependencies[0] if len(dependencies) == 1 else None,
        }

    for raw_relationship in _safe_list(semantic_model.get("relationships")):
        rel_dict = _safe_dict(raw_relationship)
        if not rel_dict:
            continue
        relationships.append(
            {
                "name": str(rel_dict.get("name", "")).strip(),
                "left_table": str(rel_dict.get("left_table", "")).strip(),
                "right_table": str(rel_dict.get("right_table", "")).strip(),
                "relationship_columns": [
                    {
                        "left_column": str(_safe_dict(item).get("left_column", "")).strip(),
                        "right_column": str(_safe_dict(item).get("right_column", "")).strip(),
                    }
                    for item in _safe_list(rel_dict.get("relationship_columns"))
                ],
            }
        )

    catalog = {
        "tables": tables,
        "fields_by_name": fields_by_name,
        "table_fields": table_fields,
        "metrics_by_name": metrics_by_name,
        "relationships": relationships,
    }

    logger.info("📊 Semantic catalog built: %d tables, %d metrics, %d fields",
                len(tables), len(metrics_by_name), len(fields_by_name))
    logger.info("📈 Available metrics: %s", list(metrics_by_name.keys()))

    return catalog


# =============================
# Field / expression resolution
# =============================

def resolve_field(
    catalog: SemanticCatalog,
    field_name: str,
    preferred_tables: Optional[Sequence[str]] = None,
) -> Optional[FieldDefinition]:
    candidates = catalog["fields_by_name"].get(field_name, [])
    if not candidates:
        return None

    preferred = list(preferred_tables or [])
    for table_name in preferred:
        for candidate in candidates:
            if candidate["table_name"] == table_name:
                return candidate

    return candidates[0]


def build_alias_map(table_names: Sequence[str]) -> Dict[str, str]:
    aliases: Dict[str, str] = {}
    used: Set[str] = set()
    for index, table_name in enumerate(table_names, start=1):
        parts = [part for part in table_name.split("_") if part]
        alias = "".join(part[0] for part in parts) or f"t{index}"
        alias = alias[:6]
        if alias in used:
            alias = f"{alias}{index}"
        aliases[table_name] = alias
        used.add(alias)
    return aliases


def extend_catalog_with_filter_values(
    catalog: SemanticCatalog,
    filter_values: Optional[Dict[str, Any]] = None,
) -> None:
    """Extend catalog with filter values as a synthetic 'filters' table.
    
    Injects filter_values (e.g., baseline_start, current_start) as fields of a
    synthetic ``filters`` table so they can be referenced in expressions like
    ``{filters.baseline_start}``. The synthetic fields have no physical alias;
    their ``expr`` is the literal value itself, rendered directly by
    :func:`render_expression`.
    
    Args:
        catalog: Semantic catalog to extend (modified in place).
        filter_values: Dict of key→value pairs to inject. Keys become field names,
            values become the literal expressions. ``None`` or an empty dict is a no-op.
    
    Example:
        >>> catalog = build_semantic_catalog(model)
        >>> extend_catalog_with_filter_values(catalog, {"baseline_start": 202601})
        >>> # Now {filters.baseline_start} resolves to the literal 202601
    """
    if not filter_values:
        return
    
    filter_table_name = "filters"
    table_fields: Dict[str, FieldDefinition] = {}
    
    for key, value in filter_values.items():
        # Create a synthetic field whose "expr" is the literal value itself.
        # render_expression will return this expr directly (no alias prefix).
        field_def: FieldDefinition = {
            "name": key,
            "table_name": filter_table_name,
            "expr": str(value),
        }
        table_fields[key] = field_def
        catalog["fields_by_name"].setdefault(key, []).append(field_def)  # type: ignore[arg-type]
    
    catalog["table_fields"][filter_table_name] = table_fields
    # Synthetic table: not a real database table, so qualified_name == name
    catalog["tables"][filter_table_name] = {  # type: ignore[typeddict-item]
        "name": filter_table_name,
        "qualified_name": filter_table_name,
    }


def render_expression(expr: str, alias_map: Dict[str, str], catalog: SemanticCatalog) -> str:
    """Resolve ``{table.field}`` placeholders to physical SQL expressions.
    
    Handles both regular catalog tables (with physical aliases) and synthetic
    tables like ``filters`` (no alias, expr is the literal value itself).
    
    Args:
        expr: Expression containing zero or more ``{table.field}`` placeholders.
        alias_map: Table name → SQL alias for physical tables.
        catalog: Semantic catalog containing field definitions.
    
    Returns:
        Expression with all placeholders resolved to SQL (e.g., ``alias.COLUMN``
        for physical fields, or literal values for synthetic fields).
    
    Raises:
        KeyError: If a placeholder references an unknown table or field.
    """
    def replacer(match: "re.Match[str]") -> str:
        table_name = match.group(1)
        field_name = match.group(2)
        field_def = catalog["table_fields"].get(table_name, {}).get(field_name)
        if not field_def:
            raise KeyError(f"Unknown field placeholder: {table_name}.{field_name}")
        
        # Synthetic tables (e.g., "filters") have no physical alias; return expr directly
        if table_name not in alias_map:
            return field_def['expr']
        
        alias = alias_map[table_name]
        return f"{alias}.{field_def['expr']}"

    return PLACEHOLDER_PATTERN.sub(replacer, expr)


def find_relationship(
    catalog: SemanticCatalog,
    left_table: str,
    right_table: str,
) -> Optional[Tuple[RelationshipDefinition, bool]]:
    for relationship in catalog["relationships"]:
        if relationship.get("left_table") == left_table and relationship.get("right_table") == right_table:
            return relationship, False
        if relationship.get("left_table") == right_table and relationship.get("right_table") == left_table:
            return relationship, True
    return None


def build_from_clause(
    catalog: SemanticCatalog,
    required_tables: Sequence[str],
    primary_table: str,
    alias_map: Dict[str, str],
) -> str:
    if primary_table not in catalog["tables"]:
        raise KeyError(f"Unknown primary table: {primary_table}")

    joined_tables: Set[str] = {primary_table}
    clauses = [f"FROM {catalog['tables'][primary_table]['qualified_name']} {alias_map[primary_table]}"]
    pending = [table_name for table_name in required_tables if table_name != primary_table]

    while pending:
        progress = False
        for table_name in list(pending):
            for joined in list(joined_tables):
                rel_info = find_relationship(catalog, joined, table_name)
                if rel_info is None:
                    continue
                relationship, reversed_direction = rel_info
                left_alias = alias_map[joined]
                right_alias = alias_map[table_name]
                conditions: List[str] = []
                for column_pair in _safe_list(relationship.get("relationship_columns")):
                    pair = _safe_dict(column_pair)
                    left_column = str(pair.get("left_column", "")).strip()
                    right_column = str(pair.get("right_column", "")).strip()
                    if not left_column or not right_column:
                        continue
                    if reversed_direction:
                        conditions.append(f"{left_alias}.{right_column} = {right_alias}.{left_column}")
                    else:
                        conditions.append(f"{left_alias}.{left_column} = {right_alias}.{right_column}")
                clauses.append(
                    f"LEFT JOIN {catalog['tables'][table_name]['qualified_name']} {right_alias}"
                    f" ON {' AND '.join(conditions)}"
                )
                joined_tables.add(table_name)
                pending.remove(table_name)
                progress = True
                break
            if progress:
                break
        if not progress:
            raise ValueError(f"Unable to join tables with available relationships: {pending}")

    return "\n".join(clauses)


# =============================
# Filter rendering
# =============================

def render_filter_clause(
    filter_condition: FilterCondition,
    catalog: SemanticCatalog,
    alias_map: Dict[str, str],
    preferred_tables: Sequence[str],
) -> str:
    operator = filter_condition["operator"].lower().strip()

    if operator == "named_filter":
        return render_expression(filter_condition["value"], alias_map, catalog)

    field_def = resolve_field(catalog, filter_condition["field"], preferred_tables=preferred_tables)
    if field_def is None:
        raise KeyError(f"Unknown filter field: {filter_condition['field']}")

    table_name = field_def["table_name"]
    if table_name not in alias_map:
        raise KeyError(
            f"Filter field {filter_condition['field']!r} resolves to table "
            f"{table_name!r}, which is not in scope here (in scope: "
            f"{sorted(alias_map)}). Join that table into the query, or route the "
            f"filter away from this scope."
        )
    alias = alias_map[table_name]
    field_sql = f"{alias}.{field_def['expr']}"

    # Null tests take no value, so read `value` only after they are handled --
    # otherwise a perfectly valid {field, operator: is not null} leaf KeyErrors.
    if operator in ("is null", "is not null"):
        return f"{field_sql} {operator.upper()}"

    if "value" not in filter_condition:
        raise ValueError(
            f"Filter on {filter_condition['field']!r} with operator {operator!r} "
            f"requires a 'value'."
        )
    raw_filter_value = filter_condition["value"]
    raw_value = str(raw_filter_value).strip()
    data_type = str(field_def.get("data_type", "")).lower().strip()

    def literal(value: str) -> str:
        if data_type in {"number", "integer", "float"} and maybe_number(value):
            return value
        if maybe_number(value) and data_type != "string":
            return value
        return f"'{escape_sql_string(value)}'"

    if operator in {"=", ">", "<", ">=", "<="}:
        if operator == "=" and isinstance(raw_filter_value, (list, tuple, set)):
            values = [str(item).strip() for item in raw_filter_value if str(item).strip()]
            if not values:
                raise ValueError(f"IN filter expects at least one value: {filter_condition}")
            return f"{field_sql} IN ({', '.join(literal(item) for item in values)})"
        return f"{field_sql} {operator} {literal(raw_value)}"
    if operator == "like":
        return f"{field_sql} LIKE {literal(raw_value)}"
    if operator == "in":
        if isinstance(raw_filter_value, (list, tuple, set)):
            values = [str(item).strip() for item in raw_filter_value if str(item).strip()]
        else:
            values = [item.strip() for item in raw_value.split(",") if item.strip()]
        if not values:
            raise ValueError(f"IN filter expects at least one value: {filter_condition}")
        return f"{field_sql} IN ({', '.join(literal(item) for item in values)})"
    if operator == "between":
        pieces = [item.strip() for item in re.split(r"\band\b", raw_value, flags=re.IGNORECASE) if item.strip()]
        if len(pieces) != 2:
            raise ValueError(f"BETWEEN filter expects 'value1 and value2': {filter_condition}")
        return f"{field_sql} BETWEEN {literal(pieces[0])} AND {literal(pieces[1])}"

    raise ValueError(f"Unsupported filter operator: {filter_condition['operator']}")


def _normalize_filter_values(filter_condition: FilterCondition) -> List[Any]:
    """Normalize filter values into a flat list for OR-style grouping."""
    value = filter_condition["value"]
    operator = str(filter_condition.get("operator", "")).lower().strip()
    if isinstance(value, (list, tuple, set)):
        return [item for item in value]
    if operator == "in" and isinstance(value, str):
        return [item.strip() for item in value.split(",") if item.strip()]
    return [value]


def normalize_filters_for_sql(filters: Sequence[FilterCondition]) -> List[FilterCondition]:
    """Collapse repeated field filters into a single IN clause to avoid AND conflicts."""
    grouped: Dict[Tuple[str, FilterSource], Dict[str, Any]] = {}
    ordered_entries: List[Tuple[str, Any]] = []

    for filter_condition in filters:
        operator = str(filter_condition.get("operator", "")).lower().strip()
        if operator in {"=", "in"}:
            key = (filter_condition["field"], filter_condition["source"])
            if key not in grouped:
                grouped[key] = {
                    "template": filter_condition,
                    "operators": set(),
                    "values": [],
                }
                ordered_entries.append(("group", key))
            grouped[key]["operators"].add(operator)
            grouped[key]["values"].extend(_normalize_filter_values(filter_condition))
        else:
            ordered_entries.append(("single", filter_condition))

    merged: List[FilterCondition] = []
    emitted_groups: Set[Tuple[str, FilterSource]] = set()

    for entry_type, entry in ordered_entries:
        if entry_type == "single":
            merged.append(entry)
            continue
        if entry in emitted_groups:
            continue
        emitted_groups.add(entry)
        group = grouped[entry]
        values: List[Any] = []
        seen: Set[str] = set()
        for value in group["values"]:
            key = _filter_value_key(value)
            if key in seen:
                continue
            seen.add(key)
            values.append(value)

        template = group["template"]
        if len(values) == 1 and group["operators"] == {"="}:
            merged.append({**template, "operator": "=", "value": values[0]})
        else:
            merged.append({**template, "operator": "in", "value": values})

    return merged


# =============================
# Nested boolean filter tree (Step 0 addition)
# =============================
#
# Extends correlation's flat-AND filter list with an arbitrarily nested
# AND/OR grammar while reusing render_filter_clause for the leaves:
#   * a plain list/tuple            -> implicit top-level AND of its children
#   * {"logic": "AND"|"OR",
#      "conditions": [child, ...]}  -> an explicit boolean group
#   * anything else (a dict)        -> a leaf FilterCondition
# The output is fully parenthesized so operator precedence is unambiguous.

FilterNode = Union[Dict[str, Any], List[Any], Tuple[Any, ...]]
_VALID_LOGIC = {"AND", "OR"}
_MAX_FILTER_DEPTH = 6


def _is_group(node: Any) -> bool:
    return isinstance(node, dict) and "logic" in node and "conditions" in node


def render_filter_tree(
    node: FilterNode,
    catalog: SemanticCatalog,
    alias_map: Dict[str, str],
    preferred_tables: Sequence[str],
    *,
    _depth: int = 0,
) -> str:
    if _depth > _MAX_FILTER_DEPTH:
        raise ValueError(f"Filter nesting exceeds max depth {_MAX_FILTER_DEPTH}")
    if isinstance(node, (list, tuple)):
        node = {"logic": "AND", "conditions": list(node)}
    if _is_group(node):
        logic = str(node.get("logic", "AND")).upper().strip()
        if logic not in _VALID_LOGIC:
            raise ValueError(f"Unsupported filter logic: {node.get('logic')!r}")
        conditions = node.get("conditions") or []
        if not conditions:
            raise ValueError("Filter group must have at least one condition")
        rendered = [
            render_filter_tree(child, catalog, alias_map, preferred_tables, _depth=_depth + 1)
            for child in conditions
        ]
        joiner = f" {logic} "
        return "(" + joiner.join(rendered) + ")"
    return "(" + render_filter_clause(node, catalog, alias_map, preferred_tables) + ")"


def collect_filter_fields(node: FilterNode) -> List[str]:
    """Return every ``field`` name referenced by a (possibly nested) filter node.

    Used to determine which tables a filter tree touches (so the FROM clause can
    join them) without rendering any SQL. ``named_filter`` leaves carry no
    ``field`` and contribute nothing here.
    """
    if isinstance(node, (list, tuple)):
        out: List[str] = []
        for child in node:
            out.extend(collect_filter_fields(child))
        return out
    if _is_group(node):
        out = []
        for child in node.get("conditions") or []:
            out.extend(collect_filter_fields(child))
        return out
    field = node.get("field")
    return [field] if field else []


def collect_filter_leaves(node: FilterNode) -> List[Dict[str, Any]]:
    """Return every leaf dict (``{field, operator, value}``) in a filter tree.

    Walks the same grammar as :func:`collect_filter_fields` (a ``list``/``tuple``
    is an implicit ``AND``; a dict with ``logic`` + ``conditions`` is a group;
    anything else is a leaf), but returns the raw leaf dicts so callers can read
    both the ``field`` and its ``value`` without rendering SQL. ``named_filter``
    and other field-less leaves are skipped (nothing to key on).
    """
    if isinstance(node, (list, tuple)):
        out: List[Dict[str, Any]] = []
        for child in node:
            out.extend(collect_filter_leaves(child))
        return out
    if _is_group(node):
        out = []
        for child in node.get("conditions") or []:
            out.extend(collect_filter_leaves(child))
        return out
    if isinstance(node, dict) and node.get("field"):
        return [node]
    return []


def _leaf_key(leaf: Dict[str, Any]) -> Tuple[str, str, Any]:
    """Stable, hashable identity for a filter leaf (used only for dedup).

    Two leaves are "the same" when they share ``field``, ``operator`` (compared
    case-insensitively, matching :func:`render_filter_clause`) and ``value``. A
    list/tuple/set value is order-sensitively canonicalized so that, e.g., an
    ``IN [a, b]`` leaf is distinct from ``IN [b, a]`` only if the members differ.
    """
    value = leaf.get("value")
    if isinstance(value, (list, tuple, set)):
        value_key: Any = ("__seq__", tuple(str(item) for item in value))
    else:
        value_key = str(value)
    operator = str(leaf.get("operator") or "").strip().lower()
    return (str(leaf.get("field")), operator, value_key)


def build_filter_tree_from_cards(
    cards: Sequence[Dict[str, Any]],
    *,
    dedup: bool = True,
) -> Optional[Dict[str, Any]]:
    """Combine several cards' flat filter lists into one nested AND/OR filter tree.

    Each card carries a flat list of leaf conditions under ``card["filters"]``
    (``{field, operator, value, source}``; multiple leaves on one card mean an
    implicit **AND**). This unions the cards into a single tree so one ranking
    query can rank the *true combined population*::

        card A (a AND b), card B (c AND d)  ->  ((a AND b) OR (c AND d))

    OR-ing the cards into a single tree (rather than ranking each card separately
    and merging) is the statistically correct way to feed a
    ``GROUP BY <dim> ... ORDER BY <metric> DESC LIMIT k`` ranking: independently
    ``LIMIT k``-truncated per-card rankings drop groups that would top the
    combined population, and per-group metrics summed over overlapping card
    populations double-count shared rows.

    This is pure filter-tree algebra: it does **no** field validation and needs
    **no** semantic catalog (the consuming agent validates the produced tree
    against its own semantic view). Each leaf is reduced to
    ``{field, operator, value}`` — the cosmetic ``source`` and any other keys are
    dropped, and a missing/blank operator defaults to ``"="`` to match
    :func:`render_filter_clause`.

    Args:
        cards: Card dicts, each optionally carrying a ``filters`` list. Non-dict
            entries, non-list ``filters``, field-less leaves, and cards that
            contribute no usable leaf are skipped.
        dedup: When True (default), drop duplicate leaves within a card and
            identical AND-groups across cards. Two cards sharing a *field* but
            with different *values* stay as separate OR branches (never collapsed
            into a single ``IN``).

    Returns:
        - ``None`` when no card contributes a usable leaf (the caller then ranks
          unfiltered — :func:`~deep_research_utils.topk_sql._is_empty_filter`
          treats ``None`` as empty).
        - The single card's ``{"logic": "AND", "conditions": [...]}`` group when
          exactly one card contributes (no redundant OR wrapper).
        - ``{"logic": "OR", "conditions": [<AND groups>]}`` when several do.
    """
    groups: List[Dict[str, Any]] = []
    seen_group_keys: Set[Tuple[Tuple[str, str, Any], ...]] = set()

    for card in cards or []:
        if not isinstance(card, dict):
            continue
        raw_leaves = card.get("filters") or []
        if not isinstance(raw_leaves, (list, tuple)):
            continue

        leaves: List[Dict[str, Any]] = []
        seen_leaf_keys: Set[Tuple[str, str, Any]] = set()
        for raw in raw_leaves:
            if not isinstance(raw, dict):
                continue
            field = raw.get("field")
            if not field:
                continue
            operator = str(raw.get("operator") or "").strip() or "="
            leaf = {"field": field, "operator": operator, "value": raw.get("value")}
            if dedup:
                key = _leaf_key(leaf)
                if key in seen_leaf_keys:
                    continue
                seen_leaf_keys.add(key)
            leaves.append(leaf)

        if not leaves:
            continue

        if dedup:
            gkey = tuple(_leaf_key(leaf) for leaf in leaves)
            if gkey in seen_group_keys:
                continue
            seen_group_keys.add(gkey)
        groups.append({"logic": "AND", "conditions": leaves})

    if not groups:
        return None
    if len(groups) == 1:
        return groups[0]
    return {"logic": "OR", "conditions": groups}


def collect_pattern_scope_cards(
    pattern: Mapping[str, Any],
    *,
    card_lookup: Mapping[str, Dict[str, Any]],
    group_lookup: Mapping[str, Mapping[str, Any]],
) -> List[Dict[str, Any]]:
    """Resolve a pattern's *group-scoped* card set (Plan B card selection).

    A business pattern's ``source_group_ids`` define its business scope, while
    ``source_card_ids`` are only representative evidence (per the pattern-agent
    contract). To feed a ranking that should span the pattern's whole
    population, this expands each ``source_group_id`` to every card its group
    contains (the group's ``card_ids``) and returns those card dicts.

    Falls back to the pattern's ``source_card_ids`` when no group resolves — an
    older pattern payload without ``source_group_ids``, or a caller that could
    not supply a ``group_lookup`` — so the selection never silently yields an
    empty scope while evidence cards are available.

    Cards are de-duplicated (one card may belong to several groups) with
    first-seen order preserved; ids resolving to no card are dropped.

    Args:
        pattern: A business-pattern dict carrying ``source_group_ids`` and/or
            ``source_card_ids``.
        card_lookup: ``card_id`` -> card dict.
        group_lookup: ``group_id`` -> group dict (each carrying ``card_ids``).

    Returns:
        The resolved card dicts, in first-seen order (possibly empty).
    """
    ordered_ids: List[str] = []
    for group_id in pattern.get("source_group_ids") or []:
        group = group_lookup.get(str(group_id))
        if not isinstance(group, Mapping):
            continue
        ordered_ids.extend(str(card_id) for card_id in (group.get("card_ids") or []))

    if not ordered_ids:
        ordered_ids = [str(card_id) for card_id in (pattern.get("source_card_ids") or [])]

    cards: List[Dict[str, Any]] = []
    seen: Set[str] = set()
    for card_id in ordered_ids:
        if card_id in seen:
            continue
        seen.add(card_id)
        card = card_lookup.get(card_id)
        if isinstance(card, dict):
            cards.append(card)
    return cards


def build_group_scope_filter_tree(
    cards: Sequence[Dict[str, Any]],
    *,
    include_sources: Sequence[str] = ("interaction_cell",),
) -> Optional[Dict[str, Any]]:
    """Build one AND-of-INs filter tree spanning a group's population.

    Where :func:`build_filter_tree_from_cards` OR-unions each card's *full* AND
    of leaves — every dimension of one interaction cell, including the
    ``drill_context`` clinical leaves (DRG / diagnosis / procedure / auth) —
    this instead:

    * keeps only leaves whose ``source`` is in ``include_sources`` (default: the
      ``interaction_cell`` provider-scoping leaves), and
    * collapses repeated values of the same ``field`` across all cards into a
      single ``IN`` list.

    The result is one ``AND`` group, e.g.::

        product_description    = PPO
        AND facility_type      = RESIDENTIAL TREATMENT CTR
        AND service_area_state IN (ME, CT)
        AND lob_description    = Commercial Individual

    This is the population a ``GROUP BY <dim> ... ORDER BY <metric> DESC
    LIMIT k`` ranking (e.g. the reimbursement top-K over
    ``provider_taxonomy_type``) should span: the pattern's business scope, not
    the pinpoint co-occurrence of one interaction cell. Dropping the clinical
    ``drill_context`` leaves is what keeps the ranked population from collapsing
    to one or two groups (or nothing).

    Like the sibling builder, this is pure filter-tree algebra: no field
    validation and no semantic catalog (the consuming agent validates the tree
    against its own semantic view). A source leaf's operator is ignored (only
    its ``field`` and ``value`` are read); the emitted operator is ``"in"`` for
    a multi-value field and ``"="`` for a single value. ``None`` leaf values are
    dropped.

    Args:
        cards: Card dicts, each optionally carrying a ``filters`` list of
            ``{field, operator, value, source}`` leaves. A leaf ``value`` that
            is itself a list/tuple/set is flattened into the field's value set.
        include_sources: Leaf ``source`` values to keep (compared
            case-insensitively). Leaves with any other source — or no source —
            are dropped. Pass a wider sequence to also admit e.g.
            ``"drill_context"`` leaves.

    Returns:
        - ``None`` when no card contributes a kept leaf (the caller then ranks
          unfiltered, matching :func:`build_filter_tree_from_cards`).
        - ``{"logic": "AND", "conditions": [...]}`` with one leaf per field
          otherwise (fields and values in first-seen order).
    """
    allowed = {str(source).strip().lower() for source in include_sources}

    values_by_field: Dict[str, List[Any]] = {}
    seen_by_field: Dict[str, Set[str]] = {}

    for card in cards or []:
        if not isinstance(card, dict):
            continue
        raw_leaves = card.get("filters") or []
        if not isinstance(raw_leaves, (list, tuple)):
            continue
        for raw in raw_leaves:
            if not isinstance(raw, dict):
                continue
            field = raw.get("field")
            if not field:
                continue
            source = str(raw.get("source") or "").strip().lower()
            if allowed and source not in allowed:
                continue
            field_key = str(field)
            value = raw.get("value")
            values = value if isinstance(value, (list, tuple, set)) else [value]
            bucket = values_by_field.setdefault(field_key, [])
            seen = seen_by_field.setdefault(field_key, set())
            for item in values:
                if item is None:
                    continue
                item_key = str(item)
                if item_key in seen:
                    continue
                seen.add(item_key)
                bucket.append(item)

    conditions: List[Dict[str, Any]] = []
    for field_key, values in values_by_field.items():
        if not values:
            continue
        if len(values) == 1:
            conditions.append({"field": field_key, "operator": "=", "value": values[0]})
        else:
            conditions.append({"field": field_key, "operator": "in", "value": list(values)})

    if not conditions:
        return None
    return {"logic": "AND", "conditions": conditions}


def build_period_filter_leaves(
    *,
    snap_month: Optional[Any] = None,
    incurred_start: Optional[Any] = None,
    incurred_end: Optional[Any] = None,
    snap_field: str = "snap_month",
    incurred_field: str = "incurred_month",
) -> List[Dict[str, Any]]:
    """Build snap / incurred year-month period filter leaves (``YYYYMM``).

    Emits leaves using *logical* field names so the tree stays portable across
    semantic views (the consuming agent's catalog resolves the physical column,
    e.g. ``SNAP_YEAR_MNTH_NBR`` / ``INCRD_YEAR_MNTH_NBR`` /
    ``ANLYTC_INCRD_YEAR_MNTH_NBR``). ``None`` inputs omit their leaf, so this is
    safe to call with whatever subset of the period is available.

    * ``snap_month`` -> ``{field: snap_month, operator: "=", value: int}``.
    * both incurred bounds -> a single ``between`` leaf whose value is the
      ``"<start> and <end>"`` string that :func:`render_filter_clause` expects.
    * a lone incurred bound -> ``>=`` (start only) or ``<=`` (end only).

    Args:
        snap_month: Snapshot year-month (``YYYYMM``); applied as an exact match.
        incurred_start: Inclusive lower bound of the incurred window (``YYYYMM``).
        incurred_end: Inclusive upper bound of the incurred window (``YYYYMM``).
        snap_field: Logical field name for the snapshot dimension.
        incurred_field: Logical field name for the incurred dimension.

    Returns:
        A (possibly empty) list of ``{field, operator, value}`` leaves.
    """
    leaves: List[Dict[str, Any]] = []
    if snap_month is not None:
        leaves.append({"field": snap_field, "operator": "=", "value": int(snap_month)})
    if incurred_start is not None and incurred_end is not None:
        leaves.append(
            {
                "field": incurred_field,
                "operator": "between",
                "value": f"{int(incurred_start)} and {int(incurred_end)}",
            }
        )
    elif incurred_start is not None:
        leaves.append({"field": incurred_field, "operator": ">=", "value": int(incurred_start)})
    elif incurred_end is not None:
        leaves.append({"field": incurred_field, "operator": "<=", "value": int(incurred_end)})
    return leaves


def combine_filter_trees_and(*nodes: Any) -> Optional[Dict[str, Any]]:
    """AND-combine any mix of filter trees, leaf lists, and bare leaves.

    Accepts the outputs of the card/tree builders (an ``{"logic", "conditions"}``
    group, possibly ``None``) alongside a list of leaves from
    :func:`build_period_filter_leaves`, and folds them into one ``AND`` group so
    a top-K ranking is narrowed by *both* the provider scope and the period.

    ``None`` and empty nodes are dropped. A top-level ``AND`` group is flattened
    into the result (its ``conditions`` are spliced in) to keep nesting shallow
    for :func:`render_filter_tree` (whose depth cap is 6); ``OR`` groups and
    leaves are kept intact. Returns ``None`` when nothing survives, and returns a
    lone surviving group/leaf unwrapped.

    Args:
        *nodes: Filter trees (dict groups), leaf lists/tuples, or bare leaf
            dicts, in the order they should be ANDed.

    Returns:
        A single ``{"logic": "AND", "conditions": [...]}`` group, a lone
        unwrapped node, or ``None``.
    """
    conditions: List[Dict[str, Any]] = []

    def _absorb(node: Any) -> None:
        if node is None:
            return
        if isinstance(node, (list, tuple)):
            for child in node:
                _absorb(child)
            return
        if not isinstance(node, dict):
            return
        if _is_group(node):
            logic = str(node.get("logic", "AND")).upper().strip()
            children = node.get("conditions") or []
            if logic == "AND":
                for child in children:
                    _absorb(child)
                return
            if children:  # keep a non-empty OR group intact
                conditions.append(node)
            return
        # bare leaf
        conditions.append(node)

    for node in nodes:
        _absorb(node)

    if not conditions:
        return None
    if len(conditions) == 1:
        return conditions[0]
    return {"logic": "AND", "conditions": conditions}


# =============================
# Path resolution
# =============================

def resolve_semantic_model_path(
    yaml_path: Optional[str],
    *,
    allowed_subdir: str = "configs/correlation_pattern",
    default_path: Optional[Union[str, Path]] = None,
    project_root: Optional[Path] = None,
    error_cls: type = ValueError,
) -> str:
    """Resolve and validate a semantic-model YAML path.

    Generalized from correlation's ``_resolve_semantic_model_path``: the allowed
    directory (``allowed_subdir``), the "no path given" fallback (``default_path``),
    and the project root are parameters, and the exception type raised on failure
    is injectable (``error_cls``). The latter lets callers in higher-level packages
    surface their own error type **without** this low-level module importing them
    (which would create a circular import).

    Security: the resolved path MUST live inside ``project_root / allowed_subdir``
    and MUST exist, exactly as the correlation original enforced.

    Args:
        yaml_path: Path to YAML (relative or absolute). If ``None``, uses ``default_path``.
        allowed_subdir: Directory (relative to project root) the path must live within.
        default_path: Path used when ``yaml_path`` is ``None``.
        project_root: Override the project root (defaults to this file's ``parents[4]``,
            which is the repository root — the same location correlation computes).
        error_cls: Exception type raised on validation failure.

    Returns:
        The absolute, validated path as a string.
    """
    if project_root is None:
        project_root = Path(__file__).resolve().parents[4]
    allowed_dir = project_root / allowed_subdir

    if yaml_path is None:
        if default_path is None:
            raise error_cls(
                "No semantic model YAML path provided and no default configured."
            )
        candidate = Path(default_path)
    else:
        candidate = Path(yaml_path).expanduser()

        # Resolve relative paths against project root
        if not candidate.is_absolute():
            candidate = project_root / candidate

    resolved = candidate.resolve()

    # Security: Ensure path is within allowed directory
    try:
        resolved.relative_to(allowed_dir)
    except ValueError:
        raise error_cls(
            f"YAML path must be within {allowed_dir}. "
            f"Attempted to access: {resolved}"
        )

    if not resolved.exists():
        raise error_cls(
            f"Semantic model YAML not found at {resolved}. "
            f"Original path: {yaml_path}"
        )

    return str(resolved)
