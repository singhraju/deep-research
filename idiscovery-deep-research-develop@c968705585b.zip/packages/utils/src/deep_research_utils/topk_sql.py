"""Semantic-model-driven top-K ranking query builder.

Builds an aggregate *ranking* query of the form::

    SELECT <dim_alias>.<dim_expr> AS <dimension>,
           <rendered_metric>      AS <metric_alias>
    FROM <fact_table> <fact_alias>
    [LEFT JOIN <dim_table> <dim_alias> ON <declared relationship>]
    [WHERE <rendered filter tree>]
    GROUP BY <dim_alias>.<dim_expr>
    ORDER BY <rendered_metric> DESC
    LIMIT <k>

The driving use case is *top-K taxonomies*: rank a claims population by a
declared metric (default ``total_paid``) grouped by a single dimension (default
``provider_taxonomy_type`` — the provider specialty), optionally narrowed by a
nested AND/OR filter tree, keeping the top ``k`` groups.

The metric must be **single-table** (computable from one table — its own): the
fact table that owns the metric drives the query. The grouping *dimension*,
however, may live either on that same table (a flat ``GROUP BY``) or on a
**separate table joined in via a declared relationship** — in which case the
fact table is ``LEFT JOIN``-ed to the dimension table (every fact row is kept,
so no measured amount is silently dropped; fact rows with no matching dimension
row fall into a ``NULL`` group). This lets you, e.g., rank an ``expense_detail``
population's ``total_paid`` by a ``ddim_prov_acct`` provider attribute.

Why a dedicated module (rather than folding into :mod:`cte_sql`)? This is a
different SQL *strategy* — a single ``GROUP BY … ORDER BY … LIMIT`` over one
fact table (optionally enriched by one joined dimension table), not a multi-CTE
aggregate-then-join. A metric that itself spans multiple tables (e.g. a PMPM
ratio across claims + membership) needs aggregate-then-join to avoid
member-month fan-out and is rejected here — that is CTE territory. Like
:mod:`~deep_research_utils.cte_sql`, this module lives in the lowest-level
package and builds ONLY on the shared primitives in
:mod:`~deep_research_utils.semantic_sql` — it MUST NOT import from
``deep_research_core`` or ``deep_research_agents``.

Injection-safety comes entirely from the shared primitives: dimension/metric
identifiers flow through the catalog (never interpolated raw), the metric
expression is rendered by :func:`~deep_research_utils.semantic_sql.render_expression`
(catalog-resolved physical columns), and filter values are escaped by
:func:`~deep_research_utils.semantic_sql.render_filter_tree`.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Optional

from deep_research_utils.semantic_sql import (
    SemanticCatalog,
    build_alias_map,
    build_from_clause,
    build_semantic_catalog,
    extend_catalog_with_filter_values,
    find_relationship,
    render_expression,
    render_filter_tree,
    resolve_field,
)

__all__ = [
    "IDENTIFIER_RE",
    "DEFAULT_DIMENSION",
    "DEFAULT_METRIC",
    "build_topk_query_sql",
]

# A SQL identifier we are willing to emit verbatim (dimension name, metric
# alias). Everything else — physical column expressions, filter values — flows
# through the catalog / escaping helpers in ``semantic_sql``.
IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# "Top-K taxonomies" defaults: rank provider specialties by total paid.
DEFAULT_DIMENSION = "provider_taxonomy_type"
DEFAULT_METRIC = "total_paid"


def _require_identifier(value: str, what: str) -> str:
    value = str(value).strip()
    if not IDENTIFIER_RE.match(value):
        raise ValueError(f"Invalid {what}: {value!r} (must match {IDENTIFIER_RE.pattern})")
    return value


def _is_empty_filter(node: Any) -> bool:
    """True when a filter node contributes no predicate (so no WHERE is emitted)."""
    if node is None:
        return True
    if isinstance(node, (list, tuple)):
        return len(node) == 0
    if isinstance(node, dict):
        if "logic" in node and "conditions" in node:
            return not node.get("conditions")
        return False  # a leaf FilterCondition is always meaningful
    return True


def _resolve_metric(catalog: SemanticCatalog, name: str) -> Dict[str, Any]:
    """Resolve a ranking metric by exact name or unique bare-name suffix.

    The catalog keys table-level metrics by their full name
    (``expense_detail.total_paid``); callers may pass either that or the bare
    ``total_paid``. Raises ``ValueError`` (listing the available metrics) on a
    blank, unknown, or ambiguous name.
    """
    metrics = catalog["metrics_by_name"]
    key = str(name or "").strip()
    if not key:
        raise ValueError(f"metric must not be blank. Available: {sorted(metrics)}")
    if key in metrics:
        return metrics[key]
    suffix_matches = [m for k, m in metrics.items() if k.split(".")[-1] == key]
    if len(suffix_matches) == 1:
        return suffix_matches[0]
    if not suffix_matches:
        raise ValueError(f"Unknown metric {name!r}. Available: {sorted(metrics)}")
    raise ValueError(
        f"Ambiguous metric {name!r} — matches "
        f"{sorted(m['name'] for m in suffix_matches)}; use the fully-qualified name"
    )


def build_topk_query_sql(
    semantic_model: Dict[str, Any],
    *,
    dimension: str = DEFAULT_DIMENSION,
    metric: str = DEFAULT_METRIC,
    top_k: int = 10,
    filters: Any = None,
    catalog: Optional[SemanticCatalog] = None,
    descending: bool = True,
    filter_values: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a top-K ranking query from a semantic model.

    Ranks ``dimension`` groups by ``metric`` (a metric declared in the model),
    optionally narrowed by a nested AND/OR ``filters`` tree, keeping the top
    ``top_k`` rows. The metric's (single) table drives the query; if the
    dimension lives on a different table, it is ``LEFT JOIN``-ed in via a
    declared relationship.

    Returns a dict with the built ``sql`` plus resolved metadata
    (``dimension``, ``metric`` fully-qualified name, ``metric_alias``, ``table``
    — the driving fact table, ``dimension_table``, ``tables`` — every table in
    the query, ``top_k``, ``descending``, ``has_filters``).
    
    Args:
        semantic_model: The full semantic YAML model.
        dimension: Grouping dimension name (field name from catalog).
        metric: Metric name (declared in the model's metrics).
        top_k: Number of top groups to return.
        filters: Optional nested AND/OR filter tree.
        catalog: Optional pre-built catalog.
        descending: If True, order by metric DESC; else ASC.
        filter_values: Optional dict injected as synthetic ``filters`` table for
            placeholders like ``{filters.baseline_start}``.

    Raises ``ValueError`` on an unknown dimension/metric, a non-positive
    ``top_k``, a metric that spans more than one table (multi-table ratios are
    CTE territory, not a flat GROUP BY), or a dimension on a table with no
    declared relationship to the metric's table.
    """
    if catalog is None:
        catalog = build_semantic_catalog(semantic_model)
    
    # Inject filter_values as a synthetic "filters" table before rendering
    extend_catalog_with_filter_values(catalog, filter_values)

    try:
        k = int(top_k)
    except (TypeError, ValueError):
        raise ValueError(f"top_k must be a positive integer, got {top_k!r}")
    if k < 1:
        raise ValueError(f"top_k must be >= 1, got {k}")

    dim_name = _require_identifier(dimension, "dimension name")
    dim_field = resolve_field(catalog, dim_name)
    if dim_field is None:
        raise ValueError(
            f"Unknown dimension {dim_name!r} — not declared in the semantic model."
        )
    dim_table = dim_field["table_name"]

    metric_def = _resolve_metric(catalog, metric)
    metric_alias = _require_identifier(metric_def["name"].split(".")[-1], "metric alias")

    # The metric must be single-table: computable from exactly one table (its own).
    # A metric spanning multiple tables (e.g. a PMPM ratio across claims +
    # membership) needs aggregate-then-join to avoid member-month fan-out — that is
    # CTE territory, not a flat GROUP BY.
    metric_tables = set(metric_def.get("dependency_tables") or [])
    if len(metric_tables) != 1:
        raise ValueError(
            f"Metric {metric_def['name']!r} depends on tables {sorted(metric_tables)}; "
            f"top-K ranking requires a single-table metric (multi-table ratios are CTE "
            f"territory)."
        )
    metric_table = next(iter(metric_tables))

    # The fact table that owns the metric drives the query. When the grouping
    # dimension lives on a *different* table, that table is joined in via a
    # declared relationship (build_from_clause LEFT JOINs it from the fact, so
    # every fact row — hence every measured amount — is kept). A single-table
    # ranking (dimension on the fact table) needs no join.
    if dim_table == metric_table:
        required_tables = [metric_table]
    else:
        if find_relationship(catalog, metric_table, dim_table) is None:
            raise ValueError(
                f"Cannot rank dimension {dim_name!r} (on table {dim_table!r}) by metric "
                f"{metric_def['name']!r} (on table {metric_table!r}): no relationship is "
                f"declared between {metric_table!r} and {dim_table!r}. Add one under "
                f"'relationships:' in the semantic model."
            )
        required_tables = [metric_table, dim_table]

    primary_table = metric_table
    alias_map = build_alias_map(required_tables)
    from_clause = build_from_clause(catalog, required_tables, primary_table, alias_map)

    dim_physical = f"{alias_map[dim_table]}.{dim_field['expr']}"
    metric_sql = render_expression(metric_def["expr"], alias_map, catalog)

    lines = [
        f"SELECT {dim_physical} AS {dim_name},",
        f"       {metric_sql} AS {metric_alias}",
        from_clause,
    ]

    has_filters = not _is_empty_filter(filters)
    if has_filters:
        # render_filter_tree raises KeyError for a filter field that is on none of
        # the queried tables; normalize it to ValueError so the builder's contract
        # stays "bad input -> ValueError" (the agent maps that to
        # AgentConfigurationError).
        try:
            where_sql = render_filter_tree(filters, catalog, alias_map, required_tables)
        except KeyError as exc:
            raise ValueError(
                f"Invalid filter — field is not on any queried table {required_tables}: {exc}"
            ) from exc
        lines.append(f"WHERE {where_sql}")

    direction = "DESC" if descending else "ASC"
    lines.append(f"GROUP BY {dim_physical}")
    lines.append(f"ORDER BY {metric_sql} {direction}")
    lines.append(f"LIMIT {k}")

    return {
        "sql": "\n".join(lines),
        "dimension": dim_name,
        "metric": metric_def["name"],
        "metric_alias": metric_alias,
        "table": primary_table,
        "dimension_table": dim_table,
        "tables": required_tables,
        "top_k": k,
        "descending": bool(descending),
        "has_filters": has_filters,
    }
