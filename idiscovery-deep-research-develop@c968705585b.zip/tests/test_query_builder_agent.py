"""Tests for :class:`deep_research_core.query_builder_agent.QueryBuilderAgent`.

The base class provides three reusable capabilities, exercised here with an
in-memory semantic model + a stubbed ``execute_sql_to_df`` (no live Snowflake /
LLM, and the heavy ``AgentBase.__init__`` is bypassed):

  * ``build_calculation`` dispatch on a Layer-2 ``calculations`` entry's
    ``type`` (topk / cte_pipeline / raw_sql), plus fail-fast on an unknown
    name or type;
  * the ``_persist_run`` hook defaulting to "persist nothing";
  * ``run_query_node`` assembling the result envelope and splicing a
    subclass's persisted artifacts.
"""

from __future__ import annotations

import logging

import pandas as pd
import pytest

from deep_research_core import QueryBuilderAgent
from deep_research_core.base_agent import AgentConfigurationError
import deep_research_core.query_builder_agent as qba


# ==========================================================================
# Fixtures / helpers
# ==========================================================================

def _model() -> dict:
    """Single-table ``claims`` model carrying all three calculation types."""
    return {
        "name": "qba_view",
        "tables": [
            {
                "name": "claims",
                "base_table": {"database": "DB", "schema": "SCH", "table": "CLAIMS"},
                "dimensions": [
                    {"name": "taxonomy", "expr": "PROV_TXNMY_CD", "data_type": "string"},
                    {"name": "mcid", "expr": "CLM_MCID", "data_type": "string"},
                ],
                "facts": [
                    {"name": "paid_amount", "expr": "PAID_AMT", "data_type": "number"},
                ],
                "metrics": [
                    {"name": "claims.total_paid", "expr": "SUM({claims.paid_amount})"},
                ],
            },
        ],
        "calculations": {
            "provider_topk": {
                "type": "topk",
                "dimension": "taxonomy",
                "metric": "total_paid",
                "top_k": 5,
            },
            "member_pipeline": {
                "type": "cte_pipeline",
                "ctes": [
                    {
                        "name": "paid_by_taxonomy",
                        "source": "claims",
                        "dimensions": ["taxonomy"],
                        "measures": [
                            {"name": "total_paid", "expr": "SUM({claims.paid_amount})"},
                        ],
                    },
                ],
                "output": {
                    "columns": [
                        {"name": "taxonomy", "expr": "{paid_by_taxonomy.taxonomy}"},
                        {"name": "total_paid", "expr": "{paid_by_taxonomy.total_paid}"},
                    ],
                },
            },
            "bespoke": {
                "type": "raw_sql",
                "sql": "SELECT {claims.taxonomy}, SUM({claims.paid_amount}) AS p "
                       "FROM {claims} GROUP BY {claims.taxonomy}",
            },
        },
    }


class _StubAgent(QueryBuilderAgent):
    """Minimal subclass that skips the credential-heavy ``AgentBase.__init__``."""

    DEFAULT_CALCULATION = "provider_topk"
    TOPK_DEFAULT_DIMENSION = "taxonomy"

    def __init__(self) -> None:  # noqa: D401 - deliberately does NOT call super().__init__
        self.logger = logging.getLogger("test.query_builder_agent")

    # AgentBase abstract-method stubs (unused by these unit tests).
    @property
    def node_name(self) -> str:
        return "query"

    def node_function(self, state):  # pragma: no cover - not exercised here
        return {}

    def extract_result(self, state):  # pragma: no cover - not exercised here
        return {}


class _PersistAgent(_StubAgent):
    """Subclass whose ``_persist_run`` returns a fixed (run_dir, artifacts)."""

    def _persist_run(self, state, *, sql, meta, rows, row_count, truncated):
        return "runs/run_abc", {"query": "queries/q.sql", "summary": "summary/s.json"}


# ==========================================================================
# build_calculation dispatch
# ==========================================================================

def test_dispatch_topk_returns_ranking_sql():
    agent = _StubAgent()
    sql = agent.build_calculation(_model(), None, calc_name="provider_topk")
    assert "PROV_TXNMY_CD" in sql
    assert "SUM(" in sql
    assert "ORDER BY" in sql
    assert "LIMIT 5" in sql


def test_dispatch_cte_pipeline_returns_with_query():
    agent = _StubAgent()
    sql = agent.build_calculation(_model(), None, calc_name="member_pipeline")
    assert sql.startswith("WITH paid_by_taxonomy AS (")
    assert "FROM DB.SCH.CLAIMS" in sql
    assert sql.rstrip().endswith("FROM paid_by_taxonomy")


def test_dispatch_raw_sql_resolves_placeholders():
    agent = _StubAgent()
    sql = agent.build_calculation(_model(), None, calc_name="bespoke")
    assert "FROM DB.SCH.CLAIMS" in sql
    assert "{" not in sql and "}" not in sql


def test_dispatch_defaults_to_class_calculation():
    agent = _StubAgent()  # DEFAULT_CALCULATION = provider_topk
    sql = agent.build_calculation(_model(), None)
    assert "LIMIT 5" in sql


def test_overrides_win_over_declared_spec():
    agent = _StubAgent()
    sql = agent.build_calculation(_model(), None, calc_name="provider_topk", top_k=3)
    assert "LIMIT 3" in sql
    assert "LIMIT 5" not in sql


def test_unknown_calculation_name_raises_config_error():
    agent = _StubAgent()
    with pytest.raises(AgentConfigurationError, match="Unknown calculation"):
        agent.build_calculation(_model(), None, calc_name="does_not_exist")


def test_unknown_calculation_type_raises_config_error():
    agent = _StubAgent()
    model = _model()
    model["calculations"]["weird"] = {"type": "nonsense"}
    with pytest.raises(AgentConfigurationError, match="Unknown calculation type"):
        agent.build_calculation(model, None, calc_name="weird")


def test_builder_value_error_becomes_config_error():
    agent = _StubAgent()
    model = _model()
    # A topk calc naming a dimension that isn't declared -> builder ValueError,
    # surfaced as AgentConfigurationError (fail fast before the graph runs).
    model["calculations"]["bad"] = {"type": "topk", "dimension": "no_such_dim"}
    with pytest.raises(AgentConfigurationError):
        agent.build_calculation(model, None, calc_name="bad")


# ==========================================================================
# run_query_node + _persist_run hook
# ==========================================================================

def test_run_query_node_envelope_without_persistence(monkeypatch):
    agent = _StubAgent()
    monkeypatch.setattr(
        qba, "execute_sql_to_df",
        lambda helper, sql: pd.DataFrame([{"taxonomy": "207R", "p": 10}]),
    )
    state = {
        "semantic_model": _model(),
        "catalog": None,
        "query_sql": "SELECT 1",
        "calculation": "provider_topk",
        "yaml_path": "configs/correlation_pattern/x.yaml",
        "snowflake_helper": object(),
        "top_k": 5,
    }
    out = agent.run_query_node(state)
    result = out["query_result"]
    assert result["calculation"] == "provider_topk"
    assert result["row_count"] == 1
    assert result["truncated"] is False  # 1 row < top_k 5
    assert result["rows"] == [{"taxonomy": "207R", "p": 10}]
    assert result["yaml_path"] == "configs/correlation_pattern/x.yaml"
    # base _persist_run returns None -> no artifacts spliced in
    assert "run_dir" not in result
    assert "artifacts" not in result


def test_run_query_node_marks_truncated_on_full_page(monkeypatch):
    agent = _StubAgent()
    monkeypatch.setattr(
        qba, "execute_sql_to_df",
        lambda helper, sql: pd.DataFrame([{"p": i} for i in range(3)]),
    )
    state = {"query_sql": "SELECT 1", "snowflake_helper": object(), "top_k": 3}
    result = agent.run_query_node(state)["query_result"]
    assert result["row_count"] == 3
    assert result["truncated"] is True  # full page of top_k=3


def test_persist_run_override_splices_artifacts(monkeypatch):
    agent = _PersistAgent()
    monkeypatch.setattr(
        qba, "execute_sql_to_df",
        lambda helper, sql: pd.DataFrame([{"p": 1}]),
    )
    state = {"query_sql": "SELECT 1", "snowflake_helper": object(), "top_k": 5}
    result = agent.run_query_node(state)["query_result"]
    assert result["run_dir"] == "runs/run_abc"
    assert result["artifacts"] == {"query": "queries/q.sql", "summary": "summary/s.json"}


def test_execute_to_rows_requires_snowflake_helper():
    agent = _StubAgent()
    with pytest.raises(RuntimeError, match="Snowflake helper is required"):
        agent._execute_to_rows(None, "SELECT 1")
