---
name: ehap-llm
description: This skill should be used when the user asks to call an LLM in this repo, connect to EHAP, mint or refresh an EHAP token, build a ChatOpenAI client, get structured or JSON output from a model, debug a 401 or AuthenticationError from the gateway, or fix an LLM call that returns empty or default values. Covers get_ehap, make_llm, llm_invoke, structured_llm_invoke, and the silent-parse-failure trap.
---

# Calling the LLM through EHAP

All model traffic goes through the EHAP gateway, which is OpenAI-compatible but requires a client-credentials JWT and a non-default `base_url`. Use `deep_research_utils.connections` -- do not construct `ChatOpenAI` by hand.

## The three-line version

```python
from deep_research_utils import make_llm

llm = make_llm(reasoning_effort="low")
response = llm.invoke([{"role": "user", "content": "..."}])
```

`make_llm` always sets `base_url`, `http_client`, and `http_async_client` from `AppConstants`. This is the whole reason it exists: a `ChatOpenAI` built without `base_url` silently resolves to the **public OpenAI endpoint** instead of the gateway. Three call sites in this repo have that bug today. Do not add a fourth.

Arguments (all optional):

| Argument | Default | Notes |
|---|---|---|
| `model` | `AppConstants.EHAP_LLM_MODEL` | Set via the `EHAP_LLM_MODEL` env var |
| `reasoning_effort` | omitted | Passed through `extra_body`; `"low"`/`"medium"`/`"high"` |
| `summary_mode` | omitted | Passed through `extra_body` as `summary` |
| `ehap` | a new client | Pass an existing `EHAPBase` to share its token cache |

## Prefer ehap_retry over raw llm.invoke

`llm_invoke` and `structured_llm_invoke` wrap the call with token-refresh-on-401. Reach for them in library and agent code; bare `llm.invoke` is acceptable only in throwaway exploration.

```python
from deep_research_utils import get_ehap, make_llm, structured_llm_invoke

ehap = get_ehap()
llm = make_llm(ehap=ehap)

result, llm = structured_llm_invoke(llm, ehap, messages, MySchema)
```

Note the return shape -- these return a **tuple**, and the second element is a possibly-rebuilt LLM. Reassign it or you will keep using the client with the dead token.

| Function | Returns |
|---|---|
| `llm_invoke(llm, ehap, messages)` | `(response, llm)` |
| `structured_llm_invoke(llm, ehap, messages, schema)` | `(schema_instance, llm)` |
| `structured_llm_invoke_with_tokens(llm, ehap, messages, schema)` | `(schema_instance, llm, raw_response)` -- use `raw_response.usage_metadata` for token accounting |

## Trap 1: structured output fails silently, so every field needs a default

`structured_llm_invoke_with_tokens` does the equivalent of `parsed = response.get("parsed") or schema()`. On a parse miss it substitutes a **default-constructed empty schema**, with no exception, no log line, and no inspection of `parsing_error`. A run of a thousand rows can come back full of zeros and empty strings and look like a successful run.

Two rules follow:

1. **Give every field a default.** If any field is required, `schema()` itself raises `ValidationError`, which the retry decorator does not catch, so the whole call blows up instead.
2. **Make one field a sentinel** whose default means "nothing usable came back", and check it.

```python
from pydantic import BaseModel, Field

class FitAssessment(BaseModel):
    rating: str = Field(default="", description="Strong | Moderate | Weak | Not a fit")
    rationale: str = Field(default="")
    confidence: float = Field(default=0.0)

result, llm, raw = structured_llm_invoke_with_tokens(llm, ehap, messages, FitAssessment)
if not result.rating:
    # parse miss, not a real "no rating" answer
    ...
```

## Trap 2: the retry decorator only covers AuthenticationError

`ehap_retry`'s tenacity decorator retries **`openai.AuthenticationError` only**. Rate limits, timeouts, and connection errors are not retried and propagate to you. Handle them yourself, ideally by recording a failure row rather than raising -- see the `llm-batch` skill.

## Tokens

```python
from deep_research_utils import get_ehap

ehap = get_ehap()
token = ehap.get_token()          # cached; mints on first call
ehap.get_token_metadata()         # status without printing the token
ehap.force_token_refresh()        # invalidate, next get_token() mints fresh
```

- Never print, log, or echo a token, a `client_id`, or a `client_secret`.
- The token cache TTL is `AppConstants.CACHE_TTL`, **1800 seconds**. A job longer than 30 minutes needs `LLMHandle` (see `llm-batch`), because `ChatOpenAI` bakes the token in at construction.
- Redis backs the cache when reachable and falls back to an in-memory dict. Never write code that deletes keys from Redis.

## Configuration gotchas

- **Token path.** `AppConstants.EHAP_TOKEN_PATH` defaults to `/v2/oauth2/token`. The unversioned `/oauth2/token` returns **404**. Override with the `EHAP_TOKEN_PATH` env var if the gateway version moves; do not edit code for that.
- **`EHAP_BASE_URL` is not consistent across environments.** Some set the bare host, some already carry the `/v2` prefix. `EHAPBase._resolve_token_url` drops any leading part of `token_path` that `base_url` already ends with, so both spellings resolve to the same URL and you never get `/v2/v2/oauth2/token`. Do not "fix" a 404 by appending `/v2` to `EHAP_BASE_URL` -- that workaround is what produced the doubled path.
- **`.env` beats your shell.** `app_constant.py` calls `load_dotenv(override=True)`, so values in `.env` **overwrite** anything already exported in the environment. Exporting `EHAP_BASE_URL` in your terminal does nothing; `.env` is the single authority, and `env -u EHAP_BASE_URL` is not a way to test a different value. To try one, pass it explicitly: `get_ehap(base_url=...)`. Note this is the opposite of the plain `load_dotenv()` default, and `ehap.py` still calls the plain form -- `app_constant.py` is the one that sets the precedence.
- **TLS.** `get_ehap()` verifies against `AppConstants.SSL_CERT_FILE`. To disable verification, set the env var `SSL_CERT_FILE=false` -- passing `verify=False` in Python does **not** work, because `EHAPBase.__init__` tests the value for truthiness and coerces `False` back to `True`. Only the literal string `"false"` takes the disable branch.
- **Never read `os.environ["SSL_CERT_FILE"]`** after touching Snowflake; it may have been deleted. See the `snowflake-query` skill.

## Related

- `llm-batch` -- running many LLM calls in parallel with token refresh
- `snowflake-query` -- pulling the rows you are about to send to the model
