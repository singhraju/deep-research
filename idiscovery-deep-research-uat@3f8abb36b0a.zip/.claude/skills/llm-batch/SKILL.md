---
name: llm-batch
description: This skill should be used when the user asks to run an LLM over many rows, score or rate or classify a whole table or DataFrame, parallelize LLM calls, speed up a scoring job with k workers, or join LLM results back onto source rows. Covers ThreadPoolExecutor fan-out, LLMHandle token refresh across a long job, per-row failure records, and reassemble-by-key joins.
---

# Running an LLM over many rows

The shape that works in this repo: pull rows with Snowflake, fan out over threads, refresh the token between chunks, return a failure record instead of raising, and reassemble by key.

## Threads, never processes

Use `concurrent.futures.ThreadPoolExecutor`. Do not use `ProcessPoolExecutor` or `multiprocessing`:

- `ChatOpenAI` holds an `httpx.Client` -- not picklable.
- `SnowparkHelper` holds a `threading.Lock` and a live Snowpark `Session` -- not picklable.

Threads are also the right tool regardless: this workload is network-bound, so the GIL is released during every call. Threads work inside a Jupyter notebook with no extra setup, no `if __name__ == "__main__"` guard, and no `nest_asyncio`.

## The token outlives your patience, not your job

`ChatOpenAI` bakes its token in at construction and `AppConstants.CACHE_TTL` is **1800 seconds**. A job over a few thousand rows runs longer than that and every worker starts failing with `AuthenticationError`.

`LLMHandle` solves this. It holds one client behind a lock with a generation counter, so when k workers all hit the same expired token, the first refresh wins and the others reuse the new client instead of each minting their own.

```python
from deep_research_utils import LLMHandle

handle = LLMHandle(reasoning_effort="low")

llm, generation = handle.get()
try:
    result = llm.invoke(messages)
except AuthenticationError:
    llm, generation = handle.refresh(generation)
    result = llm.invoke(messages)
```

Pass the generation you saw to `refresh()`. Calling `refresh()` with no argument always mints, which is what you want between chunks and not what you want inside a worker.

## The pattern

```python
from concurrent.futures import ThreadPoolExecutor, as_completed

from deep_research_utils import LLMHandle, structured_llm_invoke_with_tokens, snowpark_session

K_WORKERS = 8          # user-tunable
CHUNK_SIZE = 200       # refresh the token between chunks


def evaluate_one(handle, key, payload):
    """Never raises. Returns a record with a key and, on failure, an error string."""
    llm, generation = handle.get()
    try:
        result, _llm, raw = structured_llm_invoke_with_tokens(
            llm, handle.ehap, build_messages(payload), MySchema
        )
    except Exception as exc:
        return {"key": key, "error": f"{type(exc).__name__}: {exc}"}

    record = result.model_dump()
    record["key"] = key
    record["error"] = ""
    if raw is not None and getattr(raw, "usage_metadata", None):
        record["total_tokens"] = raw.usage_metadata.get("total_tokens", 0)
    return record


handle = LLMHandle(reasoning_effort="low")
records = []

for start in range(0, len(items), CHUNK_SIZE):
    chunk = items[start:start + CHUNK_SIZE]
    handle.refresh()                       # fresh token for this chunk
    with ThreadPoolExecutor(max_workers=K_WORKERS) as pool:
        futures = {pool.submit(evaluate_one, handle, key, payload): key
                   for key, payload in chunk}
        for future in as_completed(futures):
            records.append(future.result())
    print(f"{len(records)}/{len(items)} done")
```

## Rules that keep the output joinable

1. **Workers never raise.** Catch `Exception`, return a record carrying the key and an `error` string. One bad row must not abort a job that has been running for twenty minutes.
2. **Every record carries the key**, so results arriving out of order via `as_completed` still join back.
3. **Every record has the same fields.** Populate misses with empty string or the schema default, never omit the field -- omitted fields produce a ragged DataFrame and a broken merge.
4. **Left-join onto the source, do not concatenate.**

```python
import pandas as pd

results_df = pd.DataFrame(records)
joined = source_df.merge(results_df, on="key", how="left")
assert len(joined) == len(source_df)
```

## Before the fan-out, run exactly one

Always evaluate a single item first and inspect the raw output. Prompt and schema bugs are cheap to find on one row and expensive on a thousand.

```python
sample_key, sample_payload = items[0]
print(evaluate_one(handle, sample_key, sample_payload))
```

In a notebook, keep that as its own cell so the prompt can be tweaked without re-running the batch.

## Picking k

Start at 8. The gateway rate-limits, and `structured_llm_invoke`'s retry decorator covers **only** `AuthenticationError` -- a rate-limit error propagates straight into your worker's `except` and becomes an error record, not a retry. If the error column fills with rate-limit messages, lower k rather than adding retries.

## Checkpoint long runs

Write `records` to CSV or Parquet after each chunk. A three-hour job that dies at row 2800 with nothing on disk is a three-hour job you have to run again.

## Related

- `ehap-llm` -- schema defaults, the silent-parse-failure trap, token handling
- `snowflake-query` -- pulling the source rows and writing results back
