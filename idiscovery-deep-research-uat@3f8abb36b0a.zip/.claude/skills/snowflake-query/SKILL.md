---
name: snowflake-query
description: This skill should be used when the user asks to query Snowflake, connect to Snowflake, run SQL against the warehouse, pull a table or semantic view into a DataFrame, write a DataFrame back to Snowflake, or debug a Snowflake connection or credential problem in this repo. Covers snowpark_session, get_snowpark, SnowparkHelper, connection pooling, and the SSL env-var trap.
---

# Querying Snowflake

Use `deep_research_utils.connections`. Do not hand-roll a `SnowparkHelper` construction block, and do not write a new `_init_snowflake` helper -- five near-identical private copies already exist in this repo and they disagree with each other.

## The three-line version

```python
from deep_research_utils import snowpark_session

with snowpark_session(connection_pool_size=1) as snowpark:
    df = snowpark.execute_query_and_return_pandas_df("SELECT CURRENT_ROLE()")
```

`snowpark_session` is a context manager that builds a connected helper and calls `close()` in a `finally`, so the session is torn down on both the success and the exception path. Prefer it everywhere.

Use `get_snowpark()` only when the helper must outlive the current scope (for example, stored on an agent instance). Then you own `close()`.

```python
from deep_research_utils import get_snowpark

self.snowpark = get_snowpark()      # remember to close() in your teardown
```

## Credentials come from AppConstants, never from your code

`get_snowpark()` reads `AppConstants.SNOWFLAKE_CONNECTION_TYPE` and picks the path:

- `programmatic` when `SNOWFLAKE_SECRET` is set (local dev)
- `vault` otherwise (deployed)

Both paths fall back to `AppConstants` for account, user, secret, and warehouse, so you never pass credentials as kwargs. Never read `.env` and never put a credential in a notebook cell or a config file.

## Overrides

Any `SnowparkHelper` kwarg can be passed through and overrides the default:

```python
with snowpark_session(
    connection_pool_size=1,
    database="P01_COC",
    schema="COC_DTI",
    batch_size=50000,
) as snowpark:
    ...
```

Defaults come from `SNOWPARK_DEFAULTS` (`batch_size=10000, max_workers=6, enable_metrics=True, connection_pool_size=4`) plus `database`/`schema`/`connection_type` from `AppConstants`.

## Cost: connection_pool_size opens that many logins up front

`SnowparkHelper.__init__` creates one main session and then fills the pool **synchronously before the constructor returns**. `connection_pool_size=4` means four Snowflake logins before you get your object back.

- Notebooks, scripts, one-off queries: pass `connection_pool_size=1`.
- Concurrent query fan-out inside one process: leave the default of 4.

A failure while filling the pool is logged as a warning and breaks the fill loop, so a partially-filled pool is not an error and will not raise. If queries later fail on session checkout, suspect this.

## The SSL env-var trap

`SnowparkHelper` deletes `SSL_CERT_FILE`, `CURL_CA_BUNDLE`, and `REQUESTS_CA_BUNDLE` from `os.environ` before connecting, and its restore call sits **inside** the `try`. A *failed* Snowflake connect therefore strips those variables from the process for good, and any later `requests` or `httpx` call that expected the corporate cert bundle starts failing with a confusing TLS error.

Consequences for your code:

- Never read `os.environ["SSL_CERT_FILE"]` after touching Snowflake. Read `AppConstants.SSL_CERT_FILE`, which is captured at import.
- `get_ehap()` and `make_llm()` already do this correctly. Build EHAP clients through them, not by hand.

## Gotchas

- **`role` is ignored.** `SnowparkHelper` discards a `role=` kwarg and always derives `f"{user}_PRIVS"`. Passing a role looks like it works and silently does nothing. Confirm the effective role with `SELECT CURRENT_ROLE()`.
- **`get_session()` is not a teardown helper.** It is a pool checkout whose `finally` returns the session to the pool. It never closes anything. Use `snowpark_session` for lifecycle.
- **`execute_query` vs `execute_query_and_return_pandas_df`** -- both return a pandas DataFrame; the latter is the explicit name used in most call sites. Prefer it for readability.

## Useful methods

| Method | Use |
|---|---|
| `execute_query_and_return_pandas_df(sql)` | Read query into a DataFrame |
| `save_pandas_df_to_snowflake(df, table, overwrite=True)` | Write a DataFrame |
| `batch_merge_optimized(logical_table, primary_keys, df)` | Upsert |
| `create_transient_table(...)` / `drop_table_if_exists(...)` | Scratch tables |
| `get_qualified_table_name(logical_name)` | Apply `SNOWFLAKE_TABLE_PREFIX`/`_SUFFIX` |
| `get_performance_metrics()` | Per-operation timings when `enable_metrics=True` |

## Checking timings

```python
with snowpark_session(connection_pool_size=1) as snowpark:
    df = snowpark.execute_query_and_return_pandas_df(sql)
    for metric in snowpark.get_performance_metrics():
        print(metric.operation, metric.duration_seconds, metric.rows_per_second)
```

## Related

- `ehap-llm` -- EHAP tokens and LLM clients
- `llm-batch` -- fan-out over many rows returned from a query
