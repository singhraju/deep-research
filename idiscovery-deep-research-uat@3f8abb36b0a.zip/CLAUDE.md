# CLAUDE.md

Project rules live in AGENTS.md. Read and follow them.

@AGENTS.md
