"""Build a single-file interactive HTML report of the deep-research analysis.

Where :mod:`ui.pdf_report` flattens the screen into paper, this module keeps the
app's interactivity in a file the user can mail around:

- the same tab strip as the UI (Correlation Summary, one tab per pattern,
  Recommendations, SQL Queries, Technical Details) with client-side switching
- live Plotly charts (waterfall + pattern drill-down) so hovering still reveals
  the full drill path and per-segment deltas
- hover cards on every table cell that carries a ``title`` tooltip on screen
- collapsible sections for pattern details, referenced policies, raw payloads
  and the SQL catalog, plus a client-side stage/text filter over the queries

Everything — CSS, JS and the Plotly bundle — is inlined, so the file renders
offline with no network access. Callers use :func:`build_html_report` to turn
the orchestrator's ``output`` dict into an HTML string for ``st.download_button``.
"""

from __future__ import annotations

import datetime as dt
import html
import json
import logging
import re
from typing import Any, Dict, List, Mapping, Optional, Sequence

logger = logging.getLogger(__name__)

try:
    import plotly.io as pio
    from plotly.offline import get_plotlyjs

    _PLOTLY_AVAILABLE = True
except ImportError:  # pragma: no cover — charts degrade to a note in the report
    _PLOTLY_AVAILABLE = False

from ui.correlation_visuals import (
    build_kpi_data,
    build_matrix_section_html,
    build_waterfall_figure,
    format_compact_money,
    format_period_window,
    format_signed_money,
)
from ui.pattern_visuals import (
    build_drill_down_paths_html,
    build_pattern_breakdown_figure,
    build_payer_summary_table_html,
    build_recommended_actions_html,
    normalize_policy_entries,
)
from ui.pdf_report import (
    _pattern_segment_label,
    _reimbursement_keys,
)

_PRIORITY_BUCKETS = ("HIGH", "MEDIUM", "LOW")
_PRIORITY_COLORS = {
    "HIGH": "#B91C1C",
    "MEDIUM": "#B45309",
    "LOW": "#047857",
}
_DIRECTION_COLORS = {
    "INCREASE": "#B5364B",
    "DECREASE": "#1A8754",
    "STABLE": "#5B6776",
}


def is_available() -> bool:
    """HTML export has no hard dependency — charts degrade when Plotly is absent."""

    return True


# ---------------------------------------------------------------------------
# Escaping + minimal markdown
# ---------------------------------------------------------------------------


def _esc(value: Any) -> str:
    return html.escape("" if value is None else str(value), quote=True)


_LINK_RE = re.compile(r"\[([^\]]+)\]\((https?://[^)\s]+)\)")
_BOLD_RE = re.compile(r"\*\*(.+?)\*\*", re.DOTALL)
_ITALIC_RE = re.compile(r"(?<![*\w])\*(?!\s)([^*]+?)(?<!\s)\*(?!\*)")
_CODE_RE = re.compile(r"`([^`]+)`")
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")
_BULLET_RE = re.compile(r"^\s*[-*•]\s+(.*)$")
_ORDERED_RE = re.compile(r"^\s*\d+[.)]\s+(.*)$")
_TABLE_SEP_RE = re.compile(r"^\s*\|?[\s:\-|]+\|[\s:\-|]*$")


def _inline_md(text: Any) -> str:
    """Convert the inline markdown our renderers emit to safe inline HTML."""

    escaped = _esc(text)
    escaped = _LINK_RE.sub(
        r'<a href="\2" target="_blank" rel="noopener noreferrer">\1</a>', escaped
    )
    escaped = _BOLD_RE.sub(r"<strong>\1</strong>", escaped)
    escaped = _ITALIC_RE.sub(r"<em>\1</em>", escaped)
    escaped = _CODE_RE.sub(r"<code>\1</code>", escaped)
    return escaped


def _split_table_row(line: str) -> List[str]:
    stripped = line.strip()
    if stripped.startswith("|"):
        stripped = stripped[1:]
    if stripped.endswith("|"):
        stripped = stripped[:-1]
    return [cell.strip() for cell in stripped.split("|")]


def _markdown_to_html(text: Any) -> str:
    """Convert a markdown blob to HTML.

    Covers the subset the agents emit: headings, bullet and numbered lists,
    pipe tables, fenced code, block quotes, horizontal rules and the inline
    marks handled by :func:`_inline_md`. Unknown syntax degrades to escaped
    text rather than being dropped.
    """

    if text is None:
        return ""
    raw = str(text).strip()
    if not raw:
        return ""

    out: List[str] = []
    para: List[str] = []
    list_items: List[str] = []
    list_tag = ""
    quote: List[str] = []
    table: List[List[str]] = []
    code: List[str] = []
    in_code = False

    def flush_para() -> None:
        nonlocal para
        if para:
            out.append(f'<p>{_inline_md(" ".join(para))}</p>')
            para = []

    def flush_list() -> None:
        nonlocal list_items, list_tag
        if list_items:
            body = "".join(f"<li>{_inline_md(item)}</li>" for item in list_items)
            out.append(f"<{list_tag}>{body}</{list_tag}>")
            list_items = []
            list_tag = ""

    def flush_quote() -> None:
        nonlocal quote
        if quote:
            out.append(f'<blockquote>{_inline_md(" ".join(quote))}</blockquote>')
            quote = []

    def flush_table() -> None:
        nonlocal table
        if table:
            head, *body = table
            head_html = "".join(f"<th>{_inline_md(cell)}</th>" for cell in head)
            body_html = "".join(
                "<tr>" + "".join(f"<td>{_inline_md(cell)}</td>" for cell in row) + "</tr>"
                for row in body
            )
            out.append(
                '<div class="dr-scroll"><table class="dr-md-table">'
                f"<thead><tr>{head_html}</tr></thead><tbody>{body_html}</tbody>"
                "</table></div>"
            )
            table = []

    def flush_all() -> None:
        flush_para()
        flush_list()
        flush_quote()
        flush_table()

    for line in raw.split("\n"):
        if line.strip().startswith("```"):
            if in_code:
                out.append(f'<pre class="dr-code">{_esc(chr(10).join(code))}</pre>')
                code = []
                in_code = False
            else:
                flush_all()
                in_code = True
            continue
        if in_code:
            code.append(line)
            continue

        if not line.strip():
            flush_all()
            continue

        if line.lstrip().startswith("|") and "|" in line.strip()[1:]:
            if _TABLE_SEP_RE.match(line) and table:
                continue
            flush_para()
            flush_list()
            flush_quote()
            table.append(_split_table_row(line))
            continue
        flush_table()

        heading = _HEADING_RE.match(line)
        if heading:
            flush_all()
            level = min(6, len(heading.group(1)) + 2)
            out.append(f"<h{level}>{_inline_md(heading.group(2))}</h{level}>")
            continue

        if line.strip() in {"---", "***", "___"}:
            flush_all()
            out.append("<hr>")
            continue

        if line.lstrip().startswith("> "):
            flush_para()
            flush_list()
            quote.append(line.lstrip()[2:])
            continue
        flush_quote()

        bullet = _BULLET_RE.match(line)
        if bullet:
            flush_para()
            if list_tag and list_tag != "ul":
                flush_list()
            list_tag = "ul"
            list_items.append(bullet.group(1))
            continue

        ordered = _ORDERED_RE.match(line)
        if ordered:
            flush_para()
            if list_tag and list_tag != "ol":
                flush_list()
            list_tag = "ol"
            list_items.append(ordered.group(1))
            continue

        flush_list()
        para.append(line.strip())

    if in_code and code:
        out.append(f'<pre class="dr-code">{_esc(chr(10).join(code))}</pre>')
    flush_all()
    return "".join(out)


# ---------------------------------------------------------------------------
# Small HTML building blocks
# ---------------------------------------------------------------------------


def _slug(value: Any, fallback: str = "section") -> str:
    text = re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")
    return text or fallback


def _card(body: str, *, accent: Optional[str] = None, classes: str = "") -> str:
    stripe = (
        f'<div class="dr-card-stripe" style="background:{accent};"></div>' if accent else ""
    )
    return f'<div class="dr-card {classes}">{stripe}{body}</div>'


def _kpi_card(label: str, value: str, sub: str = "", tone: str = "") -> str:
    sub_html = (
        f'<div class="dr-kpi-sub" style="color:{tone or "#5B6776"};">{_esc(sub)}</div>'
        if sub
        else ""
    )
    return (
        '<div class="dr-kpi">'
        f'<div class="dr-kpi-label">{_esc(label)}</div>'
        f'<div class="dr-kpi-value">{_esc(value)}</div>'
        f"{sub_html}</div>"
    )


def _section_title(text: str, sub: str = "") -> str:
    sub_html = f'<div class="dr-caption">{_esc(sub)}</div>' if sub else ""
    return f'<h3 class="dr-h3">{_esc(text)}</h3>{sub_html}'


def _details(summary: str, body: str, *, open_: bool = False) -> str:
    if not body:
        return ""
    attr = " open" if open_ else ""
    return (
        f"<details class='dr-details'{attr}>"
        f"<summary>{_esc(summary)}</summary>"
        f"<div class='dr-details-body'>{body}</div></details>"
    )


def _json_block(payload: Any) -> str:
    try:
        text = json.dumps(payload, indent=2, default=str, ensure_ascii=False)
    except (TypeError, ValueError):  # pragma: no cover — defensive
        text = str(payload)
    return f'<pre class="dr-code dr-json">{_esc(text)}</pre>'


def _info(text: str) -> str:
    return f'<div class="dr-info">{_esc(text)}</div>'


def _figure_html(fig: Any, div_id: str) -> str:
    """Render a Plotly figure as an inline, interactive div."""

    if fig is None:
        return ""
    if not _PLOTLY_AVAILABLE:
        return _info("Plotly is not installed, so this chart could not be embedded.")
    try:
        return pio.to_html(
            fig,
            full_html=False,
            include_plotlyjs=False,
            div_id=div_id,
            default_width="100%",
            default_height="440px",
            config={"displayModeBar": False, "responsive": True},
        )
    except Exception:  # noqa: BLE001 — one bad chart must not kill the report
        logger.exception("Failed to embed Plotly figure %s in the HTML report", div_id)
        return _info("This chart could not be rendered.")


# ---------------------------------------------------------------------------
# Tab: Correlation Summary
# ---------------------------------------------------------------------------


def _find_correlation_summary(output: Mapping[str, Any]) -> Mapping[str, Any]:
    analysis = output.get("analysis") or {}
    metadata = analysis.get("metadata") or {} if isinstance(analysis, Mapping) else {}
    summary = metadata.get("correlation_summary") or {} if isinstance(metadata, Mapping) else {}
    return summary if isinstance(summary, Mapping) else {}


def _kpi_strip_html(correlation_summary: Mapping[str, Any]) -> str:
    data = build_kpi_data(correlation_summary)
    if data is None:
        return ""

    impact_sub = (
        f"{data['impact_pct'] * 100:+.1f}% vs prior" if data["impact_pct"] is not None else ""
    )
    impact_tone = _DIRECTION_COLORS["INCREASE"] if data["impact"] > 0 else _DIRECTION_COLORS["DECREASE"]
    driver_delta = data["top_driver_delta"]
    cards = [
        _kpi_card("Total Impact", format_signed_money(data["impact"]), impact_sub, impact_tone),
        _kpi_card(
            "Top Driver",
            str(data["top_driver_name"]),
            format_signed_money(driver_delta) if driver_delta else "",
            _DIRECTION_COLORS["INCREASE"] if driver_delta > 0 else _DIRECTION_COLORS["DECREASE"],
        ),
        _kpi_card(
            "Baseline → Comparison",
            f"{format_compact_money(data['baseline'])} → {format_compact_money(data['comparison'])}",
        ),
        _kpi_card(
            "Detected Interactions",
            str(data["n_interactions"]),
            "Operational + clinical cells the matrix flagged.",
        ),
    ]
    return f'<div class="dr-kpi-grid">{"".join(cards)}</div>'


def _correlation_tab_html(output: Mapping[str, Any]) -> str:
    correlation_summary = _find_correlation_summary(output)
    question = output.get("question") or "Analysis"
    exec_summary = correlation_summary.get("executive_summary")

    parts: List[str] = []
    title = f"Root Cause Analysis: {question}" if question else "Root Cause Analysis"
    parts.append(f'<h2 class="dr-h2">{_esc(title)}</h2>')

    if exec_summary:
        parts.append(_section_title("Summary"))
        parts.append(f'<div class="dr-prose">{_markdown_to_html(exec_summary)}</div>')

    kpi_html = _kpi_strip_html(correlation_summary)
    if kpi_html:
        parts.append(kpi_html)

    fig = None
    if _PLOTLY_AVAILABLE:
        try:
            fig = build_waterfall_figure(correlation_summary)
        except Exception:  # noqa: BLE001 — degrade to no chart
            logger.exception("Waterfall figure failed for the HTML report")
    chart_html = _figure_html(fig, "dr-waterfall")
    if chart_html:
        parts.append(
            _section_title(
                "Cost Cascade",
                "Each level stacks its top contributors — hover any segment for the "
                "dimension value and signed delta.",
            )
        )
        parts.append(f'<div class="dr-chart">{chart_html}</div>')

    matrix_html = build_matrix_section_html(correlation_summary)
    if matrix_html:
        parts.append(f'<div class="dr-embed">{matrix_html}</div>')

    research = output.get("research") or {}
    patterns = research.get("business_patterns") or []
    recommendations = research.get("recommendations") or []
    if patterns or recommendations:
        parts.append(_section_title("Downstream Outputs"))
        parts.append(
            '<div class="dr-kpi-grid">'
            + _kpi_card("Business patterns", str(len(patterns)))
            + _kpi_card("Recommendations", str(len(recommendations)))
            + "</div>"
        )

    if not exec_summary and not patterns and not kpi_html and not matrix_html:
        parts.append(_info("No executive summary or patterns available for this analysis."))

    return "".join(parts)


# ---------------------------------------------------------------------------
# Tab: one per business pattern
# ---------------------------------------------------------------------------


def _pattern_header_html(pattern: Mapping[str, Any]) -> str:
    impact = pattern.get("impact_summary") or {}
    direction = str(impact.get("direction") or "").upper()
    accent = _DIRECTION_COLORS.get(direction, "#1F3A68")
    estimated_delta = impact.get("estimated_delta")
    title = (
        pattern.get("pattern_title")
        or pattern.get("top_pattern")
        or pattern.get("what_is_impacting")
        or "Pattern"
    )

    chips: List[str] = []
    if direction:
        chips.append(
            f'<span class="dr-chip" style="background:{accent};color:#FFFFFF;">{_esc(direction)}</span>'
        )
    if estimated_delta:
        chips.append(
            '<span class="dr-chip dr-chip-outline">Impact '
            f"<b>{_esc(estimated_delta)}</b></span>"
        )

    what = pattern.get("what_is_impacting")
    what_html = f'<div class="dr-caption">{_esc(what)}</div>' if what else ""
    return (
        '<div class="dr-pattern-head">'
        f'<div><h2 class="dr-h2">{_esc(title)}</h2>{what_html}</div>'
        f'<div class="dr-chip-row">{"".join(chips)}</div>'
        "</div>"
    )


def _evidence_card_html(pattern: Mapping[str, Any]) -> str:
    impact = pattern.get("impact_summary") or {}
    direction = str(impact.get("direction") or "").upper()
    accent = _DIRECTION_COLORS.get(direction, "#1F3A68")

    why = pattern.get("why_it_matters")
    evidence = list(pattern.get("evidence_summary") or [])
    next_step = pattern.get("recommended_next_step")
    if not (why or evidence or next_step):
        return ""

    body: List[str] = []
    if why:
        body.append('<div class="dr-label">Why it matters</div>')
        body.append(f'<div class="dr-prose">{_markdown_to_html(why)}</div>')
    if evidence:
        body.append('<div class="dr-label">Evidence</div>')
        body.append(
            "<ul class='dr-list'>"
            + "".join(f"<li>{_inline_md(item)}</li>" for item in evidence)
            + "</ul>"
        )
    if next_step:
        body.append('<div class="dr-label">Recommended next step</div>')
        body.append(f'<div class="dr-prose">{_markdown_to_html(next_step)}</div>')
    return _card("".join(body), accent=accent)


def _reimbursement_html(reimbursement: Optional[Mapping[str, Any]]) -> str:
    parts: List[str] = [_section_title("Reimbursement Policy Findings")]

    if reimbursement is None:
        parts.append(_info("No reimbursement output produced for this pattern."))
        return "".join(parts)
    if reimbursement.get("error"):
        parts.append(
            f'<div class="dr-error">Reimbursement agent failed: {_esc(reimbursement["error"])}</div>'
        )
        return "".join(parts)

    formatted_output = reimbursement.get("formatted_output") or reimbursement.get("output") or {}
    if not isinstance(formatted_output, Mapping):
        formatted_output = {}

    elevance_summary = reimbursement.get("elevance_executive_summary") or formatted_output.get(
        "elevance_executive_summary"
    )
    if elevance_summary:
        parts.append('<h4 class="dr-h4">Elevance Executive Summary</h4>')
        parts.append(f'<div class="dr-prose">{_markdown_to_html(elevance_summary)}</div>')

    summary_table = formatted_output.get("summary_table")
    table_html = build_payer_summary_table_html(
        summary_table if isinstance(summary_table, Mapping) else None
    )
    if table_html:
        title = summary_table.get("title") or "Payer Policy Summary"
        subtitle = summary_table.get("subtitle")
        parts.append(f'<h4 class="dr-h4">{_esc(title)}</h4>')
        if subtitle:
            parts.append(f'<div class="dr-caption">{_esc(subtitle)}</div>')
        parts.append(f'<div class="dr-embed">{table_html}</div>')

    recommended_actions = (
        reimbursement.get("recommended_action")
        or reimbursement.get("recommendations")
        or formatted_output.get("recommended_action")
        or []
    )
    individual_policies = (
        formatted_output.get("individual_policies")
        or reimbursement.get("individual_policies")
        or formatted_output.get("reimbursement_policies")
        or reimbursement.get("reimbursement_policies")
        or []
    )
    actions_html = build_recommended_actions_html(recommended_actions, individual_policies)
    if actions_html:
        parts.append(f'<div class="dr-embed">{actions_html}</div>')

    policies = normalize_policy_entries(individual_policies)
    if policies:
        items: List[str] = []
        for policy in policies:
            link = (
                f'<a href="{_esc(policy["url"])}" target="_blank" rel="noopener noreferrer">'
                f'{_esc(policy["title"])}</a>'
                if policy["url"]
                else _esc(policy["title"])
            )
            payer = f'<strong>{_esc(policy["payer"])}</strong> — ' if policy["payer"] else ""
            effective = (
                f' · <em>Effective: {_esc(policy["effective"])}</em>' if policy["effective"] else ""
            )
            items.append(f"<li>{payer}{link}{effective}</li>")
        parts.append(
            _details(
                f"Referenced Policies ({len(policies)})",
                f"<ul class='dr-list'>{''.join(items)}</ul>",
            )
        )

    if not (table_html or recommended_actions or individual_policies or elevance_summary):
        parts.append(_info("No reimbursement details available for this pattern."))

    parts.append(_details("Raw reimbursement output", _json_block(reimbursement)))
    return "".join(parts)


def _pattern_tab_html(
    pattern: Mapping[str, Any],
    reimbursement: Optional[Mapping[str, Any]],
    cards: Sequence[Mapping[str, Any]],
    index: int,
) -> str:
    parts: List[str] = [_pattern_header_html(pattern)]

    fig = None
    if _PLOTLY_AVAILABLE:
        try:
            fig = build_pattern_breakdown_figure(pattern, cards)
        except Exception:  # noqa: BLE001 — degrade to the path list below
            logger.exception("Pattern breakdown figure failed for the HTML report")

    left: str
    if fig is not None:
        n_bars = len(fig.data[0].y) if fig.data else 0
        caption = (
            f"Drill-down contributions · {n_bars} aggregated "
            f"path{'s' if n_bars != 1 else ''}, ranked by |Δ paid| · hover for the full path"
        )
        left = (
            f'<div class="dr-caption">{_esc(caption)}</div>'
            f'<div class="dr-chart">{_figure_html(fig, f"dr-pattern-{index}")}</div>'
        )
    else:
        paths_html = build_drill_down_paths_html(pattern, cards)
        left = paths_html or _info(
            "No source cards available for this pattern's drill hierarchy."
        )

    parts.append(
        '<div class="dr-split">'
        f'<div class="dr-split-main">{left}</div>'
        f'<div class="dr-split-side">{_evidence_card_html(pattern)}</div>'
        "</div>"
    )

    details = pattern.get("pattern_details")
    if details:
        parts.append(
            _details(
                "Pattern details", f'<div class="dr-prose">{_markdown_to_html(details)}</div>'
            )
        )

    parts.append('<hr class="dr-rule">')
    parts.append(_reimbursement_html(reimbursement))
    return "".join(parts)


# ---------------------------------------------------------------------------
# Tab: Recommendations
# ---------------------------------------------------------------------------


def _normalize_priority(value: Any) -> str:
    text = "" if value is None else str(value).strip().upper()
    if text in {"H", "HIGH", "URGENT", "CRITICAL"}:
        return "HIGH"
    if text in {"M", "MED", "MEDIUM"}:
        return "MEDIUM"
    if text in {"L", "LOW", "MINOR"}:
        return "LOW"
    return text


def _recommendation_card_html(rec: Mapping[str, Any], color: str) -> str:
    rank = rec.get("rank")
    title = rec.get("description") or rec.get("title") or f"Recommendation {rank}".strip()
    evidence = list(rec.get("evidence") or [])
    peer = list(rec.get("peer_benchmarking") or [])
    owner = rec.get("owner") or rec.get("assignee")
    eta = rec.get("eta") or rec.get("eta_weeks")

    rank_chip = (
        f'<span class="dr-rank" style="background:{color};">#{_esc(rank)}</span>' if rank else ""
    )
    meta_bits: List[str] = []
    if owner:
        meta_bits.append(f"Owner: {owner}")
    if eta:
        meta_bits.append(f"ETA: {eta}")
    meta = f'<div class="dr-caption">{_esc(" · ".join(meta_bits))}</div>' if meta_bits else ""

    extra = ""
    if evidence or peer:
        blocks: List[str] = []
        if evidence:
            blocks.append('<div class="dr-label">Evidence</div>')
            blocks.append(
                "<ul class='dr-list'>"
                + "".join(f"<li>{_inline_md(item)}</li>" for item in evidence)
                + "</ul>"
            )
        if peer:
            blocks.append('<div class="dr-label">Peer benchmarking</div>')
            blocks.append(
                "<ul class='dr-list'>"
                + "".join(f"<li>{_inline_md(item)}</li>" for item in peer)
                + "</ul>"
            )
        extra = _details("Evidence & peer benchmarking", "".join(blocks))

    body = (
        f'<div class="dr-rec-title">{rank_chip}<span>{_inline_md(title)}</span></div>'
        f"{meta}{extra}"
    )
    return _card(body, classes="dr-rec")


def _recommendations_tab_html(recommendations: Sequence[Mapping[str, Any]]) -> str:
    parts: List[str] = [_section_title("Final Recommendations")]
    if not recommendations:
        parts.append(_info("No recommendations were generated for this analysis."))
        return "".join(parts)

    bucketed: Dict[str, List[Mapping[str, Any]]] = {p: [] for p in _PRIORITY_BUCKETS}
    other: List[Mapping[str, Any]] = []
    for rec in recommendations:
        if not isinstance(rec, Mapping):
            continue
        priority = _normalize_priority(rec.get("priority"))
        bucketed.get(priority, other).append(rec)

    kpis = [_kpi_card("Total recommendations", str(len(recommendations)))]
    for priority in _PRIORITY_BUCKETS:
        kpis.append(
            _kpi_card(f"{priority.title()} priority", str(len(bucketed[priority])))
        )
    parts.append(f'<div class="dr-kpi-grid">{"".join(kpis)}</div>')

    columns: List[str] = []
    for priority in _PRIORITY_BUCKETS:
        color = _PRIORITY_COLORS[priority]
        items = bucketed[priority]
        header = (
            '<div class="dr-col-head">'
            f'<span style="color:{color};font-weight:700;letter-spacing:0.04em;">{priority}</span>'
            f'<span class="dr-muted">{len(items)} item(s)</span></div>'
        )
        body = (
            "".join(_recommendation_card_html(rec, color) for rec in items)
            if items
            else '<div class="dr-caption">No items in this priority.</div>'
        )
        columns.append(f'<div class="dr-col">{header}{body}</div>')
    parts.append(f'<div class="dr-cols-3">{"".join(columns)}</div>')

    if other:
        parts.append('<h4 class="dr-h4">Other / Unclassified</h4>')
        parts.append(
            "".join(
                _recommendation_card_html(rec, _PRIORITY_COLORS["MEDIUM"]) for rec in other
            )
        )
    return "".join(parts)


# ---------------------------------------------------------------------------
# Tab: SQL Queries
# ---------------------------------------------------------------------------


def _sql_tab_html(records: Sequence[Mapping[str, Any]]) -> str:
    parts: List[str] = [_section_title("Generated SQL Queries")]
    if not records:
        parts.append(_info("No SQL queries were generated for this analysis."))
        return "".join(parts)

    stages = sorted({str(r.get("stage") or "") for r in records})
    stage_counts = {s: sum(1 for r in records if str(r.get("stage") or "") == s) for s in stages}
    chips = "".join(
        f'<span class="dr-chip dr-chip-outline">{_esc(stage)} <b>{stage_counts[stage]}</b></span>'
        for stage in stages
    )
    parts.append(
        f'<p><strong>Analysis backed by {len(records)} SQL queries across '
        f"{len(stages)} stages.</strong></p>"
    )
    parts.append(f'<div class="dr-chip-row">{chips}</div>')

    options = "".join(f'<option value="{_esc(stage)}">{_esc(stage)}</option>' for stage in stages)
    parts.append(
        '<div class="dr-filter-row">'
        '<input type="search" id="dr-sql-search" class="dr-input" '
        'placeholder="Filter by filename, title or SQL text…" '
        'oninput="drFilterSql()" aria-label="Filter SQL queries">'
        '<select id="dr-sql-stage" class="dr-input" onchange="drFilterSql()" '
        'aria-label="Filter by stage"><option value="">All stages</option>'
        f"{options}</select>"
        '<label class="dr-toggle"><input type="checkbox" id="dr-sql-key" '
        'onchange="drFilterSql()"> Key queries only</label>'
        '<span class="dr-muted" id="dr-sql-count"></span>'
        "</div>"
    )

    ordered = sorted(
        records,
        key=lambda r: (
            not bool(r.get("is_key")),
            str(r.get("stage") or ""),
            str(r.get("filename") or ""),
        ),
    )
    items: List[str] = []
    for record in ordered:
        star = "★ " if record.get("is_key") else ""
        path = str(record.get("relative_path") or record.get("filename") or "")
        lines = record.get("lines") or 0
        haystack = " ".join(
            str(record.get(field) or "")
            for field in ("filename", "relative_path", "title", "sql")
        ).lower()
        body = (
            f'<div class="dr-caption"><code>{_esc(path)}</code> · {_esc(lines)} lines</div>'
        )
        if record.get("error"):
            body += f'<div class="dr-error">Error reading file: {_esc(record["error"])}</div>'
        else:
            body += f'<pre class="dr-code">{_esc(record.get("sql") or "")}</pre>'
        items.append(
            f'<details class="dr-details dr-sql-item" data-stage="{_esc(record.get("stage") or "")}" '
            f'data-key="{"1" if record.get("is_key") else "0"}" '
            f'data-haystack="{_esc(haystack)}">'
            f'<summary>{_esc(star)}{_esc(record.get("stage") or "")} · '
            f'{_esc(record.get("title") or "")} · {_esc(lines)} lines</summary>'
            f'<div class="dr-details-body">{body}</div></details>'
        )
    parts.append(f'<div id="dr-sql-list">{"".join(items)}</div>')
    parts.append('<div class="dr-caption" id="dr-sql-empty" hidden>No queries match the filters.</div>')
    return "".join(parts)


# ---------------------------------------------------------------------------
# Tab: Technical Details
# ---------------------------------------------------------------------------


def _technical_tab_html(output: Mapping[str, Any]) -> str:
    research = output.get("research") or {}
    blocks = [
        ("Resolved Intent", output.get("intent", {})),
        ("Full Analysis Contract", output.get("analysis", {})),
        ("Business Patterns (raw)", research.get("business_patterns") or []),
        ("Reimbursement by Pattern", research.get("reimbursement_by_pattern") or {}),
        ("Recommendations (raw)", research.get("recommendations") or []),
        ("Report Contract", output.get("report", {})),
        ("Visual Recommendations", output.get("visuals", {})),
    ]
    parts: List[str] = [_section_title("Technical Details")]
    for label, payload in blocks:
        parts.append(_details(label, _json_block(payload)))
    return "".join(parts)


# ---------------------------------------------------------------------------
# Page shell
# ---------------------------------------------------------------------------


_CSS = """
:root {
  --ink:#1A2436; --muted:#5B6776; --border:#D6DBE4; --surface:#FFFFFF;
  --surface-alt:#F1F4F9; --primary:#1F3A68; --good:#1A8754; --bad:#B5364B;
}
* { box-sizing:border-box; }
body {
  margin:0; background:var(--surface-alt); color:var(--ink);
  font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
  font-size:15px; line-height:1.55;
}
code, pre { font-family:'IBM Plex Mono',ui-monospace,SFMono-Regular,Menlo,monospace; }
a { color:var(--primary); }
.dr-shell { max-width:1280px; margin:0 auto; padding:0 20px 64px; }
.dr-top {
  position:sticky; top:0; z-index:20; background:var(--surface);
  border-bottom:1px solid var(--border); box-shadow:0 1px 3px rgba(16,24,40,0.06);
}
.dr-top-inner { max-width:1280px; margin:0 auto; padding:16px 20px 0; }
.dr-eyebrow { font-size:0.72rem; font-weight:700; letter-spacing:0.12em; color:var(--muted); }
.dr-title { margin:2px 0 2px; font-size:1.35rem; font-weight:700; letter-spacing:-0.01em; }
.dr-meta { color:var(--muted); font-size:0.85rem; display:flex; gap:14px; flex-wrap:wrap; }
.dr-actions { display:flex; gap:8px; margin:10px 0 0; }
.dr-btn {
  border:1px solid var(--border); background:var(--surface); color:var(--ink);
  border-radius:8px; padding:6px 12px; font-size:0.82rem; cursor:pointer;
}
.dr-btn:hover { background:var(--surface-alt); }
.dr-tabs {
  display:flex; gap:4px; overflow-x:auto; margin-top:12px;
  scrollbar-width:thin; -webkit-overflow-scrolling:touch;
}
.dr-tab {
  flex:0 0 auto; border:0; background:transparent; cursor:pointer; color:var(--muted);
  padding:10px 14px; font-size:0.88rem; font-weight:600; white-space:nowrap;
  border-bottom:3px solid transparent; font-family:inherit;
}
.dr-tab:hover { color:var(--ink); background:var(--surface-alt); }
.dr-tab[aria-selected="true"] { color:var(--primary); border-bottom-color:var(--primary); }
.dr-panel { display:none; padding-top:22px; }
.dr-panel.dr-active { display:block; }
.dr-h2 { font-size:1.3rem; font-weight:700; letter-spacing:-0.01em; margin:0 0 6px; }
.dr-h3 { font-size:1.05rem; font-weight:700; margin:22px 0 6px; }
.dr-h4 { font-size:0.95rem; font-weight:600; margin:18px 0 6px; }
.dr-caption { color:var(--muted); font-size:0.85rem; margin-bottom:8px; }
.dr-muted { color:var(--muted); font-size:0.85rem; }
.dr-label { font-size:0.72rem; font-weight:700; letter-spacing:0.08em; color:var(--muted);
  text-transform:uppercase; margin:12px 0 4px; }
.dr-prose { background:var(--surface); border:1px solid var(--border); border-radius:10px;
  padding:14px 18px; margin-bottom:14px; }
.dr-prose > :first-child { margin-top:0; }
.dr-prose > :last-child { margin-bottom:0; }
.dr-prose p { margin:0 0 10px; }
.dr-list { margin:0 0 10px; padding-left:20px; }
.dr-list li { margin-bottom:4px; }
blockquote { margin:0 0 10px; padding:6px 14px; border-left:3px solid var(--border);
  color:var(--muted); }
.dr-kpi-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr));
  gap:12px; margin:14px 0 18px; }
.dr-kpi { background:var(--surface); border:1px solid var(--border); border-radius:10px;
  padding:14px 16px; }
.dr-kpi-label { font-size:0.72rem; font-weight:700; letter-spacing:0.08em;
  text-transform:uppercase; color:var(--muted); }
.dr-kpi-value { font-size:1.3rem; font-weight:700; margin-top:4px; word-break:break-word;
  font-variant-numeric:tabular-nums; }
.dr-kpi-sub { font-size:0.8rem; margin-top:2px; }
.dr-card { position:relative; background:var(--surface); border:1px solid var(--border);
  border-radius:10px; padding:16px 18px; margin-bottom:14px; overflow:hidden; }
.dr-card-stripe { position:absolute; inset:0 0 auto 0; height:4px; }
.dr-chart { background:var(--surface); border:1px solid var(--border); border-radius:10px;
  padding:8px; margin-bottom:16px; }
.dr-embed { background:transparent; margin-bottom:8px; }
.dr-embed table { max-width:100%; }
.dr-scroll { overflow-x:auto; }
.dr-md-table { width:100%; border-collapse:collapse; background:var(--surface);
  font-size:0.88rem; margin-bottom:12px; }
.dr-md-table th, .dr-md-table td { border:1px solid var(--border); padding:8px 10px;
  text-align:left; vertical-align:top; }
.dr-md-table th { background:var(--surface-alt); font-weight:600; }
.dr-split { display:grid; grid-template-columns:minmax(0,3fr) minmax(0,2fr); gap:18px; }
.dr-split-side .dr-card { margin-bottom:0; }
.dr-cols-3 { display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:16px; }
.dr-col-head { display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; }
.dr-rec-title { display:flex; align-items:flex-start; gap:8px; font-weight:600; line-height:1.4; }
.dr-rank { color:#FFF; border-radius:999px; padding:2px 10px; font-size:0.72rem;
  font-weight:600; flex:0 0 auto; }
.dr-chip-row { display:flex; gap:6px; flex-wrap:wrap; align-items:center; }
.dr-chip { display:inline-block; padding:5px 12px; border-radius:999px; font-size:0.78rem;
  font-weight:600; letter-spacing:0.03em; }
.dr-chip-outline { background:var(--surface); border:1px solid var(--border); color:var(--ink); }
.dr-pattern-head { display:flex; justify-content:space-between; align-items:flex-start;
  gap:16px; flex-wrap:wrap; margin-bottom:14px; }
.dr-details { background:var(--surface); border:1px solid var(--border); border-radius:10px;
  margin-bottom:10px; }
.dr-details > summary { cursor:pointer; padding:10px 14px; font-weight:600; font-size:0.9rem;
  list-style:none; display:flex; align-items:center; gap:8px; }
.dr-details > summary::before { content:'\\25B8'; color:var(--muted); }
.dr-details[open] > summary::before { content:'\\25BE'; }
.dr-details > summary::-webkit-details-marker { display:none; }
.dr-details-body { padding:0 14px 14px; }
.dr-code { background:#0F172A; color:#E2E8F0; border-radius:8px; padding:12px 14px;
  overflow-x:auto; font-size:0.78rem; line-height:1.5; white-space:pre; margin:0 0 8px; }
.dr-json { max-height:520px; overflow:auto; }
.dr-info { background:#EAF1F8; border:1px solid #C7D8EC; color:#1F3A68; border-radius:8px;
  padding:10px 14px; margin-bottom:12px; font-size:0.88rem; }
.dr-error { background:#FDECEE; border:1px solid #F1C3CA; color:#8C1F30; border-radius:8px;
  padding:10px 14px; margin-bottom:12px; font-size:0.88rem; }
.dr-rule { border:0; border-top:1px solid var(--border); margin:22px 0; }
.dr-applied-filters { display:flex; gap:6px; flex-wrap:wrap; align-items:center; margin:8px 0 4px; }
.dr-applied-filters-label { font-size:0.72rem; font-weight:700; letter-spacing:0.08em;
  text-transform:uppercase; color:var(--muted); white-space:nowrap; }
.dr-applied-filter-pill { display:inline-flex; align-items:center; gap:4px;
  background:var(--surface-alt); border:1px solid var(--border); border-radius:999px;
  padding:3px 10px; font-size:0.78rem; color:var(--ink); white-space:nowrap; }
.dr-applied-filter-pill strong { color:var(--primary); font-weight:600; }
.dr-filter-row { display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin:12px 0; }
.dr-input { border:1px solid var(--border); border-radius:8px; padding:7px 10px;
  font-size:0.85rem; font-family:inherit; background:var(--surface); color:var(--ink);
  min-width:180px; }
.dr-toggle { font-size:0.85rem; color:var(--muted); display:flex; align-items:center; gap:6px; }
.dr-tip { position:fixed; z-index:60; max-width:340px; background:#101828; color:#F9FAFB;
  border-radius:8px; padding:8px 10px; font-size:0.78rem; line-height:1.45;
  box-shadow:0 8px 24px rgba(16,24,40,0.24); pointer-events:none; opacity:0;
  transition:opacity .12s ease; white-space:pre-line; }
.dr-tip.dr-tip-on { opacity:1; }
@media (max-width:900px) {
  .dr-split { grid-template-columns:1fr; }
}
@media print {
  body { background:#FFF; }
  .dr-top { position:static; box-shadow:none; }
  .dr-tabs, .dr-actions { display:none; }
  .dr-panel { display:block !important; page-break-before:always; }
  .dr-details { break-inside:avoid; }
  .dr-details > summary { list-style:none; }
}
"""


_JS = """
(function () {
  var tabs = Array.prototype.slice.call(document.querySelectorAll('.dr-tab'));
  var panels = Array.prototype.slice.call(document.querySelectorAll('.dr-panel'));

  function resizeCharts(panel) {
    if (!window.Plotly || !panel) return;
    panel.querySelectorAll('.js-plotly-plot').forEach(function (gd) {
      try { window.Plotly.Plots.resize(gd); } catch (err) { /* chart not ready */ }
    });
  }

  function activate(id, push) {
    var found = false;
    tabs.forEach(function (tab) {
      var on = tab.dataset.target === id;
      tab.setAttribute('aria-selected', on ? 'true' : 'false');
      if (on) { found = true; tab.scrollIntoView({block: 'nearest', inline: 'nearest'}); }
    });
    if (!found) return;
    panels.forEach(function (panel) {
      var on = panel.id === id;
      panel.classList.toggle('dr-active', on);
      if (on) { resizeCharts(panel); }
    });
    if (push && window.history && window.history.replaceState) {
      window.history.replaceState(null, '', '#' + id);
    }
    window.scrollTo({top: 0, behavior: 'smooth'});
  }

  tabs.forEach(function (tab, index) {
    tab.addEventListener('click', function () { activate(tab.dataset.target, true); });
    tab.addEventListener('keydown', function (event) {
      var next = null;
      if (event.key === 'ArrowRight') next = tabs[index + 1];
      if (event.key === 'ArrowLeft') next = tabs[index - 1];
      if (next) { event.preventDefault(); next.focus(); activate(next.dataset.target, true); }
    });
  });

  var initial = (window.location.hash || '').replace('#', '');
  activate(panels.some(function (p) { return p.id === initial; }) && initial
    ? initial
    : (panels[0] ? panels[0].id : ''), false);
  window.addEventListener('resize', function () {
    resizeCharts(document.querySelector('.dr-panel.dr-active'));
  });

  // Hover cards: upgrade every native title tooltip (the interaction-matrix and
  // drill-path cells carry the full dimension list there) into a styled card.
  var tip = document.createElement('div');
  tip.className = 'dr-tip';
  document.body.appendChild(tip);
  document.querySelectorAll('[title]').forEach(function (el) {
    if (el.closest('.js-plotly-plot')) return;
    var text = el.getAttribute('title');
    if (!text || !text.trim()) return;
    el.setAttribute('data-tip', text);
    el.removeAttribute('title');
  });
  function place(event) {
    var pad = 14;
    var x = Math.min(event.clientX + pad, window.innerWidth - tip.offsetWidth - pad);
    var y = event.clientY + pad;
    if (y + tip.offsetHeight + pad > window.innerHeight) { y = event.clientY - tip.offsetHeight - pad; }
    tip.style.left = Math.max(pad, x) + 'px';
    tip.style.top = Math.max(pad, y) + 'px';
  }
  document.addEventListener('mouseover', function (event) {
    var host = event.target.closest ? event.target.closest('[data-tip]') : null;
    if (!host) return;
    tip.textContent = host.getAttribute('data-tip');
    tip.classList.add('dr-tip-on');
    place(event);
  });
  document.addEventListener('mousemove', function (event) {
    if (tip.classList.contains('dr-tip-on')) { place(event); }
  });
  document.addEventListener('mouseout', function (event) {
    var host = event.target.closest ? event.target.closest('[data-tip]') : null;
    if (host) { tip.classList.remove('dr-tip-on'); }
  });

  window.drToggleAll = function (open) {
    document.querySelectorAll('details').forEach(function (node) { node.open = open; });
    resizeCharts(document.querySelector('.dr-panel.dr-active'));
  };

  window.drFilterSql = function () {
    var search = document.getElementById('dr-sql-search');
    var stage = document.getElementById('dr-sql-stage');
    var keyOnly = document.getElementById('dr-sql-key');
    if (!search || !stage || !keyOnly) return;
    var needle = search.value.trim().toLowerCase();
    var shown = 0;
    document.querySelectorAll('.dr-sql-item').forEach(function (item) {
      var ok = (!stage.value || item.dataset.stage === stage.value)
        && (!keyOnly.checked || item.dataset.key === '1')
        && (!needle || (item.dataset.haystack || '').indexOf(needle) !== -1);
      item.hidden = !ok;
      if (ok) shown += 1;
    });
    var counter = document.getElementById('dr-sql-count');
    if (counter) { counter.textContent = shown + ' of ' + document.querySelectorAll('.dr-sql-item').length + ' queries'; }
    var empty = document.getElementById('dr-sql-empty');
    if (empty) { empty.hidden = shown !== 0; }
  };
  if (document.getElementById('dr-sql-search')) { window.drFilterSql(); }
})();
"""


def _plotly_bundle(needed: bool) -> str:
    """Inline the Plotly bundle once so the file stays interactive offline."""

    if not needed or not _PLOTLY_AVAILABLE:
        return ""
    try:
        return f"<script>{get_plotlyjs()}</script>"
    except Exception:  # noqa: BLE001 — fall back to non-interactive charts
        logger.exception("Could not inline the Plotly bundle in the HTML report")
        return ""


def _humanize_filter_name(name: str) -> str:
    """Convert a snake_case dimension or filter key to a human-readable label."""
    return name.replace("_", " ").title()


def _filters_html(applied_filters: Optional[Mapping[str, Any]]) -> str:
    """Render applied UI filters as a row of labelled pills.

    Accepts the ``selections`` dict returned by ``_render_filters`` in
    ``app.py``.  Only the user-visible fields are shown:
    ``metric_name``, ``period_label``, ``time_selections``, and
    ``dimension_selections``.
    Ignores internal keys (``principal_time_dimension*``, ``view_name``, etc.).
    Returns an empty string when no filters are present or the argument is
    ``None``.
    """

    if not applied_filters or not isinstance(applied_filters, Mapping):
        return ""

    pills: List[str] = []

    metric = applied_filters.get("metric_name")
    if metric and str(metric).strip():
        pills.append(
            f'<span class="dr-applied-filter-pill">'
            f'<strong>Metric</strong> {_esc(metric)}</span>'
        )

    period = applied_filters.get("period_label")
    if period and str(period).strip():
        pills.append(
            f'<span class="dr-applied-filter-pill">'
            f'<strong>Period</strong> {_esc(period)}</span>'
        )

    time_selections: Mapping[str, Any] = applied_filters.get("time_selections") or {}
    for dim_name, value in time_selections.items():
        if value is None:
            continue
        label = _humanize_filter_name(dim_name)
        pills.append(
            f'<span class="dr-applied-filter-pill">'
            f'<strong>{_esc(label)}</strong> {_esc(str(value))}</span>'
        )

    dimension_selections: Mapping[str, Any] = applied_filters.get("dimension_selections") or {}
    for dim_name, value in dimension_selections.items():
        if value is None:
            continue
        label = _humanize_filter_name(dim_name)
        if isinstance(value, (list, tuple)):
            display = ", ".join(str(v) for v in value if v is not None)
        else:
            display = str(value)
        if display:
            pills.append(
                f'<span class="dr-applied-filter-pill">'
                f'<strong>{_esc(label)}</strong> {_esc(display)}</span>'
            )

    if not pills:
        return ""

    pills_html = "".join(pills)
    return (
        f'<div class="dr-applied-filters">'
        f'<span class="dr-applied-filters-label">Filters applied</span>'
        f'{pills_html}</div>'
    )


def build_html_report(
    output: Mapping[str, Any],
    sql_records: Optional[Sequence[Mapping[str, Any]]] = None,
    applied_filters: Optional[Mapping[str, Any]] = None,
) -> str:
    """Turn the orchestrator's ``output`` dict into a self-contained HTML report.

    ``sql_records`` are the same dicts the SQL Queries tab renders (see
    ``app._sql_records_for_output``); pass ``None`` to omit that tab's content.
    ``applied_filters`` is the ``selections`` dict returned by
    ``app._render_filters`` and is rendered as a row of filter pills in the
    report header so readers know exactly what scope was used.
    """

    if not isinstance(output, Mapping):
        raise TypeError("build_html_report expects a mapping (the orchestrator output dict).")

    research = output.get("research") or {}
    patterns: List[Mapping[str, Any]] = [
        p for p in (research.get("business_patterns") or []) if isinstance(p, Mapping)
    ]
    reimbursement_by_pattern = research.get("reimbursement_by_pattern") or {}
    if not isinstance(reimbursement_by_pattern, Mapping):
        reimbursement_by_pattern = {}
    cards: List[Mapping[str, Any]] = [
        c
        for c in ((research.get("pattern_summary") or {}).get("cards") or [])
        if isinstance(c, Mapping)
    ]
    recommendations = [
        r for r in (research.get("recommendations") or []) if isinstance(r, Mapping)
    ]
    result_keys = _reimbursement_keys(patterns)

    tabs: List[Dict[str, str]] = [
        {
            "id": "tab-correlation",
            "label": "Correlation Summary",
            "body": _correlation_tab_html(output),
        }
    ]
    for index, pattern in enumerate(patterns):
        label = f"Pattern {pattern.get('pattern_rank', index + 1)}"
        segment_label = _pattern_segment_label(pattern)
        tabs.append(
            {
                "id": f"tab-pattern-{index + 1}",
                "label": f"{label}: {segment_label}" if segment_label else label,
                "body": _pattern_tab_html(
                    pattern,
                    reimbursement_by_pattern.get(result_keys[index]),
                    cards,
                    index + 1,
                ),
            }
        )
    tabs.append(
        {
            "id": "tab-recommendations",
            "label": "Recommendations",
            "body": _recommendations_tab_html(recommendations),
        }
    )
    tabs.append(
        {"id": "tab-sql", "label": "SQL Queries", "body": _sql_tab_html(sql_records or [])}
    )
    tabs.append(
        {"id": "tab-technical", "label": "Technical Details", "body": _technical_tab_html(output)}
    )

    tab_buttons = "".join(
        '<button class="dr-tab" role="tab" type="button" '
        f'data-target="{tab["id"]}" aria-controls="{tab["id"]}" '
        f'aria-selected="false">{_esc(tab["label"])}</button>'
        for tab in tabs
    )
    panels = "".join(
        f'<section class="dr-panel" id="{tab["id"]}" role="tabpanel">{tab["body"]}</section>'
        for tab in tabs
    )

    question = str(output.get("question") or "Deep Research Analysis")
    generated = dt.datetime.now().strftime("%d %b %Y, %H:%M")
    period_text = format_period_window(_find_correlation_summary(output).get("period_window"))
    meta_bits = [f"Generated {generated}"]
    if period_text:
        meta_bits.insert(0, period_text)

    filters_block = _filters_html(applied_filters)

    # Only pay the ~5 MB bundle when a chart actually made it into the page.
    charts_needed = "plotly-graph-div" in panels

    return (
        "<!doctype html>\n"
        '<html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        f"<title>Deep Research · {_esc(question[:80])}</title>"
        f"<style>{_CSS}</style>"
        f"{_plotly_bundle(charts_needed)}"
        "</head><body>"
        '<header class="dr-top"><div class="dr-top-inner">'
        '<div class="dr-eyebrow">DEEP RESEARCH RESULTS</div>'
        f'<h1 class="dr-title">{_esc(question)}</h1>'
        f'<div class="dr-meta">{"".join(f"<span>{_esc(bit)}</span>" for bit in meta_bits)}</div>'
        f"{filters_block}"
        '<div class="dr-actions">'
        '<button class="dr-btn" type="button" onclick="drToggleAll(true)">Expand all</button>'
        '<button class="dr-btn" type="button" onclick="drToggleAll(false)">Collapse all</button>'
        '<button class="dr-btn" type="button" onclick="window.print()">Print</button>'
        "</div>"
        f'<div class="dr-tabs" role="tablist">{tab_buttons}</div>'
        "</div></header>"
        f'<main class="dr-shell">{panels}</main>'
        f"<script>{_JS}</script>"
        "</body></html>"
    )


def suggested_filename(output: Mapping[str, Any]) -> str:
    """Return a friendly filename for the download button."""

    question = str(output.get("question") or "deep_research").strip() or "deep_research"
    slug = "".join(ch if ch.isalnum() else "_" for ch in question).strip("_").lower()
    slug = slug[:60] or "deep_research"
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M")
    return f"deep_research_{slug}_{stamp}.html"
