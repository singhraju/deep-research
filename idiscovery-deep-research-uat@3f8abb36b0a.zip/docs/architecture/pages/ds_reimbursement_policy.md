# Reimbursement policy

Payer medical and reimbursement policy documents: the published rules that say what a payer
covers, under what conditions, and how it pays. They are the evidence that turns "spending on
these codes rose" into "spending rose because this rule changed."

## What it does in Deep Research

Policy documents are the citation layer of an investigation. A pattern establishes that
something moved; a policy explains it, or fails to, and the difference between those two
outcomes is what a reviewer needs to see.

Policy text enters the system through exactly one path: the **Policy Comparison API**, called
by keyword search from `search_policies_node` in
`packages/agents/src/deep_research_agents/reimbursement_agent.py`. Results are filtered
client-side by title anchors and deduplicated on payer and title before anything reaches a
prompt - see [Reimbursement](/architecture/e/mcp_reimbursement) for why that reduction is
necessary and how large it is.

**Nothing in this repository crawls payer websites.** The URLs listed under References below
come from few-shot examples inside agent prompts. They show the *kind* of source a citation
should look like; they are not configured feeds, and no scheduled job fetches them.

## How it is set up

The API endpoint and its environment are in the table below rather than in this page.

Two properties of the source are worth knowing before relying on it:

- **It matches on full policy text, not titles.** A keyword returns every policy that
  mentions the term anywhere in prose, which is why an unfiltered search returns hundreds of
  irrelevant documents.
- **It spans payers.** Competitor policies come back alongside Elevance ones, which is what
  makes benchmarking possible - and also means "the policy says" is ambiguous until you check
  the payer field on the row.

## Key decisions

- Retrieval goes through the prebuilt Policy Comparison service rather than a bespoke
  crawler. Policy documents are published across dozens of payer sites in inconsistent
  formats; a shared service that already normalizes them is worth more than a scraper this
  team would own.
- The reduction step is client-side. The API exposes no title-scoped search, so the only
  available lever is to ask broadly and filter locally.

## Gotchas

- A hypothesis that cites a policy is not the same as a retrieved policy. The
  [policy hypothesis agent](/architecture/e/svc_policy_hypothesis) reasons over aggregated
  claim metrics and names candidate policies from the model's own knowledge - its prompt
  requires it to answer "not verified" when it has no evidence. Those citations are leads to
  check against the API, not findings.
