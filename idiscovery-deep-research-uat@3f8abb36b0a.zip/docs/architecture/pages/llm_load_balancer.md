# LLM Load Balancer

A load balancer in front of model calls spreads them across several deployments, and
sometimes across several models, so that a burst of traffic does not hit one deployment's
rate limit and start failing.

On the solution slide it sits between the Agents Framework and the LLM gateway. It does not
exist yet.

## What it does in Deep Research

Nothing today. Model selection is a single configured deployment per call site:
`EHAP_LLM_MODEL` and `DEEP_RESEARCH_LLM_MODEL`, both defaulting to the same model. Every
agent in a run therefore competes for the same deployment's quota.

The behaviour that stands in for it is retry. `EHAPBase`
(`packages/utils/src/deep_research_utils/ehap.py`) retries on transient failures and
refreshes an expired token in the process. That absorbs a brief throttle; it does not
spread load, and under sustained pressure it adds to it.

## How it is set up

It is not. What is already in place, and would be the hook for it:

- **One client.** Every model call in the codebase goes through `EHAPBase`, so a
  distribution policy has exactly one place to live rather than needing an edit per agent.
- **Per-call-site model constants.** The model name is already read from configuration
  rather than hardcoded, so pointing different call sites at different deployments needs
  no code change.
- **A shared token cache in Redis**, so a pool of deployments would not multiply token
  minting.

The missing piece is a deployment inventory - which deployments exist per environment,
with what quota - and that is a question for the EHAP team, not a code change.

## Key decisions

- Retry-in-the-client was built before distribution. It is the cheaper half of the
  problem and it covers the common case of a single slow response, so it went first.

## Gotchas

- Sizing this needs the fan-out counted, not guessed. A single orchestrator run is not one
  model call: intent detection, the analysis mode, the hypothesis agents, the pattern
  agent, the reimbursement fan-out, and then three separate contract-building nodes each
  make their own. See [Orchestrator](/architecture/e/svc_orchestrator) for the node
  sequence.
