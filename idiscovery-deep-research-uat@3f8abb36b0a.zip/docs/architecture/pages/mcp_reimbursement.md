# Reimbursement

The reimbursement agent answers whether a cost movement is explained by a policy: it takes
the codes involved in a spike, finds the payer policies that govern them, and reports which
ones changed, how Elevance's position compares to competitors', and what the codes imply
about how a claim should have been paid.

It is the most developed of the domain agents on the slide, and the only one that retrieves
external documents rather than reasoning from what it is given.

## What it does in Deep Research

The class is `ReimbursementPolicyAgent`
(`packages/agents/src/deep_research_agents/reimbursement_agent.py:348`), registered as
`reimbursement_policy`. The orchestrator calls it through `run_reimbursement_fanout`, once
per pattern - hence "fan-out": a run with six patterns makes six independent analyses.

Its inputs come from the [pattern agent](/architecture/e/svc_pattern), and the module
carries the extraction helpers that get them there:
`extract_drg_codes_from_pattern_output` and
`extract_lob_state_product_from_pattern_output` reduce pattern output to the codes, line of
business, state and product a policy search needs.

Policy text arrives from the Policy Comparison API - see
[Reimbursement policy](/architecture/e/ds_reimbursement_policy) and
[Policy Comparison](/architecture/e/model_policy_comparison).

## How it is set up

**Retrieval.** `search_policies_node` POSTs to the policy search endpoint with a keyword
and `user_type=onshore`, using `AppConstants.SSL_CERT_FILE` for verification, with two
retries at one and two seconds. The endpoint is in the environments table below, not in
this page.

**Title anchors, and why they exist.** The API does exact-string matching against the full
policy *text*, not the title. A keyword like "injection" therefore returns hundreds of
policies that mention it once in passing. So the agent asks the model for two to five title
substring anchors from the CPT/HCPCS codes
(`_generate_title_anchors_from_cpt`), then filters the response by a title regex and
deduplicates on `(payor, policy_title)`. The measured reduction is 12 to 100 times fewer
results with the topically relevant Elevance policies retained. That reduction is what makes
the step affordable; without it the result set does not fit in a prompt.

**LOB name variants.** The API expects its own line-of-business spellings, so the agent maps
between the internal names and the API's before searching. A mismatch there returns zero
results rather than an error, which is the failure mode to watch for.

**Reasoning effort** is set to `medium` at construction, deliberately per agent rather than
globally.

Tests: `packages/agents/tests/test_reimbursement_title_anchors.py` and
`test_reimbursement_cpt_keywords.py`. Both build the agent with `__new__` to bypass
Snowflake and LLM initialization, which is the established pattern for testing this agent's
pure transformations.

## Key decisions

- Filtering happens client-side after retrieval, not by sending a better query. The API
  offers no title-scoped search, so the only available lever is asking broadly and reducing
  locally.
- The anchors are model-generated rather than a static keyword table. Code-to-topic mapping
  changes with every code set, and a hand-maintained table would be stale within a quarter.
- Reimbursement runs per pattern rather than once per investigation. Policies are specific
  to codes and geography, so a single combined search would blur the distinctions the
  patterns exist to draw.

## Gotchas

- The policy endpoint URL has a hardcoded default in the constructor signature. It is
  overridable, but the default is what runs unless a caller passes something else.
- `reimbursement_agent.py` is over 5,000 lines. `prepare_state` is at the far end of it;
  use the symbol, not a scroll.
- A zero-result search usually means an LOB spelling mismatch, not an absence of policy.
