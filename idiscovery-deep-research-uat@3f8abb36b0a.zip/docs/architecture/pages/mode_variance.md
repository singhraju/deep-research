# Variance drill down

The variance drill down is the analysis behind "costs went up - why?" It resolves the two
periods being compared, computes the delta on the chosen metric, ranks every available
dimension by how much of that delta it accounts for, then drills into the top contributors
until a stop rule says enough.

It is registered as `cost_change_investigation_over_time_window`, and it is the only analysis
mode implemented today. The slide shows five.

## What it does in Deep Research

An analysis mode's job is to emit an **analysis contract**: a validated JSON structure
carrying the scope, the selected configuration, an execution plan, the findings, and the
artifacts produced. The three contract builders at the end of every orchestrator run - report,
visual, summary - read that one structure, which is why every analysis mode produces the same
output shape regardless of what it did internally.

The plan this mode declares, in order:

1. `time_window_builder` - resolve prior and current comparable periods from a rolling window
   or explicit dates
2. `baseline_delta_sql` - current versus prior totals for the drill metric within scope
3. `dimension_ranking_sql` - rank candidate dimensions by absolute and percentage
   contribution to the delta
4. `iterative_drill_subgraph` - drill into top contributors until the configured stop rules
   are hit
5. `structured_findings_builder` - emit strict JSON findings

The work itself is done by the [correlation agent](/architecture/e/svc_correlation), against
a semantic model. Stop rules, the drill metric, explainer metrics and the period all arrive
as `analysis_mode_parameters` on the resolved intent - see
[Intent resolver](/architecture/e/svc_resolver).

## How it is set up

There are **two handlers registered under the same mode name**, and knowing which one ran
explains most confusing output.

`build_default_analysis_mode_handlers()` at
`packages/agents/src/deep_research_agents/orchestrator.py:991` registers
`default_cost_change_handler`, which is a *planning stub*. It resolves the parameters and
emits a well-formed contract describing what would be done, with `status: planned` and empty
findings. It executes nothing.

`build_app` then replaces it with `build_correlation_analysis_handler(correlation_runner)`
whenever a correlation runner is available - which requires `enable_correlation_execution`
and either an injected runner or enough credentials to build one. That handler runs the real
analysis and fills in findings and artifacts.

So a contract that comes back with `status: planned` and no findings is not a failure. It
means no correlation runner was wired up, and the message explaining why is in the logs from
`build_app`.

## Key decisions

- The contract is the interface, not the agent. Downstream nodes read the contract, so an
  analysis mode can be a stub, a SQL pipeline or a future subgraph without any of them
  knowing.
- The stub is a real handler rather than an error. It lets the whole graph, the API surface
  and the UI be exercised with no Snowflake connection, which is what makes the orchestrator
  testable.
- Modes come from a registry rather than a branch, so the four remaining modes on the slide
  are one dictionary entry each plus a handler.

## Gotchas

- `validate_analysis_contract` requires twelve specific keys and asserts the whole structure
  is JSON-serializable. A handler that returns a partly-filled contract fails at the mode
  node, not downstream - which is intended, but the traceback points at the validator rather
  than at the handler that shortchanged it.
- `status` inside the contract is the contract's own lifecycle field. It is unrelated to the
  delivery status chip at the top of this page.
