# Markdown skills

A skill is a written instruction set an agent loads to perform a specific task - the
procedure for one job, versioned as a file rather than embedded in a prompt string in code.
The solution slide describes them as "markdown and scripts that enable an agent to perform a
specific task."

Nothing in this repository implements them. This page describes the concept and what
currently stands in its place, so that the gap is legible rather than implied.

## What it does in Deep Research

Nothing yet. There is no skill loader, no skills directory, and no agent that reads one.

What exists instead is prompt constants. Each agent's instructions are module-level strings -
`POLICY_SYSTEM_PROMPT` in `policy_hypothesis_agent.py` is a representative example: about
forty lines specifying the analyst role, the constraints ("do not invent policy changes"), the
inputs to expect, and a numbered reasoning process. That is a skill in everything but
packaging.

The difference packaging would make:

- **Reuse.** A prompt constant belongs to its module. Two agents needing the same procedure
  copy it, and the copies diverge.
- **Review.** Changing analytical instructions is currently a Python diff, so it goes through
  code review by people reviewing code, not by the policy analysts who know whether the
  instruction is right.
- **Composition.** An agent cannot pick up a procedure at run time based on the question it
  was asked, because there is nothing to pick up.

## How it is set up

It is not. Two things would have to be decided first, and neither is a coding question:

1. **Where skills live and who owns them.** If the point is that a domain expert can change a
   procedure without a Python change, the files cannot live where only engineers look.
2. **Whether a skill is trusted input.** A skill is instructions to a model, so an editable
   skill file is an editable instruction channel. Where they are readable from decides how
   much that matters.

There is a working precedent for the mechanism in this repo, in a much lower-stakes place:
this documentation site loads its page content from markdown files under
`docs/architecture/pages/`, found by convention on the element id, re-read on every request
with no registration step. Same shape - files as data, discovered by name - and the same
question about trust, answered there by escaping raw HTML and allowlisting link schemes.

## Key decisions

- No decision recorded. The prompts-as-constants arrangement is where the code started, not a
  position anyone argued for.

## Gotchas

- Do not read the Skills panel on the slide as describing something that exists. Every agent's
  instructions are today a string literal in a Python module.
