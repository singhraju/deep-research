# Correlation agent

The correlation agent answers "what actually moved?" It takes a cost or utilization change
and decomposes it across the dimensions available in the data - state, provider, DRG, place
of service, revenue code - to find which combinations account for the movement, then drills
into the largest ones.

It is the numerical core of an investigation. Everything downstream, from patterns to
recommendations, reads its output.

## What it does in Deep Research

Two things, in that order, and the order is the point.

**A deterministic pipeline.** Candidate selection, segment aggregation, and path drill-down
are SQL and arithmetic against a declared semantic model. No model is involved in producing
a number.

**An optional LLM summary on top.** The executive summary is generated from the pipeline's
results, not instead of them. `llm_summary_mode` defaults to `auto`: if no model is
available the analysis still completes, minus the prose.

Its output is described by explicit contracts - `CorrelationRunResult`,
`CorrelationAgentResponse` and their Pydantic equivalents in
`packages/agents/src/deep_research_agents/correlation_agent.py`. Those schemas are what
`AgentAPIBuilder` turns into the HTTP response model, so they are the published interface,
not internal detail.

Consumers: the [orchestrator](/architecture/e/svc_orchestrator) calls it as part of the
variance analysis mode, the [pattern agent](/architecture/e/svc_pattern) reads its
correlations, and the ETL pipeline runs it in batch.

## How it is set up

**The semantic model is the configuration.** A YAML file under
`configs/correlation_pattern/` declares tables, fields, metrics and relationships, and the
agent generates SQL only within what it declares. See
[Semantic views](/architecture/e/ing_semantic_views).

**Paths are constrained.** `_resolve_semantic_model_path` resolves a supplied path against
the project root and then requires the result to be inside
`configs/correlation_pattern/`, raising `AgentConfigurationError` otherwise. The path
arrives on an HTTP request, so an unconstrained one would be a file-read primitive.

**Snowflake access is injected.** The constructor takes either a `SnowparkHelper` or a
builder for one, so the agent can be constructed without a live connection and given one
later - which is what lets the orchestrator run with correlation execution disabled.

**Run artifacts** are written under `output_root`, defaulting to `correlation_runs`.

The related tables and drill-down rendering live in
`correlation_interaction_matrix.py` and `correlation_recommendation.py` beside it.

## Key decisions

- Numbers are deterministic and prose is optional. A variance figure that a model
  paraphrased is not auditable, and this analysis ends up in front of people making
  contract decisions. The LLM never touches the arithmetic.
- SQL is generated from a hand-authored semantic model rather than from raw schemas. It
  bounds the join space, which is what makes a wrong answer unlikely rather than merely
  detectable.
- The semantic model path is a request parameter, so one deployment serves several semantic
  views - hence the containment check.

## Gotchas

- SQL generation lives in functions inside this module rather than as a standalone tool, so
  no other agent can reuse it without importing the correlation agent. See
  [SQL generator](/architecture/e/tool_sql_generator).
- `_resolve_semantic_model_path` derives the project root as `parents[4]` of the module
  file. That holds for an editable install and breaks under a non-editable one.
