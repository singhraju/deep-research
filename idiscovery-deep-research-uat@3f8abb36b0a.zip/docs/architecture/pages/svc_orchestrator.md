# Orchestrator

The orchestrator is the graph that turns one question into one investigation. It decides
what the user asked for, picks the analysis to run, calls the agents in the right order,
and assembles their output into the report, chart and summary the UI renders.

It is a LangGraph `StateGraph` over a single `OrchestratorState` dictionary, compiled at
startup in `build_app`.

## What it does in Deep Research

The graph is built at `packages/agents/src/deep_research_agents/orchestrator.py:1862`.
The path a question takes:

```
prepare_request -> run_intent_detection -> decide_next_step -> (conditional)
```

`decide_next_step` routes to one of three destinations:

- **clarification** - the question is not answerable as asked. Straight to `finalize`.
- **analysis__<mode>** - a registered analysis mode owns this question. See
  [Variance drill down](/architecture/e/mode_variance).
- **analysis__generic** - no mode matches, so a general path runs instead.

An analysis mode that produces patterns continues through the agent chain:

```
run_pattern_agent -> run_reimbursement_fanout -> run_recommendation_agent
    -> build_report_contract
```

`run_hypothesis_agents` joins the same convergence point. Everything then funnels through
three contract builders and out:

```
build_report_contract -> build_visual_contract -> build_summary_contract -> finalize -> END
```

Each contract builder is a separate node on purpose - the report, the charts and the
executive summary are three different shapes of output over the same findings, and
separating them means a failure in chart building does not cost the report.

## How it is set up

**Analysis mode registry.** `build_default_analysis_mode_handlers()` at
`orchestrator.py:991` returns a name-to-handler mapping, and `build_app` adds one graph
node per entry. Registering a mode is adding a key there; the node, the edge and the
routing follow automatically.

**Intent detection has a bypass.** When the Streamlit UI has already collected filters
from the user, it hands over a fully-formed intent and sets `bypass_intent_detection`.
`run_intent_detection` then skips the model call and the soft-merge step entirely, because
filters a user picked in a dropdown are authoritative and re-deriving them from prose can
only lose information. Validation still runs. See
[Intent resolver](/architecture/e/svc_resolver).

**Correlation execution is a flag.** `enable_correlation_execution` decides whether the
graph gets a live correlation runner or none. With it off, a supplied runner is ignored and
logged - so the graph can be exercised without a Snowflake connection.

**Contracts are validated, not trusted.** `validate_analysis_contract` requires twelve
specific keys and asserts the whole structure is JSON-serializable before it travels.
A node that half-fills a contract fails at the boundary rather than three nodes later.

## Key decisions

- Modes are registered rather than branched on. A new analysis mode is one dictionary
  entry, not an edit to the routing function - which is what keeps `decide_next_step`
  readable as the graph grows.
- State is one flat `TypedDict` rather than per-node models. It makes every node's inputs
  visible in one declaration, at the cost of a large type.
- The graph fans in to `build_report_contract` from several paths rather than duplicating
  the tail per path. Every route produces the same output shape, so the UI has one contract
  to render regardless of which analysis ran.

## Gotchas

- `deep_research_agents/__init__.py` registers a `ContractAgent` from a module that does
  not exist, and `missing_agents()` reports it at import time. It is expected output, not
  a failure.
- The graph is compiled once in `build_app`. Adding a node at runtime does nothing.
