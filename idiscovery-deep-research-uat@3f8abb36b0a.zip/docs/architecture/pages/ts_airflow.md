# Airflow Scheduler

Apache Airflow is the iDiscovery platform's job scheduler. On the solution slide it is
the thing that wakes the ingestion and ETL work up on a schedule so nobody has to
remember to run it.

That is the intent. Read the status chip above before you plan around this page: no DAG
definition exists anywhere in this repository.

## What it does in Deep Research

Nothing yet, directly. The pipeline Airflow is meant to schedule does exist and does
run - it is just launched by hand.

The batch job is `apps/ETL/dr_etl_pipeline.py`, wrapped by
`apps/ETL/run_dr_etl_pipeline.sh`. That script is the shape of the command a DAG would
eventually call:

```sh
./run_dr_etl_pipeline.sh dv --lob nogbd --statscl-mdl-cd "IP AUTH" --trnd-tm-prd-cd R3
```

It takes one of four environment codes (`dv`, `ts`, `pl`, `pr`), activates a virtualenv,
and runs the pipeline. The pipeline reads anomaly insight rows out of Snowflake, walks
them through the correlation, pattern, reimbursement, recommendation and policy agents in
sequence, and writes the results back to Snowflake. `apps/ETL/ReadMe.md` documents the
stage-by-stage flow and the filter parameters (`SNAP_YEAR_MNTH_NBR`, `TRND_TM_PRD_CD`,
`LOB_SHRT_DESC`, `STATSCL_MDL_CD`).

## How it is set up

It is not, in this repo. Two things are worth knowing before someone wires it up.

The runner invokes `python /app/apps/ETL/dr_etl_pipeline.py` - an absolute container
path, not a relative one. The script is written to execute inside the built image, so a
DAG should run the container rather than a checkout. Running it from a local clone works
only if the clone happens to live at `/app`.

The environment codes the runner accepts (`dv`, `ts`, `pl`, `pr`) are not the same
vocabulary as the application's own environments (`local`, `dev`, `uat`, `prod`, which is
what the environments table on this page uses). A DAG author has to translate between
them, and getting that wrong points the pipeline at the wrong Snowflake tier.

## Key decisions

- The pipeline is a plain CLI with explicit flags rather than a scheduler-aware module.
  That keeps it runnable and debuggable by hand, which is how it is actually operated
  today, and leaves the scheduling decision open.

## Gotchas

- The environments table below is empty until someone fills in the real hostnames.
  Nobody in this repo has them, and a plausible-looking guess is worse than a blank -
  see the note on the Airflow reference below.
