# iDiscovery platform

iDiscovery is the internal analytics platform this application is a tenant of. It supplies
the things Deep Research does not build for itself: Kubernetes to run on, Argo CD to
deploy with, Vault for credentials, Redis for caching, the Snowflake accounts holding the
data, and the identity layer in front of all of it.

## What it does in Deep Research

It is the deployment target and the source of nearly every dependency on the Tech Stack
band of the solution diagram.

Deep Research contributes two long-running processes and one batch job:

- the FastAPI agent service, which serves agent runs, results, and this documentation
  site - see [FastAPI Microservices](/architecture/e/ts_fastapi)
- the Streamlit UI - see [Streamlit](/architecture/e/ts_streamlit)
- the ETL pipeline, run as a job - see [ETL pipeline](/architecture/e/ing_etl_pipeline)

`start_servers.sh` starts the first two together for local work.

## How it is set up

Deployment is not defined in this repository - it lives in the platform's own manifests.
What this repo does define is everything the platform has to inject:

- **Configuration** comes from `configs/<env>.ini`, selected by the `ENVIRONMENT`
  variable. `packages/utils/src/deep_research_utils/app_constant.py` reads it, falling
  back to process environment variables per key.
- **Credentials** are not in the image. Snowflake credentials come from Vault at
  connection time; the LLM gateway's client id and secret come from configuration.
- **One variable is easy to miss:** `DOCS_BASE_URL` defaults to `http://localhost:8000`.
  It is what the Streamlit header uses to link to this site, so in a deployed pod it has
  to be set to the external ingress hostname or every link a user copies from the UI
  reads `localhost`.

## Key decisions

- Environment selection is a single variable driving one INI file per tier, rather than a
  variable per setting. It makes the whole configuration of an environment reviewable as
  one diff.
- The architecture documentation is served by the application rather than published as a
  static site, so `/architecture` cannot drift from the code it describes. It re-reads its
  YAML and markdown on every request.

## Gotchas

- `configs/dev.ini` is currently deleted in the working tree while the default
  `ENVIRONMENT` is still `dev`, so a run with no `ENVIRONMENT` set fails to load its
  config. Set it explicitly.
