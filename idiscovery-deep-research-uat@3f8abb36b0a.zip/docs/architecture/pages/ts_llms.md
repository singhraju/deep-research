# LLMs

Every model call this application makes goes through EHAP, the enterprise hosting and
access platform for large language models. There is no direct vendor API access from this
codebase - no OpenAI or Anthropic key, no vendor SDK, no fallback path that bypasses the
gateway.

## What it does in Deep Research

Model calls are what turn structured claim numbers into an explanation. The agents that
depend on it:

- [Correlation agent](/architecture/e/svc_correlation) - summarizing what a correlation
  means, on top of a deterministic numeric pipeline
- [Reimbursement](/architecture/e/mcp_reimbursement) - reading policy documents and
  matching them to codes
- The hypothesis agents - proposing candidate policy and mandate explanations for a
  spike
- [Orchestrator](/architecture/e/svc_orchestrator) - intent detection, and the report,
  visual and summary contracts at the end of a run

All of them reach the gateway through one client: `EHAPBase`, in
`packages/utils/src/deep_research_utils/ehap.py`.

## How it is set up

`EHAPBase` is a client-credentials OAuth client with token caching.

**Authentication.** It POSTs `client_id`, `client_secret` and
`grant_type=client_credentials` to `EHAP_BASE_URL` + `EHAP_TOKEN_PATH`. That path defaults
to `/v2/oauth2/token` and is overridable per environment and per instance, because the
gateway has moved it before.

**Token caching.** Tokens go into Redis with a TTL from `AppConstants.CACHE_TTL`
(30 minutes by default), keyed so that every process shares one token instead of each
minting its own. If Redis is unreachable the client falls back to a class-level in-memory
cache and logs a warning - degraded, not broken. It also decodes the JWT's `iat` claim
without verifying the signature, purely to compare token age so a revoked-but-unexpired
cached token can be detected.

**Model selection.** `EHAP_LLM_MODEL` and `DEEP_RESEARCH_LLM_MODEL` in
`packages/utils/src/deep_research_utils/app_constant.py`, both defaulting to `gpt-5.4`.
Reasoning effort is set per agent at construction, not globally - the reimbursement agent
asks for `medium`, for instance.

Credentials come from Vault where available and from process environment variables
otherwise; `app_constant.py` checks which of `EHAP_BASE_URL`, `EHAP_CLIENT_ID` and
`EHAP_CLIENT_SECRET` each source provides.

## Key decisions

- One client class for the whole codebase, rather than an SDK per agent. It puts token
  minting, caching and retry in a single place, which is why a gateway change is a
  one-line configuration edit rather than a sweep.
- The token endpoint path is configuration, not a constant. It has already changed once.
- The token cache is shared through Redis rather than per-process. Under a pod count of
  more than one, per-process caching multiplies token requests against a gateway that
  rate-limits them.

## Gotchas

- `app_constant.py` reads `OPENAI_BASE_URL` with no default, so importing anything from
  `deep_research_utils` fails outright if that variable is unset - including in tests.
- The client never logs `client_id` or `client_secret`, and the log line on every token
  mint is written specifically to avoid it. Keep it that way: it runs at INFO, so it lands
  in log files and in captured notebook output.
