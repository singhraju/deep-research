# Okta

Okta is Elevance Health's enterprise single sign-on. It is how people authenticate to
iDiscovery, and it appears on the solution slide as part of that platform.

Deep Research itself does not authenticate through it. This page exists mainly to say so,
because the slide puts Okta next to things this application really does call, and the
distinction matters the first time someone debugs a connection failure.

## What it does in Deep Research

Nothing at runtime.

Snowflake connections are opened by `SnowparkHelper`
(`packages/utils/src/deep_research_utils/snowflake_helper.py`) and it accepts exactly two
`connection_type` values:

- `programmatic` - key-pair or password credentials supplied directly
- `vault` - the same, fetched from HashiCorp Vault at connection time

Anything else is rejected at `snowflake_helper.py:115` with the message *"Invalid
connection_type. Please use 'programmatic' or 'vault'. Okta authentication is
deprecated."*

## How it is set up

It is not set up, and the remains of the attempt are still in the file:

- `_setup_okta_connection` at `snowflake_helper.py:141` is commented out in full.
- The external-browser authenticator URL appears three times
  (`snowflake_helper.py:146`, `:167`, `:934`) and every occurrence is inside a comment.
- `snowflake_helper.py:930` carries the reason: *"WIP got error while logging in with
  okta"*.

So the authenticator endpoint under References below is real, but it is the SSO endpoint
the Snowflake connector would be handed - not a dashboard, and not something this code
calls.

## Key decisions

- Service-to-service Snowflake access went to Vault rather than Okta. Okta's external
  browser flow needs an interactive browser, which a FastAPI pod and a batch ETL job do
  not have. Vault gives an unattended path with audited credential retrieval, so the
  interactive flow was abandoned rather than fixed. See
  [HashiCorp Vault](/architecture/e/ts_vault).

## Gotchas

- The dead code reads like a working option. `connection_type="okta"` looks supported if
  you skim the file, and the constructor is where you find out it is not.
- This element deliberately carries no source path. Pointing it at
  `snowflake_helper.py` would read as "here is the integration" when the absence of one
  is the whole point.
