# Protegrity

Protegrity is the enterprise tokenization and de-identification platform. Its job is to
replace protected health information and personally identifying information with tokens,
so that analytics can run over data that is no longer directly identifying.

It is on the solution slide because PHI protection is a real requirement for everything
this application touches. It is marked planned because no part of this repository calls
it, and this page cannot tell you whether something upstream does.

## What it does in Deep Research

Nothing that is visible from here. A search of this repository for "protegrity" returns
no Python, config, or shell match at all.

That leaves an open question rather than an answer, and it is the important content of
this page: **the data this application reads from Snowflake may already be tokenized
upstream in the data lake, or it may not be.** Deep Research reads
`P01_EDL.EDL_ALLPHI`-style schemas - the `ALLPHI` naming says plainly that at least some
of what is reachable is not de-identified.

## How it is set up

Unknown from this repository, and worth establishing before this tile is promoted past
planned. Three questions that would settle it:

1. Is tokenization applied when data lands in AEDL/COC, so every consumer inherits it?
2. If so, which columns, and does any analysis in this application depend on a
   detokenized value to work?
3. If not, what is the control that keeps PHI out of an LLM prompt today?

Question 3 is the one that matters most here, because every agent in this application
sends its working context to a model. See [LLMs](/architecture/e/ts_llms) for what that
path looks like.

## Key decisions

- No decision has been recorded, which is itself the finding. This tile is deliberately
  left visibly incomplete rather than described as covered.

## Gotchas

- Do not read the presence of this tile on the slide as evidence that tokenization is in
  place for Deep Research. Nothing in the code substantiates that either way.
