"""
Decision Tree Rule Engine for CoC AI Analyst.

This module loads and manages decision tree rules from YAML configuration,
providing rule lookup and formatting for LLM-based recommendation generation.
"""

import yaml
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging

try:
    from deep_research_utils.logger_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    logger = logging.getLogger(__name__)


class DecisionTreeRuleEngine:
    """
    Load and manage decision tree rules from YAML configuration.
    
    This engine loads rules from a YAML file and provides methods to retrieve
    and format rules for use in LLM-based recommendation generation.
    
    Args:
        yaml_path: Path to YAML configuration file
        
    Example:
        >>> engine = DecisionTreeRuleEngine("configs/decision_tree_rules.yaml")
        >>> rules = engine.get_rules_by_category("IP MedSurg (DNE)")
        >>> formatted = engine.format_rules_for_llm()
    """
    
    def __init__(self, yaml_path: str):
        """
        Initialize rule engine from YAML file.
        
        Args:
            yaml_path: Path to YAML configuration file
        """
        self.yaml_path = Path(yaml_path)
        self.rules = self._load_rules_from_yaml()
        rule_count = self.get_total_rule_count()
        category_count = len(self.rules)
        logger.info(f"Loaded {rule_count} rules from {category_count} categories")
    
    def _load_rules_from_yaml(self) -> Dict[str, Dict[int, Dict[str, Any]]]:
        """
        Parse YAML file into nested structured format.
        
        Returns:
            Dictionary mapping category names to nested trend rules:

        """
        if not self.yaml_path.exists():
            logger.warning(f"Decision tree YAML not found: {self.yaml_path}")
            return {}
        
        try:
            with open(self.yaml_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            if not isinstance(data, dict):
                logger.error("Invalid YAML format: root element is not a dictionary")
                return {}
            
            service_categories = data.get('service_categories', {})
            
            if not isinstance(service_categories, dict):
                logger.error("Invalid YAML format: service_categories is not a dictionary")
                return {}
            
            # Convert new nested format to internal structure
            nested_rules = {}
            
            for category_name, trends_dict in service_categories.items():
                if not isinstance(trends_dict, dict):
                    logger.warning(f"Skipping category {category_name}: not a dictionary")
                    continue
                
                nested_rules[category_name] = {}
                
                for trend_key, trend_data in trends_dict.items():
                    if not isinstance(trend_data, dict):
                        continue
                    
                    trend_id = trend_data.get('trend_id')
                    if not trend_id:
                        logger.warning(f"Skipping trend {trend_key} in {category_name}: missing trend_id")
                        continue
                    
                    # Extract parent rule data
                    parent_rule = {
                        'trend_id': trend_id,
                        'research_considerations': trend_data.get('research_considerations'),
                        'why': trend_data.get('why'),
                        'flags': trend_data.get('flags', {}),
                        'cost_of_care_suggestions': trend_data.get('cost_of_care_suggestions'),
                        'coding_accuracy_suggestions': trend_data.get('coding_accuracy_suggestions')
                    }
                    
                    # Extract subrules
                    subrules = []
                    sub_rules_list = trend_data.get('sub_rules', [])
                    
                    if isinstance(sub_rules_list, list):
                        for subrule_data in sub_rules_list:
                            if not isinstance(subrule_data, dict):
                                continue
                            
                            # Generate unique trend_id for subrule: parent_id * 100 + sub_rule_id
                            sub_rule_id = subrule_data.get('sub_rule_id')
                            if sub_rule_id:
                                subrule_trend_id = trend_id * 100 + sub_rule_id
                            else:
                                continue
                            
                            subrule = {
                                'trend_id': subrule_trend_id,
                                'parent_trend_id': trend_id,
                                'sub_rule_id': sub_rule_id,
                                'research_considerations': subrule_data.get('research_considerations'),
                                'why': subrule_data.get('why'),
                                'flags': subrule_data.get('flags', {}),
                                'cost_of_care_suggestions': subrule_data.get('cost_of_care_suggestions'),
                                'coding_accuracy_suggestions': subrule_data.get('coding_accuracy_suggestions')
                            }
                            subrules.append(subrule)
                    
                    nested_rules[category_name][trend_id] = {
                        'parent': parent_rule,
                        'subrules': subrules
                    }
            
            logger.debug(f"Loaded {len(nested_rules)} service categories")
            return nested_rules
            
        except yaml.YAMLError as e:
            logger.error(f"Failed to parse YAML file: {e}")
            return {}
        except Exception as e:
            logger.error(f"Failed to load decision tree YAML: {e}")
            return {}
    
    def get_rules_by_category(self, category: str) -> Dict[int, Dict[str, Any]]:
        """
        Retrieve nested rules for specific service category.
        
        Args:
            category: Service category name (e.g., "IP MedSurg (DNE)")
            
        Returns:
            Dictionary of nested rules for the category, or empty dict if not found
        """
        return self.rules.get(category, {})
    
    def get_all_rules(self) -> Dict[str, Dict[int, Dict[str, Any]]]:
        """
        Return all rules across all categories.
        
        Returns:
            Dictionary mapping category names to nested rules
        """
        return self.rules
    
    def get_total_rule_count(self) -> int:
        """
        Count total number of rules (parent + subrules) across all categories.
        
        Returns:
            Total number of rules
        """
        total = 0
        for category_trends in self.rules.values():
            for trend_data in category_trends.values():
                total += 1  # Parent rule
                total += len(trend_data.get('subrules', []))  # Subrules
        return total
    
    def get_category_names(self) -> List[str]:
        """
        Get list of all service category names.
        
        Returns:
            List of category names
        """
        return list(self.rules.keys())
    
    def get_nested_rules_by_categories(
        self,
        categories: List[str]
    ) -> Dict[str, Dict[int, Dict[str, Any]]]:
        """
        Get rules organized by parent trend_id with nested subrules.
        
        Args:
            categories: List of HCC category names to retrieve
            
        Returns:
            Dictionary structure:
            {
                "HCC Category Name": {
                    trend_id_1: {
                        "parent": {...parent trend_category rule...},
                        "subrules": [{...detailed_rule 1...}, {...detailed_rule 2...}]
                    },
                    trend_id_2: {...}
                }
            }
        """
        nested_structure = {}
        
        for category in categories:
            if category not in self.rules:
                continue
            
            # Rules are already in nested format, just filter by category
            nested_structure[category] = self.rules[category]
        
        return nested_structure
    
    def get_rules_by_trend_ids(
        self,
        trend_ids: List[int],
        categories: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        Get rules by their trend_ids, optionally filtered by categories.
        
        Args:
            trend_ids: List of trend IDs to fetch (includes both parent and subrule IDs)
            categories: Optional list of categories to search in. If None, searches all.
            
        Returns:
            List of matched rules with _category tag added
        """
        matched_rules = []
        
        categories_to_search = categories if categories else self.get_category_names()
        
        for category in categories_to_search:
            if category not in self.rules:
                continue
            
            category_trends = self.rules[category]
            
            for trend_data in category_trends.values():
                parent = trend_data.get('parent', {})
                subrules = trend_data.get('subrules', [])
                
                # Check if parent trend_id matches
                if parent.get('trend_id') in trend_ids:
                    parent_copy = parent.copy()
                    parent_copy['_category'] = category
                    matched_rules.append(parent_copy)
                
                # Check if any subrule trend_id matches
                for subrule in subrules:
                    if subrule.get('trend_id') in trend_ids:
                        subrule_copy = subrule.copy()
                        subrule_copy['_category'] = category
                        matched_rules.append(subrule_copy)
        
        return matched_rules
    
    def get_all_rules_for_categories(
        self,
        categories: List[str],
        max_per_category: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get all rules (parent + subrules) from specific categories as a flat list.
        
        Args:
            categories: List of category names to fetch
            max_per_category: Optional maximum parent trends per category
            
        Returns:
            Flat list of rules with _category tag added
        """
        all_rules = []
        
        for category in categories:
            if category not in self.rules:
                continue
            
            category_trends = self.rules[category]
            trends_list = list(category_trends.values())
            
            if max_per_category:
                trends_list = trends_list[:max_per_category]
            
            for trend_data in trends_list:
                parent = trend_data.get('parent', {})
                subrules = trend_data.get('subrules', [])
                
                # Add parent rule
                if parent:
                    parent_copy = parent.copy()
                    parent_copy['_category'] = category
                    all_rules.append(parent_copy)
                
                # Add all subrules
                for subrule in subrules:
                    subrule_copy = subrule.copy()
                    subrule_copy['_category'] = category
                    all_rules.append(subrule_copy)
        
        return all_rules
    
    def format_rules_for_llm(self, categories: Optional[List[str]] = None) -> str:
        """
        Convert rules to LLM-friendly text format.
        
        Args:
            categories: Optional list of specific categories to format.
                       If None, formats all categories.
        
        Returns:
            Formatted text representation of rules
        """
        if categories:
            rules_to_format = {cat: self.rules.get(cat, {}) for cat in categories if cat in self.rules}
        else:
            rules_to_format = self.rules
        
        if not rules_to_format:
            return "No decision tree rules available."
        
        formatted = []
        formatted.append("DECISION TREE RULES BY SERVICE CATEGORY:")
        formatted.append("=" * 80)
        
        for category, category_trends in rules_to_format.items():
            formatted.append(f"\n### {category}")
            formatted.append("-" * 80)
            
            for trend_id, trend_data in category_trends.items():
                parent = trend_data.get('parent', {})
                subrules = trend_data.get('subrules', [])
                
                # Format parent rule
                formatted.append(f"\n[PARENT TREND {trend_id}]")
                
                research = parent.get('research_considerations')
                if research:
                    formatted.append(f"  Research: {research}")
                
                why = parent.get('why')
                if why:
                    formatted.append(f"  Why: {why}")
                
                suggestions = parent.get('cost_of_care_suggestions')
                if suggestions:
                    formatted.append(f"  Suggestion: {suggestions}")
                
                flags = parent.get('flags', {})
                if isinstance(flags, dict):
                    flag_list = []
                    if flags.get('clinical'):
                        flag_list.append('Clinical')
                    if flags.get('network'):
                        flag_list.append('Network')
                    if flags.get('ops'):
                        flag_list.append('Ops')
                    if flag_list:
                        formatted.append(f"  Flags: {', '.join(flag_list)}")
                
                # Format subrules
                if subrules:
                    formatted.append(f"\n  SUBRULES ({len(subrules)}):")
                    for subrule in subrules:
                        sub_id = subrule.get('sub_rule_id', 'N/A')
                        formatted.append(f"\n    [SUBRULE {sub_id}]")
                        
                        sub_research = subrule.get('research_considerations')
                        if sub_research:
                            formatted.append(f"      Research: {sub_research}")
                        
                        sub_why = subrule.get('why')
                        if sub_why:
                            formatted.append(f"      Why: {sub_why}")
                        
                        sub_suggestions = subrule.get('cost_of_care_suggestions')
                        if sub_suggestions:
                            formatted.append(f"      Suggestion: {sub_suggestions}")
                        
                        sub_flags = subrule.get('flags', {})
                        if isinstance(sub_flags, dict):
                            sub_flag_list = []
                            if sub_flags.get('clinical'):
                                sub_flag_list.append('Clinical')
                            if sub_flags.get('network'):
                                sub_flag_list.append('Network')
                            if sub_flags.get('ops'):
                                sub_flag_list.append('Ops')
                            if sub_flag_list:
                                formatted.append(f"      Flags: {', '.join(sub_flag_list)}")
        
        formatted.append("\n" + "=" * 80)
        return "\n".join(formatted)
    
    def format_rules_compact(self, categories: Optional[List[str]] = None) -> str:
        """
        Convert rules to compact LLM-friendly format (shorter version).
        
        Args:
            categories: Optional list of specific categories to format.
                       If None, formats all categories.
        
        Returns:
            Compact formatted text representation of rules
        """
        if categories:
            rules_to_format = {cat: self.rules.get(cat, {}) for cat in categories if cat in self.rules}
        else:
            rules_to_format = self.rules
        
        if not rules_to_format:
            return "No decision tree rules available."
        
        formatted = []
        
        for category, category_trends in rules_to_format.items():
            formatted.append(f"\n{category}:")
            
            for trend_id, trend_data in category_trends.items():
                parent = trend_data.get('parent', {})
                subrules = trend_data.get('subrules', [])
                
                # Include parent if it has suggestions
                parent_suggestions = parent.get('cost_of_care_suggestions')
                if parent_suggestions:
                    line_parts = []
                    research = parent.get('research_considerations')
                    why = parent.get('why')
                    if research:
                        line_parts.append(f"RESEARCH: {research}")
                    if why:
                        line_parts.append(f"WHY: {why}")
                    line_parts.append(f"SUGGESTION: {parent_suggestions}")
                    formatted.append(f"  - [Trend {trend_id}] {' | '.join(line_parts)}")
                
                # Include subrules with suggestions
                for subrule in subrules:
                    suggestions = subrule.get('cost_of_care_suggestions')
                    if suggestions:
                        line_parts = []
                        research = subrule.get('research_considerations')
                        why = subrule.get('why')
                        if research:
                            line_parts.append(f"RESEARCH: {research}")
                        if why:
                            line_parts.append(f"WHY: {why}")
                        line_parts.append(f"SUGGESTION: {suggestions}")
                        sub_id = subrule.get('sub_rule_id', 'N/A')
                        formatted.append(f"    - [Subrule {sub_id}] {' | '.join(line_parts)}")
        
        return "\n".join(formatted)


if __name__ == "__main__":
    # Test the rule engine
    import sys
    from pathlib import Path
    
    # Try to load from default location
    yaml_path = Path(__file__).resolve().parents[4] / "configs" / "decision_tree_rules.yaml"
    
    if not yaml_path.exists():
        print(f"YAML file not found: {yaml_path}")
        sys.exit(1)
    
    print(f"Loading rules from: {yaml_path}")
    engine = DecisionTreeRuleEngine(str(yaml_path))
    
    print(f"\nTotal rules: {engine.get_total_rule_count()}")
    print(f"Categories: {len(engine.get_category_names())}")
    print(f"\nCategory names:")
    for cat in engine.get_category_names():
        rule_count = len(engine.get_rules_by_category(cat))
        print(f"  - {cat}: {rule_count} rules")
    
    print("\n" + "=" * 80)
    print("Sample formatted output (first category):")
    print("=" * 80)
    first_category = engine.get_category_names()[0] if engine.get_category_names() else None
    if first_category:
        print(engine.format_rules_for_llm(categories=[first_category]))
