"""
Recommendation DTR Agent with LLM-Based Relevance Determination

This agent generates policy recommendations from combined pattern+reimbursement data
with strict business decision tree rule (DTR) alignment. Unlike keyword-based matching,
this agent uses the LLM itself to determine pattern relevance to DTR rules.

Key Features:
- LLM determines if each pattern is relevant to any DTR rules
- LLM identifies which specific rules or categories apply
- Only generates recommendations when LLM confirms relevance
- Disregards patterns that LLM deems irrelevant to DTR scope
- Processes patterns individually (not in batch)

Workflow:
1. Load business decision tree rules from YAML
2. For each pattern:
   a. LLM evaluates relevance to DTR rules
   b. If relevant: LLM identifies applicable rules
   c. Generate recommendation using identified rules
   d. If not relevant: skip pattern
3. Export recommendations with processing log

Usage:
    >>> from deep_research_agents import RecommendationDTRAgent
    >>> 
    >>> agent = RecommendationDTRAgent()
    >>> 
    >>> # DTR rules path auto-configured from AppConstants
    >>> results = agent(patterns_data=combined_patterns)
    >>> 
    >>> print(f"Generated {len(results['recommendations'])} recommendations")
    >>> print(f"Skipped {len(results['skipped_patterns'])} patterns")
    >>> 
    >>> # Optional: Override DTR rules path if needed
    >>> results = agent(
    ...     patterns_data=combined_patterns,
    ...     dtr_rules_path="custom/path/rules.yaml"
    ... )
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional, TypedDict

from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field

from deep_research_core.base_agent import AgentBase
from deep_research_agents.decision_tree_rules import DecisionTreeRuleEngine
from deep_research_utils.app_constant import AppConstants
from deep_research_utils.ehap_retry import structured_llm_invoke_with_tokens

try:
    from deep_research_utils.logger_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    logger = logging.getLogger(__name__)


class RecommendationDTRState(TypedDict, total=False):
    """State for DTR-based recommendation agent."""
    
    patterns_data: List[Dict[str, Any]]
    dtr_rules_path: str
    dtr_rule_engine: Any
    
    all_recommendations: List[Dict[str, Any]]
    skipped_patterns: List[Dict[str, Any]]
    processing_log: List[Dict[str, Any]]
    
    llm: Any
    require_llm_relevance: bool
    debug_mode: bool
    
    # Token tracking
    start_time: str  # ISO timestamp
    token_breakdown_per_pattern: Dict[str, Dict[str, Dict[str, int]]]  # Per-pattern detailed
    token_breakdown_aggregated: Dict[str, Dict[str, int]]  # Aggregated by operation


class ParentRuleIdentification(BaseModel):
    """Schema for a single parent rule identification."""
    hcc_category: str
    trend_id: int
    relevance_reason: str


class ParentRulesIdentificationSchema(BaseModel):
    """Schema for LLM parent rule identification from pattern data."""
    relevant_parent_rules: List[ParentRuleIdentification] = Field(default_factory=list)
    overall_reasoning: str = ""


class SubruleIdentification(BaseModel):
    """Schema for subrule identification for a parent rule."""
    parent_trend_id: int
    relevant_subrule_ids: List[int] = Field(default_factory=list)
    reasoning: str = ""


class SubrulesIdentificationSchema(BaseModel):
    """Schema for LLM subrule identification."""
    subrule_identifications: List[SubruleIdentification] = Field(default_factory=list)


class RecommendationItemSchema(BaseModel):
    """Schema for a single recommendation."""
    rank: int
    priority: str
    category: str
    description: str
    evidence: List[str] = Field(default_factory=list)
    story_alignment: List[str] = Field(default_factory=list)
    peer_benchmarking: List[str] = Field(default_factory=list)
    citation: List[str] = Field(default_factory=list)


class RecommendationResponseSchema(BaseModel):
    """Schema for LLM recommendation generation response."""
    recommendations: List[RecommendationItemSchema] = Field(default_factory=list)


# ============================================================================
# PROMPTS FOR LLM-BASED PARENT RULE AND SUBRULE IDENTIFICATION
# ============================================================================

PARENT_RULE_IDENTIFICATION_SYSTEM_PROMPT = """You are an expert healthcare analyst that identifies relevant parent trend rules from business decision tree rules.

Your task:
1. Analyze the entire pattern data
2. Review all parent trend rules across HCC categories
3. Identify which parent trend rules are most relevant to this pattern
4. Return up to 5 most relevant parent rules with their HCC category and trend_id

Output MUST be valid JSON only.
"""

PARENT_RULE_IDENTIFICATION_USER_PROMPT = """Identify the most relevant parent trend rules for this healthcare pattern.

PATTERN DATA (complete):
{pattern_json}

PARENT TREND RULES BY HCC CATEGORY:
{parent_rules_formatted}

INSTRUCTIONS:
1. Analyze the entire pattern including what_is_impacting, pattern_type, impact_summary, and pattern_details
2. Review all parent trend rules shown above
3. Identify which parent trend rules are most relevant to this pattern (up to 5)
4. For each relevant parent rule, provide the HCC category, trend_id, and brief relevance reason

OUTPUT SCHEMA:
{{
  "relevant_parent_rules": [
    {{
      "hcc_category": "<HCC category name>",
      "trend_id": <trend_id integer>,
      "relevance_reason": "<brief explanation>"
    }}
  ],
  "overall_reasoning": "<overall explanation of selections>"
}}

Return ONLY valid JSON.
"""

SUBRULE_IDENTIFICATION_SYSTEM_PROMPT = """You are an expert healthcare analyst that identifies relevant detailed subrules for parent trend rules.

Your task:
1. For each parent trend rule provided, review its detailed subrules
2. Identify which subrules are most relevant to the pattern
3. Return the relevant subrule trend_ids for each parent

Output MUST be valid JSON only.
"""

SUBRULE_IDENTIFICATION_USER_PROMPT = """Identify relevant subrules for the parent trend rules.

PATTERN DATA (complete):
{pattern_json}

PARENT RULES WITH THEIR SUBRULES:
{parent_rules_with_subrules}

INSTRUCTIONS:
1. For each parent trend rule shown above, review its detailed subrules
2. Identify which subrules are most relevant to the pattern
3. Return the trend_ids of relevant subrules for each parent

OUTPUT SCHEMA:
{{
  "subrule_identifications": [
    {{
      "parent_trend_id": <parent trend_id>,
      "relevant_subrule_ids": [<subrule trend_id 1>, <subrule trend_id 2>, ...],
      "reasoning": "<brief explanation>"
    }}
  ]
}}

Return ONLY valid JSON.
"""

RECOMMENDATION_SYSTEM_PROMPT = """You are an expert healthcare policy analyst that generates recommendations STRICTLY based on business decision tree rules.

CRITICAL RULES:
1. You MUST use ONLY the business decision tree rules provided
2. If the provided rules don't match the pattern, return an empty recommendations array
3. DO NOT make up or infer rules that weren't provided
4. DO NOT create recommendations without explicit rule support
5. Use ONLY information from the input pattern and reimbursement data
6. The relevance of these rules has been pre-determined by LLM analysis

Your output MUST be valid JSON only, no markdown or explanatory text.
"""

RECOMMENDATION_USER_PROMPT = """Generate a policy recommendation for this healthcare pattern using the LLM-identified relevant business rules.

PATTERN DATA:
{pattern_json}

LLM-IDENTIFIED RELEVANT BUSINESS RULES:
{matched_rules}

RELEVANCE ASSESSMENT:
The LLM has determined these rules are relevant because: {relevance_reason}

INSTRUCTIONS:
1. Review the pattern data and LLM-identified relevant rules
2. Create ONE recommendation based on these rules
3. The recommendation MUST:
   - Be a specific action (not a summary of pattern data)
   - Come from hints in the business decision tree rules
   - Use actual data from the pattern (amounts, codes, names)
   - Extract evidence directly from pattern data
   - Include policy URLs from reimbursement data if available
   - Do not repeat numbers, statistics and details from pattern data, should only consist of a recommendation
   - Do not try to explain the recommendation

OUTPUT SCHEMA:
{{
  "recommendations": [
    {{
      "rank": <pattern_rank>,
      "priority": "HIGH|MEDIUM|LOW",
      "category": "Policy",
      "description": "<specific action with identifiers>",
      "evidence": ["<specific evidence from pattern data, max 15 words each>"],
      "story_alignment": ["Business Rule <Category> - <Research Consideration>: <how it applies to this pattern, max 30 words>"],
      "peer_benchmarking": ["<peer payor practice from reimbursement data, max 25 words>"],
      "citation": ["Policy: <PayerName> - <URL from reimbursement data>"]
    }}
  ]
}}

RETURN ONLY VALID JSON.
"""


class RecommendationDTRAgent(AgentBase):
    """
    Agent for generating recommendations with LLM-based DTR relevance determination.
    
    This agent processes patterns individually and uses the LLM to determine which
    patterns are relevant to business decision tree rules. Only relevant patterns
    result in recommendations.
    
    Args:
        **kwargs: Additional arguments passed to AgentBase
    """
    
    # Concurrency configuration by environment
    _CONCURRENCY_BY_ENV = {
        "local": 3,
        "dev": 4,
        "uat": 5,
        "prod": 5,
        "local_offshore": 3
    }
    
    # Retry configuration
    _RETRY_DELAY = 2  # seconds
    _MAX_RETRIES = 1  # retry once
    
    def __init__(self, llm_timeout: Optional[float] = None, **kwargs):
        super().__init__(
            agent_name="recommendation_synthesis",
            state_class=RecommendationDTRState,
            llm_reasoning_effort="high",
            llm_summary_mode="auto",
            llm_timeout=llm_timeout,
            **kwargs
        )
    
    def build_graph(self) -> StateGraph:
        """
        Build simple 2-node graph for DTR-based recommendation pipeline.
        
        Returns:
            Configured StateGraph
        """
        graph = StateGraph(self.state_class)
        
        # Add nodes
        graph.add_node("load_rules", self.load_rules_node)
        graph.add_node("process_all_patterns", self.process_all_patterns_node)
        
        # Define flow
        graph.add_edge(START, "load_rules")
        graph.add_edge("load_rules", "process_all_patterns")
        graph.add_edge("process_all_patterns", END)
        
        return graph
    
    def load_rules_node(self, state: RecommendationDTRState) -> Dict[str, Any]:
        """
        Node 1: Load decision tree rules from YAML.
        
        Args:
            state: Current graph state
            
        Returns:
            Updated state with rule engine
        """
        dtr_rules_path = state["dtr_rules_path"]
        
        self.logger.info("[SETUP] Loading business decision tree rules")
        self.logger.debug(f"DTR rules path: {dtr_rules_path}")
        
        dtr_rule_engine = DecisionTreeRuleEngine(str(dtr_rules_path))
        
        rule_count = dtr_rule_engine.get_total_rule_count()
        category_count = len(dtr_rule_engine.get_category_names())
        
        self.logger.info(f"✓ Loaded {rule_count} rules from {category_count} categories")
        self.logger.debug(f"Categories: {', '.join(dtr_rule_engine.get_category_names())}")
        
        return {
            "dtr_rule_engine": dtr_rule_engine
        }
    
    def _process_single_pattern(
        self,
        pattern: Dict[str, Any],
        dtr_rule_engine: DecisionTreeRuleEngine,
        pattern_idx: int,
        total_patterns: int
    ) -> Optional[Dict[str, Any]]:
        """
        Process a single pattern: relevance check → fetch rules → generate recommendation.
        
        Args:
            pattern: Pattern data dictionary
            dtr_rule_engine: DecisionTreeRuleEngine instance
            pattern_idx: Zero-based index of pattern in list
            total_patterns: Total number of patterns being processed
            
        Returns:
            Dict with:
            - recommendation: The recommendation object (or None if skipped)
            - skip_info: Skip information if pattern was skipped
            - log_entry: Processing log entry for this pattern
            
            Returns None only on catastrophic failure (should not happen)
        """
        pattern_rank = pattern.get("pattern_rank", pattern_idx + 1)
        top_pattern = pattern.get("top_pattern", "Unknown")
        
        pattern_tokens = {
            "relevance": {"input": 0, "output": 0},
            "recommendation": {"input": 0, "output": 0}
        }
        
        self.logger.info(f"\n{'='*80}")
        self.logger.info(f"[Pattern {pattern_rank}] [{pattern_idx + 1}/{total_patterns}] {top_pattern[:60]}...")
        self.logger.info(f"{'='*80}")
        
        self.logger.info(f"[Pattern {pattern_rank}] [1/3] LLM checking relevance...")
        relevance_result, relevance_tokens = self._check_pattern_relevance(pattern, dtr_rule_engine)
        pattern_tokens["relevance"] = relevance_tokens
        
        is_relevant = relevance_result.get("is_relevant", False)
        relevance_reason = relevance_result.get("relevance_reason", "")
        applicable_categories = relevance_result.get("applicable_categories", [])
        applicable_rule_ids = relevance_result.get("applicable_rule_ids", [])
        
        self.logger.info(f"[Pattern {pattern_rank}]   Relevant: {is_relevant}")
        self.logger.debug(f"[Pattern {pattern_rank}]   Reason: {relevance_reason[:150]}..." if len(relevance_reason) > 150 else f"[Pattern {pattern_rank}]   Reason: {relevance_reason}")
        
        if not is_relevant:
            self.logger.info(f"[Pattern {pattern_rank}]   ⊗ Not relevant to DTR - skipping")
            return {
                "recommendation": None,
                "skip_info": {
                    "rank": pattern_rank,
                    "pattern": top_pattern,
                    "reason": f"LLM determined not relevant: {relevance_reason}"
                },
                "log_entry": {
                    "rank": pattern_rank,
                    "status": "skipped",
                    "reason": "llm_not_relevant",
                    "relevance_reason": relevance_reason
                },
                "tokens": pattern_tokens
            }
        
        self.logger.info(f"[Pattern {pattern_rank}] [2/3] Fetching relevant rules...")
        
        relevant_rules = dtr_rule_engine.get_rules_by_trend_ids(applicable_rule_ids, applicable_categories)
        
        if not relevant_rules and applicable_categories:
            relevant_rules = dtr_rule_engine.get_all_rules_for_categories(applicable_categories)
        
        if not relevant_rules:
            self.logger.warning(f"[Pattern {pattern_rank}]   ⚠️  Could not fetch rules")
            return {
                "recommendation": None,
                "skip_info": {
                    "rank": pattern_rank,
                    "pattern": top_pattern,
                    "reason": "Could not fetch relevant rules"
                },
                "log_entry": {
                    "rank": pattern_rank,
                    "status": "skipped",
                    "reason": "rules_fetch_failed"
                },
                "tokens": pattern_tokens
            }
        
        self.logger.info(f"[Pattern {pattern_rank}]   ✓ Fetched {len(relevant_rules)} rules")
        
        # Step 3: Generate recommendation using LLM-identified rules - NOW RETURNS TOKENS
        self.logger.info(f"[Pattern {pattern_rank}] [3/3] Generating recommendation...")
        recommendation, rec_tokens = self._generate_recommendation(
            pattern,
            relevant_rules,
            relevance_reason
        )
        pattern_tokens["recommendation"] = rec_tokens
        
        if recommendation:
            self.logger.info(f"[Pattern {pattern_rank}]   ✓ Recommendation generated")
            self.logger.debug(f"[Pattern {pattern_rank}]     Priority: {recommendation.get('priority', 'N/A')}")
            desc = recommendation.get('description') or ''
            self.logger.debug(f"[Pattern {pattern_rank}]     Description: {desc[:80]}...")
            
            return {
                "recommendation": recommendation,
                "skip_info": None,
                "log_entry": {
                    "rank": pattern_rank,
                    "status": "success",
                    "rules_used": len(relevant_rules),
                    "categories": applicable_categories,
                    "relevance_reason": relevance_reason
                },
                "tokens": pattern_tokens
            }
        else:
            self.logger.warning(f"[Pattern {pattern_rank}]   ⚠️  No recommendation generated")
            return {
                "recommendation": None,
                "skip_info": {
                    "rank": pattern_rank,
                    "pattern": top_pattern,
                    "reason": "Failed to generate recommendation"
                },
                "log_entry": {
                    "rank": pattern_rank,
                    "status": "skipped",
                    "reason": "generation_failed",
                    "rules_available": len(relevant_rules)
                },
                "tokens": pattern_tokens
            }
    
    def process_all_patterns_node(self, state: RecommendationDTRState) -> Dict[str, Any]:
        """
        Node 2: Process all patterns using parallel execution.
        
        Uses ThreadPoolExecutor to process multiple patterns simultaneously.
        Each pattern runs its full workflow (relevance → rules → recommendation)
        in a separate thread. Results are collected and reassembled in original
        pattern_rank order.
        
        Args:
            state: Current graph state
            
        Returns:
            Updated state with all recommendations and processing log
        """
        patterns_data = state["patterns_data"]
        dtr_rule_engine = state["dtr_rule_engine"]
        
        total_patterns = len(patterns_data)
        concurrency = self._resolve_concurrency()
        
        self.logger.info(f"\n{'='*80}")
        self.logger.info("PROCESSING PATTERNS WITH PARALLEL LLM-BASED DTR RELEVANCE")
        self.logger.info(f"Total patterns: {total_patterns}")
        self.logger.info(f"Concurrency: {concurrency} workers")
        self.logger.info(f"{'='*80}")
        
        by_index: Dict[int, Optional[Dict[str, Any]]] = {}
        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            futures = {
                pool.submit(self._process_single_pattern, pattern, dtr_rule_engine, i, total_patterns): i
                for i, pattern in enumerate(patterns_data)
            }
            for fut in as_completed(futures):
                i = futures[fut]
                try:
                    by_index[i] = fut.result()
                except Exception as e:
                    self.logger.error(f"Pattern {i+1} failed: {e}")
                    by_index[i] = None
        
        # Reassemble results in original order
        results = [by_index.get(i) for i in range(total_patterns)]
        
        # Extract recommendations, skipped patterns, logs, and tokens
        all_recommendations = []
        skipped_patterns = []
        processing_log = []
        
        # Initialize token tracking structures
        token_breakdown_per_pattern = {}
        token_breakdown_aggregated = {
            "relevance_checks": {"input": 0, "output": 0, "calls": 0},
            "recommendations": {"input": 0, "output": 0, "calls": 0}
        }
        
        for result in results:
            if result is None:
                continue
            
            if result["recommendation"]:
                all_recommendations.append(result["recommendation"])
            
            if result["skip_info"]:
                skipped_patterns.append(result["skip_info"])
            
            processing_log.append(result["log_entry"])
            
            # Extract and aggregate tokens
            if "tokens" in result:
                pattern_rank = result["log_entry"]["rank"]
                pattern_key = f"pattern_{pattern_rank}"
                
                # Store per-pattern breakdown
                token_breakdown_per_pattern[pattern_key] = result["tokens"]
                
                # Aggregate by operation type
                rel_tokens = result["tokens"]["relevance"]
                token_breakdown_aggregated["relevance_checks"]["input"] += rel_tokens["input"]
                token_breakdown_aggregated["relevance_checks"]["output"] += rel_tokens["output"]
                token_breakdown_aggregated["relevance_checks"]["calls"] += 1
                
                rec_tokens = result["tokens"]["recommendation"]
                token_breakdown_aggregated["recommendations"]["input"] += rec_tokens["input"]
                token_breakdown_aggregated["recommendations"]["output"] += rec_tokens["output"]
                if result["recommendation"]:  # Only count successful recommendations
                    token_breakdown_aggregated["recommendations"]["calls"] += 1
        
        # Summary logging
        successful = len(all_recommendations)
        skipped = len(skipped_patterns)
        self.logger.info(f"\n{'='*80}")
        self.logger.info("PATTERN PROCESSING COMPLETE")
        self.logger.info(f"Total patterns: {total_patterns}")
        self.logger.info(f"Successful: {successful}")
        self.logger.info(f"Skipped: {skipped}")
        self.logger.info(f"{'='*80}")
        
        return {
            "all_recommendations": all_recommendations,
            "skipped_patterns": skipped_patterns,
            "processing_log": processing_log,
            "token_breakdown_per_pattern": token_breakdown_per_pattern,
            "token_breakdown_aggregated": token_breakdown_aggregated
        }
    
    @classmethod
    def _resolve_concurrency(cls) -> int:
        """
        Read RECOMMENDATION_CONCURRENCY env var if set, else fall
        back to the per-env default keyed off AppConstants.ENV.
        Always returns >= 1 for ThreadPoolExecutor.
        
        Returns:
            Number of worker threads for parallel pattern processing
        """        
        override = os.environ.get("RECOMMENDATION_CONCURRENCY")
        if override:
            try:
                return max(1, min(5, int(override)))
            except ValueError:
                pass
        return cls._CONCURRENCY_BY_ENV.get(AppConstants.ENV, 3)
    
    def _extract_token_usage(self, response: Any) -> Dict[str, int]:
        """
        Extract input/output token counts from LLM response.
        
        Handles both new-style (usage_metadata) and legacy (response_metadata)
        token usage formats.
        
        Args:
            response: LangChain LLM response object
            
        Returns:
            Dict with 'input' and 'output' token counts
        """
        # Handle None response
        if response is None:
            return {"input": 0, "output": 0}
        
        # Check new-style usage_metadata
        usage = getattr(response, "usage_metadata", None)
        if usage and isinstance(usage, dict):
            return {
                "input": int(usage.get("input_tokens") or 0),
                "output": int(usage.get("output_tokens") or 0),
            }
        
        # Check legacy response_metadata.token_usage
        response_metadata = getattr(response, "response_metadata", None) or {}
        token_usage = response_metadata.get("token_usage") or {} if isinstance(response_metadata, dict) else {}
        return {
            "input": int(token_usage.get("prompt_tokens") or 0),
            "output": int(token_usage.get("completion_tokens") or 0),
        }
    
    # ========================================================================
    # HELPER METHODS - LLM-BASED TWO-STEP RELEVANCE
    # ========================================================================
    
    def _identify_parent_rules_with_llm(
        self,
        pattern: Dict[str, Any],
        nested_rules: Dict[str, Dict[int, Dict[str, Any]]]
    ) -> tuple[List[Dict[str, Any]], Dict[str, int]]:
        """
        STEP 1: Use LLM to identify relevant parent trend rules from all HCC categories.
        
        Args:
            pattern: Complete pattern data
            nested_rules: All nested rules from all HCC categories
            
        Returns:
            Tuple of (list of parent rule dicts with hcc_category and trend_id, token_usage dict)
        """
        pattern_json = json.dumps(pattern, indent=2, ensure_ascii=False)
        parent_rules_formatted = self._format_parent_rules_complete(nested_rules)
        
        user_prompt = PARENT_RULE_IDENTIFICATION_USER_PROMPT.format(
            pattern_json=pattern_json,
            parent_rules_formatted=parent_rules_formatted
        )
        
        messages = [
            {"role": "system", "content": PARENT_RULE_IDENTIFICATION_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
        
        try:
            result_schema, _, raw_response = structured_llm_invoke_with_tokens(
                llm=self.llm,
                ehap=self.ehap,
                messages=messages,
                schema=ParentRulesIdentificationSchema,
                llm_reinitializer=self._initialize_llm,
                timeout=self.llm_timeout,
            )
            
            tokens = self._extract_token_usage(raw_response)
            
            parent_rules = [
                {
                    "hcc_category": pr.hcc_category,
                    "trend_id": pr.trend_id,
                    "relevance_reason": pr.relevance_reason
                }
                for pr in result_schema.relevant_parent_rules
            ]
            
            self.logger.info(f"  LLM identified {len(parent_rules)} relevant parent rules")
            for pr in parent_rules:
                self.logger.info(f"    - [{pr['hcc_category']}] Trend {pr['trend_id']}: {pr['relevance_reason'][:80]}...")  # pyright: ignore[reportIndexIssue]
            
            return parent_rules, tokens
        
        except Exception as e:
            self.logger.error(f"  ❌ LLM parent rule identification failed: {e}")
            return [], {"input": 0, "output": 0}
    
    def _identify_subrules_with_llm(
        self,
        pattern: Dict[str, Any],
        nested_rules: Dict[str, Dict[int, Dict[str, Any]]],
        parent_rules: List[Dict[str, Any]]
    ) -> tuple[Dict[int, List[int]], Dict[str, int]]:
        """
        STEP 2: Use LLM to identify relevant subrules for each parent trend rule.
        
        Args:
            pattern: Complete pattern data
            nested_rules: All nested rules
            parent_rules: List of parent rule dicts with hcc_category and trend_id from Step 1
            
        Returns:
            Tuple of (dict mapping parent_trend_id to list of subrule_trend_ids, token_usage dict)
        """
        if not parent_rules:
            return {}, {"input": 0, "output": 0}
        
        pattern_json = json.dumps(pattern, indent=2, ensure_ascii=False)
        parent_rules_with_subrules = self._format_parent_rules_with_subrules_complete(
            nested_rules, 
            parent_rules
        )
        
        user_prompt = SUBRULE_IDENTIFICATION_USER_PROMPT.format(
            pattern_json=pattern_json,
            parent_rules_with_subrules=parent_rules_with_subrules
        )
        
        messages = [
            {"role": "system", "content": SUBRULE_IDENTIFICATION_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
        
        try:
            result_schema, _, raw_response = structured_llm_invoke_with_tokens(
                llm=self.llm,
                ehap=self.ehap,
                messages=messages,
                schema=SubrulesIdentificationSchema,
                llm_reinitializer=self._initialize_llm,
                timeout=self.llm_timeout,
            )
            
            tokens = self._extract_token_usage(raw_response)
            
            subrule_map = {}
            for sub_id in result_schema.subrule_identifications:
                subrule_map[sub_id.parent_trend_id] = sub_id.relevant_subrule_ids
                self.logger.info(f"  Parent {sub_id.parent_trend_id}: {len(sub_id.relevant_subrule_ids)} relevant subrules")
                self.logger.debug(f"    Reasoning: {sub_id.reasoning}")
            
            return subrule_map, tokens
        
        except Exception as e:
            self.logger.error(f"  ❌ LLM subrule identification failed: {e}")
            return {}, {"input": 0, "output": 0}
    
    def _check_pattern_relevance(
        self,
        pattern: Dict[str, Any],
        dtr_rule_engine: DecisionTreeRuleEngine
    ) -> tuple[Dict[str, Any], Dict[str, int]]:
        """
        Use two-step LLM approach to determine if pattern is relevant to DTR rules.
        
        Step 1: LLM identifies relevant parent trend rules from all HCC categories
        Step 2: LLM identifies relevant subrules for each parent rule
        
        Args:
            pattern: Pattern data
            dtr_rule_engine: DecisionTreeRuleEngine instance
            
        Returns:
            Tuple of (relevance_result, combined_token_usage)
        """
        all_hcc_categories = dtr_rule_engine.get_category_names()
        all_nested_rules = dtr_rule_engine.get_nested_rules_by_categories(all_hcc_categories)
        
        if not all_nested_rules:
            self.logger.warning("  No rules found in DTR engine")
            return {
                "is_relevant": False,
                "relevance_reason": "No rules available in DTR engine",
                "applicable_categories": [],
                "applicable_rule_ids": []
            }, {"input": 0, "output": 0}
        
        total_parent_rules = sum(len(trends) for trends in all_nested_rules.values())
        self.logger.info(f"  Step 1: LLM identifying relevant parent rules from {total_parent_rules} total parent rules...")
        
        parent_rules, parent_tokens = self._identify_parent_rules_with_llm(pattern, all_nested_rules)
        
        if not parent_rules:
            self.logger.warning("  No relevant parent rules identified by LLM")
            return {
                "is_relevant": False,
                "relevance_reason": "LLM could not identify any relevant parent trend rules",
                "applicable_categories": [],
                "applicable_rule_ids": []
            }, parent_tokens
        
        parent_trend_ids = [pr["trend_id"] for pr in parent_rules]
        applicable_categories = list(set(pr["hcc_category"] for pr in parent_rules))
        
        self.logger.info(f"  Step 2: LLM identifying relevant subrules for {len(parent_trend_ids)} parent rules...")
        
        subrule_map, subrule_tokens = self._identify_subrules_with_llm(
            pattern,
            all_nested_rules,
            parent_rules
        )
        
        combined_tokens = {
            "input": parent_tokens["input"] + subrule_tokens["input"],
            "output": parent_tokens["output"] + subrule_tokens["output"]
        }
        
        all_rule_ids = parent_trend_ids.copy()
        for subrule_ids in subrule_map.values():
            all_rule_ids.extend(subrule_ids)
        
        relevance_reasons = [f"{pr['hcc_category']} Trend {pr['trend_id']}: {pr['relevance_reason']}" for pr in parent_rules]
        combined_reason = "; ".join(relevance_reasons)
        
        result = {
            "is_relevant": True,
            "relevance_reason": combined_reason,
            "applicable_categories": applicable_categories,
            "applicable_rule_ids": all_rule_ids
        }
        
        self.logger.info(f"  ✓ Identified {len(parent_trend_ids)} parent rules + {len(all_rule_ids) - len(parent_trend_ids)} subrules")
        
        return result, combined_tokens
    
    def _generate_recommendation(
        self,
        pattern: Dict[str, Any],
        relevant_rules: List[Dict[str, Any]],
        relevance_reason: str
    ) -> tuple[Optional[Dict[str, Any]], Dict[str, int]]:
        """
        Generate recommendation using LLM-identified relevant rules.
        
        Args:
            pattern: Pattern data
            relevant_rules: Rules identified as relevant by LLM
            relevance_reason: LLM's explanation of relevance
            
        Returns:
            Tuple of (recommendation_dict, token_usage)
        """
        # Format pattern data
        pattern_json = json.dumps(pattern, indent=2, ensure_ascii=False)
        
        # Format matched rules
        rules_text = self._format_rules_for_prompt(relevant_rules)
        
        # Build prompt
        user_prompt = RECOMMENDATION_USER_PROMPT.format(
            pattern_json=pattern_json,
            matched_rules=rules_text,
            relevance_reason=relevance_reason
        )
        
        messages = [
            {"role": "system", "content": RECOMMENDATION_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
        
        # Invoke LLM with automatic token refresh and token tracking
        try:
            result_schema, _, raw_response = structured_llm_invoke_with_tokens(
                llm=self.llm,
                ehap=self.ehap,
                messages=messages,
                schema=RecommendationResponseSchema,
                llm_reinitializer=self._initialize_llm,
                timeout=self.llm_timeout,
            )
            
            # Extract tokens
            tokens = self._extract_token_usage(raw_response)
            
            if result_schema.recommendations:
                return result_schema.recommendations[0].model_dump(), tokens
            else:
                return None, tokens
        
        except Exception as e:
            self.logger.error(f"  ❌ LLM recommendation generation failed: {e}")
            return None, {"input": 0, "output": 0}
    
    def _format_parent_rules_complete(
        self,
        nested_rules: Dict[str, Dict[int, Dict[str, Any]]]
    ) -> str:
        """
        Format ALL parent trend rules without truncation for Step 1 LLM call.
        
        Args:
            nested_rules: Nested rules from get_nested_rules_by_categories
            
        Returns:
            Complete formatted text of all parent rules (no truncation)
        """
        if not nested_rules:
            return "No rules available."
        
        formatted = []
        
        for category, trends in nested_rules.items():
            formatted.append(f"\n### {category}")
            formatted.append("=" * 80)
            
            for trend_id, trend_data in trends.items():
                parent = trend_data.get("parent", {})
                
                formatted.append(f"\n[TREND {trend_id}]")
                
                why = parent.get("why") or ""
                if why:
                    formatted.append(f"  Why: {why}")
                
                research = parent.get("research_considerations") or ""
                if research:
                    formatted.append(f"  Research: {research}")
                
                suggestions = parent.get("cost_of_care_suggestions") or parent.get("coding_accuracy_suggestions") or ""
                if suggestions:
                    formatted.append(f"  Suggestion: {suggestions}")
                
                flags = parent.get("flags", {})
                if isinstance(flags, dict):
                    flag_list = []
                    if flags.get("clinical"):
                        flag_list.append("Clinical")
                    if flags.get("network"):
                        flag_list.append("Network")
                    if flags.get("ops"):
                        flag_list.append("Ops")
                    if flag_list:
                        formatted.append(f"  Flags: {', '.join(flag_list)}")
        
        return "\n".join(formatted)
    
    def _format_parent_rules_with_subrules_complete(
        self,
        nested_rules: Dict[str, Dict[int, Dict[str, Any]]],
        parent_rules: List[Dict[str, Any]]
    ) -> str:
        """
        Format specific parent rules with ALL their subrules (no truncation) for Step 2 LLM call.
        
        Args:
            nested_rules: Nested rules from get_nested_rules_by_categories
            parent_rules: List of parent rule dicts with hcc_category and trend_id to include
            
        Returns:
            Complete formatted text of parent rules with all subrules
        """
        if not nested_rules or not parent_rules:
            return "No rules available."
        
        # Create a set of (category, trend_id) tuples for efficient lookup
        parent_rule_keys = {(pr["hcc_category"], pr["trend_id"]) for pr in parent_rules}
        
        formatted = []
        
        for category, trends in nested_rules.items():
            for trend_id, trend_data in trends.items():
                if (category, trend_id) not in parent_rule_keys:
                    continue
                
                parent = trend_data.get("parent", {})
                subrules = trend_data.get("subrules", [])
                
                formatted.append(f"\n### {category} - PARENT TREND {trend_id}")
                formatted.append("=" * 80)
                
                why = parent.get("why") or ""
                if why:
                    formatted.append(f"Parent Why: {why}")
                
                suggestions = parent.get("cost_of_care_suggestions") or parent.get("coding_accuracy_suggestions") or ""
                if suggestions:
                    formatted.append(f"Parent Suggestion: {suggestions}")
                
                if subrules:
                    formatted.append(f"\nDETAILED SUBRULES ({len(subrules)} total):")
                    formatted.append("-" * 80)
                    
                    for subrule in subrules:
                        sub_trend_id = subrule.get("trend_id", "N/A")
                        formatted.append(f"\n  [SUBRULE {sub_trend_id}]")
                        
                        sub_why = subrule.get("why") or ""
                        if sub_why:
                            formatted.append(f"    Why: {sub_why}")
                        
                        sub_research = subrule.get("research_considerations") or ""
                        if sub_research:
                            formatted.append(f"    Research: {sub_research}")
                        
                        sub_suggestions = subrule.get("cost_of_care_suggestions") or subrule.get("coding_accuracy_suggestions") or ""
                        if sub_suggestions:
                            formatted.append(f"    Suggestion: {sub_suggestions}")
                else:
                    formatted.append("\n  (No detailed subrules)")
        
        return "\n".join(formatted)
    
    def _format_nested_rules_for_relevance(
        self,
        nested_rules: Dict[str, Dict[int, Dict[str, Any]]],
        max_trends_per_category: int = 10
    ) -> str:
        """
        Format nested rules structure for LLM relevance check.
        DEPRECATED: Use _format_parent_rules_complete and _format_parent_rules_with_subrules_complete instead.
        
        Args:
            nested_rules: Nested rules from get_nested_rules_by_categories
            max_trends_per_category: Maximum parent trends to show per category
            
        Returns:
            Formatted text representation showing parent-child hierarchy
        """
        if not nested_rules:
            return "No rules available."
        
        formatted = []
        
        for category, trends in nested_rules.items():
            formatted.append(f"\n### {category}")
            formatted.append("-" * 60)
            
            trend_count = 0
            for trend_id, trend_data in trends.items():
                if trend_count >= max_trends_per_category:
                    remaining = len(trends) - trend_count
                    if remaining > 0:
                        formatted.append(f"  ... and {remaining} more trends in this category")
                    break
                
                parent = trend_data.get("parent", {})
                subrules = trend_data.get("subrules", [])
                
                why = parent.get("why") or ""
                formatted.append(f"\n[TREND {trend_id}] {why}")
                
                suggestions = parent.get("cost_of_care_suggestions") or parent.get("coding_accuracy_suggestions")
                if suggestions:
                    formatted.append(f"  Suggestion: {suggestions}")
                
                if subrules:
                    formatted.append(f"  ({len(subrules)} detailed subrules)")
                    for subrule in subrules[:3]:
                        sub_why = subrule.get("why") or ""
                        formatted.append(f"    - {sub_why[:80]}...")
                    if len(subrules) > 3:
                        formatted.append(f"    ... and {len(subrules) - 3} more subrules")
                
                trend_count += 1
        
        return "\n".join(formatted)
    
    def _format_rules_sample(
        self,
        all_rules: List[Dict[str, Any]],
        max_sample: int = 50
    ) -> str:
        """
        Format a sample of rules for LLM review.
\
        
        Args:
            all_rules: All available rules
            max_sample: Maximum number of rules to sample
            
        Returns:
            Formatted text representation
        """
        # Take a diverse sample across categories
        categories = {}
        for rule in all_rules:
            cat = rule.get("_category", "Unknown")
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(rule)
        
        # Sample from each category
        sample = []
        rules_per_cat = max(1, max_sample // len(categories))
        
        for cat, rules in categories.items():
            sample.extend(rules[:rules_per_cat])
        
        # Format sample
        formatted = []
        for i, rule in enumerate(sample[:max_sample], 1):
            category = rule.get("_category", "Unknown")
            trend_id = rule.get("trend_id", "N/A")
            why = rule.get("why") or ""
            
            formatted.append(f"{i}. [{category}] Trend {trend_id}: {why[:100]}...")
        
        return "\n".join(formatted)
    
    def _format_rules_for_prompt(self, rules: List[Dict[str, Any]]) -> str:
        """
        Format rules for LLM prompt.
        
        Args:
            rules: Rules to format
            
        Returns:
            Formatted text representation
        """
        if not rules:
            return "No rules provided."
        
        formatted = []
        for i, rule in enumerate(rules, 1):
            category = rule.get("_category", "Unknown")
            trend_id = rule.get("trend_id", "N/A")
            why = rule.get("why", "")
            suggestions = rule.get("cost_of_care_suggestions") or rule.get("coding_accuracy_suggestions") or ""
            
            rule_text = f"{i}. Category: {category}\n"
            rule_text += f"   Trend ID: {trend_id}\n"
            rule_text += f"   Why: {why}\n"
            if suggestions:
                rule_text += f"   Suggestion: {suggestions}\n"
            
            formatted.append(rule_text)
        
        return "\n".join(formatted)
    

    
    # ========================================================================
    # AGENT BASE INTERFACE
    # ========================================================================
    
    @property
    def node_name(self) -> str:
        """Entry node name (not used since we override build_graph)."""
        return "process_all_patterns"
    
    def node_function(self, state: RecommendationDTRState) -> None:
        """Node function (not used since we override build_graph)."""
        pass
    
    def prepare_state(
        self,
        patterns_data: List[Dict[str, Any]],
        dtr_rules_path: Optional[str] = None,
        require_llm_relevance: bool = True,
        debug_mode: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Prepare initial state for graph execution.
        
        Args:
            patterns_data: List of combined pattern+reimbursement data
            dtr_rules_path: Optional path to decision tree rules YAML file.
                          If None, uses AppConstants.DTR_RULES_PATH (configs/decision_tree_rules.yaml)
            require_llm_relevance: If True, skip patterns deemed irrelevant by LLM
            debug_mode: Enable verbose logging
            **kwargs: Additional state values
            
        Returns:
            Initial state dictionary
        """
        # Use default DTR rules path from AppConstants if not provided
        if dtr_rules_path is None:
            from deep_research_utils.app_constant import AppConstants
            dtr_rules_path = AppConstants.DTR_RULES_PATH
        
        from datetime import datetime, timezone
        
        return {
            "patterns_data": patterns_data,
            "dtr_rules_path": dtr_rules_path,
            "require_llm_relevance": require_llm_relevance,
            "debug_mode": debug_mode,
            "llm": self.llm,
            "start_time": datetime.now(timezone.utc).isoformat(),
            **kwargs
        }
    
    def extract_result(self, graph_output: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract final result with orchestrator-compliant structure.
        
        Returns standard agent response format matching correlation/reimbursement/pattern agents.
        
        Args:
            graph_output: Final graph state
            
        Returns:
            Orchestrator-compliant results dictionary with job_id, agent, status, output, 
            validation, tokens, and execution info
        """
        from datetime import datetime, timezone
        
        patterns_data = graph_output.get("patterns_data", [])
        all_recommendations = graph_output.get("all_recommendations", [])
        skipped_patterns = graph_output.get("skipped_patterns", [])
        processing_log = graph_output.get("processing_log", [])
        dtr_rules_path = graph_output.get("dtr_rules_path", "")
        
        # Extract token breakdowns
        breakdown_per_pattern = graph_output.get("token_breakdown_per_pattern", {})
        breakdown_aggregated = graph_output.get("token_breakdown_aggregated", {})
        
        # Calculate total tokens from aggregated breakdown
        total_input = sum(entry.get("input", 0) for entry in breakdown_aggregated.values())
        total_output = sum(entry.get("output", 0) for entry in breakdown_aggregated.values())
        
        # Build token structure (standard format)
        tokens = {
            "input": total_input,
            "output": total_output,
            "breakdown": {
                "per_pattern": breakdown_per_pattern,
                "aggregated": breakdown_aggregated
            }
        }
        
        # Calculate execution duration
        start_time = graph_output.get("start_time", "")
        end_time = datetime.now(timezone.utc).isoformat()
        
        duration_ms = 0
        if start_time:
            try:
                start_dt = datetime.fromisoformat(start_time.replace("Z", "+00:00"))
                end_dt = datetime.fromisoformat(end_time.replace("Z", "+00:00"))
                duration_seconds = (end_dt - start_dt).total_seconds()
                duration_ms = int(duration_seconds * 1000)
            except Exception:
                pass
        
        execution = {
            "start_time": start_time,
            "end_time": end_time,
            "duration_ms": duration_ms,
            "version": "1.0.0"
        }
        
        # Remove story_alignment from all recommendations
        for rec in all_recommendations:
            rec.pop("story_alignment", None)
        
        # Determine status based on results
        if len(all_recommendations) == 0:
            status = "failed"
        elif len(skipped_patterns) > 0 and len(all_recommendations) > 0:
            status = "partial_success"
        else:
            status = "success"
        
        # Build validation checks
        checks = []
        
        # Check 1: Patterns processed
        if len(patterns_data) > 0:
            checks.append({
                "check": "patterns_processed",
                "passed": True,
                "message": f"Processed {len(patterns_data)} patterns"
            })
        else:
            checks.append({
                "check": "patterns_processed",
                "passed": False,
                "message": "No patterns provided for processing"
            })
        
        # Check 2: DTR rules loaded
        if dtr_rules_path:
            checks.append({
                "check": "dtr_rules_loaded",
                "passed": True,
                "message": f"DTR rules loaded from {dtr_rules_path}"
            })
        else:
            checks.append({
                "check": "dtr_rules_loaded",
                "passed": False,
                "message": "DTR rules path not specified"
            })
        
        # Check 3: Recommendations generated
        if len(all_recommendations) > 0:
            checks.append({
                "check": "recommendations_generated",
                "passed": True,
                "message": f"Generated {len(all_recommendations)} recommendations"
            })
        else:
            checks.append({
                "check": "recommendations_generated",
                "passed": False,
                "message": "No recommendations generated"
            })
        
        # Check 4: Token tracking
        if total_input > 0 or total_output > 0:
            checks.append({
                "check": "token_tracking",
                "passed": True,
                "message": f"Tracked {total_input} input + {total_output} output tokens"
            })
        else:
            checks.append({
                "check": "token_tracking",
                "passed": False,
                "message": "No token usage recorded"
            })
        
        # Build warnings
        warnings = []
        if len(skipped_patterns) > 0:
            warnings.append(
                f"{len(skipped_patterns)} pattern(s) skipped (not relevant to DTR rules). "
                f"See skipped_patterns in output for details."
            )
        
        # Build errors
        errors = []
        if len(all_recommendations) == 0:
            errors.append("No recommendations were generated from the provided patterns")
        
        # Determine is_valid
        is_valid = all(check["passed"] for check in checks)
        
        validation = {
            "is_valid": is_valid,
            "checks": checks,
            "warnings": warnings,
            "errors": errors
        }
        
        # Build explanation
        explanation = {
            "summary": f"Generated {len(all_recommendations)} recommendations from {len(patterns_data)} patterns",
            "total_patterns": len(patterns_data),
            "recommendations_generated": len(all_recommendations),
            "patterns_skipped": len(skipped_patterns),
            "approach": "llm_based_dtr_relevance",
            "dtr_rules_path": dtr_rules_path
        }
        
        # Extract job_id and conversation_id for orchestrator tracking
        job_id = graph_output.get("job_id", uuid.uuid4().hex)
        conversation_id = graph_output.get("conversation_id")
        
        # Build orchestrator-compliant output
        return {
            "job_id": job_id,
            "conversation_id": conversation_id,
            "agent": "recommendation_dtr",
            "status": status,
            "output": {
                "metadata": {
                    "total_patterns": len(patterns_data),
                    "recommendations_generated": len(all_recommendations),
                    "patterns_skipped": len(skipped_patterns),
                    "approach": "llm_based_dtr_relevance",
                    "dtr_rules_path": dtr_rules_path
                },
                "recommendations": all_recommendations,
                "skipped_patterns": skipped_patterns,
                "processing_log": processing_log
            },
            "recommended_action": all_recommendations,
            "visual_component": {},
            "explanation": explanation,
            "validation": validation,
            "tokens": tokens,
            "execution": execution
        }


def build_app(
    llm: Optional[Any] = None,
    llm_builder: Optional[Callable[[], Any]] = None,
    **kwargs
) -> RecommendationDTRAgent:
    """
    Build DTR-based recommendation agent with LLM relevance determination.
    
    Args:
        llm: Optional pre-configured LLM client
        llm_builder: Optional callable that returns LLM client
        **kwargs: Additional arguments passed to agent
        
    Returns:
        Callable that takes patterns_data (and optional dtr_rules_path), returns results
        
    Example:
        >>> agent = build_app()
        >>> # DTR rules path auto-configured from AppConstants
        >>> results = agent(patterns_data=combined_patterns)
        >>> print(f"Generated {len(results['recommendations'])} recommendations")
        >>> 
        >>> # Or override the DTR rules path if needed
        >>> results = agent(
        ...     patterns_data=combined_patterns,
        ...     dtr_rules_path="custom/path/rules.yaml"
        ... )
    """
    agent = RecommendationDTRAgent(
        llm=llm,
        llm_builder=llm_builder,
        **kwargs
    )
    
    return agent


if __name__ == "__main__":
    import os
    from dotenv import load_dotenv
    
    load_dotenv()
    
    # Example usage
    agent = build_app(debug=True)
    
    # Sample pattern data (in practice, load from combined_pattern_reimbursement_results.json)
    sample_patterns = [
        {
            "pattern_rank": 1,
            "top_pattern": "Maine alcohol-related IP BH growth",
            "pattern_type": "Inpatient",
            "what_is_impacting": "Behavioral Health",
            "impact_summary": "Significant cost increase in Maine BH admissions",
            "pattern_details": "Maine alcohol-related inpatient behavioral health admissions increased by $2.3M...",
            "reimbursement": {
                "pattern_title": "Observation Stay Policies",
                "individual_policies": [
                    {
                        "payer_name": "Point32Health",
                        "policy_url": "https://www.point32health.org/provider/observation-stay"
                    }
                ]
            }
        }
    ]
    
    # DTR rules path is auto-configured from AppConstants.DTR_RULES_PATH
    # No need to pass dtr_rules_path parameter!
    try:
        results = agent(patterns_data=sample_patterns)
        
        print(json.dumps(results, indent=2))
    except FileNotFoundError as e:
        print(f"Note: DTR rules file not found: {e}")
        print("Make sure configs/decision_tree_rules.yaml exists in the project root.")
