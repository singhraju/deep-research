"""
Reimbursement Policy Aggregator Agent

This agent aggregates multiple reimbursement policy extraction results (one per pattern)
and generates a heatmap visualization showing policy-code impact analysis across all patterns.

The heatmap shows:
- Rows: Policy IDs from all reimbursement results
- Columns: Medical codes (CPT, HCPCS, DRG) from all patterns
- Cells: Impact levels (High, Medium, None) based on policy applicability and cost impact

Usage:
    >>> from deep_research_agents import ReimbursementAggregatorAgent
    >>> 
    >>> agent = ReimbursementAggregatorAgent()
    >>> 
    >>> # Aggregate multiple reimbursement results
    >>> heatmap_data = agent(
    ...     reimbursement_results=[result1, result2, result3],
    ...     conversation_id="test-aggregation"
    ... )
    >>> 
    >>> # Access heatmap structure
    >>> print(heatmap_data["heatmap_data"]["rows"])
    >>> print(heatmap_data["heatmap_data"]["columns"])
    >>> print(heatmap_data["heatmap_data"]["cells"])
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, TypedDict

from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field

from deep_research_core.base_agent import AgentBase

try:
    from deep_research_utils.logger_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    logger = logging.getLogger(__name__)


# ============================================================================
# Type Definitions
# ============================================================================


class AggregatorState(TypedDict, total=False):
    """State for reimbursement policy aggregator agent."""
    
    # Orchestrator inputs
    conversation_id: str
    query: str
    job_id: str
    
    # Input data
    reimbursement_results: List[Dict[str, Any]]  # List of reimbursement agent outputs
    
    # Intermediate processing
    all_policies: List[Dict[str, Any]]  # Deduplicated policies across all results
    all_codes: List[Dict[str, Any]]  # All medical codes from patterns
    impact_matrix: Dict[str, Dict[str, float]]  # policy_id -> code -> impact_score
    evidence_matrix: Dict[str, Dict[str, Dict[str, Any]]]  # policy_id -> code -> evidence details
    elevance_baseline: Dict[str, Dict[str, Any]]  # code -> Elevance policy details for comparison
    
    # Resources
    llm: Any
    
    # Execution tracking
    start_time: str
    
    # Output
    result: Dict[str, Any]  # Heatmap data structure


class HeatmapRow(BaseModel):
    """Heatmap row representing a medical code."""
    
    code: str = Field(..., description="Medical code (CPT, HCPCS, DRG, ICD-10)")
    code_type: str = Field(..., description="Code type (CPT, HCPCS, DRG, ICD-10)")
    description: str = Field(..., description="Code description")
    pattern_id: Optional[str] = Field(None, description="Pattern this code belongs to")


class HeatmapColumn(BaseModel):
    """Heatmap column representing a policy."""
    
    policy_id: str = Field(..., description="Policy identifier")
    policy_type: str = Field(..., description="Policy type (Recommendation, Mandate, etc.)")
    policy_description: str = Field(..., description="Brief policy description")
    payor: str = Field(..., description="Payor name")
    state: Optional[str] = Field(None, description="State (if available)")
    policy_url: Optional[str] = Field(None, description="URL to the policy document")


class HeatmapCell(BaseModel):
    """Heatmap cell representing policy-code impact."""
    
    policy_id: str = Field(..., description="Policy identifier")
    code: str = Field(..., description="Medical code")
    impact_level: str = Field(..., description="High | Medium | None")
    impact_score: float = Field(..., description="Numeric impact score (0.0-1.0)")
    color: str = Field(..., description="Hex color code for visualization")
    evidence: Optional[str] = Field(None, description="Supporting evidence from policy")
    restrictiveness_level: Optional[str] = Field(None, description="more_restrictive | less_restrictive | equal | unknown (compared to Elevance)")
    hover_details: Optional[Dict[str, Any]] = Field(None, description="Detailed information for hover card")


class HeatmapMetadata(BaseModel):
    """Heatmap metadata and summary statistics."""
    
    total_policies: int = Field(..., description="Total number of policies")
    total_codes: int = Field(..., description="Total number of medical codes")
    total_patterns: int = Field(..., description="Total number of patterns analyzed")
    impact_distribution: Dict[str, int] = Field(..., description="Count by impact level")
    top_policy_types: List[str] = Field(..., description="Most common policy types")
    top_payors: List[str] = Field(..., description="Most common payors")


class AggregatorResponseSchema(BaseModel):
    """Complete aggregator response schema."""
    
    heatmap_data: Dict[str, Any] = Field(..., description="Heatmap visualization data")
    metadata: HeatmapMetadata = Field(..., description="Summary metadata")
    timestamp: str = Field(..., description="Generation timestamp")


class RestrictivenessComparisonResponse(BaseModel):
    """LLM response for restrictiveness comparison."""
    
    restrictiveness_level: str = Field(..., description="more_restrictive | less_restrictive | equal | unknown")
    confidence: str = Field(..., description="high | medium | low")
    rationale: str = Field(..., description="Explanation of the comparison")
    key_differences: List[str] = Field(default_factory=list, description="Key differences between policies")


# ============================================================================
# Impact Scoring Constants
# ============================================================================

# Impact level thresholds
IMPACT_HIGH_THRESHOLD = 0.7
IMPACT_MEDIUM_THRESHOLD = 0.3

# Color mapping
COLOR_HIGH_IMPACT = "#006400"  # Dark green
COLOR_MEDIUM_IMPACT = "#FFD700"  # Gold/yellow
COLOR_NO_IMPACT = "#8B0000"  # Dark red

# Action type weights for impact scoring
ACTION_TYPE_WEIGHTS = {
    "deny": 1.0,
    "require_auth": 0.9,
    "bundle": 0.8,
    "limit": 0.7,
    "allow_with_conditions": 0.5,
    "pay_separately": 0.3,
}


# ============================================================================
# LLM Restrictiveness Comparison Prompts
# ============================================================================

RESTRICTIVENESS_SYSTEM_PROMPT = """You are an expert at comparing healthcare reimbursement policies.
Analyze two policies for the same medical code and determine which is more restrictive.
Return ONLY valid JSON matching the schema provided.
Do not output markdown or explanatory text."""

RESTRICTIVENESS_USER_PROMPT_TEMPLATE = """Medical Code: {code}

External Policy ({policy_id}):
{policy_evidence_text}

Elevance Baseline Policy ({elevance_policy_id}):
{elevance_evidence_text}

Compare these policies and determine restrictiveness. Return ONLY valid JSON:

{{
  "restrictiveness_level": "more_restrictive | less_restrictive | equal | unknown",
  "confidence": "high | medium | low",
  "rationale": "string explaining the comparison in 1-2 sentences",
  "key_differences": ["string", ...]
}}

Guidelines:
- more_restrictive: External policy denies/limits/restricts MORE than Elevance baseline
- less_restrictive: External policy allows/covers MORE than Elevance baseline
- equal: Similar level of restrictions or both have no specific rules
- unknown: Insufficient information to make a meaningful comparison

Focus on: denials, prior authorization requirements, utilization limits, bundling restrictions, 
coverage exclusions, documentation requirements, and any other policy constraints.

If both policies are empty or lack specific rules, return "equal" with low confidence.
If only one policy has rules, compare it against no restrictions (baseline of full coverage).

Return ONLY valid JSON, no explanatory text."""


# ============================================================================
# Reimbursement Policy Aggregator Agent
# ============================================================================


class ReimbursementAggregatorAgent(AgentBase):
    """
    Agent for aggregating reimbursement policy results into a heatmap visualization.
    
    This agent:
    1. Collects all policies from multiple reimbursement agent runs
    2. Extracts all medical codes from patterns
    3. Calculates policy-code impact scores
    4. Generates heatmap data structure for visualization
    
    Args:
        **kwargs: Additional arguments passed to AgentBase
    """
    
    api_response_model = AggregatorResponseSchema
    
    def __init__(self, **kwargs):
        super().__init__(
            agent_name="reimbursement_aggregator",
            state_class=AggregatorState,
            llm_reasoning_effort="low",  # Simple aggregation, no complex reasoning needed
            **kwargs
        )
    
    # ========================================================================
    # AgentBase Implementation
    # ========================================================================
    
    @property
    def node_name(self) -> str:
        """Name of the primary graph node."""
        return "aggregate"
    
    def create_stub_llm(self) -> Any:
        """
        Create stub LLM for testing.
        
        The aggregator doesn't actually use the LLM (it's pure aggregation logic),
        so we just return a simple mock object.
        
        Returns:
            Stub LLM instance
        """
        class StubLLM:
            def invoke(self, *args, **kwargs):
                return type('Response', (), {'content': 'stub response'})()
        
        return StubLLM()
    
    def prepare_state(
        self,
        reimbursement_results: List[Dict[str, Any]],
        conversation_id: str,
        query: Optional[str] = None,
        job_id: Optional[str] = None,
        **kwargs
    ) -> AggregatorState:
        """
        Prepare state for aggregation.
        
        Args:
            reimbursement_results: List of reimbursement agent outputs (one per pattern)
            conversation_id: Conversation identifier
            query: User query (optional)
            job_id: Job identifier (optional)
            **kwargs: Additional state fields
            
        Returns:
            Initial state dictionary
        """
        return {
            "reimbursement_results": reimbursement_results,
            "conversation_id": conversation_id,
            "query": query or "Aggregate reimbursement policies across patterns",
            "job_id": job_id or f"agg-{conversation_id}",
            "llm": self.llm,
            "start_time": datetime.now(timezone.utc).isoformat(),
            **kwargs
        }
    
    def node_function(self, state: AggregatorState) -> Dict[str, Any]:
        """
        Main aggregation logic.
        
        Args:
            state: Current graph state
            
        Returns:
            Updated state with heatmap result
        """
        self.logger.info("Starting policy aggregation")
        
        reimbursement_results = state["reimbursement_results"]
        self.logger.info(f"Aggregating {len(reimbursement_results)} reimbursement results")
        
        # Step 1: Extract and deduplicate all policies
        all_policies = self._extract_policies(reimbursement_results)
        self.logger.info(f"Extracted {len(all_policies)} unique policies")
        
        # Step 2: Extract all medical codes from patterns
        all_codes = self._extract_codes(reimbursement_results)
        self.logger.info(f"Extracted {len(all_codes)} unique medical codes")
        
        # Step 3: Build impact matrix and evidence (policy_id -> code -> impact_score + evidence)
        impact_matrix, evidence_matrix = self._build_impact_matrix(reimbursement_results, all_policies, all_codes)
        self.logger.info(f"Built impact matrix with {len(impact_matrix)} policies")
        
        # Step 3.5: Build Elevance baseline for restrictiveness comparison
        elevance_baseline = self._build_elevance_baseline(reimbursement_results, all_codes)
        self.logger.info(f"Built Elevance baseline for {len(elevance_baseline)} codes")
        
        # Step 4: Generate heatmap data structure with LLM-based restrictiveness comparison
        llm = state.get("llm")
        heatmap_data = self._generate_heatmap_data(
            all_policies, 
            all_codes, 
            impact_matrix, 
            evidence_matrix, 
            elevance_baseline,
            llm=llm  # Pass LLM for restrictiveness comparison
        )
        
        # Step 4.5: Filter out Elevance policies
        heatmap_data = self._filter_elevance_policies(heatmap_data)
        self.logger.info(f"After filtering Elevance policies: {len(heatmap_data['rows'])} policies remain")
        
        # Step 4.6: Filter out rows and columns with all-None impact
        heatmap_data = self._filter_empty_rows(heatmap_data)
        self.logger.info(f"After filtering all-None rows: {len(heatmap_data['rows'])} policies remain")
        
        heatmap_data = self._filter_empty_columns(heatmap_data)
        self.logger.info(f"After filtering all-None columns: {len(heatmap_data['columns'])} codes remain")
        
        # Step 5: Generate metadata
        metadata = self._generate_metadata(
            all_policies, 
            all_codes, 
            reimbursement_results, 
            impact_matrix
        )
        
        result = {
            "heatmap_data": heatmap_data,
            "metadata": metadata.model_dump(),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        self.logger.info("Policy aggregation completed successfully")
        
        return {"result": result}
    
    def extract_result(self, graph_output: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract final result from graph output.
        
        Args:
            graph_output: Complete graph state after execution
            
        Returns:
            Heatmap data structure
        """
        return graph_output.get("result", {})
    
    def build_graph(self) -> StateGraph:
        """
        Build simple single-node graph for aggregation.
        
        Returns:
            Compiled StateGraph
        """
        graph = StateGraph(self.state_class)
        graph.add_node("aggregate", self.node_function)
        graph.add_edge(START, "aggregate")
        graph.add_edge("aggregate", END)
        return graph
    
    # ========================================================================
    # Helper Methods
    # ========================================================================
    
    def _extract_policies(self, reimbursement_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Extract and deduplicate policies from all reimbursement results.
        
        Args:
            reimbursement_results: List of reimbursement agent outputs
            
        Returns:
            List of unique policies with metadata
        """
        policies_by_id = {}
        
        for result in reimbursement_results:
            # Read from output.reimbursement_policies (actual reimbursement agent structure)
            output = result.get("output", {})
            reimbursement_policies = output.get("reimbursement_policies", [])
            
            for policy in reimbursement_policies:
                policy_id = policy.get("policy_id")
                if not policy_id:
                    continue
                
                # Deduplicate by policy_id
                if policy_id not in policies_by_id:
                    # Extract state information from policy
                    state = self._extract_state_from_policy(policy)
                    
                    policies_by_id[policy_id] = {
                        "policy_id": policy_id,
                        "policy_type": self._infer_policy_type(policy_id),
                        "policy_description": policy.get("policy_title", "")[:100],  # Truncate to 100 chars
                        "payor": policy.get("payer_name", "Unknown"),
                        "state": state,
                        "policy_url": policy.get("policy_url"),  # Extract policy URL
                        "full_data": policy  # Keep full policy data for impact scoring
                    }
        
        return list(policies_by_id.values())
    
    def _extract_codes(self, reimbursement_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Extract all medical codes from reimbursement results.
        
        Reads from explanation.{drg|cpt}_codes_requested which contains:
        - DRG codes as descriptions (e.g., "Liver Transplant with MCC or Intestinal Transplant")
        - CPT codes as code strings (e.g., "99221", "99222")
        
        Args:
            reimbursement_results: List of reimbursement agent outputs
            
        Returns:
            List of unique codes with metadata
        """
        codes_by_value = {}
        
        for idx, result in enumerate(reimbursement_results):
            # Get pattern info for labeling
            explanation = result.get("explanation", {})
            pattern_rank = explanation.get("pattern_rank", idx + 1)
            pattern_title = explanation.get("pattern_title", f"Pattern {pattern_rank}")
            pattern_id = f"pattern_{pattern_rank}"
            
            # Extract DRG codes (these are descriptions, not numeric codes)
            drg_descriptions = explanation.get("drg_codes_requested", [])
            for drg_desc in drg_descriptions:
                # Include "Not Mapped" to show patterns without specific DRG mappings
                if drg_desc and drg_desc not in codes_by_value:
                    codes_by_value[drg_desc] = {
                        "code": drg_desc,
                        "code_type": "DRG",
                        "description": drg_desc,  # Description IS the code for DRGs
                        "pattern_id": pattern_id,
                        "pattern_title": pattern_title
                    }
            
            # Extract CPT codes
            cpt_codes = explanation.get("cpt_codes_requested", [])
            for code in cpt_codes:
                if code and code not in codes_by_value:
                    codes_by_value[code] = {
                        "code": code,
                        "code_type": "CPT",
                        "description": f"CPT {code}",
                        "pattern_id": pattern_id,
                        "pattern_title": pattern_title
                    }
        
        return list(codes_by_value.values())
    
    def _build_impact_matrix(
        self,
        reimbursement_results: List[Dict[str, Any]],
        all_policies: List[Dict[str, Any]],
        all_codes: List[Dict[str, Any]]
    ) -> tuple[Dict[str, Dict[str, float]], Dict[str, Dict[str, Dict[str, Any]]]]:
        """
        Build impact matrix and evidence matrix: policy_id -> code -> impact_score + evidence.
        
        Impact score is calculated based on:
        - Whether the code is mentioned in the policy's edit_rule_facts
        - Action types (deny, require_auth, etc.)
        - Presence of structured rules (modifiers, revenue codes, etc.)
        
        Args:
            reimbursement_results: List of reimbursement agent outputs
            all_policies: List of unique policies
            all_codes: List of unique codes
            
        Returns:
            Tuple of (impact_matrix, evidence_matrix)
            - impact_matrix: {policy_id: {code: impact_score}}
            - evidence_matrix: {policy_id: {code: {evidence, action_types, rules}}}
        """
        impact_matrix = defaultdict(lambda: defaultdict(float))
        evidence_matrix = defaultdict(lambda: defaultdict(dict))
        
        # Build code lookup for matching
        code_set = {code["code"] for code in all_codes}
        
        for result in reimbursement_results:
            # Read from output.reimbursement_policies
            output = result.get("output", {})
            reimbursement_policies = output.get("reimbursement_policies", [])
            
            # Get the codes for this pattern
            explanation = result.get("explanation", {})
            pattern_drg_codes = set(explanation.get("drg_codes_requested", []))
            pattern_cpt_codes = set(explanation.get("cpt_codes_requested", []))
            pattern_codes = pattern_drg_codes | pattern_cpt_codes
            
            for policy in reimbursement_policies:
                policy_id = policy.get("policy_id")
                if not policy_id:
                    continue
                
                # Get edit_rule_facts
                edit_rule_facts = policy.get("edit_rule_facts", {})
                
                # Calculate impact for each code in the pattern
                for code in pattern_codes:
                    if not code:
                        continue
                    
                    # Calculate impact score and extract evidence
                    impact_score, evidence_details = self._calculate_impact_score_from_facts(
                        edit_rule_facts, code, return_evidence=True
                    )
                    
                    # Store in matrix (max score if code appears in multiple patterns)
                    if impact_score > 0:
                        current_score = impact_matrix[policy_id][code]
                        if impact_score > current_score:
                            impact_matrix[policy_id][code] = impact_score
                            # Store evidence details for hover card
                            evidence_matrix[policy_id][code] = {
                                "evidence": evidence_details.get("evidence", ""),
                                "policy_evidence_text": policy.get("evidence", ""),  # Full policy text from reimbursement agent
                                "action_types": evidence_details.get("action_types", []),
                                "target_codes": evidence_details.get("target_codes", []),
                                "related_codes": evidence_details.get("related_codes", []),
                                "required_modifiers": evidence_details.get("required_modifiers", []),
                                "excluded_modifiers": evidence_details.get("excluded_modifiers", []),
                                "utilization_limits": evidence_details.get("utilization_limits", []),
                                "prior_auth_thresholds": evidence_details.get("prior_auth_thresholds", []),
                                "policy_title": policy.get("policy_title", ""),
                                "payor": policy.get("payer_name", "Unknown")
                            }
        
        return dict(impact_matrix), dict(evidence_matrix)
    
    def _calculate_impact_score_from_facts(
        self, 
        edit_rule_facts: Dict[str, Any], 
        code: str,
        return_evidence: bool = False
    ) -> float | tuple[float, Dict[str, Any]]:
        """
        Calculate impact score based on edit_rule_facts structure.
        
        Args:
            edit_rule_facts: Policy edit rule facts from reimbursement agent
            code: Medical code (DRG description or CPT code)
            return_evidence: If True, return (score, evidence_dict) tuple
            
        Returns:
            Impact score (0.0-1.0) or tuple of (score, evidence_details)
        """
        score = 0.0
        evidence_details = {}
        
        # Check if code is explicitly mentioned in target_codes or related_codes
        target_codes = edit_rule_facts.get("target_codes", [])
        related_codes = edit_rule_facts.get("related_codes", [])
        
        # For DRG descriptions, check if any part matches
        code_mentioned = False
        if target_codes or related_codes:
            all_codes = target_codes + related_codes
            # Exact match or substring match for DRG descriptions
            code_mentioned = any(
                code == c or code in c or c in code 
                for c in all_codes
            )
        
        # If not explicitly mentioned, check if policy has any rules at all
        # (policy may apply broadly to the pattern)
        has_any_rules = any([
            edit_rule_facts.get("action_types"),
            edit_rule_facts.get("required_modifiers"),
            edit_rule_facts.get("excluded_modifiers"),
            edit_rule_facts.get("revenue_codes"),
            edit_rule_facts.get("prior_auth_thresholds"),
            edit_rule_facts.get("program_scope")
        ])
        
        if code_mentioned:
            score = 0.6  # Explicitly mentioned
        elif has_any_rules:
            score = 0.2  # Policy has rules, may apply broadly (reduced from 0.3 to be more conservative)
        else:
            # No relevant rules
            if return_evidence:
                return 0.0, {}
            return 0.0
        
        # Boost from action types
        action_types = edit_rule_facts.get("action_types", [])
        if action_types:
            for action in action_types:
                if action in ACTION_TYPE_WEIGHTS:
                    score = max(score, ACTION_TYPE_WEIGHTS[action])
        
        # Boost from structured rules presence
        structured_fields = [
            "required_modifiers",
            "excluded_modifiers",
            "revenue_codes",
            "utilization_limits",
            "prior_auth_thresholds",
            "discharge_status_conditions"
        ]
        
        structured_count = sum(
            1 for field in structured_fields
            if edit_rule_facts.get(field) and len(edit_rule_facts.get(field, [])) > 0
        )
        
        # Add up to 0.2 based on structured rule richness
        if structured_count > 0:
            score = min(1.0, score + (structured_count * 0.05))
        
        # Build evidence details if requested
        if return_evidence:
            evidence_details = {
                "evidence": self._build_evidence_text(edit_rule_facts, code),
                "action_types": action_types,
                "target_codes": edit_rule_facts.get("target_codes", []),
                "related_codes": edit_rule_facts.get("related_codes", []),
                "required_modifiers": edit_rule_facts.get("required_modifiers", []),
                "excluded_modifiers": edit_rule_facts.get("excluded_modifiers", []),
                "utilization_limits": edit_rule_facts.get("utilization_limits", []),
                "prior_auth_thresholds": edit_rule_facts.get("prior_auth_thresholds", []),
            }
            return score, evidence_details
        
        return score
    
    def _build_evidence_text(self, edit_rule_facts: Dict[str, Any], code: str) -> str:
        """
        Build human-readable evidence text from edit_rule_facts.
        
        Args:
            edit_rule_facts: Policy edit rule facts
            code: Medical code
            
        Returns:
            Evidence text string
        """
        evidence_parts = []
        
        action_types = edit_rule_facts.get("action_types", [])
        if action_types:
            evidence_parts.append(f"Actions: {', '.join(action_types)}")
        
        target_codes = edit_rule_facts.get("target_codes", [])
        if target_codes:
            evidence_parts.append(f"Target codes: {', '.join(target_codes[:5])}")
        
        required_modifiers = edit_rule_facts.get("required_modifiers", [])
        if required_modifiers:
            evidence_parts.append(f"Required modifiers: {', '.join(required_modifiers)}")
        
        excluded_modifiers = edit_rule_facts.get("excluded_modifiers", [])
        if excluded_modifiers:
            evidence_parts.append(f"Excluded modifiers: {', '.join(excluded_modifiers)}")
        
        utilization_limits = edit_rule_facts.get("utilization_limits", [])
        if utilization_limits:
            evidence_parts.append(f"Limits: {', '.join(utilization_limits[:3])}")
        
        prior_auth = edit_rule_facts.get("prior_auth_thresholds", [])
        if prior_auth:
            evidence_parts.append(f"Prior auth: {', '.join(prior_auth[:2])}")
        
        return "; ".join(evidence_parts) if evidence_parts else "General policy applicability"
    
    def _build_elevance_baseline(
        self,
        reimbursement_results: List[Dict[str, Any]],
        all_codes: List[Dict[str, Any]]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Build Elevance baseline for restrictiveness comparison.
        
        Args:
            reimbursement_results: List of reimbursement agent outputs
            all_codes: List of unique codes
            
        Returns:
            Dict mapping code -> Elevance policy details (including evidence text for LLM comparison)
        """
        elevance_baseline = {}
        
        for result in reimbursement_results:
            output = result.get("output", {})
            reimbursement_policies = output.get("reimbursement_policies", [])
            
            # Get codes for this pattern
            explanation = result.get("explanation", {})
            pattern_drg_codes = set(explanation.get("drg_codes_requested", []))
            pattern_cpt_codes = set(explanation.get("cpt_codes_requested", []))
            pattern_codes = pattern_drg_codes | pattern_cpt_codes
            
            for policy in reimbursement_policies:
                payor = policy.get("payer_name", "")
                
                # Check if this is an Elevance policy
                if "Elevance" not in payor:
                    continue
                
                edit_rule_facts = policy.get("edit_rule_facts", {})
                evidence_text = policy.get("evidence", "")  # Get full policy evidence text
                
                for code in pattern_codes:
                    if not code:
                        continue
                    
                    # Store Elevance policy details for this code
                    if code not in elevance_baseline:
                        elevance_baseline[code] = {
                            "action_types": edit_rule_facts.get("action_types", []),
                            "utilization_limits": edit_rule_facts.get("utilization_limits", []),
                            "prior_auth_thresholds": edit_rule_facts.get("prior_auth_thresholds", []),
                            "required_modifiers": edit_rule_facts.get("required_modifiers", []),
                            "excluded_modifiers": edit_rule_facts.get("excluded_modifiers", []),
                            "policy_id": policy.get("policy_id", ""),
                            "evidence_text": evidence_text  # Add evidence text for LLM comparison
                        }
        
        return elevance_baseline
    
    def _compare_restrictiveness_with_llm(
        self,
        policy_evidence_text: str,
        elevance_evidence_text: str,
        code: str,
        policy_id: str,
        elevance_policy_id: str
    ) -> tuple[str, str]:
        """
        Compare policy restrictiveness using LLM reasoning.
        
        Uses self._invoke_with_token_retry() which includes automatic token refresh on auth errors.
        
        Args:
            policy_evidence_text: Full policy text/evidence for the external policy
            elevance_evidence_text: Full policy text/evidence for Elevance baseline
            code: Medical code being compared
            policy_id: External policy ID
            elevance_policy_id: Elevance baseline policy ID
            
        Returns:
            Tuple of (restrictiveness_level, rationale):
                - restrictiveness_level: more_restrictive | less_restrictive | equal | unknown
                - rationale: Human-readable explanation from LLM
        """
        # Handle empty evidence cases
        if not policy_evidence_text and not elevance_evidence_text:
            return "equal", "Both policies lack specific rules for this code (low confidence)"
        
        if not policy_evidence_text:
            policy_evidence_text = "No specific policy rules found for this code."
        
        if not elevance_evidence_text:
            elevance_evidence_text = "No specific Elevance baseline rules found for this code."
        
        # Build prompt
        user_prompt = RESTRICTIVENESS_USER_PROMPT_TEMPLATE.format(
            code=code,
            policy_id=policy_id,
            policy_evidence_text=policy_evidence_text[:1000],  # Limit to 1000 chars to avoid token overflow
            elevance_policy_id=elevance_policy_id or "Unknown",
            elevance_evidence_text=elevance_evidence_text[:1000]
        )
        
        messages = [
            {"role": "system", "content": RESTRICTIVENESS_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
        
        try:
            # Call LLM with automatic token refresh on auth errors
            response = self._invoke_with_token_retry(messages)
            content = response.content.strip()
            
            # Remove markdown code fences if present
            if content.startswith("```"):
                lines = content.split("\n")
                if len(lines) > 2:
                    content = "\n".join(lines[1:-1])
            
            # Parse JSON
            data = json.loads(content)
            
            # Validate with Pydantic
            validated = RestrictivenessComparisonResponse(**data)
            
            # Build rationale with confidence
            rationale = f"{validated.rationale}"
            if validated.confidence:
                rationale += f" (confidence: {validated.confidence})"
            
            return validated.restrictiveness_level, rationale
            
        except Exception as e:
            self.logger.warning(
                f"LLM restrictiveness comparison failed for policy_id={policy_id}, code={code}: {e}; "
                f"falling back to unknown"
            )
            return "unknown", f"LLM comparison failed: {str(e)[:100]}"
    
    def _batch_compare_restrictiveness_with_llm(
        self,
        comparison_tasks: List[Dict[str, Any]],
        max_workers: int = 5
    ) -> Dict[tuple, tuple[str, str]]:
        """
        Compare restrictiveness for multiple policy-code pairs in parallel.
        
        Uses self._invoke_with_token_retry() for each comparison via a bound method,
        which includes automatic token refresh on 401 authentication errors.
        
        Args:
            comparison_tasks: List of dicts with keys:
                - policy_id, code, policy_evidence_text, elevance_policy_id, elevance_evidence_text
            max_workers: Maximum parallel workers
            
        Returns:
            Dict mapping (policy_id, code) -> (restrictiveness_level, rationale)
        """
        results = {}
        total_tasks = len(comparison_tasks)
        completed_count = 0
        
        def _compare_one(task: Dict[str, Any]) -> tuple:
            """Worker function that calls the instance method."""
            nonlocal completed_count
            policy_id = task["policy_id"]
            code = task["code"]
            try:
                level, rationale = self._compare_restrictiveness_with_llm(
                    policy_evidence_text=task["policy_evidence_text"],
                    elevance_evidence_text=task["elevance_evidence_text"],
                    code=code,
                    policy_id=policy_id,
                    elevance_policy_id=task["elevance_policy_id"]
                )
                completed_count += 1
                # Log progress every 10 comparisons
                if completed_count % 10 == 0 or completed_count == total_tasks:
                    self.logger.info(f"Progress: {completed_count}/{total_tasks} comparisons completed ({completed_count/total_tasks*100:.1f}%)")
                return (policy_id, code), (level, rationale)
            except Exception as exc:
                completed_count += 1
                self.logger.warning(
                    f"Comparison failed for policy_id={policy_id}, code={code}: {exc} (Progress: {completed_count}/{total_tasks})"
                )
                return (policy_id, code), ("unknown", f"Comparison error: {str(exc)[:100]}")
        
        self.logger.info(f"Running parallel LLM restrictiveness comparison on {total_tasks} tasks (max_workers={max_workers})")
        
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            for key, result in pool.map(_compare_one, comparison_tasks):
                results[key] = result
        
        self.logger.info(f"Completed {len(results)} restrictiveness comparisons")
        return results
    
    def _generate_heatmap_data(
        self,
        all_policies: List[Dict[str, Any]],
        all_codes: List[Dict[str, Any]],
        impact_matrix: Dict[str, Dict[str, float]],
        evidence_matrix: Dict[str, Dict[str, Dict[str, Any]]],
        elevance_baseline: Dict[str, Dict[str, Any]],
        llm: Optional[Any] = None
    ) -> Dict[str, Any]:
        """
        Generate heatmap data structure with LLM-based restrictiveness comparison.
        
        Args:
            all_policies: List of unique policies
            all_codes: List of unique codes
            impact_matrix: Impact scores
            evidence_matrix: Evidence details for each policy-code pair
            elevance_baseline: Elevance baseline for comparison
            llm: LLM client for restrictiveness comparison (optional)
            
        Returns:
            Heatmap data with rows, columns, and cells
        """
        # Build rows (codes) - TRANSPOSED
        rows = [
            {
                "code": c["code"],
                "code_type": c["code_type"],
                "description": c["description"],
                "pattern_id": c.get("pattern_id")
            }
            for c in all_codes
        ]
        
        # Build columns (policies) - TRANSPOSED
        columns = [
            {
                "policy_id": p["policy_id"],
                "policy_type": p["policy_type"],
                "policy_description": p["policy_description"],
                "payor": p["payor"],
                "state": p.get("state"),
                "policy_url": p.get("policy_url")
            }
            for p in all_policies
        ]
        
        # Step 1: Build comparison tasks for batch LLM processing
        comparison_tasks = []
        if llm:
            for code_info in all_codes:
                code = code_info["code"]
                elevance_data = elevance_baseline.get(code, {})
                elevance_evidence_text = elevance_data.get("evidence_text", "")
                elevance_policy_id = elevance_data.get("policy_id", "")
                
                for policy in all_policies:
                    policy_id = policy["policy_id"]
                    policy_evidence = evidence_matrix.get(policy_id, {})
                    evidence_details = policy_evidence.get(code, {})
                    policy_evidence_text = evidence_details.get("policy_evidence_text", "")
                    
                    # Only compare if we have some evidence
                    if policy_evidence_text or elevance_evidence_text:
                        comparison_tasks.append({
                            "policy_id": policy_id,
                            "code": code,
                            "policy_evidence_text": policy_evidence_text,
                            "elevance_evidence_text": elevance_evidence_text,
                            "elevance_policy_id": elevance_policy_id
                        })
        
        # Step 2: Run batch LLM comparison
        restrictiveness_results = {}
        if comparison_tasks:
            self.logger.info(f"Running batch LLM restrictiveness comparison for {len(comparison_tasks)} policy-code pairs")
            restrictiveness_results = self._batch_compare_restrictiveness_with_llm(
                comparison_tasks,
                max_workers=5
            )
        
        # Step 3: Build cells with restrictiveness from LLM results
        # TRANSPOSED: Iterate codes first (rows), then policies (columns)
        cells = []
        for code_info in all_codes:
            code = code_info["code"]
            
            for policy in all_policies:
                policy_id = policy["policy_id"]
                policy_impacts = impact_matrix.get(policy_id, {})
                policy_evidence = evidence_matrix.get(policy_id, {})
                impact_score = policy_impacts.get(code, 0.0)
                
                # Determine impact level and color
                if impact_score >= IMPACT_HIGH_THRESHOLD:
                    impact_level = "High"
                    color = COLOR_HIGH_IMPACT
                elif impact_score >= IMPACT_MEDIUM_THRESHOLD:
                    impact_level = "Medium"
                    color = COLOR_MEDIUM_IMPACT
                else:
                    impact_level = "None"
                    color = COLOR_NO_IMPACT
                
                # Get evidence for this policy-code pair
                evidence_details = policy_evidence.get(code, {})
                
                # Get restrictiveness from LLM results (or default to unknown)
                restrictiveness = "unknown"
                restrictiveness_rationale = "No policy evidence text found for this code"
                if (policy_id, code) in restrictiveness_results:
                    restrictiveness, restrictiveness_rationale = restrictiveness_results[(policy_id, code)]
                
                # Build hover card details
                hover_details = {
                    "policy_title": evidence_details.get("policy_title", policy.get("policy_description", "")),
                    "payor": evidence_details.get("payor", policy.get("payor", "Unknown")),
                    "evidence": evidence_details.get("evidence", ""),
                    "policy_evidence_text": evidence_details.get("policy_evidence_text", ""),  # Full policy text
                    "action_types": evidence_details.get("action_types", []),
                    "target_codes": evidence_details.get("target_codes", []),
                    "utilization_limits": evidence_details.get("utilization_limits", []),
                    "prior_auth_thresholds": evidence_details.get("prior_auth_thresholds", []),
                    "restrictiveness_level": restrictiveness,
                    "restrictiveness_rationale": restrictiveness_rationale  # LLM-generated explanation
                }
                
                cells.append({
                    "policy_id": policy_id,
                    "code": code,
                    "impact_level": impact_level,
                    "impact_score": round(impact_score, 3),
                    "color": color,
                    "restrictiveness_level": restrictiveness,
                    "hover_details": hover_details
                })
        
        return {
            "rows": rows,
            "columns": columns,
            "cells": cells
        }
    
    def _generate_metadata(
        self,
        all_policies: List[Dict[str, Any]],
        all_codes: List[Dict[str, Any]],
        reimbursement_results: List[Dict[str, Any]],
        impact_matrix: Dict[str, Dict[str, float]]
    ) -> HeatmapMetadata:
        """
        Generate summary metadata.
        
        Args:
            all_policies: List of unique policies
            all_codes: List of unique codes
            reimbursement_results: Original results
            impact_matrix: Impact scores
            
        Returns:
            Metadata object
        """
        # Count impact levels
        impact_counts = {"High": 0, "Medium": 0, "None": 0}
        for policy_impacts in impact_matrix.values():
            for score in policy_impacts.values():
                if score >= IMPACT_HIGH_THRESHOLD:
                    impact_counts["High"] += 1
                elif score >= IMPACT_MEDIUM_THRESHOLD:
                    impact_counts["Medium"] += 1
                else:
                    impact_counts["None"] += 1
        
        # Get top policy types
        policy_types = [p["policy_type"] for p in all_policies]
        top_policy_types = list(set(policy_types))[:5]
        
        # Get top payors
        payors = [p["payor"] for p in all_policies]
        top_payors = list(set(payors))[:5]
        
        return HeatmapMetadata(
            total_policies=len(all_policies),
            total_codes=len(all_codes),
            total_patterns=len(reimbursement_results),
            impact_distribution=impact_counts,
            top_policy_types=top_policy_types,
            top_payors=top_payors
        )
    
    def _extract_state_from_policy(self, policy: Dict[str, Any]) -> Optional[str]:
        """
        Extract state information from policy data.
        
        Checks multiple sources:
        1. state_specific_rules in edit_rule_facts
        2. Policy metadata or other fields
        
        Args:
            policy: Policy dictionary
            
        Returns:
            State abbreviation (e.g., "NC", "NY") or None if not found
        """
        # Check edit_rule_facts for state_specific_rules
        edit_rule_facts = policy.get("edit_rule_facts", {})
        state_rules = edit_rule_facts.get("state_specific_rules", [])
        
        if state_rules and isinstance(state_rules, list):
            # Extract state abbreviation from rules like "NC: 20 session cap"
            for rule in state_rules:
                if isinstance(rule, str) and len(rule) >= 2:
                    # Check if first 2 characters are a state abbreviation
                    potential_state = rule[:2].upper()
                    if potential_state.isalpha() and ":" in rule[:5]:
                        return potential_state
        
        # Could check other sources if needed (policy metadata, etc.)
        # For now, return None if no state found
        return None
    
    def _infer_policy_type(self, policy_id: str) -> str:
        """
        Infer policy type from policy ID prefix.
        
        Args:
            policy_id: Policy identifier
            
        Returns:
            Policy type string
        """
        if policy_id.startswith("REC-"):
            return "Recommendation"
        elif policy_id.startswith("MAN-"):
            return "Mandate"
        elif policy_id.startswith("POL-"):
            return "Policy"
        else:
            return "Unknown"
    
    def _filter_elevance_policies(self, heatmap_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Filter out all Elevance policies (both internal and external) from the heatmap.
        TRANSPOSED: Filters columns (policies) instead of rows.
        
        Args:
            heatmap_data: Heatmap data structure
            
        Returns:
            Filtered heatmap data without Elevance policies
        """
        rows = heatmap_data.get("rows", [])  # Codes (unchanged)
        columns = heatmap_data.get("columns", [])  # Policies
        cells = heatmap_data.get("cells", [])
        
        # Filter out columns where payor contains "Elevance"
        non_elevance_columns = [col for col in columns if "Elevance" not in col.get("payor", "")]
        non_elevance_policy_ids = {col["policy_id"] for col in non_elevance_columns}
        
        # Filter cells to only include non-Elevance policies
        non_elevance_cells = [cell for cell in cells if cell["policy_id"] in non_elevance_policy_ids]
        
        elevance_count = len(columns) - len(non_elevance_columns)
        self.logger.info(
            f"Filtered out {elevance_count} Elevance policies "
            f"({len(columns)} -> {len(non_elevance_columns)} policies)"
        )
        
        return {
            "rows": rows,  # Codes remain unchanged
            "columns": non_elevance_columns,  # Filtered policies
            "cells": non_elevance_cells
        }
    
    def _filter_empty_rows(self, heatmap_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Filter out rows (codes) where all cells have "None" impact or "unknown" restrictiveness.
        TRANSPOSED: Filters codes instead of policies.
        
        Args:
            heatmap_data: Heatmap data structure
            
        Returns:
            Filtered heatmap data
        """
        rows = heatmap_data.get("rows", [])  # Codes
        cells = heatmap_data.get("cells", [])
        
        # Build set of codes that have at least one meaningful cell
        # (non-None impact OR non-unknown restrictiveness)
        active_codes = set()
        for cell in cells:
            if (cell.get("impact_level") != "None" or 
                cell.get("restrictiveness_level") != "unknown"):
                active_codes.add(cell["code"])
        
        # Filter rows to keep only active codes
        filtered_rows = [row for row in rows if row["code"] in active_codes]
        
        # Filter cells to keep only active codes
        filtered_cells = [cell for cell in cells if cell["code"] in active_codes]
        
        self.logger.info(
            f"Filtered out {len(rows) - len(filtered_rows)} codes with all-None/unknown impact "
            f"({len(rows)} -> {len(filtered_rows)} codes)"
        )
        
        return {
            "rows": filtered_rows,
            "columns": heatmap_data.get("columns", []),
            "cells": filtered_cells
        }
    
    def _filter_empty_columns(self, heatmap_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Filter out columns (policies) where all cells have "None" impact or "unknown" restrictiveness.
        TRANSPOSED: Filters policies instead of codes.
        
        Args:
            heatmap_data: Heatmap data structure
            
        Returns:
            Filtered heatmap data
        """
        columns = heatmap_data.get("columns", [])  # Policies
        cells = heatmap_data.get("cells", [])
        
        # Build set of policy_ids that have at least one meaningful cell
        # (non-None impact OR non-unknown restrictiveness)
        active_policy_ids = set()
        for cell in cells:
            if (cell.get("impact_level") != "None" or 
                cell.get("restrictiveness_level") != "unknown"):
                active_policy_ids.add(cell["policy_id"])
        
        # Filter columns to keep only active policies
        filtered_columns = [col for col in columns if col["policy_id"] in active_policy_ids]
        
        # Filter cells to keep only active policies
        filtered_cells = [cell for cell in cells if cell["policy_id"] in active_policy_ids]
        
        self.logger.info(
            f"Filtered out {len(columns) - len(filtered_columns)} policies with all-None/unknown impact "
            f"({len(columns)} -> {len(filtered_columns)} policies)"
        )
        
        return {
            "rows": heatmap_data.get("rows", []),
            "columns": filtered_columns,
            "cells": filtered_cells
        }
