"""Tests for the notebook-based PatternAgent business synthesis flow."""

from __future__ import annotations

import copy
import json
from typing import Any, Dict, List, Optional, Sequence

import pytest
import yaml

from deep_research_core.base_agent import AgentConfigurationError
from deep_research_agents.pattern_agent import DEFAULT_SEMANTIC_CONFIG_PATH
from deep_research_agents.pattern_agent import BusinessPatternSchema
from deep_research_agents.pattern_agent import BusinessPatternScopeSchema
from deep_research_agents.pattern_agent import PatternAgent
from deep_research_agents.pattern_agent import PatternSynthesisSchema
from deep_research_agents.pattern_agent import build_pattern_cards_and_groups
from deep_research_agents.pattern_agent import _build_semantic_card_config
from deep_research_agents.pattern_agent import _extract_analytical_json_from_messages
from deep_research_agents.pattern_agent import _group_cards


def _build_operational_cell(product: str, facility: str, delta_value: float, admissions_delta: float, unit_delta: float) -> Dict[str, Any]:
    return {
        "cell_id": f"{product}-{facility}-{int(delta_value)}",
        "dimension_values": {
            "product_description": product,
            "facility_type": facility,
        },
        "baseline_value": max(delta_value, 1.0),
        "comparison_value": max(delta_value, 1.0) + delta_value,
        "delta_value": delta_value,
        "share_of_positive_delta": 0.45,
        "share_of_net_delta": 0.40,
        "raw_row_count_baseline": 8,
        "raw_row_count_comparison": 12,
        "explainer_metrics": {
            "expense_detail.total_admissions": {
                "baseline": 8,
                "comparison": 8 + admissions_delta,
                "delta": admissions_delta,
            },
            "expense_detail.avg_paid_per_admit": {
                "baseline": 100000,
                "comparison": 100000 + unit_delta,
                "delta": unit_delta,
            },
        },
    }


def _build_validation_level() -> Dict[str, Any]:
    return {
        "level": 1,
        "dimension": "pa_required_code",
        "top_segments": [
            {
                "value": "Y",
                "delta_value": 900000,
                "baseline_value": 200000,
                "comparison_value": 1100000,
                "raw_row_count_baseline": 5,
                "raw_row_count_comparison": 11,
            }
        ],
        "bottom_segments": [
            {
                "value": "-3",
                "delta_value": -500000,
                "baseline_value": 800000,
                "comparison_value": 300000,
                "raw_row_count_baseline": 6,
                "raw_row_count_comparison": 3,
            }
        ],
    }


def _sample_correlation_results(*, small_deltas: bool = False) -> Dict[str, Any]:
    delta_one = 800 if small_deltas else 1_800_000
    delta_two = 700 if small_deltas else 1_250_000
    return {
        "states": {
            "CO": {
                "output": {
                    "root_metric": "expense_detail.total_paid",
                    "baseline_value": 2_000_000,
                    "comparison_value": 3_800_000,
                    "delta_value": delta_one,
                    "drill_path": [_build_validation_level()],
                    "interaction_matrix": {
                        "operational": {
                            "selected_cells": [
                                _build_operational_cell("HMO", "ACUTE HOSPITAL", delta_one, 4, 25000),
                            ]
                        },
                        "clinical": {
                            "selected_cells": [
                                {
                                    "cell_id": "clinical-co",
                                    "dimension_values": {"drg_name": "IP Med/Surg"},
                                    "baseline_value": 300000,
                                    "comparison_value": 520000,
                                    "delta_value": 220000,
                                    "share_of_positive_delta": 0.10,
                                    "raw_row_count_baseline": 3,
                                    "raw_row_count_comparison": 4,
                                    "explainer_metrics": {
                                        "expense_detail.total_admissions": {
                                            "baseline": 3,
                                            "comparison": 4,
                                            "delta": 1,
                                        }
                                    },
                                }
                            ]
                        },
                    },
                }
            },
            "ME": {
                "output": {
                    "root_metric": "expense_detail.total_paid",
                    "baseline_value": 1_500_000,
                    "comparison_value": 2_750_000,
                    "delta_value": delta_two,
                    "drill_path": [_build_validation_level()],
                    "interaction_matrix": {
                        "operational": {
                            "selected_cells": [
                                _build_operational_cell("HMO", "ACUTE HOSPITAL", delta_two, 3, 18000),
                            ]
                        },
                        "clinical": {
                            "selected_cells": [
                                {
                                    "cell_id": "clinical-me",
                                    "dimension_values": {"drg_name": "Residential treatment center"},
                                    "baseline_value": 250000,
                                    "comparison_value": 430000,
                                    "delta_value": 180000,
                                    "share_of_positive_delta": 0.08,
                                    "raw_row_count_baseline": 2,
                                    "raw_row_count_comparison": 3,
                                    "explainer_metrics": {
                                        "expense_detail.total_admissions": {
                                            "baseline": 2,
                                            "comparison": 3,
                                            "delta": 1,
                                        }
                                    },
                                }
                            ]
                        },
                    },
                }
            },
        },
        "providers": {},
        "drgs": {},
    }


def _base_context(*, small_deltas: bool = False) -> Dict[str, Any]:
    return {
        "anomaly_context": {},
        "deep_dive_report": {},
        "filters": [
            {"field": "snap_month", "operator": "=", "value": 202604, "source": "base_context"},
            {"field": "lob_description", "operator": "=", "value": "Commercial", "source": "base_context"},
        ],
        "correlation_results": _sample_correlation_results(small_deltas=small_deltas),
    }


def _build_analytical_output() -> Dict[str, Any]:
    return build_pattern_cards_and_groups(
        correlation_results=_base_context()["correlation_results"],
        semantic_config_path=str(DEFAULT_SEMANTIC_CONFIG_PATH),
    )


def _format_expected_delta(value: float) -> str:
    sign = "+" if value > 0 else "-" if value < 0 else ""
    absolute = abs(value)
    if absolute >= 1_000_000:
        return f"{sign}${absolute / 1_000_000:.1f}M"
    if absolute >= 1_000:
        rounded = int(round(absolute / 1_000.0) * 1_000)
        return f"{sign}${rounded:,.0f}"
    return f"{sign}${absolute:,.0f}"


def _select_broad_group_and_focus_card() -> tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    analytical_output = _build_analytical_output()
    cards_by_id = {str(card["card_id"]): card for card in analytical_output["cards"]}
    broad_group = next(group for group in analytical_output["groups"] if int(group["impact"]["card_count"]) > 1)
    group_cards = [cards_by_id[str(card_id)] for card_id in broad_group["card_ids"]]
    focus_card = max(group_cards, key=lambda card: abs(float(card["metrics"]["value"]["delta"] or 0.0)))
    return analytical_output, broad_group, focus_card


class _StructuredLLM:
    def __init__(self, response: PatternSynthesisSchema, include_raw: bool) -> None:
        self._response = response
        self._include_raw = include_raw

    def invoke(self, _messages: list[dict[str, str]], **kwargs: object) -> object:
        _ = kwargs
        if self._include_raw:
            return {
                "parsed": self._response,
                "raw": {"usage": {"input_tokens": 12, "output_tokens": 7}},
            }
        return self._response


class _CustomLLM:
    def __init__(self, response: PatternSynthesisSchema) -> None:
        self._response = response

    def with_structured_output(self, _schema: object, **kwargs: object) -> _StructuredLLM:
        return _StructuredLLM(self._response, include_raw=bool(kwargs.get("include_raw")))


def test_pattern_agent_stub_output_builds_business_patterns_from_groups() -> None:
    agent = PatternAgent(test_mode=True)
    result = agent(conversation_id="abc123", context=_base_context())

    assert result["agent"] == "pattern_agent"
    assert result["conversation_id"] == "abc123"
    assert result["visual_component"] == {}
    assert "patterns" not in result["output"]

    groups = result["output"]["groups"]
    cards = result["output"]["cards"]
    business_patterns = result["output"]["business_patterns"]

    assert groups
    assert cards
    assert business_patterns
    assert result["output"]["quality_checks"]["patterns_returned"] == len(business_patterns)
    assert business_patterns[0]["source_group_ids"]
    assert business_patterns[0]["source_card_ids"]
    assert any(pattern["pattern_type"] == "coding_mapping_validation" for pattern in business_patterns)
    assert business_patterns[0]["top_pattern"] == groups[0]["pattern_name"]


def test_pattern_agent_returns_empty_business_patterns_when_no_groups_pass_threshold() -> None:
    agent = PatternAgent(test_mode=True)
    context = _base_context(small_deltas=True)
    context["min_abs_delta"] = 2_000_000

    result = agent(conversation_id="no_groups", context=context)

    assert result["status"] == "success"
    assert result["output"]["groups"] == []
    assert result["output"]["business_patterns"] == []
    assert result["output"]["quality_checks"]["patterns_returned"] == 0
    assert any("no analytical groups" in note.lower() for note in result["output"]["quality_checks"]["notes"])


def test_pattern_agent_validation_fails_for_unknown_trace_ids_from_structured_output() -> None:
    response = PatternSynthesisSchema(
        business_patterns=[
            BusinessPatternSchema(
                pattern_rank=1,
                top_pattern="Invalid trace pattern",
                pattern_type="utilization_growth",
                what_is_impacting="Commercial HMO / Acute Hospital",
                priority_entities={"states": ["CO"], "providers": [], "products": ["HMO"], "facility_types": ["ACUTE HOSPITAL"], "clinical_categories": []},
                key_driver_codes=["HMO"],
                impact_summary={
                    "primary_metric": "total_paid",
                    "direction": "increase",
                    "estimated_delta": "+$1.8M",
                    "volume_signal": "admissions up",
                    "unit_cost_signal": "unknown",
                },
                pattern_details="Synthetic invalid pattern for validation.",
                why_it_matters="Synthetic invalid pattern for validation.",
                recommended_next_step="Synthetic invalid pattern for validation.",
                validation_needed=False,
                validation_reason=None,
                downstream_routes=["um_operations_agent"],
                evidence_summary=["Synthetic invalid evidence."],
                source_group_ids=["missing-group"],
                source_card_ids=["missing-card"],
            )
        ]
    )
    agent = PatternAgent(test_mode=True)
    agent.llm = _CustomLLM(response)

    result = agent(conversation_id="invalid_trace", context=_base_context())

    assert result["status"] == "failed"
    assert result["tokens"]["input"] == 12
    assert result["tokens"]["output"] == 7
    assert any("unknown source_group_ids" in error.lower() for error in result["validation"]["errors"])
    assert any("unknown source_card_ids" in error.lower() for error in result["validation"]["errors"])


def test_pattern_agent_uses_selected_cards_for_pattern_attribution() -> None:
    _, broad_group, focus_card = _select_broad_group_and_focus_card()
    expected_delta = _format_expected_delta(float(focus_card["metrics"]["value"]["delta"]))

    response = PatternSynthesisSchema(
        business_patterns=[
            BusinessPatternSchema(
                pattern_rank=1,
                top_pattern="Focused utilization story",
                pattern_type="utilization_growth",
                what_is_impacting="Commercial HMO / Acute Hospital",
                priority_entities={
                    "states": ["CO", "ME"],
                    "providers": ["UNRELATED HEALTH SYSTEM"],
                    "products": ["HMO"],
                    "facility_types": ["ACUTE HOSPITAL"],
                    "clinical_categories": ["UNRELATED CATEGORY"],
                },
                key_driver_codes=["HMO", "ACUTE HOSPITAL"],
                impact_summary={
                    "primary_metric": "total_paid",
                    "direction": "increase",
                    "estimated_delta": expected_delta,
                    "volume_signal": "admissions up",
                    "unit_cost_signal": "unknown",
                },
                pattern_details="Synthetic pattern for testing LLM response preservation.",
                why_it_matters="Synthetic pattern for testing LLM response preservation.",
                recommended_next_step="Synthetic pattern for testing LLM response preservation.",
                validation_needed=False,
                validation_reason=None,
                downstream_routes=["um_operations_agent"],
                evidence_summary=["Synthetic evidence summary."],
                source_group_ids=[str(broad_group["group_id"])],
                source_card_ids=[str(focus_card["card_id"])],
            )
        ]
    )
    agent = PatternAgent(test_mode=True)
    agent.llm = _CustomLLM(response)

    result = agent(conversation_id="coverage_regression", context=_base_context())

    business_pattern = result["output"]["business_patterns"][0]
    quality_checks = result["output"]["quality_checks"]

    # Verify the agent preserves the LLM's structured output
    assert result["status"] == "success"
    assert business_pattern["source_group_ids"] == [str(broad_group["group_id"])]
    assert business_pattern["source_card_ids"] == [str(focus_card["card_id"])]
    # The agent preserves the LLM's priority_entities as-is
    assert business_pattern["priority_entities"]["states"] == ["CO", "ME"]
    assert business_pattern["priority_entities"]["products"] == ["HMO"]
    assert business_pattern["priority_entities"]["facility_types"] == ["ACUTE HOSPITAL"]
    assert business_pattern["priority_entities"]["providers"] == ["UNRELATED HEALTH SYSTEM"]
    assert business_pattern["impact_summary"]["estimated_delta"] == expected_delta
    assert quality_checks["groups_consumed"] == 1
    assert quality_checks["ungrouped_group_ids"]


# ---------------------------------------------------------------------------
# Config-driven pattern segmentation
#
# `service_area_state`, `lob_description` and `pa_required_code` are all real
# dimensions in the default eCAP semantic view, so segmentation is exercised
# through the explicit `segment_by=` argument and no YAML needs a
# `pattern_segmentation` block. The default view deliberately has none, which is
# what keeps the four tests above byte-identical.
# ---------------------------------------------------------------------------

ANALYSIS_MODE = "cost_change_investigation_over_time_window"
SEMANTIC_PATH = str(DEFAULT_SEMANTIC_CONFIG_PATH)

# Below the default `min_row_count` of 25, so every segment reads as immaterial.
IMMATERIAL_ROWS = 12
# Above it, so a segment can hold its own group.
MATERIAL_ROWS = 90


def _correlation_results_with_state(
    *,
    in_cells: bool = True,
    in_drill: bool = False,
    in_filter_groups: bool = False,
    row_count: int = MATERIAL_ROWS,
    include_lob: bool = False,
    extra_states: Sequence[str] = (),
) -> Dict[str, Any]:
    """Sample results carrying a state value on a chosen provenance tier.

    `in_cells` puts the state in the interaction cell itself (provenance
    `interaction_cell`); `in_filter_groups` pins it as a run-scope hard filter
    the way the ETL fan-out does (provenance `hard_filter`); `in_drill` adds a
    state drill level so it arrives as inherited drill context instead
    (provenance `drill_context`). The drill tier is the only one that reaches
    drill-validation cards, which is what makes the validation-driver
    segmentation test possible.
    """
    results = copy.deepcopy(_sample_correlation_results())

    # Extra states clone an existing node so one signature can hold more than two
    # segments, which is what makes cap overflow observable: a cap can never
    # reduce a signature below "kept + one residual" without dropping cards.
    for index, extra_state in enumerate(extra_states):
        clone = copy.deepcopy(results["states"]["CO"])
        for stage_payload in clone["output"]["interaction_matrix"].values():
            for cell in stage_payload["selected_cells"]:
                cell["cell_id"] = f"{cell['cell_id']}-{extra_state}"
        results["states"][extra_state] = clone

    for state, node in results["states"].items():
        output = node["output"]

        if in_drill:
            output["drill_path"].append(
                {
                    "level": 2,
                    "dimension": "service_area_state",
                    "top_segments": [
                        {
                            "value": state,
                            "delta_value": output["delta_value"],
                            "baseline_value": output["baseline_value"],
                            "comparison_value": output["comparison_value"],
                            "raw_row_count_baseline": row_count // 2,
                            "raw_row_count_comparison": row_count,
                        }
                    ],
                    "bottom_segments": [],
                }
            )

        for stage_payload in output["interaction_matrix"].values():
            if in_filter_groups:
                stage_payload["selected_cell_filter_groups"] = [
                    [
                        {
                            "field": "service_area_state",
                            "operator": "=",
                            "value": state,
                            "source": "dimension_match",
                        }
                    ]
                ]

            for cell in stage_payload["selected_cells"]:
                if in_cells:
                    cell["dimension_values"]["service_area_state"] = state
                    if include_lob:
                        cell["dimension_values"]["lob_description"] = "Commercial"
                cell["raw_row_count_baseline"] = row_count // 2
                cell["raw_row_count_comparison"] = row_count

    return results


def _build(
    correlation_results: Dict[str, Any],
    segment_by: Optional[Sequence[str]] = None,
    semantic_config_path: Optional[str] = None,
) -> Dict[str, Any]:
    return build_pattern_cards_and_groups(
        correlation_results=correlation_results,
        semantic_config_path=semantic_config_path or SEMANTIC_PATH,
        segment_by=segment_by,
    )


def _semantic_path_with_segmentation(
    tmp_path: Any,
    *,
    segment_by: Sequence[str],
    downstream_filters: Optional[Dict[str, str]] = None,
    name: str = "view.yaml",
) -> str:
    """The default view with a `pattern_segmentation` block written in.

    `downstream_filters` is YAML-only by design - there is no API override -
    because the mapping states what a dimension *means* to a downstream API, and
    that belongs with the view definition rather than with a per-request
    argument. So exercising it means writing a real config.
    """
    semantic = yaml.safe_load(DEFAULT_SEMANTIC_CONFIG_PATH.read_text())
    block: Dict[str, Any] = {
        "segment_by": list(segment_by),
        "materiality": {"min_share_of_signature": 0.0, "min_row_count": 0},
    }
    if downstream_filters is not None:
        block["downstream_filters"] = dict(downstream_filters)

    for mode in semantic.get("analysis_modes") or []:
        if mode.get("name") == ANALYSIS_MODE:
            mode["pattern_segmentation"] = block
            break
    else:  # pragma: no cover - guards a rename of the default analysis mode
        raise AssertionError(f"analysis mode {ANALYSIS_MODE} not found in the default view")

    path = tmp_path / name
    path.write_text(yaml.safe_dump(semantic, sort_keys=False))
    return str(path)


def _cfg_with_segmentation(segment_by: Sequence[str], **overrides: Any) -> Dict[str, Any]:
    """Real config for the default view, with the segmentation block overridden.

    `build_pattern_cards_and_groups` only exposes `segment_by`; the materiality
    and cap knobs are YAML-only, so exercising them means building the config and
    calling `_group_cards` directly rather than writing a throwaway YAML.
    """
    semantic = yaml.safe_load(DEFAULT_SEMANTIC_CONFIG_PATH.read_text())
    cfg = _build_semantic_card_config(semantic, ANALYSIS_MODE, segment_by=list(segment_by))
    cfg["segmentation"].update(overrides)
    return cfg


def _segment_groups(groups: List[Dict[str, Any]], driver_group: str) -> List[Dict[str, Any]]:
    return [group for group in groups if group.get("driver_group") == driver_group]


def _impact_summary(delta: str) -> Dict[str, Any]:
    return {
        "primary_metric": "total_paid",
        "direction": "increase",
        "estimated_delta": delta,
        "volume_signal": "admissions up",
        "unit_cost_signal": "unknown",
    }


def _pattern_for_group(
    group: Dict[str, Any],
    *,
    rank: int = 1,
    delta: str = "+$1.0M",
    scope: Optional[Dict[str, Any]] = None,
    states: Optional[List[str]] = None,
) -> BusinessPatternSchema:
    payload: Dict[str, Any] = {
        "pattern_rank": rank,
        "top_pattern": f"Synthetic pattern {rank}",
        "pattern_type": "utilization_growth",
        "what_is_impacting": "Commercial HMO / Acute Hospital",
        "priority_entities": {
            "states": states if states is not None else [],
            "providers": [],
            "products": ["HMO"],
            "facility_types": ["ACUTE HOSPITAL"],
            "clinical_categories": [],
        },
        "key_driver_codes": ["HMO"],
        "impact_summary": _impact_summary(delta),
        "pattern_details": "Synthetic pattern for segmentation tests.",
        "why_it_matters": "Synthetic pattern for segmentation tests.",
        "recommended_next_step": "Synthetic pattern for segmentation tests.",
        "validation_needed": False,
        "validation_reason": None,
        "downstream_routes": ["um_operations_agent"],
        "evidence_summary": ["Synthetic evidence."],
        "source_group_ids": [str(group["group_id"])],
        "source_card_ids": [str(card_id) for card_id in group["card_ids"][:2]],
    }
    if scope is not None:
        payload["scope"] = scope
    return BusinessPatternSchema(**payload)


class _SpyStructuredLLM:
    def __init__(self, response: PatternSynthesisSchema, sink: List[Any], include_raw: bool) -> None:
        self._response = response
        self._sink = sink
        self._include_raw = include_raw

    def invoke(self, messages: list[dict[str, str]], **kwargs: object) -> object:
        _ = kwargs
        self._sink.append(messages)
        if self._include_raw:
            return {"parsed": self._response, "raw": {"usage": {"input_tokens": 1, "output_tokens": 1}}}
        return self._response


class _SpyLLM:
    """Custom LLM that records the prompt messages it was handed."""

    def __init__(self, response: PatternSynthesisSchema) -> None:
        self._response = response
        self.captured: List[Any] = []

    def with_structured_output(self, _schema: object, **kwargs: object) -> _SpyStructuredLLM:
        return _SpyStructuredLLM(self._response, self.captured, include_raw=bool(kwargs.get("include_raw")))


def test_group_ids_identical_when_segmentation_disabled() -> None:
    """The backward-compatibility contract: no segment config, no observable change.

    Compares the whole payload, not just `group_id`, because `_hash_obj` is
    `repr`-based so any tuple reordering in the key would surface here.
    """
    results = _base_context()["correlation_results"]

    no_arg = _build(results)
    explicit_none = _build(results, segment_by=None)
    explicit_empty = _build(results, segment_by=[])

    assert json.dumps(no_arg, sort_keys=True, default=str) == json.dumps(explicit_none, sort_keys=True, default=str)
    assert json.dumps(no_arg, sort_keys=True, default=str) == json.dumps(explicit_empty, sort_keys=True, default=str)

    # The five segmentation keys and the stats block stay absent, not empty.
    for group in no_arg["groups"]:
        for key in ("segment", "segment_values", "segment_provenance", "segment_signature", "segment_collapsed"):
            assert key not in group
    assert "segmentation" not in no_arg["stats"]


def test_unknown_segment_dimension_raises_configuration_error() -> None:
    with pytest.raises(AgentConfigurationError) as excinfo:
        _build(_base_context()["correlation_results"], segment_by=["not_a_real_dimension"])

    assert "not_a_real_dimension" in str(excinfo.value)


def test_segment_dimension_accepts_table_qualified_name() -> None:
    results = _correlation_results_with_state()

    bare = _build(results, segment_by=["service_area_state"])
    qualified = _build(results, segment_by=["expense_detail.service_area_state"])

    assert [group["group_id"] for group in bare["groups"]] == [group["group_id"] for group in qualified["groups"]]


def test_segment_by_splits_groups_on_literal_dimension_value() -> None:
    results = _correlation_results_with_state()

    segmented = _build(results, segment_by=["service_area_state"])
    operational = _segment_groups(segmented["groups"], "mixed_volume_unit_cost")

    assert len(operational) == 2
    assert sorted(group["segment_values"] for group in operational) == [["CO"], ["ME"]]
    # Distinct groups, but the same signature: the segment is the only difference.
    assert len({group["group_id"] for group in operational}) == 2
    assert len({group["segment_signature"] for group in operational}) == 1
    for group in operational:
        assert group["segment"] == {"service_area_state": group["segment_values"]}
        assert group["segment_collapsed"] is False


def test_validation_driver_cards_are_segmented() -> None:
    """Regression guard for the two validation-driver early returns.

    `_operational_group_key` returns before building `key_parts` for
    `coding_validation` / `mapping_validation`, so a segment part appended inside
    that function would never reach those cards and every gating-validation
    pattern would pool across all states. Splicing in the `_group_key` wrapper is
    what makes this pass.
    """
    results = _correlation_results_with_state(in_cells=False, in_drill=True)

    segmented = _build(results, segment_by=["service_area_state"])
    validation = _segment_groups(segmented["groups"], "coding_validation")

    assert len(validation) == 2, "validation-driver cards pooled instead of segmenting"
    assert sorted(group["segment_values"] for group in validation) == [["CO"], ["ME"]]
    assert len({group["segment_signature"] for group in validation}) == 1


def test_operational_fallback_role_survives_segmentation() -> None:
    """Regression guard for the `len(key_parts) == 2` fallback branch.

    Appending a segment part inside `_operational_group_key` would make that
    branch permanently dead, keying cards on `(stage, driver_group, segment)`
    alone and merging distinct business drivers under one segment.
    """
    results = _correlation_results_with_state()
    segmented = _build(results, segment_by=["service_area_state"])

    for group in _segment_groups(segmented["groups"], "mixed_volume_unit_cost"):
        key = group["group_key"]
        segment_parts = [part for part in key[2:] if str(part[0]).startswith("segment:")]
        role_parts = [part for part in key[2:] if not str(part[0]).startswith("segment:")]

        assert segment_parts, "segment part missing from the key"
        assert role_parts, "driver discriminator was displaced by the segment part"
        # Stage and driver stay in slots 0 and 1 for `_summarize_group`.
        assert key[0] == "operational"
        assert key[1] == "mixed_volume_unit_cost"


def test_segment_collapse_merges_immaterial_segments() -> None:
    results = _correlation_results_with_state(row_count=IMMATERIAL_ROWS)

    segmented = _build(results, segment_by=["service_area_state"])
    operational = _segment_groups(segmented["groups"], "mixed_volume_unit_cost")

    assert len(operational) == 1
    merged = operational[0]
    assert merged["segment_collapsed"] is True
    # Literal values only, never an invented rollup label.
    assert merged["segment_values"] == ["CO", "ME"]
    assert segmented["stats"]["segmentation"]["segments_collapsed"] > 0


def test_max_segment_groups_collapses_never_drops() -> None:
    """Overflow merges into the residual group; it is never discarded.

    A dropped card would land in `ungrouped_group_ids` and degrade every run to
    `partial_success`. Three states are needed for the cap to be observable at
    all: a cap can never take a signature below "kept + one residual", so with
    only two segments the outcome is two groups either way.
    """
    results = _correlation_results_with_state(extra_states=("TX",))
    cards = _build(results, segment_by=["service_area_state"])["cards"]

    uncapped_cfg = _cfg_with_segmentation(
        ["service_area_state"],
        materiality={"min_share_of_signature": 0.0, "min_row_count": 0.0, "min_abs_delta": None},
    )
    uncapped_groups, _ = _group_cards(list(cards), uncapped_cfg, max_top_cards_per_group=5)

    cfg = _cfg_with_segmentation(
        ["service_area_state"],
        max_segment_groups=1,
        materiality={"min_share_of_signature": 0.0, "min_row_count": 0.0, "min_abs_delta": None},
    )
    groups, stats = _group_cards(list(cards), cfg, max_top_cards_per_group=5)

    # Nothing dropped: every card is still grouped exactly once.
    assert sum(int(group["impact"]["card_count"]) for group in groups) == len(cards)
    grouped_card_ids = {card_id for group in groups for card_id in group["card_ids"]}
    assert grouped_card_ids == {str(card["card_id"]) for card in cards}
    # `_group_cards` returns the segmentation stats directly; the caller nests them.
    assert stats["segments_capped"] > 0
    # The cap genuinely reduced the group count rather than merely relabelling.
    assert len(groups) < len(uncapped_groups)


def test_segment_provenance_reports_drill_context() -> None:
    results = _correlation_results_with_state(in_cells=False, in_drill=True)

    segmented = _build(results, segment_by=["service_area_state"])

    assert segmented["groups"]
    for group in segmented["groups"]:
        assert group["segment_provenance"] == "drill_context"
    provenance = segmented["stats"]["segmentation"]["provenance_counts"]
    assert provenance.get("drill_context")
    assert not provenance.get("unattributed")


def test_segment_resolves_from_run_scope_hard_filter() -> None:
    """A fan-out run pins its state as a hard filter, not a cell dimension.

    `exclude_if_filtered` keeps a pinned dimension out of the GROUP BY, so the
    ETL fan-out shape carries the state only in `selected_cell_filter_groups`.
    Without this tier every card resolves to UNATTRIBUTED and a state-segmented
    run collapses back to a single pattern.
    """
    results = _correlation_results_with_state(in_cells=False, in_filter_groups=True)

    segmented = _build(results, segment_by=["service_area_state"])

    segmentation = segmented["stats"]["segmentation"]
    assert segmentation["unattributed_cards"] == 0
    assert segmentation["provenance_counts"].get("hard_filter")
    assert "UNATTRIBUTED" not in segmentation["groups_by_segment"]
    assert len(segmentation["groups_by_segment"]) >= 2


def test_varying_filter_group_field_is_not_a_run_constant() -> None:
    """Only a value consistent across every group scopes the run.

    A field whose value differs between filter groups is discriminating cells,
    not pinning the run, so it must not be attributed to every card.
    """
    results = _correlation_results_with_state(in_cells=False, in_filter_groups=True)
    for node in results["states"].values():
        for stage_payload in node["output"]["interaction_matrix"].values():
            stage_payload["selected_cell_filter_groups"] = [
                [{"field": "service_area_state", "operator": "=", "value": "CO"}],
                [{"field": "service_area_state", "operator": "=", "value": "ME"}],
            ]

    segmented = _build(results, segment_by=["service_area_state"])

    segmentation = segmented["stats"]["segmentation"]
    assert not segmentation["provenance_counts"].get("hard_filter")
    assert segmentation["unattributed_cards"] > 0


def test_cell_dimension_outranks_run_scope_hard_filter() -> None:
    """Tier order holds: a cell's own value beats a conflicting run-scope filter.

    Drill-validation cards carry no cell-level state, so they legitimately
    resolve on the filter tier. What must never happen is a run-scope filter
    overriding an interaction cell that carries its own value.
    """
    results = _correlation_results_with_state(in_cells=True, in_filter_groups=True)
    # Force a conflict: the filter group claims a state no cell ever carries.
    for node in results["states"].values():
        for stage_payload in node["output"]["interaction_matrix"].values():
            stage_payload["selected_cell_filter_groups"] = [
                [{"field": "service_area_state", "operator": "=", "value": "ZZ"}]
            ]

    segmented = _build(results, segment_by=["service_area_state"])

    attributed = [
        group
        for group in segmented["groups"]
        if group.get("segment_provenance") == "interaction_cell"
    ]
    assert attributed
    assert all("ZZ" not in group["segment_values"] for group in attributed)


def test_drill_path_distribution_counts_as_attributed() -> None:
    """A drilled dimension's own value is real, not unattributed.

    Drill-validation cards record `drill_path_distribution` as the source for the
    dimension they drilled. Bucketing that as unattributed would inflate the
    counters and falsely fire the provenance quality note.
    """
    segmented = _build(_base_context()["correlation_results"], segment_by=["pa_required_code"])

    segmentation = segmented["stats"]["segmentation"]
    assert segmentation["unattributed_cards"] == 0
    assert segmentation["provenance_counts"].get("interaction_cell")
    assert "drill_path_distribution" not in segmentation["provenance_counts"]


def test_unattributed_segment_is_labeled_and_counted() -> None:
    # The base sample carries no state anywhere, so every card is unattributed.
    segmented = _build(_base_context()["correlation_results"], segment_by=["service_area_state"])

    segmentation = segmented["stats"]["segmentation"]
    assert segmentation["unattributed_cards"] > 0
    assert segmentation["unattributed_delta"] > 0
    assert any(group["segment_values"] == ["UNATTRIBUTED"] for group in segmented["groups"])
    assert segmentation["provenance_counts"].get("unattributed")


def test_multi_dimension_segment_by() -> None:
    """State x LOB works with no code change, and key ordering is deterministic."""
    results = _correlation_results_with_state(include_lob=True)

    first = _build(results, segment_by=["service_area_state", "lob_description"])
    second = _build(results, segment_by=["service_area_state", "lob_description"])

    assert [group["group_id"] for group in first["groups"]] == [group["group_id"] for group in second["groups"]]
    assert first["stats"]["segmentation"]["segment_by"] == ["service_area_state", "lob_description"]

    operational = _segment_groups(first["groups"], "mixed_volume_unit_cost")
    assert operational
    for group in operational:
        assert set(group["segment"]) == {"service_area_state", "lob_description"}
        assert group["segment"]["lob_description"] == ["Commercial"]


def test_prompt_omits_full_cards_but_retains_group_card_ids() -> None:
    """The prompt drops the `cards` array; the emitted output keeps it."""
    analytical = _build(_base_context()["correlation_results"])
    response = PatternSynthesisSchema(business_patterns=[_pattern_for_group(analytical["groups"][0])])

    agent = PatternAgent(test_mode=True)
    spy = _SpyLLM(response)
    agent.llm = spy

    result = agent(conversation_id="prompt_payload", context=_base_context())

    assert spy.captured, "LLM was never invoked"
    # Parse the payload back out of the prompt rather than substring-matching the
    # serialized messages, where the inner JSON quotes are escaped and any
    # `"cards"` check would pass vacuously.
    payload = _extract_analytical_json_from_messages(spy.captured[0])
    assert payload, "no analytical JSON found in the prompt"
    assert "cards" not in payload
    assert payload["groups"]
    # Group-level card ids stay in the prompt so source_card_ids remain reachable.
    assert payload["groups"][0]["card_ids"]
    assert str(analytical["groups"][0]["card_ids"][0]) in payload["groups"][0]["card_ids"]
    # The emitted payload is unchanged.
    assert result["output"]["cards"]
    assert result["output"]["groups"][0]["card_ids"]


def test_max_patterns_enforced_on_llm_path() -> None:
    analytical = _build(_base_context()["correlation_results"])
    groups = analytical["groups"]
    deltas = ["+$9.0M", "+$8.0M", "+$7.0M", "+$6.0M"]
    patterns = [
        _pattern_for_group(groups[index % len(groups)], rank=index + 1, delta=deltas[index % len(deltas)])
        for index in range(len(deltas))
    ]

    agent = PatternAgent(test_mode=True)
    agent.llm = _CustomLLM(PatternSynthesisSchema(business_patterns=patterns))

    context = _base_context()
    context["max_patterns"] = 2
    result = agent(conversation_id="cap_llm_path", context=context)

    business_patterns = result["output"]["business_patterns"]
    assert len(business_patterns) == 2
    assert [pattern["pattern_rank"] for pattern in business_patterns] == [1, 2]
    # Highest absolute impact survives the cut.
    assert business_patterns[0]["impact_summary"]["estimated_delta"] == "+$9.0M"
    assert result["output"]["quality_checks"]["patterns_returned"] == 2
    assert any("max_patterns" in note or "capped" in note.lower() for note in result["output"]["quality_checks"]["notes"])


def test_scope_is_deterministic_and_llm_invented_labels_are_discarded() -> None:
    """The no-invented-groupings guard.

    `scope` is stamped from the referenced groups, so a model that writes
    "Southeast" cannot get it into the output.
    """
    results = _correlation_results_with_state()
    analytical = _build(results, segment_by=["service_area_state"])
    target = _segment_groups(analytical["groups"], "mixed_volume_unit_cost")[0]

    response = PatternSynthesisSchema(
        business_patterns=[
            _pattern_for_group(
                target,
                scope={
                    "segment_by": ["region"],
                    "segment_values": ["Southeast"],
                    "segment_signatures": ["fabricated"],
                },
                states=["Southeast"],
            )
        ]
    )

    agent = PatternAgent(test_mode=True)
    agent.llm = _CustomLLM(response)

    context = _base_context()
    context["correlation_results"] = results
    context["segment_by"] = ["service_area_state"]
    result = agent(conversation_id="invented_scope", context=context)

    scope = result["output"]["business_patterns"][0]["scope"]
    assert scope["segment_by"] == ["service_area_state"]
    assert scope["segment_values"] == target["segment_values"]
    assert "Southeast" not in scope["segment_values"]
    assert "region" not in scope["segment_by"]
    assert scope["segment_signatures"] == [target["segment_signature"]]


def test_llm_schema_has_no_open_ended_maps() -> None:
    """OpenAI's strict structured output cannot express a free-form-key map.

    Pydantic renders `Dict[str, X]` as `{"type": "object",
    "additionalProperties": {...}}` with no `properties`, and the API rejects the
    *entire* request rather than ignoring the field: "'required' is required to
    be supplied and to be an array including every key in properties. Extra
    required key 'filters' supplied." Pattern synthesis then fails outright.

    So a map on an LLM-facing schema has to be either a fixed-key nested model
    or hidden from the schema the way `BusinessPatternScopeSchema` hides its
    stamped filters.
    """
    offenders: List[str] = []

    def walk(node: Any, path: str) -> None:
        if isinstance(node, dict):
            if isinstance(node.get("additionalProperties"), dict):
                offenders.append(path)
            for key, value in node.items():
                walk(value, f"{path}.{key}")
        elif isinstance(node, list):
            for index, value in enumerate(node):
                walk(value, f"{path}[{index}]")

    walk(PatternSynthesisSchema.model_json_schema(), "PatternSynthesisSchema")

    assert offenders == []


def test_stamped_scope_fields_are_hidden_from_the_schema_but_kept_on_the_model() -> None:
    schema = BusinessPatternScopeSchema.model_json_schema()

    assert set(schema["properties"]) == {
        "segment_by",
        "segment_values",
        "segment_signatures",
    }
    assert "filters" not in schema.get("required", [])

    dumped = BusinessPatternScopeSchema(
        filters={"state": ["CO"]}, filters_attested={"state": True}
    ).model_dump()
    assert dumped["filters"] == {"state": ["CO"]}
    assert dumped["filters_attested"] == {"state": True}


def test_downstream_filter_dimension_must_be_a_real_dimension(tmp_path) -> None:
    path = _semantic_path_with_segmentation(
        tmp_path,
        segment_by=["service_area_state"],
        downstream_filters={"state": "not_a_real_dimension"},
    )

    with pytest.raises(AgentConfigurationError) as excinfo:
        _build(_correlation_results_with_state(), semantic_config_path=path)

    assert "not_a_real_dimension" in str(excinfo.value)


def test_downstream_filter_dimension_must_be_segmented(tmp_path) -> None:
    """A mapped dimension that isn't segmented on has no per-pattern value.

    Failing loudly is the point: silently ignoring the mapping would leave the
    reimbursement agent searching every state while the config claims otherwise.
    """
    path = _semantic_path_with_segmentation(
        tmp_path,
        segment_by=["lob_description"],
        downstream_filters={"state": "service_area_state"},
    )

    with pytest.raises(AgentConfigurationError) as excinfo:
        _build(_correlation_results_with_state(include_lob=True), semantic_config_path=path)

    message = str(excinfo.value)
    assert "service_area_state" in message
    assert "segment_by" in message


def test_cards_omit_segment_filters_when_none_declared(tmp_path) -> None:
    """Segmenting without a `downstream_filters` block changes no card field."""
    path = _semantic_path_with_segmentation(tmp_path, segment_by=["service_area_state"])

    built = _build(_correlation_results_with_state(), semantic_config_path=path)

    assert built["groups"], "segmentation produced no groups"
    assert all("segment_filters" not in card for card in built["cards"])
    assert built["semantic_summary"]["segmentation"]["downstream_filters"] == {}


def test_declared_downstream_filter_resolves_from_run_scope_hard_filter(tmp_path) -> None:
    """The ETL fan-out shape is the case that matters.

    `exclude_if_filtered` drops the pinned state from the GROUP BY, so it reaches
    the card only as a run-scope hard filter. The declared filter must resolve
    from that tier or the reimbursement agent still searches every state.
    """
    path = _semantic_path_with_segmentation(
        tmp_path,
        segment_by=["service_area_state"],
        downstream_filters={"state": "service_area_state"},
    )
    results = _correlation_results_with_state(in_cells=False, in_filter_groups=True)

    built = _build(results, semantic_config_path=path)

    assert built["semantic_summary"]["segmentation"]["downstream_filters"] == {
        "state": "service_area_state"
    }
    resolved = [card["segment_filters"]["state"] for card in built["cards"]]
    assert resolved, "no cards carried a declared filter"
    assert all(values for values in resolved), "a card resolved no state"
    assert {value for values in resolved for value in values} == {"CO", "ME"}


def test_scope_filters_attested_for_fully_pinned_pattern(tmp_path) -> None:
    path = _semantic_path_with_segmentation(
        tmp_path,
        segment_by=["service_area_state"],
        downstream_filters={"state": "service_area_state"},
    )
    results = _correlation_results_with_state(in_cells=False, in_filter_groups=True)
    analytical = _build(results, semantic_config_path=path)
    target = next(
        group for group in analytical["groups"] if group["segment_values"] == ["CO"]
    )

    response = PatternSynthesisSchema(business_patterns=[_pattern_for_group(target)])
    agent = PatternAgent(test_mode=True)
    agent.llm = _CustomLLM(response)

    context = _base_context()
    context["correlation_results"] = results
    context["semantic_config_path"] = path
    result = agent(conversation_id="attested_scope", context=context)

    scope = result["output"]["business_patterns"][0]["scope"]
    assert scope["filters"] == {"state": ["CO"]}
    assert scope["filters_attested"] == {"state": True}


def test_scope_filters_unattested_when_a_source_card_has_no_value(tmp_path) -> None:
    """Mixed evidence is reported as unattested, and still names what it has.

    `post_data["state"]` is a hard filter on the policy_comparison API, so a
    consumer must be able to tell "every card says CO" from "one card says CO and
    the other says nothing" - the second must not narrow the search.
    """
    path = _semantic_path_with_segmentation(
        tmp_path,
        segment_by=["service_area_state"],
        downstream_filters={"state": "service_area_state"},
    )
    results = _correlation_results_with_state(in_cells=True)
    analytical = _build(results, semantic_config_path=path)

    co_group = next(
        group for group in analytical["groups"] if group["segment_values"] == ["CO"]
    )
    pattern = _pattern_for_group(co_group)
    # Splice in a card from a different signature that carries no state at all,
    # which is exactly what an LLM citing across segments produces.
    stateless = next(
        card
        for card in analytical["cards"]
        if not (card.get("segment_filters") or {}).get("state")
        and str(card["card_id"]) not in pattern.source_card_ids
    )
    pattern.source_card_ids = [*pattern.source_card_ids, str(stateless["card_id"])]

    agent = PatternAgent(test_mode=True)
    agent.llm = _CustomLLM(PatternSynthesisSchema(business_patterns=[pattern]))

    context = _base_context()
    context["correlation_results"] = results
    context["semantic_config_path"] = path
    result = agent(conversation_id="unattested_scope", context=context)

    scope = result["output"]["business_patterns"][0]["scope"]
    assert scope["filters_attested"] == {"state": False}
    assert scope["filters"]["state"] == ["CO"]


def test_downstream_filters_resolve_state_and_lob_independently(tmp_path) -> None:
    path = _semantic_path_with_segmentation(
        tmp_path,
        segment_by=["service_area_state", "lob_description"],
        downstream_filters={"state": "service_area_state", "lob": "lob_description"},
    )
    results = _correlation_results_with_state(include_lob=True)

    built = _build(results, semantic_config_path=path)

    carrying = [card for card in built["cards"] if card.get("segment_filters")]
    assert carrying
    for card in carrying:
        assert set(card["segment_filters"]) == {"state", "lob"}
    states = {value for card in carrying for value in card["segment_filters"]["state"]}
    lobs = {value for card in carrying for value in card["segment_filters"]["lob"]}
    assert states == {"CO", "ME"}
    assert lobs == {"Commercial"}


def test_lob_segment_value_cannot_survive_as_a_state(tmp_path) -> None:
    """Regression guard for the pooled-segment-values leak.

    The state attestation set is built from the mapped dimension only. Pooling
    every segment dimension's values would let the LOB value "Commercial" pass
    as a state the moment a config segments by state and LOB.
    """
    path = _semantic_path_with_segmentation(
        tmp_path,
        segment_by=["service_area_state", "lob_description"],
        downstream_filters={"state": "service_area_state", "lob": "lob_description"},
    )
    results = _correlation_results_with_state(include_lob=True)
    analytical = _build(results, semantic_config_path=path)
    target = _segment_groups(analytical["groups"], "mixed_volume_unit_cost")[0]

    response = PatternSynthesisSchema(
        business_patterns=[_pattern_for_group(target, states=["Commercial", "CO"])]
    )
    agent = PatternAgent(test_mode=True)
    agent.llm = _CustomLLM(response)

    context = _base_context()
    context["correlation_results"] = results
    context["semantic_config_path"] = path
    result = agent(conversation_id="lob_leak", context=context)

    states = result["output"]["business_patterns"][0]["priority_entities"]["states"]
    # `CO` surviving is what makes the exclusion meaningful: the attestation set
    # is populated and still rejects the LOB value.
    assert states == ["CO"]


def test_pattern_name_keeps_driver_label_alongside_segment() -> None:
    """Guard for the `label_parts[:3]` cap in `_pattern_name`.

    Segment values lead `group_key[2:]`, so an unfixed cap would consume every
    slot and give each pattern in a segment an identical name.
    """
    results = _correlation_results_with_state()
    segmented = _build(results, segment_by=["service_area_state"])
    operational = _segment_groups(segmented["groups"], "mixed_volume_unit_cost")

    names = [group["pattern_name"] for group in operational]
    assert len(set(names)) == len(names), "segmented patterns share a name"
    for group in operational:
        name = group["pattern_name"]
        assert group["segment_values"][0] in name
        # The driver discriminator is still present, not crowded out.
        assert "HMO" in name or "ACUTE HOSPITAL" in name
