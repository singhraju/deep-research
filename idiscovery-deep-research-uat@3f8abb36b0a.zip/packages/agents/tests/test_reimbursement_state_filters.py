"""
Unit tests for the declared downstream-filter scope on the policy search.

On a segmented run the pattern agent stamps `pattern.scope.filters` from the
dimensions the analysis mode declared in
`pattern_segmentation.downstream_filters`. This module covers how the
reimbursement agent consumes that:

- fully attested  -> the value reaches the policy_comparison filter list
- partly attested -> the filter is *suppressed*, because `post_data["state"]`
  is a hard filter and narrowing would drop the policies that explain the
  unattributed half of the evidence
- unsegmented     -> byte-identical to the behaviour before the field existed

The agent is built via `__new__` to bypass Snowflake / mini-LLM init, matching
the fixture pattern in the sibling reimbursement test modules.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Sequence

import pytest

from deep_research_agents import ReimbursementAgent
from deep_research_agents.reimbursement_agent import LOB_DOWNSTREAM_FILTER
from deep_research_agents.reimbursement_agent import STATE_DOWNSTREAM_FILTER
from deep_research_agents.reimbursement_agent import _scope_filter_suppressed


# ---------------------------------------------------------------------------
# Fixtures / builders
# ---------------------------------------------------------------------------

@pytest.fixture
def agent() -> ReimbursementAgent:
    inst = ReimbursementAgent.__new__(ReimbursementAgent)
    inst.logger = logging.getLogger("test.reimbursement_state_filters")
    inst._token_breakdown = {}
    return inst


def _card(
    card_id: str,
    *,
    segment_filters: Optional[Dict[str, List[str]]] = None,
    canonical_state: Sequence[str] = (),
    canonical_lob: Sequence[str] = (),
) -> Dict[str, Any]:
    """One source card.

    `segment_filters` is the pattern agent's declared-filter resolution;
    `canonical_state` / `canonical_lob` are the pre-existing role buckets. The
    two are deliberately independent here: the ETL fan-out shape pins the state
    with a run-scope WHERE clause, `exclude_if_filtered` drops it from the GROUP
    BY, and so it reaches `segment_filters` while `canonical_dimensions` stays
    empty. That is the case the feature exists for.
    """
    card: Dict[str, Any] = {
        "card_id": card_id,
        "canonical_dimensions": {
            "state": list(canonical_state),
            "line_of_business": list(canonical_lob),
        },
    }
    if segment_filters is not None:
        card["segment_filters"] = {
            name: list(values) for name, values in segment_filters.items()
        }
    return card


def _pattern(
    *,
    card_ids: Sequence[str],
    scope: Optional[Dict[str, Any]] = None,
    states: Sequence[str] = (),
) -> Dict[str, Any]:
    pattern: Dict[str, Any] = {
        "pattern_rank": 1,
        "source_card_ids": list(card_ids),
        "priority_entities": {"states": list(states)},
    }
    if scope is not None:
        pattern["scope"] = scope
    return pattern


def _segmented_scope(
    *,
    filters: Dict[str, List[str]],
    attested: Dict[str, bool],
    segment_values: Sequence[str] = ("CO",),
    segment_by: Sequence[str] = ("service_area_state",),
) -> Dict[str, Any]:
    return {
        "segment_by": list(segment_by),
        "segment_values": list(segment_values),
        "segment_signatures": [],
        "filters": {name: list(values) for name, values in filters.items()},
        "filters_attested": dict(attested),
    }


# ---------------------------------------------------------------------------
# Attested scope
# ---------------------------------------------------------------------------

def test_attested_state_reaches_the_filter_when_cards_have_no_state_role(agent):
    """The fan-out case: no card role attests a state, the declared filter does.

    Before this wiring the `if card_state_values:` gate stayed shut and the
    policy search went out unfiltered for a CO-specific pattern.
    """
    cards = [
        _card("c1", segment_filters={"state": ["CO"]}),
        _card("c2", segment_filters={"state": ["CO"]}),
    ]
    pattern = _pattern(
        card_ids=["c1", "c2"],
        scope=_segmented_scope(filters={"state": ["CO"]}, attested={"state": True}),
    )

    lobs, states, scope_status = agent._extract_lob_and_state_filters(
        pattern, {"cards": cards}
    )

    assert states == ["CO"]
    assert lobs == []
    assert scope_status is not None
    assert scope_status["filters"]["state"] == {
        "attested": True,
        "values": ["CO"],
        "cards_total": 2,
        "cards_missing": 0,
    }


def test_attested_state_unions_with_the_card_role_values(agent):
    """A union, not a replacement.

    The declared value is additional attested evidence rather than a correction
    of the role-derived one, and a union can only widen a hard filter.
    """
    cards = [
        _card("c1", segment_filters={"state": ["CO"]}, canonical_state=["ME"]),
    ]
    pattern = _pattern(
        card_ids=["c1"],
        scope=_segmented_scope(filters={"state": ["CO"]}, attested={"state": True}),
        states=["CO", "ME"],
    )

    _lobs, states, _status = agent._extract_lob_and_state_filters(
        pattern, {"cards": cards}
    )

    assert states == ["CO", "ME"]


def test_attested_state_still_discards_an_llm_invented_value(agent):
    """Wiring the declared filter must not loosen the existing leak guard."""
    cards = [_card("c1", segment_filters={"state": ["CO"]})]
    pattern = _pattern(
        card_ids=["c1"],
        scope=_segmented_scope(filters={"state": ["CO"]}, attested={"state": True}),
        states=["CO", "Southeast"],
    )

    _lobs, states, _status = agent._extract_lob_and_state_filters(
        pattern, {"cards": cards}
    )

    assert states == ["CO"]


def test_declared_lob_and_state_resolve_independently(agent):
    cards = [
        _card("c1", segment_filters={"state": ["CO"], "lob": ["Commercial"]}),
    ]
    pattern = _pattern(
        card_ids=["c1"],
        scope=_segmented_scope(
            filters={"state": ["CO"], "lob": ["Commercial"]},
            attested={"state": True, "lob": True},
            segment_values=["CO", "Commercial"],
            segment_by=["service_area_state", "lob_description"],
        ),
    )

    lobs, states, _status = agent._extract_lob_and_state_filters(
        pattern, {"cards": cards}
    )

    assert states == ["CO"]
    assert lobs == ["Commercial"]


# ---------------------------------------------------------------------------
# Suppression
# ---------------------------------------------------------------------------

def test_partly_attested_state_is_suppressed_not_narrowed(agent):
    """One of two source cards attests no state, so no state filter is sent.

    Narrowing to CO would exclude the policies that explain the second card's
    contribution, and a hard API filter makes that unrecoverable downstream.
    """
    cards = [
        _card("c1", segment_filters={"state": ["CO"]}, canonical_state=["CO"]),
        _card("c2", segment_filters={"state": []}, canonical_state=["CO"]),
    ]
    pattern = _pattern(
        card_ids=["c1", "c2"],
        scope=_segmented_scope(filters={"state": ["CO"]}, attested={"state": False}),
        states=["CO"],
    )

    _lobs, states, scope_status = agent._extract_lob_and_state_filters(
        pattern, {"cards": cards}
    )

    # Empty even though both cards carry a CO state role and the LLM named CO:
    # the role values describe the same partly-attributed evidence.
    assert states == []
    assert scope_status["filters"]["state"]["attested"] is False
    assert scope_status["filters"]["state"]["cards_missing"] == 1
    assert scope_status["filters"]["state"]["cards_total"] == 2
    # The attested value is still reported, so a consumer can say what was
    # skipped rather than only that something was.
    assert scope_status["filters"]["state"]["values"] == ["CO"]


def test_partly_attested_lob_is_suppressed(agent):
    cards = [
        _card("c1", segment_filters={"lob": ["Commercial"]}, canonical_lob=["Commercial"]),
        _card("c2", segment_filters={"lob": []}, canonical_lob=["Commercial"]),
    ]
    pattern = _pattern(
        card_ids=["c1", "c2"],
        scope=_segmented_scope(
            filters={"lob": ["Commercial"]},
            attested={"lob": False},
            segment_values=["Commercial"],
            segment_by=["lob_description"],
        ),
    )

    lobs, _states, scope_status = agent._extract_lob_and_state_filters(
        pattern, {"cards": cards}
    )

    assert lobs == []
    assert scope_status["filters"]["lob"]["attested"] is False


def test_unresolvable_source_cards_count_as_unattested(agent):
    """A pattern whose cards are not in the payload must not narrow anything."""
    pattern = _pattern(
        card_ids=["missing"],
        scope=_segmented_scope(filters={"state": ["CO"]}, attested={"state": False}),
        states=["CO"],
    )

    _lobs, states, scope_status = agent._extract_lob_and_state_filters(
        pattern, {"cards": [_card("other", segment_filters={"state": ["CO"]})]}
    )

    assert states == []
    assert scope_status["filters"]["state"]["cards_total"] == 0


# ---------------------------------------------------------------------------
# Backward compatibility
# ---------------------------------------------------------------------------

def test_unsegmented_pattern_behaves_exactly_as_before(agent):
    """No `scope.segment_by` means the new branch is never entered."""
    cards = [_card("c1", canonical_state=["CO"], canonical_lob=["Commercial"])]
    pattern = _pattern(card_ids=["c1"], states=["CO"])

    lobs, states, scope_status = agent._extract_lob_and_state_filters(
        pattern, {"cards": cards}
    )

    assert scope_status is None
    assert states == ["CO"]
    assert lobs == ["Commercial"]


def test_segmented_pattern_without_declared_filters_behaves_as_before(agent):
    """Segmenting alone changes nothing; only a `downstream_filters` block does."""
    cards = [_card("c1", canonical_state=["CO"])]
    pattern = _pattern(
        card_ids=["c1"],
        scope={
            "segment_by": ["service_area_state"],
            "segment_values": ["CO"],
            "segment_signatures": [],
            "filters": {},
            "filters_attested": {},
        },
        states=["CO"],
    )

    _lobs, states, scope_status = agent._extract_lob_and_state_filters(
        pattern, {"cards": cards}
    )

    assert scope_status is None
    assert states == ["CO"]


# ---------------------------------------------------------------------------
# Suppression helper
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "scope_status,expected",
    [
        (None, False),
        ({}, False),
        ({"filters": {}}, False),
        ({"filters": {"state": {"attested": True, "values": ["CO"]}}}, False),
        ({"filters": {"state": {"attested": False, "values": ["CO"]}}}, True),
        ({"filters": {"lob": {"attested": False, "values": []}}}, False),
    ],
)
def test_scope_filter_suppressed_distinguishes_suppressed_from_absent(
    scope_status: Optional[Dict[str, Any]], expected: bool
) -> None:
    """Only a *declared but unattested* filter counts as suppressed.

    An undeclared filter keeps the pre-existing "not found in cards" warning,
    which is a different situation with the same empty filter list.
    """
    assert _scope_filter_suppressed(scope_status, STATE_DOWNSTREAM_FILTER) is expected


def test_suppression_helper_reads_the_named_filter_only() -> None:
    scope_status = {
        "filters": {
            "state": {"attested": False, "values": ["CO"]},
            "lob": {"attested": True, "values": ["Commercial"]},
        }
    }

    assert _scope_filter_suppressed(scope_status, STATE_DOWNSTREAM_FILTER) is True
    assert _scope_filter_suppressed(scope_status, LOB_DOWNSTREAM_FILTER) is False


# ---------------------------------------------------------------------------
# extract_result surface
# ---------------------------------------------------------------------------

def _graph_output(scope_filter_status: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        "pattern_rank": 1,
        "pattern": {"pattern_title": "CO inpatient authorization spend"},
        "result": [{"some": "policy"}],
        "formatted_output": {"summary_table": {}, "individual_policies": []},
        "recommended_action": [],
        "cpt_codes": "99284",
        "drg_codes": [],
        "elevance_executive_summary": None,
        "conversation_id": "demo_001",
        "job_id": "j1",
        "start_time": None,
        "scope_filter_status": scope_filter_status,
    }


def test_extract_result_reports_an_attested_filter_as_passed(agent):
    out = agent.extract_result(
        _graph_output(
            {
                "segment_by": ["service_area_state"],
                "segment_values": ["CO"],
                "filters": {
                    "state": {
                        "attested": True,
                        "values": ["CO"],
                        "cards_total": 2,
                        "cards_missing": 0,
                    }
                },
            }
        )
    )

    checks = [
        check
        for check in out["validation"]["checks"]
        if check["check"] == "state_filter_attested"
    ]
    assert len(checks) == 1
    assert checks[0]["passed"] is True
    assert "['CO']" in checks[0]["message"]


def test_extract_result_reports_a_suppressed_filter_as_failed(agent):
    """A failed check here is a report, not an error.

    It says the search stayed deliberately broad, and names the value it
    declined to narrow to so a reviewer can judge the call.
    """
    out = agent.extract_result(
        _graph_output(
            {
                "segment_by": ["service_area_state"],
                "segment_values": ["CO", "UNATTRIBUTED"],
                "filters": {
                    "state": {
                        "attested": False,
                        "values": ["CO"],
                        "cards_total": 2,
                        "cards_missing": 1,
                    }
                },
            }
        )
    )

    checks = [
        check
        for check in out["validation"]["checks"]
        if check["check"] == "state_filter_attested"
    ]
    assert len(checks) == 1
    assert checks[0]["passed"] is False
    assert "suppressed" in checks[0]["message"]
    assert "1 of 2" in checks[0]["message"]
    assert "CO, UNATTRIBUTED" in checks[0]["message"]


def test_extract_result_emits_no_filter_check_on_an_unsegmented_run(agent):
    out = agent.extract_result(_graph_output(None))

    assert not [
        check
        for check in out["validation"]["checks"]
        if check["check"].endswith("_filter_attested")
    ]
