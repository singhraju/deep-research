# Utils Package - Agent Instructions

## Overview
`deep-research-utils` holds the cross-cutting helpers that agents, the UI, and the ETL pipeline all reach for: EHAP/LLM transport, Snowflake helpers, the semantic-view loader, vault config, logging, caching, and retry.

## Package Structure
```
packages/utils/
├── src/
│   └── deep_research_utils/
│       ├── __init__.py          # public exports
│       ├── app_constant.py      # AppConstants
│       ├── logger_config.py     # get_logger, setup_logging, cleanup_old_logs, LogLevel, PolicyExtractorLogger
│       ├── connections.py       # get_snowpark, snowpark_session, get_ehap, make_llm, LLMHandle
│       ├── ehap.py              # EHAPBase, EHAP — Elevance Health API Platform client
│       ├── ehap_retry.py        # llm_invoke, structured_llm_invoke, post_req, invoke_with_token_retry
│       ├── snowflake_helper.py  # SnowparkHelper, PerformanceMetrics
│       ├── semantic_view.py     # update_semantic_view_sample_values, validate_semantic_view_config
│       ├── vault_config.py      # secrets / vault loader
│       ├── cache_utils.py       # cache helpers (Redis key handling, etc.)
│       ├── retry_helper.py      # generic retry decorators / utilities
│       └── examples/            # usage examples
├── pyproject.toml
├── README.md
├── SEMANTIC_VIEW_UPDATE_SUMMARY.md
└── AGENTS.md (this file)
```

## What Each Module Does
- **`connections`** — Start here before hand-rolling any connection. `snowpark_session()` yields a connected `SnowparkHelper` and closes it in a `finally`; `get_snowpark()` returns one you own the teardown of; `get_ehap()` builds an `EHAPBase`; `make_llm()` builds a `ChatOpenAI` that is actually pointed at the gateway (`base_url` + shared httpx clients); `LLMHandle` is a thread-safe client holder with generation-counted token refresh for batch jobs longer than the 1800s `CACHE_TTL`. Do not construct `SnowparkHelper` or `ChatOpenAI` directly in new code — the drift these functions exist to prevent is real (clients missing `base_url` silently reach the public OpenAI endpoint; pools opened and never closed).
- **`ehap` / `ehap_retry`** — Token-aware client for the EHAP LLM bridge. Prefer `llm_invoke` / `structured_llm_invoke` from `ehap_retry` over calling `EHAP` directly; they handle token-expiry retry. The token endpoint path is `AppConstants.EHAP_TOKEN_PATH` (default `/v2/oauth2/token`, env-overridable); the unversioned `/oauth2/token` returns 404. `EHAP_BASE_URL` is spelled inconsistently across environments — some carry the `/v2` prefix already — so `_resolve_token_url()` drops any leading part of the token path the base URL already ends with; both spellings resolve to the same URL. Note that `app_constant.py` calls `load_dotenv(override=True)`, so `.env` **wins over an exported shell variable**. Set the value in `.env`; exporting it in your shell has no effect.
- **`snowflake_helper`** — `SnowparkHelper` for query execution with built-in `PerformanceMetrics`. Used by agents and the ETL pipeline.
- **`semantic_view`** — Loads and validates the YAML semantic views under `configs/correlation_pattern/`. See `docs/semantic_view_utilities.md`.
- **`vault_config`** — Reads secrets from vault / `.env`. Never log values from here.
- **`logger_config`** — Project logging setup. Use `get_logger(__name__)` rather than `logging.getLogger`; this routes through the project's file + console handlers and respects `cleanup_old_logs`.
- **`cache_utils` / `retry_helper`** — Generic infrastructure helpers.

## Key Principles
1. **Reusable**: Functions here are generic across agents, UI, and ETL — keep them domain-light
2. **Type-Hinted Public API**: All exported functions need accurate type hints
3. **Minimal Dependencies**: Don't pull in heavy deps for one-off needs
4. **Pure When Possible**: Prefer stateless functions over module-level state

## Development Guidelines
- Add new utility modules under `src/deep_research_utils/`
- Export new public symbols from `__init__.py` (and add them to `__all__`)
- Update dependencies with `uv add --package deep-research-utils <dependency>`
- Document non-obvious behavior with docstrings — these utilities are called from many places

## Common Tasks
- **New semantic-view validation rule**: edit `semantic_view.py`; run agent tests that load YAML configs
- **EHAP transport change**: edit `ehap.py` / `ehap_retry.py`; verify token-retry path still works (`invoke_with_token_retry`)
- **New Snowflake query pattern**: extend `SnowparkHelper` rather than duplicating connection logic in callers; get the connection itself from `connections.snowpark_session`
- **Need a connection in a new caller, agent, or notebook**: import from `connections`. If it needs an option those functions do not expose, add a keyword there rather than building the client inline
- **New logger / log file**: add to `logger_config.py` and surface through `get_logger`

## Notes
- **Do NOT read `.env`** or any credentials files when working in this package, even though `vault_config.py` references them.
- **`SSL_CERT_FILE` is destroyed by a failed Snowflake connect.** `SnowparkHelper` deletes `SSL_CERT_FILE` / `CURL_CA_BUNDLE` / `REQUESTS_CA_BUNDLE` from `os.environ` before connecting and restores them inside the `try`, so a connect failure strips them for the rest of the process. Read `AppConstants.SSL_CERT_FILE` (captured at import), never `os.environ`.
- See `SEMANTIC_VIEW_UPDATE_SUMMARY.md` for the most recent semantic-view schema changes.