"""
Architecture documentation renderer and router.

This module turns ``docs/architecture/model.yaml`` (the single source of truth for
the C4 architecture model) into a self-contained, interactive HTML page and exposes
it live at the FastAPI endpoint ``/architecture``.

Design notes:
    - ``model.yaml`` + ``template.html`` live under ``docs/architecture/`` and are
      read from disk on every render, so the served page is never stale.
    - The renderer injects the model as JSON into ``template.html`` at the
      ``__MODEL_JSON__`` placeholder. No CDN / external assets are used, so the page
      works offline and behind a corporate CSP.
    - ``validate_model`` enforces referential integrity and that every ``source:``
      path exists on disk. ``tests/test_architecture_docs.py`` runs it, so a renamed
      or removed file (or a dangling reference) fails the test suite. This turns the
      diagram into an enforced contract and prevents drift.
    - The served page validates on every request and shows any errors as an on-page
      banner at HTTP 200, while ``scripts/build_architecture_docs.py`` exits non-zero
      on the same errors. Strict at build time, forgiving while a user is looking.

FastAPI is imported lazily inside :func:`build_architecture_router` so that this
module (and the pure render/validate helpers) can be used without FastAPI installed.
"""

from __future__ import annotations

import html
import json
import os
import re
from pathlib import Path
from typing import Any, Final, Optional

import yaml

# ---------------------------------------------------------------------------
# Placeholder token in template.html that receives the model JSON.
# ---------------------------------------------------------------------------
_MODEL_PLACEHOLDER = "__MODEL_JSON__"

# The C4 manifest. Named once so validate_docs_tree() can look for it in a
# directory other than docs_dir().
_MODEL_FILENAME: Final[str] = "model.yaml"

# Node collections in the model whose entries may carry a ``source:`` path.
_SOURCED_SECTIONS = ("containers", "components")

# ---------------------------------------------------------------------------
# Fragment files merged into the model, each contributing DISJOINT top-level
# keys. Split by churn rather than by topic: solution.yaml changes when the
# slide changes (rare), catalog.yaml per element (frequent, many authors),
# links.yaml per URL rotation (platform team). One combined file would make
# every edit a merge conflict.
# ---------------------------------------------------------------------------
_FRAGMENTS: Final[tuple[tuple[str, tuple[str, ...]], ...]] = (
    ("links.yaml", ("links",)),
    ("catalog.yaml", ("elements",)),
    ("solution.yaml", ("solution",)),
)

# Closed environment set, mirroring configs/*.ini and vault_config.VAULT_CONFIGS.
# A `prd:` or `stage:` typo in links.yaml fails validation rather than rendering
# an environment row nobody can reach.
_ENVIRONMENTS: Final[tuple[str, ...]] = ("local", "local_offshore", "dev", "uat", "prod")

_LINK_KINDS: Final[tuple[str, ...]] = ("internal_tool", "vendor", "external", "docs")

# Delivery state. Deliberately small: `built` means there is code behind the
# tile, and the other two mean there is not. See ``_validate_elements``.
_STATUSES: Final[tuple[str, ...]] = ("built", "in_progress", "planned")

_CATEGORIES: Final[tuple[str, ...]] = (
    "agent",
    "analysis_mode",
    "skill",
    "tool",
    "data_source",
    "platform",
    "integration",
    "service",
    "ui",
    "external",
)

# ---------------------------------------------------------------------------
# Per-section key allowlists.
#
# This is the structural fix for a whole bug class rather than one bug. Inside a
# YAML `{ }` flow mapping an unquoted comma starts a new key, so
# `desc: Asks questions, reviews results` parses as a second key named
# "reviews results" with a null value -- valid YAML, silently wrong model. With
# an allowlist that is reported as `Unknown key 'reviews results'`.
#
# Adding a new key to any schema means adding it here too; the error message
# says so, so the failure is self-explaining.
# ---------------------------------------------------------------------------
_ALLOWED_KEYS: Final[dict[str, frozenset[str]]] = {
    "people": frozenset({"id", "name", "desc"}),
    "externalSystems": frozenset({"id", "name", "desc", "tech"}),
    "containers": frozenset({"id", "name", "desc", "tech", "source", "status", "kind"}),
    "components": frozenset(
        {"id", "name", "desc", "tech", "source", "status", "kind", "container", "extends"}
    ),
    "relationships": frozenset({"from", "to", "desc", "tech", "style"}),
    "links": frozenset({"id", "name", "kind", "desc", "homepage", "envs", "note", "todo"}),
    "elements": frozenset(
        {
            "id",
            "name",
            "category",
            "status",
            "tech",
            "owner",
            "desc",
            "source",
            "c4",
            "doc",
            "links",
            "refs",
            "related",
            "external",
        }
    ),
    "envs": frozenset({"url", "note"}),
    "panels": frozenset(
        {
            "id",
            "title",
            "subtitle",
            "caption",
            "accent",
            "layout",
            "bare",
            "cols",
            "columns",
            "render",
            "tiles",
            "children",
        }
    ),
    "bands": frozenset({"id", "layout", "columns", "panels"}),
    "arrows": frozenset({"from", "to", "dir"}),
    "solution": frozenset({"title", "columns", "bands", "arrows"}),
}


def docs_dir() -> Path:
    """Resolve the ``docs/architecture`` directory.

    Honors the ``ARCHITECTURE_DOCS_DIR`` env var (used in the container / tests),
    otherwise resolves relative to the project root. This file lives at
    ``packages/utils/src/deep_research_utils/architecture_docs.py`` so ``parents[4]``
    is the project root (mirrors ``app_constant.load_agent_config``).
    """
    override = os.environ.get("ARCHITECTURE_DOCS_DIR")
    if override:
        return Path(override)
    return Path(__file__).resolve().parents[4] / "docs" / "architecture"


def model_path() -> Path:
    """Path to the C4 model manifest."""
    return docs_dir() / _MODEL_FILENAME


def template_path() -> Path:
    """Path to the HTML render template."""
    return docs_dir() / "template.html"


def pages_dir() -> Path:
    """Directory holding one markdown file per documented element."""
    return docs_dir() / "pages"


def _read_yaml_mapping(path: Path) -> dict[str, Any]:
    """Parse ``path`` and require it to be a mapping."""
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"{path} did not parse to a mapping (got {type(data).__name__}).")
    return data


def load_model(path: Optional[Path] = None) -> dict[str, Any]:
    """Load ``model.yaml`` and merge the fragment files beside it.

    Fragments contribute **disjoint top-level keys**; there is no deep merge, so a
    key defined in two files is a hard error rather than a silent last-one-wins.
    That keeps "which file owns this list?" answerable by grep.

    A fragment that does not exist yet is skipped here so the site still renders
    the C4 view during build-out; :func:`validate_model` reports it instead. A
    fragment that exists but will not parse raises, because serving a half-loaded
    model would misrepresent the architecture.

    Passing an explicit ``path`` loads that single file with no fragment merging,
    which is what the tests use to validate synthetic models.
    """
    if path is not None:
        return _read_yaml_mapping(Path(path))

    model = _read_yaml_mapping(model_path())
    origin: dict[str, str] = {key: "model.yaml" for key in model}

    for filename, keys in _FRAGMENTS:
        fragment_path = docs_dir() / filename
        if not fragment_path.exists():
            continue
        fragment = _read_yaml_mapping(fragment_path)
        for key, value in fragment.items():
            if key in model:
                raise ValueError(
                    f"{filename} defines top-level key '{key}', which is already defined by "
                    f"{origin[key]}. Fragments must contribute disjoint keys - move the "
                    f"content into one file rather than splitting it."
                )
            if key not in keys:
                raise ValueError(
                    f"{filename} defines unexpected top-level key '{key}'; it may only "
                    f"define {', '.join(keys)}. Update _FRAGMENTS in architecture_docs.py "
                    f"if this file is meant to own a new section."
                )
            model[key] = value
            origin[key] = filename

    return model


def _project_root() -> Path:
    """Project root used to resolve ``source:`` paths for existence checks.

    Resolution order:
        1. ``ARCHITECTURE_PROJECT_ROOT`` - explicit override, set in the container.
        2. Derived from :func:`docs_dir` when it ends in ``docs/architecture``, so an
           ``ARCHITECTURE_DOCS_DIR`` relocation stays self-consistent instead of
           validating one tree's model against another tree's files.
        3. ``parents[4]`` of this file, which is the project root for an editable
           workspace install (mirrors ``app_constant.load_agent_config``).
    """
    override = os.environ.get("ARCHITECTURE_PROJECT_ROOT")
    if override:
        return Path(override)
    docs = docs_dir().resolve()
    if docs.name == "architecture" and docs.parent.name == "docs":
        return docs.parent.parent
    return Path(__file__).resolve().parents[4]


def _check_keys(schema: str, item: dict[str, Any], label: str, errors: list[str]) -> None:
    """Reject keys that are not in ``_ALLOWED_KEYS[schema]``."""
    allowed = _ALLOWED_KEYS.get(schema)
    if allowed is None:
        return
    for key in item:
        if key not in allowed:
            errors.append(
                f"Unknown key '{key}' on {label}. Allowed: {', '.join(sorted(allowed))}. "
                f"(A stray comma inside a YAML {{ }} flow mapping creates a key like this - "
                f"quote the value. If the key is genuinely new, add it to _ALLOWED_KEYS.)"
            )


def _check_text(item: dict[str, Any], key: str, label: str, errors: list[str]) -> None:
    """Require ``key`` to be a non-empty string when present."""
    if key not in item:
        return
    value = item[key]
    if not isinstance(value, str) or not value.strip():
        errors.append(f"'{key}' on {label} must be a non-empty string; got {value!r}.")


def _id_list(item: dict[str, Any], key: str, label: str, errors: list[str]) -> list[str]:
    """Read a list-of-ids field, reporting a scalar written where a list belongs."""
    value = item.get(key)
    if value is None:
        return []
    if not isinstance(value, list):
        errors.append(f"'{key}' on {label} must be a list of ids; got {value!r}.")
        return []
    out: list[str] = []
    for entry in value:
        if not isinstance(entry, str) or not entry.strip():
            errors.append(f"'{key}' on {label} contains a non-id entry: {entry!r}.")
            continue
        out.append(entry)
    return out


def _validate_links(model: dict[str, Any], errors: list[str]) -> None:
    """Validate ``links.yaml`` entries.

    The url scheme check is the security-relevant one: restricting every url to
    http(s) at the DATA layer kills ``javascript:`` before it ever reaches a
    renderer, so no template is one forgotten escape away from an injection.
    """
    for link in model.get("links") or []:
        if not isinstance(link, dict):
            errors.append(f"Entry in 'links' is not a mapping: {link!r}.")
            continue
        lid = link.get("id", "<no-id>")
        label = f"link '{lid}'"
        _check_keys("links", link, label, errors)
        if not link.get("name"):
            errors.append(f"{label} is missing 'name'.")
        _check_text(link, "name", label, errors)
        _check_text(link, "desc", label, errors)
        _check_text(link, "note", label, errors)

        kind = link.get("kind")
        if kind is not None and kind not in _LINK_KINDS:
            errors.append(
                f"{label} has unknown kind '{kind}'. Allowed: {', '.join(_LINK_KINDS)}."
            )

        homepage = link.get("homepage")
        if homepage is not None:
            _check_url(homepage, f"{label} homepage", errors)

        envs = link.get("envs")
        if envs is not None and not isinstance(envs, dict):
            errors.append(f"{label} 'envs' must be a mapping of environment -> {{url}}.")
            envs = None
        for env_name, env in (envs or {}).items():
            env_label = f"{label} env '{env_name}'"
            if env_name not in _ENVIRONMENTS:
                errors.append(
                    f"{env_label} is not a known environment. Allowed: "
                    f"{', '.join(_ENVIRONMENTS)}."
                )
            if not isinstance(env, dict):
                errors.append(f"{env_label} must be a mapping with a 'url'; got {env!r}.")
                continue
            _check_keys("envs", env, env_label, errors)
            _check_text(env, "note", env_label, errors)
            url = env.get("url")
            if not url:
                errors.append(f"{env_label} is missing 'url'.")
            else:
                _check_url(url, env_label, errors)

        # A link with no destination at all is an error UNLESS it is explicitly
        # marked `todo: true`. That marker is the honest way to declare a system
        # whose URL nobody has yet, and it renders as a caution on the page - the
        # alternative is someone inventing a plausible host to quiet the error.
        if not homepage and not envs and not link.get("todo"):
            errors.append(
                f"{label} has neither 'homepage' nor 'envs'. Add one, or set 'todo: true' "
                f"to declare that the URL is not known yet."
            )


def _check_url(url: Any, label: str, errors: list[str]) -> None:
    """Require an http(s) url."""
    if not isinstance(url, str) or not url.strip():
        errors.append(f"{label} url must be a non-empty string; got {url!r}.")
        return
    if not url.startswith(("http://", "https://")):
        errors.append(
            f"{label} url must start with http:// or https://; got {url!r}. "
            f"Other schemes (javascript:, data:, file:) are rejected here so they can "
            f"never reach the rendered page."
        )


def _validate_elements(
    model: dict[str, Any], c4_ids: set[str], element_ids: set[str], errors: list[str]
) -> None:
    """Validate ``catalog.yaml`` entries, including the status-aware source rules."""
    link_ids = {
        link["id"]
        for link in (model.get("links") or [])
        if isinstance(link, dict) and link.get("id")
    }
    known_targets = c4_ids | element_ids

    for element in model.get("elements") or []:
        if not isinstance(element, dict):
            errors.append(f"Entry in 'elements' is not a mapping: {element!r}.")
            continue
        eid = element.get("id", "<no-id>")
        label = f"element '{eid}'"
        _check_keys("elements", element, label, errors)
        if not element.get("name"):
            errors.append(f"{label} is missing 'name'.")
        _check_text(element, "name", label, errors)
        _check_text(element, "desc", label, errors)
        _check_text(element, "owner", label, errors)
        _check_text(element, "tech", label, errors)

        status = element.get("status")
        if status is None:
            errors.append(
                f"{label} is missing 'status'. Every tile must declare one of "
                f"{', '.join(_STATUSES)} - the diagram doubles as a delivery tracker, so an "
                f"undeclared tile would read as built."
            )
        elif status not in _STATUSES:
            errors.append(
                f"{label} has unknown status '{status}'. Allowed: {', '.join(_STATUSES)}."
            )

        category = element.get("category")
        if category is None:
            errors.append(f"{label} is missing 'category'.")
        elif category not in _CATEGORIES:
            errors.append(
                f"{label} has unknown category '{category}'. Allowed: "
                f"{', '.join(_CATEGORIES)}."
            )

        c4 = element.get("c4")
        if c4 is not None and c4 not in c4_ids:
            errors.append(
                f"{label} has 'c4: {c4}' which is not an id in model.yaml. The c4 key is an "
                f"explicit cross-reference so a tile can inherit source/tech/desc from the C4 "
                f"model instead of duplicating it."
            )

        # Status drives what must exist. Declaring a path is always checked
        # (see _validate_sources); claiming `built` with nothing behind it is not
        # allowed; and `planned` needs nothing, which is what lets an undeveloped
        # capability be documented today.
        if status == "built" and not (
            element.get("source") or c4 is not None or element.get("external")
        ):
            errors.append(
                f"{label} is 'status: built' but declares no 'source', no 'c4' and is not "
                f"'external: true'. Either point it at the code that implements it or set "
                f"'status: planned' / 'in_progress'."
            )

        for key in ("links", "refs"):
            for ref in _id_list(element, key, label, errors):
                if ref not in link_ids:
                    errors.append(
                        f"{label} '{key}' references unknown link id '{ref}'. Add it to "
                        f"links.yaml."
                    )
        for ref in _id_list(element, "related", label, errors):
            if ref not in known_targets:
                errors.append(
                    f"{label} 'related' references unknown id '{ref}' (expected a "
                    f"catalog element or a model.yaml id)."
                )

        doc = element.get("doc")
        if doc is not None:
            if not isinstance(doc, str) or not doc.strip():
                errors.append(f"{label} 'doc' must be a non-empty path; got {doc!r}.")
            else:
                _check_doc_path(doc, label, errors)


def _check_doc_path(doc: str, label: str, errors: list[str]) -> None:
    """Keep an explicit ``doc:`` inside ``docs/architecture/``.

    Without this a catalog entry could name ``../../.env`` or an absolute path and
    the page renderer would happily read and publish it.
    """
    candidate = Path(doc)
    if candidate.is_absolute():
        errors.append(f"{label} 'doc' must be a relative path, not {doc!r}.")
        return
    if ".." in candidate.parts:
        errors.append(
            f"{label} 'doc' must not contain '..' ({doc!r}). Pages live under "
            f"docs/architecture/pages/."
        )


def _walk_panels(panels: Any, errors: list[str], where: str) -> list[dict[str, Any]]:
    """Flatten a panel tree, validating shape as it recurses.

    ``children:`` recursion is what lets "an EHAP sub-box inside Tech Stack" and
    "a row of three panels inside Agents Framework" fall out of one schema.
    """
    out: list[dict[str, Any]] = []
    if panels is None:
        return out
    if not isinstance(panels, list):
        errors.append(f"{where} must be a list of panels; got {panels!r}.")
        return out
    for panel in panels:
        if not isinstance(panel, dict):
            errors.append(f"Panel in {where} is not a mapping: {panel!r}.")
            continue
        label = f"panel '{panel.get('id', '<no-id>')}'"
        _check_keys("panels", panel, label, errors)
        _check_text(panel, "title", label, errors)
        _check_text(panel, "subtitle", label, errors)
        _check_text(panel, "caption", label, errors)
        out.append(panel)
        out.extend(_walk_panels(panel.get("children"), errors, f"{label} children"))
    return out


def _validate_solution(model: dict[str, Any], element_ids: set[str], errors: list[str]) -> None:
    """Validate ``solution.yaml``: ids resolve, nothing is placed twice."""
    solution = model.get("solution")
    if solution is None:
        return
    if not isinstance(solution, dict):
        errors.append(f"'solution' must be a mapping; got {solution!r}.")
        return
    _check_keys("solution", solution, "solution", errors)
    _check_text(solution, "title", "solution", errors)

    bands = solution.get("bands")
    if not isinstance(bands, list) or not bands:
        errors.append("'solution.bands' must be a non-empty list.")
        bands = []

    panels: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for band in bands:
        if not isinstance(band, dict):
            errors.append(f"Band is not a mapping: {band!r}.")
            continue
        band_label = f"band '{band.get('id', '<no-id>')}'"
        _check_keys("bands", band, band_label, errors)
        bid = band.get("id")
        if not bid:
            errors.append(f"{band_label} is missing 'id'.")
        elif bid in seen_ids:
            errors.append(f"Duplicate layout id '{bid}' in solution.yaml.")
        else:
            seen_ids.add(bid)
        panels.extend(_walk_panels(band.get("panels"), errors, band_label))

    for panel in panels:
        pid = panel.get("id")
        if not pid:
            errors.append(f"Panel is missing 'id': {panel!r}.")
            continue
        if pid in seen_ids:
            errors.append(
                f"Duplicate layout id '{pid}' in solution.yaml. Band and panel ids share "
                f"one namespace because 'arrows' endpoints reference either."
            )
        else:
            seen_ids.add(pid)

    # A layout id that is also a catalog element id would make `arrows` ambiguous
    # between "point at this panel" and "point at this tile", so keep them apart.
    for layout_id in sorted(seen_ids & element_ids):
        errors.append(
            f"Layout id '{layout_id}' in solution.yaml is also a catalog element id. "
            f"Band/panel ids must not reuse element ids - arrows reference layout ids."
        )

    # Every tile must resolve to a catalog element, and no element may be placed
    # in two panels: a tile appearing twice means two places to click for one
    # thing, and the header rollup would double-count it.
    placement: dict[str, str] = {}
    for panel in panels:
        label = f"panel '{panel.get('id', '<no-id>')}'"
        for tile in _id_list(panel, "tiles", label, errors):
            if tile not in element_ids:
                errors.append(
                    f"{label} places tile '{tile}', which is not an element in catalog.yaml."
                )
                continue
            if tile in placement:
                errors.append(
                    f"Tile '{tile}' is placed in both {placement[tile]} and {label}. "
                    f"Each element belongs to exactly one panel."
                )
            else:
                placement[tile] = label

    arrows = solution.get("arrows")
    if arrows is not None and not isinstance(arrows, list):
        errors.append(f"'solution.arrows' must be a list; got {arrows!r}.")
        arrows = None
    for arrow in arrows or []:
        if not isinstance(arrow, dict):
            errors.append(f"Arrow is not a mapping: {arrow!r}.")
            continue
        _check_keys("arrows", arrow, f"arrow {arrow!r}", errors)
        for endpoint in ("from", "to"):
            ref = arrow.get(endpoint)
            if ref is None:
                errors.append(f"Arrow is missing '{endpoint}': {arrow!r}.")
            elif ref not in seen_ids:
                errors.append(
                    f"Arrow '{endpoint}' references unknown band/panel id '{ref}': {arrow!r}."
                )
        direction = arrow.get("dir")
        if direction is not None and direction not in ("both", "down", "up"):
            errors.append(
                f"Arrow 'dir' must be one of both, down, up; got {direction!r}: {arrow!r}."
            )


def validate_docs_tree(directory: Optional[Path] = None) -> list[str]:
    """Validate the documentation DIRECTORY, as distinct from the document.

    Whether ``links.yaml`` is on disk is a fact about the deployment, not about the
    model, so it is checked here rather than in :func:`validate_model`. Keeping the
    two apart is what lets ``validate_model`` stay a pure function of its argument:
    a caller can validate a hand-built or partial model without the answer
    depending on which files happen to be in ``docs/architecture``.

    The failure this catches is a silent one. :func:`load_model` skips a fragment
    that is absent so a bad image still serves the C4 view instead of a 500 - but
    absent means the solution diagram loses every tile with no error anywhere.
    Note the converse needs no check: a fragment that *is* present either
    contributes its keys or makes ``load_model`` raise.
    """
    base = Path(directory) if directory is not None else docs_dir()
    errors: list[str] = []
    if not (base / _MODEL_FILENAME).exists():
        errors.append(f"{base / _MODEL_FILENAME} does not exist.")
    for filename, keys in _FRAGMENTS:
        if not (base / filename).exists():
            errors.append(
                f"{base / filename} does not exist, so the '{', '.join(keys)}' "
                f"section(s) are missing from the model. Check that the file was "
                f"copied into the image (see .dockerignore) and that "
                f"ARCHITECTURE_DOCS_DIR points at the right directory."
            )
    return errors


def validate_model(model: dict[str, Any]) -> list[str]:
    """Validate the model and return a list of human-readable errors.

    Errors are the things that mean the documentation is *wrong*: a dangling
    reference, a path that does not exist, an unknown key, a tile claiming to be
    built with no code behind it. Things that merely mean the documentation is
    *incomplete* - a page not written yet, a link with no URL - are warnings from
    :func:`collect_model_warnings`, so unwritten docs never block a merge.

    An empty list means the model is valid.
    """
    errors: list[str] = []

    for section in ("people", "externalSystems", "containers", "components", "relationships"):
        if section not in model:
            errors.append(f"Missing top-level section: '{section}'.")

    people = model.get("people") or []
    externals = model.get("externalSystems") or []
    containers = model.get("containers") or []
    components = model.get("components") or []
    relationships = model.get("relationships") or []

    # --- id uniqueness + registry -----------------------------------------
    # c4_ids is the registry relationships may reference; all_ids is the global
    # namespace, because /architecture/e/<id> must never be ambiguous.
    c4_ids: set[str] = set()
    element_ids: set[str] = set()
    all_ids: set[str] = set()
    container_ids: set[str] = set()
    for section_name, items in (
        ("people", people),
        ("externalSystems", externals),
        ("containers", containers),
        ("components", components),
        ("links", model.get("links") or []),
        ("elements", model.get("elements") or []),
    ):
        if not isinstance(items, list):
            errors.append(f"Section '{section_name}' must be a list; got {items!r}.")
            continue
        for item in items:
            if not isinstance(item, dict):
                errors.append(f"Entry in '{section_name}' is not a mapping: {item!r}.")
                continue
            _id = item.get("id")
            if not _id:
                errors.append(f"Entry in '{section_name}' is missing an 'id': {item!r}.")
                continue
            if _id in all_ids:
                errors.append(
                    f"Duplicate id '{_id}' in '{section_name}'. Ids share one namespace "
                    f"across model.yaml, links.yaml and catalog.yaml."
                )
            all_ids.add(_id)
            if section_name in ("people", "externalSystems", "containers", "components"):
                c4_ids.add(_id)
            if section_name == "elements":
                element_ids.add(_id)
            if section_name == "containers":
                container_ids.add(_id)

    for section_name in ("people", "externalSystems", "containers", "components"):
        for item in model.get(section_name) or []:
            if isinstance(item, dict):
                _check_keys(
                    section_name, item, f"{section_name[:-1]} '{item.get('id', '<no-id>')}'", errors
                )

    # --- component container / extends references -------------------------
    for comp in components:
        if not isinstance(comp, dict):
            continue
        cid = comp.get("id", "<no-id>")
        container = comp.get("container")
        if container is None:
            errors.append(f"Component '{cid}' is missing 'container'.")
        elif container not in container_ids:
            errors.append(f"Component '{cid}' references unknown container '{container}'.")
        extends = comp.get("extends")
        if extends is not None and extends not in c4_ids:
            errors.append(f"Component '{cid}' extends unknown id '{extends}'.")

    # --- relationship endpoints ------------------------------------------
    for rel in relationships:
        if not isinstance(rel, dict):
            errors.append(f"Relationship is not a mapping: {rel!r}.")
            continue
        _check_keys("relationships", rel, f"relationship {rel.get('from')} -> {rel.get('to')}", errors)
        _check_text(rel, "desc", f"relationship {rel.get('from')} -> {rel.get('to')}", errors)
        for endpoint in ("from", "to"):
            ref = rel.get(endpoint)
            if ref is None:
                errors.append(f"Relationship missing '{endpoint}': {rel!r}.")
            elif ref not in c4_ids:
                errors.append(f"Relationship '{endpoint}' references unknown id '{ref}': {rel!r}.")

    _validate_links(model, errors)
    _validate_elements(model, c4_ids, element_ids, errors)
    _validate_solution(model, element_ids, errors)

    # --- source paths exist on disk --------------------------------------
    # Applies to any status: declaring a path that is not there is always a
    # mistake, and this is the check that keeps the diagram honest as code moves.
    root = _project_root()
    for section in (*_SOURCED_SECTIONS, "elements"):
        for item in model.get(section) or []:
            if not isinstance(item, dict):
                continue
            source = item.get("source")
            if not source:
                continue
            if not (root / source).exists():
                errors.append(
                    f"{section[:-1].capitalize()} '{item.get('id', '<no-id>')}' "
                    f"has source '{source}' which does not exist on disk."
                )

    return errors


def element_doc_path(element: dict[str, Any]) -> Path:
    """Resolve the markdown page for a catalog element.

    Convention first: ``pages/<id>.md``. That is the single largest
    maintainability win in the design - **adding a page is dropping a file in a
    folder**, with no YAML edit at all. An explicit ``doc:`` overrides it.
    """
    doc = element.get("doc")
    if isinstance(doc, str) and doc.strip():
        return docs_dir() / doc.strip()
    return pages_dir() / f"{element.get('id', '')}.md"


def collect_model_warnings(model: dict[str, Any]) -> list[str]:
    """Non-fatal findings: the documentation is incomplete rather than wrong.

    Printed by ``scripts/build_architecture_docs.py`` and surfaced in the page
    header, but never fatal - the point of the status feature is that a tile can
    be declared long before anyone writes its page.
    """
    warnings: list[str] = []

    for link in model.get("links") or []:
        if not isinstance(link, dict):
            continue
        if link.get("todo"):
            warnings.append(
                f"link '{link.get('id')}' is marked todo: its URL is not confirmed yet."
            )

    placed: set[str] = set()
    solution = model.get("solution")
    if isinstance(solution, dict):
        for band in solution.get("bands") or []:
            if not isinstance(band, dict):
                continue
            for panel in _walk_panels(band.get("panels"), [], "warnings"):
                for tile in panel.get("tiles") or []:
                    if isinstance(tile, str):
                        placed.add(tile)

    for element in model.get("elements") or []:
        if not isinstance(element, dict):
            continue
        eid = element.get("id")
        label = f"element '{eid}'"
        declared_doc = element.get("doc")
        path = element_doc_path(element)
        if not path.exists():
            if declared_doc:
                # An explicit doc: pointing nowhere is a typo worth reporting even
                # for a planned tile.
                warnings.append(f"{label} declares doc '{declared_doc}' but {path} is missing.")
            elif element.get("status") == "built":
                warnings.append(
                    f"{label} is built but has no page yet: create "
                    f"{path.relative_to(docs_dir()).as_posix()} under docs/architecture/."
                )
        elif path.is_file() and path.stat().st_size > 40_000:
            warnings.append(
                f"{label} page {path.name} is over 40 KB; consider splitting it."
            )

        if solution is not None and eid and eid not in placed:
            warnings.append(
                f"{label} is not placed on any panel in solution.yaml, so nothing links to it."
            )

    return warnings


# ===========================================================================
# Markdown
# ===========================================================================
# Page bodies are markdown files under docs/architecture/pages/. Two independent
# layers make a sanitizer unnecessary:
#
#   1. escape=True - raw HTML inside a page renders as visible text rather than
#      being executed, so there is no allowlist of tags to get wrong.
#   2. an href allowlist - anything not on the list renders as literal text.
#
# mistune 3.2 does block javascript:, vbscript:, file: and data: by itself (it
# rewrites them to "#harmful-link"), so layer 2 is not strictly required today.
# It is here anyway because that is a blocklist, and a blocklist is only ever as
# current as the last scheme someone thought of. For our own documentation, a
# link to anything outside this list is a mistake worth seeing on the page.
# ---------------------------------------------------------------------------
_SAFE_HREF_PREFIXES: Final[tuple[str, ...]] = (
    "https://",
    "http://",
    "mailto:",
    "#",  # in-page anchor
    "/architecture/",  # another page on this site
    "docs/",  # repo-relative reading material
)

# Cached parser. Caching code is not caching content: page files are still read
# from disk on every request, so the never-stale property is untouched.
_MARKDOWN: Any = None


def _esc(value: Any) -> str:
    """Escape for HTML text and attribute contexts."""
    return html.escape("" if value is None else str(value), quote=True)


def _is_safe_href(url: Any) -> bool:
    """Whether ``url`` may be emitted as an href.

    Allowlist, not blocklist. ``//host`` is rejected: it is a protocol-relative
    URL, so it inherits https and reads like a path while pointing off-site.
    """
    if not isinstance(url, str):
        return False
    candidate = url.strip()
    if not candidate or candidate.startswith("//"):
        return False
    return candidate.lower().startswith(_SAFE_HREF_PREFIXES)


def _markdown() -> Any:
    """Build (once) the configured mistune parser.

    Imported lazily, and the renderer subclass is defined inside the function for
    the same reason: ``mistune.HTMLRenderer`` must exist before it can be
    subclassed, and this module must stay importable without mistune so the
    validator and the C4 renderer keep working.
    """
    global _MARKDOWN
    if _MARKDOWN is not None:
        return _MARKDOWN

    import mistune

    class _AllowlistRenderer(mistune.HTMLRenderer):
        """HTML renderer that drops any href outside ``_SAFE_HREF_PREFIXES``.

        A rejected link keeps its text and shows its destination in parentheses
        rather than vanishing: in documentation, a link that silently loses where
        it pointed is harder to fix than one that looks wrong.
        """

        def link(self, text: str, url: str, title: Optional[str] = None) -> str:
            if not _is_safe_href(url):
                return f"{text} ({_esc(url)})"
            rendered = super().link(text, url, title)
            if url.strip().lower().startswith(("http://", "https://")):
                rendered = rendered.replace(
                    "<a href=", '<a target="_blank" rel="noopener noreferrer" href=', 1
                )
            return rendered

        def image(self, text: str, url: str, title: Optional[str] = None) -> str:
            if not _is_safe_href(url):
                return f"{text} ({_esc(url)})"
            return super().image(text, url, title)

    _MARKDOWN = mistune.create_markdown(
        escape=True,
        plugins=["table", "url", "strikethrough"],
        renderer=_AllowlistRenderer(escape=True),
    )
    return _MARKDOWN


def render_markdown(text: Optional[str]) -> str:
    """Render a page body to HTML.

    Degrades instead of failing: if mistune is missing or throws, the markdown is
    shown verbatim in a ``<pre>``. A documentation page is never worth a 500.
    """
    if not isinstance(text, str) or not text.strip():
        return ""
    try:
        return str(_markdown()(text))
    except Exception:  # missing dependency, or a parser bug on odd input
        return '<pre class="md-fallback">' + _esc(text) + "</pre>"


# ===========================================================================
# Element pages
# ===========================================================================


def _current_env() -> str:
    """The environment this process is running as.

    Same expression as ``app_constant.py``, deliberately not imported from it:
    that module does ``os.environ["OPENAI_BASE_URL"]`` at import time with no
    default, and the package ``__init__`` pulls in Snowflake. The docs site must
    not be able to fail for either reason.
    """
    return (os.environ.get("ENVIRONMENT") or "dev").strip().lower()


def _index_by_id(items: Any) -> dict[str, dict[str, Any]]:
    return {
        item["id"]: item
        for item in (items or [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }


def _c4_nodes(model: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Every C4 node by id, so a catalog element can inherit through ``c4:``."""
    nodes: dict[str, dict[str, Any]] = {}
    for section in ("people", "externalSystems", "containers", "components"):
        nodes.update(_index_by_id(model.get(section)))
    return nodes


def _breadcrumb_index(model: dict[str, Any]) -> dict[str, list[dict[str, str]]]:
    """Tile id -> the panel titles enclosing it, outermost first.

    Derived from solution.yaml rather than stored per element, so moving a tile on
    the diagram moves its breadcrumb too and the two cannot disagree.
    """
    trails: dict[str, list[dict[str, str]]] = {}
    solution = model.get("solution")
    if not isinstance(solution, dict):
        return trails

    def walk(panels: Any, trail: list[dict[str, str]]) -> None:
        for panel in panels or []:
            if not isinstance(panel, dict):
                continue
            here = list(trail)
            title = panel.get("title")
            if isinstance(title, str) and title.strip():
                here.append({"id": str(panel.get("id") or ""), "label": title.strip()})
            for tile in panel.get("tiles") or []:
                if isinstance(tile, str):
                    trails[tile] = here
            walk(panel.get("children"), here)

    for band in solution.get("bands") or []:
        if isinstance(band, dict):
            walk(band.get("panels"), [])
    return trails


def _related_from_relationships(
    model: dict[str, Any], element_by_c4: dict[str, str]
) -> dict[str, list[str]]:
    """Neighbours implied by the C4 graph, keyed by element id.

    Augmenting ``related:`` from ``relationships:`` is what keeps the diagram and
    the pages telling the same story: an edge drawn in the C4 view shows up as a
    link on both endpoints' pages without anyone maintaining it twice.
    """
    found: dict[str, list[str]] = {}
    for rel in model.get("relationships") or []:
        if not isinstance(rel, dict):
            continue
        left = element_by_c4.get(rel.get("from"))
        right = element_by_c4.get(rel.get("to"))
        if not left or not right or left == right:
            continue
        for a, b in ((left, right), (right, left)):
            neighbours = found.setdefault(a, [])
            if b not in neighbours:
                neighbours.append(b)
    return found


def _inherit(element: dict[str, Any], c4: Optional[dict[str, Any]], key: str) -> Any:
    """Element value, falling back to the C4 node it points at."""
    value = element.get(key)
    if value:
        return value
    return (c4 or {}).get(key)


def build_pages(model: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Resolve every catalog element into a ready-to-render page dict.

    Resolves ``c4:`` inheritance, dereferences ``links:``/``refs:`` into
    environment rows and reference entries, augments ``related:`` from the C4
    graph, reads the markdown body, and derives the breadcrumb from the diagram.

    Never raises. A page is the thing a user is looking at when documentation is
    wrong, so a broken element degrades to a page that says so; the same problem
    is reported as an error by :func:`validate_model` and fails the build.
    """
    links = _index_by_id(model.get("links"))
    nodes = _c4_nodes(model)
    trails = _breadcrumb_index(model)
    elements = [
        element
        for element in (model.get("elements") or [])
        if isinstance(element, dict) and isinstance(element.get("id"), str)
    ]
    by_id = {element["id"]: element for element in elements}
    element_by_c4 = {
        element["c4"]: element["id"]
        for element in elements
        if isinstance(element.get("c4"), str)
    }
    graph_related = _related_from_relationships(model, element_by_c4)
    repo_base = str((model.get("meta") or {}).get("repo_browse_base") or "").rstrip("/")
    current_env = _current_env()

    pages: dict[str, dict[str, Any]] = {}
    for element in elements:
        eid = element["id"]
        try:
            pages[eid] = _build_page(
                element, nodes, links, by_id, graph_related, trails, repo_base, current_env
            )
        except Exception as exc:  # never let one bad entry take the site down
            pages[eid] = {
                "id": eid,
                "name": str(element.get("name") or eid),
                "status": "planned",
                "category": "",
                "desc": "",
                "body": "",
                "doc_state": "absent",
                "doc_rel": f"pages/{eid}.md",
                "doc_declared": None,
                "environments": [],
                "references": [],
                "related": [],
                "trail": [],
                "source": None,
                "tech": None,
                "owner": None,
                "external": False,
                "c4_id": None,
                "error": f"{type(exc).__name__}: {exc}",
            }
    return pages


def _build_page(
    element: dict[str, Any],
    nodes: dict[str, dict[str, Any]],
    links: dict[str, dict[str, Any]],
    by_id: dict[str, dict[str, Any]],
    graph_related: dict[str, list[str]],
    trails: dict[str, list[dict[str, str]]],
    repo_base: str,
    current_env: str,
) -> dict[str, Any]:
    eid = element["id"]
    c4_id = element.get("c4") if isinstance(element.get("c4"), str) else None
    c4 = nodes.get(c4_id) if c4_id else None

    # --- markdown body -----------------------------------------------------
    doc_path = element_doc_path(element)
    doc_state = "absent"
    body = ""
    if doc_path.is_file():
        try:
            body = render_markdown(doc_path.read_text(encoding="utf-8"))
            doc_state = "present"
        except OSError:
            doc_state = "unreadable"
    try:
        doc_rel = doc_path.relative_to(docs_dir()).as_posix()
    except ValueError:
        doc_rel = doc_path.name

    # --- environment rows --------------------------------------------------
    env_rows: list[dict[str, Any]] = []
    for link_id in element.get("links") or []:
        link = links.get(link_id)
        if not isinstance(link, dict):
            continue
        envs = link.get("envs") or {}
        if not isinstance(envs, dict):
            continue
        # Iterate _ENVIRONMENTS, not the mapping: local -> dev -> uat -> prod is
        # the promotion order, and a table in YAML-authoring order would reshuffle
        # itself every time someone added a row.
        for env in _ENVIRONMENTS:
            entry = envs.get(env)
            if not isinstance(entry, dict):
                continue
            url = entry.get("url")
            if not _is_safe_href(url):
                continue
            env_rows.append(
                {
                    "link_id": link_id,
                    "link": str(link.get("name") or link_id),
                    "env": env,
                    "url": str(url),
                    "note": str(entry.get("note") or ""),
                    "current": env == current_env,
                }
            )

    # --- references --------------------------------------------------------
    references: list[dict[str, Any]] = []
    seen_refs: set[str] = set()
    for key in ("links", "refs"):
        for link_id in element.get(key) or []:
            if link_id in seen_refs:
                continue
            link = links.get(link_id)
            if not isinstance(link, dict):
                continue
            seen_refs.add(link_id)
            homepage = link.get("homepage")
            references.append(
                {
                    "id": link_id,
                    "name": str(link.get("name") or link_id),
                    "kind": str(link.get("kind") or ""),
                    "url": str(homepage) if _is_safe_href(homepage) else None,
                    "desc": str(link.get("desc") or ""),
                    # Carried through because a note on a todo link is usually the
                    # instruction for closing it ("ask the platform team"), which is
                    # the one thing a reader of an incomplete entry actually needs.
                    "note": str(link.get("note") or ""),
                    "todo": bool(link.get("todo")),
                }
            )

    # --- source ------------------------------------------------------------
    source_info = None
    source = _inherit(element, c4, "source")
    if isinstance(source, str) and source.strip():
        source = source.strip()
        source_info = {
            "path": source,
            "url": f"{repo_base}/{source}" if repo_base else None,
        }

    # --- related -----------------------------------------------------------
    related: list[dict[str, Any]] = []
    seen_related = {eid}
    for other in list(element.get("related") or []) + graph_related.get(eid, []):
        if not isinstance(other, str) or other in seen_related:
            continue
        neighbour = by_id.get(other)
        if neighbour is None:
            continue  # dangling id: validate_model reports it as an error
        seen_related.add(other)
        related.append(
            {
                "id": other,
                "name": str(neighbour.get("name") or other),
                "status": str(neighbour.get("status") or "planned"),
            }
        )

    return {
        "id": eid,
        "name": str(element.get("name") or (c4 or {}).get("name") or eid),
        "status": str(element.get("status") or "planned"),
        "category": str(element.get("category") or ""),
        "tech": _inherit(element, c4, "tech"),
        "owner": element.get("owner"),
        "desc": str(_inherit(element, c4, "desc") or ""),
        "external": bool(element.get("external")),
        "body": body,
        "doc_state": doc_state,
        "doc_rel": doc_rel,
        "doc_declared": element.get("doc"),
        "environments": env_rows,
        "references": references,
        "related": related,
        "trail": trails.get(eid, []),
        "source": source_info,
        "c4_id": c4_id,
        "error": None,
    }


# ===========================================================================
# HTML rendering: shell, element page, element index
# ===========================================================================
# `base` and `suffix` are what let one renderer serve both worlds: live routes
# pass base="/architecture" and suffix="", the offline snapshot passes base="."
# and suffix=".html" so the same links resolve as files over file://.
# ---------------------------------------------------------------------------
_SHELL_PLACEHOLDERS: Final[tuple[str, ...]] = (
    "__TITLE__",
    "__DESCRIPTION__",
    "__PAGE_CLASS__",
    "__HOME__",
    "__NAV__",
    "__BODY__",
)

# Classes the renderer is allowed to put on <body>. A closed set rather than a free
# string because it lands unescaped inside a class attribute, and because the page
# measure is a design decision that belongs in the renderer where it can be tested,
# not in whatever a caller happens to pass.
_PAGE_CLASSES: Final[frozenset[str]] = frozenset({"", "wide"})

_STATUS_LABELS: Final[dict[str, str]] = {
    "built": "Built",
    "in_progress": "In progress",
    "planned": "Planned",
}

_CATEGORY_LABELS: Final[dict[str, str]] = {
    "agent": "Agent",
    "analysis_mode": "Analysis mode",
    "skill": "Skill",
    "tool": "Tool",
    "data_source": "Data source",
    "platform": "Platform",
    "integration": "Integration",
    "service": "Service",
    "ui": "UI",
    "external": "External",
}


def shell_path() -> Path:
    """Path to the shared page chrome."""
    return docs_dir() / "shell.html"


def _element_href(base: str, element_id: str, suffix: str = "") -> str:
    return f"{base}/e/{element_id}{suffix}"


def _view_href(base: str, view: str, suffix: str = "") -> str:
    """Link to a top-level view. ``view`` is "" (home), "e" or "c4"."""
    if not view:
        return f"{base}/index{suffix}" if suffix else (base or "/")
    if suffix:
        return f"{base}/{view}/index{suffix}" if view == "e" else f"{base}/{view}{suffix}"
    return f"{base}/{view}"


# Markdown page bodies write internal links the live way - `/architecture/e/<id>` -
# because that is the URL an author clicks while writing, and the only one they can
# check. Offline those paths resolve against the filesystem root, so every one of them
# is a dead link over file://. Rewriting the rendered HTML here, rather than asking
# authors to write relative paths, keeps one markdown file correct in both worlds and
# keeps `base`/`suffix` the single mechanism that separates them.
#
# Live this is an identity transform (base="/architecture", suffix=""), which matters:
# the served path runs the same substitution, so the code cannot rot unnoticed in the
# case nobody tests offline.
_SITE_HREF_RE: Final[Any] = re.compile(r'href="/architecture(?P<path>[^"#]*)(?P<frag>#[^"]*)?"')

# Anchors in `template.html` that legitimately hold a live path and fix themselves in
# the browser over file://. Marked in the HTML so the offline audit below can tell an
# intentional one from a dead one.
_FILE_HREF_ATTR: Final[str] = "data-file-href"

_ANCHOR_TAG_RE: Final[Any] = re.compile(r"<a\b[^>]*>", re.IGNORECASE)
_ANCHOR_HREF_RE: Final[Any] = re.compile(r'href="(/architecture[^"]*)"')


def _rewrite_site_hrefs(body: str, base: str, suffix: str) -> str:
    """Retarget absolute ``/architecture`` hrefs in rendered markdown for this render."""

    def _replace(match: Any) -> str:
        trimmed = (match.group("path") or "").strip("/")
        frag = match.group("frag") or ""
        if trimmed.startswith("e/"):
            element_id = trimmed[2:]
            if not element_id or "/" in element_id:
                return str(match.group(0))
            href = _element_href(base, element_id, suffix)
        elif trimmed in ("", "e", "c4"):
            href = _view_href(base, trimmed, suffix)
        elif trimmed.startswith("c4/"):
            # A drilled-in C4 level is a live route only. Offline there is one explorer
            # document, so point at it: opening on the context level beats a dead link.
            href = _view_href(base, "c4", suffix)
        else:
            # /architecture/model and any other route with no file behind it. Left as the
            # server path rather than rewritten to a file the snapshot does not contain.
            return str(match.group(0))
        return f'href="{_esc(href)}{frag}"'

    return _SITE_HREF_RE.sub(_replace, body)


def find_absolute_site_hrefs(page_html: str) -> list[str]:
    """Absolute ``/architecture`` hrefs in ``page_html`` that would be dead offline.

    Used by the build script to audit the snapshot it just rendered. Anchors carrying
    ``data-file-href`` are excluded: those hold a live path deliberately and rewrite
    themselves in the browser when the protocol is ``file:``.
    """
    found = []
    for tag in _ANCHOR_TAG_RE.findall(page_html):
        if _FILE_HREF_ATTR in tag:
            continue
        match = _ANCHOR_HREF_RE.search(tag)
        if match:
            found.append(match.group(1))
    return found


def _nav_html(base: str, suffix: str, current: str) -> str:
    """Top-bar links. ``current`` is the view key to mark as the current page."""
    items = (("", "Solution"), ("e", "All elements"), ("c4", "C4 explorer"))
    parts = []
    for view, label in items:
        mark = ' aria-current="page"' if view == current else ""
        parts.append(f'<a href="{_esc(_view_href(base, view, suffix))}"{mark}>{_esc(label)}</a>')
    return "".join(parts)


def render_shell(
    *,
    title: str,
    description: str,
    body: str,
    nav: str,
    base: str = "/architecture",
    suffix: str = "",
    page_class: str = "",
) -> str:
    """Wrap ``body`` in the shared chrome from ``shell.html``.

    ``page_class`` goes on ``<body>`` and selects the page measure: the default
    narrow one for prose, ``"wide"`` for the pages that are pictures rather than
    text. It sits on ``<body>`` rather than ``<main>`` so the footer inherits the
    same width without a second rule to keep in sync.

    Every placeholder must occur EXACTLY ONCE, which is the same guard the C4
    renderer applies to ``template.html`` and for the same reason: a second copy
    of a token - a comment that names it, a stray paste - gets its own
    substitution, so the page silently renders that section twice. This is not
    hypothetical. The first version of ``shell.html`` documented its own
    placeholders by naming them literally, and the element index duly listed all
    71 elements twice under 18 category headers. Counting, rather than checking
    presence, is what turns that into a loud failure.

    Counts are taken against the pristine template before anything is
    substituted, so a token appearing inside ``nav`` or ``body`` content cannot
    be mistaken for a second placeholder in the chrome.
    """
    if page_class not in _PAGE_CLASSES:
        raise ValueError(
            f"page_class must be one of {sorted(_PAGE_CLASSES)}; got {page_class!r}."
        )
    shell = shell_path().read_text(encoding="utf-8")
    values = {
        "__TITLE__": _esc(title),
        "__DESCRIPTION__": _esc(description),
        "__PAGE_CLASS__": page_class,
        # A finished href, not a prefix. Offline the landing page is a file, and a
        # bare directory link ("../") opens a file:// directory listing instead.
        "__HOME__": _esc(_view_href(base.rstrip("/"), "", suffix)),
        "__NAV__": nav,
        "__BODY__": body,
    }
    for token in _SHELL_PLACEHOLDERS:
        occurrences = shell.count(token)
        if occurrences != 1:
            raise ValueError(
                f"{shell_path()} must contain exactly one {token} placeholder; "
                f"found {occurrences}. More than one duplicates that part of the "
                f"page; none means the renderer cannot build the page at all."
            )
    for token in _SHELL_PLACEHOLDERS:
        shell = shell.replace(token, values[token], 1)
    return shell


def _chip(label: str, *, status: Optional[str] = None, href: Optional[str] = None) -> str:
    attrs = f' data-status="{_esc(status)}"' if status else ""
    if href:
        return f'<a class="chip" href="{_esc(href)}"{attrs}>{_esc(label)}</a>'
    return f'<span class="chip"{attrs}>{_esc(label)}</span>'


def _diagnostics_html(diagnostics: Optional[list[str]]) -> str:
    """Render validation errors as a banner rather than swallowing them.

    Shown at HTTP 200: inside a container a ``source:`` path may legitimately be
    absent, and blanking the page over a documentation problem is worse than
    showing the page with the problem named on it.

    ``id="diag"`` deliberately matches the banner template.html emits, so one
    selector finds the banner whichever renderer produced the page - in the CSS,
    in the tests, and in any future "jump to the problems" link. There is exactly
    one banner per page, so the id stays unique.
    """
    if not diagnostics:
        return ""
    items = "".join(f"<li>{_esc(line)}</li>" for line in diagnostics)
    return (
        '<section class="diag" id="diag"><h2>'
        f"{len(diagnostics)} documentation problem(s) in docs/architecture/</h2>"
        f"<ul>{items}</ul></section>"
    )


def _crumbs_html(page: dict[str, Any], base: str, suffix: str) -> str:
    parts = [f'<a href="{_esc(_view_href(base, "e", suffix))}">All elements</a>']
    for crumb in page.get("trail") or []:
        parts.append(f"<span>{_esc(crumb.get('label'))}</span>")
    parts.append(f"<b>{_esc(page.get('name'))}</b>")
    return '<nav class="crumbs">' + '<span class="sep">/</span>'.join(parts) + "</nav>"


def _page_head_html(page: dict[str, Any], base: str, suffix: str) -> str:
    status = page.get("status") or "planned"
    chips = [_chip(_STATUS_LABELS.get(status, status), status=status)]
    category = page.get("category")
    if category:
        chips.append(_chip(_CATEGORY_LABELS.get(category, category)))
    if page.get("external"):
        chips.append(_chip("External"))

    meta: list[str] = []
    if page.get("tech"):
        meta.append(f"<span>Tech <b>{_esc(page['tech'])}</b></span>")
    if page.get("owner"):
        meta.append(f"<span>Owner <b>{_esc(page['owner'])}</b></span>")
    source = page.get("source")
    if source:
        if source.get("url"):
            link = (
                f'<a href="{_esc(source["url"])}" target="_blank" rel="noopener noreferrer">'
                f"{_esc(source['path'])}</a>"
            )
        else:
            link = f"<code>{_esc(source['path'])}</code>"
        meta.append(f"<span>Source {link}</span>")
    if page.get("c4_id"):
        meta.append(
            f'<span>C4 <a href="{_esc(_view_href(base, "c4", suffix))}">'
            f"{_esc(page['c4_id'])}</a></span>"
        )
    meta.append(
        '<button class="copy" type="button" data-url="'
        f'{_esc(_element_href(base, page["id"], suffix))}">Copy link</button>'
    )

    desc = f'<p class="lede">{_esc(page["desc"])}</p>' if page.get("desc") else ""
    return (
        '<section class="card page-head">'
        f'<h1>{_esc(page["name"])}</h1>{desc}'
        f'<div class="chips">{"".join(chips)}</div>'
        f'<div class="meta">{"".join(meta)}</div>'
        "</section>"
    )


def _body_card_html(page: dict[str, Any], base: str, suffix: str) -> str:
    """The markdown body, or the authoring placeholder.

    The placeholder is the maintenance workflow surfacing itself in the product:
    it names the exact file to create. Every Skills tile lands here on day one,
    which is the required behaviour, not a failure.
    """
    if page.get("doc_state") == "present" and page.get("body"):
        body = _rewrite_site_hrefs(page["body"], base, suffix)
        return f'<section class="card"><h2>Detail</h2><div class="md">{body}</div></section>'

    declared = page.get("doc_declared")
    if page.get("doc_state") == "unreadable":
        lead = f"<b>Page file could not be read.</b> Check permissions on <code>{_esc(page['doc_rel'])}</code>."
    elif declared:
        lead = (
            f"<b>Declared page is missing.</b> This element sets "
            f"<code>doc: {_esc(declared)}</code>, but <code>{_esc(page['doc_rel'])}</code> "
            f"does not exist."
        )
    else:
        lead = (
            f"<b>No detail document yet.</b> Create "
            f"<code>docs/architecture/{_esc(page['doc_rel'])}</code> and it appears here on "
            f"the next page load: no YAML edit, no rebuild, no restart."
        )
    stub = (
        f"# {page.get('name')}\n\n"
        "What it is. What it does in Deep Research. How it is set up.\n\n"
        "## Key decisions\n\n- \n\n## Notes\n\n- \n"
    )
    return (
        '<section class="card"><h2>Detail</h2>'
        f'<div class="todo"><p>{lead}</p>'
        "<p>Starting point:</p>"
        f"<pre>{_esc(stub)}</pre></div></section>"
    )


def _environments_card_html(page: dict[str, Any]) -> str:
    rows = page.get("environments") or []
    if not rows:
        return ""
    multi_link = len({row["link_id"] for row in rows}) > 1
    head = "<tr>" + ("<th>System</th>" if multi_link else "") + "<th>Environment</th><th>URL</th></tr>"
    body = []
    for row in rows:
        note = f'<span class="note">{_esc(row["note"])}</span>' if row.get("note") else ""
        system = f"<td>{_esc(row['link'])}</td>" if multi_link else ""
        body.append(
            f'<tr data-current="{"true" if row["current"] else "false"}">'
            f'{system}<td class="env">{_esc(row["env"])}</td>'
            f'<td><a href="{_esc(row["url"])}" target="_blank" rel="noopener noreferrer">'
            f"{_esc(row['url'])}</a>{note}</td></tr>"
        )
    return (
        '<section class="card"><h2>Environments</h2><div class="table-wrap"><table>'
        f"<thead>{head}</thead><tbody>{''.join(body)}</tbody></table></div></section>"
    )


def _references_card_html(page: dict[str, Any]) -> str:
    refs = page.get("references") or []
    if not refs:
        return ""
    items = []
    for ref in refs:
        if ref.get("url"):
            label = (
                f'<a href="{_esc(ref["url"])}" target="_blank" rel="noopener noreferrer">'
                f"{_esc(ref['name'])}</a>"
            )
        else:
            label = _esc(ref["name"])
        # The chip goes on todo entries whether or not a homepage resolved: a link can
        # have upstream product docs and still be missing the environment URLs someone
        # came here for, and that difference is invisible from the link text alone.
        if ref.get("todo"):
            label += ' <span class="chip">URL not yet confirmed</span>'
        kind = f' <span class="chip">{_esc(ref["kind"].replace("_", " "))}</span>' if ref.get("kind") else ""
        desc = f'<span class="note">{_esc(ref["desc"])}</span>' if ref.get("desc") else ""
        note = f'<span class="note">{_esc(ref["note"])}</span>' if ref.get("note") else ""
        items.append(f"<li>{label}{kind}{desc}{note}</li>")
    return (
        '<section class="card"><h2>Links and references</h2>'
        f'<ul class="refs">{"".join(items)}</ul></section>'
    )


def _related_card_html(page: dict[str, Any], base: str, suffix: str) -> str:
    related = page.get("related") or []
    if not related:
        return ""
    chips = "".join(
        _chip(
            item["name"],
            status=item.get("status"),
            href=_element_href(base, item["id"], suffix),
        )
        for item in related
    )
    return f'<section class="card"><h2>Related</h2><div class="chips">{chips}</div></section>'


def render_element_page_body(page: dict[str, Any], base: str, suffix: str) -> str:
    """The element page itself, without the shell chrome."""
    error = (
        f'<section class="diag"><h2>This element could not be resolved</h2>'
        f'<ul><li>{_esc(page["error"])}</li></ul></section>'
        if page.get("error")
        else ""
    )
    return (
        _crumbs_html(page, base, suffix)
        + error
        + _page_head_html(page, base, suffix)
        + _body_card_html(page, base, suffix)
        + _environments_card_html(page)
        + _references_card_html(page)
        + _related_card_html(page, base, suffix)
    )


def render_element_html(
    element_id: str,
    model: Optional[dict[str, Any]] = None,
    *,
    diagnostics: Optional[list[str]] = None,
    base: str = "/architecture",
    suffix: str = "",
) -> str:
    """Render one element's page. Raises ``KeyError`` for an unknown id (-> 404)."""
    if model is None:
        model = load_model()
    pages = build_pages(model)
    page = pages.get(element_id)
    if page is None:
        raise KeyError(element_id)

    site = str((model.get("meta") or {}).get("name") or "Deep Research")
    description = page.get("desc") or f"{page['name']} - {site} architecture."
    return render_shell(
        # "<name> - <site> Architecture" is what a shared link unfurls as, which is
        # the whole reason these are server routes and not URL fragments.
        title=f"{page['name']} - {site} Architecture",
        description=description,
        body=_diagnostics_html(diagnostics) + render_element_page_body(page, base, suffix),
        nav=_nav_html(base, suffix, "e"),
        base=base,
        suffix=suffix,
    )


def render_element_index_html(
    model: Optional[dict[str, Any]] = None,
    *,
    diagnostics: Optional[list[str]] = None,
    base: str = "/architecture",
    suffix: str = "",
) -> str:
    """Render the A-Z index of every catalog element, grouped by category."""
    if model is None:
        model = load_model()
    pages = build_pages(model)
    counts: dict[str, int] = {}
    for page in pages.values():
        status = page.get("status") or "planned"
        counts[status] = counts.get(status, 0) + 1
    rollup = " | ".join(
        f"{counts.get(status, 0)} {_STATUS_LABELS[status].lower()}" for status in _STATUSES
    )

    grouped: dict[str, list[dict[str, Any]]] = {}
    for page in pages.values():
        grouped.setdefault(page.get("category") or "other", []).append(page)

    sections = []
    for category in list(_CATEGORIES) + ["other"]:
        items = grouped.get(category)
        if not items:
            continue
        entries = []
        for page in sorted(items, key=lambda p: str(p.get("name", "")).lower()):
            why = page.get("desc") or ""
            if len(why) > 130:
                why = why[:127].rstrip() + "..."
            # `entry`, not `tile` and not `card`: this listing and the diagram's tiles
            # are different components that happen to both be grids of links, and each
            # carries a `.name` child. Sharing a class name means sharing every child
            # rule, so whichever block came second in the stylesheet silently restyled
            # the other - the listing's `font-size: .9rem` won on the diagram, which is
            # why tile names were breaking mid-word. `card` is the page-frame section
            # and the tiles render inside one, so it collided the same way.
            entries.append(
                f'<li><a class="entry" href="{_esc(_element_href(base, page["id"], suffix))}" '
                f'data-status="{_esc(page.get("status"))}">'
                f'<span class="name">{_esc(page["name"])}</span>'
                f'<span class="why">{_esc(why)}</span></a></li>'
            )
        sections.append(
            f'<div class="group"><h3>{_esc(_CATEGORY_LABELS.get(category, category))} '
            f'({len(items)})</h3><ul class="entries">{"".join(entries)}</ul></div>'
        )

    site = str((model.get("meta") or {}).get("name") or "Deep Research")
    body = (
        _diagnostics_html(diagnostics)
        + '<section class="card page-head"><h1>All elements</h1>'
        + f'<p class="lede">Every capability on the solution diagram, whether or not it is '
        f"built yet. {_esc(rollup)}.</p>"
        + f'<div class="meta"><span>Total <b>{len(pages)}</b></span>'
        + '<button class="copy" type="button">Copy link</button></div></section>'
        + f'<section class="card">{"".join(sections)}</section>'
    )
    return render_shell(
        title=f"All elements - {site} Architecture",
        description=f"Index of the {len(pages)} elements in the {site} solution architecture.",
        body=body,
        nav=_nav_html(base, suffix, "e"),
        base=base,
        suffix=suffix,
        # A listing of 71 cards, not prose: the extra width buys columns.
        page_class="wide",
    )


# ---------------------------------------------------------------------------
# The solution diagram.
#
# Rendered as HTML and CSS Grid rather than SVG, and the reasons are practical:
# SVG has no text wrapping (the C4 renderer's answer is to truncate at 26
# characters), real <a> tiles get keyboard tab order, Ctrl-click and Ctrl-F for
# free, Grid reflows from a laptop to a 4K display and paginates under @media
# print, and a fixed <svg width> does none of that.
#
# Containment is the whole layout: panels nest, tiles sit in grids. The only
# genuinely graphical elements are the arrows between the top band and the tech
# band, and those are CSS - a vertical rule with border-triangle heads, laid out
# on the same `columns:` value as the panels above them, so they cannot drift out
# of alignment at any window width and need no measurement in JavaScript.
# ---------------------------------------------------------------------------
def _rollup(pages: dict[str, dict[str, Any]]) -> dict[str, int]:
    counts = {status: 0 for status in _STATUSES}
    for page in pages.values():
        if page["status"] in counts:
            counts[page["status"]] += 1
    return counts


def _rollup_html(pages: dict[str, dict[str, Any]]) -> str:
    """The delivery rollup, rendered as the legend.

    One control doing two jobs on purpose: the reader cannot learn what the
    colours mean without also being told how much of the diagram is not built.
    """
    counts = _rollup(pages)
    items = "".join(
        f'<button type="button" class="legend-item" data-filter-status="{_esc(status)}" '
        f'aria-pressed="false"><span class="swatch" data-status="{_esc(status)}"></span>'
        f'{_esc(_STATUS_LABELS[status])}<b>{counts[status]}</b></button>'
        for status in _STATUSES
    )
    return (
        '<div class="legend" role="group" aria-label="Filter by delivery status">'
        f"{items}"
        f'<button type="button" class="legend-item" data-filter-status="" aria-pressed="true">'
        f"All<b>{len(pages)}</b></button>"
        "</div>"
    )


def _tile_html(page: Optional[dict[str, Any]], tile_id: str, base: str, suffix: str) -> str:
    """One clickable tile.

    ``data-name`` and ``data-status`` carry everything the search box and the
    status filter need, so filtering is a class toggle over attributes already in
    the markup - no second copy of the catalog in JavaScript.
    """
    if page is None:
        # Validation reports a dangling tile as an error; the diagram still has to
        # render, and saying so on the tile beats a silent gap in the picture.
        return (
            f'<li class="tile-wrap"><span class="tile missing">'
            f'<span class="name">{_esc(tile_id)}</span>'
            f'<span class="sub">not in catalog.yaml</span></span></li>'
        )
    sub = page.get("tech") or _CATEGORY_LABELS.get(page.get("category") or "", "")
    return (
        f'<li class="tile-wrap" data-status="{_esc(page["status"])}" '
        f'data-name="{_esc(page["name"].lower())}">'
        f'<a class="tile" href="{_esc(_element_href(base, page["id"], suffix))}" '
        f'data-status="{_esc(page["status"])}" '
        f'title="{_esc(page["name"])} - {_esc(_STATUS_LABELS.get(page["status"], page["status"]))}">'
        f'<span class="name">{_esc(page["name"])}</span>'
        + (f'<span class="sub">{_esc(sub)}</span>' if sub else "")
        + "</a></li>"
    )


def _bullets_html(
    panel: dict[str, Any], pages: dict[str, dict[str, Any]], base: str, suffix: str
) -> str:
    """`render: bullets` - a prose panel whose entries are still links."""
    items = []
    for tile_id in panel.get("tiles") or []:
        page = pages.get(tile_id)
        if page is None:
            items.append(f'<li>{_esc(tile_id)} <em>(not in catalog.yaml)</em></li>')
            continue
        desc = page.get("desc") or ""
        items.append(
            f'<li data-status="{_esc(page["status"])}" data-name="{_esc(page["name"].lower())}">'
            f'<a href="{_esc(_element_href(base, page["id"], suffix))}" '
            f'data-status="{_esc(page["status"])}">{_esc(page["name"])}</a>'
            + (f"<span>{_esc(desc)}</span>" if desc else "")
            + "</li>"
        )
    return f'<ul class="bullets">{"".join(items)}</ul>'


def _panel_html(
    panel: dict[str, Any],
    pages: dict[str, dict[str, Any]],
    base: str,
    suffix: str,
    depth: int = 0,
) -> str:
    """Render one panel and, recursively, its children.

    The recursion is the whole layout engine: "an EHAP box inside Tech Stack" and
    "a row of three panels inside Agents Framework" are the same rule applied at
    different depths, which is why neither is a special case here.

    ``bare: true`` renders the group without any chrome of its own. Some panels in
    the tree are concepts the diagram is about, and some exist only to say "these
    two sit side by side" - the row inside Agents Framework has no title because
    there is nothing to title. Drawing a box around it added a border, 28px of
    padding and one more level of visual nesting to express nothing. A bare group
    also passes its own depth to its children, so removing the box does not shift
    the panels inside it to a different heading level or a different shade.
    """
    bare = bool(panel.get("bare"))
    # A bare group is not a level of nesting, so its children keep the depth they
    # would have had without it. That is what makes `bare:` purely a chrome
    # decision: adding or removing it never changes a heading level or a shade.
    child_depth = depth if bare else depth + 1
    parts: list[str] = []
    title = panel.get("title")
    if title:
        heading = "h2" if depth == 0 else "h3"
        parts.append(f"<{heading}>{_esc(title)}</{heading}>")
    if panel.get("caption"):
        parts.append(f'<p class="caption">{_esc(panel["caption"])}</p>')
    if panel.get("subtitle"):
        parts.append(f'<p class="subtitle">{_esc(panel["subtitle"])}</p>')

    tiles = panel.get("tiles") or []
    if tiles:
        if panel.get("render") == "bullets":
            parts.append(_bullets_html(panel, pages, base, suffix))
        else:
            cols = panel.get("cols")
            style = f' style="--cols:{int(cols)}"' if isinstance(cols, int) and cols > 0 else ""
            rendered = "".join(_tile_html(pages.get(t), t, base, suffix) for t in tiles)
            parts.append(f'<ul class="tiles"{style}>{rendered}</ul>')

    children = panel.get("children") or []
    if children:
        # `layout: columns` on a panel means its children sit side by side, sharing
        # that panel's `columns:` track list; otherwise they stack.
        if panel.get("layout") == "columns":
            style = f' style="--cols-tracks:{_esc(panel.get("columns") or "1fr")}"'
            klass = "panel-row"
        else:
            style = ""
            klass = "panel-stack"
        inner = "".join(_panel_html(c, pages, base, suffix, child_depth) for c in children)
        parts.append(f'<div class="{klass}"{style}>{inner}</div>')

    element_id = _esc("p-" + str(panel.get("id")))
    if bare:
        return f'<div class="panel-group" id="{element_id}" data-depth="{depth}">' + (
            f'{"".join(parts)}</div>'
        )
    accent = panel.get("accent")
    attrs = f' data-accent="{_esc(accent)}"' if accent else ""
    return (
        f'<section class="panel" id="{element_id}"'
        f' data-depth="{depth}"{attrs}>{"".join(parts)}</section>'
    )


def _connector_row_html(band: dict[str, Any], arrows: list[dict[str, Any]], tracks: str) -> str:
    """The arrows under a band, aligned to that band's own column tracks.

    Only downward arrows between bands are drawn, which is what the slide shows.
    An arrow is placed in the grid column of its source panel, so it lines up with
    that panel at every width without measuring anything at runtime. An arrow
    whose source is not a top-level panel of this band is skipped here rather than
    guessed at - validation has already confirmed both endpoints exist, so the
    honest outcome for a shape the renderer cannot draw is to leave it out.
    """
    panels = [p for p in (band.get("panels") or []) if isinstance(p, dict)]
    by_source = {}
    for arrow in arrows:
        by_source.setdefault(arrow.get("from"), arrow)
    if not any(p.get("id") in by_source for p in panels):
        return ""
    cells = []
    for panel in panels:
        arrow = by_source.get(panel.get("id"))
        if arrow is None:
            cells.append("<div></div>")
            continue
        direction = arrow.get("dir") or "down"
        label = f'{panel.get("title") or panel.get("id")} and {arrow.get("to")}'
        cells.append(
            f'<div class="conn" data-dir="{_esc(direction)}" '
            f'role="img" aria-label="{_esc(label)} exchange data"></div>'
        )
    return (
        f'<div class="conn-row" style="--cols-tracks:{_esc(tracks)}" aria-hidden="false">'
        f'{"".join(cells)}</div>'
    )


def _band_html(
    band: dict[str, Any],
    pages: dict[str, dict[str, Any]],
    default_tracks: str,
    base: str,
    suffix: str,
) -> str:
    panels = [p for p in (band.get("panels") or []) if isinstance(p, dict)]
    inner = "".join(_panel_html(p, pages, base, suffix) for p in panels)
    tracks = band.get("columns") or default_tracks
    if band.get("layout") == "columns":
        style = f' style="--cols-tracks:{_esc(tracks)}"'
        klass = "band cols"
    else:
        style = ""
        klass = "band full"
    return f'<div class="{klass}" id="{_esc("b-" + str(band.get("id")))}"{style}>{inner}</div>'


def _toolbar_html(pages: dict[str, dict[str, Any]]) -> str:
    """Search and the status legend.

    Progressive enhancement: with JavaScript off the controls simply do nothing
    and every tile is still visible and still a link.
    """
    return (
        '<div class="toolbar">'
        '<label class="search"><span class="sr-only">Search the diagram</span>'
        '<input type="search" id="tile-search" placeholder="Search tiles..." '
        'autocomplete="off" /></label>'
        f"{_rollup_html(pages)}"
        '<span class="filter-count" id="filter-count" aria-live="polite"></span>'
        "</div>"
    )


def render_solution_html(
    model: Optional[dict[str, Any]] = None,
    *,
    diagnostics: Optional[list[str]] = None,
    base: str = "/architecture",
    suffix: str = "",
) -> str:
    """Render the solution diagram: the landing page, and the business-facing view."""
    if model is None:
        model = load_model()
    pages = build_pages(model)
    solution = model.get("solution") or {}
    meta = model.get("meta") or {}
    site = meta.get("name") or "Deep Research"
    title = solution.get("title") or f"{site} Solution"
    default_tracks = solution.get("columns") or "1fr"

    bands = [b for b in (solution.get("bands") or []) if isinstance(b, dict)]
    arrows = [a for a in (solution.get("arrows") or []) if isinstance(a, dict)]

    rendered: list[str] = []
    for index, band in enumerate(bands):
        rendered.append(_band_html(band, pages, default_tracks, base, suffix))
        if index < len(bands) - 1:
            rendered.append(
                _connector_row_html(band, arrows, band.get("columns") or default_tracks)
            )

    counts = _rollup(pages)
    lede = (
        f"{counts['built']} built, {counts['in_progress']} in progress, "
        f"{counts['planned']} planned. Every tile links to its own page."
    )
    if rendered:
        diagram = f'<div class="solution filterable">{"".join(rendered)}</div>'
    else:
        # No layout to draw. Reachable inside a container that ships model.yaml without
        # the fragments, and it must say so rather than render a blank page under a
        # heading - the element index below is the whole site's fallback navigation.
        diagram = (
            '<section class="card empty">'
            "<h2>No layout to draw</h2>"
            "<p>solution.yaml declares no bands, so there is nothing to lay out. The "
            f'<a href="{_view_href(base, "e", suffix)}">element index</a> lists every '
            "element regardless.</p></section>"
        )
    body = (
        _diagnostics_html(diagnostics)
        + '<section class="card page-head">'
        + f"<h1>{_esc(title)}</h1>"
        + f'<p class="lede">{_esc(lede)}</p>'
        + "</section>"
        + _toolbar_html(pages)
        + diagram
    )
    # Panel titles rather than a hardcoded phrase: this string is the Teams/Slack unfurl
    # text, so it has to keep telling the truth when the slide is re-laid-out.
    top_titles = [
        str(panel["title"])
        for band in bands
        for panel in (band.get("panels") or [])
        if isinstance(panel, dict) and panel.get("title")
    ]
    across = f" across {', '.join(top_titles)}" if top_titles else ""
    return render_shell(
        title=f"{title} - {site}",
        description=f"{title}: {len(pages)} elements{across}. {lede}",
        body=body,
        nav=_nav_html(base, suffix, ""),
        base=base,
        suffix=suffix,
        # The diagram is the one page where width is the whole point: three columns of
        # nested panels holding 71 tiles. Capped at the prose measure, every tile ends
        # up narrower than its own label.
        page_class="wide",
    )


def render_c4_html(
    model: Optional[dict[str, Any]] = None, *, initial_level: Optional[str] = None
) -> str:
    """Render the C4 explorer by injecting the model into ``template.html``.

    ``initial_level`` travels inside ``meta`` rather than through a second template
    placeholder, which keeps ``template.html`` at exactly one injection point - the
    structural fix for the double-injection defect, not a patch of it.

    The placeholder must occur exactly once. A second occurrence - even inside an HTML
    comment - would embed the whole model twice, silently doubling the payload, so it
    is treated as a template defect rather than tolerated.
    """
    if model is None:
        model = load_model()
    if initial_level:
        model = {**model, "meta": {**(model.get("meta") or {}), "initial_level": initial_level}}
    template = template_path().read_text(encoding="utf-8")

    occurrences = template.count(_MODEL_PLACEHOLDER)
    if occurrences != 1:
        raise ValueError(
            f"{template_path()} must contain exactly one {_MODEL_PLACEHOLDER} placeholder; "
            f"found {occurrences}. Injecting into more than one location duplicates the "
            f"model in the output."
        )

    # Escape any "</" so an embedded string can never close the <script> tag early,
    # and keep the JSON compact.
    model_json = json.dumps(model, ensure_ascii=False).replace("</", "<\\/")
    return template.replace(_MODEL_PLACEHOLDER, model_json, 1)


def render_index_html(model: Optional[dict[str, Any]] = None, **kwargs: Any) -> str:
    """Render the site's landing page. Retained name; prefer ``render_solution_html``.

    This used to render the C4 explorer, because the explorer used to be the whole
    site. The landing page is now the solution diagram, and the explorer moved to
    ``render_c4_html``. The name follows the page, not the implementation - it means
    "whatever ``index.html`` holds" - which is why it moved with the landing page
    instead of staying with the explorer.

    Kept only so an external caller still resolves; everything in this repo names the
    view it wants. Nothing here calls it.
    """
    return render_solution_html(model, **kwargs)


def _with_diagnostics(model: dict[str, Any], diagnostics: list[str]) -> dict[str, Any]:
    """Return a shallow copy of ``model`` carrying ``diagnostics`` under ``meta``.

    A copy (not a mutation) so ``GET /architecture/model`` keeps serving the clean
    document, and so the model on disk is never contaminated by render-time state.
    """
    if not diagnostics:
        return model
    annotated = dict(model)
    annotated["meta"] = {**(model.get("meta") or {}), "diagnostics": diagnostics}
    return annotated


_C4_LEVELS: Final[tuple[str, ...]] = ("context", "containers", "components")


def build_architecture_router():
    """Build a FastAPI ``APIRouter`` exposing the docs.

    Routes:
        - ``GET /architecture``            -> the solution diagram (the landing page).
        - ``GET /architecture/e``          -> index of every catalog element.
        - ``GET /architecture/e/{id}``     -> one element's page; 404 on unknown id.
        - ``GET /architecture/c4``         -> the C4 explorer.
        - ``GET /architecture/c4/{level}`` -> bookmarkable L1 / L2 / L3.
        - ``GET /architecture/model``      -> the merged model as JSON, unannotated.

    Every URL is a real server route, so each one carries its own ``<title>`` and
    unfurls with the name of the thing it documents. That is the point: a link to
    an agent page shared with a developer, and the solution page shared with the
    business, must not read the same in a chat client. A URL fragment never reaches
    the server and could not do this.

    Page routes validate on every request and render errors as an on-page banner at
    HTTP 200. Inside a container a ``source:`` path may legitimately be absent (only
    ``docs/architecture/`` and the app code are copied in), and blanking the page
    over a documentation problem would be worse than showing it with a warning.
    Only YAML that will not parse is a 500. ``scripts/build_architecture_docs.py``
    still hard-fails on the same errors, so builds stay strict.

    FastAPI is imported here (not at module top) so the render/validate helpers stay
    usable without FastAPI installed.
    """
    from fastapi import APIRouter, HTTPException
    from fastapi.responses import HTMLResponse, JSONResponse

    router = APIRouter(tags=["architecture"])

    def _load() -> dict[str, Any]:
        try:
            return load_model()
        except Exception as exc:  # unparseable / missing model.yaml - nothing to render
            raise HTTPException(
                status_code=500,
                detail=(
                    f"Could not load the architecture model from {model_path()}: {exc}. "
                    f"Check the YAML syntax."
                ),
            ) from exc

    def _diagnostics(model: dict[str, Any]) -> list[str]:
        """Directory problems first: a missing fragment file makes every other
        error downstream of it a red herring."""
        return validate_docs_tree() + validate_model(model)

    @router.get("/architecture", response_class=HTMLResponse)
    def architecture_page():
        model = _load()
        return HTMLResponse(
            content=render_solution_html(model, diagnostics=_diagnostics(model))
        )

    @router.get("/architecture/c4", response_class=HTMLResponse)
    def architecture_c4():
        model = _load()
        return HTMLResponse(content=render_c4_html(_with_diagnostics(model, _diagnostics(model))))

    @router.get("/architecture/c4/{level}", response_class=HTMLResponse)
    def architecture_c4_level(level: str):
        if level not in _C4_LEVELS:
            raise HTTPException(
                status_code=404,
                detail=f"Unknown C4 level '{level}'. Expected one of: {', '.join(_C4_LEVELS)}.",
            )
        model = _load()
        return HTMLResponse(
            content=render_c4_html(
                _with_diagnostics(model, _diagnostics(model)), initial_level=level
            )
        )

    @router.get("/architecture/e", response_class=HTMLResponse)
    def architecture_elements():
        model = _load()
        return HTMLResponse(
            content=render_element_index_html(model, diagnostics=_diagnostics(model))
        )

    @router.get("/architecture/e/{element_id}", response_class=HTMLResponse)
    def architecture_element(element_id: str):
        model = _load()
        try:
            content = render_element_html(
                element_id, model, diagnostics=_diagnostics(model)
            )
        except KeyError as exc:
            raise HTTPException(
                status_code=404,
                detail=(
                    f"No architecture element with id '{element_id}'. "
                    f"See /architecture/e for the full list."
                ),
            ) from exc
        return HTMLResponse(content=content)

    @router.get("/architecture/model")
    def architecture_model():
        return JSONResponse(content=load_model())

    return router
