"""One place to build correctly-configured Snowflake, EHAP, and LLM clients.

Callers used to hand-roll this setup: the repo grew 18 ``SnowparkHelper``
construction sites and around 20 EHAP/``ChatOpenAI`` sites, which drifted apart
in ways that silently broke things (clients missing ``base_url`` so they never
reached the gateway, TLS verification on in notebooks and off in library code,
Snowflake pools opened and never closed). Use these helpers instead of copying
a setup block.

Typical use::

    from deep_research_utils.connections import make_llm, snowpark_session

    with snowpark_session(connection_pool_size=1) as snowpark:
        df = snowpark.execute_query_and_return_pandas_df("SELECT 1")

    llm = make_llm(reasoning_effort="low")

For a long batch of LLM calls across threads, use :class:`LLMHandle` so the
baked-in token can be refreshed once when it expires rather than per worker.
"""

from __future__ import annotations

import threading
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Dict, Iterator, Optional, Tuple, Union

from deep_research_utils.app_constant import AppConstants
from deep_research_utils.ehap import EHAPBase
from deep_research_utils.logger_config import get_logger
from deep_research_utils.snowflake_helper import SnowparkHelper

if TYPE_CHECKING:  # pragma: no cover - typing only
    from langchain_openai import ChatOpenAI

logger = get_logger(__name__)


# Tuning values that 14 of the repo's 18 SnowparkHelper call sites already pass.
# None of them is a SnowparkHelper default, so keeping them here makes
# get_snowpark() a drop-in replacement for the copy-pasted block.
SNOWPARK_DEFAULTS: Dict[str, Any] = {
    "batch_size": 10000,
    "max_workers": 6,
    "enable_metrics": True,
    "connection_pool_size": 4,
}


def get_ehap(
    base_url: Optional[str] = None,
    token_path: Optional[str] = None,
    verify: Optional[Union[str, bool]] = None,
) -> EHAPBase:
    """Build an EHAP client for token minting and gateway calls.

    Args:
        base_url: Gateway host. Defaults to ``AppConstants.EHAP_BASE_URL``.
        token_path: Token endpoint path appended to ``base_url``. Defaults to
            ``AppConstants.EHAP_TOKEN_PATH`` (``/v2/oauth2/token``). The
            unversioned ``/oauth2/token`` path returns HTTP 404.
        verify: TLS verification. Defaults to ``AppConstants.SSL_CERT_FILE``, which
            is the corporate cert bundle path in the container and dev images.

    ``AppConstants.SSL_CERT_FILE`` is read here rather than ``os.environ``
    deliberately: ``SnowparkHelper._clear_ssl_env_vars`` deletes ``SSL_CERT_FILE``,
    ``CURL_CA_BUNDLE``, and ``REQUESTS_CA_BUNDLE`` from the process environment,
    and its restore call sits inside the ``try``, so a *failed* Snowflake connect
    strips them permanently. ``AppConstants`` captures the value at import and is
    immune to that.

    To turn verification off, set the env var ``SSL_CERT_FILE=false`` -- passing
    ``verify=False`` here does not work. ``EHAPBase.__init__`` tests the value for
    truthiness and coerces ``False`` back to ``True``; only the literal string
    ``"false"`` takes the disable branch. That coercion is pre-existing and left
    alone on purpose, since changing it would flip eight existing call sites from
    verified to unverified.
    """
    return EHAPBase(
        base_url=base_url or AppConstants.EHAP_BASE_URL,
        client_id=AppConstants.EHAP_CLIENT_ID,
        client_secret=AppConstants.EHAP_CLIENT_SECRET,
        verify=verify if verify is not None else AppConstants.SSL_CERT_FILE,
        token_path=token_path,
    )


def make_llm(
    model: Optional[str] = None,
    reasoning_effort: Optional[str] = None,
    summary_mode: Optional[str] = None,
    ehap: Optional[EHAPBase] = None,
) -> "ChatOpenAI":
    """Build a ``ChatOpenAI`` pointed at the EHAP gateway with a fresh token.

    Args:
        model: Model name. Defaults to ``AppConstants.EHAP_LLM_MODEL``.
        reasoning_effort: Passed through ``extra_body``; omitted when None.
        summary_mode: Passed through ``extra_body``; omitted when None.
        ehap: Reuse an existing client. A new one is built when omitted.

    Always sets ``base_url``, ``http_client``, and ``http_async_client``. Clients
    built without those reach the public OpenAI endpoint instead of the gateway,
    which is the defect this function exists to prevent.

    The token is baked in at construction and ``AppConstants.CACHE_TTL`` is 1800s,
    so a job running longer than 30 minutes needs :class:`LLMHandle`, not this.
    """
    # Imported lazily: langchain-openai is a root dependency, not a
    # deep-research-utils one, and the ETL imports this package.
    from langchain_openai import ChatOpenAI

    client = ehap or get_ehap()

    extra_body: Dict[str, Any] = {}
    if reasoning_effort is not None:
        extra_body["reasoning_effort"] = reasoning_effort
    if summary_mode is not None:
        extra_body["summary"] = summary_mode

    return ChatOpenAI(
        base_url=AppConstants.OPENAI_BASE_URL,
        model=model or AppConstants.EHAP_LLM_MODEL,
        api_key=client.get_token(),
        extra_body=extra_body or None,
        http_client=AppConstants.http_client_,
        http_async_client=AppConstants.http_async_client_,
    )


def get_snowpark(**overrides: Any) -> SnowparkHelper:
    """Build a connected ``SnowparkHelper``.

    Keyword overrides are merged over :data:`SNOWPARK_DEFAULTS`; anything
    ``SnowparkHelper`` accepts works, including ``connection_type``, ``database``,
    and ``schema``.

    The caller owns teardown. Prefer :func:`snowpark_session`, which closes for
    you -- only ``semantic_view.py`` gets this right anywhere else in the repo,
    and eight of nine notebooks leak their pool.

    Cost warning: ``connection_pool_size`` opens that many Snowflake logins
    *synchronously before the constructor returns* (one main session plus
    ``size - 1`` pooled). The default of 4 is what existing call sites use, but
    notebooks and one-off scripts usually want ``connection_pool_size=1``.
    Failures while filling the pool are logged as warnings and break the loop, so
    a partially-filled pool is not an error.

    Do not pass ``role``. ``SnowparkHelper`` discards it and always derives
    ``f"{user}_PRIVS"``.
    """
    kwargs: Dict[str, Any] = dict(SNOWPARK_DEFAULTS)
    kwargs.setdefault("connection_type", AppConstants.SNOWFLAKE_CONNECTION_TYPE)
    # Set explicitly so the session carries a database and schema; the
    # programmatic path only forwards these when they are present in kwargs.
    kwargs.setdefault("database", AppConstants.SNOWFLAKE_DATABASE)
    kwargs.setdefault("schema", AppConstants.SNOWFLAKE_SCHEMA)
    kwargs.update(overrides)

    logger.info(
        "Building SnowparkHelper (connection_type=%s, connection_pool_size=%s)",
        kwargs.get("connection_type"),
        kwargs.get("connection_pool_size"),
    )
    return SnowparkHelper(**kwargs)


@contextmanager
def snowpark_session(**overrides: Any) -> Iterator[SnowparkHelper]:
    """Yield a connected ``SnowparkHelper`` and close it on the way out.

    Closes on both the success and the exception path, which plain
    :func:`get_snowpark` cannot do. Accepts the same keyword overrides.

    ``SnowparkHelper.get_session()`` is not an alternative to this: it is a pool
    checkout whose ``finally`` returns the session to the pool and never closes
    anything.

    Example::

        with snowpark_session(connection_pool_size=1) as snowpark:
            df = snowpark.execute_query_and_return_pandas_df("SELECT CURRENT_ROLE()")
    """
    helper = get_snowpark(**overrides)
    try:
        yield helper
    finally:
        try:
            helper.close()
        except Exception as exc:  # pragma: no cover - teardown must not mask errors
            logger.warning("Error closing SnowparkHelper: %s", exc)


class LLMHandle:
    """Thread-safe ``ChatOpenAI`` holder that can re-mint its token mid-job.

    A ``ChatOpenAI`` has its token baked in at construction and
    ``AppConstants.CACHE_TTL`` is 1800s, so a batch running longer than 30
    minutes will start seeing ``openai.AuthenticationError``. Workers call
    :meth:`get` to obtain ``(llm, generation)``; on an auth failure they call
    :meth:`refresh` passing the generation they saw.

    The generation counter is what makes this safe under fan-out: when k workers
    all fail on the same expired token, the first refresh wins and the rest see a
    generation mismatch and reuse the new client instead of each minting again.

    Example::

        handle = LLMHandle(reasoning_effort="low")
        llm, generation = handle.get()
        try:
            result = llm.invoke(messages)
        except AuthenticationError:
            llm, generation = handle.refresh(generation)
            result = llm.invoke(messages)
    """

    def __init__(
        self,
        model: Optional[str] = None,
        reasoning_effort: Optional[str] = None,
        summary_mode: Optional[str] = None,
        ehap: Optional[EHAPBase] = None,
    ) -> None:
        self._model = model
        self._reasoning_effort = reasoning_effort
        self._summary_mode = summary_mode
        self._ehap = ehap or get_ehap()
        self._lock = threading.Lock()
        self._generation = 0
        self._llm = self._build()

    @property
    def ehap(self) -> EHAPBase:
        """The underlying EHAP client, for callers that also need ``ehap_retry``."""
        return self._ehap

    def _build(self) -> "ChatOpenAI":
        return make_llm(
            model=self._model,
            reasoning_effort=self._reasoning_effort,
            summary_mode=self._summary_mode,
            ehap=self._ehap,
        )

    def get(self) -> Tuple["ChatOpenAI", int]:
        """Return the current ``(llm, generation)`` pair."""
        with self._lock:
            return self._llm, self._generation

    def refresh(self, seen_generation: Optional[int] = None) -> Tuple["ChatOpenAI", int]:
        """Force a new token and rebuild the client, returning ``(llm, generation)``.

        Args:
            seen_generation: The generation the caller was using. When it no
                longer matches, another thread has already refreshed and the
                current client is returned without minting a second token.
        """
        with self._lock:
            if seen_generation is not None and seen_generation != self._generation:
                return self._llm, self._generation

            self._ehap.force_token_refresh()
            self._llm = self._build()
            self._generation += 1
            logger.info("LLM client refreshed (generation=%s)", self._generation)
            return self._llm, self._generation
