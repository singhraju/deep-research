"""Build the standalone architecture documentation snapshot.

Renders the YAML sources plus ``shell.html`` / ``template.html`` into a directory of
self-contained pages under ``docs/architecture/site/``: the solution diagram
(``index.html``), the C4 explorer (``c4.html``) and one page per element (``e/<id>.html``).
The whole set opens offline over ``file://`` with no server and no network, which is what
makes it shareable with leadership as a folder or a zip.

The live, always-current version is served by the FastAPI agent service at
``GET /architecture`` (see ``deep_research_utils.architecture_docs``); this script
just emits an offline copy. ``site/`` is gitignored: the live route is the source of
truth, and a stale committed snapshot that contradicts it is worse than none.

Unlike the served page - which renders validation errors as an on-page banner so a
documentation problem never blanks the diagram - this script exits non-zero on any
error. Strict at build time, forgiving at request time.

``--report`` prints the delivery rollup instead of building. Most of the tiles on
the solution diagram are not implemented yet, so the diagram doubles as a tracker:
one command turns it into a weekly status ritual rather than an aspirational
drawing.

Usage:
    uv run python scripts/build_architecture_docs.py
    uv run python scripts/build_architecture_docs.py --report
    uv run python scripts/build_architecture_docs.py --check
    uv run python scripts/build_architecture_docs.py --out /tmp/arch
"""

from __future__ import annotations

import argparse
import sys
from collections import Counter
from pathlib import Path

from deep_research_utils.architecture_docs import (
    build_pages,
    collect_model_warnings,
    docs_dir,
    element_doc_path,
    find_absolute_site_hrefs,
    load_model,
    render_c4_html,
    render_element_html,
    render_element_index_html,
    render_solution_html,
    validate_docs_tree,
    validate_model,
)

# Offline pages are files, not routes, so links must be relative and carry .html.
# The renderers are the live ones; only these parameters differ. Pages written into
# `e/` need a base of ".." because their links are resolved against their own
# directory, not the site root.
_SUFFIX = ".html"
_ROOT_BASE = "."
_ELEMENT_BASE = ".."


def _render_site(model: dict) -> dict[str, str]:
    """Render every page of the offline snapshot, keyed by path relative to out_dir.

    Element pages are emitted as real files so a shared link works with no server
    at all: ``e/ts_airflow.html`` opens over ``file://`` and its links resolve.
    Rendering the whole set up front (rather than writing as we go) is what lets
    ``--check`` compare the entire snapshot instead of just the landing page.
    """
    pages = {
        "index.html": render_solution_html(model, base=_ROOT_BASE, suffix=_SUFFIX),
        # The C4 explorer is a single self-contained document with the model injected
        # into it, so it takes no base/suffix: its navigation is JavaScript inside the
        # page, not links between files.
        "c4.html": render_c4_html(model),
        "e/index.html": render_element_index_html(model, base=_ELEMENT_BASE, suffix=_SUFFIX),
    }
    for element_id in build_pages(model):
        pages[f"e/{element_id}{_SUFFIX}"] = render_element_html(
            element_id, model, base=_ELEMENT_BASE, suffix=_SUFFIX
        )
    return pages


def _audit_offline_links(pages: dict[str, str]) -> list[str]:
    """Absolute ``/architecture`` links left in the snapshot, which are dead over file://.

    The snapshot's whole value is that it opens with no server, so an absolute path in it
    is a broken link by construction - and one that looks perfectly correct in the live
    site, which is where it gets written. This is not hypothetical: markdown page bodies
    linked to ``/architecture/e/<id>`` for every cross-reference, and 24 of them were dead
    in the snapshot while the same pages worked when served.

    Anchors marked ``data-file-href`` are exempt; they rewrite themselves in the browser.
    """
    problems = []
    for rel, html in sorted(pages.items()):
        for href in find_absolute_site_hrefs(html):
            problems.append(f"{rel}: absolute link {href} will not resolve over file://")
    return problems


def _print_report(model: dict) -> None:
    """Print the status rollup and the documentation gap."""
    elements = [e for e in (model.get("elements") or []) if isinstance(e, dict)]
    counts = Counter(e.get("status", "<none>") for e in elements)
    no_page = [e for e in elements if not element_doc_path(e).exists()]

    print(f"{model.get('meta', {}).get('name', 'Architecture')} solution status")
    for status in ("built", "in_progress", "planned"):
        print(f"  {status:<12} {counts.get(status, 0):>4}")
    for status, count in sorted(counts.items()):
        if status not in ("built", "in_progress", "planned"):
            print(f"  {status:<12} {count:>4}")
    print(f"  {'-' * 16}")
    print(f"  {'total':<12} {len(elements):>4}")
    print(f"  {'no page yet':<12} {len(no_page):>4}   (docs/architecture/pages/<id>.md missing)")
    print(f"  {'links':<12} {len(model.get('links') or []):>4}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build the offline architecture docs snapshot.")
    parser.add_argument(
        "--out",
        type=Path,
        default=None,
        help="Output directory (default: docs/architecture/site).",
    )
    parser.add_argument(
        "--report",
        action="store_true",
        help="Print the built / in_progress / planned rollup and exit without building.",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help=(
            "Validate and compare against the existing snapshot without writing. "
            "Exits 1 if the snapshot is missing or stale, so freshness can be enforced "
            "the moment there is a CI job to enforce it."
        ),
    )
    args = parser.parse_args(argv)

    model = load_model()
    # Two validators: the directory (are the fragment files present?) and the
    # document (does it hang together?). A missing fragment file makes every
    # downstream error a red herring, so both are reported in one pass.
    errors = validate_docs_tree() + validate_model(model)
    if errors:
        print("Architecture model validation failed:", file=sys.stderr)
        for err in errors:
            print(f"  - {err}", file=sys.stderr)
        return 1

    # Warnings mean the documentation is incomplete, not wrong. Printed so the gap
    # is visible on every build, never fatal - a tile is meant to be declarable
    # long before anyone writes its page.
    warnings = collect_model_warnings(model)
    if warnings:
        print(f"{len(warnings)} warning(s):", file=sys.stderr)
        for warn in warnings:
            print(f"  ~ {warn}", file=sys.stderr)

    if args.report:
        _print_report(model)
        return 0

    out_dir = args.out if args.out is not None else docs_dir() / "site"
    pages = _render_site(model)

    # Audited before anything is written, so a snapshot with dead links is never
    # produced at all rather than produced and then complained about.
    dead = _audit_offline_links(pages)
    if dead:
        print(f"{len(dead)} link(s) would be dead in the offline snapshot:", file=sys.stderr)
        for line in dead:
            print(f"  - {line}", file=sys.stderr)
        return 1

    if args.check:
        stale = []
        for rel, html in sorted(pages.items()):
            path = out_dir / rel
            if not path.exists():
                stale.append(f"{rel} is missing")
            elif path.read_text(encoding="utf-8") != html:
                stale.append(f"{rel} differs")
        # Files the snapshot no longer produces are stale too - a renamed element
        # would otherwise leave its old page behind for anyone still holding the link.
        if out_dir.exists():
            expected = {out_dir / rel for rel in pages}
            for path in sorted(out_dir.rglob("*.html")):
                if path not in expected:
                    stale.append(f"{path.relative_to(out_dir)} is left over")
        if stale:
            print(f"{out_dir} is out of date; re-run without --check:", file=sys.stderr)
            for line in stale:
                print(f"  - {line}", file=sys.stderr)
            return 1
        print(f"{out_dir} is up to date ({len(pages)} pages).")
        return 0

    for rel, html in sorted(pages.items()):
        path = out_dir / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
    total = sum(len(html) for html in pages.values())
    print(f"Wrote {len(pages)} pages to {out_dir} ({total:,} bytes).")
    print(f"  open {out_dir / 'index.html'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
