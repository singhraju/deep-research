"""Tests for the architecture documentation renderer.

These tests turn ``docs/architecture/model.yaml`` into an enforced contract:
every relationship endpoint, container/extends reference, and ``source:`` path is
validated, so a renamed or removed file (or a dangling reference) fails the suite.
"""

import json
import re
import shutil
from pathlib import Path

import pytest
import yaml

from deep_research_utils import architecture_docs
from deep_research_utils.architecture_docs import (
    _C4_LEVELS,
    _ENVIRONMENTS,
    _FRAGMENTS,
    _MODEL_PLACEHOLDER,
    _SHELL_PLACEHOLDERS,
    _STATUSES,
    build_architecture_router,
    build_pages,
    collect_model_warnings,
    docs_dir,
    element_doc_path,
    find_absolute_site_hrefs,
    load_model,
    render_c4_html,
    render_element_html,
    render_element_index_html,
    render_markdown,
    render_shell,
    render_solution_html,
    shell_path,
    template_path,
    validate_docs_tree,
    validate_model,
)

# A live capability agent is a module containing an uncommented `class X(AgentBase)`.
# Deriving the set from file contents (rather than hardcoding names) is what makes the
# drift guard self-maintaining: a new agent module fails the suite until it is modeled.
_AGENT_CLASS_RE = re.compile(r"^\s*class\s+\w+\s*\(\s*AgentBase\s*\)", re.MULTILINE)

# `pattern_agent copy.py` is a dead duplicate; the other two are the resolver and the
# orchestrator, which agent_api.py already treats separately from capability agents.
_EXCLUDED_MODULES = frozenset({"pattern_agent copy.py", "orchestrator.py", "user_intent.py"})

_AGENTS_DIR = Path("packages/agents/src/deep_research_agents")


@pytest.fixture(scope="module")
def model():
    return load_model()


def _live_agent_modules(root: Path) -> set[Path]:
    """Modules under deep_research_agents that define an uncommented AgentBase subclass."""
    found: set[Path] = set()
    for path in sorted((root / _AGENTS_DIR).glob("*.py")):
        if path.name in _EXCLUDED_MODULES or path.name.startswith("_"):
            continue
        if _AGENT_CLASS_RE.search(path.read_text(encoding="utf-8")):
            found.add(path.relative_to(root))
    return found


def test_model_loads(model):
    for section in ("meta", "people", "externalSystems", "containers", "components", "relationships"):
        assert section in model, f"model.yaml missing section '{section}'"
    assert model["meta"].get("name")
    assert model["meta"].get("repo_browse_base")


def test_model_referential_integrity(model):
    errors = validate_model(model)
    assert errors == [], "model.yaml has referential/integrity errors:\n" + "\n".join(errors)


def test_source_paths_exist(model):
    # validate_model already checks this; assert the specific class of error is absent
    # so a regression here gives a precise message.
    from deep_research_utils.architecture_docs import _project_root

    root = _project_root()
    for section in ("containers", "components"):
        for item in model.get(section) or []:
            source = item.get("source")
            if source:
                assert (root / source).exists(), (
                    f"{section} '{item.get('id')}' source does not exist: {source}"
                )


def test_every_agent_module_is_modeled(model):
    """Forward drift guard: a new agent module must be added to model.yaml.

    Replaces an older version that hardcoded three agent names, so eight of the eleven
    modeled components were unguarded and a brand new agent passed silently.
    """
    from deep_research_utils.architecture_docs import _project_root

    root = _project_root()
    modeled = {
        Path(item["source"])
        for item in model.get("components") or []
        if item.get("source")
    }
    live = _live_agent_modules(root)
    assert live, "found no AgentBase subclasses - the detection regex is probably broken"

    missing = sorted(str(p) for p in live - modeled)
    assert not missing, (
        "these modules define an AgentBase subclass but have no components[] entry in "
        "docs/architecture/model.yaml:\n  " + "\n  ".join(missing)
    )


def test_modeled_agents_reflect_reality(model):
    """Inverse drift guard: model.yaml may not claim an agent that isn't built.

    A component only carries `extends: agent_base` if its module really defines an
    AgentBase subclass. If the class is absent or commented out, the component must say
    so via `status: planned` / `in_progress` rather than presenting as delivered.
    """
    from deep_research_utils.architecture_docs import _project_root

    root = _project_root()
    live = _live_agent_modules(root)

    overstated = []
    for item in model.get("components") or []:
        if item.get("extends") != "agent_base":
            continue
        source = item.get("source")
        if not source or Path(source) in live:
            continue
        if item.get("status") in ("planned", "in_progress"):
            continue
        overstated.append(f"{item.get('id')} ({source})")

    assert not overstated, (
        "these components claim `extends: agent_base` with a status implying they are "
        "built, but their module defines no uncommented AgentBase subclass. Either wire "
        "them up or set status: planned:\n  " + "\n  ".join(sorted(overstated))
    )


def test_render_smoke(model):
    html = render_c4_html(model)
    assert "<svg" in html
    assert "arch-model" in html
    # the injected JSON must be present and parseable back out
    assert "correlation_agent" in html
    assert "__MODEL_JSON__" not in html, "placeholder was not replaced"


def test_render_json_is_valid_and_script_safe(model):
    html = render_c4_html(model)
    start = html.index('<script id="arch-model" type="application/json">') + len(
        '<script id="arch-model" type="application/json">'
    )
    end = html.index("</script>", start)
    payload = html[start:end]
    # embedded "</" must be escaped so it can't close the script tag early
    assert "</" not in payload
    parsed = json.loads(payload.replace("<\\/", "</"))
    assert parsed["meta"]["name"] == model["meta"]["name"]


def test_template_has_exactly_one_placeholder():
    """Defect 1, template side.

    The placeholder used to appear twice - once in the leading HTML comment describing
    the template, once in the real <script id="arch-model"> element - so every render
    embedded the whole model twice. Note the comment came FIRST, which is why passing
    count=1 to str.replace on its own would have been worse than the bug: the model
    would land in the comment and the real script tag would keep the literal token.
    """
    template = template_path().read_text(encoding="utf-8")
    count = template.count(_MODEL_PLACEHOLDER)
    assert count == 1, (
        f"{template_path()} contains the model placeholder {count} times, expected 1. "
        f"Describe it indirectly in comments instead of writing the literal token."
    )


def test_model_injected_once(model):
    """Defect 1, output side: the model appears in the rendered page exactly once."""
    html = render_c4_html(model)
    # A key unique to meta, so one occurrence == one injected copy of the model.
    assert html.count('"repo_browse_base"') == 1, (
        "the model JSON was injected more than once - check the placeholder count guard"
    )


def test_relationship_descs_are_intact(model):
    """Defect 2: an unquoted comma inside a { } flow mapping splits the value.

    `desc: Asks questions, reviews results` parses as desc="Asks questions" plus a
    second key named "reviews results" with a null value - valid YAML, silently wrong.
    """
    for rel in model.get("relationships") or []:
        desc = rel.get("desc")
        assert desc and str(desc).strip(), f"relationship has an empty desc: {rel!r}"

    analyst_edges = [
        r for r in model["relationships"] if r.get("from") == "analyst" and r.get("to") == "ui"
    ]
    assert analyst_edges, "expected an analyst -> ui relationship"
    assert "reviews results" in analyst_edges[0]["desc"], (
        "the analyst -> ui desc lost its text after the comma - it needs quoting"
    )


def test_project_root_follows_docs_dir_override(tmp_path, monkeypatch):
    """Defect 5: _project_root ignored ARCHITECTURE_DOCS_DIR.

    It always used parents[4] of this module, so relocating the docs dir validated the
    relocated model against the original checkout's files.
    """
    from deep_research_utils.architecture_docs import _project_root

    relocated = tmp_path / "docs" / "architecture"
    relocated.mkdir(parents=True)
    monkeypatch.setenv("ARCHITECTURE_DOCS_DIR", str(relocated))
    monkeypatch.delenv("ARCHITECTURE_PROJECT_ROOT", raising=False)
    assert _project_root() == tmp_path.resolve()

    monkeypatch.setenv("ARCHITECTURE_PROJECT_ROOT", str(tmp_path / "explicit"))
    assert _project_root() == tmp_path / "explicit"


def test_route_serves():
    fastapi = pytest.importorskip("fastapi")
    starlette_testclient = pytest.importorskip("starlette.testclient")

    app = fastapi.FastAPI()
    app.include_router(build_architecture_router())
    client = starlette_testclient.TestClient(app)

    resp = client.get("/architecture")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/html")
    # The landing page is the solution diagram; the SVG explorer is its own route.
    assert "Deep Research High Level Solution" in resp.text
    # a clean model must not render the diagnostics banner
    assert 'class="diag on"' not in resp.text

    resp_c4 = client.get("/architecture/c4")
    assert resp_c4.status_code == 200
    assert "<svg" in resp_c4.text

    resp_model = client.get("/architecture/model")
    assert resp_model.status_code == 200
    assert resp_model.json()["meta"]["name"]


def test_route_degrades_on_invalid_model(tmp_path, monkeypatch):
    """Defect 4: the live route never validated.

    A dangling `source:` is expected inside the container (only docs/architecture/ and
    the app code are copied in), so it must surface as an on-page banner at HTTP 200
    rather than blanking the diagram. Only unparseable YAML is a 500.
    """
    _relocate_docs(
        tmp_path,
        monkeypatch,
        "meta:\n"
        "  name: Broken\n"
        "  repo_browse_base: https://example.invalid/browse\n"
        "people: []\n"
        "externalSystems: []\n"
        "containers:\n"
        "  - id: ui\n"
        "    name: UI\n"
        "    source: does/not/exist.py\n"
        "components: []\n"
        "relationships: []\n",
    )
    client = _client()

    resp = client.get("/architecture")
    assert resp.status_code == 200, "a documentation defect must not blank the page"
    assert 'class="diag" id="diag"' in resp.text
    assert "does/not/exist.py" in resp.text, "the error should be reported on the page"
    # No fragments were relocated, so there is no layout to draw. The landing page must
    # still say something useful and point at the index rather than render blank.
    assert "No layout to draw" in resp.text

    # the model endpoint stays clean - diagnostics are render-time only
    assert "diagnostics" not in client.get("/architecture/model").json().get("meta", {})


def test_route_500s_on_unparseable_model(tmp_path, monkeypatch):
    """The one case that is genuinely fatal: YAML that will not parse."""
    fastapi = pytest.importorskip("fastapi")
    starlette_testclient = pytest.importorskip("starlette.testclient")

    relocated = tmp_path / "docs" / "architecture"
    relocated.mkdir(parents=True)
    shutil.copy(template_path(), relocated / "template.html")
    (relocated / "model.yaml").write_text("meta: {name: 'unterminated\n", encoding="utf-8")
    monkeypatch.setenv("ARCHITECTURE_DOCS_DIR", str(relocated))

    app = fastapi.FastAPI()
    app.include_router(build_architecture_router())
    client = starlette_testclient.TestClient(app, raise_server_exceptions=False)
    assert client.get("/architecture").status_code == 500


def test_docs_dir_contains_expected_files():
    """Guards the container copy: these are the files the Dockerfile must ship."""
    for name in ("model.yaml", "template.html"):
        assert (docs_dir() / name).is_file(), f"docs/architecture/{name} is missing"


def test_dockerignore_reincludes_architecture_docs():
    """Defect 3: /architecture was broken in every container build.

    Two patterns hid the docs - `docs/` and `*.md` - so COPY docs/architecture/ landed
    nothing and the route 500'd in the image while working locally. Docker resolves
    ignore rules last-match-wins, so the re-inclusions have to come after BOTH
    exclusions; that ordering is the property worth pinning.
    """
    from deep_research_utils.architecture_docs import _project_root

    lines = [
        line.strip()
        for line in (_project_root() / ".dockerignore").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]

    def index_of(pattern: str) -> int:
        assert pattern in lines, f".dockerignore is missing the '{pattern}' rule"
        return lines.index(pattern)

    docs_exclusion = index_of("docs/**")
    md_exclusion = index_of("*.md")
    arch_reinclusion = index_of("!docs/architecture/**")
    pages_reinclusion = index_of("!docs/architecture/pages/**/*.md")

    assert arch_reinclusion > docs_exclusion, (
        "'!docs/architecture/**' must come after 'docs/**' or the docs are excluded"
    )
    assert pages_reinclusion > md_exclusion, (
        "'!docs/architecture/pages/**/*.md' must come after '*.md' or every page markdown "
        "file is stripped from the image and each element page shows its placeholder"
    )


def test_dockerfile_pins_architecture_paths():
    """The container cannot rely on the parents[4] fallback in docs_dir().

    That fallback only lands on /app while the workspace package is editable-installed.
    A non-editable install puts __file__ under /app/.venv/lib/... and parents[4] becomes
    /app/.venv/lib, breaking /architecture invisibly until someone opens the page.
    """
    from deep_research_utils.architecture_docs import _project_root

    dockerfile = (_project_root() / "Dockerfile").read_text(encoding="utf-8")
    for var in ("ARCHITECTURE_DOCS_DIR=/app/docs/architecture", "ARCHITECTURE_PROJECT_ROOT=/app"):
        assert var in dockerfile, f"Dockerfile must set {var}"


def test_dockerfile_copies_the_architecture_docs():
    """The third leg of the container fix, and the one with no other guard.

    Re-including docs/architecture in .dockerignore only permits the copy; it does not
    perform one. The Dockerfile copies specific directories rather than the whole context,
    so dropping this line leaves the negation rules looking correct while the image ships
    no YAML at all - and /architecture then fails only in the container.
    """
    from deep_research_utils.architecture_docs import _project_root

    dockerfile = (_project_root() / "Dockerfile").read_text(encoding="utf-8")
    assert "COPY docs/architecture/ ./docs/architecture/" in dockerfile, (
        "Dockerfile must copy docs/architecture/ into the image; the .dockerignore "
        "negations permit the copy but do not make one happen"
    )


# ===========================================================================
# Fragment loading (links.yaml / catalog.yaml / solution.yaml)
# ===========================================================================


def test_fragments_are_merged(model):
    """Every fragment file present on disk contributes its section to the model."""
    for filename, keys in _FRAGMENTS:
        if not (docs_dir() / filename).exists():
            continue
        for key in keys:
            assert key in model, f"{filename} exists but did not contribute '{key}'"
            assert model[key], f"{filename} contributed an empty '{key}'"


def test_overlapping_fragment_keys_raise(tmp_path, monkeypatch):
    """A key defined in two files is a hard error, not a silent last-one-wins.

    Without this, moving a section between files and forgetting to delete the old
    copy would leave a half-updated model that still validates.
    """
    (tmp_path / "model.yaml").write_text("meta: {name: T}\nlinks: []\n", encoding="utf-8")
    (tmp_path / "links.yaml").write_text("links: []\n", encoding="utf-8")
    monkeypatch.setenv("ARCHITECTURE_DOCS_DIR", str(tmp_path))

    with pytest.raises(ValueError, match="already defined by model.yaml"):
        load_model()


def test_fragment_cannot_define_a_foreign_key(tmp_path, monkeypatch):
    """links.yaml may only own the sections _FRAGMENTS assigns to it."""
    (tmp_path / "model.yaml").write_text("meta: {name: T}\n", encoding="utf-8")
    (tmp_path / "links.yaml").write_text("links: []\nelements: []\n", encoding="utf-8")
    monkeypatch.setenv("ARCHITECTURE_DOCS_DIR", str(tmp_path))

    with pytest.raises(ValueError, match="unexpected top-level key 'elements'"):
        load_model()


def test_docs_tree_is_complete():
    """Every fragment file is where the loader expects it.

    Separate from validate_model on purpose: whether links.yaml is on disk is a
    fact about the deployment, not about the document, and this is the check that
    catches an image built without it. load_model skips an absent fragment so the
    C4 view still serves, which is exactly why the absence needs saying out loud.
    """
    assert validate_docs_tree() == []


def test_missing_fragment_file_is_reported(tmp_path):
    (tmp_path / "model.yaml").write_text("meta: {name: T}\n", encoding="utf-8")
    errors = validate_docs_tree(tmp_path)
    assert len(errors) == len(_FRAGMENTS), errors
    assert any("links.yaml" in e for e in errors), errors


def test_validate_model_does_not_depend_on_the_docs_directory():
    """validate_model must be a pure function of its argument.

    It used to also check the docs directory, which meant a partial model built in
    memory failed for reasons that had nothing to do with the model. Anything the
    filesystem knows belongs in validate_docs_tree.
    """
    assert validate_model(_base_model()) == []


def test_explicit_path_skips_fragment_merge(tmp_path):
    """load_model(path) loads exactly that file, which is what the tests below rely on."""
    solo = tmp_path / "solo.yaml"
    solo.write_text("meta: {name: Solo}\npeople: []\n", encoding="utf-8")
    loaded = load_model(solo)
    assert loaded == {"meta": {"name": "Solo"}, "people": []}


# ===========================================================================
# Unknown-key rejection -- the structural fix for the YAML comma bug class
# ===========================================================================


def _base_model() -> dict:
    """A minimal model that validates clean, for mutation by the tests below."""
    return {
        "meta": {"name": "T"},
        "people": [{"id": "p1", "name": "Person"}],
        "externalSystems": [],
        "containers": [{"id": "c1", "name": "Container"}],
        "components": [{"id": "cm1", "name": "Component", "container": "c1"}],
        "relationships": [{"from": "p1", "to": "c1", "desc": "uses"}],
    }


def test_real_model_has_no_unknown_keys(model):
    """The shipped model uses only allowlisted keys."""
    assert [e for e in validate_model(model) if "Unknown key" in e] == []


def test_unknown_key_is_rejected():
    """A junk key anywhere in a section is reported rather than ignored."""
    m = _base_model()
    m["components"][0]["junk_key"] = "x"
    errors = validate_model(m)
    assert any("Unknown key 'junk_key'" in e for e in errors), errors


def test_yaml_comma_bug_is_caught():
    """Regression test for the defect this allowlist exists to prevent.

    In YAML, `{desc: Asks questions, reviews results}` parses as TWO keys: `desc`
    and a second key named "reviews results" with a null value. Valid YAML, wrong
    model, and previously silent.
    """
    parsed = yaml.safe_load("rel: {from: p1, to: c1, desc: Asks questions, reviews results}")
    assert "reviews results" in parsed["rel"], "premise of this test no longer holds"

    m = _base_model()
    m["relationships"] = [parsed["rel"]]
    errors = validate_model(m)
    assert any("Unknown key 'reviews results'" in e for e in errors), errors


# ===========================================================================
# links.yaml
# ===========================================================================


def test_link_ids_resolve(model):
    """Every links:/refs: id on an element exists in links.yaml."""
    link_ids = {link["id"] for link in model.get("links") or []}
    for element in model.get("elements") or []:
        for key in ("links", "refs"):
            for ref in element.get(key) or []:
                assert ref in link_ids, f"element '{element['id']}' {key} -> unknown '{ref}'"


def test_link_env_names_are_allowed(model):
    for link in model.get("links") or []:
        for env in (link.get("envs") or {}):
            assert env in _ENVIRONMENTS, f"link '{link['id']}' has unknown env '{env}'"


def test_every_link_url_is_http(model):
    """No scheme other than http(s) reaches the renderer.

    Enforced at the data layer so a template is never one forgotten escape away
    from a javascript: URL.
    """
    urls = []
    for link in model.get("links") or []:
        if link.get("homepage"):
            urls.append(link["homepage"])
        for env in (link.get("envs") or {}).values():
            if isinstance(env, dict) and env.get("url"):
                urls.append(env["url"])
    assert urls, "no urls found -- this test would pass vacuously"
    for url in urls:
        assert url.startswith(("http://", "https://")), url


def test_non_http_url_is_rejected():
    m = _base_model()
    m["links"] = [{"id": "l1", "name": "L", "homepage": "javascript:alert(1)"}]
    errors = validate_model(m)
    assert any("must start with http" in e for e in errors), errors


def test_bad_env_name_is_rejected():
    m = _base_model()
    m["links"] = [{"id": "l1", "name": "L", "envs": {"prd": {"url": "https://x.example.com"}}}]
    errors = validate_model(m)
    assert any("not a known environment" in e for e in errors), errors


def test_link_with_no_destination_needs_todo():
    """A link with nowhere to go is an error unless it says so with todo: true."""
    m = _base_model()
    m["links"] = [{"id": "l1", "name": "L"}]
    assert any("neither 'homepage' nor 'envs'" in e for e in validate_model(m))

    m["links"] = [{"id": "l1", "name": "L", "todo": True}]
    assert validate_model(m) == []
    assert any("marked todo" in w for w in collect_model_warnings(m))


# ===========================================================================
# catalog.yaml -- status drives what must exist
# ===========================================================================


def test_element_statuses_and_categories_are_known(model):
    assert [e for e in validate_model(model) if "unknown status" in e or "unknown category" in e] == []


def test_planned_element_with_no_source_is_valid():
    """The requirement that unblocks documenting work that does not exist yet.

    Most of this module is not built. A planned tile must declare cleanly, with no
    source path and no page, and still leave the model valid.
    """
    m = _base_model()
    m["elements"] = [
        {"id": "e1", "name": "Not built yet", "category": "agent", "status": "planned"}
    ]
    assert validate_model(m) == []


def test_built_element_needs_something_behind_it():
    """`status: built` may not be claimed with no code, no c4 node and no external flag."""
    m = _base_model()
    m["elements"] = [{"id": "e1", "name": "E", "category": "agent", "status": "built"}]
    errors = validate_model(m)
    assert any("declares no 'source'" in e for e in errors), errors

    m["elements"][0]["c4"] = "cm1"
    assert validate_model(m) == []


def test_element_missing_status_is_rejected():
    m = _base_model()
    m["elements"] = [{"id": "e1", "name": "E", "category": "agent"}]
    assert any("missing 'status'" in e for e in validate_model(m))


def test_element_source_must_exist_at_any_status():
    """A declared path is checked even for a planned tile: a wrong path is always a bug."""
    m = _base_model()
    m["elements"] = [
        {
            "id": "e1",
            "name": "E",
            "category": "agent",
            "status": "planned",
            "source": "packages/agents/src/deep_research_agents/does_not_exist.py",
        }
    ]
    assert any("does not exist on disk" in e for e in validate_model(m))


def test_element_c4_must_resolve():
    m = _base_model()
    m["elements"] = [
        {"id": "e1", "name": "E", "category": "agent", "status": "built", "c4": "nope"}
    ]
    assert any("is not an id in model.yaml" in e for e in validate_model(m))


def test_doc_path_cannot_escape_the_docs_directory():
    """A catalog entry must not be able to name a file outside docs/architecture/.

    The page renderer reads and publishes whatever `doc:` points at, so traversal
    is blocked at the data layer.
    """
    for bad in ("../../.env", "/etc/passwd"):
        m = _base_model()
        m["elements"] = [
            {"id": "e1", "name": "E", "category": "agent", "status": "planned", "doc": bad}
        ]
        errors = validate_model(m)
        assert errors, f"{bad} was accepted"


def test_element_ids_do_not_collide_with_link_or_c4_ids(model):
    """One namespace, so /architecture/e/<id> is never ambiguous."""
    seen: dict[str, str] = {}
    for section in ("people", "externalSystems", "containers", "components", "links", "elements"):
        for item in model.get(section) or []:
            _id = item["id"]
            assert _id not in seen, f"id '{_id}' appears in both {seen[_id]} and {section}"
            seen[_id] = section


# ===========================================================================
# solution.yaml
# ===========================================================================


def _panels(model) -> list[dict]:
    out: list[dict] = []

    def walk(panels):
        for panel in panels or []:
            out.append(panel)
            walk(panel.get("children"))

    for band in (model.get("solution") or {}).get("bands") or []:
        walk(band.get("panels"))
    return out


def test_every_tile_resolves_to_an_element(model):
    element_ids = {e["id"] for e in model.get("elements") or []}
    tiles = [t for panel in _panels(model) for t in panel.get("tiles") or []]
    assert tiles, "no tiles found -- this test would pass vacuously"
    for tile in tiles:
        assert tile in element_ids, f"solution.yaml places unknown tile '{tile}'"


def test_no_element_is_placed_twice(model):
    tiles = [t for panel in _panels(model) for t in panel.get("tiles") or []]
    duplicates = {t for t in tiles if tiles.count(t) > 1}
    assert not duplicates, f"tiles placed in more than one panel: {sorted(duplicates)}"


def test_every_element_is_placed(model):
    """An unplaced element is unreachable from the diagram. A warning, checked here.

    Kept as an assertion rather than only a warning because during authoring it is
    the single easiest thing to get wrong: add to catalog.yaml, forget solution.yaml.
    """
    placed = {t for panel in _panels(model) for t in panel.get("tiles") or []}
    unplaced = sorted({e["id"] for e in model.get("elements") or []} - placed)
    assert not unplaced, f"elements not placed on any panel: {unplaced}"


def test_dangling_tile_is_rejected():
    m = _base_model()
    m["elements"] = [{"id": "e1", "name": "E", "category": "agent", "status": "planned"}]
    m["solution"] = {
        "title": "T",
        "bands": [{"id": "b1", "panels": [{"id": "p1", "tiles": ["e1", "ghost"]}]}],
    }
    assert any("not an element in catalog.yaml" in e for e in validate_model(m))


def test_tile_placed_twice_is_rejected():
    m = _base_model()
    m["elements"] = [{"id": "e1", "name": "E", "category": "agent", "status": "planned"}]
    m["solution"] = {
        "title": "T",
        "bands": [
            {
                "id": "b1",
                "panels": [{"id": "p1", "tiles": ["e1"]}, {"id": "p2", "tiles": ["e1"]}],
            }
        ],
    }
    assert any("is placed in both" in e for e in validate_model(m))


def test_arrow_endpoints_resolve(model):
    layout_ids = {b["id"] for b in (model.get("solution") or {}).get("bands") or []}
    layout_ids |= {p["id"] for p in _panels(model)}
    arrows = (model.get("solution") or {}).get("arrows") or []
    assert arrows, "no arrows found -- this test would pass vacuously"
    for arrow in arrows:
        assert arrow["from"] in layout_ids, arrow
        assert arrow["to"] in layout_ids, arrow


def test_layout_id_may_not_reuse_an_element_id():
    m = _base_model()
    m["elements"] = [{"id": "e1", "name": "E", "category": "agent", "status": "planned"}]
    m["solution"] = {
        "title": "T",
        "bands": [{"id": "b1", "panels": [{"id": "e1", "tiles": ["e1"]}]}],
    }
    assert any("also a catalog element id" in e for e in validate_model(m))


# ===========================================================================
# Warnings channel -- incomplete is not invalid
# ===========================================================================


def test_missing_page_is_a_warning_not_an_error(model):
    """The Skills case (requirement 4).

    No skill has a markdown page yet. That must never fail the build: unwritten
    docs would otherwise block every merge.
    """
    assert validate_model(model) == []
    warnings = collect_model_warnings(model)
    assert any("has no page yet" in w for w in warnings), warnings


def test_declared_doc_pointing_nowhere_warns():
    m = _base_model()
    m["elements"] = [
        {
            "id": "e1",
            "name": "E",
            "category": "skill",
            "status": "planned",
            "doc": "pages/definitely_absent.md",
        }
    ]
    assert validate_model(m) == []
    assert any("but" in w and "is missing" in w for w in collect_model_warnings(m))


def test_element_doc_path_is_convention_based():
    """Adding a page is dropping a file in a folder -- no YAML edit."""
    assert element_doc_path({"id": "airflow"}) == docs_dir() / "pages" / "airflow.md"
    assert element_doc_path({"id": "x", "doc": "pages/other.md"}) == docs_dir() / "pages" / "other.md"


def test_warnings_never_raise(model):
    """collect_model_warnings is called from the request path; it must not throw."""
    assert isinstance(collect_model_warnings(model), list)
    assert isinstance(collect_model_warnings({}), list)


def test_statuses_are_a_closed_vocabulary(model):
    for element in model.get("elements") or []:
        assert element["status"] in _STATUSES, element["id"]


# ---------------------------------------------------------------------------
# Phase 2: markdown, element pages, routes
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def pages(model):
    return build_pages(model)


def _relocate_docs(tmp_path, monkeypatch, model_yaml: str):
    """Point ARCHITECTURE_DOCS_DIR at a throwaway copy holding both templates.

    Element pages need shell.html as well as template.html, so a relocation that
    copies only the latter 500s for reasons that have nothing to do with the test.
    """
    relocated = tmp_path / "docs" / "architecture"
    relocated.mkdir(parents=True)
    shutil.copy(template_path(), relocated / "template.html")
    shutil.copy(shell_path(), relocated / "shell.html")
    (relocated / "model.yaml").write_text(model_yaml, encoding="utf-8")
    monkeypatch.setenv("ARCHITECTURE_DOCS_DIR", str(relocated))
    monkeypatch.delenv("ARCHITECTURE_PROJECT_ROOT", raising=False)
    return relocated


def _client(*, raise_server_exceptions: bool = True):
    fastapi = pytest.importorskip("fastapi")
    starlette_testclient = pytest.importorskip("starlette.testclient")
    app = fastapi.FastAPI()
    app.include_router(build_architecture_router())
    return starlette_testclient.TestClient(app, raise_server_exceptions=raise_server_exceptions)


def test_shell_placeholders_occur_exactly_once():
    """Regression: shell.html once documented its own tokens by naming them.

    Each substitution then hit the comment as well as the real placeholder, and the
    element index rendered all 71 elements twice under 18 category headers. The
    count guard in render_shell is the fix; this test pins the file itself so the
    comment cannot quietly reacquire a literal token.
    """
    shell = shell_path().read_text(encoding="utf-8")
    for token in _SHELL_PLACEHOLDERS:
        assert shell.count(token) == 1, f"{token} appears {shell.count(token)} times in shell.html"


def test_duplicate_shell_placeholder_is_rejected(tmp_path, monkeypatch):
    """The guard must reject a doubled token rather than duplicate the page."""
    relocated = tmp_path / "docs" / "architecture"
    relocated.mkdir(parents=True)
    doubled = shell_path().read_text(encoding="utf-8").replace(
        "<main>__BODY__</main>", "<main>__BODY__</main><main>__BODY__</main>"
    )
    (relocated / "shell.html").write_text(doubled, encoding="utf-8")
    monkeypatch.setenv("ARCHITECTURE_DOCS_DIR", str(relocated))

    with pytest.raises(ValueError, match="exactly one __BODY__"):
        render_shell(title="T", description="D", body="B", nav="")


def test_missing_shell_placeholder_is_rejected(tmp_path, monkeypatch):
    relocated = tmp_path / "docs" / "architecture"
    relocated.mkdir(parents=True)
    stripped = shell_path().read_text(encoding="utf-8").replace("__TITLE__", "Fixed title")
    (relocated / "shell.html").write_text(stripped, encoding="utf-8")
    monkeypatch.setenv("ARCHITECTURE_DOCS_DIR", str(relocated))

    with pytest.raises(ValueError, match="exactly one __TITLE__"):
        render_shell(title="T", description="D", body="B", nav="")


def test_markdown_subset_renders():
    """The subset pages/_TEMPLATE.md.txt promises authors."""
    html = render_markdown(
        "# Heading\n\n"
        "Text with **bold**, *italic* and `code`.\n\n"
        "- one\n- two\n\n"
        "| a | b |\n| --- | --- |\n| 1 | 2 |\n\n"
        "```python\nprint('hi')\n```\n\n"
        "> quoted\n"
    )
    for fragment in ("<h1>", "<strong>", "<em>", "<code>", "<li>", "<table>", "<pre>", "<blockquote>"):
        assert fragment in html, fragment
    assert "print(" in html, "code fence content should survive"


def test_raw_html_in_a_page_is_escaped_not_executed():
    """escape=True: a page is prose, not a template. Defence layer one.

    Asserted as "no tag of this name was emitted at all", rather than "the
    dangerous attribute is absent" -- with escaping, `onerror` legitimately
    appears as visible text, so looking for the attribute name would pass for the
    wrong reason.
    """
    html = render_markdown("Hello <script>alert(1)</script> and <img src=x onerror=alert(1)>")
    assert re.search(r"<\s*(script|img)\b", html, re.I) is None, html
    assert "&lt;script&gt;" in html, "the raw source should still be visible as text"


def test_javascript_href_is_dropped_but_real_links_survive():
    """Defence layer two: an href allowlist, not a blocklist of known-bad schemes.

    The strong form of this check is to collect every href the renderer emitted
    and require each one to be on the allowlist -- that catches a scheme nobody
    thought to write a case for, which is the entire reason for preferring an
    allowlist here.
    """
    html = render_markdown(
        "[bad](javascript:alert(1))\n\n"
        "[worse](JaVaScRiPt:alert(1))\n\n"
        "[data](data:text/html;base64,PHNjcmlwdD4=)\n\n"
        "[vb](vbscript:msgbox)\n\n"
        "[protocol relative](//evil.example.com)\n\n"
        "[good](https://example.com/x)\n\n"
        "[internal](/architecture/e/ts_airflow)\n\n"
        "[repo](docs/design/01_architecture.MD)\n\n"
        "[anchor](#gotchas)\n"
    )
    emitted = re.findall(r'href="([^"]*)"', html)
    assert emitted, "no links were rendered at all"
    for href in emitted:
        assert href.startswith(
            ("https://", "http://", "mailto:", "#", "/architecture/", "docs/")
        ), f"{href} is not on the allowlist"

    # rejected links keep their text and show the URL, so the author sees what failed
    for text in ("bad", "worse", "data", "vb", "protocol relative"):
        assert text in html, text

    assert 'href="https://example.com/x"' in html
    assert 'target="_blank"' in html and 'rel="noopener noreferrer"' in html
    assert 'href="/architecture/e/ts_airflow"' in html
    assert 'href="docs/design/01_architecture.MD"' in html
    assert 'href="#gotchas"' in html


def test_markdown_degrades_instead_of_raising(monkeypatch):
    """If mistune is absent or throws, a page renders as preformatted text.

    The route calls this per element; a markdown failure must cost one page's
    formatting, not the whole site.
    """
    def boom():
        raise RuntimeError("no mistune here")

    monkeypatch.setattr(architecture_docs, "_MARKDOWN", None)
    monkeypatch.setattr(architecture_docs, "_markdown", boom)
    html = render_markdown("# Heading\n\n<script>alert(1)</script>")
    assert 'class="md-fallback"' in html
    assert "<h1>" not in html
    assert "<script" not in html.lower(), "the fallback must still escape"


def test_markdown_handles_empty_input():
    assert render_markdown(None) == ""
    assert render_markdown("") == ""


def test_build_pages_covers_every_element(model, pages):
    assert set(pages) == {e["id"] for e in model["elements"]}


def test_element_index_lists_every_element_exactly_once(model, pages):
    """The double-render regression, asserted on the output rather than the template."""
    html = render_element_index_html(model)
    hrefs = re.findall(r'href="/architecture/e/([^"]+)"', html)
    assert len(hrefs) == len(pages), f"{len(hrefs)} links for {len(pages)} elements"
    assert len(set(hrefs)) == len(hrefs), "an element is listed more than once"
    assert set(hrefs) == set(pages)


def test_element_page_carries_its_own_title(model):
    """The point of server routes: a pasted link unfurls with the page's own name."""
    html = render_element_html("ts_airflow", model=model)
    title = re.search(r"<title>(.*?)</title>", html, re.S).group(1)
    assert "Airflow" in title
    assert title != "Deep Research Architecture", "the title must be per page, not the site name"


def test_rendered_pages_never_leak_a_placeholder(model, pages):
    for element_id in pages:
        html = render_element_html(element_id, model=model)
        for token in _SHELL_PLACEHOLDERS:
            assert token not in html, f"{token} leaked into {element_id}"


def test_every_page_renders_without_error(model, pages):
    """build_pages never raises; it records the failure on the page instead."""
    broken = {pid: page["error"] for pid, page in pages.items() if page.get("error")}
    assert broken == {}


def test_missing_page_renders_the_authoring_placeholder(model, pages):
    """Requirement 4: the Skills tiles have no markdown yet and must not error."""
    undocumented = [p for p in pages.values() if p["doc_state"] == "absent"]
    assert undocumented, "no undocumented element left to exercise the placeholder"
    page = undocumented[0]
    html = render_element_html(page["id"], model=model)
    assert 'class="todo"' in html
    # the placeholder must name the exact file to create -- it is the workflow, on screen
    assert f'pages/{page["id"]}.md' in html


def test_environment_rows_follow_promotion_order(pages):
    with_envs = [p for p in pages.values() if len(p["environments"]) > 1]
    assert with_envs, "no element has more than one environment URL"
    order = {name: i for i, name in enumerate(_ENVIRONMENTS)}
    for page in with_envs:
        indexes = [order[row["env"]] for row in page["environments"]]
        assert indexes == sorted(indexes), f"{page['id']} lists environments out of order"


def test_related_chips_are_symmetric_across_a_c4_edge(model, pages):
    """A C4 relationship should surface on both endpoints' pages, not just one."""
    by_c4 = {p["c4_id"]: p["id"] for p in pages.values() if p.get("c4_id")}
    related_ids = {pid: {r["id"] for r in page["related"]} for pid, page in pages.items()}
    checked = 0
    for rel in model["relationships"]:
        src, dst = by_c4.get(rel["from"]), by_c4.get(rel["to"])
        if not src or not dst or src == dst:
            continue
        checked += 1
        assert dst in related_ids[src], f"{dst} missing from {src}"
        assert src in related_ids[dst], f"{src} missing from {dst}"
    assert checked, "no relationship connected two catalog elements"


def test_breadcrumb_trail_comes_from_the_solution_layout(pages):
    trails = [p["trail"] for p in pages.values() if p["trail"]]
    assert len(trails) == len(pages), "every placed element should have a breadcrumb"


def test_element_route_serves_and_404s():
    client = _client()

    resp = client.get("/architecture/e/ts_airflow")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/html")
    assert "Airflow" in resp.text

    index = client.get("/architecture/e")
    assert index.status_code == 200
    assert 'href="/architecture/e/' in index.text

    assert client.get("/architecture/e/no_such_element").status_code == 404


def test_c4_level_routes_are_bookmarkable():
    client = _client()
    for level in _C4_LEVELS:
        resp = client.get(f"/architecture/c4/{level}")
        assert resp.status_code == 200, level
        assert f'"initial_level": "{level}"' in resp.text or f'"initial_level":"{level}"' in resp.text
    assert client.get("/architecture/c4").status_code == 200
    assert client.get("/architecture/c4/nope").status_code == 404


def test_element_routes_degrade_on_invalid_model(tmp_path, monkeypatch):
    """Defect 4 again, for the pages: a documentation defect is a banner, not a 500."""
    _relocate_docs(
        tmp_path,
        monkeypatch,
        "meta:\n"
        "  name: Broken\n"
        "people: []\n"
        "externalSystems: []\n"
        "containers:\n"
        "  - id: ui\n"
        "    name: UI\n"
        "    source: does/not/exist.py\n"
        "components: []\n"
        "relationships: []\n"
        "elements:\n"
        "  - id: only\n"
        "    name: Only element\n"
        "    category: platform\n"
        "    status: planned\n"
        "    desc: Survives a broken model.\n",
    )
    client = _client(raise_server_exceptions=False)

    index = client.get("/architecture/e")
    assert index.status_code == 200
    assert 'class="diag" id="diag"' in index.text
    assert "does/not/exist.py" in index.text

    page = client.get("/architecture/e/only")
    assert page.status_code == 200
    assert "Only element" in page.text
    assert 'class="diag" id="diag"' in page.text


# ---------------------------------------------------------------------------
# Phase 3: the solution diagram
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def solution_html(model):
    return render_solution_html(model)


def _placed_tile_ids(model) -> list[str]:
    """Every tile id the layout places, in document order, panels recursively."""
    found: list[str] = []

    def walk(panel):
        found.extend(panel.get("tiles") or [])
        for child in panel.get("children") or []:
            walk(child)

    for band in model["solution"]["bands"]:
        for panel in band.get("panels") or []:
            walk(panel)
    return found


def test_solution_page_links_every_placed_tile(model, solution_html):
    """Requirement 1: every element on the diagram is a link to its own page."""
    placed = _placed_tile_ids(model)
    assert len(placed) >= 60, f"only {len(placed)} tiles placed; the slide has far more"

    for tile_id in placed:
        href = f'href="/architecture/e/{tile_id}"'
        assert solution_html.count(href) == 1, (
            f"{tile_id} is placed on the diagram but links to its page "
            f"{solution_html.count(href)} times, expected 1"
        )
    assert "not in catalog.yaml" not in solution_html, "a placed tile has no catalog entry"


def test_solution_panel_nesting_renders_at_every_depth(model, solution_html):
    """`children:` recursion is the layout engine, so nesting must actually nest."""
    # Top-level panels are the slide's three columns plus the Tech Stack band.
    for title in ("AI data preparation", "Agents Framework", "Research", "Tech Stack"):
        assert f"<h2>{title}</h2>" in solution_html, f"{title} is not a top-level panel"
    # Nested panels are headings one level down, whatever their depth.
    for title in ("Snowflake", "Prebuilt Models", "Analysis Modes", "EHAP", "iDiscovery"):
        assert f"<h3>{title}</h3>" in solution_html, f"{title} did not render as a child panel"
    # EHAP sits inside Tech Stack, so a second level of panels exists. There is no
    # third: the row inside Agents Framework is a `bare:` group, which contributes
    # layout without contributing a level of nesting.
    assert 'data-depth="1"' in solution_html
    assert 'data-depth="2"' not in solution_html, (
        "a panel is nested three deep; a third shade and an <h4>-less heading is "
        "more nesting than the drawing can carry - use `bare: true` for grouping"
    )


def test_bare_groups_contribute_layout_and_no_chrome(model, solution_html):
    """`bare: true` is a layout group, so it must render nothing of its own.

    The row holding Integration, LLM Load Balancer and Services has no title,
    because there is nothing to title. Rendered as a panel it drew a border and 28px
    of padding around three already-bordered boxes - the crowding the diagram was
    reported for. Rendered bare it still positions its children and nothing else.
    """
    bare_ids = []

    def walk(panels: list, depth: int) -> None:
        for panel in panels:
            if panel.get("bare"):
                bare_ids.append((panel["id"], depth))
            walk(panel.get("children") or [], depth if panel.get("bare") else depth + 1)

    for band in model["solution"]["bands"]:
        walk(band.get("panels") or [], 0)

    assert bare_ids, "no panel uses `bare:`, so this test is no longer measuring anything"
    for panel_id, depth in bare_ids:
        group = f'<div class="panel-group" id="p-{panel_id}" data-depth="{depth}">'
        assert group in solution_html, f"{panel_id} did not render as a bare group"
        assert f'<section class="panel" id="p-{panel_id}"' not in solution_html, (
            f"{panel_id} still renders panel chrome"
        )
    assert ".panel-group" in shell_path().read_text(encoding="utf-8"), (
        "bare groups render a class with no rule behind it"
    )


def test_bullets_panel_renders_prose_not_tiles(model, solution_html):
    """`render: bullets` is the ingestion-pipeline case from the slide."""
    assert '<ul class="bullets">' in solution_html
    ingestion = next(
        p
        for p in model["solution"]["bands"][0]["panels"][0]["children"]
        if p["id"] == "ingestion_pipeline"
    )
    assert ingestion.get("render") == "bullets"
    # Still links, not inert text - the requirement is that everything is clickable.
    for tile_id in ingestion["tiles"]:
        assert f'href="/architecture/e/{tile_id}"' in solution_html


def test_rollup_counts_match_the_catalog(model, solution_html):
    """The legend doubles as the delivery rollup, so it must agree with --report."""
    from collections import Counter

    expected = Counter(e["status"] for e in model["elements"])
    rendered = dict(re.findall(r'data-filter-status="([a-z_]*)"[^>]*>.*?<b>(\d+)</b>', solution_html))
    assert rendered, "the legend rendered no counts"
    for status in _STATUSES:
        assert rendered[status] == str(expected[status]), (
            f"legend says {rendered[status]} {status}, catalog has {expected[status]}"
        )
    assert rendered[""] == str(len(model["elements"])), "the All button miscounts"
    # The header lede carries the same numbers, so the two cannot disagree.
    assert f"{expected['built']} built, {expected['in_progress']} in progress" in solution_html


def test_connectors_align_to_the_band_they_sit_under(model, solution_html):
    """The arrows share the band's track list, which is why they cannot drift.

    Declared once in solution.yaml and consumed by both the band and the connector
    row: no runtime measurement, so alignment survives a resize and a print.
    """
    tracks = model["solution"]["columns"]
    arrows = model["solution"]["arrows"]
    assert solution_html.count('class="conn"') == len(arrows), (
        "one connector per arrow, placed in its source panel's column"
    )
    assert solution_html.count(f'class="conn-row" style="--cols-tracks:{tracks}"') == 1
    assert f'class="band cols" id="b-top" style="--cols-tracks:{tracks}"' in solution_html
    for arrow in arrows:
        assert arrow["dir"] == "both"
    # Matched together with the class: `data-dir="both"` on its own also occurs in
    # the stylesheet's `.conn[data-dir="both"]` rule.
    assert solution_html.count('class="conn" data-dir="both"') == len(arrows)


def test_filter_markup_and_script_agree(solution_html):
    """The filter is markup-driven; a rename on one side must fail loudly.

    The script reads `[data-status][data-name]` inside `.filterable` and writes to
    `#filter-count`, so those four names are a contract between two files.
    """
    shell = shell_path().read_text(encoding="utf-8")
    for selector in (
        "'.filterable'",
        "'[data-status][data-name]'",
        "'tile-search'",
        "'filter-count'",
        "'[data-filter-status]'",
    ):
        assert selector in shell, f"{selector} is not what the script looks for any more"

    assert 'class="solution filterable"' in solution_html
    assert 'id="tile-search"' in solution_html
    assert 'id="filter-count"' in solution_html
    # Every filterable item must carry BOTH attributes: the script's selector needs
    # both, so a tile with only one would be invisible to search and to the filter.
    wraps = re.findall(r'<li class="tile-wrap"([^>]*)>', solution_html)
    assert wraps, "no tiles rendered"
    for attrs in wraps:
        assert "data-status=" in attrs and "data-name=" in attrs, attrs


def test_status_filter_offers_every_status(solution_html):
    for status in _STATUSES:
        assert f'data-filter-status="{status}"' in solution_html
    assert 'data-filter-status=""' in solution_html, "there must be a way back to All"


def test_solution_page_stays_within_budget(solution_html):
    """A budget ratchet: the diagram is one request with no lazy loading."""
    size = len(solution_html.encode("utf-8"))
    assert size < 512 * 1024, f"the solution page grew to {size:,} bytes"


# ---------------------------------------------------------------------------
# Layout: page measure, tile track floor, text wrapping
# ---------------------------------------------------------------------------
# These assert CSS, which is unusual and deliberate. Each rule below encodes a
# decision that showed up as a visible defect - names spilling across neighbouring
# tiles, sub-labels truncated to "FastAPI + LangG", a three-column diagram squeezed
# into a prose measure - and CSS has no other test. Matching on the declaration
# block, not the whole file, so an unrelated rule elsewhere cannot satisfy them.
# ---------------------------------------------------------------------------
def _css_block(selector: str) -> str:
    """The declaration block for ``selector`` in shell.html, comments stripped."""
    shell = shell_path().read_text(encoding="utf-8")
    shell = re.sub(r"/\*.*?\*/", "", shell, flags=re.DOTALL)
    match = re.search(rf"(?:^|[\}}\n])\s*{re.escape(selector)}\s*\{{(.*?)\}}", shell, re.DOTALL)
    assert match, f"{selector} is no longer a rule in shell.html"
    return match.group(1)


def test_the_diagram_gets_the_wide_measure_and_prose_does_not(model, solution_html):
    """Width is a per-page-family decision, made in the renderer and visible in HTML.

    The diagram is a picture of 71 tiles and wants the display; a page of prose is
    unreadable past ~90 characters a line and stays narrow. Asserted through the
    class on <body> rather than a screenshot, because that is the whole reason the
    switch is a class the renderer sets instead of a CSS heuristic.
    """
    assert '<body class="wide">' in solution_html
    assert '<body class="wide">' in render_element_index_html(model)
    element_id = sorted(build_pages(model))[0]
    assert '<body class="">' in render_element_html(element_id, model)

    # `wide` has to actually widen something, and both the content and the footer
    # under it, or the page renders visibly misaligned at the bottom.
    assert "body.wide { --measure:" in shell_path().read_text(encoding="utf-8")
    assert "max-width: var(--measure)" in _css_block("main")
    assert "max-width: var(--measure)" in _css_block("footer.app")


def test_page_class_is_a_closed_set():
    """It lands unescaped in a class attribute, so the renderer will not take prose."""
    with pytest.raises(ValueError, match="page_class"):
        render_shell(title="t", description="d", body="b", nav="n", page_class="wide onerror=x")


def test_tile_tracks_have_a_width_floor():
    """`cols:` is an intent; the floor is what stops it clipping the labels.

    `minmax(0, 1fr)` let tracks shrink below their own content, so on a narrower
    window tile names overflowed sideways across their neighbours instead of the row
    wrapping. The fix is a floor under the authored share - wrapping is the graceful
    failure, overflow is not - and reverting to a zero minimum must fail here.
    """
    block = _css_block("ul.tiles")
    assert "--tile-min:" in block, "the track floor is gone"
    assert "auto-fit" in block and "max(" in block, "the floor is not in the track list"
    assert "var(--cols" in block, "the authored column count is no longer honoured"
    assert "minmax(0" not in block, "a zero track minimum is what caused the overflow"
    # The floor is capped at the panel's own width, or it becomes the new overflow: a
    # 132px minimum inside an 84px panel pushed 48px of Integration and EHAP out
    # through the side of the page, and dragged the whole band out with them. The
    # nesting is the assertion - `min(100%, max(...))` caps the floor, `max(...,
    # min(100%, ...))` would not - so it is matched as a shape, not as three tokens.
    assert re.search(r"minmax\(\s*min\(\s*100%\s*,\s*max\(", block), (
        "the track floor is no longer capped at the container width by min(100%, ...)"
    )


def test_tile_labels_wrap_instead_of_overflowing_or_clipping():
    """Both halves of a tile have to survive a narrow track.

    The name breaks - "Intent and context resolver" has to go somewhere - and the
    sub-label wraps rather than truncating, because the sub-label is the tech behind
    the tile and "FastAPI + LangG" is the part that distinguished it from its
    neighbour.
    """
    name = _css_block(".tile .name")
    assert "overflow-wrap: break-word" in name

    # `word-break: break-word` is defined as `overflow-wrap: anywhere`, and `anywhere`
    # collapses the element's min-content width to one character. Every track floor in
    # this diagram is content-derived - bare `fr` at band level, `max(--tile-min,
    # share)` inside a panel - so a name that claims to fit in one character is a name
    # no track ever widens for. That is what produced "Reimburseme / nt policy": not a
    # track too narrow for the text, but a text that had stopped asking for room.
    assert "word-break" not in name, (
        "word-break: break-word is overflow-wrap: anywhere, which zeroes the "
        "min-content width the content-derived track floors are measured from"
    )
    assert "hyphens: auto" in name, (
        "the breaks that remain unavoidable should read as 'Reimburse- / ment'"
    )

    sub = _css_block(".tile .sub")
    for clipping in ("text-overflow: ellipsis", "white-space: nowrap", "overflow: hidden"):
        assert clipping not in sub, f"{clipping} truncates the sub-label instead of wrapping it"


def test_tile_labels_are_styled_by_exactly_one_component(model, solution_html):
    """Two components must not share a class name, because `.name` is a child of both.

    This has now broken the diagram twice, the same way each time. A descendant
    selector reaches every level below it, so `X .name` restyles anything called
    `name` anywhere under an `X`. The element listing was called `tiles`, and
    `ul.tiles .name` - one type selector, so more specific than `.tile .name` - won on
    the diagram and rendered its labels at .9rem, wide enough that thirteen-character
    words no longer fit their tracks. Renaming it to `card` moved the collision rather
    than removing it: the tiles are drawn inside a `.card` section, and at equal
    specificity source order decides, which the later block wins.

    So the invariant is not "specific enough" - escalating specificity is what got it
    wrong twice - it is that a class owning a `.name` rule may not appear on any
    ancestor of a tile. Checked by class name rather than by cascade, because that is
    the property a future rename can actually preserve.
    """
    shell = re.sub(r"/\*.*?\*/", "", shell_path().read_text(encoding="utf-8"), flags=re.DOTALL)
    owners = {m.group(1) for m in re.finditer(r"\.([\w-]+)\s+\.name\b", shell)}
    assert "tile" in owners, "the diagram's tile labels have no rule of their own"

    # Every class the solution page actually renders. A `.name` rule keyed on any of
    # these - other than `tile` itself - reaches the tile labels through the ancestor
    # chain, whatever its specificity.
    rendered = set()
    for attr in re.findall(r'class="([^"]*)"', solution_html):
        rendered.update(attr.split())
    for owner in sorted(owners - {"tile"}):
        assert owner not in rendered, (
            f"'.{owner} .name' is styled and '{owner}' is a class on the solution "
            f"page, so that rule reaches the diagram's tile labels"
        )

    # And the inverse, so the listing's own labels are not left to the tile rule
    # either: the listing must not render a class that the diagram styles a child of.
    listing = set()
    for attr in re.findall(r'class="([^"]*)"', render_element_index_html(model)):
        listing.update(attr.split())
    assert "tile" not in listing, "the element listing renders `tile`, so `.tile .name` reaches it"


def test_connector_gap_is_the_band_gap(solution_html):
    """The arrows sit in a separate grid, so its gap must be the band's gap.

    Track alignment is already pinned by ``test_connectors_align_to_the_band_they_sit_under``;
    this is the other half. Two different gap values with identical tracks still puts
    every arrow off-centre from the panel it joins, so the two rows read the one
    property rather than two numbers someone has to change together.
    """
    assert "--band-gap:" in _css_block(".solution")
    assert "gap: var(--band-gap" in _css_block(".band.cols")
    assert "gap: var(--band-gap" in _css_block(".conn-row")
    assert 'class="conn-row"' in solution_html


def test_dangling_tile_renders_a_marker_instead_of_raising(tmp_path, monkeypatch):
    """Validation calls this an error; the renderer still has to draw the picture."""
    relocated = _relocate_docs(
        tmp_path,
        monkeypatch,
        "meta:\n  name: Sparse\npeople: []\nexternalSystems: []\n"
        "containers: []\ncomponents: []\nrelationships: []\n",
    )
    (relocated / "catalog.yaml").write_text(
        "elements:\n"
        "  - id: real\n"
        "    name: Real element\n"
        "    category: platform\n"
        "    status: planned\n"
        "    desc: Exists in the catalog.\n",
        encoding="utf-8",
    )
    (relocated / "solution.yaml").write_text(
        "solution:\n"
        "  title: Sparse solution\n"
        "  bands:\n"
        "    - id: only\n"
        "      panels:\n"
        "        - id: p\n"
        "          title: Panel\n"
        "          tiles: [real, ghost]\n",
        encoding="utf-8",
    )

    model = load_model()
    assert any("ghost" in err for err in validate_model(model)), (
        "a tile with no catalog entry must still be a validation error"
    )
    html = render_solution_html(model)
    assert 'href="/architecture/e/real"' in html
    assert "not in catalog.yaml" in html, "the gap must be visible on the tile"
    assert "ghost" in html


def test_offline_solution_page_uses_relative_hrefs(model):
    """The snapshot is opened over file://, where an absolute path leaves the folder."""
    html = render_solution_html(model, base=".", suffix=".html")
    assert 'href="/architecture' not in html, "an absolute route escapes the snapshot"
    assert 'href="./e/ts_airflow.html"' in html
    for href in re.findall(r'href="([^"]*)"', html):
        assert not href.startswith("/"), f"{href} does not resolve as a file"


def test_offline_element_pages_use_relative_hrefs(model, pages):
    """The gap that let 24 dead links into a snapshot that passed every other test.

    ``test_offline_solution_page_uses_relative_hrefs`` covered the diagram, where every
    href is built by the renderer through ``base``/``suffix``. Element pages have a
    second source of links: the markdown body, whose author writes the live path
    ``/architecture/e/<id>`` because that is the URL they can click while writing. Those
    hrefs bypassed the renderer entirely and shipped absolute, so they worked when
    served and were dead in the folder handed to a reader.

    Every page, not a sample: the pages with body links are exactly the ones someone
    bothered to document, so a sample would most likely miss them.
    """
    offenders = {}
    for element_id in pages:
        html = render_element_html(element_id, model, base="..", suffix=".html")
        dead = find_absolute_site_hrefs(html)
        if dead:
            offenders[element_id] = dead
    assert offenders == {}, f"absolute links do not resolve over file://: {offenders}"


def test_markdown_body_links_are_retargeted_per_render(model):
    """One markdown file, two correct outputs - the point of `base`/`suffix`.

    The live render must keep the absolute path (it is a server route), and the offline
    render must turn the same link into the sibling file. Asserting both directions is
    what stops a fix for one from silently breaking the other.
    """
    source = (docs_dir() / "pages" / "svc_orchestrator.md").read_text(encoding="utf-8")
    assert "](/architecture/e/mode_variance)" in source, (
        "this test needs a page that cross-links; pick another if the link is gone"
    )

    live = render_element_html("svc_orchestrator", model)
    assert '<a href="/architecture/e/mode_variance">' in live

    offline = render_element_html("svc_orchestrator", model, base="..", suffix=".html")
    assert '<a href="../e/mode_variance.html">' in offline
    assert "/architecture/e/mode_variance" not in offline


def test_href_rewrite_leaves_alone_what_it_cannot_map():
    """A route with no file behind it must not be rewritten to a file that is not there.

    ``/architecture/model`` is JSON served by the API; the snapshot contains no such
    file. Turning it into ``../model.html`` would swap a link that is honestly
    server-only for one that looks local and 404s. Fragments have to survive too, since
    a deep link into a long page is the main reason to write one by hand.
    """
    rewrite = architecture_docs._rewrite_site_hrefs

    assert rewrite('href="/architecture/model"', "..", ".html") == 'href="/architecture/model"'
    assert rewrite('href="/architecture/e/x#gotchas"', "..", ".html") == (
        'href="../e/x.html#gotchas"'
    )
    # A drilled-in C4 level exists only as a route; offline there is one explorer file.
    assert rewrite('href="/architecture/c4/containers"', "..", ".html") == 'href="../c4.html"'
    assert rewrite('href="/architecture/e"', "..", ".html") == 'href="../e/index.html"'
    # Live, the whole substitution is an identity transform, so the served page runs the
    # same code path and the rewrite cannot rot in the direction nobody checks offline.
    for href in ("/architecture", "/architecture/e", "/architecture/e/x", "/architecture/c4"):
        markup = f'href="{href}"'
        assert rewrite(markup, "/architecture", "") == markup


def test_solution_route_is_the_landing_page():
    client = _client()
    resp = client.get("/architecture")
    assert resp.status_code == 200
    assert resp.text.count('href="/architecture/e/') >= 60
    assert 'class="diag"' not in resp.text, "a clean model must not show the banner"


def test_unconfirmed_link_says_so_and_keeps_its_note(model, pages):
    """`todo: true` is the honest alternative to inventing a URL.

    The Airflow entry is the live example: it has upstream product docs but nobody
    has the iDiscovery per-environment URLs, so the page must not read as though
    the apache.org link is what someone came for.
    """
    page = pages["ts_airflow"]
    ref = next(r for r in page["references"] if r["id"] == "airflow")
    assert ref["todo"] is True
    assert not page["environments"], "no envs are known for airflow yet"
    assert "platform team" in ref["note"], "the note explains how to close the gap"

    html = render_element_html("ts_airflow", model)
    assert "URL not yet confirmed" in html, (
        "a todo link with a homepage still has to admit the real URLs are missing"
    )
    assert "Get the per-environment URLs from the platform team" in html


def test_c4_absolute_links_are_all_rewritten_for_file_urls():
    """The C4 page is not rendered through the shell, so it fixes its own links.

    template.html keeps exactly one injection point by design, which means it cannot
    receive a base prefix and instead rewrites its absolute hrefs in the browser when
    opened over file://. Each link now carries its own offline target in
    ``data-file-href`` rather than being named in a script-side list, so the pairing is
    checked on the anchor itself - a link added without one is a dead link offline, and
    that is the whole failure this test exists to prevent.
    """
    template = template_path().read_text(encoding="utf-8")
    anchors = re.findall(r'<a\b[^>]*href="(/architecture[^"]*)"[^>]*>', template)
    assert anchors, "expected the C4 page to link out to the rest of the site"

    for tag in re.findall(r'<a\b[^>]*href="/architecture[^"]*"[^>]*>', template):
        assert "data-file-href" in tag, (
            f"{tag} points at a live route with no offline target, so it is dead over "
            f"file://; add data-file-href"
        )
    assert 'querySelectorAll("a[data-file-href]")' in template, (
        "the offline rewrite must read the attribute, or the attributes are decoration"
    )
    assert find_absolute_site_hrefs(render_c4_html()) == [], (
        "every absolute link on the C4 page must be marked as self-rewriting"
    )


def test_c4_page_is_not_a_dead_end():
    """Both escape hatches must be live routes, since the nav now leads people here."""
    client = _client()
    c4 = client.get("/architecture/c4")
    assert 'href="/architecture"' in c4.text
    assert 'href="/architecture/e"' in c4.text
    for href in ("/architecture", "/architecture/e"):
        assert client.get(href).status_code == 200


def test_every_rendered_page_is_well_formed(model, pages):
    """These pages are built by string concatenation, so tag balance is not free.

    A stray unclosed <div> in a panel does not raise anything - it silently swallows
    the rest of the diagram in the browser, which is exactly the kind of defect that
    reaches a reader before it reaches a developer.
    """
    from html.parser import HTMLParser

    void = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
            "meta", "source", "track", "wbr"}

    class Check(HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=True)
            self.stack: list[tuple[str, tuple[int, int]]] = []
            self.problems: list[str] = []

        def handle_starttag(self, tag, attrs):
            if tag not in void:
                self.stack.append((tag, self.getpos()))

        def handle_endtag(self, tag):
            if tag in void:
                return
            if not self.stack:
                self.problems.append(f"</{tag}> at {self.getpos()} closes nothing")
            elif self.stack[-1][0] != tag:
                self.problems.append(
                    f"</{tag}> at {self.getpos()} closes <{self.stack[-1][0]}> "
                    f"opened at {self.stack[-1][1]}"
                )
                self.stack.pop()
            else:
                self.stack.pop()

    def check(name: str, html: str) -> None:
        parser = Check()
        parser.feed(html)
        assert not parser.problems, f"{name}: " + "; ".join(parser.problems)
        assert not parser.stack, f"{name}: unclosed {[t for t, _ in parser.stack]}"

    check("solution", render_solution_html(model))
    check("element index", render_element_index_html(model))
    # Every element page: the interesting variation is in the optional cards, and a
    # page with (say) no environments table takes a different branch than one with.
    for element_id in pages:
        check(element_id, render_element_html(element_id, model))
