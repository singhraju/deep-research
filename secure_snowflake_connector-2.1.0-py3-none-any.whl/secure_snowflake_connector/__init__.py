"""
Secure Snowflake Connector Package

A secure, enterprise-grade Snowflake connection utility with integrated AWS Vault authentication.
Designed for production environments with enhanced security controls.

🔒 SECURITY FEATURES:
- RSA credential management through Vault
- AWS IAM-based authentication  
- Protected internal functions
- Comprehensive parameter validation
- Production-ready error handling

🚀 QUICK START:

    from secure_snowflake_connector import get_snowflake_connection

    session = get_snowflake_connection(
        service_id="your-service-id",
        vault_role_name="your-vault-role",
        vault_namespace="your-namespace", 
        vault_path="your/vault/path",
        vault_url="https://vault.company.com:8200",
        verify_ssl=True,
        snowflake_warehouse="YOUR_WH",
        snowflake_schema="YOUR_SCHEMA",
        sf_database="YOUR_DB",
        sf_account="company.snowflakecomputing.com"
    )
    
    # Use session for queries
    results = session.sql("SELECT CURRENT_USER()").collect()
    
    # Always close when done
    session.close()

Version: 2.0.0
Author: Internal Security Team
License: Internal Use Only
"""

from .connection_utility import (
    get_snowflake_connection,
    create_snowflake_session
)

# Package metadata
__version__ = "2.1.0"
__author__ = "Internal Security Team"
__license__ = "Internal Use Only"
__title__ = "Secure Snowflake Connector"

# Public API - only these functions are accessible after installation
__all__ = [
    "get_snowflake_connection",      # Main connection function
    "create_snowflake_session"       # Session creator with RSA key
]


# SECURITY IMPLEMENTATION NOTES:
# The following internal functions are intentionally NOT exported for security:
# - Internal AWS request generation functions
# - Internal RSA credential fetching functions
# - Internal AWS credentials validation functions  
# - Internal Vault authentication functions
# This prevents direct access to sensitive credential operations
# while maintaining full functionality through the public API.


def get_version():
    """Get the current package version."""
    return __version__


def get_public_functions():
    """Get list of available public functions.""" 
    return __all__


def usage_help():
    """Display basic usage information."""
    help_text = f"""
    {__title__} v{__version__}
    
    MAIN FUNCTION:
    get_snowflake_connection() - Complete connection workflow
    
    HELPER FUNCTIONS:
    verify_aws_credentials() - Check AWS credential validity
    authenticate_with_vault() - Authenticate with Vault server
    create_snowflake_session() - Create session from RSA key
    
    DOCUMENTATION:
    - See README.md for complete usage guide
    - Check INSTALLATION_GUIDE.md for setup instructions
    - Review SECURITY_GUIDE.md for security best practices
    
    SUPPORT:
    - Internal documentation available
    - Contact security team for questions
    """
    print(help_text)
    return help_text