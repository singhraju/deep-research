"""
Secure Snowflake Connection Utility

This module provides secure functions to:
1. Authenticate with AWS and Vault
2. Establish Snowflake connection using RSA key
3. Return a ready-to-use Snowflake session

Security Note: Internal credential fetching functions are protected from external access.
"""

import boto3
import json
import base64
import requests
import os
from datetime import datetime
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from snowflake.snowpark import Session
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend


def _generate_vault_request(role_name=""):
    """Generate a signed AWS request for Vault authentication (INTERNAL USE ONLY)"""
    # STS uses a global endpoint that requires us-east-1 region for signing
    sts_region = "us-east-1"
    aws_region = os.getenv("AWS_REGION", "us-east-1")  # Your default AWS region
    
    session = boto3.session.Session(region_name=aws_region)
    credentials = session.get_credentials().get_frozen_credentials()

    # Prepare STS request components
    request_url = "https://sts.amazonaws.com/"
    request_body = "Action=GetCallerIdentity&Version=2011-06-15"
    headers = {
        "Host": "sts.amazonaws.com",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Amz-Date": datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"),
    }
    
    # Add security token if using temporary credentials
    if credentials.token:
        headers["X-Amz-Security-Token"] = credentials.token

    # Sign the request - MUST use us-east-1 for STS global endpoint
    aws_request = AWSRequest(
        method="POST",
        url=request_url,
        data=request_body,
        headers=headers
    )
    SigV4Auth(credentials, "sts", sts_region).add_auth(aws_request)

    # Filter required headers for Vault
    required_headers = ["Host", "Authorization", "Content-Type", "X-Amz-Date"]  
    if credentials.token:
        required_headers.append("X-Amz-Security-Token")
    
    filtered_headers = {k: v for k, v in aws_request.headers.items() 
                       if k in required_headers}

    return {
        'iam_http_request_method': aws_request.method,
        'iam_request_url': base64.b64encode(request_url.encode('utf-8')).decode('utf-8'),
        'iam_request_body': base64.b64encode(request_body.encode('utf-8')).decode('utf-8'),
        'iam_request_headers': filtered_headers,
        'role': role_name,
    }


def _verify_aws_credentials():
    """
    Verify that AWS credentials are valid (INTERNAL USE ONLY).
    
    Returns:
        tuple: (is_valid: bool, info: dict or str)
            - If valid: (True, {'Account': str, 'ARN': str, 'UserId': str})
            - If invalid: (False, error_message: str)
            
    Example:
        >>> is_valid, info = _verify_aws_credentials()
        >>> if is_valid:
        ...     print(f"Connected to AWS Account: {info['Account']}")
        ... else:
        ...     print(f"AWS Error: {info}")
    """
    aws_region = os.getenv("AWS_REGION", "us-east-2")
    session = boto3.session.Session(region_name=aws_region)
    credentials = session.get_credentials().get_frozen_credentials()

    try:
        client = session.client("sts")
        response = client.get_caller_identity()
        return True, {
            'Account': response['Account'],
            'ARN': response['Arn'], 
            'UserId': response['UserId']
        }
    except Exception as e:
        return False, str(e)


def _authenticate_with_vault(vault_url, role_name, verify_ssl=False, cert_path=None):
    """
    Authenticate with Vault using AWS IAM method (INTERNAL USE ONLY).
    
    Args:
        vault_url (str): Vault server URL (e.g., "https://vault.example.com:8200")
        role_name (str): Vault role name for AWS IAM authentication
        verify_ssl (bool): Enable SSL certificate verification (default: False)
        cert_path (str, optional): Path to custom CA certificate file
        
    Returns:
        str: Vault authentication token
        
    Raises:
        Exception: If authentication fails or network errors occur
        
    Example:
        >>> token = _authenticate_with_vault(
        ...     "https://vault.company.com:8200",
        ...     "snowflake-role",
        ...     verify_ssl=True
        ... )
        >>> print("Authenticated successfully!")
    """
    signed_request = _generate_vault_request(role_name)

    payload = {
        "role": signed_request['role'],
        "iam_http_request_method": signed_request['iam_http_request_method'],
        "iam_request_url": signed_request['iam_request_url'],
        "iam_request_body": signed_request['iam_request_body'],
        "iam_request_headers": signed_request['iam_request_headers'],
    }

    verify = cert_path if cert_path else verify_ssl
    auth_url = f"{vault_url}/v1/auth/aws/login"

    try:
        response = requests.post(auth_url, json=payload, verify=verify)
        if response.status_code == 200:
            auth_data = response.json()
            return auth_data.get('auth', {}).get('client_token')
        else:
            error_msg = f"Vault authentication failed: {response.status_code}"
            if response.text:
                error_msg += f"\nResponse: {response.text}"
            raise Exception(error_msg)
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error during Vault authentication: {e}")


def _fetch_rsa_token(vault_url, vault_token, namespace, path, verify_ssl=False):
    """
    Fetch RSA token from Vault using authenticated token (INTERNAL USE ONLY).
    
    This function is intentionally private to prevent direct access to RSA credentials.
    """
    url = f"{vault_url}/v1/{path}"
    headers = {
        "X-Vault-Token": vault_token,
        "X-Vault-Namespace": namespace
    }

    try:
        response = requests.get(url, headers=headers, verify=verify_ssl)
        
        if response.status_code == 200:
            try:
                rsa_data = response.json()
                return rsa_data
            except json.JSONDecodeError:
                raise Exception(f"Response is not valid JSON: {response.text}")
        else:
            raise Exception(f"Failed to fetch RSA token. Status: {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error during RSA token fetch: {e}")


def create_snowflake_session(
    rsa_private_key_pem, 
    service_id,
    sf_account,
    sf_database,
    snowflake_schema,
    snowflake_warehouse
):
    """
    Create Snowflake session using RSA private key and connection parameters.
    
    Args:
        rsa_private_key_pem (str): RSA private key in PEM format
        service_id (str): Snowflake service/user identifier
        sf_account (str): Snowflake account identifier 
        sf_database (str): Target database name
        snowflake_schema (str): Target schema name
        snowflake_warehouse (str): Compute warehouse name
        
    Returns:
        snowflake.snowpark.Session: Active Snowflake session
        
    Raises:
        Exception: If session creation fails or parameters are invalid
        
    Example:
        >>> session = create_snowflake_session(
        ...     rsa_key_pem,
        ...     "my-service-id", 
        ...     "company.snowflakecomputing.com",
        ...     "PROD_DB",
        ...     "PUBLIC",
        ...     "COMPUTE_WH"
        ... )
        >>> results = session.sql("SELECT CURRENT_USER()").collect()
    """
    
    # Validate required parameters
    required_params = {
        'rsa_private_key_pem': rsa_private_key_pem,
        'service_id': service_id,
        'sf_account': sf_account,
        'sf_database': sf_database,
        'snowflake_schema': snowflake_schema,
        'snowflake_warehouse': snowflake_warehouse
    }
    
    missing_params = []
    for param_name, param_value in required_params.items():
        if param_value is None or (isinstance(param_value, str) and param_value.strip() == ''):
            missing_params.append(param_name)
    
    if missing_params:
        raise Exception(f"Missing required Snowflake parameters: {', '.join(missing_params)}")
    
    try:
        # Convert PEM key to bytes if it's a string
        if isinstance(rsa_private_key_pem, str):
            private_key_bytes = rsa_private_key_pem.encode('utf-8')
        else:
            private_key_bytes = rsa_private_key_pem
            
        # Load the private key and convert to DER format
        p_key = serialization.load_pem_private_key(
            private_key_bytes,
            password=None,
            backend=default_backend()
        )
        pkb = p_key.private_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )

        # Build connection parameters using provided values
        connection_parameters = {
            "account": sf_account,
            "user": service_id, 
            "private_key": pkb,
            "database": sf_database,
            "schema": snowflake_schema,
            "warehouse": snowflake_warehouse,
            "role": f"{service_id}_PRIVS"
        }

        # Create session
        session = Session.builder.configs(connection_parameters).create()
        return session
        
    except Exception as e:
        raise Exception(f"Failed to create Snowflake session: {e}")


def get_snowflake_connection(
    service_id,
    vault_role_name,
    vault_namespace, 
    vault_path,
    vault_url,
    verify_ssl,
    snowflake_warehouse,
    snowflake_schema,
    sf_database,
    sf_account,
    verbose=True
):
    """
    Main utility function to get a Snowflake connection with secure credential management.
    
    This function handles the complete authentication workflow:
    1. Validates AWS credentials
    2. Authenticates with Vault using AWS IAM
    3. Securely retrieves RSA credentials (internal only)
    4. Creates and returns a ready-to-use Snowflake session
    
    Args:
        service_id (str): Service ID for RSA token fetching (REQUIRED)
        vault_role_name (str): Vault role name for AWS IAM authentication (REQUIRED)
        vault_namespace (str): Vault namespace (REQUIRED)
        vault_path (str): Vault path for RSA credentials (REQUIRED)
        vault_url (str): Vault URL including port (REQUIRED)
        verify_ssl (bool): Enable SSL verification (REQUIRED)
        snowflake_warehouse (str): Snowflake warehouse name (REQUIRED)
        snowflake_schema (str): Snowflake schema name (REQUIRED)
        sf_database (str): Snowflake database name (REQUIRED)
        sf_account (str): Snowflake account identifier (REQUIRED)
        verbose (bool): Enable verbose logging (default: True)
    
    Returns:
        snowflake.snowpark.Session: Connected and ready-to-use Snowflake session
        
    Raises:
        Exception: If any step fails or required parameters are missing
        
    Example:
        >>> # Basic usage
        >>> session = get_snowflake_connection(
        ...     service_id="my-service-id",
        ...     vault_role_name="snowflake-prod-role",
        ...     vault_namespace="production",
        ...     vault_path="creds/snowflake/service-account",
        ...     vault_url="https://vault.company.com:8200",
        ...     verify_ssl=True,
        ...     snowflake_warehouse="COMPUTE_WH",
        ...     snowflake_schema="PUBLIC",
        ...     sf_database="PROD_DB",
        ...     sf_account="company.snowflakecomputing.com"
        ... )
        >>> 
        >>> # Use the session
        >>> results = session.sql("SELECT COUNT(*) FROM my_table").collect()
        >>> print(f"Row count: {results[0][0]}")
        >>> 
        >>> # Always close when done
        >>> session.close()
        
    Security Notes:
        - RSA credential retrieval is handled internally and not exposed
        - All parameters are validated before processing
        - Supports both permanent and temporary AWS credentials
        - Uses secure Vault authentication via AWS IAM
    """
    
    # Validate all required parameters
    required_params = {
        'service_id': service_id,
        'vault_role_name': vault_role_name,
        'vault_namespace': vault_namespace,
        'vault_path': vault_path,
        'vault_url': vault_url,
        'snowflake_warehouse': snowflake_warehouse,
        'snowflake_schema': snowflake_schema,
        'sf_database': sf_database,
        'sf_account': sf_account
    }
    
    # Check for missing or empty parameters
    missing_params = []
    for param_name, param_value in required_params.items():
        if param_value is None or (isinstance(param_value, str) and param_value.strip() == ''):
            missing_params.append(param_name)
    
    if missing_params:
        raise Exception(f"Missing required parameters: {', '.join(missing_params)}. All parameters must be provided.")
    
    # Validate verify_ssl is boolean
    if not isinstance(verify_ssl, bool):
        raise Exception(f"verify_ssl must be a boolean value, got: {type(verify_ssl).__name__}")
    
    if verbose:
        print("🔄 Starting Snowflake connection process...")
    
    try:
        # Step 1: Verify AWS credentials
        if verbose:
            print("🔐 Verifying AWS credentials...")
        
        aws_valid, aws_info = _verify_aws_credentials()
        if not aws_valid:
            raise Exception(f"AWS credential verification failed: {aws_info}")
        
        if verbose:
            print(f"✅ AWS credentials verified - Account: {aws_info['Account']}")

        # Step 2: Authenticate with Vault
        if verbose:
            print(f"🏛️  Authenticating with Vault (role: {vault_role_name})...")
            
        vault_token = _authenticate_with_vault(
            vault_url,
            vault_role_name,
            verify_ssl=verify_ssl
        )

        if not vault_token:
            raise Exception("Failed to obtain Vault token")

        if verbose:
            print(f"✅ Vault authentication successful")

        # Step 3: Fetch RSA credentials (internal function - not exposed to users)
        if verbose:
            print(f"🔑 Retrieving RSA credentials from: {vault_path}")
            
        rsa_data = _fetch_rsa_token(
            vault_url,
            vault_token,
            vault_namespace,
            vault_path,
            verify_ssl=verify_ssl
        )

        if not rsa_data:
            raise Exception("Failed to fetch RSA credentials")

        # Step 4: Extract RSA private key
        if 'data' in rsa_data:
            creds = rsa_data['data']
            
            if 'rsa_private_key' not in creds:
                raise Exception(f"RSA private key not found in credentials. Available keys: {list(creds.keys())}")
                
            rsa_private_key = creds['rsa_private_key']
            
            if verbose:
                print("✅ RSA credentials retrieved successfully")
        else:
            raise Exception("Unexpected response structure from Vault")

        # Step 5: Create Snowflake session
        if verbose:
            print("❄️  Creating Snowflake session...")
            
        session = create_snowflake_session(
            rsa_private_key, 
            service_id,
            sf_account=sf_account,
            sf_database=sf_database,
            snowflake_schema=snowflake_schema,
            snowflake_warehouse=snowflake_warehouse
        )
        
        if verbose:
            print("🎉 Snowflake session created successfully!")
            
            # Test connection
            try:
                results = session.sql("SELECT CURRENT_ACCOUNT(), CURRENT_ROLE(), CURRENT_USER()").collect()
                for row in results:
                    print(f"   📊 Account: {row['CURRENT_ACCOUNT()']}")
                    print(f"   👤 Role: {row['CURRENT_ROLE()']}")  
                    print(f"   🆔 User: {row['CURRENT_USER()']}")
            except:
                pass  # Skip test if it fails

        return session
        
    except Exception as e:
        if verbose:
            print(f"❌ Error: {e}")
        raise e